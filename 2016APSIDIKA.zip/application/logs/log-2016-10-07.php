<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-10-07 09:28:26 --> Config Class Initialized
DEBUG - 2016-10-07 09:28:26 --> Hooks Class Initialized
DEBUG - 2016-10-07 09:28:26 --> Utf8 Class Initialized
DEBUG - 2016-10-07 09:28:26 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 09:28:26 --> URI Class Initialized
DEBUG - 2016-10-07 09:28:26 --> Router Class Initialized
DEBUG - 2016-10-07 09:28:26 --> No URI present. Default controller set.
DEBUG - 2016-10-07 09:28:26 --> Output Class Initialized
DEBUG - 2016-10-07 09:28:26 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 09:28:26 --> Security Class Initialized
DEBUG - 2016-10-07 09:28:26 --> Input Class Initialized
DEBUG - 2016-10-07 09:28:26 --> XSS Filtering completed
DEBUG - 2016-10-07 09:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 09:28:26 --> Language Class Initialized
DEBUG - 2016-10-07 09:28:26 --> Loader Class Initialized
DEBUG - 2016-10-07 09:28:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 09:28:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 09:28:26 --> Helper loaded: url_helper
DEBUG - 2016-10-07 09:28:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 09:28:26 --> Helper loaded: file_helper
DEBUG - 2016-10-07 09:28:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 09:28:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 09:28:26 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 09:28:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 09:28:26 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 09:28:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 09:28:26 --> Helper loaded: common_helper
DEBUG - 2016-10-07 09:28:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 09:28:26 --> Helper loaded: common_helper
DEBUG - 2016-10-07 09:28:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 09:28:26 --> Helper loaded: form_helper
DEBUG - 2016-10-07 09:28:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 09:28:26 --> Helper loaded: security_helper
DEBUG - 2016-10-07 09:28:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 09:28:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 09:28:26 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 09:28:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 09:28:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 09:28:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 09:28:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 09:28:26 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 09:28:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 09:28:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 09:28:26 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 09:28:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 09:28:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 09:28:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 09:28:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 09:28:26 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 09:28:26 --> Database Driver Class Initialized
DEBUG - 2016-10-07 09:28:26 --> Session Class Initialized
DEBUG - 2016-10-07 09:28:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 09:28:26 --> Helper loaded: string_helper
DEBUG - 2016-10-07 09:28:26 --> A session cookie was not found.
DEBUG - 2016-10-07 09:28:26 --> Session routines successfully run
DEBUG - 2016-10-07 09:28:26 --> Native_session Class Initialized
DEBUG - 2016-10-07 09:28:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 09:28:26 --> Form Validation Class Initialized
DEBUG - 2016-10-07 09:28:26 --> Form Validation Class Initialized
DEBUG - 2016-10-07 09:28:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 09:28:26 --> Controller Class Initialized
DEBUG - 2016-10-07 09:28:26 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 09:28:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 09:28:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 09:28:26 --> Carabiner: library configured.
DEBUG - 2016-10-07 09:28:26 --> Carabiner: library configured.
DEBUG - 2016-10-07 09:28:26 --> User Agent Class Initialized
DEBUG - 2016-10-07 09:28:26 --> Model Class Initialized
DEBUG - 2016-10-07 09:28:26 --> Model Class Initialized
DEBUG - 2016-10-07 09:28:26 --> Model Class Initialized
ERROR - 2016-10-07 09:28:27 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-10-07 09:28:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-10-07 09:28:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-10-07 09:28:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 09:28:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 09:28:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 09:28:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 09:28:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 09:28:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-07 09:28:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-07 09:28:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 09:28:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 09:28:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 09:28:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 09:28:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 09:28:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 09:28:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 09:28:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-07 09:28:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-07 09:28:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 09:28:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 09:28:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-10-07 09:28:27 --> Final output sent to browser
DEBUG - 2016-10-07 09:28:27 --> Total execution time: 1.0705
DEBUG - 2016-10-07 09:28:29 --> Config Class Initialized
DEBUG - 2016-10-07 09:28:29 --> Hooks Class Initialized
DEBUG - 2016-10-07 09:28:29 --> Utf8 Class Initialized
DEBUG - 2016-10-07 09:28:29 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 09:28:29 --> URI Class Initialized
DEBUG - 2016-10-07 09:28:29 --> Router Class Initialized
DEBUG - 2016-10-07 09:28:29 --> Output Class Initialized
DEBUG - 2016-10-07 09:28:29 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 09:28:29 --> Security Class Initialized
DEBUG - 2016-10-07 09:28:29 --> Input Class Initialized
DEBUG - 2016-10-07 09:28:29 --> XSS Filtering completed
DEBUG - 2016-10-07 09:28:29 --> XSS Filtering completed
DEBUG - 2016-10-07 09:28:29 --> XSS Filtering completed
DEBUG - 2016-10-07 09:28:29 --> XSS Filtering completed
DEBUG - 2016-10-07 09:28:29 --> XSS Filtering completed
DEBUG - 2016-10-07 09:28:29 --> XSS Filtering completed
DEBUG - 2016-10-07 09:28:29 --> XSS Filtering completed
DEBUG - 2016-10-07 09:28:29 --> XSS Filtering completed
DEBUG - 2016-10-07 09:28:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 09:28:29 --> Language Class Initialized
DEBUG - 2016-10-07 09:28:29 --> Loader Class Initialized
DEBUG - 2016-10-07 09:28:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 09:28:29 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 09:28:29 --> Helper loaded: url_helper
DEBUG - 2016-10-07 09:28:29 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 09:28:29 --> Helper loaded: file_helper
DEBUG - 2016-10-07 09:28:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 09:28:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 09:28:29 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 09:28:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 09:28:29 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 09:28:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 09:28:29 --> Helper loaded: common_helper
DEBUG - 2016-10-07 09:28:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 09:28:29 --> Helper loaded: common_helper
DEBUG - 2016-10-07 09:28:29 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 09:28:29 --> Helper loaded: form_helper
DEBUG - 2016-10-07 09:28:29 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 09:28:29 --> Helper loaded: security_helper
DEBUG - 2016-10-07 09:28:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 09:28:29 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 09:28:29 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 09:28:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 09:28:29 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 09:28:29 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 09:28:29 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 09:28:29 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 09:28:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 09:28:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 09:28:29 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 09:28:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 09:28:29 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 09:28:29 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 09:28:29 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 09:28:29 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 09:28:29 --> Database Driver Class Initialized
DEBUG - 2016-10-07 09:28:29 --> Session Class Initialized
DEBUG - 2016-10-07 09:28:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 09:28:29 --> Helper loaded: string_helper
DEBUG - 2016-10-07 09:28:29 --> Session routines successfully run
DEBUG - 2016-10-07 09:28:29 --> Native_session Class Initialized
DEBUG - 2016-10-07 09:28:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 09:28:29 --> Form Validation Class Initialized
DEBUG - 2016-10-07 09:28:29 --> Form Validation Class Initialized
DEBUG - 2016-10-07 09:28:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 09:28:29 --> Controller Class Initialized
DEBUG - 2016-10-07 09:28:29 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 09:28:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 09:28:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 09:28:29 --> Carabiner: library configured.
DEBUG - 2016-10-07 09:28:29 --> Carabiner: library configured.
DEBUG - 2016-10-07 09:28:29 --> User Agent Class Initialized
DEBUG - 2016-10-07 09:28:29 --> Model Class Initialized
DEBUG - 2016-10-07 09:28:29 --> Model Class Initialized
DEBUG - 2016-10-07 09:28:29 --> Model Class Initialized
DEBUG - 2016-10-07 09:28:29 --> Model Class Initialized
DEBUG - 2016-10-07 09:28:29 --> Model Class Initialized
DEBUG - 2016-10-07 09:28:29 --> Model Class Initialized
DEBUG - 2016-10-07 09:28:29 --> Model Class Initialized
DEBUG - 2016-10-07 09:28:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-10-07 09:28:30 --> Final output sent to browser
DEBUG - 2016-10-07 09:28:30 --> Total execution time: 1.4910
DEBUG - 2016-10-07 09:47:31 --> Config Class Initialized
DEBUG - 2016-10-07 09:47:31 --> Hooks Class Initialized
DEBUG - 2016-10-07 09:47:31 --> Utf8 Class Initialized
DEBUG - 2016-10-07 09:47:31 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 09:47:31 --> URI Class Initialized
DEBUG - 2016-10-07 09:47:31 --> Router Class Initialized
DEBUG - 2016-10-07 09:47:31 --> Output Class Initialized
DEBUG - 2016-10-07 09:47:31 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 09:47:31 --> Security Class Initialized
DEBUG - 2016-10-07 09:47:31 --> Input Class Initialized
DEBUG - 2016-10-07 09:47:31 --> XSS Filtering completed
DEBUG - 2016-10-07 09:47:31 --> XSS Filtering completed
DEBUG - 2016-10-07 09:47:31 --> XSS Filtering completed
DEBUG - 2016-10-07 09:47:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 09:47:31 --> Language Class Initialized
DEBUG - 2016-10-07 09:47:31 --> Loader Class Initialized
DEBUG - 2016-10-07 09:47:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 09:47:31 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 09:47:31 --> Helper loaded: url_helper
DEBUG - 2016-10-07 09:47:31 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 09:47:31 --> Helper loaded: file_helper
DEBUG - 2016-10-07 09:47:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 09:47:31 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 09:47:31 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 09:47:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 09:47:31 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 09:47:31 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 09:47:31 --> Helper loaded: common_helper
DEBUG - 2016-10-07 09:47:31 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 09:47:31 --> Helper loaded: common_helper
DEBUG - 2016-10-07 09:47:31 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 09:47:31 --> Helper loaded: form_helper
DEBUG - 2016-10-07 09:47:31 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 09:47:31 --> Helper loaded: security_helper
DEBUG - 2016-10-07 09:47:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 09:47:31 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 09:47:31 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 09:47:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 09:47:31 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 09:47:31 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 09:47:31 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 09:47:31 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 09:47:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 09:47:31 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 09:47:31 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 09:47:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 09:47:31 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 09:47:31 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 09:47:31 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 09:47:31 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 09:47:31 --> Database Driver Class Initialized
ERROR - 2016-10-07 09:47:31 --> Severity: Warning  --> pg_connect(): Unable to connect to PostgreSQL server: FATAL:  database &quot;db_sidika&quot; does not exist E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 87
ERROR - 2016-10-07 09:47:31 --> Unable to connect to the database
DEBUG - 2016-10-07 09:47:31 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-10-07 14:28:49 --> Config Class Initialized
DEBUG - 2016-10-07 14:28:49 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:28:49 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:28:49 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:28:49 --> URI Class Initialized
DEBUG - 2016-10-07 14:28:49 --> Router Class Initialized
DEBUG - 2016-10-07 14:28:49 --> No URI present. Default controller set.
DEBUG - 2016-10-07 14:28:49 --> Output Class Initialized
DEBUG - 2016-10-07 14:28:49 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:28:49 --> Security Class Initialized
DEBUG - 2016-10-07 14:28:49 --> Input Class Initialized
DEBUG - 2016-10-07 14:28:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:28:49 --> Language Class Initialized
DEBUG - 2016-10-07 14:28:49 --> Loader Class Initialized
DEBUG - 2016-10-07 14:28:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:28:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:28:49 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:28:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:28:49 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:28:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:28:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:28:49 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:28:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:28:49 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:28:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:28:49 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:28:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:28:49 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:28:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:28:49 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:28:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:28:49 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:28:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:28:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:28:49 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:28:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:28:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:28:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:28:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:28:49 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:28:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:28:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:28:49 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:28:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:28:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:28:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:28:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:28:49 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:28:49 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:28:49 --> Session Class Initialized
DEBUG - 2016-10-07 14:28:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:28:49 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:28:49 --> A session cookie was not found.
DEBUG - 2016-10-07 14:28:49 --> Session routines successfully run
DEBUG - 2016-10-07 14:28:49 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:28:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:28:49 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:28:49 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:28:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:28:49 --> Controller Class Initialized
DEBUG - 2016-10-07 14:28:49 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:28:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:28:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:28:49 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:28:49 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:28:49 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:28:49 --> Model Class Initialized
DEBUG - 2016-10-07 14:28:49 --> Model Class Initialized
DEBUG - 2016-10-07 14:28:49 --> Model Class Initialized
ERROR - 2016-10-07 14:28:49 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-10-07 14:28:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-10-07 14:28:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-10-07 14:28:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:28:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:28:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:28:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:28:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:28:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-07 14:28:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-07 14:28:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:28:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:28:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:28:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:28:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:28:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:28:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:28:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-07 14:28:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-07 14:28:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:28:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:28:49 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-10-07 14:28:49 --> Final output sent to browser
DEBUG - 2016-10-07 14:28:49 --> Total execution time: 0.3088
DEBUG - 2016-10-07 14:28:50 --> Config Class Initialized
DEBUG - 2016-10-07 14:28:50 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:28:50 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:28:50 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:28:50 --> URI Class Initialized
DEBUG - 2016-10-07 14:28:50 --> Router Class Initialized
DEBUG - 2016-10-07 14:28:50 --> Output Class Initialized
DEBUG - 2016-10-07 14:28:50 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:28:50 --> Security Class Initialized
DEBUG - 2016-10-07 14:28:50 --> Input Class Initialized
DEBUG - 2016-10-07 14:28:50 --> XSS Filtering completed
DEBUG - 2016-10-07 14:28:50 --> XSS Filtering completed
DEBUG - 2016-10-07 14:28:50 --> XSS Filtering completed
DEBUG - 2016-10-07 14:28:50 --> XSS Filtering completed
DEBUG - 2016-10-07 14:28:50 --> XSS Filtering completed
DEBUG - 2016-10-07 14:28:50 --> XSS Filtering completed
DEBUG - 2016-10-07 14:28:50 --> XSS Filtering completed
DEBUG - 2016-10-07 14:28:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:28:50 --> Language Class Initialized
DEBUG - 2016-10-07 14:28:50 --> Loader Class Initialized
DEBUG - 2016-10-07 14:28:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:28:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:28:50 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:28:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:28:50 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:28:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:28:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:28:50 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:28:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:28:50 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:28:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:28:50 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:28:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:28:50 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:28:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:28:50 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:28:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:28:50 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:28:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:28:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:28:50 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:28:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:28:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:28:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:28:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:28:50 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:28:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:28:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:28:50 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:28:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:28:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:28:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:28:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:28:50 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:28:50 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:28:50 --> Session Class Initialized
DEBUG - 2016-10-07 14:28:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:28:50 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:28:50 --> Session routines successfully run
DEBUG - 2016-10-07 14:28:50 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:28:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:28:50 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:28:50 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:28:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:28:50 --> Controller Class Initialized
DEBUG - 2016-10-07 14:28:50 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:28:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:28:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:28:50 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:28:50 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:28:50 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:28:50 --> Model Class Initialized
DEBUG - 2016-10-07 14:28:50 --> Model Class Initialized
DEBUG - 2016-10-07 14:28:50 --> Model Class Initialized
DEBUG - 2016-10-07 14:28:50 --> Model Class Initialized
DEBUG - 2016-10-07 14:28:50 --> Model Class Initialized
DEBUG - 2016-10-07 14:28:50 --> Model Class Initialized
DEBUG - 2016-10-07 14:28:50 --> Model Class Initialized
DEBUG - 2016-10-07 14:28:50 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-10-07 14:28:50 --> Final output sent to browser
DEBUG - 2016-10-07 14:28:50 --> Total execution time: 0.3220
DEBUG - 2016-10-07 14:28:56 --> Config Class Initialized
DEBUG - 2016-10-07 14:28:56 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:28:56 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:28:56 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:28:56 --> URI Class Initialized
DEBUG - 2016-10-07 14:28:56 --> Router Class Initialized
DEBUG - 2016-10-07 14:28:56 --> Output Class Initialized
DEBUG - 2016-10-07 14:28:56 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:28:56 --> Security Class Initialized
DEBUG - 2016-10-07 14:28:56 --> Input Class Initialized
DEBUG - 2016-10-07 14:28:56 --> XSS Filtering completed
DEBUG - 2016-10-07 14:28:56 --> XSS Filtering completed
DEBUG - 2016-10-07 14:28:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:28:56 --> Language Class Initialized
DEBUG - 2016-10-07 14:28:56 --> Loader Class Initialized
DEBUG - 2016-10-07 14:28:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:28:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:28:56 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:28:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:28:56 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:28:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:28:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:28:56 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:28:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:28:56 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:28:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:28:56 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:28:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:28:56 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:28:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:28:56 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:28:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:28:56 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:28:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:28:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:28:56 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:28:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:28:56 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:28:56 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:28:56 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:28:56 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:28:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:28:56 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:28:56 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:28:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:28:56 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:28:56 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:28:56 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:28:56 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:28:56 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:28:57 --> Session Class Initialized
DEBUG - 2016-10-07 14:28:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:28:57 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:28:57 --> Session routines successfully run
DEBUG - 2016-10-07 14:28:57 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:28:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:28:57 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:28:57 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:28:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:28:57 --> Controller Class Initialized
DEBUG - 2016-10-07 14:28:57 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:28:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:28:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:28:57 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:28:57 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:28:57 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:28:57 --> Model Class Initialized
DEBUG - 2016-10-07 14:28:57 --> Model Class Initialized
DEBUG - 2016-10-07 14:28:57 --> Model Class Initialized
DEBUG - 2016-10-07 14:28:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-10-07 14:28:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-07 14:28:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-07 14:28:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:28:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-07 14:28:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:28:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-07 14:28:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-07 14:28:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-07 14:28:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:28:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-07 14:28:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:28:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-07 14:28:57 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-10-07 14:28:57 --> Final output sent to browser
DEBUG - 2016-10-07 14:28:57 --> Total execution time: 0.2837
DEBUG - 2016-10-07 14:28:59 --> Config Class Initialized
DEBUG - 2016-10-07 14:28:59 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:28:59 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:28:59 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:28:59 --> URI Class Initialized
DEBUG - 2016-10-07 14:28:59 --> Router Class Initialized
DEBUG - 2016-10-07 14:28:59 --> Output Class Initialized
DEBUG - 2016-10-07 14:28:59 --> Security Class Initialized
DEBUG - 2016-10-07 14:28:59 --> Input Class Initialized
DEBUG - 2016-10-07 14:28:59 --> XSS Filtering completed
DEBUG - 2016-10-07 14:28:59 --> XSS Filtering completed
DEBUG - 2016-10-07 14:28:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:28:59 --> Language Class Initialized
DEBUG - 2016-10-07 14:28:59 --> Loader Class Initialized
DEBUG - 2016-10-07 14:28:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:28:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:28:59 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:28:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:28:59 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:28:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:28:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:28:59 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:28:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:28:59 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:28:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:28:59 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:28:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:28:59 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:28:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:28:59 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:28:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:28:59 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:28:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:28:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:28:59 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:28:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:28:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:28:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:28:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:28:59 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:28:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:28:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:28:59 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:28:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:28:59 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:28:59 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:28:59 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:28:59 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:28:59 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:28:59 --> Session Class Initialized
DEBUG - 2016-10-07 14:28:59 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:28:59 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:28:59 --> Session routines successfully run
DEBUG - 2016-10-07 14:28:59 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:28:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:28:59 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:28:59 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:28:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:28:59 --> Controller Class Initialized
DEBUG - 2016-10-07 14:28:59 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:28:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:28:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:28:59 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:28:59 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:28:59 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:28:59 --> Model Class Initialized
DEBUG - 2016-10-07 14:28:59 --> Model Class Initialized
DEBUG - 2016-10-07 14:28:59 --> Model Class Initialized
DEBUG - 2016-10-07 14:28:59 --> Model Class Initialized
DEBUG - 2016-10-07 14:28:59 --> Model Class Initialized
DEBUG - 2016-10-07 14:28:59 --> Model Class Initialized
DEBUG - 2016-10-07 14:28:59 --> Model Class Initialized
DEBUG - 2016-10-07 14:28:59 --> Model Class Initialized
ERROR - 2016-10-07 14:28:59 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-10-07 14:28:59 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-07 14:28:59 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-10-07 14:28:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-10-07 14:28:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-10-07 14:28:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-10-07 14:28:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-10-07 14:28:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-10-07 14:28:59 --> Final output sent to browser
DEBUG - 2016-10-07 14:28:59 --> Total execution time: 0.3076
DEBUG - 2016-10-07 14:28:59 --> Config Class Initialized
DEBUG - 2016-10-07 14:28:59 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:28:59 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:28:59 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:28:59 --> URI Class Initialized
DEBUG - 2016-10-07 14:28:59 --> Router Class Initialized
ERROR - 2016-10-07 14:28:59 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-10-07 14:29:06 --> Config Class Initialized
DEBUG - 2016-10-07 14:29:06 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:29:06 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:29:06 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:29:06 --> URI Class Initialized
DEBUG - 2016-10-07 14:29:06 --> Router Class Initialized
DEBUG - 2016-10-07 14:29:06 --> Output Class Initialized
DEBUG - 2016-10-07 14:29:06 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:29:06 --> Security Class Initialized
DEBUG - 2016-10-07 14:29:06 --> Input Class Initialized
DEBUG - 2016-10-07 14:29:06 --> XSS Filtering completed
DEBUG - 2016-10-07 14:29:06 --> XSS Filtering completed
DEBUG - 2016-10-07 14:29:06 --> XSS Filtering completed
DEBUG - 2016-10-07 14:29:06 --> XSS Filtering completed
DEBUG - 2016-10-07 14:29:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:29:06 --> Language Class Initialized
DEBUG - 2016-10-07 14:29:06 --> Loader Class Initialized
DEBUG - 2016-10-07 14:29:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:29:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:29:06 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:29:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:29:06 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:29:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:29:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:29:06 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:29:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:29:06 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:29:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:29:06 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:29:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:29:06 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:29:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:29:06 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:29:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:29:06 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:29:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:29:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:29:06 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:29:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:29:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:29:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:29:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:29:06 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:29:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:29:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:29:06 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:29:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:29:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:29:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:29:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:29:06 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:29:06 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:29:06 --> Session Class Initialized
DEBUG - 2016-10-07 14:29:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:29:06 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:29:06 --> Session routines successfully run
DEBUG - 2016-10-07 14:29:06 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:29:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:29:06 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:29:06 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:29:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:29:06 --> Controller Class Initialized
DEBUG - 2016-10-07 14:29:06 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:29:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:29:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:29:06 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:29:06 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:29:06 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:29:06 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:06 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:06 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:06 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:06 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:06 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:06 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:06 --> Model Class Initialized
ERROR - 2016-10-07 14:29:06 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-10-07 14:29:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-10-07 14:29:06 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:29:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:29:06 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-10-07 14:29:07 --> Config Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:29:07 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:29:07 --> URI Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Router Class Initialized
DEBUG - 2016-10-07 14:29:07 --> No URI present. Default controller set.
DEBUG - 2016-10-07 14:29:07 --> Output Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:29:07 --> Security Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Input Class Initialized
DEBUG - 2016-10-07 14:29:07 --> XSS Filtering completed
DEBUG - 2016-10-07 14:29:07 --> XSS Filtering completed
DEBUG - 2016-10-07 14:29:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:29:07 --> Language Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Loader Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:29:07 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:29:07 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:29:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:29:07 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:29:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:29:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:29:07 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:29:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:29:07 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:29:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:29:07 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:29:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:29:07 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:29:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:29:07 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:29:07 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:29:07 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:29:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:29:07 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:29:07 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:29:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:29:07 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:29:07 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:29:07 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:29:07 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:29:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:29:07 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:29:07 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:29:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:29:07 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:29:07 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:29:07 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:29:07 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:29:07 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Session Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:29:07 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:29:07 --> Session routines successfully run
DEBUG - 2016-10-07 14:29:07 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:29:07 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:29:07 --> Controller Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:29:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:29:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:29:07 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:29:07 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:29:07 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Model Class Initialized
ERROR - 2016-10-07 14:29:07 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-10-07 14:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-10-07 14:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-10-07 14:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-07 14:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-07 14:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-07 14:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-07 14:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:29:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-10-07 14:29:07 --> Final output sent to browser
DEBUG - 2016-10-07 14:29:07 --> Total execution time: 0.3038
DEBUG - 2016-10-07 14:29:07 --> Config Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:29:07 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:29:07 --> URI Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Router Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Output Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:29:07 --> Security Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Input Class Initialized
DEBUG - 2016-10-07 14:29:07 --> XSS Filtering completed
DEBUG - 2016-10-07 14:29:07 --> XSS Filtering completed
DEBUG - 2016-10-07 14:29:07 --> XSS Filtering completed
DEBUG - 2016-10-07 14:29:07 --> XSS Filtering completed
DEBUG - 2016-10-07 14:29:07 --> XSS Filtering completed
DEBUG - 2016-10-07 14:29:07 --> XSS Filtering completed
DEBUG - 2016-10-07 14:29:07 --> XSS Filtering completed
DEBUG - 2016-10-07 14:29:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:29:07 --> Language Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Loader Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:29:07 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:29:07 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:29:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:29:07 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:29:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:29:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:29:07 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:29:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:29:07 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:29:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:29:07 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:29:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:29:07 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:29:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:29:07 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:29:07 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:29:07 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:29:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:29:07 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:29:07 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:29:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:29:07 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:29:07 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:29:07 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:29:07 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:29:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:29:07 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:29:07 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:29:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:29:07 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:29:07 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:29:07 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:29:07 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:29:07 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Session Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:29:07 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:29:07 --> Session routines successfully run
DEBUG - 2016-10-07 14:29:07 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:29:07 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:29:07 --> Controller Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:29:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:29:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:29:07 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:29:07 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:29:07 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-10-07 14:29:07 --> Final output sent to browser
DEBUG - 2016-10-07 14:29:07 --> Total execution time: 0.3910
DEBUG - 2016-10-07 14:29:09 --> Config Class Initialized
DEBUG - 2016-10-07 14:29:09 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:29:09 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:29:09 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:29:09 --> URI Class Initialized
DEBUG - 2016-10-07 14:29:09 --> Router Class Initialized
DEBUG - 2016-10-07 14:29:09 --> Output Class Initialized
DEBUG - 2016-10-07 14:29:09 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:29:09 --> Security Class Initialized
DEBUG - 2016-10-07 14:29:09 --> Input Class Initialized
DEBUG - 2016-10-07 14:29:09 --> XSS Filtering completed
DEBUG - 2016-10-07 14:29:09 --> XSS Filtering completed
DEBUG - 2016-10-07 14:29:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:29:09 --> Language Class Initialized
DEBUG - 2016-10-07 14:29:09 --> Loader Class Initialized
DEBUG - 2016-10-07 14:29:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:29:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:29:09 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:29:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:29:09 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:29:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:29:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:29:09 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:29:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:29:09 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:29:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:29:09 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:29:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:29:09 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:29:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:29:09 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:29:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:29:09 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:29:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:29:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:29:09 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:29:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:29:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:29:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:29:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:29:09 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:29:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:29:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:29:09 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:29:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:29:09 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:29:09 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:29:09 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:29:09 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:29:09 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:29:09 --> Session Class Initialized
DEBUG - 2016-10-07 14:29:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:29:09 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:29:09 --> Session routines successfully run
DEBUG - 2016-10-07 14:29:09 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:29:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:29:09 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:29:09 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:29:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:29:09 --> Controller Class Initialized
DEBUG - 2016-10-07 14:29:09 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:29:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:29:09 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:29:09 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:29:09 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:29:09 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:29:09 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:09 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:09 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-10-07 14:29:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-07 14:29:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-07 14:29:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:29:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-07 14:29:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:29:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-07 14:29:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-07 14:29:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-07 14:29:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:29:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-07 14:29:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:29:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-07 14:29:09 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-10-07 14:29:09 --> Final output sent to browser
DEBUG - 2016-10-07 14:29:09 --> Total execution time: 0.3766
DEBUG - 2016-10-07 14:29:11 --> Config Class Initialized
DEBUG - 2016-10-07 14:29:11 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:29:11 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:29:11 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:29:11 --> URI Class Initialized
DEBUG - 2016-10-07 14:29:11 --> Router Class Initialized
DEBUG - 2016-10-07 14:29:11 --> Output Class Initialized
DEBUG - 2016-10-07 14:29:11 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:29:11 --> Security Class Initialized
DEBUG - 2016-10-07 14:29:11 --> Input Class Initialized
DEBUG - 2016-10-07 14:29:11 --> XSS Filtering completed
DEBUG - 2016-10-07 14:29:11 --> XSS Filtering completed
DEBUG - 2016-10-07 14:29:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:29:11 --> Language Class Initialized
DEBUG - 2016-10-07 14:29:11 --> Loader Class Initialized
DEBUG - 2016-10-07 14:29:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:29:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:29:11 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:29:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:29:11 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:29:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:29:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:29:11 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:29:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:29:11 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:29:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:29:11 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:29:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:29:12 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:29:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:29:12 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:29:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:29:12 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:29:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:29:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:29:12 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:29:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:29:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:29:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:29:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:29:12 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:29:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:29:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:29:12 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:29:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:29:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:29:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:29:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:29:12 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:29:12 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:29:12 --> Session Class Initialized
DEBUG - 2016-10-07 14:29:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:29:12 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:29:12 --> Session routines successfully run
DEBUG - 2016-10-07 14:29:12 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:29:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:29:12 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:29:12 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:29:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:29:12 --> Controller Class Initialized
DEBUG - 2016-10-07 14:29:12 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:29:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:29:12 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:29:12 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:29:12 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:29:12 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:29:12 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:12 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:12 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:12 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:12 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:12 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:12 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:12 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-07 14:29:12 --> Pagination Class Initialized
DEBUG - 2016-10-07 14:29:12 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-07 14:29:12 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/index.php
DEBUG - 2016-10-07 14:29:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-07 14:29:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-07 14:29:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:29:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-07 14:29:12 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-07 14:29:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:29:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-07 14:29:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-07 14:29:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-07 14:29:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:29:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-07 14:29:12 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-07 14:29:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:29:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-07 14:29:12 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55961f1d1ca16fdfc4239ae1901a174e
DEBUG - 2016-10-07 14:29:12 --> Final output sent to browser
DEBUG - 2016-10-07 14:29:12 --> Total execution time: 0.5188
DEBUG - 2016-10-07 14:29:18 --> Config Class Initialized
DEBUG - 2016-10-07 14:29:18 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:29:18 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:29:18 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:29:18 --> URI Class Initialized
DEBUG - 2016-10-07 14:29:18 --> Router Class Initialized
DEBUG - 2016-10-07 14:29:18 --> Output Class Initialized
DEBUG - 2016-10-07 14:29:18 --> Security Class Initialized
DEBUG - 2016-10-07 14:29:18 --> Input Class Initialized
DEBUG - 2016-10-07 14:29:18 --> XSS Filtering completed
DEBUG - 2016-10-07 14:29:18 --> XSS Filtering completed
DEBUG - 2016-10-07 14:29:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:29:18 --> Language Class Initialized
DEBUG - 2016-10-07 14:29:18 --> Loader Class Initialized
DEBUG - 2016-10-07 14:29:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:29:18 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:29:18 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:29:18 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:29:18 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:29:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:29:18 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:29:18 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:29:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:29:18 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:29:18 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:29:18 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:29:18 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:29:18 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:29:18 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:29:18 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:29:18 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:29:18 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:29:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:29:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:29:18 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:29:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:29:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:29:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:29:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:29:18 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:29:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:29:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:29:18 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:29:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:29:18 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:29:18 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:29:18 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:29:18 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:29:18 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:29:18 --> Session Class Initialized
DEBUG - 2016-10-07 14:29:18 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:29:18 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:29:18 --> Session routines successfully run
DEBUG - 2016-10-07 14:29:18 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:29:18 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:29:18 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:29:18 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:29:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:29:18 --> Controller Class Initialized
DEBUG - 2016-10-07 14:29:18 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:29:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:29:18 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:29:18 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:29:18 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:29:18 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:29:18 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:18 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:18 --> Model Class Initialized
ERROR - 2016-10-07 14:29:18 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-10-07 14:29:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-10-07 14:29:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:29:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:29:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:29:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:29:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:29:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:29:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:29:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:29:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:29:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:29:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:29:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:29:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:29:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:29:18 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-10-07 14:29:18 --> Final output sent to browser
DEBUG - 2016-10-07 14:29:18 --> Total execution time: 0.3760
DEBUG - 2016-10-07 14:29:26 --> Config Class Initialized
DEBUG - 2016-10-07 14:29:26 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:29:26 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:29:26 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:29:26 --> URI Class Initialized
DEBUG - 2016-10-07 14:29:26 --> Router Class Initialized
DEBUG - 2016-10-07 14:29:26 --> Output Class Initialized
DEBUG - 2016-10-07 14:29:26 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:29:26 --> Security Class Initialized
DEBUG - 2016-10-07 14:29:26 --> Input Class Initialized
DEBUG - 2016-10-07 14:29:26 --> XSS Filtering completed
DEBUG - 2016-10-07 14:29:26 --> XSS Filtering completed
DEBUG - 2016-10-07 14:29:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:29:26 --> Language Class Initialized
DEBUG - 2016-10-07 14:29:26 --> Loader Class Initialized
DEBUG - 2016-10-07 14:29:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:29:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:29:26 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:29:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:29:26 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:29:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:29:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:29:26 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:29:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:29:26 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:29:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:29:26 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:29:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:29:26 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:29:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:29:26 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:29:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:29:26 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:29:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:29:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:29:26 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:29:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:29:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:29:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:29:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:29:26 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:29:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:29:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:29:26 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:29:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:29:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:29:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:29:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:29:26 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:29:26 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:29:26 --> Session Class Initialized
DEBUG - 2016-10-07 14:29:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:29:26 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:29:26 --> Session routines successfully run
DEBUG - 2016-10-07 14:29:26 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:29:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:29:26 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:29:26 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:29:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:29:26 --> Controller Class Initialized
DEBUG - 2016-10-07 14:29:26 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:29:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:29:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:29:26 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:29:26 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:29:26 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:29:26 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:26 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:26 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:26 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:26 --> Model Class Initialized
DEBUG - 2016-10-07 14:29:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-07 14:29:26 --> Pagination Class Initialized
DEBUG - 2016-10-07 14:29:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-10-07 14:29:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/index.php
DEBUG - 2016-10-07 14:29:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-07 14:29:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-07 14:29:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:29:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-07 14:29:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-10-07 14:29:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:29:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-07 14:29:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-07 14:29:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-07 14:29:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:29:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-07 14:29:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-10-07 14:29:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:29:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-07 14:29:26 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c2a3e0401bd35d4fcac4bae5f9412231
DEBUG - 2016-10-07 14:29:26 --> Final output sent to browser
DEBUG - 2016-10-07 14:29:26 --> Total execution time: 0.5405
DEBUG - 2016-10-07 14:30:05 --> Config Class Initialized
DEBUG - 2016-10-07 14:30:05 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:30:05 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:30:05 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:30:05 --> URI Class Initialized
DEBUG - 2016-10-07 14:30:05 --> Router Class Initialized
DEBUG - 2016-10-07 14:30:05 --> Output Class Initialized
DEBUG - 2016-10-07 14:30:05 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:30:05 --> Security Class Initialized
DEBUG - 2016-10-07 14:30:05 --> Input Class Initialized
DEBUG - 2016-10-07 14:30:05 --> XSS Filtering completed
DEBUG - 2016-10-07 14:30:05 --> XSS Filtering completed
DEBUG - 2016-10-07 14:30:05 --> XSS Filtering completed
DEBUG - 2016-10-07 14:30:05 --> XSS Filtering completed
DEBUG - 2016-10-07 14:30:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:30:05 --> Language Class Initialized
DEBUG - 2016-10-07 14:30:05 --> Loader Class Initialized
DEBUG - 2016-10-07 14:30:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:30:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:30:05 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:30:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:30:05 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:30:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:30:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:30:05 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:30:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:30:05 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:30:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:30:05 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:30:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:30:05 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:30:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:30:05 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:30:05 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:30:05 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:30:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:30:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:30:05 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:30:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:30:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:30:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:30:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:30:05 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:30:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:30:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:30:05 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:30:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:30:05 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:30:05 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:30:05 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:30:05 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:30:05 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:30:05 --> Session Class Initialized
DEBUG - 2016-10-07 14:30:05 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:30:05 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:30:05 --> Session routines successfully run
DEBUG - 2016-10-07 14:30:05 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:30:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:30:05 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:30:05 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:30:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:30:05 --> Controller Class Initialized
DEBUG - 2016-10-07 14:30:05 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:30:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:30:05 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:30:05 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:30:05 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:30:05 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:30:05 --> Model Class Initialized
DEBUG - 2016-10-07 14:30:05 --> Model Class Initialized
DEBUG - 2016-10-07 14:30:05 --> Model Class Initialized
ERROR - 2016-10-07 14:30:05 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-10-07 14:30:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-10-07 14:30:05 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:30:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:30:06 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-10-07 14:30:06 --> Config Class Initialized
DEBUG - 2016-10-07 14:30:06 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:30:06 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:30:06 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:30:06 --> URI Class Initialized
DEBUG - 2016-10-07 14:30:06 --> Router Class Initialized
DEBUG - 2016-10-07 14:30:06 --> No URI present. Default controller set.
DEBUG - 2016-10-07 14:30:06 --> Output Class Initialized
DEBUG - 2016-10-07 14:30:06 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:30:06 --> Security Class Initialized
DEBUG - 2016-10-07 14:30:06 --> Input Class Initialized
DEBUG - 2016-10-07 14:30:06 --> XSS Filtering completed
DEBUG - 2016-10-07 14:30:06 --> XSS Filtering completed
DEBUG - 2016-10-07 14:30:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:30:06 --> Language Class Initialized
DEBUG - 2016-10-07 14:30:06 --> Loader Class Initialized
DEBUG - 2016-10-07 14:30:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:30:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:30:06 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:30:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:30:06 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:30:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:30:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:30:06 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:30:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:30:06 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:30:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:30:06 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:30:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:30:06 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:30:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:30:06 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:30:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:30:06 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:30:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:30:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:30:06 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:30:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:30:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:30:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:30:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:30:06 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:30:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:30:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:30:06 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:30:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:30:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:30:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:30:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:30:06 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:30:06 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:30:06 --> Session Class Initialized
DEBUG - 2016-10-07 14:30:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:30:06 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:30:06 --> Session routines successfully run
DEBUG - 2016-10-07 14:30:06 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:30:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:30:06 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:30:06 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:30:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:30:06 --> Controller Class Initialized
DEBUG - 2016-10-07 14:30:06 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:30:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:30:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:30:06 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:30:06 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:30:06 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:30:06 --> Model Class Initialized
DEBUG - 2016-10-07 14:30:06 --> Model Class Initialized
DEBUG - 2016-10-07 14:30:06 --> Model Class Initialized
ERROR - 2016-10-07 14:30:06 --> Hak Akses modul/kontroller 'home' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 14:30:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-10-07 14:30:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-10-07 14:30:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:30:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:30:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:30:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:30:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:30:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-07 14:30:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-07 14:30:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:30:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:30:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:30:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:30:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:30:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:30:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:30:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-07 14:30:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-07 14:30:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:30:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:30:06 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-10-07 14:30:06 --> Final output sent to browser
DEBUG - 2016-10-07 14:30:06 --> Total execution time: 0.4307
DEBUG - 2016-10-07 14:30:06 --> Config Class Initialized
DEBUG - 2016-10-07 14:30:06 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:30:06 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:30:06 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:30:06 --> URI Class Initialized
DEBUG - 2016-10-07 14:30:06 --> Router Class Initialized
DEBUG - 2016-10-07 14:30:06 --> Output Class Initialized
DEBUG - 2016-10-07 14:30:06 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:30:06 --> Security Class Initialized
DEBUG - 2016-10-07 14:30:06 --> Input Class Initialized
DEBUG - 2016-10-07 14:30:06 --> XSS Filtering completed
DEBUG - 2016-10-07 14:30:06 --> XSS Filtering completed
DEBUG - 2016-10-07 14:30:06 --> XSS Filtering completed
DEBUG - 2016-10-07 14:30:06 --> XSS Filtering completed
DEBUG - 2016-10-07 14:30:06 --> XSS Filtering completed
DEBUG - 2016-10-07 14:30:06 --> XSS Filtering completed
DEBUG - 2016-10-07 14:30:06 --> XSS Filtering completed
DEBUG - 2016-10-07 14:30:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:30:06 --> Language Class Initialized
DEBUG - 2016-10-07 14:30:06 --> Loader Class Initialized
DEBUG - 2016-10-07 14:30:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:30:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:30:06 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:30:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:30:06 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:30:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:30:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:30:06 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:30:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:30:06 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:30:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:30:06 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:30:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:30:06 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:30:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:30:06 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:30:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:30:06 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:30:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:30:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:30:06 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:30:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:30:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:30:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:30:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:30:06 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:30:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:30:07 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:30:07 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:30:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:30:07 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:30:07 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:30:07 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:30:07 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:30:07 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:30:07 --> Session Class Initialized
DEBUG - 2016-10-07 14:30:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:30:07 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:30:07 --> Session routines successfully run
DEBUG - 2016-10-07 14:30:07 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:30:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:30:07 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:30:07 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:30:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:30:07 --> Controller Class Initialized
DEBUG - 2016-10-07 14:30:07 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:30:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:30:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:30:07 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:30:07 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:30:07 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:30:07 --> Model Class Initialized
DEBUG - 2016-10-07 14:30:07 --> Model Class Initialized
DEBUG - 2016-10-07 14:30:07 --> Model Class Initialized
DEBUG - 2016-10-07 14:30:07 --> Model Class Initialized
DEBUG - 2016-10-07 14:30:07 --> Model Class Initialized
DEBUG - 2016-10-07 14:30:07 --> Model Class Initialized
DEBUG - 2016-10-07 14:30:07 --> Model Class Initialized
DEBUG - 2016-10-07 14:30:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-10-07 14:30:07 --> Final output sent to browser
DEBUG - 2016-10-07 14:30:07 --> Total execution time: 0.5267
DEBUG - 2016-10-07 14:30:11 --> Config Class Initialized
DEBUG - 2016-10-07 14:30:11 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:30:11 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:30:11 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:30:11 --> URI Class Initialized
DEBUG - 2016-10-07 14:30:11 --> Router Class Initialized
DEBUG - 2016-10-07 14:30:11 --> Output Class Initialized
DEBUG - 2016-10-07 14:30:11 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:30:11 --> Security Class Initialized
DEBUG - 2016-10-07 14:30:11 --> Input Class Initialized
DEBUG - 2016-10-07 14:30:11 --> XSS Filtering completed
DEBUG - 2016-10-07 14:30:11 --> XSS Filtering completed
DEBUG - 2016-10-07 14:30:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:30:11 --> Language Class Initialized
DEBUG - 2016-10-07 14:30:11 --> Loader Class Initialized
DEBUG - 2016-10-07 14:30:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:30:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:30:11 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:30:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:30:11 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:30:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:30:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:30:11 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:30:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:30:11 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:30:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:30:11 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:30:11 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:30:11 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:30:11 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:30:11 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:30:11 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:30:11 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:30:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:30:11 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:30:11 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:30:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:30:11 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:30:11 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:30:11 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:30:11 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:30:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:30:11 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:30:11 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:30:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:30:11 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:30:11 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:30:11 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:30:11 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:30:11 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:30:11 --> Session Class Initialized
DEBUG - 2016-10-07 14:30:11 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:30:11 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:30:11 --> Session routines successfully run
DEBUG - 2016-10-07 14:30:11 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:30:11 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:30:11 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:30:11 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:30:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:30:11 --> Controller Class Initialized
DEBUG - 2016-10-07 14:30:11 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:30:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:30:11 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:30:11 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:30:11 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:30:11 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:30:11 --> Model Class Initialized
DEBUG - 2016-10-07 14:30:11 --> Model Class Initialized
DEBUG - 2016-10-07 14:30:11 --> Model Class Initialized
ERROR - 2016-10-07 14:30:11 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 14:30:11 --> Model Class Initialized
DEBUG - 2016-10-07 14:30:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-07 14:30:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:30:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:30:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:30:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:30:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:30:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:30:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:30:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:30:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:30:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:30:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:30:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:30:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:30:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:30:12 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-07 14:30:12 --> Final output sent to browser
DEBUG - 2016-10-07 14:30:12 --> Total execution time: 0.5370
DEBUG - 2016-10-07 14:31:09 --> Config Class Initialized
DEBUG - 2016-10-07 14:31:09 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:31:09 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:31:09 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:31:09 --> URI Class Initialized
DEBUG - 2016-10-07 14:31:09 --> Router Class Initialized
DEBUG - 2016-10-07 14:31:09 --> Output Class Initialized
DEBUG - 2016-10-07 14:31:09 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:31:09 --> Security Class Initialized
DEBUG - 2016-10-07 14:31:09 --> Input Class Initialized
DEBUG - 2016-10-07 14:31:09 --> XSS Filtering completed
DEBUG - 2016-10-07 14:31:09 --> XSS Filtering completed
DEBUG - 2016-10-07 14:31:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:31:09 --> Language Class Initialized
DEBUG - 2016-10-07 14:31:09 --> Loader Class Initialized
DEBUG - 2016-10-07 14:31:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:31:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:31:09 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:31:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:31:09 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:31:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:31:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:31:09 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:31:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:31:09 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:31:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:31:09 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:31:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:31:09 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:31:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:31:09 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:31:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:31:09 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:31:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:31:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:31:09 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:31:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:31:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:31:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:31:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:31:09 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:31:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:31:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:31:09 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:31:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:31:09 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:31:09 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:31:09 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:31:09 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:31:09 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:31:09 --> Session Class Initialized
DEBUG - 2016-10-07 14:31:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:31:09 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:31:09 --> Session routines successfully run
DEBUG - 2016-10-07 14:31:09 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:31:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:31:09 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:31:09 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:31:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:31:09 --> Controller Class Initialized
DEBUG - 2016-10-07 14:31:09 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:31:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:31:09 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:31:09 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:31:09 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:31:09 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:31:09 --> Model Class Initialized
DEBUG - 2016-10-07 14:31:09 --> Model Class Initialized
DEBUG - 2016-10-07 14:31:09 --> Model Class Initialized
ERROR - 2016-10-07 14:31:09 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 14:31:09 --> Model Class Initialized
DEBUG - 2016-10-07 14:31:12 --> Config Class Initialized
DEBUG - 2016-10-07 14:31:12 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:31:12 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:31:12 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:31:12 --> URI Class Initialized
DEBUG - 2016-10-07 14:31:12 --> Router Class Initialized
DEBUG - 2016-10-07 14:31:12 --> Output Class Initialized
DEBUG - 2016-10-07 14:31:12 --> Security Class Initialized
DEBUG - 2016-10-07 14:31:12 --> Input Class Initialized
DEBUG - 2016-10-07 14:31:12 --> XSS Filtering completed
DEBUG - 2016-10-07 14:31:12 --> XSS Filtering completed
DEBUG - 2016-10-07 14:31:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:31:12 --> Language Class Initialized
DEBUG - 2016-10-07 14:31:12 --> Loader Class Initialized
DEBUG - 2016-10-07 14:31:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:31:12 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:31:12 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:31:12 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:31:12 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:31:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:31:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:31:12 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:31:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:31:12 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:31:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:31:12 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:31:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:31:12 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:31:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:31:12 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:31:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:31:12 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:31:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:31:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:31:12 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:31:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:31:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:31:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:31:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:31:12 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:31:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:31:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:31:12 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:31:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:31:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:31:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:31:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:31:12 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:31:12 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:31:12 --> Session Class Initialized
DEBUG - 2016-10-07 14:31:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:31:12 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:31:12 --> Session routines successfully run
DEBUG - 2016-10-07 14:31:12 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:31:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:31:12 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:31:12 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:31:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:31:12 --> Controller Class Initialized
DEBUG - 2016-10-07 14:31:12 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:31:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:31:12 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:31:12 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:31:12 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:31:12 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:31:12 --> Model Class Initialized
DEBUG - 2016-10-07 14:31:12 --> Model Class Initialized
DEBUG - 2016-10-07 14:31:12 --> Model Class Initialized
ERROR - 2016-10-07 14:31:12 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 14:31:12 --> Model Class Initialized
DEBUG - 2016-10-07 14:38:24 --> Config Class Initialized
DEBUG - 2016-10-07 14:38:24 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:38:24 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:38:24 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:38:24 --> URI Class Initialized
DEBUG - 2016-10-07 14:38:24 --> Router Class Initialized
DEBUG - 2016-10-07 14:38:24 --> Output Class Initialized
DEBUG - 2016-10-07 14:38:24 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:38:24 --> Security Class Initialized
DEBUG - 2016-10-07 14:38:24 --> Input Class Initialized
DEBUG - 2016-10-07 14:38:24 --> XSS Filtering completed
DEBUG - 2016-10-07 14:38:24 --> XSS Filtering completed
DEBUG - 2016-10-07 14:38:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:38:24 --> Language Class Initialized
DEBUG - 2016-10-07 14:38:24 --> Loader Class Initialized
DEBUG - 2016-10-07 14:38:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:38:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:38:24 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:38:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:38:24 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:38:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:38:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:38:24 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:38:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:38:24 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:38:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:38:24 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:38:24 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:38:24 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:38:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:38:24 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:38:24 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:38:24 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:38:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:38:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:38:24 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:38:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:38:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:38:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:38:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:38:24 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:38:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:38:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:38:24 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:38:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:38:24 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:38:24 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:38:24 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:38:24 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:38:24 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:38:24 --> Session Class Initialized
DEBUG - 2016-10-07 14:38:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:38:24 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:38:24 --> Session routines successfully run
DEBUG - 2016-10-07 14:38:24 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:38:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:38:24 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:38:24 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:38:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:38:24 --> Controller Class Initialized
DEBUG - 2016-10-07 14:38:24 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:38:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:38:24 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:38:24 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:38:24 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:38:24 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:38:24 --> Model Class Initialized
DEBUG - 2016-10-07 14:38:24 --> Model Class Initialized
DEBUG - 2016-10-07 14:38:25 --> Model Class Initialized
DEBUG - 2016-10-07 14:38:25 --> Model Class Initialized
DEBUG - 2016-10-07 14:38:25 --> Model Class Initialized
DEBUG - 2016-10-07 14:38:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-07 14:38:25 --> Pagination Class Initialized
DEBUG - 2016-10-07 14:38:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-10-07 14:38:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_tingkat_pendidikan/index.php
DEBUG - 2016-10-07 14:38:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-07 14:38:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-07 14:38:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:38:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-07 14:38:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_tingkat_pendidikan/js/index_js.php
DEBUG - 2016-10-07 14:38:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:38:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-07 14:38:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-07 14:38:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-07 14:38:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:38:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-07 14:38:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_tingkat_pendidikan/js/index_js.php
DEBUG - 2016-10-07 14:38:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:38:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-07 14:38:25 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c75a32d2afef33dce35572ed7fc68d18
DEBUG - 2016-10-07 14:38:25 --> Final output sent to browser
DEBUG - 2016-10-07 14:38:25 --> Total execution time: 0.6790
DEBUG - 2016-10-07 14:38:28 --> Config Class Initialized
DEBUG - 2016-10-07 14:38:28 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:38:28 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:38:28 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:38:28 --> URI Class Initialized
DEBUG - 2016-10-07 14:38:28 --> Router Class Initialized
DEBUG - 2016-10-07 14:38:28 --> Output Class Initialized
DEBUG - 2016-10-07 14:38:28 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:38:28 --> Security Class Initialized
DEBUG - 2016-10-07 14:38:28 --> Input Class Initialized
DEBUG - 2016-10-07 14:38:28 --> XSS Filtering completed
DEBUG - 2016-10-07 14:38:28 --> XSS Filtering completed
DEBUG - 2016-10-07 14:38:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:38:28 --> Language Class Initialized
DEBUG - 2016-10-07 14:38:28 --> Loader Class Initialized
DEBUG - 2016-10-07 14:38:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:38:28 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:38:28 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:38:28 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:38:28 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:38:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:38:28 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:38:28 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:38:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:38:28 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:38:28 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:38:28 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:38:28 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:38:28 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:38:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:38:28 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:38:28 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:38:28 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:38:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:38:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:38:28 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:38:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:38:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:38:28 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:38:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:38:28 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:38:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:38:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:38:28 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:38:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:38:28 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:38:28 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:38:28 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:38:28 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:38:28 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:38:28 --> Session Class Initialized
DEBUG - 2016-10-07 14:38:28 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:38:28 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:38:28 --> Session routines successfully run
DEBUG - 2016-10-07 14:38:28 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:38:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:38:28 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:38:28 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:38:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:38:28 --> Controller Class Initialized
DEBUG - 2016-10-07 14:38:28 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:38:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:38:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:38:28 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:38:28 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:38:28 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:38:28 --> Model Class Initialized
DEBUG - 2016-10-07 14:38:28 --> Model Class Initialized
DEBUG - 2016-10-07 14:38:28 --> Model Class Initialized
DEBUG - 2016-10-07 14:38:28 --> Model Class Initialized
DEBUG - 2016-10-07 14:38:28 --> Model Class Initialized
DEBUG - 2016-10-07 14:38:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-07 14:38:28 --> Pagination Class Initialized
DEBUG - 2016-10-07 14:38:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-10-07 14:38:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/index.php
DEBUG - 2016-10-07 14:38:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-07 14:38:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-07 14:38:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:38:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-07 14:38:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-10-07 14:38:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:38:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-07 14:38:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-07 14:38:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-07 14:38:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:38:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-07 14:38:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-10-07 14:38:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:38:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-07 14:38:28 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c2a3e0401bd35d4fcac4bae5f9412231
DEBUG - 2016-10-07 14:38:28 --> Final output sent to browser
DEBUG - 2016-10-07 14:38:28 --> Total execution time: 0.6037
DEBUG - 2016-10-07 14:40:44 --> Config Class Initialized
DEBUG - 2016-10-07 14:40:44 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:40:44 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:40:44 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:40:44 --> URI Class Initialized
DEBUG - 2016-10-07 14:40:44 --> Router Class Initialized
DEBUG - 2016-10-07 14:40:44 --> Output Class Initialized
DEBUG - 2016-10-07 14:40:44 --> Security Class Initialized
DEBUG - 2016-10-07 14:40:44 --> Input Class Initialized
DEBUG - 2016-10-07 14:40:44 --> XSS Filtering completed
DEBUG - 2016-10-07 14:40:44 --> XSS Filtering completed
DEBUG - 2016-10-07 14:40:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:40:44 --> Language Class Initialized
DEBUG - 2016-10-07 14:40:44 --> Loader Class Initialized
DEBUG - 2016-10-07 14:40:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:40:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:40:44 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:40:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:40:44 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:40:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:40:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:40:44 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:40:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:40:44 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:40:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:40:44 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:40:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:40:44 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:40:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:40:44 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:40:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:40:44 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:40:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:40:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:40:44 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:40:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:40:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:40:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:40:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:40:44 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:40:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:40:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:40:44 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:40:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:40:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:40:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:40:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:40:44 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:40:44 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:40:44 --> Session Class Initialized
DEBUG - 2016-10-07 14:40:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:40:44 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:40:44 --> Session routines successfully run
DEBUG - 2016-10-07 14:40:44 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:40:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:40:44 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:40:44 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:40:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:40:45 --> Controller Class Initialized
DEBUG - 2016-10-07 14:40:45 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:40:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:40:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:40:45 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:40:45 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:40:45 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:40:45 --> Model Class Initialized
DEBUG - 2016-10-07 14:40:45 --> Model Class Initialized
DEBUG - 2016-10-07 14:40:45 --> Model Class Initialized
ERROR - 2016-10-07 14:40:45 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 14:40:45 --> Model Class Initialized
DEBUG - 2016-10-07 14:40:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-07 14:40:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:40:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:40:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:40:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:40:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:40:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:40:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:40:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:40:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:40:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:40:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:40:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:40:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:40:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:40:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-07 14:40:45 --> Final output sent to browser
DEBUG - 2016-10-07 14:40:45 --> Total execution time: 0.5756
DEBUG - 2016-10-07 14:40:46 --> Config Class Initialized
DEBUG - 2016-10-07 14:40:46 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:40:46 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:40:46 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:40:46 --> URI Class Initialized
DEBUG - 2016-10-07 14:40:46 --> Router Class Initialized
DEBUG - 2016-10-07 14:40:46 --> Output Class Initialized
DEBUG - 2016-10-07 14:40:46 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:40:46 --> Security Class Initialized
DEBUG - 2016-10-07 14:40:46 --> Input Class Initialized
DEBUG - 2016-10-07 14:40:46 --> XSS Filtering completed
DEBUG - 2016-10-07 14:40:46 --> XSS Filtering completed
DEBUG - 2016-10-07 14:40:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:40:46 --> Language Class Initialized
DEBUG - 2016-10-07 14:40:46 --> Loader Class Initialized
DEBUG - 2016-10-07 14:40:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:40:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:40:46 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:40:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:40:46 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:40:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:40:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:40:46 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:40:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:40:46 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:40:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:40:46 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:40:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:40:46 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:40:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:40:46 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:40:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:40:46 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:40:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:40:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:40:46 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:40:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:40:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:40:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:40:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:40:46 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:40:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:40:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:40:46 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:40:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:40:46 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:40:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:40:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:40:46 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:40:46 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:40:46 --> Session Class Initialized
DEBUG - 2016-10-07 14:40:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:40:46 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:40:46 --> Session routines successfully run
DEBUG - 2016-10-07 14:40:46 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:40:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:40:46 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:40:46 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:40:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:40:46 --> Controller Class Initialized
DEBUG - 2016-10-07 14:40:46 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:40:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:40:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:40:46 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:40:46 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:40:46 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:40:46 --> Model Class Initialized
DEBUG - 2016-10-07 14:40:46 --> Model Class Initialized
DEBUG - 2016-10-07 14:40:46 --> Model Class Initialized
ERROR - 2016-10-07 14:40:46 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 14:40:46 --> Model Class Initialized
DEBUG - 2016-10-07 14:40:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-07 14:40:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:40:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:40:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:40:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:40:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:40:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:40:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:40:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:40:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:40:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:40:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:40:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:40:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:40:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:40:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-07 14:40:47 --> Final output sent to browser
DEBUG - 2016-10-07 14:40:47 --> Total execution time: 0.6114
DEBUG - 2016-10-07 14:41:01 --> Config Class Initialized
DEBUG - 2016-10-07 14:41:01 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:41:01 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:41:01 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:41:01 --> URI Class Initialized
DEBUG - 2016-10-07 14:41:01 --> Router Class Initialized
DEBUG - 2016-10-07 14:41:01 --> Output Class Initialized
DEBUG - 2016-10-07 14:41:01 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:41:01 --> Security Class Initialized
DEBUG - 2016-10-07 14:41:01 --> Input Class Initialized
DEBUG - 2016-10-07 14:41:01 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:01 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:41:01 --> Language Class Initialized
DEBUG - 2016-10-07 14:41:01 --> Loader Class Initialized
DEBUG - 2016-10-07 14:41:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:41:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:41:01 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:41:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:41:01 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:41:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:41:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:41:01 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:41:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:41:01 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:41:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:41:01 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:41:01 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:41:01 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:41:01 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:41:01 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:41:01 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:41:01 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:41:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:41:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:41:01 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:41:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:41:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:41:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:41:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:41:01 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:41:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:41:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:41:01 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:41:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:41:01 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:41:01 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:41:01 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:41:01 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:41:01 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:41:01 --> Session Class Initialized
DEBUG - 2016-10-07 14:41:01 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:41:01 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:41:01 --> Session routines successfully run
DEBUG - 2016-10-07 14:41:01 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:41:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:41:01 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:41:01 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:41:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:41:01 --> Controller Class Initialized
DEBUG - 2016-10-07 14:41:01 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:41:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:41:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:41:01 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:41:01 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:41:01 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:41:01 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:01 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:01 --> Model Class Initialized
ERROR - 2016-10-07 14:41:01 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 14:41:01 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:03 --> Config Class Initialized
DEBUG - 2016-10-07 14:41:03 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:41:03 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:41:03 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:41:03 --> URI Class Initialized
DEBUG - 2016-10-07 14:41:03 --> Router Class Initialized
DEBUG - 2016-10-07 14:41:03 --> Output Class Initialized
DEBUG - 2016-10-07 14:41:03 --> Security Class Initialized
DEBUG - 2016-10-07 14:41:03 --> Input Class Initialized
DEBUG - 2016-10-07 14:41:03 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:03 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:41:03 --> Language Class Initialized
DEBUG - 2016-10-07 14:41:03 --> Loader Class Initialized
DEBUG - 2016-10-07 14:41:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:41:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:41:03 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:41:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:41:03 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:41:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:41:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:41:03 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:41:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:41:03 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:41:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:41:04 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:41:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:41:04 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:41:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:41:04 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:41:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:41:04 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:41:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:41:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:41:04 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:41:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:41:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:41:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:41:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:41:04 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:41:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:41:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:41:04 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:41:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:41:04 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:41:04 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:41:04 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:41:04 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:41:04 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:41:04 --> Session Class Initialized
DEBUG - 2016-10-07 14:41:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:41:04 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:41:04 --> Session routines successfully run
DEBUG - 2016-10-07 14:41:04 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:41:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:41:04 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:41:04 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:41:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:41:04 --> Controller Class Initialized
DEBUG - 2016-10-07 14:41:04 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:41:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:41:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:41:04 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:41:04 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:41:04 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:41:04 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:04 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:04 --> Model Class Initialized
ERROR - 2016-10-07 14:41:04 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 14:41:04 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:16 --> Config Class Initialized
DEBUG - 2016-10-07 14:41:16 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:41:16 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:41:16 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:41:16 --> URI Class Initialized
DEBUG - 2016-10-07 14:41:16 --> Router Class Initialized
DEBUG - 2016-10-07 14:41:16 --> Output Class Initialized
DEBUG - 2016-10-07 14:41:16 --> Security Class Initialized
DEBUG - 2016-10-07 14:41:16 --> Input Class Initialized
DEBUG - 2016-10-07 14:41:16 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:16 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:41:16 --> Language Class Initialized
DEBUG - 2016-10-07 14:41:16 --> Loader Class Initialized
DEBUG - 2016-10-07 14:41:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:41:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:41:16 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:41:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:41:16 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:41:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:41:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:41:16 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:41:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:41:16 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:41:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:41:16 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:41:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:41:16 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:41:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:41:16 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:41:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:41:16 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:41:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:41:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:41:16 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:41:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:41:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:41:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:41:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:41:16 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:41:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:41:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:41:16 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:41:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:41:16 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:41:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:41:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:41:16 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:41:16 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:41:16 --> Session Class Initialized
DEBUG - 2016-10-07 14:41:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:41:16 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:41:16 --> Session routines successfully run
DEBUG - 2016-10-07 14:41:16 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:41:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:41:16 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:41:16 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:41:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:41:16 --> Controller Class Initialized
DEBUG - 2016-10-07 14:41:16 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:41:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:41:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:41:16 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:41:17 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:41:17 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:41:17 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:17 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:17 --> Model Class Initialized
ERROR - 2016-10-07 14:41:17 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 14:41:17 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:29 --> Config Class Initialized
DEBUG - 2016-10-07 14:41:29 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:41:29 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:41:29 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:41:29 --> URI Class Initialized
DEBUG - 2016-10-07 14:41:29 --> Router Class Initialized
DEBUG - 2016-10-07 14:41:29 --> Output Class Initialized
DEBUG - 2016-10-07 14:41:29 --> Security Class Initialized
DEBUG - 2016-10-07 14:41:29 --> Input Class Initialized
DEBUG - 2016-10-07 14:41:29 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:29 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:41:29 --> Language Class Initialized
DEBUG - 2016-10-07 14:41:29 --> Loader Class Initialized
DEBUG - 2016-10-07 14:41:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:41:29 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:41:29 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:41:29 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:41:29 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:41:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:41:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:41:29 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:41:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:41:29 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:41:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:41:29 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:41:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:41:29 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:41:29 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:41:29 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:41:29 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:41:29 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:41:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:41:29 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:41:29 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:41:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:41:29 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:41:29 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:41:29 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:41:29 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:41:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:41:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:41:29 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:41:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:41:29 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:41:29 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:41:29 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:41:29 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:41:29 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:41:29 --> Session Class Initialized
DEBUG - 2016-10-07 14:41:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:41:29 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:41:29 --> Session routines successfully run
DEBUG - 2016-10-07 14:41:29 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:41:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:41:29 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:41:29 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:41:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:41:29 --> Controller Class Initialized
DEBUG - 2016-10-07 14:41:29 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:41:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:41:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:41:29 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:41:29 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:41:29 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:41:29 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:29 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:29 --> Model Class Initialized
ERROR - 2016-10-07 14:41:29 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 14:41:29 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-07 14:41:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:41:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:41:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:41:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:41:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:41:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:41:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:41:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:41:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:41:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:41:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:41:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:41:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:41:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:41:29 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-07 14:41:29 --> Final output sent to browser
DEBUG - 2016-10-07 14:41:29 --> Total execution time: 0.6770
DEBUG - 2016-10-07 14:41:30 --> Config Class Initialized
DEBUG - 2016-10-07 14:41:30 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:41:30 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:41:30 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:41:30 --> URI Class Initialized
DEBUG - 2016-10-07 14:41:30 --> Router Class Initialized
DEBUG - 2016-10-07 14:41:30 --> Output Class Initialized
DEBUG - 2016-10-07 14:41:30 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:41:30 --> Security Class Initialized
DEBUG - 2016-10-07 14:41:30 --> Input Class Initialized
DEBUG - 2016-10-07 14:41:30 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:30 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:41:30 --> Language Class Initialized
DEBUG - 2016-10-07 14:41:30 --> Loader Class Initialized
DEBUG - 2016-10-07 14:41:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:41:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:41:30 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:41:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:41:30 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:41:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:41:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:41:30 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:41:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:41:30 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:41:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:41:30 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:41:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:41:30 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:41:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:41:30 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:41:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:41:30 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:41:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:41:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:41:30 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:41:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:41:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:41:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:41:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:41:30 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:41:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:41:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:41:30 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:41:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:41:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:41:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:41:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:41:30 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:41:30 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:41:30 --> Session Class Initialized
DEBUG - 2016-10-07 14:41:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:41:30 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:41:30 --> Session routines successfully run
DEBUG - 2016-10-07 14:41:30 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:41:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:41:30 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:41:30 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:41:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:41:30 --> Controller Class Initialized
DEBUG - 2016-10-07 14:41:30 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:41:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:41:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:41:30 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:41:30 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:41:30 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:41:30 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:30 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:30 --> Model Class Initialized
ERROR - 2016-10-07 14:41:30 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 14:41:30 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-07 14:41:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:41:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:41:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:41:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:41:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:41:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:41:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:41:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:41:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:41:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:41:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:41:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:41:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:41:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:41:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-07 14:41:30 --> Final output sent to browser
DEBUG - 2016-10-07 14:41:30 --> Total execution time: 0.7295
DEBUG - 2016-10-07 14:41:32 --> Config Class Initialized
DEBUG - 2016-10-07 14:41:32 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:41:32 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:41:32 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:41:32 --> URI Class Initialized
DEBUG - 2016-10-07 14:41:32 --> Router Class Initialized
DEBUG - 2016-10-07 14:41:32 --> Output Class Initialized
DEBUG - 2016-10-07 14:41:32 --> Security Class Initialized
DEBUG - 2016-10-07 14:41:32 --> Input Class Initialized
DEBUG - 2016-10-07 14:41:32 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:32 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:41:32 --> Language Class Initialized
DEBUG - 2016-10-07 14:41:32 --> Loader Class Initialized
DEBUG - 2016-10-07 14:41:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:41:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:41:32 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:41:32 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:41:32 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:41:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:41:32 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:41:32 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:41:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:41:32 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:41:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:41:32 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:41:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:41:32 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:41:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:41:32 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:41:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:41:32 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:41:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:41:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:41:32 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:41:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:41:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:41:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:41:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:41:32 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:41:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:41:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:41:32 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:41:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:41:32 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:41:32 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:41:32 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:41:32 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:41:32 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:41:33 --> Session Class Initialized
DEBUG - 2016-10-07 14:41:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:41:33 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:41:33 --> Session routines successfully run
DEBUG - 2016-10-07 14:41:33 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:41:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:41:33 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:41:33 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:41:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:41:33 --> Controller Class Initialized
DEBUG - 2016-10-07 14:41:33 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:41:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:41:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:41:33 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:41:33 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:41:33 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:41:33 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:33 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:33 --> Model Class Initialized
ERROR - 2016-10-07 14:41:33 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 14:41:33 --> Config Class Initialized
DEBUG - 2016-10-07 14:41:33 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:41:33 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:41:33 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:41:33 --> URI Class Initialized
DEBUG - 2016-10-07 14:41:33 --> Router Class Initialized
DEBUG - 2016-10-07 14:41:33 --> No URI present. Default controller set.
DEBUG - 2016-10-07 14:41:33 --> Output Class Initialized
DEBUG - 2016-10-07 14:41:33 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:41:33 --> Security Class Initialized
DEBUG - 2016-10-07 14:41:33 --> Input Class Initialized
DEBUG - 2016-10-07 14:41:33 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:33 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:41:33 --> Language Class Initialized
DEBUG - 2016-10-07 14:41:33 --> Loader Class Initialized
DEBUG - 2016-10-07 14:41:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:41:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:41:33 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:41:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:41:33 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:41:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:41:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:41:33 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:41:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:41:33 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:41:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:41:33 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:41:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:41:33 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:41:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:41:33 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:41:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:41:33 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:41:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:41:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:41:33 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:41:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:41:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:41:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:41:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:41:33 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:41:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:41:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:41:33 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:41:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:41:33 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:41:33 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:41:33 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:41:33 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:41:33 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:41:33 --> Session Class Initialized
DEBUG - 2016-10-07 14:41:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:41:33 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:41:33 --> Session routines successfully run
DEBUG - 2016-10-07 14:41:33 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:41:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:41:33 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:41:33 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:41:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:41:33 --> Controller Class Initialized
DEBUG - 2016-10-07 14:41:33 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:41:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:41:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:41:33 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:41:33 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:41:33 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:41:33 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:33 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:33 --> Model Class Initialized
ERROR - 2016-10-07 14:41:33 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-10-07 14:41:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-10-07 14:41:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-10-07 14:41:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:41:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:41:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:41:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:41:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:41:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-07 14:41:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-07 14:41:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:41:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:41:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:41:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:41:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:41:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:41:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:41:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-07 14:41:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-07 14:41:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:41:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:41:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-10-07 14:41:34 --> Final output sent to browser
DEBUG - 2016-10-07 14:41:34 --> Total execution time: 0.7078
DEBUG - 2016-10-07 14:41:34 --> Config Class Initialized
DEBUG - 2016-10-07 14:41:34 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:41:34 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:41:34 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:41:34 --> URI Class Initialized
DEBUG - 2016-10-07 14:41:34 --> Router Class Initialized
DEBUG - 2016-10-07 14:41:34 --> Output Class Initialized
DEBUG - 2016-10-07 14:41:34 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:41:34 --> Security Class Initialized
DEBUG - 2016-10-07 14:41:34 --> Input Class Initialized
DEBUG - 2016-10-07 14:41:34 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:34 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:34 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:34 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:34 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:34 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:34 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:41:34 --> Language Class Initialized
DEBUG - 2016-10-07 14:41:34 --> Loader Class Initialized
DEBUG - 2016-10-07 14:41:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:41:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:41:34 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:41:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:41:34 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:41:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:41:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:41:34 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:41:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:41:34 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:41:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:41:34 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:41:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:41:34 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:41:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:41:34 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:41:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:41:34 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:41:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:41:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:41:34 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:41:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:41:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:41:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:41:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:41:34 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:41:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:41:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:41:34 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:41:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:41:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:41:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:41:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:41:34 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:41:34 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:41:34 --> Session Class Initialized
DEBUG - 2016-10-07 14:41:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:41:34 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:41:34 --> Session routines successfully run
DEBUG - 2016-10-07 14:41:34 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:41:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:41:34 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:41:34 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:41:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:41:34 --> Controller Class Initialized
DEBUG - 2016-10-07 14:41:34 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:41:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:41:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:41:35 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:41:35 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:41:35 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:41:35 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:35 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:35 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:35 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:35 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:35 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:35 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:35 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-10-07 14:41:35 --> Final output sent to browser
DEBUG - 2016-10-07 14:41:35 --> Total execution time: 0.8252
DEBUG - 2016-10-07 14:41:35 --> Config Class Initialized
DEBUG - 2016-10-07 14:41:35 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:41:35 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:41:35 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:41:35 --> URI Class Initialized
DEBUG - 2016-10-07 14:41:35 --> Router Class Initialized
DEBUG - 2016-10-07 14:41:35 --> Output Class Initialized
DEBUG - 2016-10-07 14:41:35 --> Security Class Initialized
DEBUG - 2016-10-07 14:41:35 --> Input Class Initialized
DEBUG - 2016-10-07 14:41:35 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:35 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:41:35 --> Language Class Initialized
DEBUG - 2016-10-07 14:41:35 --> Loader Class Initialized
DEBUG - 2016-10-07 14:41:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:41:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:41:35 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:41:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:41:35 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:41:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:41:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:41:35 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:41:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:41:35 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:41:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:41:35 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:41:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:41:35 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:41:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:41:35 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:41:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:41:35 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:41:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:41:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:41:35 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:41:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:41:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:41:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:41:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:41:35 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:41:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:41:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:41:35 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:41:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:41:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:41:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:41:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:41:35 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:41:35 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:41:35 --> Session Class Initialized
DEBUG - 2016-10-07 14:41:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:41:35 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:41:35 --> Session routines successfully run
DEBUG - 2016-10-07 14:41:35 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:41:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:41:35 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:41:35 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:41:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:41:35 --> Controller Class Initialized
DEBUG - 2016-10-07 14:41:35 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:41:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:41:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:41:35 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:41:35 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:41:35 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:41:35 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:35 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:35 --> Model Class Initialized
ERROR - 2016-10-07 14:41:35 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-10-07 14:41:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-10-07 14:41:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:41:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:41:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:41:36 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-10-07 14:41:36 --> Final output sent to browser
DEBUG - 2016-10-07 14:41:36 --> Total execution time: 0.7278
DEBUG - 2016-10-07 14:41:46 --> Config Class Initialized
DEBUG - 2016-10-07 14:41:46 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:41:46 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:41:46 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:41:46 --> URI Class Initialized
DEBUG - 2016-10-07 14:41:46 --> Router Class Initialized
DEBUG - 2016-10-07 14:41:46 --> Output Class Initialized
DEBUG - 2016-10-07 14:41:46 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:41:46 --> Security Class Initialized
DEBUG - 2016-10-07 14:41:46 --> Input Class Initialized
DEBUG - 2016-10-07 14:41:46 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:46 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:41:46 --> Language Class Initialized
DEBUG - 2016-10-07 14:41:46 --> Loader Class Initialized
DEBUG - 2016-10-07 14:41:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:41:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:41:46 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:41:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:41:46 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:41:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:41:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:41:46 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:41:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:41:46 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:41:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:41:46 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:41:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:41:46 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:41:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:41:46 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:41:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:41:47 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:41:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:41:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:41:47 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:41:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:41:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:41:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:41:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:41:47 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:41:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:41:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:41:47 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:41:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:41:47 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:41:47 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:41:47 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:41:47 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:41:47 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:41:47 --> Session Class Initialized
DEBUG - 2016-10-07 14:41:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:41:47 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:41:47 --> Session routines successfully run
DEBUG - 2016-10-07 14:41:47 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:41:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:41:47 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:41:47 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:41:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:41:47 --> Controller Class Initialized
DEBUG - 2016-10-07 14:41:47 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:41:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:41:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:41:47 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:41:47 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:41:47 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:41:47 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:47 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:47 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:47 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:47 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:47 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:47 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:47 --> Model Class Initialized
DEBUG - 2016-10-07 14:41:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-07 14:41:47 --> Pagination Class Initialized
DEBUG - 2016-10-07 14:41:47 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-07 14:41:47 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/index.php
DEBUG - 2016-10-07 14:41:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-07 14:41:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-07 14:41:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:41:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-07 14:41:47 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-07 14:41:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:41:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-07 14:41:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-07 14:41:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-07 14:41:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:41:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-07 14:41:47 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-07 14:41:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:41:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-07 14:41:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55961f1d1ca16fdfc4239ae1901a174e
DEBUG - 2016-10-07 14:41:47 --> Final output sent to browser
DEBUG - 2016-10-07 14:41:47 --> Total execution time: 0.8712
DEBUG - 2016-10-07 14:41:59 --> Config Class Initialized
DEBUG - 2016-10-07 14:41:59 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:41:59 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:41:59 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:41:59 --> URI Class Initialized
DEBUG - 2016-10-07 14:41:59 --> Router Class Initialized
DEBUG - 2016-10-07 14:41:59 --> Output Class Initialized
DEBUG - 2016-10-07 14:41:59 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:41:59 --> Security Class Initialized
DEBUG - 2016-10-07 14:41:59 --> Input Class Initialized
DEBUG - 2016-10-07 14:41:59 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:59 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:59 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:59 --> XSS Filtering completed
DEBUG - 2016-10-07 14:41:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:41:59 --> Language Class Initialized
DEBUG - 2016-10-07 14:41:59 --> Loader Class Initialized
DEBUG - 2016-10-07 14:41:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:41:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:41:59 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:41:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:41:59 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:41:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:41:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:41:59 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:41:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:41:59 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:41:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:41:59 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:41:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:41:59 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:41:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:41:59 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:41:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:42:00 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:42:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:42:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:42:00 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:42:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:42:00 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:42:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:42:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:42:00 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:42:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:42:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:42:00 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:42:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:42:00 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:42:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:42:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:42:00 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:42:00 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:42:00 --> Session Class Initialized
DEBUG - 2016-10-07 14:42:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:42:00 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:42:00 --> Session routines successfully run
DEBUG - 2016-10-07 14:42:00 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:42:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:42:00 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:42:00 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:42:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:42:00 --> Controller Class Initialized
DEBUG - 2016-10-07 14:42:00 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:42:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:42:00 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:42:00 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:42:00 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:42:00 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:42:00 --> Model Class Initialized
DEBUG - 2016-10-07 14:42:00 --> Model Class Initialized
DEBUG - 2016-10-07 14:42:00 --> Model Class Initialized
ERROR - 2016-10-07 14:42:00 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-10-07 14:42:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-10-07 14:42:00 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:42:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:42:00 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-10-07 14:42:00 --> Config Class Initialized
DEBUG - 2016-10-07 14:42:00 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:42:00 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:42:00 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:42:00 --> URI Class Initialized
DEBUG - 2016-10-07 14:42:00 --> Router Class Initialized
DEBUG - 2016-10-07 14:42:00 --> No URI present. Default controller set.
DEBUG - 2016-10-07 14:42:00 --> Output Class Initialized
DEBUG - 2016-10-07 14:42:00 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:42:00 --> Security Class Initialized
DEBUG - 2016-10-07 14:42:00 --> Input Class Initialized
DEBUG - 2016-10-07 14:42:00 --> XSS Filtering completed
DEBUG - 2016-10-07 14:42:00 --> XSS Filtering completed
DEBUG - 2016-10-07 14:42:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:42:00 --> Language Class Initialized
DEBUG - 2016-10-07 14:42:00 --> Loader Class Initialized
DEBUG - 2016-10-07 14:42:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:42:00 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:42:00 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:42:00 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:42:00 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:42:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:42:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:42:00 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:42:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:42:00 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:42:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:42:00 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:42:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:42:00 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:42:00 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:42:00 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:42:00 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:42:00 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:42:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:42:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:42:00 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:42:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:42:00 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:42:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:42:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:42:00 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:42:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:42:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:42:01 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:42:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:42:01 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:42:01 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:42:01 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:42:01 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:42:01 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:42:01 --> Session Class Initialized
DEBUG - 2016-10-07 14:42:01 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:42:01 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:42:01 --> Session routines successfully run
DEBUG - 2016-10-07 14:42:01 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:42:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:42:01 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:42:01 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:42:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:42:01 --> Controller Class Initialized
DEBUG - 2016-10-07 14:42:01 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:42:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:42:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:42:01 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:42:01 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:42:01 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:42:01 --> Model Class Initialized
DEBUG - 2016-10-07 14:42:01 --> Model Class Initialized
DEBUG - 2016-10-07 14:42:01 --> Model Class Initialized
ERROR - 2016-10-07 14:42:01 --> Hak Akses modul/kontroller 'home' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 14:42:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-10-07 14:42:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-10-07 14:42:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:42:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:42:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:42:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:42:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:42:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-07 14:42:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-07 14:42:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:42:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:42:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:42:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:42:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:42:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:42:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:42:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-07 14:42:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-07 14:42:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:42:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:42:01 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-10-07 14:42:01 --> Final output sent to browser
DEBUG - 2016-10-07 14:42:01 --> Total execution time: 0.8000
DEBUG - 2016-10-07 14:42:01 --> Config Class Initialized
DEBUG - 2016-10-07 14:42:01 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:42:01 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:42:01 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:42:01 --> URI Class Initialized
DEBUG - 2016-10-07 14:42:01 --> Router Class Initialized
DEBUG - 2016-10-07 14:42:01 --> Output Class Initialized
DEBUG - 2016-10-07 14:42:01 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:42:01 --> Security Class Initialized
DEBUG - 2016-10-07 14:42:01 --> Input Class Initialized
DEBUG - 2016-10-07 14:42:01 --> XSS Filtering completed
DEBUG - 2016-10-07 14:42:01 --> XSS Filtering completed
DEBUG - 2016-10-07 14:42:01 --> XSS Filtering completed
DEBUG - 2016-10-07 14:42:01 --> XSS Filtering completed
DEBUG - 2016-10-07 14:42:01 --> XSS Filtering completed
DEBUG - 2016-10-07 14:42:01 --> XSS Filtering completed
DEBUG - 2016-10-07 14:42:01 --> XSS Filtering completed
DEBUG - 2016-10-07 14:42:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:42:01 --> Language Class Initialized
DEBUG - 2016-10-07 14:42:01 --> Loader Class Initialized
DEBUG - 2016-10-07 14:42:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:42:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:42:01 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:42:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:42:02 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:42:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:42:02 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:42:02 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:42:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:42:02 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:42:02 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:42:02 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:42:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:42:02 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:42:02 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:42:02 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:42:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:42:02 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:42:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:42:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:42:02 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:42:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:42:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:42:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:42:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:42:02 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:42:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:42:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:42:02 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:42:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:42:02 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:42:02 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:42:02 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:42:02 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:42:02 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:42:02 --> Session Class Initialized
DEBUG - 2016-10-07 14:42:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:42:02 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:42:02 --> Session routines successfully run
DEBUG - 2016-10-07 14:42:02 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:42:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:42:02 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:42:02 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:42:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:42:02 --> Controller Class Initialized
DEBUG - 2016-10-07 14:42:02 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:42:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:42:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:42:02 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:42:02 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:42:02 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:42:02 --> Model Class Initialized
DEBUG - 2016-10-07 14:42:02 --> Model Class Initialized
DEBUG - 2016-10-07 14:42:02 --> Model Class Initialized
DEBUG - 2016-10-07 14:42:02 --> Model Class Initialized
DEBUG - 2016-10-07 14:42:02 --> Model Class Initialized
DEBUG - 2016-10-07 14:42:02 --> Model Class Initialized
DEBUG - 2016-10-07 14:42:02 --> Model Class Initialized
DEBUG - 2016-10-07 14:42:02 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-10-07 14:42:02 --> Final output sent to browser
DEBUG - 2016-10-07 14:42:02 --> Total execution time: 0.9032
DEBUG - 2016-10-07 14:42:05 --> Config Class Initialized
DEBUG - 2016-10-07 14:42:05 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:42:05 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:42:05 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:42:05 --> URI Class Initialized
DEBUG - 2016-10-07 14:42:05 --> Router Class Initialized
DEBUG - 2016-10-07 14:42:05 --> Output Class Initialized
DEBUG - 2016-10-07 14:42:05 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:42:05 --> Security Class Initialized
DEBUG - 2016-10-07 14:42:05 --> Input Class Initialized
DEBUG - 2016-10-07 14:42:05 --> XSS Filtering completed
DEBUG - 2016-10-07 14:42:05 --> XSS Filtering completed
DEBUG - 2016-10-07 14:42:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:42:05 --> Language Class Initialized
DEBUG - 2016-10-07 14:42:05 --> Loader Class Initialized
DEBUG - 2016-10-07 14:42:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:42:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:42:05 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:42:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:42:05 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:42:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:42:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:42:05 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:42:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:42:05 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:42:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:42:05 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:42:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:42:05 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:42:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:42:06 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:42:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:42:06 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:42:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:42:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:42:06 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:42:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:42:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:42:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:42:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:42:06 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:42:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:42:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:42:06 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:42:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:42:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:42:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:42:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:42:06 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:42:06 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:42:06 --> Session Class Initialized
DEBUG - 2016-10-07 14:42:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:42:06 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:42:06 --> Session routines successfully run
DEBUG - 2016-10-07 14:42:06 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:42:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:42:06 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:42:06 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:42:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:42:06 --> Controller Class Initialized
DEBUG - 2016-10-07 14:42:06 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:42:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:42:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:42:06 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:42:06 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:42:06 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:42:06 --> Model Class Initialized
DEBUG - 2016-10-07 14:42:06 --> Model Class Initialized
DEBUG - 2016-10-07 14:42:06 --> Model Class Initialized
ERROR - 2016-10-07 14:42:06 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 14:42:06 --> Model Class Initialized
DEBUG - 2016-10-07 14:42:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-07 14:42:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:42:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:42:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:42:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:42:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:42:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:42:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:42:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:42:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:42:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:42:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:42:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:42:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:42:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:42:06 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-07 14:42:06 --> Final output sent to browser
DEBUG - 2016-10-07 14:42:06 --> Total execution time: 0.8492
DEBUG - 2016-10-07 14:42:13 --> Config Class Initialized
DEBUG - 2016-10-07 14:42:13 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:42:13 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:42:13 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:42:13 --> URI Class Initialized
DEBUG - 2016-10-07 14:42:13 --> Router Class Initialized
DEBUG - 2016-10-07 14:42:13 --> Output Class Initialized
DEBUG - 2016-10-07 14:42:13 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:42:13 --> Security Class Initialized
DEBUG - 2016-10-07 14:42:13 --> Input Class Initialized
DEBUG - 2016-10-07 14:42:13 --> XSS Filtering completed
DEBUG - 2016-10-07 14:42:13 --> XSS Filtering completed
DEBUG - 2016-10-07 14:42:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:42:13 --> Language Class Initialized
DEBUG - 2016-10-07 14:42:13 --> Loader Class Initialized
DEBUG - 2016-10-07 14:42:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:42:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:42:13 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:42:13 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:42:13 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:42:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:42:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:42:13 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:42:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:42:13 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:42:13 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:42:14 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:42:14 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:42:14 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:42:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:42:14 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:42:14 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:42:14 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:42:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:42:14 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:42:14 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:42:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:42:14 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:42:14 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:42:14 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:42:14 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:42:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:42:14 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:42:14 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:42:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:42:14 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:42:14 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:42:14 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:42:14 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:42:14 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:42:14 --> Session Class Initialized
DEBUG - 2016-10-07 14:42:14 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:42:14 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:42:14 --> Session routines successfully run
DEBUG - 2016-10-07 14:42:14 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:42:14 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:42:14 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:42:14 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:42:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:42:14 --> Controller Class Initialized
DEBUG - 2016-10-07 14:42:14 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:42:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:42:14 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:42:14 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:42:14 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:42:14 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:42:14 --> Model Class Initialized
DEBUG - 2016-10-07 14:42:14 --> Model Class Initialized
DEBUG - 2016-10-07 14:42:14 --> Model Class Initialized
ERROR - 2016-10-07 14:42:14 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 14:42:14 --> Model Class Initialized
DEBUG - 2016-10-07 14:42:14 --> Config Class Initialized
DEBUG - 2016-10-07 14:42:14 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:42:14 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:42:14 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:42:14 --> URI Class Initialized
DEBUG - 2016-10-07 14:42:14 --> Router Class Initialized
DEBUG - 2016-10-07 14:42:14 --> Output Class Initialized
DEBUG - 2016-10-07 14:42:14 --> Security Class Initialized
DEBUG - 2016-10-07 14:42:14 --> Input Class Initialized
DEBUG - 2016-10-07 14:42:14 --> XSS Filtering completed
DEBUG - 2016-10-07 14:42:14 --> XSS Filtering completed
DEBUG - 2016-10-07 14:42:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:42:14 --> Language Class Initialized
DEBUG - 2016-10-07 14:42:14 --> Loader Class Initialized
DEBUG - 2016-10-07 14:42:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:42:14 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:42:14 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:42:14 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:42:14 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:42:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:42:14 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:42:14 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:42:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:42:14 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:42:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:42:14 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:42:14 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:42:14 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:42:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:42:14 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:42:14 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:42:14 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:42:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:42:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:42:15 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:42:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:42:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:42:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:42:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:42:15 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:42:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:42:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:42:15 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:42:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:42:15 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:42:15 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:42:15 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:42:15 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:42:15 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:42:15 --> Session Class Initialized
DEBUG - 2016-10-07 14:42:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:42:15 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:42:15 --> Session routines successfully run
DEBUG - 2016-10-07 14:42:15 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:42:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:42:15 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:42:15 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:42:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:42:15 --> Controller Class Initialized
DEBUG - 2016-10-07 14:42:15 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:42:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:42:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:42:15 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:42:15 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:42:15 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:42:15 --> Model Class Initialized
DEBUG - 2016-10-07 14:42:15 --> Model Class Initialized
DEBUG - 2016-10-07 14:42:15 --> Model Class Initialized
ERROR - 2016-10-07 14:42:15 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 14:42:15 --> Model Class Initialized
DEBUG - 2016-10-07 14:46:12 --> Config Class Initialized
DEBUG - 2016-10-07 14:46:12 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:46:12 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:46:12 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:46:12 --> URI Class Initialized
DEBUG - 2016-10-07 14:46:12 --> Router Class Initialized
DEBUG - 2016-10-07 14:46:12 --> Output Class Initialized
DEBUG - 2016-10-07 14:46:12 --> Security Class Initialized
DEBUG - 2016-10-07 14:46:12 --> Input Class Initialized
DEBUG - 2016-10-07 14:46:12 --> XSS Filtering completed
DEBUG - 2016-10-07 14:46:12 --> XSS Filtering completed
DEBUG - 2016-10-07 14:46:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:46:12 --> Language Class Initialized
DEBUG - 2016-10-07 14:46:12 --> Loader Class Initialized
DEBUG - 2016-10-07 14:46:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:46:12 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:46:12 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:46:12 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:46:12 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:46:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:46:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:46:12 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:46:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:46:12 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:46:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:46:12 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:46:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:46:12 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:46:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:46:12 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:46:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:46:12 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:46:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:46:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:46:12 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:46:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:46:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:46:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:46:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:46:12 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:46:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:46:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:46:12 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:46:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:46:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:46:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:46:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:46:12 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:46:12 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:46:12 --> Session Class Initialized
DEBUG - 2016-10-07 14:46:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:46:12 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:46:12 --> Session routines successfully run
DEBUG - 2016-10-07 14:46:12 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:46:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:46:12 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:46:12 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:46:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:46:12 --> Controller Class Initialized
DEBUG - 2016-10-07 14:46:12 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:46:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:46:12 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:46:12 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:46:12 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:46:12 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:46:12 --> Model Class Initialized
DEBUG - 2016-10-07 14:46:12 --> Model Class Initialized
DEBUG - 2016-10-07 14:46:12 --> Model Class Initialized
ERROR - 2016-10-07 14:46:12 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 14:46:12 --> Model Class Initialized
DEBUG - 2016-10-07 14:46:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-07 14:46:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:46:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:46:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:46:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:46:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:46:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:46:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:46:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:46:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:46:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:46:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:46:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:46:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:46:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:46:13 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-07 14:46:13 --> Final output sent to browser
DEBUG - 2016-10-07 14:46:13 --> Total execution time: 0.8942
DEBUG - 2016-10-07 14:46:56 --> Config Class Initialized
DEBUG - 2016-10-07 14:46:56 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:46:56 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:46:56 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:46:56 --> URI Class Initialized
DEBUG - 2016-10-07 14:46:56 --> Router Class Initialized
DEBUG - 2016-10-07 14:46:56 --> Output Class Initialized
DEBUG - 2016-10-07 14:46:56 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:46:56 --> Security Class Initialized
DEBUG - 2016-10-07 14:46:56 --> Input Class Initialized
DEBUG - 2016-10-07 14:46:56 --> XSS Filtering completed
DEBUG - 2016-10-07 14:46:56 --> XSS Filtering completed
DEBUG - 2016-10-07 14:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:46:56 --> Language Class Initialized
DEBUG - 2016-10-07 14:46:56 --> Loader Class Initialized
DEBUG - 2016-10-07 14:46:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:46:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:46:57 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:46:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:46:57 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:46:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:46:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:46:57 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:46:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:46:57 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:46:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:46:57 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:46:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:46:57 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:46:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:46:57 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:46:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:46:57 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:46:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:46:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:46:57 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:46:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:46:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:46:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:46:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:46:57 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:46:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:46:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:46:57 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:46:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:46:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:46:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:46:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:46:57 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:46:57 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:46:57 --> Session Class Initialized
DEBUG - 2016-10-07 14:46:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:46:57 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:46:57 --> Session routines successfully run
DEBUG - 2016-10-07 14:46:57 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:46:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:46:57 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:46:57 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:46:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:46:57 --> Controller Class Initialized
DEBUG - 2016-10-07 14:46:57 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:46:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:46:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:46:57 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:46:57 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:46:57 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:46:57 --> Model Class Initialized
DEBUG - 2016-10-07 14:46:57 --> Model Class Initialized
DEBUG - 2016-10-07 14:46:57 --> Model Class Initialized
ERROR - 2016-10-07 14:46:57 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 14:46:57 --> Model Class Initialized
DEBUG - 2016-10-07 14:46:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-07 14:46:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:46:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:46:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:46:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:46:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:46:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:46:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:46:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:46:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:46:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:46:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:46:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:46:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:46:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:46:57 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-07 14:46:57 --> Final output sent to browser
DEBUG - 2016-10-07 14:46:57 --> Total execution time: 0.9488
DEBUG - 2016-10-07 14:47:36 --> Config Class Initialized
DEBUG - 2016-10-07 14:47:36 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:47:36 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:47:36 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:47:36 --> URI Class Initialized
DEBUG - 2016-10-07 14:47:36 --> Router Class Initialized
DEBUG - 2016-10-07 14:47:36 --> Output Class Initialized
DEBUG - 2016-10-07 14:47:36 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:47:36 --> Security Class Initialized
DEBUG - 2016-10-07 14:47:36 --> Input Class Initialized
DEBUG - 2016-10-07 14:47:36 --> XSS Filtering completed
DEBUG - 2016-10-07 14:47:36 --> XSS Filtering completed
DEBUG - 2016-10-07 14:47:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:47:36 --> Language Class Initialized
DEBUG - 2016-10-07 14:47:36 --> Loader Class Initialized
DEBUG - 2016-10-07 14:47:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:47:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:47:36 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:47:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:47:36 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:47:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:47:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:47:36 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:47:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:47:36 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:47:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:47:36 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:47:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:47:36 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:47:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:47:36 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:47:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:47:37 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:47:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:47:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:47:37 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:47:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:47:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:47:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:47:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:47:37 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:47:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:47:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:47:37 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:47:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:47:37 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:47:37 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:47:37 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:47:37 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:47:37 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:47:37 --> Session Class Initialized
DEBUG - 2016-10-07 14:47:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:47:37 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:47:37 --> Session routines successfully run
DEBUG - 2016-10-07 14:47:37 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:47:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:47:37 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:47:37 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:47:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:47:37 --> Controller Class Initialized
DEBUG - 2016-10-07 14:47:37 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:47:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:47:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:47:37 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:47:37 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:47:37 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:47:37 --> Model Class Initialized
DEBUG - 2016-10-07 14:47:37 --> Model Class Initialized
DEBUG - 2016-10-07 14:47:37 --> Model Class Initialized
ERROR - 2016-10-07 14:47:37 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 14:47:37 --> Model Class Initialized
DEBUG - 2016-10-07 14:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-07 14:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:47:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-07 14:47:37 --> Final output sent to browser
DEBUG - 2016-10-07 14:47:37 --> Total execution time: 0.9401
DEBUG - 2016-10-07 14:48:03 --> Config Class Initialized
DEBUG - 2016-10-07 14:48:03 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:48:03 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:48:03 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:48:03 --> URI Class Initialized
DEBUG - 2016-10-07 14:48:03 --> Router Class Initialized
DEBUG - 2016-10-07 14:48:03 --> Output Class Initialized
DEBUG - 2016-10-07 14:48:03 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:48:03 --> Security Class Initialized
DEBUG - 2016-10-07 14:48:03 --> Input Class Initialized
DEBUG - 2016-10-07 14:48:03 --> XSS Filtering completed
DEBUG - 2016-10-07 14:48:03 --> XSS Filtering completed
DEBUG - 2016-10-07 14:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:48:03 --> Language Class Initialized
DEBUG - 2016-10-07 14:48:03 --> Loader Class Initialized
DEBUG - 2016-10-07 14:48:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:48:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:48:03 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:48:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:48:03 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:48:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:48:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:48:03 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:48:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:48:03 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:48:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:48:03 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:48:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:48:03 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:48:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:48:03 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:48:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:48:03 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:48:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:48:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:48:03 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:48:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:48:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:48:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:48:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:48:03 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:48:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:48:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:48:03 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:48:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:48:03 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:48:03 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:48:03 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:48:03 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:48:03 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:48:04 --> Session Class Initialized
DEBUG - 2016-10-07 14:48:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:48:04 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:48:04 --> Session routines successfully run
DEBUG - 2016-10-07 14:48:04 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:48:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:48:04 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:48:04 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:48:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:48:04 --> Controller Class Initialized
DEBUG - 2016-10-07 14:48:04 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:48:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:48:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:48:04 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:48:04 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:48:04 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:48:04 --> Model Class Initialized
DEBUG - 2016-10-07 14:48:04 --> Model Class Initialized
DEBUG - 2016-10-07 14:48:04 --> Model Class Initialized
ERROR - 2016-10-07 14:48:04 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 14:48:04 --> Model Class Initialized
DEBUG - 2016-10-07 14:48:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-07 14:48:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:48:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:48:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:48:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:48:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:48:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:48:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:48:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:48:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:48:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:48:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:48:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:48:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:48:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:48:04 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-07 14:48:04 --> Final output sent to browser
DEBUG - 2016-10-07 14:48:04 --> Total execution time: 0.9677
DEBUG - 2016-10-07 14:48:44 --> Config Class Initialized
DEBUG - 2016-10-07 14:48:44 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:48:44 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:48:44 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:48:44 --> URI Class Initialized
DEBUG - 2016-10-07 14:48:44 --> Router Class Initialized
DEBUG - 2016-10-07 14:48:44 --> Output Class Initialized
DEBUG - 2016-10-07 14:48:44 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:48:44 --> Security Class Initialized
DEBUG - 2016-10-07 14:48:44 --> Input Class Initialized
DEBUG - 2016-10-07 14:48:44 --> XSS Filtering completed
DEBUG - 2016-10-07 14:48:44 --> XSS Filtering completed
DEBUG - 2016-10-07 14:48:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:48:45 --> Language Class Initialized
DEBUG - 2016-10-07 14:48:45 --> Loader Class Initialized
DEBUG - 2016-10-07 14:48:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:48:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:48:45 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:48:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:48:45 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:48:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:48:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:48:45 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:48:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:48:45 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:48:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:48:45 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:48:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:48:45 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:48:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:48:45 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:48:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:48:45 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:48:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:48:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:48:45 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:48:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:48:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:48:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:48:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:48:45 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:48:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:48:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:48:45 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:48:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:48:45 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:48:45 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:48:45 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:48:45 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:48:45 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:48:45 --> Session Class Initialized
DEBUG - 2016-10-07 14:48:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:48:45 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:48:45 --> Session routines successfully run
DEBUG - 2016-10-07 14:48:45 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:48:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:48:45 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:48:45 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:48:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:48:45 --> Controller Class Initialized
DEBUG - 2016-10-07 14:48:45 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:48:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:48:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:48:45 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:48:45 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:48:45 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:48:45 --> Model Class Initialized
DEBUG - 2016-10-07 14:48:45 --> Model Class Initialized
DEBUG - 2016-10-07 14:48:45 --> Model Class Initialized
ERROR - 2016-10-07 14:48:45 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 14:48:45 --> Model Class Initialized
DEBUG - 2016-10-07 14:48:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-07 14:48:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:48:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:48:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:48:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:48:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:48:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:48:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:48:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:48:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:48:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:48:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:48:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:48:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:48:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:48:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-07 14:48:46 --> Final output sent to browser
DEBUG - 2016-10-07 14:48:46 --> Total execution time: 0.9800
DEBUG - 2016-10-07 14:54:19 --> Config Class Initialized
DEBUG - 2016-10-07 14:54:19 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:54:19 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:54:19 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:54:19 --> URI Class Initialized
DEBUG - 2016-10-07 14:54:19 --> Router Class Initialized
DEBUG - 2016-10-07 14:54:19 --> Output Class Initialized
DEBUG - 2016-10-07 14:54:19 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:54:19 --> Security Class Initialized
DEBUG - 2016-10-07 14:54:19 --> Input Class Initialized
DEBUG - 2016-10-07 14:54:19 --> XSS Filtering completed
DEBUG - 2016-10-07 14:54:19 --> XSS Filtering completed
DEBUG - 2016-10-07 14:54:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:54:19 --> Language Class Initialized
DEBUG - 2016-10-07 14:54:19 --> Loader Class Initialized
DEBUG - 2016-10-07 14:54:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:54:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:54:19 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:54:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:54:19 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:54:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:54:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:54:19 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:54:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:54:19 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:54:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:54:19 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:54:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:54:19 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:54:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:54:19 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:54:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:54:19 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:54:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:54:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:54:19 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:54:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:54:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:54:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:54:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:54:19 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:54:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:54:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:54:19 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:54:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:54:20 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:54:20 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:54:20 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:54:20 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:54:20 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:54:20 --> Session Class Initialized
DEBUG - 2016-10-07 14:54:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:54:20 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:54:20 --> Session routines successfully run
DEBUG - 2016-10-07 14:54:20 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:54:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:54:20 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:54:20 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:54:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:54:20 --> Controller Class Initialized
DEBUG - 2016-10-07 14:54:20 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:54:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:54:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:54:20 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:54:20 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:54:20 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:54:20 --> Model Class Initialized
DEBUG - 2016-10-07 14:54:20 --> Model Class Initialized
DEBUG - 2016-10-07 14:54:20 --> Model Class Initialized
ERROR - 2016-10-07 14:54:20 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 14:54:20 --> Model Class Initialized
DEBUG - 2016-10-07 14:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-07 14:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:54:20 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-07 14:54:20 --> Final output sent to browser
DEBUG - 2016-10-07 14:54:20 --> Total execution time: 1.0358
DEBUG - 2016-10-07 14:55:56 --> Config Class Initialized
DEBUG - 2016-10-07 14:55:56 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:55:56 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:55:56 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:55:56 --> URI Class Initialized
DEBUG - 2016-10-07 14:55:56 --> Router Class Initialized
DEBUG - 2016-10-07 14:55:56 --> Output Class Initialized
DEBUG - 2016-10-07 14:55:56 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:55:56 --> Security Class Initialized
DEBUG - 2016-10-07 14:55:56 --> Input Class Initialized
DEBUG - 2016-10-07 14:55:56 --> XSS Filtering completed
DEBUG - 2016-10-07 14:55:56 --> XSS Filtering completed
DEBUG - 2016-10-07 14:55:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:55:56 --> Language Class Initialized
DEBUG - 2016-10-07 14:55:56 --> Loader Class Initialized
DEBUG - 2016-10-07 14:55:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:55:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:55:56 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:55:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:55:56 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:55:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:55:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:55:56 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:55:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:55:56 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:55:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:55:56 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:55:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:55:56 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:55:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:55:56 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:55:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:55:56 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:55:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:55:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:55:56 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:55:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:55:56 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:55:56 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:55:56 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:55:56 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:55:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:55:56 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:55:56 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:55:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:55:56 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:55:56 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:55:56 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:55:56 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:55:56 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:55:56 --> Session Class Initialized
DEBUG - 2016-10-07 14:55:56 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:55:56 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:55:56 --> Session routines successfully run
DEBUG - 2016-10-07 14:55:56 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:55:56 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:55:56 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:55:56 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:55:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:55:56 --> Controller Class Initialized
DEBUG - 2016-10-07 14:55:56 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:55:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:55:56 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:55:56 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:55:56 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:55:56 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:55:56 --> Model Class Initialized
DEBUG - 2016-10-07 14:55:56 --> Model Class Initialized
DEBUG - 2016-10-07 14:55:56 --> Model Class Initialized
ERROR - 2016-10-07 14:55:56 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 14:55:57 --> Model Class Initialized
DEBUG - 2016-10-07 14:55:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-07 14:55:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:55:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:55:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:55:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:55:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:55:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:55:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:55:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:55:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:55:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:55:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:55:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:55:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:55:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:55:57 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-07 14:55:57 --> Final output sent to browser
DEBUG - 2016-10-07 14:55:57 --> Total execution time: 1.0123
DEBUG - 2016-10-07 14:57:47 --> Config Class Initialized
DEBUG - 2016-10-07 14:57:47 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:57:47 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:57:47 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:57:47 --> URI Class Initialized
DEBUG - 2016-10-07 14:57:47 --> Router Class Initialized
DEBUG - 2016-10-07 14:57:47 --> Output Class Initialized
DEBUG - 2016-10-07 14:57:47 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:57:47 --> Security Class Initialized
DEBUG - 2016-10-07 14:57:47 --> Input Class Initialized
DEBUG - 2016-10-07 14:57:47 --> XSS Filtering completed
DEBUG - 2016-10-07 14:57:47 --> XSS Filtering completed
DEBUG - 2016-10-07 14:57:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:57:47 --> Language Class Initialized
DEBUG - 2016-10-07 14:57:47 --> Loader Class Initialized
DEBUG - 2016-10-07 14:57:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:57:47 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:57:47 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:57:47 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:57:47 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:57:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:57:47 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:57:47 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:57:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:57:47 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:57:47 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:57:47 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:57:47 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:57:47 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:57:47 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:57:47 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:57:47 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:57:47 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:57:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:57:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:57:47 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:57:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:57:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:57:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:57:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:57:47 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:57:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:57:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:57:47 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:57:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:57:47 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:57:47 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:57:47 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:57:47 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:57:47 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:57:47 --> Session Class Initialized
DEBUG - 2016-10-07 14:57:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:57:47 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:57:47 --> Session routines successfully run
DEBUG - 2016-10-07 14:57:47 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:57:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:57:47 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:57:47 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:57:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:57:47 --> Controller Class Initialized
DEBUG - 2016-10-07 14:57:47 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:57:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:57:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:57:47 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:57:47 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:57:47 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:57:47 --> Model Class Initialized
DEBUG - 2016-10-07 14:57:47 --> Model Class Initialized
DEBUG - 2016-10-07 14:57:47 --> Model Class Initialized
ERROR - 2016-10-07 14:57:48 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 14:57:48 --> Model Class Initialized
DEBUG - 2016-10-07 14:57:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-07 14:57:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:57:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:57:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:57:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:57:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:57:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:57:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:57:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:57:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:57:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:57:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:57:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:57:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:57:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:57:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-07 14:57:48 --> Final output sent to browser
DEBUG - 2016-10-07 14:57:48 --> Total execution time: 1.0274
DEBUG - 2016-10-07 14:58:58 --> Config Class Initialized
DEBUG - 2016-10-07 14:58:58 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:58:58 --> Utf8 Class Initialized
DEBUG - 2016-10-07 14:58:58 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 14:58:58 --> URI Class Initialized
DEBUG - 2016-10-07 14:58:58 --> Router Class Initialized
DEBUG - 2016-10-07 14:58:58 --> Output Class Initialized
DEBUG - 2016-10-07 14:58:58 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 14:58:58 --> Security Class Initialized
DEBUG - 2016-10-07 14:58:58 --> Input Class Initialized
DEBUG - 2016-10-07 14:58:58 --> XSS Filtering completed
DEBUG - 2016-10-07 14:58:58 --> XSS Filtering completed
DEBUG - 2016-10-07 14:58:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 14:58:58 --> Language Class Initialized
DEBUG - 2016-10-07 14:58:58 --> Loader Class Initialized
DEBUG - 2016-10-07 14:58:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 14:58:58 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 14:58:58 --> Helper loaded: url_helper
DEBUG - 2016-10-07 14:58:58 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 14:58:58 --> Helper loaded: file_helper
DEBUG - 2016-10-07 14:58:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:58:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 14:58:58 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 14:58:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 14:58:58 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 14:58:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 14:58:58 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:58:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 14:58:58 --> Helper loaded: common_helper
DEBUG - 2016-10-07 14:58:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 14:58:59 --> Helper loaded: form_helper
DEBUG - 2016-10-07 14:58:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 14:58:59 --> Helper loaded: security_helper
DEBUG - 2016-10-07 14:58:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:58:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 14:58:59 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 14:58:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 14:58:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 14:58:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 14:58:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 14:58:59 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 14:58:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:58:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 14:58:59 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 14:58:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 14:58:59 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 14:58:59 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 14:58:59 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 14:58:59 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 14:58:59 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:58:59 --> Session Class Initialized
DEBUG - 2016-10-07 14:58:59 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 14:58:59 --> Helper loaded: string_helper
DEBUG - 2016-10-07 14:58:59 --> Session routines successfully run
DEBUG - 2016-10-07 14:58:59 --> Native_session Class Initialized
DEBUG - 2016-10-07 14:58:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 14:58:59 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:58:59 --> Form Validation Class Initialized
DEBUG - 2016-10-07 14:58:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 14:58:59 --> Controller Class Initialized
DEBUG - 2016-10-07 14:58:59 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 14:58:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 14:58:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 14:58:59 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:58:59 --> Carabiner: library configured.
DEBUG - 2016-10-07 14:58:59 --> User Agent Class Initialized
DEBUG - 2016-10-07 14:58:59 --> Model Class Initialized
DEBUG - 2016-10-07 14:58:59 --> Model Class Initialized
DEBUG - 2016-10-07 14:58:59 --> Model Class Initialized
ERROR - 2016-10-07 14:58:59 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 14:58:59 --> Model Class Initialized
DEBUG - 2016-10-07 14:58:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-07 14:58:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:58:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:58:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:58:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:58:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:58:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:58:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:58:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 14:58:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 14:58:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 14:58:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 14:58:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 14:58:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 14:58:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 14:58:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-07 14:58:59 --> Final output sent to browser
DEBUG - 2016-10-07 14:58:59 --> Total execution time: 1.0600
DEBUG - 2016-10-07 15:02:34 --> Config Class Initialized
DEBUG - 2016-10-07 15:02:34 --> Hooks Class Initialized
DEBUG - 2016-10-07 15:02:34 --> Utf8 Class Initialized
DEBUG - 2016-10-07 15:02:34 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 15:02:34 --> URI Class Initialized
DEBUG - 2016-10-07 15:02:34 --> Router Class Initialized
DEBUG - 2016-10-07 15:02:34 --> Output Class Initialized
DEBUG - 2016-10-07 15:02:34 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 15:02:34 --> Security Class Initialized
DEBUG - 2016-10-07 15:02:34 --> Input Class Initialized
DEBUG - 2016-10-07 15:02:34 --> XSS Filtering completed
DEBUG - 2016-10-07 15:02:34 --> XSS Filtering completed
DEBUG - 2016-10-07 15:02:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 15:02:34 --> Language Class Initialized
DEBUG - 2016-10-07 15:02:34 --> Loader Class Initialized
DEBUG - 2016-10-07 15:02:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 15:02:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 15:02:34 --> Helper loaded: url_helper
DEBUG - 2016-10-07 15:02:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 15:02:34 --> Helper loaded: file_helper
DEBUG - 2016-10-07 15:02:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 15:02:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 15:02:34 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 15:02:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 15:02:34 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 15:02:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 15:02:34 --> Helper loaded: common_helper
DEBUG - 2016-10-07 15:02:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 15:02:34 --> Helper loaded: common_helper
DEBUG - 2016-10-07 15:02:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 15:02:34 --> Helper loaded: form_helper
DEBUG - 2016-10-07 15:02:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 15:02:34 --> Helper loaded: security_helper
DEBUG - 2016-10-07 15:02:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 15:02:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 15:02:34 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 15:02:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 15:02:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 15:02:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 15:02:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 15:02:34 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 15:02:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 15:02:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 15:02:34 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 15:02:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 15:02:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 15:02:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 15:02:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 15:02:34 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 15:02:34 --> Database Driver Class Initialized
DEBUG - 2016-10-07 15:02:34 --> Session Class Initialized
DEBUG - 2016-10-07 15:02:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 15:02:34 --> Helper loaded: string_helper
DEBUG - 2016-10-07 15:02:34 --> Session routines successfully run
DEBUG - 2016-10-07 15:02:34 --> Native_session Class Initialized
DEBUG - 2016-10-07 15:02:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 15:02:35 --> Form Validation Class Initialized
DEBUG - 2016-10-07 15:02:35 --> Form Validation Class Initialized
DEBUG - 2016-10-07 15:02:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 15:02:35 --> Controller Class Initialized
DEBUG - 2016-10-07 15:02:35 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 15:02:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 15:02:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 15:02:35 --> Carabiner: library configured.
DEBUG - 2016-10-07 15:02:35 --> Carabiner: library configured.
DEBUG - 2016-10-07 15:02:35 --> User Agent Class Initialized
DEBUG - 2016-10-07 15:02:35 --> Model Class Initialized
DEBUG - 2016-10-07 15:02:35 --> Model Class Initialized
DEBUG - 2016-10-07 15:02:35 --> Model Class Initialized
ERROR - 2016-10-07 15:02:35 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 15:02:35 --> Model Class Initialized
DEBUG - 2016-10-07 15:02:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-07 15:02:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 15:02:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 15:02:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 15:02:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 15:02:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 15:02:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 15:02:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 15:02:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 15:02:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 15:02:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 15:02:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 15:02:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 15:02:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 15:02:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 15:02:35 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-07 15:02:35 --> Final output sent to browser
DEBUG - 2016-10-07 15:02:35 --> Total execution time: 1.0756
DEBUG - 2016-10-07 15:03:52 --> Config Class Initialized
DEBUG - 2016-10-07 15:03:52 --> Hooks Class Initialized
DEBUG - 2016-10-07 15:03:52 --> Utf8 Class Initialized
DEBUG - 2016-10-07 15:03:52 --> UTF-8 Support Enabled
DEBUG - 2016-10-07 15:03:52 --> URI Class Initialized
DEBUG - 2016-10-07 15:03:52 --> Router Class Initialized
DEBUG - 2016-10-07 15:03:52 --> Output Class Initialized
DEBUG - 2016-10-07 15:03:52 --> Cache file has expired. File deleted
DEBUG - 2016-10-07 15:03:52 --> Security Class Initialized
DEBUG - 2016-10-07 15:03:52 --> Input Class Initialized
DEBUG - 2016-10-07 15:03:52 --> XSS Filtering completed
DEBUG - 2016-10-07 15:03:52 --> XSS Filtering completed
DEBUG - 2016-10-07 15:03:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-07 15:03:52 --> Language Class Initialized
DEBUG - 2016-10-07 15:03:52 --> Loader Class Initialized
DEBUG - 2016-10-07 15:03:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-07 15:03:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-07 15:03:52 --> Helper loaded: url_helper
DEBUG - 2016-10-07 15:03:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-07 15:03:52 --> Helper loaded: file_helper
DEBUG - 2016-10-07 15:03:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 15:03:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-07 15:03:52 --> Helper loaded: conf_helper
DEBUG - 2016-10-07 15:03:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-07 15:03:52 --> Check Exists common_helper.php: No
DEBUG - 2016-10-07 15:03:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-07 15:03:52 --> Helper loaded: common_helper
DEBUG - 2016-10-07 15:03:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-07 15:03:52 --> Helper loaded: common_helper
DEBUG - 2016-10-07 15:03:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-07 15:03:52 --> Helper loaded: form_helper
DEBUG - 2016-10-07 15:03:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-07 15:03:52 --> Helper loaded: security_helper
DEBUG - 2016-10-07 15:03:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 15:03:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-07 15:03:52 --> Helper loaded: lang_helper
DEBUG - 2016-10-07 15:03:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-07 15:03:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-07 15:03:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-07 15:03:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-07 15:03:52 --> Helper loaded: atlant_helper
DEBUG - 2016-10-07 15:03:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 15:03:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-07 15:03:52 --> Helper loaded: crypto_helper
DEBUG - 2016-10-07 15:03:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-07 15:03:52 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-07 15:03:52 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-07 15:03:53 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-07 15:03:53 --> Helper loaded: sidika_helper
DEBUG - 2016-10-07 15:03:53 --> Database Driver Class Initialized
DEBUG - 2016-10-07 15:03:53 --> Session Class Initialized
DEBUG - 2016-10-07 15:03:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-07 15:03:53 --> Helper loaded: string_helper
DEBUG - 2016-10-07 15:03:53 --> Session routines successfully run
DEBUG - 2016-10-07 15:03:53 --> Native_session Class Initialized
DEBUG - 2016-10-07 15:03:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-07 15:03:53 --> Form Validation Class Initialized
DEBUG - 2016-10-07 15:03:53 --> Form Validation Class Initialized
DEBUG - 2016-10-07 15:03:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-07 15:03:53 --> Controller Class Initialized
DEBUG - 2016-10-07 15:03:53 --> Carabiner: Library initialized.
DEBUG - 2016-10-07 15:03:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-07 15:03:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-07 15:03:53 --> Carabiner: library configured.
DEBUG - 2016-10-07 15:03:53 --> Carabiner: library configured.
DEBUG - 2016-10-07 15:03:53 --> User Agent Class Initialized
DEBUG - 2016-10-07 15:03:53 --> Model Class Initialized
DEBUG - 2016-10-07 15:03:53 --> Model Class Initialized
DEBUG - 2016-10-07 15:03:53 --> Model Class Initialized
ERROR - 2016-10-07 15:03:53 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-07 15:03:53 --> Model Class Initialized
DEBUG - 2016-10-07 15:03:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-07 15:03:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 15:03:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 15:03:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 15:03:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 15:03:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 15:03:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 15:03:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 15:03:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-07 15:03:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-07 15:03:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-07 15:03:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-07 15:03:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-07 15:03:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-07 15:03:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-07 15:03:53 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-07 15:03:53 --> Final output sent to browser
DEBUG - 2016-10-07 15:03:53 --> Total execution time: 1.1140
