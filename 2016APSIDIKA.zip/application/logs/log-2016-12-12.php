<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-12-12 22:43:40 --> Config Class Initialized
DEBUG - 2016-12-12 22:43:40 --> Hooks Class Initialized
DEBUG - 2016-12-12 22:43:40 --> Utf8 Class Initialized
DEBUG - 2016-12-12 22:43:40 --> UTF-8 Support Enabled
DEBUG - 2016-12-12 22:43:40 --> URI Class Initialized
DEBUG - 2016-12-12 22:43:40 --> Router Class Initialized
DEBUG - 2016-12-12 22:43:40 --> No URI present. Default controller set.
DEBUG - 2016-12-12 22:43:40 --> Output Class Initialized
DEBUG - 2016-12-12 22:43:40 --> Security Class Initialized
DEBUG - 2016-12-12 22:43:40 --> Input Class Initialized
DEBUG - 2016-12-12 22:43:40 --> XSS Filtering completed
DEBUG - 2016-12-12 22:43:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-12 22:43:40 --> Language Class Initialized
DEBUG - 2016-12-12 22:43:41 --> Loader Class Initialized
DEBUG - 2016-12-12 22:43:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-12 22:43:41 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-12 22:43:41 --> Helper loaded: url_helper
DEBUG - 2016-12-12 22:43:41 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-12 22:43:41 --> Helper loaded: file_helper
DEBUG - 2016-12-12 22:43:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-12 22:43:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-12 22:43:41 --> Helper loaded: conf_helper
DEBUG - 2016-12-12 22:43:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-12 22:43:41 --> Check Exists common_helper.php: No
DEBUG - 2016-12-12 22:43:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-12 22:43:41 --> Helper loaded: common_helper
DEBUG - 2016-12-12 22:43:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-12 22:43:41 --> Helper loaded: common_helper
DEBUG - 2016-12-12 22:43:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-12 22:43:41 --> Helper loaded: form_helper
DEBUG - 2016-12-12 22:43:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-12 22:43:41 --> Helper loaded: security_helper
DEBUG - 2016-12-12 22:43:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-12 22:43:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-12 22:43:41 --> Helper loaded: lang_helper
DEBUG - 2016-12-12 22:43:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-12 22:43:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-12 22:43:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-12 22:43:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-12 22:43:41 --> Helper loaded: atlant_helper
DEBUG - 2016-12-12 22:43:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-12 22:43:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-12 22:43:41 --> Helper loaded: crypto_helper
DEBUG - 2016-12-12 22:43:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-12 22:43:41 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-12 22:43:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-12 22:43:41 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-12 22:43:41 --> Helper loaded: sidika_helper
DEBUG - 2016-12-12 22:43:41 --> Database Driver Class Initialized
DEBUG - 2016-12-12 22:43:42 --> Session Class Initialized
DEBUG - 2016-12-12 22:43:42 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-12 22:43:42 --> Helper loaded: string_helper
DEBUG - 2016-12-12 22:43:42 --> A session cookie was not found.
DEBUG - 2016-12-12 22:43:42 --> Session routines successfully run
DEBUG - 2016-12-12 22:43:42 --> Native_session Class Initialized
DEBUG - 2016-12-12 22:43:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-12 22:43:43 --> Form Validation Class Initialized
DEBUG - 2016-12-12 22:43:43 --> Form Validation Class Initialized
DEBUG - 2016-12-12 22:43:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-12 22:43:43 --> Controller Class Initialized
DEBUG - 2016-12-12 22:43:43 --> Carabiner: Library initialized.
DEBUG - 2016-12-12 22:43:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-12 22:43:43 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-12 22:43:43 --> Carabiner: library configured.
DEBUG - 2016-12-12 22:43:43 --> Carabiner: library configured.
DEBUG - 2016-12-12 22:43:43 --> User Agent Class Initialized
DEBUG - 2016-12-12 22:43:43 --> Model Class Initialized
DEBUG - 2016-12-12 22:43:43 --> Model Class Initialized
DEBUG - 2016-12-12 22:43:44 --> Model Class Initialized
ERROR - 2016-12-12 22:43:45 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-12-12 22:43:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-12-12 22:43:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-12-12 22:43:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-12 22:43:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-12 22:43:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-12 22:43:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-12 22:43:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-12 22:43:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-12-12 22:43:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-12-12 22:43:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-12 22:43:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-12 22:43:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-12 22:43:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-12 22:43:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-12 22:43:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-12 22:43:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-12 22:43:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-12-12 22:43:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-12-12 22:43:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-12 22:43:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-12 22:43:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-12-12 22:43:45 --> Final output sent to browser
DEBUG - 2016-12-12 22:43:45 --> Total execution time: 5.2702
DEBUG - 2016-12-12 22:43:53 --> Config Class Initialized
DEBUG - 2016-12-12 22:43:53 --> Hooks Class Initialized
DEBUG - 2016-12-12 22:43:53 --> Utf8 Class Initialized
DEBUG - 2016-12-12 22:43:53 --> UTF-8 Support Enabled
DEBUG - 2016-12-12 22:43:53 --> URI Class Initialized
DEBUG - 2016-12-12 22:43:53 --> Router Class Initialized
DEBUG - 2016-12-12 22:43:53 --> Output Class Initialized
DEBUG - 2016-12-12 22:43:53 --> Cache file has expired. File deleted
DEBUG - 2016-12-12 22:43:53 --> Security Class Initialized
DEBUG - 2016-12-12 22:43:53 --> Input Class Initialized
DEBUG - 2016-12-12 22:43:53 --> XSS Filtering completed
DEBUG - 2016-12-12 22:43:53 --> XSS Filtering completed
DEBUG - 2016-12-12 22:43:53 --> XSS Filtering completed
DEBUG - 2016-12-12 22:43:53 --> XSS Filtering completed
DEBUG - 2016-12-12 22:43:53 --> XSS Filtering completed
DEBUG - 2016-12-12 22:43:53 --> XSS Filtering completed
DEBUG - 2016-12-12 22:43:53 --> XSS Filtering completed
DEBUG - 2016-12-12 22:43:53 --> XSS Filtering completed
DEBUG - 2016-12-12 22:43:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-12 22:43:53 --> Language Class Initialized
DEBUG - 2016-12-12 22:43:53 --> Loader Class Initialized
DEBUG - 2016-12-12 22:43:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-12 22:43:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-12 22:43:53 --> Helper loaded: url_helper
DEBUG - 2016-12-12 22:43:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-12 22:43:53 --> Helper loaded: file_helper
DEBUG - 2016-12-12 22:43:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-12 22:43:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-12 22:43:53 --> Helper loaded: conf_helper
DEBUG - 2016-12-12 22:43:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-12 22:43:53 --> Check Exists common_helper.php: No
DEBUG - 2016-12-12 22:43:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-12 22:43:53 --> Helper loaded: common_helper
DEBUG - 2016-12-12 22:43:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-12 22:43:53 --> Helper loaded: common_helper
DEBUG - 2016-12-12 22:43:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-12 22:43:53 --> Helper loaded: form_helper
DEBUG - 2016-12-12 22:43:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-12 22:43:53 --> Helper loaded: security_helper
DEBUG - 2016-12-12 22:43:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-12 22:43:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-12 22:43:53 --> Helper loaded: lang_helper
DEBUG - 2016-12-12 22:43:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-12 22:43:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-12 22:43:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-12 22:43:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-12 22:43:53 --> Helper loaded: atlant_helper
DEBUG - 2016-12-12 22:43:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-12 22:43:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-12 22:43:53 --> Helper loaded: crypto_helper
DEBUG - 2016-12-12 22:43:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-12 22:43:53 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-12 22:43:53 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-12 22:43:53 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-12 22:43:53 --> Helper loaded: sidika_helper
DEBUG - 2016-12-12 22:43:53 --> Database Driver Class Initialized
DEBUG - 2016-12-12 22:43:53 --> Session Class Initialized
DEBUG - 2016-12-12 22:43:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-12 22:43:53 --> Helper loaded: string_helper
DEBUG - 2016-12-12 22:43:53 --> Session routines successfully run
DEBUG - 2016-12-12 22:43:53 --> Native_session Class Initialized
DEBUG - 2016-12-12 22:43:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-12 22:43:53 --> Form Validation Class Initialized
DEBUG - 2016-12-12 22:43:53 --> Form Validation Class Initialized
DEBUG - 2016-12-12 22:43:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-12 22:43:53 --> Controller Class Initialized
DEBUG - 2016-12-12 22:43:53 --> Carabiner: Library initialized.
DEBUG - 2016-12-12 22:43:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-12 22:43:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-12 22:43:53 --> Carabiner: library configured.
DEBUG - 2016-12-12 22:43:53 --> Carabiner: library configured.
DEBUG - 2016-12-12 22:43:53 --> User Agent Class Initialized
DEBUG - 2016-12-12 22:43:53 --> Model Class Initialized
DEBUG - 2016-12-12 22:43:53 --> Model Class Initialized
DEBUG - 2016-12-12 22:43:53 --> Model Class Initialized
DEBUG - 2016-12-12 22:43:54 --> Model Class Initialized
DEBUG - 2016-12-12 22:43:54 --> Model Class Initialized
DEBUG - 2016-12-12 22:43:54 --> Model Class Initialized
DEBUG - 2016-12-12 22:43:54 --> Model Class Initialized
DEBUG - 2016-12-12 22:43:56 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-12-12 22:43:56 --> Final output sent to browser
DEBUG - 2016-12-12 22:43:56 --> Total execution time: 3.2171
DEBUG - 2016-12-12 22:44:02 --> Config Class Initialized
DEBUG - 2016-12-12 22:44:02 --> Hooks Class Initialized
DEBUG - 2016-12-12 22:44:02 --> Utf8 Class Initialized
DEBUG - 2016-12-12 22:44:02 --> UTF-8 Support Enabled
DEBUG - 2016-12-12 22:44:02 --> URI Class Initialized
DEBUG - 2016-12-12 22:44:02 --> Router Class Initialized
DEBUG - 2016-12-12 22:44:02 --> Output Class Initialized
DEBUG - 2016-12-12 22:44:02 --> Cache file has expired. File deleted
DEBUG - 2016-12-12 22:44:02 --> Security Class Initialized
DEBUG - 2016-12-12 22:44:02 --> Input Class Initialized
DEBUG - 2016-12-12 22:44:02 --> XSS Filtering completed
DEBUG - 2016-12-12 22:44:02 --> XSS Filtering completed
DEBUG - 2016-12-12 22:44:02 --> XSS Filtering completed
DEBUG - 2016-12-12 22:44:02 --> XSS Filtering completed
DEBUG - 2016-12-12 22:44:02 --> XSS Filtering completed
DEBUG - 2016-12-12 22:44:02 --> XSS Filtering completed
DEBUG - 2016-12-12 22:44:02 --> XSS Filtering completed
DEBUG - 2016-12-12 22:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-12 22:44:02 --> Language Class Initialized
DEBUG - 2016-12-12 22:44:02 --> Loader Class Initialized
DEBUG - 2016-12-12 22:44:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-12 22:44:02 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-12 22:44:02 --> Helper loaded: url_helper
DEBUG - 2016-12-12 22:44:02 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-12 22:44:02 --> Helper loaded: file_helper
DEBUG - 2016-12-12 22:44:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-12 22:44:02 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-12 22:44:02 --> Helper loaded: conf_helper
DEBUG - 2016-12-12 22:44:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-12 22:44:02 --> Check Exists common_helper.php: No
DEBUG - 2016-12-12 22:44:02 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-12 22:44:02 --> Helper loaded: common_helper
DEBUG - 2016-12-12 22:44:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-12 22:44:02 --> Helper loaded: common_helper
DEBUG - 2016-12-12 22:44:02 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-12 22:44:02 --> Helper loaded: form_helper
DEBUG - 2016-12-12 22:44:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-12 22:44:02 --> Helper loaded: security_helper
DEBUG - 2016-12-12 22:44:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-12 22:44:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-12 22:44:02 --> Helper loaded: lang_helper
DEBUG - 2016-12-12 22:44:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-12 22:44:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-12 22:44:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-12 22:44:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-12 22:44:02 --> Helper loaded: atlant_helper
DEBUG - 2016-12-12 22:44:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-12 22:44:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-12 22:44:02 --> Helper loaded: crypto_helper
DEBUG - 2016-12-12 22:44:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-12 22:44:02 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-12 22:44:02 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-12 22:44:02 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-12 22:44:02 --> Helper loaded: sidika_helper
DEBUG - 2016-12-12 22:44:02 --> Database Driver Class Initialized
DEBUG - 2016-12-12 22:44:02 --> Session Class Initialized
DEBUG - 2016-12-12 22:44:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-12 22:44:02 --> Helper loaded: string_helper
DEBUG - 2016-12-12 22:44:02 --> Session routines successfully run
DEBUG - 2016-12-12 22:44:02 --> Native_session Class Initialized
DEBUG - 2016-12-12 22:44:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-12 22:44:02 --> Form Validation Class Initialized
DEBUG - 2016-12-12 22:44:02 --> Form Validation Class Initialized
DEBUG - 2016-12-12 22:44:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-12 22:44:02 --> Controller Class Initialized
DEBUG - 2016-12-12 22:44:02 --> Carabiner: Library initialized.
DEBUG - 2016-12-12 22:44:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-12 22:44:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-12 22:44:02 --> Carabiner: library configured.
DEBUG - 2016-12-12 22:44:02 --> Carabiner: library configured.
DEBUG - 2016-12-12 22:44:02 --> User Agent Class Initialized
DEBUG - 2016-12-12 22:44:02 --> Model Class Initialized
DEBUG - 2016-12-12 22:44:02 --> Model Class Initialized
DEBUG - 2016-12-12 22:44:02 --> Model Class Initialized
DEBUG - 2016-12-12 22:44:02 --> Model Class Initialized
DEBUG - 2016-12-12 22:44:02 --> Model Class Initialized
DEBUG - 2016-12-12 22:44:02 --> Model Class Initialized
DEBUG - 2016-12-12 22:44:02 --> Model Class Initialized
DEBUG - 2016-12-12 22:44:02 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-12-12 22:44:02 --> Final output sent to browser
DEBUG - 2016-12-12 22:44:02 --> Total execution time: 0.2289
DEBUG - 2016-12-12 22:49:55 --> Config Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Hooks Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Utf8 Class Initialized
DEBUG - 2016-12-12 22:49:55 --> UTF-8 Support Enabled
DEBUG - 2016-12-12 22:49:55 --> URI Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Router Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Output Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Cache file has expired. File deleted
DEBUG - 2016-12-12 22:49:55 --> Security Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Input Class Initialized
DEBUG - 2016-12-12 22:49:55 --> XSS Filtering completed
DEBUG - 2016-12-12 22:49:55 --> XSS Filtering completed
DEBUG - 2016-12-12 22:49:55 --> XSS Filtering completed
DEBUG - 2016-12-12 22:49:55 --> XSS Filtering completed
DEBUG - 2016-12-12 22:49:55 --> XSS Filtering completed
DEBUG - 2016-12-12 22:49:55 --> XSS Filtering completed
DEBUG - 2016-12-12 22:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-12 22:49:55 --> Language Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Loader Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-12 22:49:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-12 22:49:55 --> Helper loaded: url_helper
DEBUG - 2016-12-12 22:49:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-12 22:49:55 --> Helper loaded: file_helper
DEBUG - 2016-12-12 22:49:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-12 22:49:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-12 22:49:55 --> Helper loaded: conf_helper
DEBUG - 2016-12-12 22:49:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-12 22:49:55 --> Check Exists common_helper.php: No
DEBUG - 2016-12-12 22:49:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-12 22:49:55 --> Helper loaded: common_helper
DEBUG - 2016-12-12 22:49:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-12 22:49:55 --> Helper loaded: common_helper
DEBUG - 2016-12-12 22:49:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-12 22:49:55 --> Helper loaded: form_helper
DEBUG - 2016-12-12 22:49:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-12 22:49:55 --> Helper loaded: security_helper
DEBUG - 2016-12-12 22:49:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-12 22:49:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-12 22:49:55 --> Helper loaded: lang_helper
DEBUG - 2016-12-12 22:49:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-12 22:49:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-12 22:49:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-12 22:49:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-12 22:49:55 --> Helper loaded: atlant_helper
DEBUG - 2016-12-12 22:49:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-12 22:49:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-12 22:49:55 --> Helper loaded: crypto_helper
DEBUG - 2016-12-12 22:49:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-12 22:49:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-12 22:49:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-12 22:49:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-12 22:49:55 --> Helper loaded: sidika_helper
DEBUG - 2016-12-12 22:49:55 --> Database Driver Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Session Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-12 22:49:55 --> Helper loaded: string_helper
DEBUG - 2016-12-12 22:49:55 --> Session routines successfully run
DEBUG - 2016-12-12 22:49:55 --> Native_session Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-12 22:49:55 --> Form Validation Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Config Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Form Validation Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Hooks Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-12 22:49:55 --> Utf8 Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Controller Class Initialized
DEBUG - 2016-12-12 22:49:55 --> UTF-8 Support Enabled
DEBUG - 2016-12-12 22:49:55 --> Carabiner: Library initialized.
DEBUG - 2016-12-12 22:49:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-12 22:49:55 --> URI Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-12 22:49:55 --> Router Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Carabiner: library configured.
DEBUG - 2016-12-12 22:49:55 --> Output Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Carabiner: library configured.
DEBUG - 2016-12-12 22:49:55 --> Security Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Input Class Initialized
DEBUG - 2016-12-12 22:49:55 --> User Agent Class Initialized
DEBUG - 2016-12-12 22:49:55 --> XSS Filtering completed
DEBUG - 2016-12-12 22:49:55 --> XSS Filtering completed
DEBUG - 2016-12-12 22:49:55 --> Model Class Initialized
DEBUG - 2016-12-12 22:49:55 --> XSS Filtering completed
DEBUG - 2016-12-12 22:49:55 --> Model Class Initialized
DEBUG - 2016-12-12 22:49:55 --> XSS Filtering completed
DEBUG - 2016-12-12 22:49:55 --> Model Class Initialized
DEBUG - 2016-12-12 22:49:55 --> XSS Filtering completed
DEBUG - 2016-12-12 22:49:55 --> Model Class Initialized
DEBUG - 2016-12-12 22:49:55 --> XSS Filtering completed
DEBUG - 2016-12-12 22:49:55 --> Model Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-12 22:49:55 --> Model Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Language Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Model Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Loader Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-12 22:49:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-12 22:49:55 --> Helper loaded: url_helper
DEBUG - 2016-12-12 22:49:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-12 22:49:55 --> Helper loaded: file_helper
DEBUG - 2016-12-12 22:49:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-12 22:49:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-12 22:49:55 --> Helper loaded: conf_helper
DEBUG - 2016-12-12 22:49:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-12 22:49:55 --> Check Exists common_helper.php: No
DEBUG - 2016-12-12 22:49:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-12 22:49:55 --> Helper loaded: common_helper
DEBUG - 2016-12-12 22:49:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-12 22:49:55 --> Helper loaded: common_helper
DEBUG - 2016-12-12 22:49:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-12 22:49:55 --> Helper loaded: form_helper
DEBUG - 2016-12-12 22:49:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-12 22:49:55 --> Helper loaded: security_helper
DEBUG - 2016-12-12 22:49:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-12 22:49:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-12 22:49:55 --> Helper loaded: lang_helper
DEBUG - 2016-12-12 22:49:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-12 22:49:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-12 22:49:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-12 22:49:55 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-12-12 22:49:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-12 22:49:55 --> Final output sent to browser
DEBUG - 2016-12-12 22:49:55 --> Helper loaded: atlant_helper
DEBUG - 2016-12-12 22:49:55 --> Total execution time: 0.2940
DEBUG - 2016-12-12 22:49:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-12 22:49:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-12 22:49:55 --> Helper loaded: crypto_helper
DEBUG - 2016-12-12 22:49:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-12 22:49:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-12 22:49:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-12 22:49:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-12 22:49:55 --> Helper loaded: sidika_helper
DEBUG - 2016-12-12 22:49:55 --> Database Driver Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Session Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-12 22:49:55 --> Helper loaded: string_helper
DEBUG - 2016-12-12 22:49:55 --> Session routines successfully run
DEBUG - 2016-12-12 22:49:55 --> Native_session Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-12 22:49:55 --> Form Validation Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Form Validation Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-12 22:49:55 --> Controller Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Carabiner: Library initialized.
DEBUG - 2016-12-12 22:49:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-12 22:49:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-12 22:49:55 --> Carabiner: library configured.
DEBUG - 2016-12-12 22:49:55 --> Carabiner: library configured.
DEBUG - 2016-12-12 22:49:55 --> User Agent Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Model Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Model Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Model Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Model Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Model Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Model Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Model Class Initialized
DEBUG - 2016-12-12 22:49:55 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-12-12 22:49:55 --> Final output sent to browser
DEBUG - 2016-12-12 22:49:55 --> Total execution time: 0.2689
