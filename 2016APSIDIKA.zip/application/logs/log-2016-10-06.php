<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-10-06 13:11:38 --> Config Class Initialized
DEBUG - 2016-10-06 13:11:38 --> Hooks Class Initialized
DEBUG - 2016-10-06 13:11:38 --> Utf8 Class Initialized
DEBUG - 2016-10-06 13:11:38 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 13:11:38 --> URI Class Initialized
DEBUG - 2016-10-06 13:11:38 --> Router Class Initialized
DEBUG - 2016-10-06 13:11:38 --> No URI present. Default controller set.
DEBUG - 2016-10-06 13:11:38 --> Output Class Initialized
DEBUG - 2016-10-06 13:11:38 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 13:11:38 --> Security Class Initialized
DEBUG - 2016-10-06 13:11:38 --> Input Class Initialized
DEBUG - 2016-10-06 13:11:38 --> XSS Filtering completed
DEBUG - 2016-10-06 13:11:38 --> XSS Filtering completed
DEBUG - 2016-10-06 13:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 13:11:38 --> Language Class Initialized
DEBUG - 2016-10-06 13:11:38 --> Loader Class Initialized
DEBUG - 2016-10-06 13:11:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 13:11:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 13:11:38 --> Helper loaded: url_helper
DEBUG - 2016-10-06 13:11:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 13:11:38 --> Helper loaded: file_helper
DEBUG - 2016-10-06 13:11:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 13:11:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 13:11:38 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 13:11:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 13:11:38 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 13:11:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 13:11:38 --> Helper loaded: common_helper
DEBUG - 2016-10-06 13:11:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 13:11:38 --> Helper loaded: common_helper
DEBUG - 2016-10-06 13:11:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 13:11:38 --> Helper loaded: form_helper
DEBUG - 2016-10-06 13:11:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 13:11:38 --> Helper loaded: security_helper
DEBUG - 2016-10-06 13:11:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 13:11:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 13:11:38 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 13:11:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 13:11:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 13:11:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 13:11:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 13:11:38 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 13:11:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 13:11:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 13:11:38 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 13:11:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 13:11:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 13:11:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 13:11:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 13:11:38 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 13:11:38 --> Database Driver Class Initialized
ERROR - 2016-10-06 13:11:39 --> Severity: Warning  --> pg_connect(): Unable to connect to PostgreSQL server: could not connect to server: Connection refused (0x0000274D/10061)
	Is the server running on host &quot;127.0.0.1&quot; and accepting
	TCP/IP connections on port 5432? E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 87
ERROR - 2016-10-06 13:11:39 --> Unable to connect to the database
DEBUG - 2016-10-06 13:11:39 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-10-06 13:12:04 --> Config Class Initialized
DEBUG - 2016-10-06 13:12:04 --> Hooks Class Initialized
DEBUG - 2016-10-06 13:12:04 --> Utf8 Class Initialized
DEBUG - 2016-10-06 13:12:04 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 13:12:04 --> URI Class Initialized
DEBUG - 2016-10-06 13:12:04 --> Router Class Initialized
DEBUG - 2016-10-06 13:12:04 --> No URI present. Default controller set.
DEBUG - 2016-10-06 13:12:04 --> Output Class Initialized
DEBUG - 2016-10-06 13:12:04 --> Security Class Initialized
DEBUG - 2016-10-06 13:12:04 --> Input Class Initialized
DEBUG - 2016-10-06 13:12:04 --> XSS Filtering completed
DEBUG - 2016-10-06 13:12:04 --> XSS Filtering completed
DEBUG - 2016-10-06 13:12:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 13:12:04 --> Language Class Initialized
DEBUG - 2016-10-06 13:12:04 --> Loader Class Initialized
DEBUG - 2016-10-06 13:12:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 13:12:04 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 13:12:04 --> Helper loaded: url_helper
DEBUG - 2016-10-06 13:12:04 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 13:12:04 --> Helper loaded: file_helper
DEBUG - 2016-10-06 13:12:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 13:12:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 13:12:04 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 13:12:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 13:12:04 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 13:12:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 13:12:04 --> Helper loaded: common_helper
DEBUG - 2016-10-06 13:12:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 13:12:04 --> Helper loaded: common_helper
DEBUG - 2016-10-06 13:12:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 13:12:04 --> Helper loaded: form_helper
DEBUG - 2016-10-06 13:12:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 13:12:04 --> Helper loaded: security_helper
DEBUG - 2016-10-06 13:12:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 13:12:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 13:12:04 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 13:12:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 13:12:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 13:12:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 13:12:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 13:12:04 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 13:12:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 13:12:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 13:12:04 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 13:12:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 13:12:04 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 13:12:04 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 13:12:04 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 13:12:04 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 13:12:04 --> Database Driver Class Initialized
DEBUG - 2016-10-06 13:12:05 --> Session Class Initialized
DEBUG - 2016-10-06 13:12:05 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 13:12:05 --> Helper loaded: string_helper
DEBUG - 2016-10-06 13:12:05 --> A session cookie was not found.
DEBUG - 2016-10-06 13:12:05 --> Session routines successfully run
DEBUG - 2016-10-06 13:12:05 --> Native_session Class Initialized
DEBUG - 2016-10-06 13:12:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 13:12:05 --> Form Validation Class Initialized
DEBUG - 2016-10-06 13:12:05 --> Form Validation Class Initialized
DEBUG - 2016-10-06 13:12:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 13:12:05 --> Controller Class Initialized
DEBUG - 2016-10-06 13:12:05 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 13:12:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 13:12:05 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 13:12:05 --> Carabiner: library configured.
DEBUG - 2016-10-06 13:12:05 --> Carabiner: library configured.
DEBUG - 2016-10-06 13:12:05 --> User Agent Class Initialized
DEBUG - 2016-10-06 13:12:05 --> Model Class Initialized
DEBUG - 2016-10-06 13:12:05 --> Model Class Initialized
DEBUG - 2016-10-06 13:12:05 --> Model Class Initialized
ERROR - 2016-10-06 13:12:07 --> Hak Akses modul/kontroller 'home' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-06 13:12:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-10-06 13:12:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-10-06 13:12:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 13:12:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 13:12:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 13:12:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 13:12:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 13:12:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-06 13:12:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-06 13:12:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 13:12:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 13:12:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 13:12:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 13:12:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 13:12:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 13:12:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 13:12:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-06 13:12:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-06 13:12:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 13:12:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 13:12:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-10-06 13:12:07 --> Final output sent to browser
DEBUG - 2016-10-06 13:12:07 --> Total execution time: 2.7355
DEBUG - 2016-10-06 13:12:10 --> Config Class Initialized
DEBUG - 2016-10-06 13:12:10 --> Hooks Class Initialized
DEBUG - 2016-10-06 13:12:10 --> Utf8 Class Initialized
DEBUG - 2016-10-06 13:12:10 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 13:12:10 --> URI Class Initialized
DEBUG - 2016-10-06 13:12:10 --> Router Class Initialized
DEBUG - 2016-10-06 13:12:10 --> Output Class Initialized
DEBUG - 2016-10-06 13:12:10 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 13:12:10 --> Security Class Initialized
DEBUG - 2016-10-06 13:12:10 --> Input Class Initialized
DEBUG - 2016-10-06 13:12:10 --> XSS Filtering completed
DEBUG - 2016-10-06 13:12:10 --> XSS Filtering completed
DEBUG - 2016-10-06 13:12:10 --> XSS Filtering completed
DEBUG - 2016-10-06 13:12:10 --> XSS Filtering completed
DEBUG - 2016-10-06 13:12:10 --> XSS Filtering completed
DEBUG - 2016-10-06 13:12:10 --> XSS Filtering completed
DEBUG - 2016-10-06 13:12:10 --> XSS Filtering completed
DEBUG - 2016-10-06 13:12:10 --> XSS Filtering completed
DEBUG - 2016-10-06 13:12:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 13:12:10 --> Language Class Initialized
DEBUG - 2016-10-06 13:12:10 --> Loader Class Initialized
DEBUG - 2016-10-06 13:12:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 13:12:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 13:12:10 --> Helper loaded: url_helper
DEBUG - 2016-10-06 13:12:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 13:12:10 --> Helper loaded: file_helper
DEBUG - 2016-10-06 13:12:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 13:12:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 13:12:10 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 13:12:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 13:12:10 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 13:12:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 13:12:10 --> Helper loaded: common_helper
DEBUG - 2016-10-06 13:12:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 13:12:10 --> Helper loaded: common_helper
DEBUG - 2016-10-06 13:12:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 13:12:10 --> Helper loaded: form_helper
DEBUG - 2016-10-06 13:12:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 13:12:10 --> Helper loaded: security_helper
DEBUG - 2016-10-06 13:12:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 13:12:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 13:12:10 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 13:12:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 13:12:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 13:12:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 13:12:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 13:12:10 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 13:12:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 13:12:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 13:12:10 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 13:12:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 13:12:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 13:12:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 13:12:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 13:12:10 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 13:12:10 --> Database Driver Class Initialized
DEBUG - 2016-10-06 13:12:10 --> Session Class Initialized
DEBUG - 2016-10-06 13:12:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 13:12:10 --> Helper loaded: string_helper
DEBUG - 2016-10-06 13:12:10 --> Session routines successfully run
DEBUG - 2016-10-06 13:12:10 --> Native_session Class Initialized
DEBUG - 2016-10-06 13:12:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 13:12:10 --> Form Validation Class Initialized
DEBUG - 2016-10-06 13:12:10 --> Form Validation Class Initialized
DEBUG - 2016-10-06 13:12:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 13:12:10 --> Controller Class Initialized
DEBUG - 2016-10-06 13:12:10 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 13:12:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 13:12:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 13:12:10 --> Carabiner: library configured.
DEBUG - 2016-10-06 13:12:10 --> Carabiner: library configured.
DEBUG - 2016-10-06 13:12:10 --> User Agent Class Initialized
DEBUG - 2016-10-06 13:12:10 --> Model Class Initialized
DEBUG - 2016-10-06 13:12:10 --> Model Class Initialized
DEBUG - 2016-10-06 13:12:10 --> Model Class Initialized
DEBUG - 2016-10-06 13:12:10 --> Model Class Initialized
DEBUG - 2016-10-06 13:12:10 --> Model Class Initialized
DEBUG - 2016-10-06 13:12:10 --> Model Class Initialized
DEBUG - 2016-10-06 13:12:10 --> Model Class Initialized
DEBUG - 2016-10-06 13:12:12 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-10-06 13:12:12 --> Final output sent to browser
DEBUG - 2016-10-06 13:12:12 --> Total execution time: 1.8706
DEBUG - 2016-10-06 16:02:24 --> Config Class Initialized
DEBUG - 2016-10-06 16:02:24 --> Hooks Class Initialized
DEBUG - 2016-10-06 16:02:24 --> Utf8 Class Initialized
DEBUG - 2016-10-06 16:02:24 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 16:02:24 --> URI Class Initialized
DEBUG - 2016-10-06 16:02:24 --> Router Class Initialized
DEBUG - 2016-10-06 16:02:24 --> No URI present. Default controller set.
DEBUG - 2016-10-06 16:02:24 --> Output Class Initialized
DEBUG - 2016-10-06 16:02:24 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 16:02:24 --> Security Class Initialized
DEBUG - 2016-10-06 16:02:24 --> Input Class Initialized
DEBUG - 2016-10-06 16:02:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 16:02:24 --> Language Class Initialized
DEBUG - 2016-10-06 16:02:24 --> Loader Class Initialized
DEBUG - 2016-10-06 16:02:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 16:02:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 16:02:24 --> Helper loaded: url_helper
DEBUG - 2016-10-06 16:02:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 16:02:24 --> Helper loaded: file_helper
DEBUG - 2016-10-06 16:02:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:02:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 16:02:24 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 16:02:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:02:24 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 16:02:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 16:02:24 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:02:24 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 16:02:24 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:02:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 16:02:24 --> Helper loaded: form_helper
DEBUG - 2016-10-06 16:02:24 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 16:02:24 --> Helper loaded: security_helper
DEBUG - 2016-10-06 16:02:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:02:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 16:02:24 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 16:02:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:02:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 16:02:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 16:02:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 16:02:24 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 16:02:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:02:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 16:02:24 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 16:02:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:02:24 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 16:02:24 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 16:02:24 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 16:02:24 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 16:02:24 --> Database Driver Class Initialized
DEBUG - 2016-10-06 16:02:24 --> Session Class Initialized
DEBUG - 2016-10-06 16:02:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 16:02:24 --> Helper loaded: string_helper
DEBUG - 2016-10-06 16:02:24 --> A session cookie was not found.
DEBUG - 2016-10-06 16:02:24 --> Session routines successfully run
DEBUG - 2016-10-06 16:02:24 --> Native_session Class Initialized
DEBUG - 2016-10-06 16:02:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 16:02:24 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:02:24 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:02:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 16:02:24 --> Controller Class Initialized
DEBUG - 2016-10-06 16:02:24 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 16:02:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 16:02:24 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 16:02:24 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:02:24 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:02:24 --> User Agent Class Initialized
DEBUG - 2016-10-06 16:02:24 --> Model Class Initialized
DEBUG - 2016-10-06 16:02:24 --> Model Class Initialized
DEBUG - 2016-10-06 16:02:24 --> Model Class Initialized
ERROR - 2016-10-06 16:02:24 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-10-06 16:02:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-10-06 16:02:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-10-06 16:02:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 16:02:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 16:02:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 16:02:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 16:02:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 16:02:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-06 16:02:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-06 16:02:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 16:02:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 16:02:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 16:02:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 16:02:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 16:02:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 16:02:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 16:02:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-06 16:02:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-06 16:02:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 16:02:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 16:02:24 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-10-06 16:02:24 --> Final output sent to browser
DEBUG - 2016-10-06 16:02:24 --> Total execution time: 0.2056
DEBUG - 2016-10-06 16:02:37 --> Config Class Initialized
DEBUG - 2016-10-06 16:02:37 --> Hooks Class Initialized
DEBUG - 2016-10-06 16:02:37 --> Utf8 Class Initialized
DEBUG - 2016-10-06 16:02:37 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 16:02:37 --> URI Class Initialized
DEBUG - 2016-10-06 16:02:37 --> Router Class Initialized
DEBUG - 2016-10-06 16:02:37 --> Output Class Initialized
DEBUG - 2016-10-06 16:02:37 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 16:02:37 --> Security Class Initialized
DEBUG - 2016-10-06 16:02:37 --> Input Class Initialized
DEBUG - 2016-10-06 16:02:37 --> XSS Filtering completed
DEBUG - 2016-10-06 16:02:37 --> XSS Filtering completed
DEBUG - 2016-10-06 16:02:37 --> XSS Filtering completed
DEBUG - 2016-10-06 16:02:37 --> XSS Filtering completed
DEBUG - 2016-10-06 16:02:37 --> XSS Filtering completed
DEBUG - 2016-10-06 16:02:37 --> XSS Filtering completed
DEBUG - 2016-10-06 16:02:37 --> XSS Filtering completed
DEBUG - 2016-10-06 16:02:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 16:02:37 --> Language Class Initialized
DEBUG - 2016-10-06 16:02:37 --> Loader Class Initialized
DEBUG - 2016-10-06 16:02:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 16:02:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 16:02:37 --> Helper loaded: url_helper
DEBUG - 2016-10-06 16:02:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 16:02:37 --> Helper loaded: file_helper
DEBUG - 2016-10-06 16:02:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:02:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 16:02:37 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 16:02:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:02:37 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 16:02:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 16:02:37 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:02:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 16:02:37 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:02:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 16:02:37 --> Helper loaded: form_helper
DEBUG - 2016-10-06 16:02:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 16:02:37 --> Helper loaded: security_helper
DEBUG - 2016-10-06 16:02:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:02:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 16:02:37 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 16:02:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:02:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 16:02:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 16:02:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 16:02:37 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 16:02:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:02:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 16:02:37 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 16:02:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:02:37 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 16:02:37 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 16:02:37 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 16:02:37 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 16:02:37 --> Database Driver Class Initialized
DEBUG - 2016-10-06 16:02:37 --> Session Class Initialized
DEBUG - 2016-10-06 16:02:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 16:02:37 --> Helper loaded: string_helper
DEBUG - 2016-10-06 16:02:37 --> Session routines successfully run
DEBUG - 2016-10-06 16:02:37 --> Native_session Class Initialized
DEBUG - 2016-10-06 16:02:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 16:02:37 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:02:37 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:02:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 16:02:37 --> Controller Class Initialized
DEBUG - 2016-10-06 16:02:37 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 16:02:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 16:02:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 16:02:37 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:02:37 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:02:37 --> User Agent Class Initialized
DEBUG - 2016-10-06 16:02:37 --> Model Class Initialized
DEBUG - 2016-10-06 16:02:37 --> Model Class Initialized
DEBUG - 2016-10-06 16:02:37 --> Model Class Initialized
DEBUG - 2016-10-06 16:02:37 --> Model Class Initialized
DEBUG - 2016-10-06 16:02:37 --> Model Class Initialized
DEBUG - 2016-10-06 16:02:37 --> Model Class Initialized
DEBUG - 2016-10-06 16:02:37 --> Model Class Initialized
DEBUG - 2016-10-06 16:02:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-10-06 16:02:37 --> Final output sent to browser
DEBUG - 2016-10-06 16:02:37 --> Total execution time: 0.2696
DEBUG - 2016-10-06 16:02:43 --> Config Class Initialized
DEBUG - 2016-10-06 16:02:43 --> Hooks Class Initialized
DEBUG - 2016-10-06 16:02:43 --> Utf8 Class Initialized
DEBUG - 2016-10-06 16:02:43 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 16:02:43 --> URI Class Initialized
DEBUG - 2016-10-06 16:02:43 --> Router Class Initialized
DEBUG - 2016-10-06 16:02:43 --> Output Class Initialized
DEBUG - 2016-10-06 16:02:43 --> Security Class Initialized
DEBUG - 2016-10-06 16:02:43 --> Input Class Initialized
DEBUG - 2016-10-06 16:02:43 --> XSS Filtering completed
DEBUG - 2016-10-06 16:02:43 --> XSS Filtering completed
DEBUG - 2016-10-06 16:02:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 16:02:43 --> Language Class Initialized
DEBUG - 2016-10-06 16:02:43 --> Loader Class Initialized
DEBUG - 2016-10-06 16:02:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 16:02:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 16:02:43 --> Helper loaded: url_helper
DEBUG - 2016-10-06 16:02:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 16:02:43 --> Helper loaded: file_helper
DEBUG - 2016-10-06 16:02:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:02:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 16:02:43 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 16:02:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:02:43 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 16:02:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 16:02:43 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:02:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 16:02:43 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:02:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 16:02:43 --> Helper loaded: form_helper
DEBUG - 2016-10-06 16:02:43 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 16:02:43 --> Helper loaded: security_helper
DEBUG - 2016-10-06 16:02:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:02:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 16:02:43 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 16:02:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:02:43 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 16:02:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 16:02:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 16:02:43 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 16:02:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:02:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 16:02:43 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 16:02:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:02:43 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 16:02:43 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 16:02:43 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 16:02:43 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 16:02:43 --> Database Driver Class Initialized
DEBUG - 2016-10-06 16:02:43 --> Session Class Initialized
DEBUG - 2016-10-06 16:02:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 16:02:43 --> Helper loaded: string_helper
DEBUG - 2016-10-06 16:02:43 --> Session routines successfully run
DEBUG - 2016-10-06 16:02:43 --> Native_session Class Initialized
DEBUG - 2016-10-06 16:02:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 16:02:43 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:02:43 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:02:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 16:02:43 --> Controller Class Initialized
DEBUG - 2016-10-06 16:02:43 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 16:02:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 16:02:43 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 16:02:43 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:02:43 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:02:43 --> User Agent Class Initialized
DEBUG - 2016-10-06 16:02:43 --> Model Class Initialized
DEBUG - 2016-10-06 16:02:43 --> Model Class Initialized
DEBUG - 2016-10-06 16:02:43 --> Model Class Initialized
ERROR - 2016-10-06 16:02:43 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-10-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-10-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 16:02:43 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-10-06 16:02:43 --> Final output sent to browser
DEBUG - 2016-10-06 16:02:43 --> Total execution time: 0.2419
DEBUG - 2016-10-06 16:03:16 --> Config Class Initialized
DEBUG - 2016-10-06 16:03:16 --> Hooks Class Initialized
DEBUG - 2016-10-06 16:03:16 --> Utf8 Class Initialized
DEBUG - 2016-10-06 16:03:16 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 16:03:16 --> URI Class Initialized
DEBUG - 2016-10-06 16:03:16 --> Router Class Initialized
DEBUG - 2016-10-06 16:03:16 --> Output Class Initialized
DEBUG - 2016-10-06 16:03:16 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 16:03:16 --> Security Class Initialized
DEBUG - 2016-10-06 16:03:16 --> Input Class Initialized
DEBUG - 2016-10-06 16:03:16 --> XSS Filtering completed
DEBUG - 2016-10-06 16:03:16 --> XSS Filtering completed
DEBUG - 2016-10-06 16:03:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 16:03:16 --> Language Class Initialized
DEBUG - 2016-10-06 16:03:16 --> Loader Class Initialized
DEBUG - 2016-10-06 16:03:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 16:03:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 16:03:16 --> Helper loaded: url_helper
DEBUG - 2016-10-06 16:03:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 16:03:16 --> Helper loaded: file_helper
DEBUG - 2016-10-06 16:03:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:03:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 16:03:16 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 16:03:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:03:16 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 16:03:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 16:03:16 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:03:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 16:03:16 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:03:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 16:03:16 --> Helper loaded: form_helper
DEBUG - 2016-10-06 16:03:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 16:03:16 --> Helper loaded: security_helper
DEBUG - 2016-10-06 16:03:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:03:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 16:03:16 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 16:03:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:03:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 16:03:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 16:03:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 16:03:16 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 16:03:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:03:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 16:03:16 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 16:03:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:03:16 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 16:03:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 16:03:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 16:03:16 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 16:03:16 --> Database Driver Class Initialized
DEBUG - 2016-10-06 16:03:16 --> Session Class Initialized
DEBUG - 2016-10-06 16:03:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 16:03:16 --> Helper loaded: string_helper
DEBUG - 2016-10-06 16:03:16 --> Session routines successfully run
DEBUG - 2016-10-06 16:03:16 --> Native_session Class Initialized
DEBUG - 2016-10-06 16:03:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 16:03:16 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:03:16 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:03:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 16:03:16 --> Controller Class Initialized
DEBUG - 2016-10-06 16:03:16 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 16:03:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 16:03:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 16:03:16 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:03:16 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:03:16 --> User Agent Class Initialized
DEBUG - 2016-10-06 16:03:16 --> Model Class Initialized
DEBUG - 2016-10-06 16:03:16 --> Model Class Initialized
DEBUG - 2016-10-06 16:03:16 --> Model Class Initialized
DEBUG - 2016-10-06 16:03:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-10-06 16:03:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-06 16:03:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-06 16:03:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 16:03:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-06 16:03:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 16:03:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-06 16:03:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-06 16:03:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-06 16:03:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 16:03:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-06 16:03:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 16:03:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-06 16:03:16 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-10-06 16:03:16 --> Final output sent to browser
DEBUG - 2016-10-06 16:03:16 --> Total execution time: 0.2847
DEBUG - 2016-10-06 16:03:30 --> Config Class Initialized
DEBUG - 2016-10-06 16:03:30 --> Hooks Class Initialized
DEBUG - 2016-10-06 16:03:30 --> Utf8 Class Initialized
DEBUG - 2016-10-06 16:03:30 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 16:03:30 --> URI Class Initialized
DEBUG - 2016-10-06 16:03:30 --> Router Class Initialized
DEBUG - 2016-10-06 16:03:30 --> Output Class Initialized
DEBUG - 2016-10-06 16:03:30 --> Security Class Initialized
DEBUG - 2016-10-06 16:03:30 --> Input Class Initialized
DEBUG - 2016-10-06 16:03:30 --> XSS Filtering completed
DEBUG - 2016-10-06 16:03:30 --> XSS Filtering completed
DEBUG - 2016-10-06 16:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 16:03:30 --> Language Class Initialized
DEBUG - 2016-10-06 16:03:30 --> Loader Class Initialized
DEBUG - 2016-10-06 16:03:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 16:03:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 16:03:30 --> Helper loaded: url_helper
DEBUG - 2016-10-06 16:03:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 16:03:30 --> Helper loaded: file_helper
DEBUG - 2016-10-06 16:03:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:03:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 16:03:30 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 16:03:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:03:30 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 16:03:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 16:03:30 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:03:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 16:03:30 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:03:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 16:03:30 --> Helper loaded: form_helper
DEBUG - 2016-10-06 16:03:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 16:03:30 --> Helper loaded: security_helper
DEBUG - 2016-10-06 16:03:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:03:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 16:03:30 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 16:03:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:03:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 16:03:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 16:03:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 16:03:30 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 16:03:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:03:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 16:03:30 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 16:03:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:03:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 16:03:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 16:03:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 16:03:30 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 16:03:30 --> Database Driver Class Initialized
DEBUG - 2016-10-06 16:03:30 --> Session Class Initialized
DEBUG - 2016-10-06 16:03:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 16:03:30 --> Helper loaded: string_helper
DEBUG - 2016-10-06 16:03:30 --> Session routines successfully run
DEBUG - 2016-10-06 16:03:30 --> Native_session Class Initialized
DEBUG - 2016-10-06 16:03:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 16:03:30 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:03:30 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:03:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 16:03:30 --> Controller Class Initialized
DEBUG - 2016-10-06 16:03:30 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 16:03:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 16:03:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 16:03:30 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:03:30 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:03:30 --> User Agent Class Initialized
DEBUG - 2016-10-06 16:03:30 --> Model Class Initialized
DEBUG - 2016-10-06 16:03:30 --> Model Class Initialized
DEBUG - 2016-10-06 16:03:30 --> Model Class Initialized
DEBUG - 2016-10-06 16:03:30 --> Model Class Initialized
DEBUG - 2016-10-06 16:03:30 --> Model Class Initialized
DEBUG - 2016-10-06 16:03:30 --> Model Class Initialized
DEBUG - 2016-10-06 16:03:30 --> Model Class Initialized
DEBUG - 2016-10-06 16:03:30 --> Model Class Initialized
ERROR - 2016-10-06 16:03:30 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-10-06 16:03:30 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-06 16:03:30 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-10-06 16:03:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-10-06 16:03:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-10-06 16:03:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-10-06 16:03:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-10-06 16:03:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-10-06 16:03:30 --> Final output sent to browser
DEBUG - 2016-10-06 16:03:30 --> Total execution time: 0.3034
DEBUG - 2016-10-06 16:04:25 --> Config Class Initialized
DEBUG - 2016-10-06 16:04:25 --> Hooks Class Initialized
DEBUG - 2016-10-06 16:04:25 --> Utf8 Class Initialized
DEBUG - 2016-10-06 16:04:25 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 16:04:25 --> URI Class Initialized
DEBUG - 2016-10-06 16:04:25 --> Router Class Initialized
ERROR - 2016-10-06 16:04:25 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-10-06 16:04:31 --> Config Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Hooks Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Utf8 Class Initialized
DEBUG - 2016-10-06 16:04:31 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 16:04:31 --> URI Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Router Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Output Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 16:04:31 --> Security Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Input Class Initialized
DEBUG - 2016-10-06 16:04:31 --> XSS Filtering completed
DEBUG - 2016-10-06 16:04:31 --> XSS Filtering completed
DEBUG - 2016-10-06 16:04:31 --> XSS Filtering completed
DEBUG - 2016-10-06 16:04:31 --> XSS Filtering completed
DEBUG - 2016-10-06 16:04:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 16:04:31 --> Language Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Loader Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 16:04:31 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 16:04:31 --> Helper loaded: url_helper
DEBUG - 2016-10-06 16:04:31 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 16:04:31 --> Helper loaded: file_helper
DEBUG - 2016-10-06 16:04:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:04:31 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 16:04:31 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 16:04:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:04:31 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 16:04:31 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 16:04:31 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:04:31 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 16:04:31 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:04:31 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 16:04:31 --> Helper loaded: form_helper
DEBUG - 2016-10-06 16:04:31 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 16:04:31 --> Helper loaded: security_helper
DEBUG - 2016-10-06 16:04:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:04:31 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 16:04:31 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 16:04:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:04:31 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 16:04:31 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 16:04:31 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 16:04:31 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 16:04:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:04:31 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 16:04:31 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 16:04:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:04:31 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 16:04:31 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 16:04:31 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 16:04:31 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 16:04:31 --> Database Driver Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Session Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 16:04:31 --> Helper loaded: string_helper
DEBUG - 2016-10-06 16:04:31 --> Session routines successfully run
DEBUG - 2016-10-06 16:04:31 --> Native_session Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 16:04:31 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 16:04:31 --> Controller Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 16:04:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 16:04:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 16:04:31 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:04:31 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:04:31 --> User Agent Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Model Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Model Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Model Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Model Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Model Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Model Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Model Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Model Class Initialized
ERROR - 2016-10-06 16:04:31 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-10-06 16:04:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-10-06 16:04:31 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 16:04:31 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-10-06 16:04:31 --> Config Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Hooks Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Utf8 Class Initialized
DEBUG - 2016-10-06 16:04:31 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 16:04:31 --> URI Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Router Class Initialized
DEBUG - 2016-10-06 16:04:31 --> No URI present. Default controller set.
DEBUG - 2016-10-06 16:04:31 --> Output Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 16:04:31 --> Security Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Input Class Initialized
DEBUG - 2016-10-06 16:04:31 --> XSS Filtering completed
DEBUG - 2016-10-06 16:04:31 --> XSS Filtering completed
DEBUG - 2016-10-06 16:04:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 16:04:31 --> Language Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Loader Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 16:04:31 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 16:04:31 --> Helper loaded: url_helper
DEBUG - 2016-10-06 16:04:31 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 16:04:31 --> Helper loaded: file_helper
DEBUG - 2016-10-06 16:04:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:04:31 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 16:04:31 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 16:04:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:04:31 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 16:04:31 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 16:04:31 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:04:31 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 16:04:31 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:04:31 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 16:04:31 --> Helper loaded: form_helper
DEBUG - 2016-10-06 16:04:31 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 16:04:31 --> Helper loaded: security_helper
DEBUG - 2016-10-06 16:04:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:04:31 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 16:04:31 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 16:04:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:04:31 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 16:04:31 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 16:04:31 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 16:04:31 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 16:04:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:04:31 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 16:04:31 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 16:04:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:04:31 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 16:04:31 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 16:04:31 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 16:04:31 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 16:04:31 --> Database Driver Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Session Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 16:04:31 --> Helper loaded: string_helper
DEBUG - 2016-10-06 16:04:31 --> Session routines successfully run
DEBUG - 2016-10-06 16:04:31 --> Native_session Class Initialized
DEBUG - 2016-10-06 16:04:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 16:04:32 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:04:32 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:04:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 16:04:32 --> Controller Class Initialized
DEBUG - 2016-10-06 16:04:32 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 16:04:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 16:04:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 16:04:32 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:04:32 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:04:32 --> User Agent Class Initialized
DEBUG - 2016-10-06 16:04:32 --> Model Class Initialized
DEBUG - 2016-10-06 16:04:32 --> Model Class Initialized
DEBUG - 2016-10-06 16:04:32 --> Model Class Initialized
ERROR - 2016-10-06 16:04:32 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-10-06 16:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-10-06 16:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-10-06 16:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 16:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 16:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 16:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 16:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 16:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-06 16:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-06 16:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 16:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 16:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 16:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 16:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 16:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 16:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 16:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-06 16:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-06 16:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 16:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 16:04:32 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-10-06 16:04:32 --> Final output sent to browser
DEBUG - 2016-10-06 16:04:32 --> Total execution time: 0.3171
DEBUG - 2016-10-06 16:05:21 --> Config Class Initialized
DEBUG - 2016-10-06 16:05:21 --> Hooks Class Initialized
DEBUG - 2016-10-06 16:05:21 --> Utf8 Class Initialized
DEBUG - 2016-10-06 16:05:21 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 16:05:21 --> URI Class Initialized
DEBUG - 2016-10-06 16:05:21 --> Router Class Initialized
DEBUG - 2016-10-06 16:05:21 --> Output Class Initialized
DEBUG - 2016-10-06 16:05:21 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 16:05:21 --> Security Class Initialized
DEBUG - 2016-10-06 16:05:21 --> Input Class Initialized
DEBUG - 2016-10-06 16:05:21 --> XSS Filtering completed
DEBUG - 2016-10-06 16:05:21 --> XSS Filtering completed
DEBUG - 2016-10-06 16:05:21 --> XSS Filtering completed
DEBUG - 2016-10-06 16:05:21 --> XSS Filtering completed
DEBUG - 2016-10-06 16:05:21 --> XSS Filtering completed
DEBUG - 2016-10-06 16:05:21 --> XSS Filtering completed
DEBUG - 2016-10-06 16:05:21 --> XSS Filtering completed
DEBUG - 2016-10-06 16:05:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 16:05:21 --> Language Class Initialized
DEBUG - 2016-10-06 16:05:21 --> Loader Class Initialized
DEBUG - 2016-10-06 16:05:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 16:05:21 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 16:05:21 --> Helper loaded: url_helper
DEBUG - 2016-10-06 16:05:21 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 16:05:21 --> Helper loaded: file_helper
DEBUG - 2016-10-06 16:05:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:05:21 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 16:05:21 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 16:05:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:05:21 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 16:05:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 16:05:21 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:05:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 16:05:21 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:05:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 16:05:21 --> Helper loaded: form_helper
DEBUG - 2016-10-06 16:05:21 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 16:05:21 --> Helper loaded: security_helper
DEBUG - 2016-10-06 16:05:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:05:21 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 16:05:21 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 16:05:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:05:21 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 16:05:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 16:05:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 16:05:21 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 16:05:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:05:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 16:05:21 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 16:05:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:05:21 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 16:05:21 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 16:05:21 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 16:05:21 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 16:05:21 --> Database Driver Class Initialized
DEBUG - 2016-10-06 16:05:21 --> Session Class Initialized
DEBUG - 2016-10-06 16:05:21 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 16:05:21 --> Helper loaded: string_helper
DEBUG - 2016-10-06 16:05:21 --> Session routines successfully run
DEBUG - 2016-10-06 16:05:21 --> Native_session Class Initialized
DEBUG - 2016-10-06 16:05:21 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 16:05:21 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:05:21 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:05:21 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 16:05:21 --> Controller Class Initialized
DEBUG - 2016-10-06 16:05:21 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 16:05:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 16:05:21 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 16:05:21 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:05:21 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:05:21 --> User Agent Class Initialized
DEBUG - 2016-10-06 16:05:21 --> Model Class Initialized
DEBUG - 2016-10-06 16:05:21 --> Model Class Initialized
DEBUG - 2016-10-06 16:05:21 --> Model Class Initialized
DEBUG - 2016-10-06 16:05:21 --> Model Class Initialized
DEBUG - 2016-10-06 16:05:21 --> Model Class Initialized
DEBUG - 2016-10-06 16:05:21 --> Model Class Initialized
DEBUG - 2016-10-06 16:05:21 --> Model Class Initialized
DEBUG - 2016-10-06 16:05:21 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-10-06 16:05:21 --> Final output sent to browser
DEBUG - 2016-10-06 16:05:21 --> Total execution time: 0.3918
DEBUG - 2016-10-06 16:07:06 --> Config Class Initialized
DEBUG - 2016-10-06 16:07:06 --> Hooks Class Initialized
DEBUG - 2016-10-06 16:07:06 --> Utf8 Class Initialized
DEBUG - 2016-10-06 16:07:06 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 16:07:06 --> URI Class Initialized
DEBUG - 2016-10-06 16:07:06 --> Router Class Initialized
DEBUG - 2016-10-06 16:07:06 --> Output Class Initialized
DEBUG - 2016-10-06 16:07:06 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 16:07:06 --> Security Class Initialized
DEBUG - 2016-10-06 16:07:06 --> Input Class Initialized
DEBUG - 2016-10-06 16:07:06 --> XSS Filtering completed
DEBUG - 2016-10-06 16:07:06 --> XSS Filtering completed
DEBUG - 2016-10-06 16:07:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 16:07:06 --> Language Class Initialized
DEBUG - 2016-10-06 16:07:06 --> Loader Class Initialized
DEBUG - 2016-10-06 16:07:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 16:07:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 16:07:06 --> Helper loaded: url_helper
DEBUG - 2016-10-06 16:07:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 16:07:06 --> Helper loaded: file_helper
DEBUG - 2016-10-06 16:07:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:07:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 16:07:06 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 16:07:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:07:06 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 16:07:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 16:07:06 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:07:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 16:07:06 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:07:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 16:07:06 --> Helper loaded: form_helper
DEBUG - 2016-10-06 16:07:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 16:07:06 --> Helper loaded: security_helper
DEBUG - 2016-10-06 16:07:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:07:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 16:07:06 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 16:07:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:07:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 16:07:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 16:07:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 16:07:06 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 16:07:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:07:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 16:07:06 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 16:07:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:07:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 16:07:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 16:07:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 16:07:06 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 16:07:06 --> Database Driver Class Initialized
DEBUG - 2016-10-06 16:07:06 --> Session Class Initialized
DEBUG - 2016-10-06 16:07:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 16:07:06 --> Helper loaded: string_helper
DEBUG - 2016-10-06 16:07:06 --> Session routines successfully run
DEBUG - 2016-10-06 16:07:06 --> Native_session Class Initialized
DEBUG - 2016-10-06 16:07:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 16:07:06 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:07:06 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:07:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 16:07:06 --> Controller Class Initialized
DEBUG - 2016-10-06 16:07:06 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 16:07:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 16:07:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 16:07:06 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:07:06 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:07:06 --> User Agent Class Initialized
DEBUG - 2016-10-06 16:07:06 --> Model Class Initialized
DEBUG - 2016-10-06 16:07:06 --> Model Class Initialized
DEBUG - 2016-10-06 16:07:07 --> Model Class Initialized
DEBUG - 2016-10-06 16:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-10-06 16:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-06 16:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-06 16:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 16:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-06 16:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 16:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-06 16:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-06 16:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-06 16:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 16:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-06 16:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 16:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-06 16:07:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-10-06 16:07:07 --> Final output sent to browser
DEBUG - 2016-10-06 16:07:07 --> Total execution time: 0.3450
DEBUG - 2016-10-06 16:07:31 --> Config Class Initialized
DEBUG - 2016-10-06 16:07:31 --> Hooks Class Initialized
DEBUG - 2016-10-06 16:07:31 --> Utf8 Class Initialized
DEBUG - 2016-10-06 16:07:31 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 16:07:31 --> URI Class Initialized
DEBUG - 2016-10-06 16:07:31 --> Router Class Initialized
DEBUG - 2016-10-06 16:07:31 --> Output Class Initialized
DEBUG - 2016-10-06 16:07:31 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 16:07:31 --> Security Class Initialized
DEBUG - 2016-10-06 16:07:31 --> Input Class Initialized
DEBUG - 2016-10-06 16:07:31 --> XSS Filtering completed
DEBUG - 2016-10-06 16:07:31 --> XSS Filtering completed
DEBUG - 2016-10-06 16:07:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 16:07:31 --> Language Class Initialized
DEBUG - 2016-10-06 16:07:31 --> Loader Class Initialized
DEBUG - 2016-10-06 16:07:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 16:07:31 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 16:07:31 --> Helper loaded: url_helper
DEBUG - 2016-10-06 16:07:31 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 16:07:31 --> Helper loaded: file_helper
DEBUG - 2016-10-06 16:07:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:07:31 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 16:07:31 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 16:07:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:07:31 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 16:07:31 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 16:07:31 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:07:31 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 16:07:31 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:07:31 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 16:07:31 --> Helper loaded: form_helper
DEBUG - 2016-10-06 16:07:31 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 16:07:31 --> Helper loaded: security_helper
DEBUG - 2016-10-06 16:07:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:07:31 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 16:07:31 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 16:07:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:07:31 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 16:07:31 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 16:07:31 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 16:07:31 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 16:07:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:07:31 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 16:07:31 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 16:07:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:07:31 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 16:07:31 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 16:07:31 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 16:07:31 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 16:07:31 --> Database Driver Class Initialized
DEBUG - 2016-10-06 16:07:31 --> Session Class Initialized
DEBUG - 2016-10-06 16:07:31 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 16:07:31 --> Helper loaded: string_helper
DEBUG - 2016-10-06 16:07:31 --> Session routines successfully run
DEBUG - 2016-10-06 16:07:31 --> Native_session Class Initialized
DEBUG - 2016-10-06 16:07:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 16:07:31 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:07:31 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:07:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 16:07:31 --> Controller Class Initialized
DEBUG - 2016-10-06 16:07:31 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 16:07:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 16:07:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 16:07:31 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:07:31 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:07:31 --> User Agent Class Initialized
DEBUG - 2016-10-06 16:07:31 --> Model Class Initialized
DEBUG - 2016-10-06 16:07:31 --> Model Class Initialized
DEBUG - 2016-10-06 16:07:31 --> Model Class Initialized
DEBUG - 2016-10-06 16:07:31 --> Model Class Initialized
DEBUG - 2016-10-06 16:07:31 --> Model Class Initialized
DEBUG - 2016-10-06 16:07:31 --> Model Class Initialized
DEBUG - 2016-10-06 16:07:31 --> Model Class Initialized
DEBUG - 2016-10-06 16:07:31 --> Model Class Initialized
DEBUG - 2016-10-06 16:07:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-06 16:07:32 --> Pagination Class Initialized
DEBUG - 2016-10-06 16:07:32 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-06 16:07:32 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/index.php
DEBUG - 2016-10-06 16:07:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-06 16:07:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-06 16:07:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 16:07:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-06 16:07:32 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-06 16:07:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 16:07:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-06 16:07:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-06 16:07:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-06 16:07:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 16:07:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-06 16:07:32 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-06 16:07:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 16:07:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-06 16:07:32 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55961f1d1ca16fdfc4239ae1901a174e
DEBUG - 2016-10-06 16:07:32 --> Final output sent to browser
DEBUG - 2016-10-06 16:07:32 --> Total execution time: 0.5206
DEBUG - 2016-10-06 16:08:01 --> Config Class Initialized
DEBUG - 2016-10-06 16:08:01 --> Hooks Class Initialized
DEBUG - 2016-10-06 16:08:01 --> Utf8 Class Initialized
DEBUG - 2016-10-06 16:08:01 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 16:08:01 --> URI Class Initialized
DEBUG - 2016-10-06 16:08:01 --> Router Class Initialized
DEBUG - 2016-10-06 16:08:01 --> Output Class Initialized
DEBUG - 2016-10-06 16:08:01 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 16:08:01 --> Security Class Initialized
DEBUG - 2016-10-06 16:08:01 --> Input Class Initialized
DEBUG - 2016-10-06 16:08:01 --> XSS Filtering completed
DEBUG - 2016-10-06 16:08:01 --> XSS Filtering completed
DEBUG - 2016-10-06 16:08:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 16:08:01 --> Language Class Initialized
DEBUG - 2016-10-06 16:08:01 --> Loader Class Initialized
DEBUG - 2016-10-06 16:08:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 16:08:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 16:08:01 --> Helper loaded: url_helper
DEBUG - 2016-10-06 16:08:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 16:08:01 --> Helper loaded: file_helper
DEBUG - 2016-10-06 16:08:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:08:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 16:08:01 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 16:08:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:08:01 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 16:08:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 16:08:01 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:08:01 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 16:08:01 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:08:01 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 16:08:01 --> Helper loaded: form_helper
DEBUG - 2016-10-06 16:08:01 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 16:08:01 --> Helper loaded: security_helper
DEBUG - 2016-10-06 16:08:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:08:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 16:08:01 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 16:08:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:08:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 16:08:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 16:08:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 16:08:01 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 16:08:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:08:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 16:08:01 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 16:08:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:08:01 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 16:08:01 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 16:08:01 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 16:08:01 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 16:08:01 --> Database Driver Class Initialized
DEBUG - 2016-10-06 16:08:01 --> Session Class Initialized
DEBUG - 2016-10-06 16:08:01 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 16:08:01 --> Helper loaded: string_helper
DEBUG - 2016-10-06 16:08:01 --> Session routines successfully run
DEBUG - 2016-10-06 16:08:01 --> Native_session Class Initialized
DEBUG - 2016-10-06 16:08:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 16:08:01 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:08:01 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:08:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 16:08:01 --> Controller Class Initialized
DEBUG - 2016-10-06 16:08:01 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 16:08:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 16:08:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 16:08:01 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:08:01 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:08:01 --> User Agent Class Initialized
DEBUG - 2016-10-06 16:08:01 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:01 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:01 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:01 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:01 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:01 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:01 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:01 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-06 16:08:01 --> Pagination Class Initialized
DEBUG - 2016-10-06 16:08:01 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-06 16:08:01 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/index.php
DEBUG - 2016-10-06 16:08:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-06 16:08:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-06 16:08:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 16:08:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-06 16:08:01 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-06 16:08:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 16:08:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-06 16:08:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-06 16:08:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-06 16:08:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 16:08:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-06 16:08:02 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-06 16:08:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 16:08:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-06 16:08:02 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55961f1d1ca16fdfc4239ae1901a174e
DEBUG - 2016-10-06 16:08:02 --> Final output sent to browser
DEBUG - 2016-10-06 16:08:02 --> Total execution time: 0.4452
DEBUG - 2016-10-06 16:08:14 --> Config Class Initialized
DEBUG - 2016-10-06 16:08:14 --> Hooks Class Initialized
DEBUG - 2016-10-06 16:08:14 --> Utf8 Class Initialized
DEBUG - 2016-10-06 16:08:14 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 16:08:14 --> URI Class Initialized
DEBUG - 2016-10-06 16:08:14 --> Router Class Initialized
DEBUG - 2016-10-06 16:08:14 --> Output Class Initialized
DEBUG - 2016-10-06 16:08:14 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 16:08:14 --> Security Class Initialized
DEBUG - 2016-10-06 16:08:14 --> Input Class Initialized
DEBUG - 2016-10-06 16:08:14 --> XSS Filtering completed
DEBUG - 2016-10-06 16:08:14 --> XSS Filtering completed
DEBUG - 2016-10-06 16:08:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 16:08:14 --> Language Class Initialized
DEBUG - 2016-10-06 16:08:14 --> Loader Class Initialized
DEBUG - 2016-10-06 16:08:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 16:08:14 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 16:08:14 --> Helper loaded: url_helper
DEBUG - 2016-10-06 16:08:14 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 16:08:14 --> Helper loaded: file_helper
DEBUG - 2016-10-06 16:08:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:08:14 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 16:08:14 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 16:08:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:08:14 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 16:08:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 16:08:14 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:08:14 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 16:08:14 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:08:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 16:08:14 --> Helper loaded: form_helper
DEBUG - 2016-10-06 16:08:14 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 16:08:14 --> Helper loaded: security_helper
DEBUG - 2016-10-06 16:08:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:08:14 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 16:08:14 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 16:08:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:08:14 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 16:08:14 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 16:08:14 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 16:08:14 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 16:08:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:08:14 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 16:08:14 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 16:08:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:08:14 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 16:08:14 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 16:08:14 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 16:08:14 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 16:08:14 --> Database Driver Class Initialized
DEBUG - 2016-10-06 16:08:14 --> Session Class Initialized
DEBUG - 2016-10-06 16:08:14 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 16:08:14 --> Helper loaded: string_helper
DEBUG - 2016-10-06 16:08:14 --> Session routines successfully run
DEBUG - 2016-10-06 16:08:14 --> Native_session Class Initialized
DEBUG - 2016-10-06 16:08:14 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 16:08:14 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:08:14 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:08:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 16:08:14 --> Controller Class Initialized
DEBUG - 2016-10-06 16:08:14 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 16:08:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 16:08:14 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 16:08:14 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:08:14 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:08:14 --> User Agent Class Initialized
DEBUG - 2016-10-06 16:08:14 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:14 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:14 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:14 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:14 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-06 16:08:14 --> Pagination Class Initialized
DEBUG - 2016-10-06 16:08:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-10-06 16:08:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/index.php
DEBUG - 2016-10-06 16:08:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-06 16:08:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-06 16:08:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 16:08:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-06 16:08:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-10-06 16:08:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 16:08:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-06 16:08:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-06 16:08:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-06 16:08:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 16:08:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-06 16:08:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-10-06 16:08:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 16:08:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-06 16:08:14 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c2a3e0401bd35d4fcac4bae5f9412231
DEBUG - 2016-10-06 16:08:14 --> Final output sent to browser
DEBUG - 2016-10-06 16:08:14 --> Total execution time: 0.4887
DEBUG - 2016-10-06 16:08:36 --> Config Class Initialized
DEBUG - 2016-10-06 16:08:36 --> Hooks Class Initialized
DEBUG - 2016-10-06 16:08:36 --> Utf8 Class Initialized
DEBUG - 2016-10-06 16:08:36 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 16:08:36 --> URI Class Initialized
DEBUG - 2016-10-06 16:08:36 --> Router Class Initialized
DEBUG - 2016-10-06 16:08:36 --> Output Class Initialized
DEBUG - 2016-10-06 16:08:36 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 16:08:36 --> Security Class Initialized
DEBUG - 2016-10-06 16:08:36 --> Input Class Initialized
DEBUG - 2016-10-06 16:08:36 --> XSS Filtering completed
DEBUG - 2016-10-06 16:08:36 --> XSS Filtering completed
DEBUG - 2016-10-06 16:08:36 --> XSS Filtering completed
DEBUG - 2016-10-06 16:08:36 --> XSS Filtering completed
DEBUG - 2016-10-06 16:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 16:08:36 --> Language Class Initialized
DEBUG - 2016-10-06 16:08:36 --> Loader Class Initialized
DEBUG - 2016-10-06 16:08:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 16:08:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 16:08:36 --> Helper loaded: url_helper
DEBUG - 2016-10-06 16:08:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 16:08:36 --> Helper loaded: file_helper
DEBUG - 2016-10-06 16:08:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:08:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 16:08:36 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 16:08:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:08:36 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 16:08:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 16:08:37 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:08:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 16:08:37 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:08:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 16:08:37 --> Helper loaded: form_helper
DEBUG - 2016-10-06 16:08:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 16:08:37 --> Helper loaded: security_helper
DEBUG - 2016-10-06 16:08:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:08:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 16:08:37 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 16:08:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:08:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 16:08:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 16:08:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 16:08:37 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 16:08:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:08:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 16:08:37 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 16:08:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:08:37 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 16:08:37 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 16:08:37 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 16:08:37 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 16:08:37 --> Database Driver Class Initialized
DEBUG - 2016-10-06 16:08:37 --> Session Class Initialized
DEBUG - 2016-10-06 16:08:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 16:08:37 --> Helper loaded: string_helper
DEBUG - 2016-10-06 16:08:37 --> Session routines successfully run
DEBUG - 2016-10-06 16:08:37 --> Native_session Class Initialized
DEBUG - 2016-10-06 16:08:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 16:08:37 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:08:37 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:08:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 16:08:37 --> Controller Class Initialized
DEBUG - 2016-10-06 16:08:37 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 16:08:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 16:08:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 16:08:37 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:08:37 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:08:37 --> User Agent Class Initialized
DEBUG - 2016-10-06 16:08:37 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:37 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:37 --> Model Class Initialized
ERROR - 2016-10-06 16:08:37 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-10-06 16:08:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-10-06 16:08:37 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:08:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 16:08:37 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-10-06 16:08:37 --> Config Class Initialized
DEBUG - 2016-10-06 16:08:37 --> Hooks Class Initialized
DEBUG - 2016-10-06 16:08:37 --> Utf8 Class Initialized
DEBUG - 2016-10-06 16:08:37 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 16:08:37 --> URI Class Initialized
DEBUG - 2016-10-06 16:08:37 --> Router Class Initialized
DEBUG - 2016-10-06 16:08:37 --> No URI present. Default controller set.
DEBUG - 2016-10-06 16:08:37 --> Output Class Initialized
DEBUG - 2016-10-06 16:08:37 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 16:08:37 --> Security Class Initialized
DEBUG - 2016-10-06 16:08:37 --> Input Class Initialized
DEBUG - 2016-10-06 16:08:37 --> XSS Filtering completed
DEBUG - 2016-10-06 16:08:37 --> XSS Filtering completed
DEBUG - 2016-10-06 16:08:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 16:08:37 --> Language Class Initialized
DEBUG - 2016-10-06 16:08:37 --> Loader Class Initialized
DEBUG - 2016-10-06 16:08:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 16:08:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 16:08:37 --> Helper loaded: url_helper
DEBUG - 2016-10-06 16:08:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 16:08:37 --> Helper loaded: file_helper
DEBUG - 2016-10-06 16:08:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:08:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 16:08:37 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 16:08:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:08:37 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 16:08:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 16:08:37 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:08:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 16:08:37 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:08:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 16:08:37 --> Helper loaded: form_helper
DEBUG - 2016-10-06 16:08:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 16:08:37 --> Helper loaded: security_helper
DEBUG - 2016-10-06 16:08:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:08:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 16:08:37 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 16:08:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:08:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 16:08:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 16:08:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 16:08:37 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 16:08:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:08:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 16:08:37 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 16:08:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:08:37 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 16:08:37 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 16:08:37 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 16:08:37 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 16:08:37 --> Database Driver Class Initialized
DEBUG - 2016-10-06 16:08:37 --> Session Class Initialized
DEBUG - 2016-10-06 16:08:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 16:08:37 --> Helper loaded: string_helper
DEBUG - 2016-10-06 16:08:37 --> Session routines successfully run
DEBUG - 2016-10-06 16:08:37 --> Native_session Class Initialized
DEBUG - 2016-10-06 16:08:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 16:08:37 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:08:37 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:08:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 16:08:37 --> Controller Class Initialized
DEBUG - 2016-10-06 16:08:37 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 16:08:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 16:08:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 16:08:37 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:08:37 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:08:37 --> User Agent Class Initialized
DEBUG - 2016-10-06 16:08:37 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:37 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:37 --> Model Class Initialized
ERROR - 2016-10-06 16:08:37 --> Hak Akses modul/kontroller 'home' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-06 16:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-10-06 16:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-10-06 16:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 16:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 16:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 16:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 16:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 16:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-06 16:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-06 16:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 16:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 16:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 16:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 16:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 16:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 16:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 16:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-06 16:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-06 16:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 16:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 16:08:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-10-06 16:08:37 --> Final output sent to browser
DEBUG - 2016-10-06 16:08:37 --> Total execution time: 0.4416
DEBUG - 2016-10-06 16:08:38 --> Config Class Initialized
DEBUG - 2016-10-06 16:08:38 --> Hooks Class Initialized
DEBUG - 2016-10-06 16:08:38 --> Utf8 Class Initialized
DEBUG - 2016-10-06 16:08:38 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 16:08:38 --> URI Class Initialized
DEBUG - 2016-10-06 16:08:38 --> Router Class Initialized
DEBUG - 2016-10-06 16:08:38 --> Output Class Initialized
DEBUG - 2016-10-06 16:08:38 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 16:08:38 --> Security Class Initialized
DEBUG - 2016-10-06 16:08:38 --> Input Class Initialized
DEBUG - 2016-10-06 16:08:38 --> XSS Filtering completed
DEBUG - 2016-10-06 16:08:38 --> XSS Filtering completed
DEBUG - 2016-10-06 16:08:38 --> XSS Filtering completed
DEBUG - 2016-10-06 16:08:38 --> XSS Filtering completed
DEBUG - 2016-10-06 16:08:38 --> XSS Filtering completed
DEBUG - 2016-10-06 16:08:38 --> XSS Filtering completed
DEBUG - 2016-10-06 16:08:38 --> XSS Filtering completed
DEBUG - 2016-10-06 16:08:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 16:08:38 --> Language Class Initialized
DEBUG - 2016-10-06 16:08:38 --> Loader Class Initialized
DEBUG - 2016-10-06 16:08:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 16:08:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 16:08:38 --> Helper loaded: url_helper
DEBUG - 2016-10-06 16:08:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 16:08:38 --> Helper loaded: file_helper
DEBUG - 2016-10-06 16:08:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:08:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 16:08:38 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 16:08:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:08:38 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 16:08:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 16:08:38 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:08:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 16:08:38 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:08:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 16:08:38 --> Helper loaded: form_helper
DEBUG - 2016-10-06 16:08:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 16:08:38 --> Helper loaded: security_helper
DEBUG - 2016-10-06 16:08:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:08:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 16:08:38 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 16:08:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:08:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 16:08:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 16:08:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 16:08:38 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 16:08:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:08:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 16:08:38 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 16:08:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:08:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 16:08:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 16:08:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 16:08:38 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 16:08:38 --> Database Driver Class Initialized
DEBUG - 2016-10-06 16:08:38 --> Session Class Initialized
DEBUG - 2016-10-06 16:08:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 16:08:38 --> Helper loaded: string_helper
DEBUG - 2016-10-06 16:08:38 --> Session routines successfully run
DEBUG - 2016-10-06 16:08:38 --> Native_session Class Initialized
DEBUG - 2016-10-06 16:08:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 16:08:38 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:08:38 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:08:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 16:08:38 --> Controller Class Initialized
DEBUG - 2016-10-06 16:08:38 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 16:08:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 16:08:38 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 16:08:38 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:08:38 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:08:38 --> User Agent Class Initialized
DEBUG - 2016-10-06 16:08:38 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:38 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:38 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:38 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:38 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:38 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:38 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:38 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-10-06 16:08:38 --> Final output sent to browser
DEBUG - 2016-10-06 16:08:38 --> Total execution time: 0.5196
DEBUG - 2016-10-06 16:08:42 --> Config Class Initialized
DEBUG - 2016-10-06 16:08:42 --> Hooks Class Initialized
DEBUG - 2016-10-06 16:08:42 --> Utf8 Class Initialized
DEBUG - 2016-10-06 16:08:42 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 16:08:42 --> URI Class Initialized
DEBUG - 2016-10-06 16:08:42 --> Router Class Initialized
DEBUG - 2016-10-06 16:08:42 --> Output Class Initialized
DEBUG - 2016-10-06 16:08:42 --> Security Class Initialized
DEBUG - 2016-10-06 16:08:42 --> Input Class Initialized
DEBUG - 2016-10-06 16:08:42 --> XSS Filtering completed
DEBUG - 2016-10-06 16:08:42 --> XSS Filtering completed
DEBUG - 2016-10-06 16:08:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 16:08:42 --> Language Class Initialized
DEBUG - 2016-10-06 16:08:42 --> Loader Class Initialized
DEBUG - 2016-10-06 16:08:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 16:08:42 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 16:08:42 --> Helper loaded: url_helper
DEBUG - 2016-10-06 16:08:42 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 16:08:42 --> Helper loaded: file_helper
DEBUG - 2016-10-06 16:08:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:08:42 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 16:08:42 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 16:08:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:08:42 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 16:08:42 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 16:08:42 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:08:42 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 16:08:42 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:08:42 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 16:08:42 --> Helper loaded: form_helper
DEBUG - 2016-10-06 16:08:42 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 16:08:42 --> Helper loaded: security_helper
DEBUG - 2016-10-06 16:08:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:08:42 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 16:08:42 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 16:08:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:08:42 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 16:08:42 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 16:08:42 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 16:08:42 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 16:08:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:08:42 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 16:08:42 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 16:08:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:08:42 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 16:08:42 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 16:08:42 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 16:08:42 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 16:08:42 --> Database Driver Class Initialized
DEBUG - 2016-10-06 16:08:42 --> Session Class Initialized
DEBUG - 2016-10-06 16:08:42 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 16:08:42 --> Helper loaded: string_helper
DEBUG - 2016-10-06 16:08:42 --> Session routines successfully run
DEBUG - 2016-10-06 16:08:42 --> Native_session Class Initialized
DEBUG - 2016-10-06 16:08:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 16:08:42 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:08:42 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:08:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 16:08:42 --> Controller Class Initialized
DEBUG - 2016-10-06 16:08:42 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 16:08:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 16:08:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 16:08:42 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:08:42 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:08:42 --> User Agent Class Initialized
DEBUG - 2016-10-06 16:08:42 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:42 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:42 --> Model Class Initialized
ERROR - 2016-10-06 16:08:42 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-06 16:08:42 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:44 --> Config Class Initialized
DEBUG - 2016-10-06 16:08:44 --> Hooks Class Initialized
DEBUG - 2016-10-06 16:08:44 --> Utf8 Class Initialized
DEBUG - 2016-10-06 16:08:44 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 16:08:44 --> URI Class Initialized
DEBUG - 2016-10-06 16:08:44 --> Router Class Initialized
DEBUG - 2016-10-06 16:08:44 --> Output Class Initialized
DEBUG - 2016-10-06 16:08:44 --> Security Class Initialized
DEBUG - 2016-10-06 16:08:44 --> Input Class Initialized
DEBUG - 2016-10-06 16:08:44 --> XSS Filtering completed
DEBUG - 2016-10-06 16:08:44 --> XSS Filtering completed
DEBUG - 2016-10-06 16:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 16:08:44 --> Language Class Initialized
DEBUG - 2016-10-06 16:08:44 --> Loader Class Initialized
DEBUG - 2016-10-06 16:08:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 16:08:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 16:08:44 --> Helper loaded: url_helper
DEBUG - 2016-10-06 16:08:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 16:08:44 --> Helper loaded: file_helper
DEBUG - 2016-10-06 16:08:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:08:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 16:08:44 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 16:08:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:08:44 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 16:08:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 16:08:44 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:08:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 16:08:45 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:08:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 16:08:45 --> Helper loaded: form_helper
DEBUG - 2016-10-06 16:08:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 16:08:45 --> Helper loaded: security_helper
DEBUG - 2016-10-06 16:08:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:08:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 16:08:45 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 16:08:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:08:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 16:08:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 16:08:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 16:08:45 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 16:08:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:08:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 16:08:45 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 16:08:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:08:45 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 16:08:45 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 16:08:45 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 16:08:45 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 16:08:45 --> Database Driver Class Initialized
DEBUG - 2016-10-06 16:08:45 --> Session Class Initialized
DEBUG - 2016-10-06 16:08:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 16:08:45 --> Helper loaded: string_helper
DEBUG - 2016-10-06 16:08:45 --> Session routines successfully run
DEBUG - 2016-10-06 16:08:45 --> Native_session Class Initialized
DEBUG - 2016-10-06 16:08:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 16:08:45 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:08:45 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:08:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 16:08:45 --> Controller Class Initialized
DEBUG - 2016-10-06 16:08:45 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 16:08:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 16:08:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 16:08:45 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:08:45 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:08:45 --> User Agent Class Initialized
DEBUG - 2016-10-06 16:08:45 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:45 --> Model Class Initialized
DEBUG - 2016-10-06 16:08:45 --> Model Class Initialized
ERROR - 2016-10-06 16:08:45 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-06 16:08:45 --> Model Class Initialized
DEBUG - 2016-10-06 16:11:26 --> Config Class Initialized
DEBUG - 2016-10-06 16:11:26 --> Hooks Class Initialized
DEBUG - 2016-10-06 16:11:26 --> Utf8 Class Initialized
DEBUG - 2016-10-06 16:11:26 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 16:11:26 --> URI Class Initialized
DEBUG - 2016-10-06 16:11:26 --> Router Class Initialized
DEBUG - 2016-10-06 16:11:26 --> Output Class Initialized
DEBUG - 2016-10-06 16:11:26 --> Security Class Initialized
DEBUG - 2016-10-06 16:11:26 --> Input Class Initialized
DEBUG - 2016-10-06 16:11:26 --> XSS Filtering completed
DEBUG - 2016-10-06 16:11:26 --> XSS Filtering completed
DEBUG - 2016-10-06 16:11:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 16:11:26 --> Language Class Initialized
DEBUG - 2016-10-06 16:11:26 --> Loader Class Initialized
DEBUG - 2016-10-06 16:11:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 16:11:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 16:11:26 --> Helper loaded: url_helper
DEBUG - 2016-10-06 16:11:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 16:11:26 --> Helper loaded: file_helper
DEBUG - 2016-10-06 16:11:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:11:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 16:11:26 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 16:11:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:11:26 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 16:11:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 16:11:26 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:11:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 16:11:26 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:11:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 16:11:26 --> Helper loaded: form_helper
DEBUG - 2016-10-06 16:11:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 16:11:26 --> Helper loaded: security_helper
DEBUG - 2016-10-06 16:11:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:11:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 16:11:26 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 16:11:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:11:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 16:11:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 16:11:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 16:11:26 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 16:11:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:11:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 16:11:26 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 16:11:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:11:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 16:11:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 16:11:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 16:11:26 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 16:11:26 --> Database Driver Class Initialized
DEBUG - 2016-10-06 16:11:26 --> Session Class Initialized
DEBUG - 2016-10-06 16:11:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 16:11:26 --> Helper loaded: string_helper
DEBUG - 2016-10-06 16:11:26 --> Session routines successfully run
DEBUG - 2016-10-06 16:11:26 --> Native_session Class Initialized
DEBUG - 2016-10-06 16:11:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 16:11:26 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:11:26 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:11:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 16:11:26 --> Controller Class Initialized
DEBUG - 2016-10-06 16:11:26 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 16:11:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 16:11:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 16:11:26 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:11:26 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:11:26 --> User Agent Class Initialized
DEBUG - 2016-10-06 16:11:26 --> Model Class Initialized
DEBUG - 2016-10-06 16:11:26 --> Model Class Initialized
DEBUG - 2016-10-06 16:11:26 --> Model Class Initialized
ERROR - 2016-10-06 16:11:26 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-06 16:11:26 --> Model Class Initialized
DEBUG - 2016-10-06 16:27:01 --> Config Class Initialized
DEBUG - 2016-10-06 16:27:01 --> Hooks Class Initialized
DEBUG - 2016-10-06 16:27:01 --> Utf8 Class Initialized
DEBUG - 2016-10-06 16:27:01 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 16:27:01 --> URI Class Initialized
DEBUG - 2016-10-06 16:27:01 --> Router Class Initialized
DEBUG - 2016-10-06 16:27:01 --> Output Class Initialized
DEBUG - 2016-10-06 16:27:01 --> Security Class Initialized
DEBUG - 2016-10-06 16:27:01 --> Input Class Initialized
DEBUG - 2016-10-06 16:27:01 --> XSS Filtering completed
DEBUG - 2016-10-06 16:27:01 --> XSS Filtering completed
DEBUG - 2016-10-06 16:27:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 16:27:01 --> Language Class Initialized
DEBUG - 2016-10-06 16:27:01 --> Loader Class Initialized
DEBUG - 2016-10-06 16:27:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 16:27:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 16:27:01 --> Helper loaded: url_helper
DEBUG - 2016-10-06 16:27:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 16:27:01 --> Helper loaded: file_helper
DEBUG - 2016-10-06 16:27:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:27:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 16:27:01 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 16:27:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:27:01 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 16:27:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 16:27:01 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:27:01 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 16:27:01 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:27:01 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 16:27:01 --> Helper loaded: form_helper
DEBUG - 2016-10-06 16:27:01 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 16:27:02 --> Helper loaded: security_helper
DEBUG - 2016-10-06 16:27:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:27:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 16:27:02 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 16:27:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:27:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 16:27:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 16:27:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 16:27:02 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 16:27:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:27:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 16:27:02 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 16:27:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:27:02 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 16:27:02 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 16:27:02 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 16:27:02 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 16:27:02 --> Database Driver Class Initialized
DEBUG - 2016-10-06 16:27:02 --> Session Class Initialized
DEBUG - 2016-10-06 16:27:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 16:27:02 --> Helper loaded: string_helper
DEBUG - 2016-10-06 16:27:02 --> Session routines successfully run
DEBUG - 2016-10-06 16:27:02 --> Native_session Class Initialized
DEBUG - 2016-10-06 16:27:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 16:27:02 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:27:02 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:27:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 16:27:02 --> Controller Class Initialized
DEBUG - 2016-10-06 16:27:02 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 16:27:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 16:27:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 16:27:02 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:27:02 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:27:02 --> User Agent Class Initialized
DEBUG - 2016-10-06 16:27:02 --> Model Class Initialized
DEBUG - 2016-10-06 16:27:02 --> Model Class Initialized
DEBUG - 2016-10-06 16:27:02 --> Model Class Initialized
ERROR - 2016-10-06 16:27:02 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-06 16:27:02 --> Model Class Initialized
DEBUG - 2016-10-06 16:30:58 --> Config Class Initialized
DEBUG - 2016-10-06 16:30:58 --> Hooks Class Initialized
DEBUG - 2016-10-06 16:30:58 --> Utf8 Class Initialized
DEBUG - 2016-10-06 16:30:58 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 16:30:58 --> URI Class Initialized
DEBUG - 2016-10-06 16:30:59 --> Router Class Initialized
DEBUG - 2016-10-06 16:30:59 --> Output Class Initialized
DEBUG - 2016-10-06 16:30:59 --> Security Class Initialized
DEBUG - 2016-10-06 16:30:59 --> Input Class Initialized
DEBUG - 2016-10-06 16:30:59 --> XSS Filtering completed
DEBUG - 2016-10-06 16:30:59 --> XSS Filtering completed
DEBUG - 2016-10-06 16:30:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 16:30:59 --> Language Class Initialized
DEBUG - 2016-10-06 16:30:59 --> Loader Class Initialized
DEBUG - 2016-10-06 16:30:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 16:30:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 16:30:59 --> Helper loaded: url_helper
DEBUG - 2016-10-06 16:30:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 16:30:59 --> Helper loaded: file_helper
DEBUG - 2016-10-06 16:30:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:30:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 16:30:59 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 16:30:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:30:59 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 16:30:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 16:30:59 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:30:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 16:30:59 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:30:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 16:30:59 --> Helper loaded: form_helper
DEBUG - 2016-10-06 16:30:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 16:30:59 --> Helper loaded: security_helper
DEBUG - 2016-10-06 16:30:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:30:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 16:30:59 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 16:30:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:30:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 16:30:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 16:30:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 16:30:59 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 16:30:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:30:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 16:30:59 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 16:30:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:30:59 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 16:30:59 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 16:30:59 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 16:30:59 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 16:30:59 --> Database Driver Class Initialized
DEBUG - 2016-10-06 16:30:59 --> Session Class Initialized
DEBUG - 2016-10-06 16:30:59 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 16:30:59 --> Helper loaded: string_helper
DEBUG - 2016-10-06 16:30:59 --> Session routines successfully run
DEBUG - 2016-10-06 16:30:59 --> Native_session Class Initialized
DEBUG - 2016-10-06 16:30:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 16:30:59 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:30:59 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:30:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 16:30:59 --> Controller Class Initialized
DEBUG - 2016-10-06 16:30:59 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 16:30:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 16:30:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 16:30:59 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:30:59 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:30:59 --> User Agent Class Initialized
DEBUG - 2016-10-06 16:30:59 --> Model Class Initialized
DEBUG - 2016-10-06 16:30:59 --> Model Class Initialized
DEBUG - 2016-10-06 16:30:59 --> Model Class Initialized
ERROR - 2016-10-06 16:30:59 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-06 16:30:59 --> Model Class Initialized
ERROR - 2016-10-06 16:30:59 --> Severity: Notice  --> Undefined property: stdClass::$nama E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 24
DEBUG - 2016-10-06 16:30:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-06 16:30:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 16:30:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 16:30:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 16:30:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 16:30:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 16:30:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 16:30:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 16:30:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 16:30:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 16:30:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 16:30:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 16:30:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 16:30:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 16:30:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 16:30:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-06 16:30:59 --> Final output sent to browser
DEBUG - 2016-10-06 16:30:59 --> Total execution time: 0.5583
DEBUG - 2016-10-06 16:31:09 --> Config Class Initialized
DEBUG - 2016-10-06 16:31:09 --> Hooks Class Initialized
DEBUG - 2016-10-06 16:31:09 --> Utf8 Class Initialized
DEBUG - 2016-10-06 16:31:09 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 16:31:09 --> URI Class Initialized
DEBUG - 2016-10-06 16:31:09 --> Router Class Initialized
DEBUG - 2016-10-06 16:31:09 --> Output Class Initialized
DEBUG - 2016-10-06 16:31:09 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 16:31:09 --> Security Class Initialized
DEBUG - 2016-10-06 16:31:09 --> Input Class Initialized
DEBUG - 2016-10-06 16:31:09 --> XSS Filtering completed
DEBUG - 2016-10-06 16:31:09 --> XSS Filtering completed
DEBUG - 2016-10-06 16:31:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 16:31:09 --> Language Class Initialized
DEBUG - 2016-10-06 16:31:09 --> Loader Class Initialized
DEBUG - 2016-10-06 16:31:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 16:31:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 16:31:09 --> Helper loaded: url_helper
DEBUG - 2016-10-06 16:31:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 16:31:09 --> Helper loaded: file_helper
DEBUG - 2016-10-06 16:31:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:31:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 16:31:09 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 16:31:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:31:09 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 16:31:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 16:31:09 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:31:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 16:31:09 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:31:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 16:31:09 --> Helper loaded: form_helper
DEBUG - 2016-10-06 16:31:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 16:31:09 --> Helper loaded: security_helper
DEBUG - 2016-10-06 16:31:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:31:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 16:31:09 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 16:31:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:31:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 16:31:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 16:31:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 16:31:09 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 16:31:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:31:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 16:31:09 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 16:31:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:31:09 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 16:31:09 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 16:31:09 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 16:31:09 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 16:31:09 --> Database Driver Class Initialized
DEBUG - 2016-10-06 16:31:09 --> Session Class Initialized
DEBUG - 2016-10-06 16:31:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 16:31:09 --> Helper loaded: string_helper
DEBUG - 2016-10-06 16:31:09 --> Session routines successfully run
DEBUG - 2016-10-06 16:31:09 --> Native_session Class Initialized
DEBUG - 2016-10-06 16:31:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 16:31:09 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:31:10 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:31:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 16:31:10 --> Controller Class Initialized
DEBUG - 2016-10-06 16:31:10 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 16:31:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 16:31:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 16:31:10 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:31:10 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:31:10 --> User Agent Class Initialized
DEBUG - 2016-10-06 16:31:10 --> Model Class Initialized
DEBUG - 2016-10-06 16:31:10 --> Model Class Initialized
DEBUG - 2016-10-06 16:31:10 --> Model Class Initialized
ERROR - 2016-10-06 16:31:10 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-06 16:31:10 --> Model Class Initialized
DEBUG - 2016-10-06 16:31:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-06 16:31:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 16:31:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 16:31:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 16:31:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 16:31:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 16:31:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 16:31:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 16:31:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 16:31:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 16:31:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 16:31:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 16:31:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 16:31:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 16:31:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 16:31:10 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-06 16:31:10 --> Final output sent to browser
DEBUG - 2016-10-06 16:31:10 --> Total execution time: 0.5852
DEBUG - 2016-10-06 16:42:10 --> Config Class Initialized
DEBUG - 2016-10-06 16:42:10 --> Hooks Class Initialized
DEBUG - 2016-10-06 16:42:10 --> Utf8 Class Initialized
DEBUG - 2016-10-06 16:42:10 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 16:42:10 --> URI Class Initialized
DEBUG - 2016-10-06 16:42:10 --> Router Class Initialized
DEBUG - 2016-10-06 16:42:10 --> Output Class Initialized
DEBUG - 2016-10-06 16:42:10 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 16:42:10 --> Security Class Initialized
DEBUG - 2016-10-06 16:42:10 --> Input Class Initialized
DEBUG - 2016-10-06 16:42:10 --> XSS Filtering completed
DEBUG - 2016-10-06 16:42:10 --> XSS Filtering completed
DEBUG - 2016-10-06 16:42:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 16:42:10 --> Language Class Initialized
DEBUG - 2016-10-06 16:42:10 --> Loader Class Initialized
DEBUG - 2016-10-06 16:42:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 16:42:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 16:42:10 --> Helper loaded: url_helper
DEBUG - 2016-10-06 16:42:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 16:42:10 --> Helper loaded: file_helper
DEBUG - 2016-10-06 16:42:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:42:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 16:42:10 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 16:42:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:42:10 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 16:42:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 16:42:10 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:42:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 16:42:10 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:42:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 16:42:10 --> Helper loaded: form_helper
DEBUG - 2016-10-06 16:42:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 16:42:10 --> Helper loaded: security_helper
DEBUG - 2016-10-06 16:42:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:42:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 16:42:10 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 16:42:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:42:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 16:42:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 16:42:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 16:42:10 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 16:42:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:42:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 16:42:10 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 16:42:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:42:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 16:42:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 16:42:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 16:42:10 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 16:42:10 --> Database Driver Class Initialized
DEBUG - 2016-10-06 16:42:10 --> Session Class Initialized
DEBUG - 2016-10-06 16:42:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 16:42:10 --> Helper loaded: string_helper
DEBUG - 2016-10-06 16:42:10 --> Session routines successfully run
DEBUG - 2016-10-06 16:42:10 --> Native_session Class Initialized
DEBUG - 2016-10-06 16:42:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 16:42:10 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:42:10 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:42:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 16:42:10 --> Controller Class Initialized
DEBUG - 2016-10-06 16:42:10 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 16:42:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 16:42:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 16:42:10 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:42:10 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:42:10 --> User Agent Class Initialized
DEBUG - 2016-10-06 16:42:10 --> Model Class Initialized
DEBUG - 2016-10-06 16:42:10 --> Model Class Initialized
DEBUG - 2016-10-06 16:42:10 --> Model Class Initialized
ERROR - 2016-10-06 16:42:10 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-06 16:42:10 --> Model Class Initialized
DEBUG - 2016-10-06 16:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-06 16:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 16:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 16:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 16:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 16:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 16:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 16:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 16:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 16:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 16:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 16:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 16:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 16:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 16:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 16:42:10 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-06 16:42:10 --> Final output sent to browser
DEBUG - 2016-10-06 16:42:10 --> Total execution time: 0.5950
DEBUG - 2016-10-06 16:44:20 --> Config Class Initialized
DEBUG - 2016-10-06 16:44:20 --> Hooks Class Initialized
DEBUG - 2016-10-06 16:44:20 --> Utf8 Class Initialized
DEBUG - 2016-10-06 16:44:20 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 16:44:20 --> URI Class Initialized
DEBUG - 2016-10-06 16:44:20 --> Router Class Initialized
DEBUG - 2016-10-06 16:44:20 --> Output Class Initialized
DEBUG - 2016-10-06 16:44:20 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 16:44:20 --> Security Class Initialized
DEBUG - 2016-10-06 16:44:20 --> Input Class Initialized
DEBUG - 2016-10-06 16:44:20 --> XSS Filtering completed
DEBUG - 2016-10-06 16:44:20 --> XSS Filtering completed
DEBUG - 2016-10-06 16:44:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 16:44:20 --> Language Class Initialized
DEBUG - 2016-10-06 16:44:20 --> Loader Class Initialized
DEBUG - 2016-10-06 16:44:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 16:44:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 16:44:20 --> Helper loaded: url_helper
DEBUG - 2016-10-06 16:44:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 16:44:20 --> Helper loaded: file_helper
DEBUG - 2016-10-06 16:44:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:44:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 16:44:20 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 16:44:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 16:44:20 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 16:44:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 16:44:20 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:44:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 16:44:20 --> Helper loaded: common_helper
DEBUG - 2016-10-06 16:44:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 16:44:20 --> Helper loaded: form_helper
DEBUG - 2016-10-06 16:44:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 16:44:20 --> Helper loaded: security_helper
DEBUG - 2016-10-06 16:44:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:44:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 16:44:20 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 16:44:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 16:44:21 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 16:44:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 16:44:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 16:44:21 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 16:44:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:44:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 16:44:21 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 16:44:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 16:44:21 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 16:44:21 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 16:44:21 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 16:44:21 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 16:44:21 --> Database Driver Class Initialized
DEBUG - 2016-10-06 16:44:21 --> Session Class Initialized
DEBUG - 2016-10-06 16:44:21 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 16:44:21 --> Helper loaded: string_helper
DEBUG - 2016-10-06 16:44:21 --> Session routines successfully run
DEBUG - 2016-10-06 16:44:21 --> Native_session Class Initialized
DEBUG - 2016-10-06 16:44:21 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 16:44:21 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:44:21 --> Form Validation Class Initialized
DEBUG - 2016-10-06 16:44:21 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 16:44:21 --> Controller Class Initialized
DEBUG - 2016-10-06 16:44:21 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 16:44:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 16:44:21 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 16:44:21 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:44:21 --> Carabiner: library configured.
DEBUG - 2016-10-06 16:44:21 --> User Agent Class Initialized
DEBUG - 2016-10-06 16:44:21 --> Model Class Initialized
DEBUG - 2016-10-06 16:44:21 --> Model Class Initialized
DEBUG - 2016-10-06 16:44:21 --> Model Class Initialized
ERROR - 2016-10-06 16:44:21 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-06 16:44:21 --> Model Class Initialized
DEBUG - 2016-10-06 17:03:06 --> Config Class Initialized
DEBUG - 2016-10-06 17:03:06 --> Hooks Class Initialized
DEBUG - 2016-10-06 17:03:06 --> Utf8 Class Initialized
DEBUG - 2016-10-06 17:03:06 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 17:03:06 --> URI Class Initialized
DEBUG - 2016-10-06 17:03:06 --> Router Class Initialized
DEBUG - 2016-10-06 17:03:06 --> Output Class Initialized
DEBUG - 2016-10-06 17:03:06 --> Security Class Initialized
DEBUG - 2016-10-06 17:03:06 --> Input Class Initialized
DEBUG - 2016-10-06 17:03:06 --> XSS Filtering completed
DEBUG - 2016-10-06 17:03:06 --> XSS Filtering completed
DEBUG - 2016-10-06 17:03:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 17:03:06 --> Language Class Initialized
DEBUG - 2016-10-06 17:03:06 --> Loader Class Initialized
DEBUG - 2016-10-06 17:03:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 17:03:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 17:03:06 --> Helper loaded: url_helper
DEBUG - 2016-10-06 17:03:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 17:03:06 --> Helper loaded: file_helper
DEBUG - 2016-10-06 17:03:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 17:03:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 17:03:06 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 17:03:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 17:03:06 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 17:03:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 17:03:06 --> Helper loaded: common_helper
DEBUG - 2016-10-06 17:03:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 17:03:06 --> Helper loaded: common_helper
DEBUG - 2016-10-06 17:03:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 17:03:06 --> Helper loaded: form_helper
DEBUG - 2016-10-06 17:03:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 17:03:06 --> Helper loaded: security_helper
DEBUG - 2016-10-06 17:03:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 17:03:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 17:03:06 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 17:03:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 17:03:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 17:03:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 17:03:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 17:03:06 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 17:03:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 17:03:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 17:03:06 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 17:03:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 17:03:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 17:03:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 17:03:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 17:03:06 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 17:03:06 --> Database Driver Class Initialized
DEBUG - 2016-10-06 17:03:06 --> Session Class Initialized
DEBUG - 2016-10-06 17:03:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 17:03:06 --> Helper loaded: string_helper
DEBUG - 2016-10-06 17:03:06 --> Session routines successfully run
DEBUG - 2016-10-06 17:03:06 --> Native_session Class Initialized
DEBUG - 2016-10-06 17:03:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 17:03:06 --> Form Validation Class Initialized
DEBUG - 2016-10-06 17:03:06 --> Form Validation Class Initialized
DEBUG - 2016-10-06 17:03:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 17:03:06 --> Controller Class Initialized
DEBUG - 2016-10-06 17:03:06 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 17:03:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 17:03:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 17:03:06 --> Carabiner: library configured.
DEBUG - 2016-10-06 17:03:06 --> Carabiner: library configured.
DEBUG - 2016-10-06 17:03:06 --> User Agent Class Initialized
DEBUG - 2016-10-06 17:03:06 --> Model Class Initialized
DEBUG - 2016-10-06 17:03:06 --> Model Class Initialized
DEBUG - 2016-10-06 17:03:06 --> Model Class Initialized
ERROR - 2016-10-06 17:03:06 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-06 17:03:06 --> Model Class Initialized
ERROR - 2016-10-06 17:03:06 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 33
DEBUG - 2016-10-06 17:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-06 17:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 17:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 17:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 17:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 17:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 17:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 17:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 17:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 17:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 17:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 17:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 17:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 17:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 17:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 17:03:06 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-06 17:03:07 --> Final output sent to browser
DEBUG - 2016-10-06 17:03:07 --> Total execution time: 0.6299
DEBUG - 2016-10-06 17:03:33 --> Config Class Initialized
DEBUG - 2016-10-06 17:03:33 --> Hooks Class Initialized
DEBUG - 2016-10-06 17:03:33 --> Utf8 Class Initialized
DEBUG - 2016-10-06 17:03:33 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 17:03:33 --> URI Class Initialized
DEBUG - 2016-10-06 17:03:33 --> Router Class Initialized
DEBUG - 2016-10-06 17:03:33 --> Output Class Initialized
DEBUG - 2016-10-06 17:03:33 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 17:03:33 --> Security Class Initialized
DEBUG - 2016-10-06 17:03:33 --> Input Class Initialized
DEBUG - 2016-10-06 17:03:33 --> XSS Filtering completed
DEBUG - 2016-10-06 17:03:33 --> XSS Filtering completed
DEBUG - 2016-10-06 17:03:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 17:03:33 --> Language Class Initialized
DEBUG - 2016-10-06 17:03:33 --> Loader Class Initialized
DEBUG - 2016-10-06 17:03:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 17:03:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 17:03:33 --> Helper loaded: url_helper
DEBUG - 2016-10-06 17:03:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 17:03:33 --> Helper loaded: file_helper
DEBUG - 2016-10-06 17:03:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 17:03:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 17:03:33 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 17:03:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 17:03:33 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 17:03:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 17:03:33 --> Helper loaded: common_helper
DEBUG - 2016-10-06 17:03:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 17:03:33 --> Helper loaded: common_helper
DEBUG - 2016-10-06 17:03:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 17:03:33 --> Helper loaded: form_helper
DEBUG - 2016-10-06 17:03:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 17:03:33 --> Helper loaded: security_helper
DEBUG - 2016-10-06 17:03:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 17:03:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 17:03:33 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 17:03:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 17:03:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 17:03:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 17:03:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 17:03:33 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 17:03:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 17:03:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 17:03:33 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 17:03:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 17:03:33 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 17:03:33 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 17:03:33 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 17:03:33 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 17:03:33 --> Database Driver Class Initialized
DEBUG - 2016-10-06 17:03:33 --> Session Class Initialized
DEBUG - 2016-10-06 17:03:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 17:03:33 --> Helper loaded: string_helper
DEBUG - 2016-10-06 17:03:33 --> Session routines successfully run
DEBUG - 2016-10-06 17:03:33 --> Native_session Class Initialized
DEBUG - 2016-10-06 17:03:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 17:03:33 --> Form Validation Class Initialized
DEBUG - 2016-10-06 17:03:33 --> Form Validation Class Initialized
DEBUG - 2016-10-06 17:03:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 17:03:33 --> Controller Class Initialized
DEBUG - 2016-10-06 17:03:33 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 17:03:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 17:03:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 17:03:33 --> Carabiner: library configured.
DEBUG - 2016-10-06 17:03:33 --> Carabiner: library configured.
DEBUG - 2016-10-06 17:03:33 --> User Agent Class Initialized
DEBUG - 2016-10-06 17:03:33 --> Model Class Initialized
DEBUG - 2016-10-06 17:03:33 --> Model Class Initialized
DEBUG - 2016-10-06 17:03:33 --> Model Class Initialized
ERROR - 2016-10-06 17:03:33 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-06 17:03:33 --> Model Class Initialized
ERROR - 2016-10-06 17:03:33 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 33
DEBUG - 2016-10-06 17:03:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-06 17:03:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 17:03:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 17:03:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 17:03:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 17:03:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 17:03:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 17:03:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 17:03:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 17:03:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 17:03:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 17:03:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 17:03:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 17:03:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 17:03:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 17:03:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-06 17:03:34 --> Final output sent to browser
DEBUG - 2016-10-06 17:03:34 --> Total execution time: 0.6562
DEBUG - 2016-10-06 17:04:06 --> Config Class Initialized
DEBUG - 2016-10-06 17:04:06 --> Hooks Class Initialized
DEBUG - 2016-10-06 17:04:06 --> Utf8 Class Initialized
DEBUG - 2016-10-06 17:04:06 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 17:04:06 --> URI Class Initialized
DEBUG - 2016-10-06 17:04:06 --> Router Class Initialized
DEBUG - 2016-10-06 17:04:06 --> Output Class Initialized
DEBUG - 2016-10-06 17:04:06 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 17:04:06 --> Security Class Initialized
DEBUG - 2016-10-06 17:04:06 --> Input Class Initialized
DEBUG - 2016-10-06 17:04:06 --> XSS Filtering completed
DEBUG - 2016-10-06 17:04:06 --> XSS Filtering completed
DEBUG - 2016-10-06 17:04:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 17:04:06 --> Language Class Initialized
DEBUG - 2016-10-06 17:04:06 --> Loader Class Initialized
DEBUG - 2016-10-06 17:04:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 17:04:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 17:04:06 --> Helper loaded: url_helper
DEBUG - 2016-10-06 17:04:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 17:04:06 --> Helper loaded: file_helper
DEBUG - 2016-10-06 17:04:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 17:04:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 17:04:06 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 17:04:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 17:04:06 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 17:04:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 17:04:06 --> Helper loaded: common_helper
DEBUG - 2016-10-06 17:04:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 17:04:06 --> Helper loaded: common_helper
DEBUG - 2016-10-06 17:04:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 17:04:06 --> Helper loaded: form_helper
DEBUG - 2016-10-06 17:04:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 17:04:06 --> Helper loaded: security_helper
DEBUG - 2016-10-06 17:04:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 17:04:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 17:04:06 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 17:04:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 17:04:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 17:04:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 17:04:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 17:04:06 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 17:04:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 17:04:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 17:04:06 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 17:04:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 17:04:07 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 17:04:07 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 17:04:07 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 17:04:07 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 17:04:07 --> Database Driver Class Initialized
DEBUG - 2016-10-06 17:04:07 --> Session Class Initialized
DEBUG - 2016-10-06 17:04:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 17:04:07 --> Helper loaded: string_helper
DEBUG - 2016-10-06 17:04:07 --> Session routines successfully run
DEBUG - 2016-10-06 17:04:07 --> Native_session Class Initialized
DEBUG - 2016-10-06 17:04:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 17:04:07 --> Form Validation Class Initialized
DEBUG - 2016-10-06 17:04:07 --> Form Validation Class Initialized
DEBUG - 2016-10-06 17:04:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 17:04:07 --> Controller Class Initialized
DEBUG - 2016-10-06 17:04:07 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 17:04:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 17:04:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 17:04:07 --> Carabiner: library configured.
DEBUG - 2016-10-06 17:04:07 --> Carabiner: library configured.
DEBUG - 2016-10-06 17:04:07 --> User Agent Class Initialized
DEBUG - 2016-10-06 17:04:07 --> Model Class Initialized
DEBUG - 2016-10-06 17:04:07 --> Model Class Initialized
DEBUG - 2016-10-06 17:04:07 --> Model Class Initialized
ERROR - 2016-10-06 17:04:07 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-06 17:04:07 --> Model Class Initialized
DEBUG - 2016-10-06 17:04:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-06 17:04:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 17:04:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 17:04:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 17:04:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 17:04:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 17:04:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 17:04:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 17:04:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 17:04:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 17:04:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 17:04:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 17:04:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 17:04:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 17:04:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 17:04:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-06 17:04:07 --> Final output sent to browser
DEBUG - 2016-10-06 17:04:07 --> Total execution time: 0.6971
DEBUG - 2016-10-06 17:15:04 --> Config Class Initialized
DEBUG - 2016-10-06 17:15:04 --> Hooks Class Initialized
DEBUG - 2016-10-06 17:15:04 --> Utf8 Class Initialized
DEBUG - 2016-10-06 17:15:04 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 17:15:04 --> URI Class Initialized
DEBUG - 2016-10-06 17:15:04 --> Router Class Initialized
DEBUG - 2016-10-06 17:15:04 --> Output Class Initialized
DEBUG - 2016-10-06 17:15:04 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 17:15:04 --> Security Class Initialized
DEBUG - 2016-10-06 17:15:04 --> Input Class Initialized
DEBUG - 2016-10-06 17:15:04 --> XSS Filtering completed
DEBUG - 2016-10-06 17:15:04 --> XSS Filtering completed
DEBUG - 2016-10-06 17:15:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 17:15:04 --> Language Class Initialized
DEBUG - 2016-10-06 17:15:04 --> Loader Class Initialized
DEBUG - 2016-10-06 17:15:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 17:15:04 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 17:15:04 --> Helper loaded: url_helper
DEBUG - 2016-10-06 17:15:04 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 17:15:04 --> Helper loaded: file_helper
DEBUG - 2016-10-06 17:15:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 17:15:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 17:15:04 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 17:15:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 17:15:04 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 17:15:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 17:15:04 --> Helper loaded: common_helper
DEBUG - 2016-10-06 17:15:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 17:15:04 --> Helper loaded: common_helper
DEBUG - 2016-10-06 17:15:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 17:15:04 --> Helper loaded: form_helper
DEBUG - 2016-10-06 17:15:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 17:15:04 --> Helper loaded: security_helper
DEBUG - 2016-10-06 17:15:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 17:15:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 17:15:04 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 17:15:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 17:15:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 17:15:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 17:15:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 17:15:04 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 17:15:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 17:15:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 17:15:04 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 17:15:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 17:15:04 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 17:15:04 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 17:15:04 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 17:15:04 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 17:15:04 --> Database Driver Class Initialized
DEBUG - 2016-10-06 17:15:04 --> Session Class Initialized
DEBUG - 2016-10-06 17:15:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 17:15:04 --> Helper loaded: string_helper
DEBUG - 2016-10-06 17:15:04 --> Session routines successfully run
DEBUG - 2016-10-06 17:15:04 --> Native_session Class Initialized
DEBUG - 2016-10-06 17:15:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 17:15:04 --> Form Validation Class Initialized
DEBUG - 2016-10-06 17:15:04 --> Form Validation Class Initialized
DEBUG - 2016-10-06 17:15:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 17:15:04 --> Controller Class Initialized
DEBUG - 2016-10-06 17:15:04 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 17:15:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 17:15:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 17:15:04 --> Carabiner: library configured.
DEBUG - 2016-10-06 17:15:04 --> Carabiner: library configured.
DEBUG - 2016-10-06 17:15:04 --> User Agent Class Initialized
DEBUG - 2016-10-06 17:15:04 --> Model Class Initialized
DEBUG - 2016-10-06 17:15:04 --> Model Class Initialized
DEBUG - 2016-10-06 17:15:04 --> Model Class Initialized
ERROR - 2016-10-06 17:15:04 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-06 17:15:04 --> Model Class Initialized
DEBUG - 2016-10-06 17:15:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-06 17:15:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 17:15:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 17:15:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 17:15:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 17:15:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 17:15:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 17:15:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 17:15:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 17:15:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 17:15:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 17:15:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 17:15:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 17:15:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 17:15:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 17:15:04 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-06 17:15:04 --> Final output sent to browser
DEBUG - 2016-10-06 17:15:04 --> Total execution time: 0.7022
DEBUG - 2016-10-06 17:18:10 --> Config Class Initialized
DEBUG - 2016-10-06 17:18:10 --> Hooks Class Initialized
DEBUG - 2016-10-06 17:18:10 --> Utf8 Class Initialized
DEBUG - 2016-10-06 17:18:10 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 17:18:10 --> URI Class Initialized
DEBUG - 2016-10-06 17:18:10 --> Router Class Initialized
DEBUG - 2016-10-06 17:18:10 --> Output Class Initialized
DEBUG - 2016-10-06 17:18:10 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 17:18:10 --> Security Class Initialized
DEBUG - 2016-10-06 17:18:10 --> Input Class Initialized
DEBUG - 2016-10-06 17:18:10 --> XSS Filtering completed
DEBUG - 2016-10-06 17:18:10 --> XSS Filtering completed
DEBUG - 2016-10-06 17:18:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 17:18:10 --> Language Class Initialized
DEBUG - 2016-10-06 17:18:10 --> Loader Class Initialized
DEBUG - 2016-10-06 17:18:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 17:18:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 17:18:10 --> Helper loaded: url_helper
DEBUG - 2016-10-06 17:18:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 17:18:10 --> Helper loaded: file_helper
DEBUG - 2016-10-06 17:18:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 17:18:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 17:18:10 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 17:18:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 17:18:10 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 17:18:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 17:18:10 --> Helper loaded: common_helper
DEBUG - 2016-10-06 17:18:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 17:18:10 --> Helper loaded: common_helper
DEBUG - 2016-10-06 17:18:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 17:18:10 --> Helper loaded: form_helper
DEBUG - 2016-10-06 17:18:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 17:18:10 --> Helper loaded: security_helper
DEBUG - 2016-10-06 17:18:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 17:18:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 17:18:10 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 17:18:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 17:18:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 17:18:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 17:18:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 17:18:10 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 17:18:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 17:18:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 17:18:10 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 17:18:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 17:18:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 17:18:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 17:18:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 17:18:10 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 17:18:10 --> Database Driver Class Initialized
DEBUG - 2016-10-06 17:18:10 --> Session Class Initialized
DEBUG - 2016-10-06 17:18:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 17:18:10 --> Helper loaded: string_helper
DEBUG - 2016-10-06 17:18:10 --> Session routines successfully run
DEBUG - 2016-10-06 17:18:10 --> Native_session Class Initialized
DEBUG - 2016-10-06 17:18:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 17:18:10 --> Form Validation Class Initialized
DEBUG - 2016-10-06 17:18:10 --> Form Validation Class Initialized
DEBUG - 2016-10-06 17:18:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 17:18:10 --> Controller Class Initialized
DEBUG - 2016-10-06 17:18:10 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 17:18:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 17:18:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 17:18:10 --> Carabiner: library configured.
DEBUG - 2016-10-06 17:18:10 --> Carabiner: library configured.
DEBUG - 2016-10-06 17:18:10 --> User Agent Class Initialized
DEBUG - 2016-10-06 17:18:10 --> Model Class Initialized
DEBUG - 2016-10-06 17:18:10 --> Model Class Initialized
DEBUG - 2016-10-06 17:18:10 --> Model Class Initialized
ERROR - 2016-10-06 17:18:10 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-06 17:18:10 --> Model Class Initialized
DEBUG - 2016-10-06 17:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-06 17:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 17:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 17:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 17:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 17:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 17:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 17:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 17:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 17:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 17:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 17:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 17:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 17:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 17:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 17:18:11 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-06 17:18:11 --> Final output sent to browser
DEBUG - 2016-10-06 17:18:11 --> Total execution time: 0.7155
DEBUG - 2016-10-06 17:19:03 --> Config Class Initialized
DEBUG - 2016-10-06 17:19:03 --> Hooks Class Initialized
DEBUG - 2016-10-06 17:19:03 --> Utf8 Class Initialized
DEBUG - 2016-10-06 17:19:03 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 17:19:03 --> URI Class Initialized
DEBUG - 2016-10-06 17:19:03 --> Router Class Initialized
DEBUG - 2016-10-06 17:19:03 --> Output Class Initialized
DEBUG - 2016-10-06 17:19:03 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 17:19:03 --> Security Class Initialized
DEBUG - 2016-10-06 17:19:03 --> Input Class Initialized
DEBUG - 2016-10-06 17:19:03 --> XSS Filtering completed
DEBUG - 2016-10-06 17:19:03 --> XSS Filtering completed
DEBUG - 2016-10-06 17:19:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 17:19:03 --> Language Class Initialized
DEBUG - 2016-10-06 17:19:03 --> Loader Class Initialized
DEBUG - 2016-10-06 17:19:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 17:19:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 17:19:03 --> Helper loaded: url_helper
DEBUG - 2016-10-06 17:19:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 17:19:03 --> Helper loaded: file_helper
DEBUG - 2016-10-06 17:19:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 17:19:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 17:19:03 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 17:19:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 17:19:03 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 17:19:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 17:19:03 --> Helper loaded: common_helper
DEBUG - 2016-10-06 17:19:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 17:19:03 --> Helper loaded: common_helper
DEBUG - 2016-10-06 17:19:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 17:19:03 --> Helper loaded: form_helper
DEBUG - 2016-10-06 17:19:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 17:19:03 --> Helper loaded: security_helper
DEBUG - 2016-10-06 17:19:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 17:19:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 17:19:03 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 17:19:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 17:19:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 17:19:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 17:19:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 17:19:03 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 17:19:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 17:19:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 17:19:03 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 17:19:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 17:19:03 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 17:19:03 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 17:19:03 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 17:19:03 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 17:19:03 --> Database Driver Class Initialized
DEBUG - 2016-10-06 17:19:03 --> Session Class Initialized
DEBUG - 2016-10-06 17:19:03 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 17:19:03 --> Helper loaded: string_helper
DEBUG - 2016-10-06 17:19:03 --> Session routines successfully run
DEBUG - 2016-10-06 17:19:03 --> Native_session Class Initialized
DEBUG - 2016-10-06 17:19:03 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 17:19:03 --> Form Validation Class Initialized
DEBUG - 2016-10-06 17:19:03 --> Form Validation Class Initialized
DEBUG - 2016-10-06 17:19:03 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 17:19:03 --> Controller Class Initialized
DEBUG - 2016-10-06 17:19:03 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 17:19:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 17:19:03 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 17:19:03 --> Carabiner: library configured.
DEBUG - 2016-10-06 17:19:03 --> Carabiner: library configured.
DEBUG - 2016-10-06 17:19:03 --> User Agent Class Initialized
DEBUG - 2016-10-06 17:19:03 --> Model Class Initialized
DEBUG - 2016-10-06 17:19:03 --> Model Class Initialized
DEBUG - 2016-10-06 17:19:03 --> Model Class Initialized
ERROR - 2016-10-06 17:19:03 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-06 17:19:03 --> Model Class Initialized
DEBUG - 2016-10-06 17:19:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-06 17:19:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 17:19:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 17:19:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 17:19:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 17:19:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 17:19:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 17:19:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 17:19:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 17:19:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 17:19:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 17:19:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 17:19:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 17:19:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 17:19:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 17:19:04 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-06 17:19:04 --> Final output sent to browser
DEBUG - 2016-10-06 17:19:04 --> Total execution time: 0.7319
DEBUG - 2016-10-06 17:26:45 --> Config Class Initialized
DEBUG - 2016-10-06 17:26:45 --> Hooks Class Initialized
DEBUG - 2016-10-06 17:26:45 --> Utf8 Class Initialized
DEBUG - 2016-10-06 17:26:45 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 17:26:45 --> URI Class Initialized
DEBUG - 2016-10-06 17:26:45 --> Router Class Initialized
DEBUG - 2016-10-06 17:26:45 --> Output Class Initialized
DEBUG - 2016-10-06 17:26:45 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 17:26:45 --> Security Class Initialized
DEBUG - 2016-10-06 17:26:45 --> Input Class Initialized
DEBUG - 2016-10-06 17:26:45 --> XSS Filtering completed
DEBUG - 2016-10-06 17:26:45 --> XSS Filtering completed
DEBUG - 2016-10-06 17:26:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 17:26:45 --> Language Class Initialized
DEBUG - 2016-10-06 17:26:45 --> Loader Class Initialized
DEBUG - 2016-10-06 17:26:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 17:26:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 17:26:45 --> Helper loaded: url_helper
DEBUG - 2016-10-06 17:26:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 17:26:45 --> Helper loaded: file_helper
DEBUG - 2016-10-06 17:26:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 17:26:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 17:26:45 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 17:26:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 17:26:45 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 17:26:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 17:26:45 --> Helper loaded: common_helper
DEBUG - 2016-10-06 17:26:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 17:26:45 --> Helper loaded: common_helper
DEBUG - 2016-10-06 17:26:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 17:26:45 --> Helper loaded: form_helper
DEBUG - 2016-10-06 17:26:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 17:26:45 --> Helper loaded: security_helper
DEBUG - 2016-10-06 17:26:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 17:26:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 17:26:45 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 17:26:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 17:26:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 17:26:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 17:26:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 17:26:45 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 17:26:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 17:26:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 17:26:45 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 17:26:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 17:26:45 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 17:26:45 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 17:26:45 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 17:26:45 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 17:26:45 --> Database Driver Class Initialized
DEBUG - 2016-10-06 17:26:45 --> Session Class Initialized
DEBUG - 2016-10-06 17:26:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 17:26:45 --> Helper loaded: string_helper
DEBUG - 2016-10-06 17:26:45 --> Session routines successfully run
DEBUG - 2016-10-06 17:26:45 --> Native_session Class Initialized
DEBUG - 2016-10-06 17:26:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 17:26:45 --> Form Validation Class Initialized
DEBUG - 2016-10-06 17:26:45 --> Form Validation Class Initialized
DEBUG - 2016-10-06 17:26:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 17:26:45 --> Controller Class Initialized
DEBUG - 2016-10-06 17:26:45 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 17:26:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 17:26:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 17:26:45 --> Carabiner: library configured.
DEBUG - 2016-10-06 17:26:45 --> Carabiner: library configured.
DEBUG - 2016-10-06 17:26:45 --> User Agent Class Initialized
DEBUG - 2016-10-06 17:26:45 --> Model Class Initialized
DEBUG - 2016-10-06 17:26:45 --> Model Class Initialized
DEBUG - 2016-10-06 17:26:45 --> Model Class Initialized
DEBUG - 2016-10-06 17:26:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-10-06 17:26:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-06 17:26:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-06 17:26:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 17:26:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-06 17:26:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 17:26:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-06 17:26:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-06 17:26:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-06 17:26:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 17:26:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-06 17:26:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 17:26:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-06 17:26:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-10-06 17:26:45 --> Final output sent to browser
DEBUG - 2016-10-06 17:26:45 --> Total execution time: 0.7039
DEBUG - 2016-10-06 17:26:49 --> Config Class Initialized
DEBUG - 2016-10-06 17:26:49 --> Hooks Class Initialized
DEBUG - 2016-10-06 17:26:49 --> Utf8 Class Initialized
DEBUG - 2016-10-06 17:26:49 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 17:26:49 --> URI Class Initialized
DEBUG - 2016-10-06 17:26:49 --> Router Class Initialized
DEBUG - 2016-10-06 17:26:49 --> Output Class Initialized
DEBUG - 2016-10-06 17:26:49 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 17:26:49 --> Security Class Initialized
DEBUG - 2016-10-06 17:26:49 --> Input Class Initialized
DEBUG - 2016-10-06 17:26:49 --> XSS Filtering completed
DEBUG - 2016-10-06 17:26:49 --> XSS Filtering completed
DEBUG - 2016-10-06 17:26:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 17:26:49 --> Language Class Initialized
DEBUG - 2016-10-06 17:26:49 --> Loader Class Initialized
DEBUG - 2016-10-06 17:26:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 17:26:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 17:26:49 --> Helper loaded: url_helper
DEBUG - 2016-10-06 17:26:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 17:26:49 --> Helper loaded: file_helper
DEBUG - 2016-10-06 17:26:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 17:26:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 17:26:49 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 17:26:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 17:26:49 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 17:26:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 17:26:49 --> Helper loaded: common_helper
DEBUG - 2016-10-06 17:26:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 17:26:49 --> Helper loaded: common_helper
DEBUG - 2016-10-06 17:26:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 17:26:49 --> Helper loaded: form_helper
DEBUG - 2016-10-06 17:26:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 17:26:49 --> Helper loaded: security_helper
DEBUG - 2016-10-06 17:26:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 17:26:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 17:26:49 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 17:26:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 17:26:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 17:26:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 17:26:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 17:26:49 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 17:26:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 17:26:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 17:26:49 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 17:26:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 17:26:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 17:26:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 17:26:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 17:26:49 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 17:26:49 --> Database Driver Class Initialized
DEBUG - 2016-10-06 17:26:49 --> Session Class Initialized
DEBUG - 2016-10-06 17:26:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 17:26:49 --> Helper loaded: string_helper
DEBUG - 2016-10-06 17:26:49 --> Session routines successfully run
DEBUG - 2016-10-06 17:26:49 --> Native_session Class Initialized
DEBUG - 2016-10-06 17:26:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 17:26:49 --> Form Validation Class Initialized
DEBUG - 2016-10-06 17:26:49 --> Form Validation Class Initialized
DEBUG - 2016-10-06 17:26:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 17:26:49 --> Controller Class Initialized
DEBUG - 2016-10-06 17:26:49 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 17:26:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 17:26:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 17:26:49 --> Carabiner: library configured.
DEBUG - 2016-10-06 17:26:49 --> Carabiner: library configured.
DEBUG - 2016-10-06 17:26:49 --> User Agent Class Initialized
DEBUG - 2016-10-06 17:26:49 --> Model Class Initialized
DEBUG - 2016-10-06 17:26:49 --> Model Class Initialized
DEBUG - 2016-10-06 17:26:49 --> Model Class Initialized
DEBUG - 2016-10-06 17:26:49 --> Model Class Initialized
DEBUG - 2016-10-06 17:26:49 --> Model Class Initialized
DEBUG - 2016-10-06 17:26:49 --> Model Class Initialized
DEBUG - 2016-10-06 17:26:49 --> Model Class Initialized
DEBUG - 2016-10-06 17:26:49 --> Model Class Initialized
DEBUG - 2016-10-06 17:26:49 --> Model Class Initialized
DEBUG - 2016-10-06 17:26:50 --> Model Class Initialized
DEBUG - 2016-10-06 17:26:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-06 17:26:50 --> Pagination Class Initialized
DEBUG - 2016-10-06 17:26:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-10-06 17:26:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-10-06 17:26:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-06 17:26:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-06 17:26:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 17:26:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-06 17:26:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-10-06 17:26:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 17:26:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-06 17:26:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-06 17:26:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-06 17:26:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 17:26:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-06 17:26:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-10-06 17:26:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 17:26:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-06 17:26:50 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-10-06 17:26:50 --> Final output sent to browser
DEBUG - 2016-10-06 17:26:50 --> Total execution time: 0.8824
DEBUG - 2016-10-06 17:26:53 --> Config Class Initialized
DEBUG - 2016-10-06 17:26:54 --> Hooks Class Initialized
DEBUG - 2016-10-06 17:26:54 --> Utf8 Class Initialized
DEBUG - 2016-10-06 17:26:54 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 17:26:54 --> URI Class Initialized
DEBUG - 2016-10-06 17:26:54 --> Router Class Initialized
DEBUG - 2016-10-06 17:26:54 --> Output Class Initialized
DEBUG - 2016-10-06 17:26:54 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 17:26:54 --> Security Class Initialized
DEBUG - 2016-10-06 17:26:54 --> Input Class Initialized
DEBUG - 2016-10-06 17:26:54 --> XSS Filtering completed
DEBUG - 2016-10-06 17:26:54 --> XSS Filtering completed
DEBUG - 2016-10-06 17:26:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 17:26:54 --> Language Class Initialized
DEBUG - 2016-10-06 17:26:54 --> Loader Class Initialized
DEBUG - 2016-10-06 17:26:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 17:26:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 17:26:54 --> Helper loaded: url_helper
DEBUG - 2016-10-06 17:26:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 17:26:54 --> Helper loaded: file_helper
DEBUG - 2016-10-06 17:26:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 17:26:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 17:26:54 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 17:26:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 17:26:54 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 17:26:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 17:26:54 --> Helper loaded: common_helper
DEBUG - 2016-10-06 17:26:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 17:26:54 --> Helper loaded: common_helper
DEBUG - 2016-10-06 17:26:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 17:26:54 --> Helper loaded: form_helper
DEBUG - 2016-10-06 17:26:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 17:26:54 --> Helper loaded: security_helper
DEBUG - 2016-10-06 17:26:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 17:26:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 17:26:54 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 17:26:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 17:26:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 17:26:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 17:26:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 17:26:54 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 17:26:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 17:26:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 17:26:54 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 17:26:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 17:26:54 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 17:26:54 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 17:26:54 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 17:26:54 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 17:26:54 --> Database Driver Class Initialized
DEBUG - 2016-10-06 17:26:54 --> Session Class Initialized
DEBUG - 2016-10-06 17:26:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 17:26:54 --> Helper loaded: string_helper
DEBUG - 2016-10-06 17:26:54 --> Session routines successfully run
DEBUG - 2016-10-06 17:26:54 --> Native_session Class Initialized
DEBUG - 2016-10-06 17:26:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 17:26:54 --> Form Validation Class Initialized
DEBUG - 2016-10-06 17:26:54 --> Form Validation Class Initialized
DEBUG - 2016-10-06 17:26:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 17:26:54 --> Controller Class Initialized
DEBUG - 2016-10-06 17:26:54 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 17:26:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 17:26:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 17:26:54 --> Carabiner: library configured.
DEBUG - 2016-10-06 17:26:54 --> Carabiner: library configured.
DEBUG - 2016-10-06 17:26:54 --> User Agent Class Initialized
DEBUG - 2016-10-06 17:26:54 --> Model Class Initialized
DEBUG - 2016-10-06 17:26:54 --> Model Class Initialized
DEBUG - 2016-10-06 17:26:54 --> Model Class Initialized
DEBUG - 2016-10-06 17:26:54 --> Model Class Initialized
DEBUG - 2016-10-06 17:26:54 --> Model Class Initialized
DEBUG - 2016-10-06 17:26:54 --> Model Class Initialized
DEBUG - 2016-10-06 17:26:54 --> Model Class Initialized
DEBUG - 2016-10-06 17:26:54 --> Model Class Initialized
DEBUG - 2016-10-06 17:26:54 --> Model Class Initialized
DEBUG - 2016-10-06 17:26:54 --> Model Class Initialized
DEBUG - 2016-10-06 17:26:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-10-06 17:26:54 --> Form Validation Class Initialized
DEBUG - 2016-10-06 17:26:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 17:26:54 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-10-06 17:26:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-10-06 17:26:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-10-06 17:26:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-10-06 17:26:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-10-06 17:26:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-10-06 17:26:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-10-06 17:26:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 17:26:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-06 17:26:55 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8f8e2926e3f1cbfc3aa536b43cdd0626
DEBUG - 2016-10-06 17:26:55 --> Final output sent to browser
DEBUG - 2016-10-06 17:26:55 --> Total execution time: 0.9223
DEBUG - 2016-10-06 17:27:15 --> Config Class Initialized
DEBUG - 2016-10-06 17:27:15 --> Hooks Class Initialized
DEBUG - 2016-10-06 17:27:15 --> Utf8 Class Initialized
DEBUG - 2016-10-06 17:27:15 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 17:27:15 --> URI Class Initialized
DEBUG - 2016-10-06 17:27:15 --> Router Class Initialized
DEBUG - 2016-10-06 17:27:15 --> Output Class Initialized
DEBUG - 2016-10-06 17:27:15 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 17:27:15 --> Security Class Initialized
DEBUG - 2016-10-06 17:27:15 --> Input Class Initialized
DEBUG - 2016-10-06 17:27:15 --> XSS Filtering completed
DEBUG - 2016-10-06 17:27:15 --> XSS Filtering completed
DEBUG - 2016-10-06 17:27:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 17:27:15 --> Language Class Initialized
DEBUG - 2016-10-06 17:27:15 --> Loader Class Initialized
DEBUG - 2016-10-06 17:27:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 17:27:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 17:27:15 --> Helper loaded: url_helper
DEBUG - 2016-10-06 17:27:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 17:27:15 --> Helper loaded: file_helper
DEBUG - 2016-10-06 17:27:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 17:27:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 17:27:15 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 17:27:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 17:27:15 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 17:27:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 17:27:15 --> Helper loaded: common_helper
DEBUG - 2016-10-06 17:27:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 17:27:15 --> Helper loaded: common_helper
DEBUG - 2016-10-06 17:27:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 17:27:15 --> Helper loaded: form_helper
DEBUG - 2016-10-06 17:27:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 17:27:15 --> Helper loaded: security_helper
DEBUG - 2016-10-06 17:27:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 17:27:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 17:27:15 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 17:27:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 17:27:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 17:27:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 17:27:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 17:27:15 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 17:27:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 17:27:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 17:27:15 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 17:27:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 17:27:15 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 17:27:15 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 17:27:15 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 17:27:15 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 17:27:15 --> Database Driver Class Initialized
DEBUG - 2016-10-06 17:27:15 --> Session Class Initialized
DEBUG - 2016-10-06 17:27:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 17:27:15 --> Helper loaded: string_helper
DEBUG - 2016-10-06 17:27:15 --> Session routines successfully run
DEBUG - 2016-10-06 17:27:15 --> Native_session Class Initialized
DEBUG - 2016-10-06 17:27:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 17:27:15 --> Form Validation Class Initialized
DEBUG - 2016-10-06 17:27:16 --> Form Validation Class Initialized
DEBUG - 2016-10-06 17:27:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 17:27:16 --> Controller Class Initialized
DEBUG - 2016-10-06 17:27:16 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 17:27:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 17:27:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 17:27:16 --> Carabiner: library configured.
DEBUG - 2016-10-06 17:27:16 --> Carabiner: library configured.
DEBUG - 2016-10-06 17:27:16 --> User Agent Class Initialized
DEBUG - 2016-10-06 17:27:16 --> Model Class Initialized
DEBUG - 2016-10-06 17:27:16 --> Model Class Initialized
DEBUG - 2016-10-06 17:27:16 --> Model Class Initialized
DEBUG - 2016-10-06 17:27:16 --> Model Class Initialized
DEBUG - 2016-10-06 17:27:16 --> Model Class Initialized
DEBUG - 2016-10-06 17:27:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-06 17:27:16 --> Pagination Class Initialized
DEBUG - 2016-10-06 17:27:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-10-06 17:27:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/index.php
DEBUG - 2016-10-06 17:27:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-06 17:27:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-06 17:27:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 17:27:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-06 17:27:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-10-06 17:27:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 17:27:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-06 17:27:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-06 17:27:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-06 17:27:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 17:27:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-06 17:27:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-10-06 17:27:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 17:27:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-06 17:27:16 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c2a3e0401bd35d4fcac4bae5f9412231
DEBUG - 2016-10-06 17:27:16 --> Final output sent to browser
DEBUG - 2016-10-06 17:27:16 --> Total execution time: 0.8323
DEBUG - 2016-10-06 17:27:18 --> Config Class Initialized
DEBUG - 2016-10-06 17:27:18 --> Hooks Class Initialized
DEBUG - 2016-10-06 17:27:18 --> Utf8 Class Initialized
DEBUG - 2016-10-06 17:27:18 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 17:27:18 --> URI Class Initialized
DEBUG - 2016-10-06 17:27:18 --> Router Class Initialized
DEBUG - 2016-10-06 17:27:18 --> Output Class Initialized
DEBUG - 2016-10-06 17:27:18 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 17:27:18 --> Security Class Initialized
DEBUG - 2016-10-06 17:27:18 --> Input Class Initialized
DEBUG - 2016-10-06 17:27:18 --> XSS Filtering completed
DEBUG - 2016-10-06 17:27:18 --> XSS Filtering completed
DEBUG - 2016-10-06 17:27:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 17:27:18 --> Language Class Initialized
DEBUG - 2016-10-06 17:27:19 --> Loader Class Initialized
DEBUG - 2016-10-06 17:27:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 17:27:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 17:27:19 --> Helper loaded: url_helper
DEBUG - 2016-10-06 17:27:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 17:27:19 --> Helper loaded: file_helper
DEBUG - 2016-10-06 17:27:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 17:27:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 17:27:19 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 17:27:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 17:27:19 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 17:27:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 17:27:19 --> Helper loaded: common_helper
DEBUG - 2016-10-06 17:27:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 17:27:19 --> Helper loaded: common_helper
DEBUG - 2016-10-06 17:27:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 17:27:19 --> Helper loaded: form_helper
DEBUG - 2016-10-06 17:27:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 17:27:19 --> Helper loaded: security_helper
DEBUG - 2016-10-06 17:27:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 17:27:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 17:27:19 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 17:27:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 17:27:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 17:27:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 17:27:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 17:27:19 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 17:27:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 17:27:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 17:27:19 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 17:27:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 17:27:19 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 17:27:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 17:27:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 17:27:19 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 17:27:19 --> Database Driver Class Initialized
DEBUG - 2016-10-06 17:27:19 --> Session Class Initialized
DEBUG - 2016-10-06 17:27:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 17:27:19 --> Helper loaded: string_helper
DEBUG - 2016-10-06 17:27:19 --> Session routines successfully run
DEBUG - 2016-10-06 17:27:19 --> Native_session Class Initialized
DEBUG - 2016-10-06 17:27:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 17:27:19 --> Form Validation Class Initialized
DEBUG - 2016-10-06 17:27:19 --> Form Validation Class Initialized
DEBUG - 2016-10-06 17:27:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 17:27:19 --> Controller Class Initialized
DEBUG - 2016-10-06 17:27:19 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 17:27:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 17:27:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 17:27:19 --> Carabiner: library configured.
DEBUG - 2016-10-06 17:27:19 --> Carabiner: library configured.
DEBUG - 2016-10-06 17:27:19 --> User Agent Class Initialized
DEBUG - 2016-10-06 17:27:19 --> Model Class Initialized
DEBUG - 2016-10-06 17:27:19 --> Model Class Initialized
DEBUG - 2016-10-06 17:27:19 --> Model Class Initialized
DEBUG - 2016-10-06 17:27:19 --> Model Class Initialized
DEBUG - 2016-10-06 17:27:19 --> Model Class Initialized
DEBUG - 2016-10-06 17:27:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-06 17:27:19 --> Pagination Class Initialized
DEBUG - 2016-10-06 17:27:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-10-06 17:27:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/index.php
DEBUG - 2016-10-06 17:27:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-06 17:27:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-06 17:27:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 17:27:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-06 17:27:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-10-06 17:27:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 17:27:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-06 17:27:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-06 17:27:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-06 17:27:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 17:27:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-06 17:27:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-10-06 17:27:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 17:27:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-06 17:27:19 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c2a3e0401bd35d4fcac4bae5f9412231
DEBUG - 2016-10-06 17:27:19 --> Final output sent to browser
DEBUG - 2016-10-06 17:27:19 --> Total execution time: 0.8611
DEBUG - 2016-10-06 17:29:32 --> Config Class Initialized
DEBUG - 2016-10-06 17:29:32 --> Hooks Class Initialized
DEBUG - 2016-10-06 17:29:32 --> Utf8 Class Initialized
DEBUG - 2016-10-06 17:29:32 --> UTF-8 Support Enabled
DEBUG - 2016-10-06 17:29:32 --> URI Class Initialized
DEBUG - 2016-10-06 17:29:32 --> Router Class Initialized
DEBUG - 2016-10-06 17:29:32 --> Output Class Initialized
DEBUG - 2016-10-06 17:29:32 --> Cache file has expired. File deleted
DEBUG - 2016-10-06 17:29:32 --> Security Class Initialized
DEBUG - 2016-10-06 17:29:32 --> Input Class Initialized
DEBUG - 2016-10-06 17:29:32 --> XSS Filtering completed
DEBUG - 2016-10-06 17:29:32 --> XSS Filtering completed
DEBUG - 2016-10-06 17:29:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-06 17:29:32 --> Language Class Initialized
DEBUG - 2016-10-06 17:29:32 --> Loader Class Initialized
DEBUG - 2016-10-06 17:29:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-06 17:29:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-06 17:29:32 --> Helper loaded: url_helper
DEBUG - 2016-10-06 17:29:32 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-06 17:29:32 --> Helper loaded: file_helper
DEBUG - 2016-10-06 17:29:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 17:29:32 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-06 17:29:32 --> Helper loaded: conf_helper
DEBUG - 2016-10-06 17:29:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-06 17:29:32 --> Check Exists common_helper.php: No
DEBUG - 2016-10-06 17:29:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-06 17:29:32 --> Helper loaded: common_helper
DEBUG - 2016-10-06 17:29:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-06 17:29:32 --> Helper loaded: common_helper
DEBUG - 2016-10-06 17:29:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-06 17:29:32 --> Helper loaded: form_helper
DEBUG - 2016-10-06 17:29:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-06 17:29:32 --> Helper loaded: security_helper
DEBUG - 2016-10-06 17:29:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 17:29:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-06 17:29:32 --> Helper loaded: lang_helper
DEBUG - 2016-10-06 17:29:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-06 17:29:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-06 17:29:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-06 17:29:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-06 17:29:32 --> Helper loaded: atlant_helper
DEBUG - 2016-10-06 17:29:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 17:29:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-06 17:29:32 --> Helper loaded: crypto_helper
DEBUG - 2016-10-06 17:29:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-06 17:29:32 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-06 17:29:32 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-06 17:29:32 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-06 17:29:32 --> Helper loaded: sidika_helper
DEBUG - 2016-10-06 17:29:32 --> Database Driver Class Initialized
DEBUG - 2016-10-06 17:29:32 --> Session Class Initialized
DEBUG - 2016-10-06 17:29:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-06 17:29:33 --> Helper loaded: string_helper
DEBUG - 2016-10-06 17:29:33 --> Session routines successfully run
DEBUG - 2016-10-06 17:29:33 --> Native_session Class Initialized
DEBUG - 2016-10-06 17:29:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-06 17:29:33 --> Form Validation Class Initialized
DEBUG - 2016-10-06 17:29:33 --> Form Validation Class Initialized
DEBUG - 2016-10-06 17:29:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-06 17:29:33 --> Controller Class Initialized
DEBUG - 2016-10-06 17:29:33 --> Carabiner: Library initialized.
DEBUG - 2016-10-06 17:29:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-06 17:29:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-06 17:29:33 --> Carabiner: library configured.
DEBUG - 2016-10-06 17:29:33 --> Carabiner: library configured.
DEBUG - 2016-10-06 17:29:33 --> User Agent Class Initialized
DEBUG - 2016-10-06 17:29:33 --> Model Class Initialized
DEBUG - 2016-10-06 17:29:33 --> Model Class Initialized
DEBUG - 2016-10-06 17:29:33 --> Model Class Initialized
ERROR - 2016-10-06 17:29:33 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-06 17:29:33 --> Model Class Initialized
DEBUG - 2016-10-06 17:29:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-06 17:29:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 17:29:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 17:29:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 17:29:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 17:29:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 17:29:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 17:29:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 17:29:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-06 17:29:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-06 17:29:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-06 17:29:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-06 17:29:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-06 17:29:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-06 17:29:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-06 17:29:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-06 17:29:33 --> Final output sent to browser
DEBUG - 2016-10-06 17:29:33 --> Total execution time: 0.8585
