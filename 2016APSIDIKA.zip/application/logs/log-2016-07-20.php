<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-07-20 08:48:27 --> Config Class Initialized
DEBUG - 2016-07-20 08:48:27 --> Hooks Class Initialized
DEBUG - 2016-07-20 08:48:27 --> Utf8 Class Initialized
DEBUG - 2016-07-20 08:48:27 --> UTF-8 Support Enabled
DEBUG - 2016-07-20 08:48:27 --> URI Class Initialized
DEBUG - 2016-07-20 08:48:27 --> Router Class Initialized
DEBUG - 2016-07-20 08:48:27 --> Output Class Initialized
DEBUG - 2016-07-20 08:48:28 --> Security Class Initialized
DEBUG - 2016-07-20 08:48:28 --> Input Class Initialized
DEBUG - 2016-07-20 08:48:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-20 08:48:28 --> Language Class Initialized
DEBUG - 2016-07-20 08:48:28 --> Loader Class Initialized
DEBUG - 2016-07-20 08:48:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-07-20 08:48:28 --> Check Exists url_helper.php: Yes
DEBUG - 2016-07-20 08:48:28 --> Helper loaded: url_helper
DEBUG - 2016-07-20 08:48:28 --> Check Exists file_helper.php: Yes
DEBUG - 2016-07-20 08:48:28 --> Helper loaded: file_helper
DEBUG - 2016-07-20 08:48:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-07-20 08:48:28 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-07-20 08:48:28 --> Helper loaded: conf_helper
DEBUG - 2016-07-20 08:48:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-07-20 08:48:28 --> Check Exists common_helper.php: No
DEBUG - 2016-07-20 08:48:28 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-07-20 08:48:28 --> Helper loaded: common_helper
DEBUG - 2016-07-20 08:48:28 --> Check Exists common_helper.php: Yes
DEBUG - 2016-07-20 08:48:28 --> Helper loaded: common_helper
DEBUG - 2016-07-20 08:48:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-07-20 08:48:28 --> Helper loaded: form_helper
DEBUG - 2016-07-20 08:48:28 --> Check Exists security_helper.php: Yes
DEBUG - 2016-07-20 08:48:28 --> Helper loaded: security_helper
DEBUG - 2016-07-20 08:48:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-07-20 08:48:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-07-20 08:48:28 --> Helper loaded: lang_helper
DEBUG - 2016-07-20 08:48:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-07-20 08:48:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-07-20 08:48:28 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-07-20 08:48:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-07-20 08:48:28 --> Helper loaded: atlant_helper
DEBUG - 2016-07-20 08:48:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-07-20 08:48:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-07-20 08:48:29 --> Helper loaded: crypto_helper
DEBUG - 2016-07-20 08:48:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-07-20 08:48:29 --> Database Driver Class Initialized
ERROR - 2016-07-20 08:48:29 --> Severity: Warning  --> pg_connect(): Unable to connect to PostgreSQL server: FATAL:  database &quot;db_sidika&quot; does not exist E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 87
ERROR - 2016-07-20 08:48:29 --> Unable to connect to the database
DEBUG - 2016-07-20 08:48:29 --> Language file loaded: language/indonesia/db_lang.php
