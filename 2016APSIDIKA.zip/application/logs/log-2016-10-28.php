<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-10-28 15:04:18 --> Config Class Initialized
DEBUG - 2016-10-28 15:04:18 --> Hooks Class Initialized
DEBUG - 2016-10-28 15:04:18 --> Utf8 Class Initialized
DEBUG - 2016-10-28 15:04:18 --> UTF-8 Support Enabled
DEBUG - 2016-10-28 15:04:18 --> URI Class Initialized
DEBUG - 2016-10-28 15:04:18 --> Router Class Initialized
DEBUG - 2016-10-28 15:04:18 --> No URI present. Default controller set.
DEBUG - 2016-10-28 15:04:18 --> Output Class Initialized
DEBUG - 2016-10-28 15:04:18 --> Security Class Initialized
DEBUG - 2016-10-28 15:04:19 --> Input Class Initialized
DEBUG - 2016-10-28 15:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-28 15:04:19 --> Language Class Initialized
DEBUG - 2016-10-28 15:04:19 --> Loader Class Initialized
DEBUG - 2016-10-28 15:04:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-28 15:04:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-28 15:04:19 --> Helper loaded: url_helper
DEBUG - 2016-10-28 15:04:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-28 15:04:19 --> Helper loaded: file_helper
DEBUG - 2016-10-28 15:04:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-28 15:04:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-28 15:04:19 --> Helper loaded: conf_helper
DEBUG - 2016-10-28 15:04:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-28 15:04:19 --> Check Exists common_helper.php: No
DEBUG - 2016-10-28 15:04:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-28 15:04:19 --> Helper loaded: common_helper
DEBUG - 2016-10-28 15:04:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-28 15:04:19 --> Helper loaded: common_helper
DEBUG - 2016-10-28 15:04:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-28 15:04:19 --> Helper loaded: form_helper
DEBUG - 2016-10-28 15:04:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-28 15:04:19 --> Helper loaded: security_helper
DEBUG - 2016-10-28 15:04:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-28 15:04:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-28 15:04:19 --> Helper loaded: lang_helper
DEBUG - 2016-10-28 15:04:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-28 15:04:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-28 15:04:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-28 15:04:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-28 15:04:19 --> Helper loaded: atlant_helper
DEBUG - 2016-10-28 15:04:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-28 15:04:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-28 15:04:19 --> Helper loaded: crypto_helper
DEBUG - 2016-10-28 15:04:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-28 15:04:19 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-28 15:04:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-28 15:04:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-28 15:04:19 --> Helper loaded: sidika_helper
DEBUG - 2016-10-28 15:04:19 --> Database Driver Class Initialized
ERROR - 2016-10-28 15:04:20 --> Severity: Warning  --> pg_connect(): Unable to connect to PostgreSQL server: could not connect to server: Connection refused (0x0000274D/10061)
	Is the server running on host &quot;127.0.0.1&quot; and accepting
	TCP/IP connections on port 5432? E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 87
ERROR - 2016-10-28 15:04:20 --> Unable to connect to the database
DEBUG - 2016-10-28 15:04:20 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-10-28 17:55:12 --> Config Class Initialized
DEBUG - 2016-10-28 17:55:12 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:55:12 --> Utf8 Class Initialized
DEBUG - 2016-10-28 17:55:12 --> UTF-8 Support Enabled
DEBUG - 2016-10-28 17:55:12 --> URI Class Initialized
DEBUG - 2016-10-28 17:55:12 --> Router Class Initialized
DEBUG - 2016-10-28 17:55:12 --> No URI present. Default controller set.
DEBUG - 2016-10-28 17:55:12 --> Output Class Initialized
DEBUG - 2016-10-28 17:55:12 --> Security Class Initialized
DEBUG - 2016-10-28 17:55:12 --> Input Class Initialized
DEBUG - 2016-10-28 17:55:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-28 17:55:12 --> Language Class Initialized
DEBUG - 2016-10-28 17:55:12 --> Loader Class Initialized
DEBUG - 2016-10-28 17:55:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-28 17:55:12 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-28 17:55:12 --> Helper loaded: url_helper
DEBUG - 2016-10-28 17:55:12 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-28 17:55:12 --> Helper loaded: file_helper
DEBUG - 2016-10-28 17:55:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-28 17:55:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-28 17:55:12 --> Helper loaded: conf_helper
DEBUG - 2016-10-28 17:55:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-28 17:55:12 --> Check Exists common_helper.php: No
DEBUG - 2016-10-28 17:55:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-28 17:55:12 --> Helper loaded: common_helper
DEBUG - 2016-10-28 17:55:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-28 17:55:12 --> Helper loaded: common_helper
DEBUG - 2016-10-28 17:55:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-28 17:55:12 --> Helper loaded: form_helper
DEBUG - 2016-10-28 17:55:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-28 17:55:12 --> Helper loaded: security_helper
DEBUG - 2016-10-28 17:55:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-28 17:55:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-28 17:55:12 --> Helper loaded: lang_helper
DEBUG - 2016-10-28 17:55:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-28 17:55:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-28 17:55:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-28 17:55:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-28 17:55:12 --> Helper loaded: atlant_helper
DEBUG - 2016-10-28 17:55:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-28 17:55:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-28 17:55:12 --> Helper loaded: crypto_helper
DEBUG - 2016-10-28 17:55:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-28 17:55:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-28 17:55:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-28 17:55:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-28 17:55:12 --> Helper loaded: sidika_helper
DEBUG - 2016-10-28 17:55:12 --> Database Driver Class Initialized
DEBUG - 2016-10-28 17:55:12 --> Session Class Initialized
DEBUG - 2016-10-28 17:55:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-28 17:55:12 --> Helper loaded: string_helper
DEBUG - 2016-10-28 17:55:12 --> A session cookie was not found.
DEBUG - 2016-10-28 17:55:12 --> Session routines successfully run
DEBUG - 2016-10-28 17:55:12 --> Native_session Class Initialized
DEBUG - 2016-10-28 17:55:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-28 17:55:13 --> Form Validation Class Initialized
DEBUG - 2016-10-28 17:55:13 --> Form Validation Class Initialized
DEBUG - 2016-10-28 17:55:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-28 17:55:13 --> Controller Class Initialized
DEBUG - 2016-10-28 17:55:13 --> Carabiner: Library initialized.
DEBUG - 2016-10-28 17:55:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-28 17:55:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-28 17:55:13 --> Carabiner: library configured.
DEBUG - 2016-10-28 17:55:13 --> Carabiner: library configured.
DEBUG - 2016-10-28 17:55:13 --> User Agent Class Initialized
DEBUG - 2016-10-28 17:55:13 --> Model Class Initialized
DEBUG - 2016-10-28 17:55:13 --> Model Class Initialized
DEBUG - 2016-10-28 17:55:13 --> Model Class Initialized
ERROR - 2016-10-28 17:55:13 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-10-28 17:55:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-10-28 17:55:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-10-28 17:55:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-28 17:55:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-28 17:55:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-28 17:55:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-28 17:55:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-28 17:55:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-28 17:55:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-28 17:55:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-28 17:55:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-28 17:55:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-28 17:55:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-28 17:55:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-28 17:55:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-28 17:55:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-28 17:55:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-28 17:55:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-28 17:55:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-28 17:55:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-28 17:55:13 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-10-28 17:55:13 --> Final output sent to browser
DEBUG - 2016-10-28 17:55:13 --> Total execution time: 1.1505
DEBUG - 2016-10-28 17:55:14 --> Config Class Initialized
DEBUG - 2016-10-28 17:55:14 --> Hooks Class Initialized
DEBUG - 2016-10-28 17:55:14 --> Utf8 Class Initialized
DEBUG - 2016-10-28 17:55:14 --> UTF-8 Support Enabled
DEBUG - 2016-10-28 17:55:14 --> URI Class Initialized
DEBUG - 2016-10-28 17:55:14 --> Router Class Initialized
DEBUG - 2016-10-28 17:55:14 --> Output Class Initialized
DEBUG - 2016-10-28 17:55:14 --> Cache file has expired. File deleted
DEBUG - 2016-10-28 17:55:14 --> Security Class Initialized
DEBUG - 2016-10-28 17:55:14 --> Input Class Initialized
DEBUG - 2016-10-28 17:55:14 --> XSS Filtering completed
DEBUG - 2016-10-28 17:55:14 --> XSS Filtering completed
DEBUG - 2016-10-28 17:55:14 --> XSS Filtering completed
DEBUG - 2016-10-28 17:55:14 --> XSS Filtering completed
DEBUG - 2016-10-28 17:55:14 --> XSS Filtering completed
DEBUG - 2016-10-28 17:55:14 --> XSS Filtering completed
DEBUG - 2016-10-28 17:55:14 --> XSS Filtering completed
DEBUG - 2016-10-28 17:55:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-28 17:55:14 --> Language Class Initialized
DEBUG - 2016-10-28 17:55:14 --> Loader Class Initialized
DEBUG - 2016-10-28 17:55:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-28 17:55:14 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-28 17:55:14 --> Helper loaded: url_helper
DEBUG - 2016-10-28 17:55:14 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-28 17:55:14 --> Helper loaded: file_helper
DEBUG - 2016-10-28 17:55:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-28 17:55:14 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-28 17:55:14 --> Helper loaded: conf_helper
DEBUG - 2016-10-28 17:55:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-28 17:55:14 --> Check Exists common_helper.php: No
DEBUG - 2016-10-28 17:55:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-28 17:55:14 --> Helper loaded: common_helper
DEBUG - 2016-10-28 17:55:14 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-28 17:55:14 --> Helper loaded: common_helper
DEBUG - 2016-10-28 17:55:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-28 17:55:14 --> Helper loaded: form_helper
DEBUG - 2016-10-28 17:55:14 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-28 17:55:14 --> Helper loaded: security_helper
DEBUG - 2016-10-28 17:55:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-28 17:55:14 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-28 17:55:14 --> Helper loaded: lang_helper
DEBUG - 2016-10-28 17:55:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-28 17:55:14 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-28 17:55:14 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-28 17:55:14 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-28 17:55:14 --> Helper loaded: atlant_helper
DEBUG - 2016-10-28 17:55:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-28 17:55:14 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-28 17:55:14 --> Helper loaded: crypto_helper
DEBUG - 2016-10-28 17:55:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-28 17:55:14 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-28 17:55:14 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-28 17:55:14 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-28 17:55:14 --> Helper loaded: sidika_helper
DEBUG - 2016-10-28 17:55:14 --> Database Driver Class Initialized
DEBUG - 2016-10-28 17:55:15 --> Session Class Initialized
DEBUG - 2016-10-28 17:55:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-28 17:55:15 --> Helper loaded: string_helper
DEBUG - 2016-10-28 17:55:15 --> Session routines successfully run
DEBUG - 2016-10-28 17:55:15 --> Native_session Class Initialized
DEBUG - 2016-10-28 17:55:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-28 17:55:15 --> Form Validation Class Initialized
DEBUG - 2016-10-28 17:55:15 --> Form Validation Class Initialized
DEBUG - 2016-10-28 17:55:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-28 17:55:15 --> Controller Class Initialized
DEBUG - 2016-10-28 17:55:15 --> Carabiner: Library initialized.
DEBUG - 2016-10-28 17:55:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-28 17:55:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-28 17:55:15 --> Carabiner: library configured.
DEBUG - 2016-10-28 17:55:15 --> Carabiner: library configured.
DEBUG - 2016-10-28 17:55:15 --> User Agent Class Initialized
DEBUG - 2016-10-28 17:55:15 --> Model Class Initialized
DEBUG - 2016-10-28 17:55:15 --> Model Class Initialized
DEBUG - 2016-10-28 17:55:15 --> Model Class Initialized
DEBUG - 2016-10-28 17:55:15 --> Model Class Initialized
DEBUG - 2016-10-28 17:55:15 --> Model Class Initialized
DEBUG - 2016-10-28 17:55:15 --> Model Class Initialized
DEBUG - 2016-10-28 17:55:15 --> Model Class Initialized
DEBUG - 2016-10-28 17:55:17 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-10-28 17:55:17 --> Final output sent to browser
DEBUG - 2016-10-28 17:55:17 --> Total execution time: 2.5655
