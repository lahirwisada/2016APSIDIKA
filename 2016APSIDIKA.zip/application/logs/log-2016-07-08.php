<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-07-08 16:52:38 --> Config Class Initialized
DEBUG - 2016-07-08 16:52:38 --> Hooks Class Initialized
DEBUG - 2016-07-08 16:52:38 --> Utf8 Class Initialized
DEBUG - 2016-07-08 16:52:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-08 16:52:38 --> URI Class Initialized
DEBUG - 2016-07-08 16:52:38 --> Router Class Initialized
DEBUG - 2016-07-08 16:52:38 --> Output Class Initialized
DEBUG - 2016-07-08 16:52:38 --> Cache file has expired. File deleted
DEBUG - 2016-07-08 16:52:39 --> Security Class Initialized
DEBUG - 2016-07-08 16:52:39 --> Input Class Initialized
DEBUG - 2016-07-08 16:52:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-08 16:52:39 --> Language Class Initialized
DEBUG - 2016-07-08 16:52:39 --> Loader Class Initialized
DEBUG - 2016-07-08 16:52:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-07-08 16:52:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-07-08 16:52:39 --> Helper loaded: url_helper
DEBUG - 2016-07-08 16:52:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-07-08 16:52:39 --> Helper loaded: file_helper
DEBUG - 2016-07-08 16:52:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-07-08 16:52:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-07-08 16:52:39 --> Helper loaded: conf_helper
DEBUG - 2016-07-08 16:52:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-07-08 16:52:39 --> Check Exists common_helper.php: No
DEBUG - 2016-07-08 16:52:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-07-08 16:52:39 --> Helper loaded: common_helper
DEBUG - 2016-07-08 16:52:39 --> Check Exists common_helper.php: Yes
DEBUG - 2016-07-08 16:52:39 --> Helper loaded: common_helper
DEBUG - 2016-07-08 16:52:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-07-08 16:52:39 --> Helper loaded: form_helper
DEBUG - 2016-07-08 16:52:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-07-08 16:52:39 --> Helper loaded: security_helper
DEBUG - 2016-07-08 16:52:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-07-08 16:52:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-07-08 16:52:39 --> Helper loaded: lang_helper
DEBUG - 2016-07-08 16:52:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-07-08 16:52:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-07-08 16:52:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-07-08 16:52:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-07-08 16:52:39 --> Helper loaded: atlant_helper
DEBUG - 2016-07-08 16:52:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-07-08 16:52:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-07-08 16:52:39 --> Helper loaded: crypto_helper
DEBUG - 2016-07-08 16:52:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-07-08 16:52:39 --> Database Driver Class Initialized
DEBUG - 2016-07-08 16:52:39 --> Session Class Initialized
DEBUG - 2016-07-08 16:52:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-07-08 16:52:39 --> Helper loaded: string_helper
DEBUG - 2016-07-08 16:52:39 --> A session cookie was not found.
DEBUG - 2016-07-08 16:52:39 --> Session routines successfully run
DEBUG - 2016-07-08 16:52:39 --> Native_session Class Initialized
DEBUG - 2016-07-08 16:52:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-07-08 16:52:40 --> Form Validation Class Initialized
DEBUG - 2016-07-08 16:52:40 --> Form Validation Class Initialized
DEBUG - 2016-07-08 16:52:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-07-08 16:52:40 --> Controller Class Initialized
DEBUG - 2016-07-08 16:52:40 --> Carabiner: Library initialized.
DEBUG - 2016-07-08 16:52:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-07-08 16:52:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-07-08 16:52:40 --> Carabiner: library configured.
DEBUG - 2016-07-08 16:52:40 --> Carabiner: library configured.
DEBUG - 2016-07-08 16:52:40 --> User Agent Class Initialized
DEBUG - 2016-07-08 16:52:40 --> Model Class Initialized
DEBUG - 2016-07-08 16:52:40 --> Model Class Initialized
DEBUG - 2016-07-08 16:52:41 --> Model Class Initialized
DEBUG - 2016-07-08 16:52:42 --> Model Class Initialized
DEBUG - 2016-07-08 16:52:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-07-08 16:52:43 --> Pagination Class Initialized
DEBUG - 2016-07-08 16:52:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-07-08 16:52:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/index.php
DEBUG - 2016-07-08 16:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-07-08 16:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-07-08 16:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-07-08 16:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-07-08 16:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-07-08 16:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-07-08 16:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-07-08 16:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-07-08 16:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-07-08 16:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-07-08 16:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-07-08 16:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-07-08 16:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-07-08 16:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-07-08 16:52:44 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0afc8ae14bdb2df5b4e2fbf4366db4fc
DEBUG - 2016-07-08 16:52:44 --> Final output sent to browser
DEBUG - 2016-07-08 16:52:44 --> Total execution time: 5.0737
DEBUG - 2016-07-08 16:52:57 --> Config Class Initialized
DEBUG - 2016-07-08 16:52:57 --> Hooks Class Initialized
DEBUG - 2016-07-08 16:52:57 --> Utf8 Class Initialized
DEBUG - 2016-07-08 16:52:57 --> UTF-8 Support Enabled
DEBUG - 2016-07-08 16:52:57 --> URI Class Initialized
DEBUG - 2016-07-08 16:52:57 --> Router Class Initialized
ERROR - 2016-07-08 16:52:57 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-07-08 16:53:04 --> Config Class Initialized
DEBUG - 2016-07-08 16:53:04 --> Hooks Class Initialized
DEBUG - 2016-07-08 16:53:04 --> Utf8 Class Initialized
DEBUG - 2016-07-08 16:53:04 --> UTF-8 Support Enabled
DEBUG - 2016-07-08 16:53:04 --> URI Class Initialized
DEBUG - 2016-07-08 16:53:04 --> Router Class Initialized
DEBUG - 2016-07-08 16:53:04 --> Output Class Initialized
DEBUG - 2016-07-08 16:53:04 --> Cache file has expired. File deleted
DEBUG - 2016-07-08 16:53:04 --> Security Class Initialized
DEBUG - 2016-07-08 16:53:04 --> Input Class Initialized
DEBUG - 2016-07-08 16:53:04 --> XSS Filtering completed
DEBUG - 2016-07-08 16:53:04 --> XSS Filtering completed
DEBUG - 2016-07-08 16:53:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-08 16:53:04 --> Language Class Initialized
DEBUG - 2016-07-08 16:53:04 --> Loader Class Initialized
DEBUG - 2016-07-08 16:53:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-07-08 16:53:04 --> Check Exists url_helper.php: Yes
DEBUG - 2016-07-08 16:53:04 --> Helper loaded: url_helper
DEBUG - 2016-07-08 16:53:04 --> Check Exists file_helper.php: Yes
DEBUG - 2016-07-08 16:53:04 --> Helper loaded: file_helper
DEBUG - 2016-07-08 16:53:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-07-08 16:53:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-07-08 16:53:04 --> Helper loaded: conf_helper
DEBUG - 2016-07-08 16:53:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-07-08 16:53:04 --> Check Exists common_helper.php: No
DEBUG - 2016-07-08 16:53:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-07-08 16:53:04 --> Helper loaded: common_helper
DEBUG - 2016-07-08 16:53:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-07-08 16:53:04 --> Helper loaded: common_helper
DEBUG - 2016-07-08 16:53:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-07-08 16:53:04 --> Helper loaded: form_helper
DEBUG - 2016-07-08 16:53:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-07-08 16:53:04 --> Helper loaded: security_helper
DEBUG - 2016-07-08 16:53:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-07-08 16:53:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-07-08 16:53:05 --> Helper loaded: lang_helper
DEBUG - 2016-07-08 16:53:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-07-08 16:53:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-07-08 16:53:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-07-08 16:53:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-07-08 16:53:05 --> Helper loaded: atlant_helper
DEBUG - 2016-07-08 16:53:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-07-08 16:53:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-07-08 16:53:05 --> Helper loaded: crypto_helper
DEBUG - 2016-07-08 16:53:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-07-08 16:53:05 --> Database Driver Class Initialized
DEBUG - 2016-07-08 16:53:05 --> Session Class Initialized
DEBUG - 2016-07-08 16:53:05 --> Check Exists string_helper.php: Yes
DEBUG - 2016-07-08 16:53:05 --> Helper loaded: string_helper
DEBUG - 2016-07-08 16:53:05 --> Session routines successfully run
DEBUG - 2016-07-08 16:53:05 --> Native_session Class Initialized
DEBUG - 2016-07-08 16:53:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-07-08 16:53:05 --> Form Validation Class Initialized
DEBUG - 2016-07-08 16:53:05 --> Form Validation Class Initialized
DEBUG - 2016-07-08 16:53:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-07-08 16:53:05 --> Controller Class Initialized
DEBUG - 2016-07-08 16:53:05 --> Carabiner: Library initialized.
DEBUG - 2016-07-08 16:53:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-07-08 16:53:05 --> Carabiner: config loaded from config file.
DEBUG - 2016-07-08 16:53:05 --> Carabiner: library configured.
DEBUG - 2016-07-08 16:53:05 --> Carabiner: library configured.
DEBUG - 2016-07-08 16:53:05 --> User Agent Class Initialized
DEBUG - 2016-07-08 16:53:05 --> Model Class Initialized
DEBUG - 2016-07-08 16:53:05 --> Model Class Initialized
DEBUG - 2016-07-08 16:53:05 --> Model Class Initialized
DEBUG - 2016-07-08 16:53:05 --> Model Class Initialized
DEBUG - 2016-07-08 16:53:05 --> Model Class Initialized
DEBUG - 2016-07-08 16:53:05 --> Model Class Initialized
DEBUG - 2016-07-08 16:53:05 --> Model Class Initialized
DEBUG - 2016-07-08 16:53:05 --> Model Class Initialized
DEBUG - 2016-07-08 16:53:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-07-08 16:53:07 --> Pagination Class Initialized
DEBUG - 2016-07-08 16:53:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-07-08 16:53:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-07-08 16:53:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-07-08 16:53:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-07-08 16:53:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-07-08 16:53:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-07-08 16:53:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-07-08 16:53:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-07-08 16:53:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-07-08 16:53:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-07-08 16:53:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-07-08 16:53:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-07-08 16:53:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-07-08 16:53:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-07-08 16:53:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-07-08 16:53:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-07-08 16:53:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-07-08 16:53:07 --> Final output sent to browser
DEBUG - 2016-07-08 16:53:07 --> Total execution time: 2.4491
DEBUG - 2016-07-08 16:53:08 --> Config Class Initialized
DEBUG - 2016-07-08 16:53:08 --> Hooks Class Initialized
DEBUG - 2016-07-08 16:53:08 --> Utf8 Class Initialized
DEBUG - 2016-07-08 16:53:08 --> UTF-8 Support Enabled
DEBUG - 2016-07-08 16:53:08 --> URI Class Initialized
DEBUG - 2016-07-08 16:53:08 --> Router Class Initialized
ERROR - 2016-07-08 16:53:08 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-07-08 16:53:25 --> Config Class Initialized
DEBUG - 2016-07-08 16:53:25 --> Hooks Class Initialized
DEBUG - 2016-07-08 16:53:25 --> Utf8 Class Initialized
DEBUG - 2016-07-08 16:53:25 --> UTF-8 Support Enabled
DEBUG - 2016-07-08 16:53:25 --> URI Class Initialized
DEBUG - 2016-07-08 16:53:25 --> Router Class Initialized
DEBUG - 2016-07-08 16:53:25 --> Output Class Initialized
DEBUG - 2016-07-08 16:53:25 --> Security Class Initialized
DEBUG - 2016-07-08 16:53:25 --> Input Class Initialized
DEBUG - 2016-07-08 16:53:25 --> XSS Filtering completed
DEBUG - 2016-07-08 16:53:25 --> XSS Filtering completed
DEBUG - 2016-07-08 16:53:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-08 16:53:25 --> Language Class Initialized
DEBUG - 2016-07-08 16:53:25 --> Loader Class Initialized
DEBUG - 2016-07-08 16:53:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-07-08 16:53:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-07-08 16:53:25 --> Helper loaded: url_helper
DEBUG - 2016-07-08 16:53:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-07-08 16:53:25 --> Helper loaded: file_helper
DEBUG - 2016-07-08 16:53:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-07-08 16:53:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-07-08 16:53:25 --> Helper loaded: conf_helper
DEBUG - 2016-07-08 16:53:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-07-08 16:53:25 --> Check Exists common_helper.php: No
DEBUG - 2016-07-08 16:53:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-07-08 16:53:25 --> Helper loaded: common_helper
DEBUG - 2016-07-08 16:53:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-07-08 16:53:25 --> Helper loaded: common_helper
DEBUG - 2016-07-08 16:53:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-07-08 16:53:25 --> Helper loaded: form_helper
DEBUG - 2016-07-08 16:53:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-07-08 16:53:25 --> Helper loaded: security_helper
DEBUG - 2016-07-08 16:53:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-07-08 16:53:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-07-08 16:53:25 --> Helper loaded: lang_helper
DEBUG - 2016-07-08 16:53:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-07-08 16:53:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-07-08 16:53:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-07-08 16:53:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-07-08 16:53:25 --> Helper loaded: atlant_helper
DEBUG - 2016-07-08 16:53:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-07-08 16:53:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-07-08 16:53:25 --> Helper loaded: crypto_helper
DEBUG - 2016-07-08 16:53:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-07-08 16:53:25 --> Database Driver Class Initialized
DEBUG - 2016-07-08 16:53:26 --> Session Class Initialized
DEBUG - 2016-07-08 16:53:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-07-08 16:53:26 --> Helper loaded: string_helper
DEBUG - 2016-07-08 16:53:26 --> Session routines successfully run
DEBUG - 2016-07-08 16:53:26 --> Native_session Class Initialized
DEBUG - 2016-07-08 16:53:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-07-08 16:53:26 --> Form Validation Class Initialized
DEBUG - 2016-07-08 16:53:26 --> Form Validation Class Initialized
DEBUG - 2016-07-08 16:53:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-07-08 16:53:26 --> Controller Class Initialized
DEBUG - 2016-07-08 16:53:26 --> Carabiner: Library initialized.
DEBUG - 2016-07-08 16:53:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-07-08 16:53:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-07-08 16:53:26 --> Carabiner: library configured.
DEBUG - 2016-07-08 16:53:26 --> Carabiner: library configured.
DEBUG - 2016-07-08 16:53:26 --> User Agent Class Initialized
DEBUG - 2016-07-08 16:53:26 --> Model Class Initialized
DEBUG - 2016-07-08 16:53:26 --> Model Class Initialized
DEBUG - 2016-07-08 16:53:26 --> Model Class Initialized
DEBUG - 2016-07-08 16:53:26 --> Model Class Initialized
DEBUG - 2016-07-08 16:53:26 --> Model Class Initialized
DEBUG - 2016-07-08 16:53:26 --> Model Class Initialized
DEBUG - 2016-07-08 16:53:26 --> Model Class Initialized
DEBUG - 2016-07-08 16:53:26 --> Model Class Initialized
DEBUG - 2016-07-08 16:53:26 --> Model Class Initialized
ERROR - 2016-07-08 16:53:27 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:172) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
