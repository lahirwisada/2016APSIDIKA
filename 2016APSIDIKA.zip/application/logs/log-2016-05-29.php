<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-05-29 22:02:27 --> Config Class Initialized
DEBUG - 2016-05-29 22:02:34 --> Hooks Class Initialized
DEBUG - 2016-05-29 22:02:34 --> Utf8 Class Initialized
DEBUG - 2016-05-29 22:02:34 --> UTF-8 Support Enabled
DEBUG - 2016-05-29 22:02:34 --> URI Class Initialized
DEBUG - 2016-05-29 22:02:35 --> Router Class Initialized
DEBUG - 2016-05-29 22:02:36 --> Output Class Initialized
DEBUG - 2016-05-29 22:02:38 --> Cache file has expired. File deleted
DEBUG - 2016-05-29 22:02:39 --> Security Class Initialized
DEBUG - 2016-05-29 22:02:39 --> Input Class Initialized
DEBUG - 2016-05-29 22:02:39 --> XSS Filtering completed
DEBUG - 2016-05-29 22:02:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-29 22:02:39 --> Language Class Initialized
DEBUG - 2016-05-29 22:02:40 --> Loader Class Initialized
DEBUG - 2016-05-29 22:02:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-29 22:02:41 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-29 22:02:41 --> Helper loaded: url_helper
DEBUG - 2016-05-29 22:02:41 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-29 22:02:41 --> Helper loaded: file_helper
DEBUG - 2016-05-29 22:02:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-29 22:02:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-29 22:02:42 --> Helper loaded: conf_helper
DEBUG - 2016-05-29 22:02:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-29 22:02:42 --> Check Exists common_helper.php: No
DEBUG - 2016-05-29 22:02:42 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-29 22:02:42 --> Helper loaded: common_helper
DEBUG - 2016-05-29 22:02:42 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-29 22:02:42 --> Helper loaded: common_helper
DEBUG - 2016-05-29 22:02:42 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-29 22:02:42 --> Helper loaded: form_helper
DEBUG - 2016-05-29 22:02:42 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-29 22:02:43 --> Helper loaded: security_helper
DEBUG - 2016-05-29 22:02:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-29 22:02:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-29 22:02:43 --> Helper loaded: lang_helper
DEBUG - 2016-05-29 22:02:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-29 22:02:43 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-29 22:02:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-29 22:02:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-29 22:02:43 --> Helper loaded: atlant_helper
DEBUG - 2016-05-29 22:02:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-29 22:02:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-29 22:02:43 --> Helper loaded: crypto_helper
DEBUG - 2016-05-29 22:02:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-29 22:02:43 --> Database Driver Class Initialized
DEBUG - 2016-05-29 22:02:44 --> Session Class Initialized
DEBUG - 2016-05-29 22:02:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-29 22:02:44 --> Helper loaded: string_helper
DEBUG - 2016-05-29 22:02:44 --> A session cookie was not found.
DEBUG - 2016-05-29 22:02:44 --> Session routines successfully run
DEBUG - 2016-05-29 22:02:44 --> Native_session Class Initialized
DEBUG - 2016-05-29 22:02:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-29 22:02:45 --> Form Validation Class Initialized
DEBUG - 2016-05-29 22:02:45 --> Form Validation Class Initialized
DEBUG - 2016-05-29 22:02:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-29 22:02:45 --> Controller Class Initialized
DEBUG - 2016-05-29 22:02:45 --> Carabiner: Library initialized.
DEBUG - 2016-05-29 22:02:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-29 22:02:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-29 22:02:45 --> Carabiner: library configured.
DEBUG - 2016-05-29 22:02:45 --> Carabiner: library configured.
DEBUG - 2016-05-29 22:02:45 --> User Agent Class Initialized
DEBUG - 2016-05-29 22:02:46 --> Model Class Initialized
DEBUG - 2016-05-29 22:02:46 --> Model Class Initialized
DEBUG - 2016-05-29 22:02:46 --> Model Class Initialized
DEBUG - 2016-05-29 22:02:47 --> Model Class Initialized
DEBUG - 2016-05-29 22:02:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-29 22:02:47 --> Pagination Class Initialized
DEBUG - 2016-05-29 22:02:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-29 22:02:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/index.php
DEBUG - 2016-05-29 22:02:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-29 22:02:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-29 22:02:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-29 22:02:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-29 22:02:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-05-29 22:02:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-29 22:02:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-29 22:02:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-29 22:02:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-29 22:02:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-29 22:02:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-29 22:02:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-05-29 22:02:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-29 22:02:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-29 22:02:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0afc8ae14bdb2df5b4e2fbf4366db4fc
DEBUG - 2016-05-29 22:02:48 --> Final output sent to browser
DEBUG - 2016-05-29 22:02:48 --> Total execution time: 20.4523
DEBUG - 2016-05-29 22:03:03 --> Config Class Initialized
DEBUG - 2016-05-29 22:03:03 --> Hooks Class Initialized
DEBUG - 2016-05-29 22:03:03 --> Utf8 Class Initialized
DEBUG - 2016-05-29 22:03:03 --> UTF-8 Support Enabled
DEBUG - 2016-05-29 22:03:03 --> URI Class Initialized
DEBUG - 2016-05-29 22:03:03 --> Router Class Initialized
ERROR - 2016-05-29 22:03:04 --> 404 Page Not Found --> back_end/favicon.ico
