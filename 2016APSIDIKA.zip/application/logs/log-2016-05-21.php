<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-05-21 01:30:28 --> Config Class Initialized
DEBUG - 2016-05-21 01:30:28 --> Hooks Class Initialized
DEBUG - 2016-05-21 01:30:28 --> Utf8 Class Initialized
DEBUG - 2016-05-21 01:30:28 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 01:30:28 --> URI Class Initialized
DEBUG - 2016-05-21 01:30:28 --> Router Class Initialized
DEBUG - 2016-05-21 01:30:28 --> Output Class Initialized
DEBUG - 2016-05-21 01:30:28 --> Security Class Initialized
DEBUG - 2016-05-21 01:30:28 --> Input Class Initialized
DEBUG - 2016-05-21 01:30:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 01:30:28 --> Language Class Initialized
DEBUG - 2016-05-21 01:30:28 --> Loader Class Initialized
DEBUG - 2016-05-21 01:30:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 01:30:28 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 01:30:28 --> Helper loaded: url_helper
DEBUG - 2016-05-21 01:30:28 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 01:30:28 --> Helper loaded: file_helper
DEBUG - 2016-05-21 01:30:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 01:30:28 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 01:30:28 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 01:30:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 01:30:28 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 01:30:28 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 01:30:28 --> Helper loaded: common_helper
DEBUG - 2016-05-21 01:30:28 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 01:30:28 --> Helper loaded: common_helper
DEBUG - 2016-05-21 01:30:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 01:30:28 --> Helper loaded: form_helper
DEBUG - 2016-05-21 01:30:28 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 01:30:28 --> Helper loaded: security_helper
DEBUG - 2016-05-21 01:30:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 01:30:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 01:30:28 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 01:30:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 01:30:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 01:30:28 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 01:30:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 01:30:28 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 01:30:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 01:30:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 01:30:28 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 01:30:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 01:30:28 --> Database Driver Class Initialized
DEBUG - 2016-05-21 01:30:28 --> Session Class Initialized
DEBUG - 2016-05-21 01:30:28 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 01:30:28 --> Helper loaded: string_helper
DEBUG - 2016-05-21 01:30:28 --> A session cookie was not found.
DEBUG - 2016-05-21 01:30:28 --> Session routines successfully run
DEBUG - 2016-05-21 01:30:28 --> Native_session Class Initialized
DEBUG - 2016-05-21 01:30:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 01:30:28 --> Form Validation Class Initialized
DEBUG - 2016-05-21 01:30:28 --> Form Validation Class Initialized
DEBUG - 2016-05-21 01:30:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 01:30:29 --> Controller Class Initialized
DEBUG - 2016-05-21 01:30:29 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 01:30:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 01:30:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 01:30:29 --> Carabiner: library configured.
DEBUG - 2016-05-21 01:30:29 --> Carabiner: library configured.
DEBUG - 2016-05-21 01:30:29 --> User Agent Class Initialized
DEBUG - 2016-05-21 01:30:29 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:29 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:29 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:29 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-21 01:30:29 --> Pagination Class Initialized
DEBUG - 2016-05-21 01:30:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-21 01:30:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/index.php
DEBUG - 2016-05-21 01:30:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-21 01:30:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-21 01:30:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-21 01:30:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-21 01:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-05-21 01:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-21 01:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-21 01:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-21 01:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-21 01:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-21 01:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-21 01:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-05-21 01:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-21 01:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-21 01:30:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0afc8ae14bdb2df5b4e2fbf4366db4fc
DEBUG - 2016-05-21 01:30:30 --> Final output sent to browser
DEBUG - 2016-05-21 01:30:30 --> Total execution time: 1.8479
DEBUG - 2016-05-21 01:30:33 --> Config Class Initialized
DEBUG - 2016-05-21 01:30:33 --> Hooks Class Initialized
DEBUG - 2016-05-21 01:30:33 --> Utf8 Class Initialized
DEBUG - 2016-05-21 01:30:33 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 01:30:33 --> URI Class Initialized
DEBUG - 2016-05-21 01:30:33 --> Router Class Initialized
ERROR - 2016-05-21 01:30:33 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-05-21 01:30:35 --> Config Class Initialized
DEBUG - 2016-05-21 01:30:35 --> Hooks Class Initialized
DEBUG - 2016-05-21 01:30:35 --> Utf8 Class Initialized
DEBUG - 2016-05-21 01:30:35 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 01:30:35 --> URI Class Initialized
DEBUG - 2016-05-21 01:30:35 --> Router Class Initialized
DEBUG - 2016-05-21 01:30:35 --> Output Class Initialized
DEBUG - 2016-05-21 01:30:35 --> Cache file has expired. File deleted
DEBUG - 2016-05-21 01:30:35 --> Security Class Initialized
DEBUG - 2016-05-21 01:30:35 --> Input Class Initialized
DEBUG - 2016-05-21 01:30:35 --> XSS Filtering completed
DEBUG - 2016-05-21 01:30:35 --> XSS Filtering completed
DEBUG - 2016-05-21 01:30:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 01:30:35 --> Language Class Initialized
DEBUG - 2016-05-21 01:30:35 --> Loader Class Initialized
DEBUG - 2016-05-21 01:30:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 01:30:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 01:30:35 --> Helper loaded: url_helper
DEBUG - 2016-05-21 01:30:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 01:30:35 --> Helper loaded: file_helper
DEBUG - 2016-05-21 01:30:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 01:30:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 01:30:35 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 01:30:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 01:30:35 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 01:30:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 01:30:35 --> Helper loaded: common_helper
DEBUG - 2016-05-21 01:30:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 01:30:35 --> Helper loaded: common_helper
DEBUG - 2016-05-21 01:30:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 01:30:35 --> Helper loaded: form_helper
DEBUG - 2016-05-21 01:30:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 01:30:35 --> Helper loaded: security_helper
DEBUG - 2016-05-21 01:30:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 01:30:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 01:30:35 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 01:30:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 01:30:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 01:30:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 01:30:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 01:30:35 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 01:30:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 01:30:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 01:30:35 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 01:30:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 01:30:35 --> Database Driver Class Initialized
DEBUG - 2016-05-21 01:30:35 --> Session Class Initialized
DEBUG - 2016-05-21 01:30:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 01:30:35 --> Helper loaded: string_helper
DEBUG - 2016-05-21 01:30:35 --> Session routines successfully run
DEBUG - 2016-05-21 01:30:35 --> Native_session Class Initialized
DEBUG - 2016-05-21 01:30:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 01:30:35 --> Form Validation Class Initialized
DEBUG - 2016-05-21 01:30:35 --> Form Validation Class Initialized
DEBUG - 2016-05-21 01:30:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 01:30:35 --> Controller Class Initialized
DEBUG - 2016-05-21 01:30:35 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 01:30:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 01:30:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 01:30:35 --> Carabiner: library configured.
DEBUG - 2016-05-21 01:30:35 --> Carabiner: library configured.
DEBUG - 2016-05-21 01:30:35 --> User Agent Class Initialized
DEBUG - 2016-05-21 01:30:35 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:35 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:35 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:35 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:35 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:35 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:35 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:36 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-21 01:30:36 --> Pagination Class Initialized
DEBUG - 2016-05-21 01:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-21 01:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-05-21 01:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-21 01:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-21 01:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-21 01:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-21 01:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-21 01:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-21 01:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-21 01:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-21 01:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-21 01:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-21 01:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-21 01:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-21 01:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-21 01:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-21 01:30:36 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-05-21 01:30:36 --> Final output sent to browser
DEBUG - 2016-05-21 01:30:36 --> Total execution time: 1.4782
DEBUG - 2016-05-21 01:30:37 --> Config Class Initialized
DEBUG - 2016-05-21 01:30:37 --> Hooks Class Initialized
DEBUG - 2016-05-21 01:30:37 --> Utf8 Class Initialized
DEBUG - 2016-05-21 01:30:37 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 01:30:37 --> URI Class Initialized
DEBUG - 2016-05-21 01:30:37 --> Router Class Initialized
ERROR - 2016-05-21 01:30:37 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-05-21 01:30:38 --> Config Class Initialized
DEBUG - 2016-05-21 01:30:38 --> Hooks Class Initialized
DEBUG - 2016-05-21 01:30:38 --> Utf8 Class Initialized
DEBUG - 2016-05-21 01:30:38 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 01:30:38 --> URI Class Initialized
DEBUG - 2016-05-21 01:30:38 --> Router Class Initialized
DEBUG - 2016-05-21 01:30:38 --> Output Class Initialized
DEBUG - 2016-05-21 01:30:38 --> Security Class Initialized
DEBUG - 2016-05-21 01:30:38 --> Input Class Initialized
DEBUG - 2016-05-21 01:30:38 --> XSS Filtering completed
DEBUG - 2016-05-21 01:30:38 --> XSS Filtering completed
DEBUG - 2016-05-21 01:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 01:30:38 --> Language Class Initialized
DEBUG - 2016-05-21 01:30:38 --> Loader Class Initialized
DEBUG - 2016-05-21 01:30:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 01:30:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 01:30:38 --> Helper loaded: url_helper
DEBUG - 2016-05-21 01:30:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 01:30:38 --> Helper loaded: file_helper
DEBUG - 2016-05-21 01:30:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 01:30:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 01:30:38 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 01:30:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 01:30:38 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 01:30:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 01:30:39 --> Helper loaded: common_helper
DEBUG - 2016-05-21 01:30:39 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 01:30:39 --> Helper loaded: common_helper
DEBUG - 2016-05-21 01:30:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 01:30:39 --> Helper loaded: form_helper
DEBUG - 2016-05-21 01:30:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 01:30:39 --> Helper loaded: security_helper
DEBUG - 2016-05-21 01:30:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 01:30:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 01:30:39 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 01:30:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 01:30:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 01:30:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 01:30:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 01:30:39 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 01:30:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 01:30:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 01:30:39 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 01:30:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 01:30:39 --> Database Driver Class Initialized
DEBUG - 2016-05-21 01:30:39 --> Session Class Initialized
DEBUG - 2016-05-21 01:30:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 01:30:39 --> Helper loaded: string_helper
DEBUG - 2016-05-21 01:30:39 --> Session routines successfully run
DEBUG - 2016-05-21 01:30:39 --> Native_session Class Initialized
DEBUG - 2016-05-21 01:30:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 01:30:39 --> Form Validation Class Initialized
DEBUG - 2016-05-21 01:30:39 --> Form Validation Class Initialized
DEBUG - 2016-05-21 01:30:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 01:30:39 --> Controller Class Initialized
DEBUG - 2016-05-21 01:30:39 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 01:30:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 01:30:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 01:30:39 --> Carabiner: library configured.
DEBUG - 2016-05-21 01:30:39 --> Carabiner: library configured.
DEBUG - 2016-05-21 01:30:39 --> User Agent Class Initialized
DEBUG - 2016-05-21 01:30:39 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:39 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:39 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:39 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:39 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:39 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:39 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:39 --> Model Class Initialized
ERROR - 2016-05-21 01:30:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:163) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-05-21 01:30:44 --> Config Class Initialized
DEBUG - 2016-05-21 01:30:44 --> Hooks Class Initialized
DEBUG - 2016-05-21 01:30:44 --> Utf8 Class Initialized
DEBUG - 2016-05-21 01:30:44 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 01:30:44 --> URI Class Initialized
DEBUG - 2016-05-21 01:30:44 --> Router Class Initialized
DEBUG - 2016-05-21 01:30:44 --> Output Class Initialized
DEBUG - 2016-05-21 01:30:44 --> Cache file has expired. File deleted
DEBUG - 2016-05-21 01:30:44 --> Security Class Initialized
DEBUG - 2016-05-21 01:30:44 --> Input Class Initialized
DEBUG - 2016-05-21 01:30:44 --> XSS Filtering completed
DEBUG - 2016-05-21 01:30:44 --> XSS Filtering completed
DEBUG - 2016-05-21 01:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 01:30:45 --> Language Class Initialized
DEBUG - 2016-05-21 01:30:45 --> Loader Class Initialized
DEBUG - 2016-05-21 01:30:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 01:30:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 01:30:45 --> Helper loaded: url_helper
DEBUG - 2016-05-21 01:30:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 01:30:45 --> Helper loaded: file_helper
DEBUG - 2016-05-21 01:30:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 01:30:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 01:30:45 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 01:30:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 01:30:45 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 01:30:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 01:30:45 --> Helper loaded: common_helper
DEBUG - 2016-05-21 01:30:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 01:30:45 --> Helper loaded: common_helper
DEBUG - 2016-05-21 01:30:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 01:30:45 --> Helper loaded: form_helper
DEBUG - 2016-05-21 01:30:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 01:30:45 --> Helper loaded: security_helper
DEBUG - 2016-05-21 01:30:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 01:30:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 01:30:45 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 01:30:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 01:30:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 01:30:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 01:30:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 01:30:45 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 01:30:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 01:30:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 01:30:45 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 01:30:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 01:30:45 --> Database Driver Class Initialized
DEBUG - 2016-05-21 01:30:45 --> Session Class Initialized
DEBUG - 2016-05-21 01:30:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 01:30:45 --> Helper loaded: string_helper
DEBUG - 2016-05-21 01:30:45 --> Session routines successfully run
DEBUG - 2016-05-21 01:30:45 --> Native_session Class Initialized
DEBUG - 2016-05-21 01:30:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 01:30:45 --> Form Validation Class Initialized
DEBUG - 2016-05-21 01:30:45 --> Form Validation Class Initialized
DEBUG - 2016-05-21 01:30:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 01:30:45 --> Controller Class Initialized
DEBUG - 2016-05-21 01:30:45 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 01:30:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 01:30:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 01:30:45 --> Carabiner: library configured.
DEBUG - 2016-05-21 01:30:45 --> Carabiner: library configured.
DEBUG - 2016-05-21 01:30:45 --> User Agent Class Initialized
DEBUG - 2016-05-21 01:30:45 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:45 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:45 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:45 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:45 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-21 01:30:45 --> Pagination Class Initialized
DEBUG - 2016-05-21 01:30:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-21 01:30:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-05-21 01:30:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-21 01:30:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-21 01:30:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-21 01:30:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-21 01:30:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-05-21 01:30:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-21 01:30:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-21 01:30:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-21 01:30:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-21 01:30:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-21 01:30:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-21 01:30:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-05-21 01:30:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-21 01:30:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-21 01:30:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5cf2ac055215a66f98ba4d6c33c8329d
DEBUG - 2016-05-21 01:30:46 --> Final output sent to browser
DEBUG - 2016-05-21 01:30:46 --> Total execution time: 1.0771
DEBUG - 2016-05-21 01:30:46 --> Config Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Hooks Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Utf8 Class Initialized
DEBUG - 2016-05-21 01:30:46 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 01:30:46 --> URI Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Router Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Output Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Security Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Input Class Initialized
DEBUG - 2016-05-21 01:30:46 --> XSS Filtering completed
DEBUG - 2016-05-21 01:30:46 --> XSS Filtering completed
DEBUG - 2016-05-21 01:30:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 01:30:46 --> Language Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Loader Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 01:30:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 01:30:46 --> Helper loaded: url_helper
DEBUG - 2016-05-21 01:30:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 01:30:46 --> Helper loaded: file_helper
DEBUG - 2016-05-21 01:30:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 01:30:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 01:30:46 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 01:30:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 01:30:46 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 01:30:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 01:30:46 --> Helper loaded: common_helper
DEBUG - 2016-05-21 01:30:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 01:30:46 --> Helper loaded: common_helper
DEBUG - 2016-05-21 01:30:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 01:30:46 --> Helper loaded: form_helper
DEBUG - 2016-05-21 01:30:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 01:30:46 --> Helper loaded: security_helper
DEBUG - 2016-05-21 01:30:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 01:30:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 01:30:46 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 01:30:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 01:30:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 01:30:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 01:30:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 01:30:46 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 01:30:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 01:30:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 01:30:46 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 01:30:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 01:30:46 --> Database Driver Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Session Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 01:30:46 --> Helper loaded: string_helper
DEBUG - 2016-05-21 01:30:46 --> Session routines successfully run
DEBUG - 2016-05-21 01:30:46 --> Native_session Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 01:30:46 --> Form Validation Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Form Validation Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 01:30:46 --> Controller Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 01:30:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 01:30:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 01:30:46 --> Carabiner: library configured.
DEBUG - 2016-05-21 01:30:46 --> Carabiner: library configured.
DEBUG - 2016-05-21 01:30:46 --> User Agent Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Config Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Hooks Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Utf8 Class Initialized
DEBUG - 2016-05-21 01:30:46 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 01:30:46 --> URI Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Router Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Output Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Cache file has expired. File deleted
DEBUG - 2016-05-21 01:30:46 --> Security Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Input Class Initialized
DEBUG - 2016-05-21 01:30:46 --> XSS Filtering completed
DEBUG - 2016-05-21 01:30:46 --> XSS Filtering completed
DEBUG - 2016-05-21 01:30:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 01:30:46 --> Language Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Loader Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 01:30:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 01:30:46 --> Helper loaded: url_helper
DEBUG - 2016-05-21 01:30:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 01:30:46 --> Helper loaded: file_helper
DEBUG - 2016-05-21 01:30:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 01:30:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 01:30:46 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 01:30:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 01:30:46 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 01:30:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 01:30:46 --> Helper loaded: common_helper
DEBUG - 2016-05-21 01:30:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 01:30:46 --> Helper loaded: common_helper
DEBUG - 2016-05-21 01:30:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 01:30:46 --> Helper loaded: form_helper
DEBUG - 2016-05-21 01:30:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 01:30:46 --> Helper loaded: security_helper
DEBUG - 2016-05-21 01:30:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 01:30:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 01:30:46 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 01:30:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 01:30:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 01:30:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 01:30:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 01:30:46 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 01:30:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 01:30:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 01:30:46 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 01:30:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 01:30:46 --> Database Driver Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Session Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 01:30:46 --> Helper loaded: string_helper
DEBUG - 2016-05-21 01:30:46 --> Session routines successfully run
DEBUG - 2016-05-21 01:30:46 --> Native_session Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 01:30:46 --> Form Validation Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Form Validation Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 01:30:46 --> Controller Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 01:30:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 01:30:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 01:30:46 --> Carabiner: library configured.
DEBUG - 2016-05-21 01:30:46 --> Carabiner: library configured.
DEBUG - 2016-05-21 01:30:46 --> User Agent Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Model Class Initialized
DEBUG - 2016-05-21 01:30:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-21 01:30:46 --> Pagination Class Initialized
DEBUG - 2016-05-21 01:30:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-21 01:30:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-05-21 01:30:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-21 01:30:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-21 01:30:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-21 01:30:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-21 01:30:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-21 01:30:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-21 01:30:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-21 01:30:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-21 01:30:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-21 01:30:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-21 01:30:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-21 01:30:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-21 01:30:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-21 01:30:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-21 01:30:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-05-21 01:30:46 --> Final output sent to browser
DEBUG - 2016-05-21 01:30:46 --> Total execution time: 0.3105
DEBUG - 2016-05-21 02:11:20 --> Config Class Initialized
DEBUG - 2016-05-21 02:11:20 --> Hooks Class Initialized
DEBUG - 2016-05-21 02:11:20 --> Utf8 Class Initialized
DEBUG - 2016-05-21 02:11:20 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 02:11:20 --> URI Class Initialized
DEBUG - 2016-05-21 02:11:20 --> Router Class Initialized
DEBUG - 2016-05-21 02:11:20 --> Output Class Initialized
DEBUG - 2016-05-21 02:11:20 --> Cache file has expired. File deleted
DEBUG - 2016-05-21 02:11:20 --> Security Class Initialized
DEBUG - 2016-05-21 02:11:20 --> Input Class Initialized
DEBUG - 2016-05-21 02:11:20 --> XSS Filtering completed
DEBUG - 2016-05-21 02:11:20 --> XSS Filtering completed
DEBUG - 2016-05-21 02:11:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 02:11:20 --> Language Class Initialized
DEBUG - 2016-05-21 02:11:20 --> Loader Class Initialized
DEBUG - 2016-05-21 02:11:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 02:11:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 02:11:20 --> Helper loaded: url_helper
DEBUG - 2016-05-21 02:11:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 02:11:20 --> Helper loaded: file_helper
DEBUG - 2016-05-21 02:11:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:11:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 02:11:20 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 02:11:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:11:20 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 02:11:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 02:11:20 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:11:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 02:11:20 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:11:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 02:11:20 --> Helper loaded: form_helper
DEBUG - 2016-05-21 02:11:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 02:11:20 --> Helper loaded: security_helper
DEBUG - 2016-05-21 02:11:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:11:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 02:11:20 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 02:11:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:11:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 02:11:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 02:11:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 02:11:20 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 02:11:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:11:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 02:11:20 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 02:11:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:11:20 --> Database Driver Class Initialized
DEBUG - 2016-05-21 02:11:20 --> Session Class Initialized
DEBUG - 2016-05-21 02:11:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 02:11:20 --> Helper loaded: string_helper
DEBUG - 2016-05-21 02:11:20 --> Session routines successfully run
DEBUG - 2016-05-21 02:11:20 --> Native_session Class Initialized
DEBUG - 2016-05-21 02:11:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 02:11:20 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:11:20 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:11:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 02:11:20 --> Controller Class Initialized
DEBUG - 2016-05-21 02:11:20 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 02:11:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 02:11:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 02:11:20 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:11:20 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:11:20 --> User Agent Class Initialized
DEBUG - 2016-05-21 02:11:20 --> Model Class Initialized
DEBUG - 2016-05-21 02:11:20 --> Model Class Initialized
DEBUG - 2016-05-21 02:11:20 --> Model Class Initialized
DEBUG - 2016-05-21 02:11:20 --> Model Class Initialized
DEBUG - 2016-05-21 02:11:20 --> Model Class Initialized
DEBUG - 2016-05-21 02:11:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-21 02:11:20 --> Pagination Class Initialized
DEBUG - 2016-05-21 02:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-21 02:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-05-21 02:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-21 02:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-21 02:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-21 02:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-21 02:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-05-21 02:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-21 02:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-21 02:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-21 02:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-21 02:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-21 02:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-21 02:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-05-21 02:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-21 02:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-21 02:11:20 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5cf2ac055215a66f98ba4d6c33c8329d
DEBUG - 2016-05-21 02:11:20 --> Final output sent to browser
DEBUG - 2016-05-21 02:11:20 --> Total execution time: 0.3629
DEBUG - 2016-05-21 02:23:03 --> Config Class Initialized
DEBUG - 2016-05-21 02:23:03 --> Hooks Class Initialized
DEBUG - 2016-05-21 02:23:03 --> Utf8 Class Initialized
DEBUG - 2016-05-21 02:23:03 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 02:23:03 --> URI Class Initialized
DEBUG - 2016-05-21 02:23:03 --> Router Class Initialized
DEBUG - 2016-05-21 02:23:03 --> Output Class Initialized
DEBUG - 2016-05-21 02:23:03 --> Cache file has expired. File deleted
DEBUG - 2016-05-21 02:23:03 --> Security Class Initialized
DEBUG - 2016-05-21 02:23:03 --> Input Class Initialized
DEBUG - 2016-05-21 02:23:03 --> XSS Filtering completed
DEBUG - 2016-05-21 02:23:03 --> XSS Filtering completed
DEBUG - 2016-05-21 02:23:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 02:23:03 --> Language Class Initialized
DEBUG - 2016-05-21 02:23:03 --> Loader Class Initialized
DEBUG - 2016-05-21 02:23:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 02:23:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 02:23:03 --> Helper loaded: url_helper
DEBUG - 2016-05-21 02:23:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 02:23:03 --> Helper loaded: file_helper
DEBUG - 2016-05-21 02:23:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:23:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 02:23:03 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 02:23:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:23:03 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 02:23:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 02:23:03 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:23:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 02:23:03 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:23:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 02:23:03 --> Helper loaded: form_helper
DEBUG - 2016-05-21 02:23:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 02:23:03 --> Helper loaded: security_helper
DEBUG - 2016-05-21 02:23:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:23:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 02:23:03 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 02:23:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:23:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 02:23:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 02:23:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 02:23:03 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 02:23:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:23:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 02:23:03 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 02:23:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:23:03 --> Database Driver Class Initialized
DEBUG - 2016-05-21 02:23:03 --> Session Class Initialized
DEBUG - 2016-05-21 02:23:03 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 02:23:03 --> Helper loaded: string_helper
DEBUG - 2016-05-21 02:23:03 --> Session routines successfully run
DEBUG - 2016-05-21 02:23:03 --> Native_session Class Initialized
DEBUG - 2016-05-21 02:23:03 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 02:23:03 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:23:03 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:23:03 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 02:23:03 --> Controller Class Initialized
DEBUG - 2016-05-21 02:23:03 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 02:23:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 02:23:03 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 02:23:03 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:23:03 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:23:03 --> User Agent Class Initialized
DEBUG - 2016-05-21 02:23:03 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:03 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:03 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:03 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:03 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-21 02:23:03 --> Pagination Class Initialized
DEBUG - 2016-05-21 02:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-21 02:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-05-21 02:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-21 02:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-21 02:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-21 02:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-21 02:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-05-21 02:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-21 02:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-21 02:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-21 02:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-21 02:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-21 02:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-21 02:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-05-21 02:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-21 02:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-21 02:23:03 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5cf2ac055215a66f98ba4d6c33c8329d
DEBUG - 2016-05-21 02:23:03 --> Final output sent to browser
DEBUG - 2016-05-21 02:23:03 --> Total execution time: 0.6085
DEBUG - 2016-05-21 02:23:05 --> Config Class Initialized
DEBUG - 2016-05-21 02:23:05 --> Hooks Class Initialized
DEBUG - 2016-05-21 02:23:05 --> Utf8 Class Initialized
DEBUG - 2016-05-21 02:23:05 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 02:23:05 --> URI Class Initialized
DEBUG - 2016-05-21 02:23:05 --> Router Class Initialized
DEBUG - 2016-05-21 02:23:05 --> Output Class Initialized
DEBUG - 2016-05-21 02:23:05 --> Security Class Initialized
DEBUG - 2016-05-21 02:23:05 --> Input Class Initialized
DEBUG - 2016-05-21 02:23:05 --> XSS Filtering completed
DEBUG - 2016-05-21 02:23:05 --> XSS Filtering completed
DEBUG - 2016-05-21 02:23:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 02:23:05 --> Language Class Initialized
DEBUG - 2016-05-21 02:23:05 --> Loader Class Initialized
DEBUG - 2016-05-21 02:23:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 02:23:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 02:23:05 --> Helper loaded: url_helper
DEBUG - 2016-05-21 02:23:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 02:23:05 --> Helper loaded: file_helper
DEBUG - 2016-05-21 02:23:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:23:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 02:23:05 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 02:23:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:23:05 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 02:23:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 02:23:05 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:23:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 02:23:05 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:23:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 02:23:05 --> Helper loaded: form_helper
DEBUG - 2016-05-21 02:23:05 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 02:23:05 --> Helper loaded: security_helper
DEBUG - 2016-05-21 02:23:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:23:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 02:23:05 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 02:23:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:23:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 02:23:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 02:23:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 02:23:05 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 02:23:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:23:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 02:23:05 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 02:23:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:23:05 --> Database Driver Class Initialized
DEBUG - 2016-05-21 02:23:05 --> Session Class Initialized
DEBUG - 2016-05-21 02:23:05 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 02:23:05 --> Helper loaded: string_helper
DEBUG - 2016-05-21 02:23:05 --> Session routines successfully run
DEBUG - 2016-05-21 02:23:05 --> Native_session Class Initialized
DEBUG - 2016-05-21 02:23:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 02:23:05 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 02:23:06 --> Controller Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 02:23:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 02:23:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 02:23:06 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:23:06 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:23:06 --> User Agent Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Config Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Hooks Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Utf8 Class Initialized
DEBUG - 2016-05-21 02:23:06 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 02:23:06 --> URI Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Router Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Output Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Cache file has expired. File deleted
DEBUG - 2016-05-21 02:23:06 --> Security Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Input Class Initialized
DEBUG - 2016-05-21 02:23:06 --> XSS Filtering completed
DEBUG - 2016-05-21 02:23:06 --> XSS Filtering completed
DEBUG - 2016-05-21 02:23:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 02:23:06 --> Language Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Loader Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 02:23:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 02:23:06 --> Helper loaded: url_helper
DEBUG - 2016-05-21 02:23:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 02:23:06 --> Helper loaded: file_helper
DEBUG - 2016-05-21 02:23:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:23:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 02:23:06 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 02:23:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:23:06 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 02:23:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 02:23:06 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:23:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 02:23:06 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:23:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 02:23:06 --> Helper loaded: form_helper
DEBUG - 2016-05-21 02:23:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 02:23:06 --> Helper loaded: security_helper
DEBUG - 2016-05-21 02:23:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:23:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 02:23:06 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 02:23:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:23:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 02:23:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 02:23:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 02:23:06 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 02:23:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:23:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 02:23:06 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 02:23:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:23:06 --> Database Driver Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Session Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 02:23:06 --> Helper loaded: string_helper
DEBUG - 2016-05-21 02:23:06 --> Session routines successfully run
DEBUG - 2016-05-21 02:23:06 --> Native_session Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 02:23:06 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 02:23:06 --> Controller Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 02:23:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 02:23:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 02:23:06 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:23:06 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:23:06 --> User Agent Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-21 02:23:06 --> Pagination Class Initialized
DEBUG - 2016-05-21 02:23:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-21 02:23:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-05-21 02:23:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-21 02:23:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-21 02:23:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-21 02:23:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-21 02:23:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-21 02:23:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-21 02:23:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-21 02:23:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-21 02:23:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-21 02:23:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-21 02:23:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-21 02:23:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-21 02:23:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-21 02:23:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-21 02:23:06 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-05-21 02:23:06 --> Final output sent to browser
DEBUG - 2016-05-21 02:23:06 --> Total execution time: 0.4861
DEBUG - 2016-05-21 02:23:38 --> Config Class Initialized
DEBUG - 2016-05-21 02:23:38 --> Hooks Class Initialized
DEBUG - 2016-05-21 02:23:38 --> Utf8 Class Initialized
DEBUG - 2016-05-21 02:23:38 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 02:23:38 --> URI Class Initialized
DEBUG - 2016-05-21 02:23:38 --> Router Class Initialized
DEBUG - 2016-05-21 02:23:38 --> Output Class Initialized
DEBUG - 2016-05-21 02:23:38 --> Cache file has expired. File deleted
DEBUG - 2016-05-21 02:23:38 --> Security Class Initialized
DEBUG - 2016-05-21 02:23:38 --> Input Class Initialized
DEBUG - 2016-05-21 02:23:38 --> XSS Filtering completed
DEBUG - 2016-05-21 02:23:38 --> XSS Filtering completed
DEBUG - 2016-05-21 02:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 02:23:38 --> Language Class Initialized
DEBUG - 2016-05-21 02:23:38 --> Loader Class Initialized
DEBUG - 2016-05-21 02:23:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 02:23:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 02:23:38 --> Helper loaded: url_helper
DEBUG - 2016-05-21 02:23:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 02:23:38 --> Helper loaded: file_helper
DEBUG - 2016-05-21 02:23:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:23:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 02:23:38 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 02:23:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:23:38 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 02:23:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 02:23:38 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:23:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 02:23:38 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:23:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 02:23:38 --> Helper loaded: form_helper
DEBUG - 2016-05-21 02:23:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 02:23:38 --> Helper loaded: security_helper
DEBUG - 2016-05-21 02:23:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:23:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 02:23:38 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 02:23:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:23:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 02:23:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 02:23:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 02:23:38 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 02:23:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:23:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 02:23:38 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 02:23:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:23:38 --> Database Driver Class Initialized
DEBUG - 2016-05-21 02:23:39 --> Session Class Initialized
DEBUG - 2016-05-21 02:23:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 02:23:39 --> Helper loaded: string_helper
DEBUG - 2016-05-21 02:23:39 --> Session routines successfully run
DEBUG - 2016-05-21 02:23:39 --> Native_session Class Initialized
DEBUG - 2016-05-21 02:23:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 02:23:39 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:23:39 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:23:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 02:23:39 --> Controller Class Initialized
DEBUG - 2016-05-21 02:23:39 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 02:23:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 02:23:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 02:23:39 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:23:39 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:23:39 --> User Agent Class Initialized
DEBUG - 2016-05-21 02:23:39 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:39 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:39 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:39 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:39 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-21 02:23:39 --> Pagination Class Initialized
DEBUG - 2016-05-21 02:23:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-21 02:23:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-05-21 02:23:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-21 02:23:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-21 02:23:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-21 02:23:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-21 02:23:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-05-21 02:23:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-21 02:23:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-21 02:23:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-21 02:23:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-21 02:23:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-21 02:23:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-21 02:23:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-05-21 02:23:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-21 02:23:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-21 02:23:39 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5cf2ac055215a66f98ba4d6c33c8329d
DEBUG - 2016-05-21 02:23:39 --> Final output sent to browser
DEBUG - 2016-05-21 02:23:39 --> Total execution time: 0.6121
DEBUG - 2016-05-21 02:23:51 --> Config Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Hooks Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Utf8 Class Initialized
DEBUG - 2016-05-21 02:23:51 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 02:23:51 --> URI Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Router Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Output Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Security Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Input Class Initialized
DEBUG - 2016-05-21 02:23:51 --> XSS Filtering completed
DEBUG - 2016-05-21 02:23:51 --> XSS Filtering completed
DEBUG - 2016-05-21 02:23:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 02:23:51 --> Language Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Loader Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 02:23:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 02:23:51 --> Helper loaded: url_helper
DEBUG - 2016-05-21 02:23:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 02:23:51 --> Helper loaded: file_helper
DEBUG - 2016-05-21 02:23:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:23:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 02:23:51 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 02:23:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:23:51 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 02:23:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 02:23:51 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:23:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 02:23:51 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:23:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 02:23:51 --> Helper loaded: form_helper
DEBUG - 2016-05-21 02:23:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 02:23:51 --> Helper loaded: security_helper
DEBUG - 2016-05-21 02:23:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:23:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 02:23:51 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 02:23:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:23:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 02:23:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 02:23:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 02:23:51 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 02:23:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:23:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 02:23:51 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 02:23:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:23:51 --> Database Driver Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Session Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 02:23:51 --> Helper loaded: string_helper
DEBUG - 2016-05-21 02:23:51 --> Session routines successfully run
DEBUG - 2016-05-21 02:23:51 --> Native_session Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 02:23:51 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 02:23:51 --> Controller Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 02:23:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 02:23:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 02:23:51 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:23:51 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:23:51 --> User Agent Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Config Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Hooks Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Utf8 Class Initialized
DEBUG - 2016-05-21 02:23:51 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 02:23:51 --> URI Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Router Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Output Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Cache file has expired. File deleted
DEBUG - 2016-05-21 02:23:51 --> Security Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Input Class Initialized
DEBUG - 2016-05-21 02:23:51 --> XSS Filtering completed
DEBUG - 2016-05-21 02:23:51 --> XSS Filtering completed
DEBUG - 2016-05-21 02:23:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 02:23:51 --> Language Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Loader Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 02:23:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 02:23:51 --> Helper loaded: url_helper
DEBUG - 2016-05-21 02:23:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 02:23:51 --> Helper loaded: file_helper
DEBUG - 2016-05-21 02:23:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:23:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 02:23:51 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 02:23:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:23:51 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 02:23:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 02:23:51 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:23:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 02:23:51 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:23:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 02:23:51 --> Helper loaded: form_helper
DEBUG - 2016-05-21 02:23:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 02:23:51 --> Helper loaded: security_helper
DEBUG - 2016-05-21 02:23:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:23:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 02:23:51 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 02:23:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:23:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 02:23:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 02:23:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 02:23:51 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 02:23:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:23:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 02:23:51 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 02:23:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:23:51 --> Database Driver Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Session Class Initialized
DEBUG - 2016-05-21 02:23:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 02:23:51 --> Helper loaded: string_helper
DEBUG - 2016-05-21 02:23:51 --> Session routines successfully run
DEBUG - 2016-05-21 02:23:51 --> Native_session Class Initialized
DEBUG - 2016-05-21 02:23:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 02:23:52 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:23:52 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:23:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 02:23:52 --> Controller Class Initialized
DEBUG - 2016-05-21 02:23:52 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 02:23:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 02:23:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 02:23:52 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:23:52 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:23:52 --> User Agent Class Initialized
DEBUG - 2016-05-21 02:23:52 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:52 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:52 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:52 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:52 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:52 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:52 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:52 --> Model Class Initialized
DEBUG - 2016-05-21 02:23:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-21 02:23:52 --> Pagination Class Initialized
DEBUG - 2016-05-21 02:23:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-21 02:23:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-05-21 02:23:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-21 02:23:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-21 02:23:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-21 02:23:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-21 02:23:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-21 02:23:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-21 02:23:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-21 02:23:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-21 02:23:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-21 02:23:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-21 02:23:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-21 02:23:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-21 02:23:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-21 02:23:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-21 02:23:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-05-21 02:23:52 --> Final output sent to browser
DEBUG - 2016-05-21 02:23:52 --> Total execution time: 0.4388
DEBUG - 2016-05-21 02:24:47 --> Config Class Initialized
DEBUG - 2016-05-21 02:24:47 --> Hooks Class Initialized
DEBUG - 2016-05-21 02:24:47 --> Utf8 Class Initialized
DEBUG - 2016-05-21 02:24:47 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 02:24:47 --> URI Class Initialized
DEBUG - 2016-05-21 02:24:47 --> Router Class Initialized
DEBUG - 2016-05-21 02:24:47 --> Output Class Initialized
DEBUG - 2016-05-21 02:24:47 --> Cache file has expired. File deleted
DEBUG - 2016-05-21 02:24:47 --> Security Class Initialized
DEBUG - 2016-05-21 02:24:47 --> Input Class Initialized
DEBUG - 2016-05-21 02:24:47 --> XSS Filtering completed
DEBUG - 2016-05-21 02:24:47 --> XSS Filtering completed
DEBUG - 2016-05-21 02:24:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 02:24:47 --> Language Class Initialized
DEBUG - 2016-05-21 02:24:47 --> Loader Class Initialized
DEBUG - 2016-05-21 02:24:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 02:24:47 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 02:24:47 --> Helper loaded: url_helper
DEBUG - 2016-05-21 02:24:47 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 02:24:47 --> Helper loaded: file_helper
DEBUG - 2016-05-21 02:24:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:24:47 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 02:24:47 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 02:24:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:24:47 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 02:24:47 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 02:24:47 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:24:47 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 02:24:47 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:24:47 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 02:24:47 --> Helper loaded: form_helper
DEBUG - 2016-05-21 02:24:47 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 02:24:47 --> Helper loaded: security_helper
DEBUG - 2016-05-21 02:24:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:24:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 02:24:47 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 02:24:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:24:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 02:24:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 02:24:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 02:24:47 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 02:24:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:24:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 02:24:47 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 02:24:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:24:47 --> Database Driver Class Initialized
DEBUG - 2016-05-21 02:24:47 --> Session Class Initialized
DEBUG - 2016-05-21 02:24:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 02:24:47 --> Helper loaded: string_helper
DEBUG - 2016-05-21 02:24:47 --> Session routines successfully run
DEBUG - 2016-05-21 02:24:47 --> Native_session Class Initialized
DEBUG - 2016-05-21 02:24:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 02:24:47 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:24:47 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:24:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 02:24:47 --> Controller Class Initialized
DEBUG - 2016-05-21 02:24:47 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 02:24:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 02:24:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 02:24:47 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:24:47 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:24:47 --> User Agent Class Initialized
DEBUG - 2016-05-21 02:24:47 --> Model Class Initialized
DEBUG - 2016-05-21 02:24:47 --> Model Class Initialized
DEBUG - 2016-05-21 02:24:47 --> Model Class Initialized
DEBUG - 2016-05-21 02:24:47 --> Model Class Initialized
DEBUG - 2016-05-21 02:24:47 --> Model Class Initialized
DEBUG - 2016-05-21 02:24:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-21 02:24:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-21 02:24:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-21 02:24:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-21 02:24:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-21 02:24:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-21 02:24:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-21 02:24:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-21 02:24:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-21 02:24:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-21 02:24:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-21 02:24:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-21 02:24:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-21 02:24:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-21 02:24:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-05-21 02:24:47 --> Final output sent to browser
DEBUG - 2016-05-21 02:24:47 --> Total execution time: 0.4342
DEBUG - 2016-05-21 02:24:48 --> Config Class Initialized
DEBUG - 2016-05-21 02:24:48 --> Hooks Class Initialized
DEBUG - 2016-05-21 02:24:48 --> Utf8 Class Initialized
DEBUG - 2016-05-21 02:24:48 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 02:24:48 --> URI Class Initialized
DEBUG - 2016-05-21 02:24:48 --> Router Class Initialized
DEBUG - 2016-05-21 02:24:48 --> Output Class Initialized
DEBUG - 2016-05-21 02:24:48 --> Cache file has expired. File deleted
DEBUG - 2016-05-21 02:24:48 --> Security Class Initialized
DEBUG - 2016-05-21 02:24:48 --> Input Class Initialized
DEBUG - 2016-05-21 02:24:48 --> XSS Filtering completed
DEBUG - 2016-05-21 02:24:48 --> XSS Filtering completed
DEBUG - 2016-05-21 02:24:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 02:24:48 --> Language Class Initialized
DEBUG - 2016-05-21 02:24:48 --> Loader Class Initialized
DEBUG - 2016-05-21 02:24:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 02:24:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 02:24:48 --> Helper loaded: url_helper
DEBUG - 2016-05-21 02:24:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 02:24:48 --> Helper loaded: file_helper
DEBUG - 2016-05-21 02:24:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:24:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 02:24:48 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 02:24:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:24:48 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 02:24:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 02:24:48 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:24:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 02:24:48 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:24:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 02:24:48 --> Helper loaded: form_helper
DEBUG - 2016-05-21 02:24:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 02:24:48 --> Helper loaded: security_helper
DEBUG - 2016-05-21 02:24:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:24:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 02:24:48 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 02:24:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:24:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 02:24:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 02:24:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 02:24:49 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 02:24:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:24:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 02:24:49 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 02:24:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:24:49 --> Database Driver Class Initialized
DEBUG - 2016-05-21 02:24:49 --> Session Class Initialized
DEBUG - 2016-05-21 02:24:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 02:24:49 --> Helper loaded: string_helper
DEBUG - 2016-05-21 02:24:49 --> Session routines successfully run
DEBUG - 2016-05-21 02:24:49 --> Native_session Class Initialized
DEBUG - 2016-05-21 02:24:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 02:24:49 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:24:49 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:24:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 02:24:49 --> Controller Class Initialized
DEBUG - 2016-05-21 02:24:49 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 02:24:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 02:24:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 02:24:49 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:24:49 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:24:49 --> User Agent Class Initialized
DEBUG - 2016-05-21 02:24:49 --> Model Class Initialized
DEBUG - 2016-05-21 02:24:49 --> Model Class Initialized
DEBUG - 2016-05-21 02:24:49 --> Model Class Initialized
DEBUG - 2016-05-21 02:24:49 --> Model Class Initialized
DEBUG - 2016-05-21 02:24:49 --> Model Class Initialized
ERROR - 2016-05-21 02:24:49 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-05-21 02:24:49 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-05-21 02:24:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-21 02:24:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-21 02:24:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-21 02:24:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-21 02:24:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-21 02:24:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-21 02:24:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-21 02:24:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-21 02:24:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-21 02:24:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-21 02:24:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-21 02:24:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-21 02:24:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-21 02:24:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-21 02:24:49 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-05-21 02:24:49 --> Final output sent to browser
DEBUG - 2016-05-21 02:24:49 --> Total execution time: 0.4380
DEBUG - 2016-05-21 02:25:11 --> Config Class Initialized
DEBUG - 2016-05-21 02:25:11 --> Hooks Class Initialized
DEBUG - 2016-05-21 02:25:11 --> Utf8 Class Initialized
DEBUG - 2016-05-21 02:25:11 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 02:25:11 --> URI Class Initialized
DEBUG - 2016-05-21 02:25:11 --> Router Class Initialized
DEBUG - 2016-05-21 02:25:11 --> Output Class Initialized
DEBUG - 2016-05-21 02:25:11 --> Cache file has expired. File deleted
DEBUG - 2016-05-21 02:25:11 --> Security Class Initialized
DEBUG - 2016-05-21 02:25:11 --> Input Class Initialized
DEBUG - 2016-05-21 02:25:11 --> XSS Filtering completed
DEBUG - 2016-05-21 02:25:11 --> XSS Filtering completed
DEBUG - 2016-05-21 02:25:11 --> XSS Filtering completed
DEBUG - 2016-05-21 02:25:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 02:25:11 --> Language Class Initialized
DEBUG - 2016-05-21 02:25:11 --> Loader Class Initialized
DEBUG - 2016-05-21 02:25:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 02:25:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 02:25:11 --> Helper loaded: url_helper
DEBUG - 2016-05-21 02:25:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 02:25:11 --> Helper loaded: file_helper
DEBUG - 2016-05-21 02:25:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:25:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 02:25:11 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 02:25:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:25:11 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 02:25:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 02:25:11 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:25:11 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 02:25:11 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:25:11 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 02:25:11 --> Helper loaded: form_helper
DEBUG - 2016-05-21 02:25:11 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 02:25:11 --> Helper loaded: security_helper
DEBUG - 2016-05-21 02:25:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:25:11 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 02:25:11 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 02:25:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:25:11 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 02:25:11 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 02:25:11 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 02:25:11 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 02:25:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:25:11 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 02:25:11 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 02:25:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:25:11 --> Database Driver Class Initialized
DEBUG - 2016-05-21 02:25:11 --> Session Class Initialized
DEBUG - 2016-05-21 02:25:11 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 02:25:11 --> Helper loaded: string_helper
DEBUG - 2016-05-21 02:25:11 --> Session routines successfully run
DEBUG - 2016-05-21 02:25:11 --> Native_session Class Initialized
DEBUG - 2016-05-21 02:25:11 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 02:25:11 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:25:11 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:25:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 02:25:11 --> Controller Class Initialized
DEBUG - 2016-05-21 02:25:11 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 02:25:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 02:25:11 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 02:25:11 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:25:11 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:25:11 --> User Agent Class Initialized
DEBUG - 2016-05-21 02:25:11 --> Model Class Initialized
DEBUG - 2016-05-21 02:25:11 --> Model Class Initialized
DEBUG - 2016-05-21 02:25:11 --> Model Class Initialized
DEBUG - 2016-05-21 02:25:11 --> Model Class Initialized
DEBUG - 2016-05-21 02:25:11 --> Model Class Initialized
ERROR - 2016-05-21 02:25:11 --> Severity: Warning  --> mkdir(): Invalid argument E:\www\lwscodeigniterwrapper\helpers\LWS_common_helper.php 812
DEBUG - 2016-05-21 02:28:01 --> Config Class Initialized
DEBUG - 2016-05-21 02:28:01 --> Hooks Class Initialized
DEBUG - 2016-05-21 02:28:01 --> Utf8 Class Initialized
DEBUG - 2016-05-21 02:28:01 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 02:28:01 --> URI Class Initialized
DEBUG - 2016-05-21 02:28:01 --> Router Class Initialized
DEBUG - 2016-05-21 02:28:01 --> Output Class Initialized
DEBUG - 2016-05-21 02:28:01 --> Security Class Initialized
DEBUG - 2016-05-21 02:28:01 --> Input Class Initialized
DEBUG - 2016-05-21 02:28:01 --> XSS Filtering completed
DEBUG - 2016-05-21 02:28:01 --> XSS Filtering completed
DEBUG - 2016-05-21 02:28:01 --> XSS Filtering completed
DEBUG - 2016-05-21 02:28:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 02:28:01 --> Language Class Initialized
DEBUG - 2016-05-21 02:28:01 --> Loader Class Initialized
DEBUG - 2016-05-21 02:28:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 02:28:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 02:28:01 --> Helper loaded: url_helper
DEBUG - 2016-05-21 02:28:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 02:28:01 --> Helper loaded: file_helper
DEBUG - 2016-05-21 02:28:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:28:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 02:28:01 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 02:28:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:28:01 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 02:28:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 02:28:01 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:28:01 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 02:28:01 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:28:01 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 02:28:01 --> Helper loaded: form_helper
DEBUG - 2016-05-21 02:28:01 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 02:28:01 --> Helper loaded: security_helper
DEBUG - 2016-05-21 02:28:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:28:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 02:28:01 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 02:28:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:28:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 02:28:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 02:28:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 02:28:01 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 02:28:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:28:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 02:28:01 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 02:28:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:28:01 --> Database Driver Class Initialized
DEBUG - 2016-05-21 02:28:01 --> Session Class Initialized
DEBUG - 2016-05-21 02:28:01 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 02:28:01 --> Helper loaded: string_helper
DEBUG - 2016-05-21 02:28:01 --> Session routines successfully run
DEBUG - 2016-05-21 02:28:01 --> Native_session Class Initialized
DEBUG - 2016-05-21 02:28:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 02:28:01 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:28:01 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:28:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 02:28:01 --> Controller Class Initialized
DEBUG - 2016-05-21 02:28:01 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 02:28:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 02:28:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 02:28:01 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:28:01 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:28:01 --> User Agent Class Initialized
DEBUG - 2016-05-21 02:28:01 --> Model Class Initialized
DEBUG - 2016-05-21 02:28:01 --> Model Class Initialized
DEBUG - 2016-05-21 02:28:01 --> Model Class Initialized
DEBUG - 2016-05-21 02:28:01 --> Model Class Initialized
DEBUG - 2016-05-21 02:28:01 --> Model Class Initialized
DEBUG - 2016-05-21 02:28:50 --> Config Class Initialized
DEBUG - 2016-05-21 02:28:50 --> Hooks Class Initialized
DEBUG - 2016-05-21 02:28:50 --> Utf8 Class Initialized
DEBUG - 2016-05-21 02:28:50 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 02:28:50 --> URI Class Initialized
DEBUG - 2016-05-21 02:28:50 --> Router Class Initialized
DEBUG - 2016-05-21 02:28:50 --> Output Class Initialized
DEBUG - 2016-05-21 02:28:50 --> Security Class Initialized
DEBUG - 2016-05-21 02:28:50 --> Input Class Initialized
DEBUG - 2016-05-21 02:28:50 --> XSS Filtering completed
DEBUG - 2016-05-21 02:28:50 --> XSS Filtering completed
DEBUG - 2016-05-21 02:28:50 --> XSS Filtering completed
DEBUG - 2016-05-21 02:28:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 02:28:50 --> Language Class Initialized
DEBUG - 2016-05-21 02:28:50 --> Loader Class Initialized
DEBUG - 2016-05-21 02:28:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 02:28:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 02:28:50 --> Helper loaded: url_helper
DEBUG - 2016-05-21 02:28:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 02:28:50 --> Helper loaded: file_helper
DEBUG - 2016-05-21 02:28:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:28:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 02:28:50 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 02:28:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:28:50 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 02:28:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 02:28:50 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:28:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 02:28:50 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:28:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 02:28:50 --> Helper loaded: form_helper
DEBUG - 2016-05-21 02:28:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 02:28:50 --> Helper loaded: security_helper
DEBUG - 2016-05-21 02:28:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:28:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 02:28:50 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 02:28:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:28:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 02:28:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 02:28:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 02:28:50 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 02:28:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:28:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 02:28:50 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 02:28:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:28:50 --> Database Driver Class Initialized
DEBUG - 2016-05-21 02:28:50 --> Session Class Initialized
DEBUG - 2016-05-21 02:28:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 02:28:50 --> Helper loaded: string_helper
DEBUG - 2016-05-21 02:28:50 --> Session routines successfully run
DEBUG - 2016-05-21 02:28:50 --> Native_session Class Initialized
DEBUG - 2016-05-21 02:28:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 02:28:50 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:28:50 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:28:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 02:28:50 --> Controller Class Initialized
DEBUG - 2016-05-21 02:28:50 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 02:28:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 02:28:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 02:28:50 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:28:50 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:28:50 --> User Agent Class Initialized
DEBUG - 2016-05-21 02:28:50 --> Model Class Initialized
DEBUG - 2016-05-21 02:28:50 --> Model Class Initialized
DEBUG - 2016-05-21 02:28:50 --> Model Class Initialized
DEBUG - 2016-05-21 02:28:50 --> Model Class Initialized
DEBUG - 2016-05-21 02:28:50 --> Model Class Initialized
DEBUG - 2016-05-21 02:30:14 --> Config Class Initialized
DEBUG - 2016-05-21 02:30:14 --> Hooks Class Initialized
DEBUG - 2016-05-21 02:30:14 --> Utf8 Class Initialized
DEBUG - 2016-05-21 02:30:14 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 02:30:14 --> URI Class Initialized
DEBUG - 2016-05-21 02:30:14 --> Router Class Initialized
DEBUG - 2016-05-21 02:30:14 --> Output Class Initialized
DEBUG - 2016-05-21 02:30:14 --> Security Class Initialized
DEBUG - 2016-05-21 02:30:14 --> Input Class Initialized
DEBUG - 2016-05-21 02:30:14 --> XSS Filtering completed
DEBUG - 2016-05-21 02:30:14 --> XSS Filtering completed
DEBUG - 2016-05-21 02:30:14 --> XSS Filtering completed
DEBUG - 2016-05-21 02:30:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 02:30:14 --> Language Class Initialized
DEBUG - 2016-05-21 02:30:14 --> Loader Class Initialized
DEBUG - 2016-05-21 02:30:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 02:30:14 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 02:30:14 --> Helper loaded: url_helper
DEBUG - 2016-05-21 02:30:14 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 02:30:14 --> Helper loaded: file_helper
DEBUG - 2016-05-21 02:30:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:30:14 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 02:30:14 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 02:30:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:30:14 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 02:30:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 02:30:14 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:30:14 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 02:30:14 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:30:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 02:30:14 --> Helper loaded: form_helper
DEBUG - 2016-05-21 02:30:14 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 02:30:14 --> Helper loaded: security_helper
DEBUG - 2016-05-21 02:30:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:30:14 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 02:30:14 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 02:30:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:30:14 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 02:30:14 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 02:30:14 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 02:30:14 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 02:30:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:30:14 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 02:30:14 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 02:30:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:30:14 --> Database Driver Class Initialized
DEBUG - 2016-05-21 02:30:14 --> Session Class Initialized
DEBUG - 2016-05-21 02:30:14 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 02:30:14 --> Helper loaded: string_helper
DEBUG - 2016-05-21 02:30:14 --> Session routines successfully run
DEBUG - 2016-05-21 02:30:14 --> Native_session Class Initialized
DEBUG - 2016-05-21 02:30:14 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 02:30:14 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:30:14 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:30:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 02:30:14 --> Controller Class Initialized
DEBUG - 2016-05-21 02:30:14 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 02:30:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 02:30:14 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 02:30:14 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:30:14 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:30:14 --> User Agent Class Initialized
DEBUG - 2016-05-21 02:30:14 --> Model Class Initialized
DEBUG - 2016-05-21 02:30:14 --> Model Class Initialized
DEBUG - 2016-05-21 02:30:14 --> Model Class Initialized
DEBUG - 2016-05-21 02:30:14 --> Model Class Initialized
DEBUG - 2016-05-21 02:30:14 --> Model Class Initialized
DEBUG - 2016-05-21 02:31:29 --> Config Class Initialized
DEBUG - 2016-05-21 02:31:29 --> Hooks Class Initialized
DEBUG - 2016-05-21 02:31:29 --> Utf8 Class Initialized
DEBUG - 2016-05-21 02:31:29 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 02:31:29 --> URI Class Initialized
DEBUG - 2016-05-21 02:31:29 --> Router Class Initialized
DEBUG - 2016-05-21 02:31:29 --> Output Class Initialized
DEBUG - 2016-05-21 02:31:29 --> Security Class Initialized
DEBUG - 2016-05-21 02:31:29 --> Input Class Initialized
DEBUG - 2016-05-21 02:31:29 --> XSS Filtering completed
DEBUG - 2016-05-21 02:31:29 --> XSS Filtering completed
DEBUG - 2016-05-21 02:31:29 --> XSS Filtering completed
DEBUG - 2016-05-21 02:31:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 02:31:29 --> Language Class Initialized
DEBUG - 2016-05-21 02:31:29 --> Loader Class Initialized
DEBUG - 2016-05-21 02:31:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 02:31:29 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 02:31:29 --> Helper loaded: url_helper
DEBUG - 2016-05-21 02:31:29 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 02:31:29 --> Helper loaded: file_helper
DEBUG - 2016-05-21 02:31:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:31:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 02:31:29 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 02:31:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 02:31:29 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 02:31:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 02:31:29 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:31:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 02:31:29 --> Helper loaded: common_helper
DEBUG - 2016-05-21 02:31:29 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 02:31:29 --> Helper loaded: form_helper
DEBUG - 2016-05-21 02:31:29 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 02:31:29 --> Helper loaded: security_helper
DEBUG - 2016-05-21 02:31:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:31:29 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 02:31:29 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 02:31:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 02:31:29 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 02:31:29 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 02:31:29 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 02:31:29 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 02:31:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:31:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 02:31:29 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 02:31:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 02:31:29 --> Database Driver Class Initialized
DEBUG - 2016-05-21 02:31:29 --> Session Class Initialized
DEBUG - 2016-05-21 02:31:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 02:31:29 --> Helper loaded: string_helper
DEBUG - 2016-05-21 02:31:29 --> Session routines successfully run
DEBUG - 2016-05-21 02:31:29 --> Native_session Class Initialized
DEBUG - 2016-05-21 02:31:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 02:31:29 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:31:29 --> Form Validation Class Initialized
DEBUG - 2016-05-21 02:31:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 02:31:29 --> Controller Class Initialized
DEBUG - 2016-05-21 02:31:29 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 02:31:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 02:31:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 02:31:29 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:31:29 --> Carabiner: library configured.
DEBUG - 2016-05-21 02:31:29 --> User Agent Class Initialized
DEBUG - 2016-05-21 02:31:29 --> Model Class Initialized
DEBUG - 2016-05-21 02:31:29 --> Model Class Initialized
DEBUG - 2016-05-21 02:31:29 --> Model Class Initialized
DEBUG - 2016-05-21 02:31:29 --> Model Class Initialized
DEBUG - 2016-05-21 02:31:29 --> Model Class Initialized
DEBUG - 2016-05-21 11:25:09 --> Config Class Initialized
DEBUG - 2016-05-21 11:25:09 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:25:09 --> Utf8 Class Initialized
DEBUG - 2016-05-21 11:25:09 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 11:25:09 --> URI Class Initialized
DEBUG - 2016-05-21 11:25:09 --> Router Class Initialized
DEBUG - 2016-05-21 11:25:09 --> Output Class Initialized
DEBUG - 2016-05-21 11:25:09 --> Security Class Initialized
DEBUG - 2016-05-21 11:25:09 --> Input Class Initialized
DEBUG - 2016-05-21 11:25:09 --> XSS Filtering completed
DEBUG - 2016-05-21 11:25:09 --> XSS Filtering completed
DEBUG - 2016-05-21 11:25:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 11:25:09 --> Language Class Initialized
DEBUG - 2016-05-21 11:25:09 --> Loader Class Initialized
DEBUG - 2016-05-21 11:25:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 11:25:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 11:25:09 --> Helper loaded: url_helper
DEBUG - 2016-05-21 11:25:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 11:25:09 --> Helper loaded: file_helper
DEBUG - 2016-05-21 11:25:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 11:25:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 11:25:09 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 11:25:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 11:25:09 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 11:25:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 11:25:09 --> Helper loaded: common_helper
DEBUG - 2016-05-21 11:25:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 11:25:09 --> Helper loaded: common_helper
DEBUG - 2016-05-21 11:25:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 11:25:09 --> Helper loaded: form_helper
DEBUG - 2016-05-21 11:25:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 11:25:09 --> Helper loaded: security_helper
DEBUG - 2016-05-21 11:25:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 11:25:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 11:25:09 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 11:25:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 11:25:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 11:25:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 11:25:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 11:25:09 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 11:25:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 11:25:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 11:25:09 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 11:25:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 11:25:09 --> Database Driver Class Initialized
DEBUG - 2016-05-21 11:25:09 --> Session Class Initialized
DEBUG - 2016-05-21 11:25:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 11:25:09 --> Helper loaded: string_helper
DEBUG - 2016-05-21 11:25:09 --> A session cookie was not found.
DEBUG - 2016-05-21 11:25:10 --> Session routines successfully run
DEBUG - 2016-05-21 11:25:10 --> Native_session Class Initialized
DEBUG - 2016-05-21 11:25:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 11:25:10 --> Form Validation Class Initialized
DEBUG - 2016-05-21 11:25:10 --> Form Validation Class Initialized
DEBUG - 2016-05-21 11:25:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 11:25:10 --> Controller Class Initialized
DEBUG - 2016-05-21 11:25:10 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 11:25:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 11:25:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 11:25:10 --> Carabiner: library configured.
DEBUG - 2016-05-21 11:25:10 --> Carabiner: library configured.
DEBUG - 2016-05-21 11:25:10 --> User Agent Class Initialized
DEBUG - 2016-05-21 11:25:10 --> Model Class Initialized
DEBUG - 2016-05-21 11:25:10 --> Model Class Initialized
DEBUG - 2016-05-21 11:25:10 --> Model Class Initialized
DEBUG - 2016-05-21 11:25:10 --> Model Class Initialized
DEBUG - 2016-05-21 11:25:10 --> Model Class Initialized
DEBUG - 2016-05-21 11:39:53 --> Config Class Initialized
DEBUG - 2016-05-21 11:39:53 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:39:53 --> Utf8 Class Initialized
DEBUG - 2016-05-21 11:39:53 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 11:39:53 --> URI Class Initialized
DEBUG - 2016-05-21 11:39:53 --> Router Class Initialized
DEBUG - 2016-05-21 11:39:53 --> Output Class Initialized
DEBUG - 2016-05-21 11:39:53 --> Security Class Initialized
DEBUG - 2016-05-21 11:39:53 --> Input Class Initialized
DEBUG - 2016-05-21 11:39:53 --> XSS Filtering completed
DEBUG - 2016-05-21 11:39:53 --> XSS Filtering completed
DEBUG - 2016-05-21 11:39:53 --> XSS Filtering completed
DEBUG - 2016-05-21 11:39:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 11:39:53 --> Language Class Initialized
DEBUG - 2016-05-21 11:39:53 --> Loader Class Initialized
DEBUG - 2016-05-21 11:39:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 11:39:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 11:39:53 --> Helper loaded: url_helper
DEBUG - 2016-05-21 11:39:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 11:39:53 --> Helper loaded: file_helper
DEBUG - 2016-05-21 11:39:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 11:39:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 11:39:53 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 11:39:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 11:39:53 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 11:39:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 11:39:53 --> Helper loaded: common_helper
DEBUG - 2016-05-21 11:39:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 11:39:53 --> Helper loaded: common_helper
DEBUG - 2016-05-21 11:39:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 11:39:53 --> Helper loaded: form_helper
DEBUG - 2016-05-21 11:39:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 11:39:53 --> Helper loaded: security_helper
DEBUG - 2016-05-21 11:39:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 11:39:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 11:39:53 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 11:39:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 11:39:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 11:39:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 11:39:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 11:39:53 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 11:39:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 11:39:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 11:39:53 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 11:39:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 11:39:54 --> Database Driver Class Initialized
DEBUG - 2016-05-21 11:39:54 --> Session Class Initialized
DEBUG - 2016-05-21 11:39:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 11:39:54 --> Helper loaded: string_helper
DEBUG - 2016-05-21 11:39:54 --> Session routines successfully run
DEBUG - 2016-05-21 11:39:54 --> Native_session Class Initialized
DEBUG - 2016-05-21 11:39:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 11:39:54 --> Form Validation Class Initialized
DEBUG - 2016-05-21 11:39:54 --> Form Validation Class Initialized
DEBUG - 2016-05-21 11:39:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 11:39:54 --> Controller Class Initialized
DEBUG - 2016-05-21 11:39:54 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 11:39:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 11:39:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 11:39:54 --> Carabiner: library configured.
DEBUG - 2016-05-21 11:39:54 --> Carabiner: library configured.
DEBUG - 2016-05-21 11:39:54 --> User Agent Class Initialized
DEBUG - 2016-05-21 11:39:54 --> Model Class Initialized
DEBUG - 2016-05-21 11:39:54 --> Model Class Initialized
DEBUG - 2016-05-21 11:39:54 --> Model Class Initialized
DEBUG - 2016-05-21 11:39:54 --> Model Class Initialized
DEBUG - 2016-05-21 11:39:54 --> Model Class Initialized
DEBUG - 2016-05-21 11:40:01 --> Config Class Initialized
DEBUG - 2016-05-21 11:40:01 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:40:01 --> Utf8 Class Initialized
DEBUG - 2016-05-21 11:40:01 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 11:40:01 --> URI Class Initialized
DEBUG - 2016-05-21 11:40:01 --> Router Class Initialized
DEBUG - 2016-05-21 11:40:01 --> Output Class Initialized
DEBUG - 2016-05-21 11:40:01 --> Security Class Initialized
DEBUG - 2016-05-21 11:40:02 --> Input Class Initialized
DEBUG - 2016-05-21 11:40:02 --> XSS Filtering completed
DEBUG - 2016-05-21 11:40:02 --> XSS Filtering completed
DEBUG - 2016-05-21 11:40:02 --> XSS Filtering completed
DEBUG - 2016-05-21 11:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 11:40:02 --> Language Class Initialized
DEBUG - 2016-05-21 11:40:02 --> Loader Class Initialized
DEBUG - 2016-05-21 11:40:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 11:40:02 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 11:40:02 --> Helper loaded: url_helper
DEBUG - 2016-05-21 11:40:02 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 11:40:02 --> Helper loaded: file_helper
DEBUG - 2016-05-21 11:40:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 11:40:02 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 11:40:02 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 11:40:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 11:40:02 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 11:40:02 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 11:40:02 --> Helper loaded: common_helper
DEBUG - 2016-05-21 11:40:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 11:40:02 --> Helper loaded: common_helper
DEBUG - 2016-05-21 11:40:02 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 11:40:02 --> Helper loaded: form_helper
DEBUG - 2016-05-21 11:40:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 11:40:02 --> Helper loaded: security_helper
DEBUG - 2016-05-21 11:40:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 11:40:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 11:40:02 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 11:40:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 11:40:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 11:40:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 11:40:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 11:40:02 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 11:40:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 11:40:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 11:40:02 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 11:40:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 11:40:02 --> Database Driver Class Initialized
DEBUG - 2016-05-21 11:40:02 --> Session Class Initialized
DEBUG - 2016-05-21 11:40:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 11:40:02 --> Helper loaded: string_helper
DEBUG - 2016-05-21 11:40:02 --> Session routines successfully run
DEBUG - 2016-05-21 11:40:02 --> Native_session Class Initialized
DEBUG - 2016-05-21 11:40:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 11:40:02 --> Form Validation Class Initialized
DEBUG - 2016-05-21 11:40:02 --> Form Validation Class Initialized
DEBUG - 2016-05-21 11:40:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 11:40:02 --> Controller Class Initialized
DEBUG - 2016-05-21 11:40:02 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 11:40:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 11:40:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 11:40:02 --> Carabiner: library configured.
DEBUG - 2016-05-21 11:40:02 --> Carabiner: library configured.
DEBUG - 2016-05-21 11:40:02 --> User Agent Class Initialized
DEBUG - 2016-05-21 11:40:02 --> Model Class Initialized
DEBUG - 2016-05-21 11:40:02 --> Model Class Initialized
DEBUG - 2016-05-21 11:40:02 --> Model Class Initialized
DEBUG - 2016-05-21 11:40:02 --> Model Class Initialized
DEBUG - 2016-05-21 11:40:02 --> Model Class Initialized
DEBUG - 2016-05-21 11:41:00 --> Config Class Initialized
DEBUG - 2016-05-21 11:41:00 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:41:00 --> Utf8 Class Initialized
DEBUG - 2016-05-21 11:41:00 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 11:41:00 --> URI Class Initialized
DEBUG - 2016-05-21 11:41:00 --> Router Class Initialized
DEBUG - 2016-05-21 11:41:00 --> Output Class Initialized
DEBUG - 2016-05-21 11:41:00 --> Security Class Initialized
DEBUG - 2016-05-21 11:41:00 --> Input Class Initialized
DEBUG - 2016-05-21 11:41:00 --> XSS Filtering completed
DEBUG - 2016-05-21 11:41:00 --> XSS Filtering completed
DEBUG - 2016-05-21 11:41:00 --> XSS Filtering completed
DEBUG - 2016-05-21 11:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 11:41:00 --> Language Class Initialized
DEBUG - 2016-05-21 11:41:00 --> Loader Class Initialized
DEBUG - 2016-05-21 11:41:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 11:41:00 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 11:41:00 --> Helper loaded: url_helper
DEBUG - 2016-05-21 11:41:00 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 11:41:00 --> Helper loaded: file_helper
DEBUG - 2016-05-21 11:41:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 11:41:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 11:41:00 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 11:41:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 11:41:00 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 11:41:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 11:41:00 --> Helper loaded: common_helper
DEBUG - 2016-05-21 11:41:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 11:41:00 --> Helper loaded: common_helper
DEBUG - 2016-05-21 11:41:00 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 11:41:00 --> Helper loaded: form_helper
DEBUG - 2016-05-21 11:41:00 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 11:41:00 --> Helper loaded: security_helper
DEBUG - 2016-05-21 11:41:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 11:41:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 11:41:00 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 11:41:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 11:41:00 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 11:41:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 11:41:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 11:41:00 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 11:41:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 11:41:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 11:41:00 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 11:41:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 11:41:00 --> Database Driver Class Initialized
DEBUG - 2016-05-21 11:41:00 --> Session Class Initialized
DEBUG - 2016-05-21 11:41:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 11:41:00 --> Helper loaded: string_helper
DEBUG - 2016-05-21 11:41:00 --> Session routines successfully run
DEBUG - 2016-05-21 11:41:00 --> Native_session Class Initialized
DEBUG - 2016-05-21 11:41:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 11:41:00 --> Form Validation Class Initialized
DEBUG - 2016-05-21 11:41:00 --> Form Validation Class Initialized
DEBUG - 2016-05-21 11:41:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 11:41:00 --> Controller Class Initialized
DEBUG - 2016-05-21 11:41:00 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 11:41:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 11:41:00 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 11:41:00 --> Carabiner: library configured.
DEBUG - 2016-05-21 11:41:00 --> Carabiner: library configured.
DEBUG - 2016-05-21 11:41:00 --> User Agent Class Initialized
DEBUG - 2016-05-21 11:41:00 --> Model Class Initialized
DEBUG - 2016-05-21 11:41:00 --> Model Class Initialized
DEBUG - 2016-05-21 11:41:00 --> Model Class Initialized
DEBUG - 2016-05-21 11:41:01 --> Model Class Initialized
DEBUG - 2016-05-21 11:41:01 --> Model Class Initialized
ERROR - 2016-05-21 11:41:01 --> Severity: Warning  --> mkdir(): Invalid argument E:\www\lwscodeigniterwrapper\helpers\LWS_common_helper.php 814
DEBUG - 2016-05-21 11:49:46 --> Config Class Initialized
DEBUG - 2016-05-21 11:49:46 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:49:46 --> Utf8 Class Initialized
DEBUG - 2016-05-21 11:49:46 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 11:49:46 --> URI Class Initialized
DEBUG - 2016-05-21 11:49:46 --> Router Class Initialized
DEBUG - 2016-05-21 11:49:46 --> Output Class Initialized
DEBUG - 2016-05-21 11:49:46 --> Security Class Initialized
DEBUG - 2016-05-21 11:49:46 --> Input Class Initialized
DEBUG - 2016-05-21 11:49:46 --> XSS Filtering completed
DEBUG - 2016-05-21 11:49:46 --> XSS Filtering completed
DEBUG - 2016-05-21 11:49:46 --> XSS Filtering completed
DEBUG - 2016-05-21 11:49:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 11:49:46 --> Language Class Initialized
DEBUG - 2016-05-21 11:49:46 --> Loader Class Initialized
DEBUG - 2016-05-21 11:49:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 11:49:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 11:49:46 --> Helper loaded: url_helper
DEBUG - 2016-05-21 11:49:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 11:49:46 --> Helper loaded: file_helper
DEBUG - 2016-05-21 11:49:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 11:49:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 11:49:46 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 11:49:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 11:49:46 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 11:49:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 11:49:46 --> Helper loaded: common_helper
DEBUG - 2016-05-21 11:49:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 11:49:46 --> Helper loaded: common_helper
DEBUG - 2016-05-21 11:49:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 11:49:46 --> Helper loaded: form_helper
DEBUG - 2016-05-21 11:49:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 11:49:46 --> Helper loaded: security_helper
DEBUG - 2016-05-21 11:49:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 11:49:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 11:49:46 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 11:49:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 11:49:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 11:49:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 11:49:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 11:49:46 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 11:49:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 11:49:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 11:49:46 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 11:49:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 11:49:46 --> Database Driver Class Initialized
DEBUG - 2016-05-21 11:49:46 --> Session Class Initialized
DEBUG - 2016-05-21 11:49:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 11:49:46 --> Helper loaded: string_helper
DEBUG - 2016-05-21 11:49:46 --> Session routines successfully run
DEBUG - 2016-05-21 11:49:46 --> Native_session Class Initialized
DEBUG - 2016-05-21 11:49:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 11:49:46 --> Form Validation Class Initialized
DEBUG - 2016-05-21 11:49:46 --> Form Validation Class Initialized
DEBUG - 2016-05-21 11:49:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 11:49:46 --> Controller Class Initialized
DEBUG - 2016-05-21 11:49:46 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 11:49:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 11:49:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 11:49:46 --> Carabiner: library configured.
DEBUG - 2016-05-21 11:49:46 --> Carabiner: library configured.
DEBUG - 2016-05-21 11:49:46 --> User Agent Class Initialized
DEBUG - 2016-05-21 11:49:46 --> Model Class Initialized
DEBUG - 2016-05-21 11:49:46 --> Model Class Initialized
DEBUG - 2016-05-21 11:49:46 --> Model Class Initialized
DEBUG - 2016-05-21 11:49:46 --> Model Class Initialized
DEBUG - 2016-05-21 11:49:46 --> Model Class Initialized
ERROR - 2016-05-21 11:49:46 --> Severity: Warning  --> mkdir(): Invalid argument E:\www\lwscodeigniterwrapper\helpers\LWS_common_helper.php 814
DEBUG - 2016-05-21 11:56:37 --> Config Class Initialized
DEBUG - 2016-05-21 11:56:37 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:56:37 --> Utf8 Class Initialized
DEBUG - 2016-05-21 11:56:37 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 11:56:37 --> URI Class Initialized
DEBUG - 2016-05-21 11:56:37 --> Router Class Initialized
DEBUG - 2016-05-21 11:56:37 --> Output Class Initialized
DEBUG - 2016-05-21 11:56:37 --> Security Class Initialized
DEBUG - 2016-05-21 11:56:37 --> Input Class Initialized
DEBUG - 2016-05-21 11:56:37 --> XSS Filtering completed
DEBUG - 2016-05-21 11:56:37 --> XSS Filtering completed
DEBUG - 2016-05-21 11:56:37 --> XSS Filtering completed
DEBUG - 2016-05-21 11:56:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 11:56:37 --> Language Class Initialized
DEBUG - 2016-05-21 11:56:37 --> Loader Class Initialized
DEBUG - 2016-05-21 11:56:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 11:56:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 11:56:37 --> Helper loaded: url_helper
DEBUG - 2016-05-21 11:56:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 11:56:37 --> Helper loaded: file_helper
DEBUG - 2016-05-21 11:56:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 11:56:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 11:56:37 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 11:56:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 11:56:37 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 11:56:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 11:56:37 --> Helper loaded: common_helper
DEBUG - 2016-05-21 11:56:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 11:56:37 --> Helper loaded: common_helper
DEBUG - 2016-05-21 11:56:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 11:56:37 --> Helper loaded: form_helper
DEBUG - 2016-05-21 11:56:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 11:56:37 --> Helper loaded: security_helper
DEBUG - 2016-05-21 11:56:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 11:56:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 11:56:37 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 11:56:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 11:56:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 11:56:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 11:56:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 11:56:38 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 11:56:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 11:56:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 11:56:38 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 11:56:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 11:56:38 --> Database Driver Class Initialized
DEBUG - 2016-05-21 11:56:38 --> Session Class Initialized
DEBUG - 2016-05-21 11:56:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 11:56:38 --> Helper loaded: string_helper
DEBUG - 2016-05-21 11:56:38 --> Session routines successfully run
DEBUG - 2016-05-21 11:56:38 --> Native_session Class Initialized
DEBUG - 2016-05-21 11:56:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 11:56:38 --> Form Validation Class Initialized
DEBUG - 2016-05-21 11:56:38 --> Form Validation Class Initialized
DEBUG - 2016-05-21 11:56:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 11:56:38 --> Controller Class Initialized
DEBUG - 2016-05-21 11:56:38 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 11:56:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 11:56:38 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 11:56:38 --> Carabiner: library configured.
DEBUG - 2016-05-21 11:56:38 --> Carabiner: library configured.
DEBUG - 2016-05-21 11:56:38 --> User Agent Class Initialized
DEBUG - 2016-05-21 11:56:38 --> Model Class Initialized
DEBUG - 2016-05-21 11:56:38 --> Model Class Initialized
DEBUG - 2016-05-21 11:56:38 --> Model Class Initialized
DEBUG - 2016-05-21 11:56:38 --> Model Class Initialized
DEBUG - 2016-05-21 11:56:38 --> Model Class Initialized
ERROR - 2016-05-21 11:56:38 --> Severity: Warning  --> mkdir(): Invalid argument E:\www\lwscodeigniterwrapper\helpers\LWS_common_helper.php 823
DEBUG - 2016-05-21 11:57:16 --> Config Class Initialized
DEBUG - 2016-05-21 11:57:16 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:57:16 --> Utf8 Class Initialized
DEBUG - 2016-05-21 11:57:16 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 11:57:16 --> URI Class Initialized
DEBUG - 2016-05-21 11:57:16 --> Router Class Initialized
DEBUG - 2016-05-21 11:57:16 --> Output Class Initialized
DEBUG - 2016-05-21 11:57:16 --> Security Class Initialized
DEBUG - 2016-05-21 11:57:16 --> Input Class Initialized
DEBUG - 2016-05-21 11:57:16 --> XSS Filtering completed
DEBUG - 2016-05-21 11:57:16 --> XSS Filtering completed
DEBUG - 2016-05-21 11:57:16 --> XSS Filtering completed
DEBUG - 2016-05-21 11:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 11:57:16 --> Language Class Initialized
DEBUG - 2016-05-21 11:57:16 --> Loader Class Initialized
DEBUG - 2016-05-21 11:57:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 11:57:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 11:57:16 --> Helper loaded: url_helper
DEBUG - 2016-05-21 11:57:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 11:57:16 --> Helper loaded: file_helper
DEBUG - 2016-05-21 11:57:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 11:57:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 11:57:16 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 11:57:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 11:57:16 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 11:57:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 11:57:16 --> Helper loaded: common_helper
DEBUG - 2016-05-21 11:57:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 11:57:16 --> Helper loaded: common_helper
DEBUG - 2016-05-21 11:57:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 11:57:16 --> Helper loaded: form_helper
DEBUG - 2016-05-21 11:57:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 11:57:16 --> Helper loaded: security_helper
DEBUG - 2016-05-21 11:57:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 11:57:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 11:57:16 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 11:57:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 11:57:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 11:57:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 11:57:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 11:57:16 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 11:57:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 11:57:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 11:57:16 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 11:57:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 11:57:16 --> Database Driver Class Initialized
DEBUG - 2016-05-21 11:57:16 --> Session Class Initialized
DEBUG - 2016-05-21 11:57:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 11:57:16 --> Helper loaded: string_helper
DEBUG - 2016-05-21 11:57:16 --> Session routines successfully run
DEBUG - 2016-05-21 11:57:16 --> Native_session Class Initialized
DEBUG - 2016-05-21 11:57:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 11:57:16 --> Form Validation Class Initialized
DEBUG - 2016-05-21 11:57:16 --> Form Validation Class Initialized
DEBUG - 2016-05-21 11:57:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 11:57:16 --> Controller Class Initialized
DEBUG - 2016-05-21 11:57:16 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 11:57:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 11:57:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 11:57:16 --> Carabiner: library configured.
DEBUG - 2016-05-21 11:57:16 --> Carabiner: library configured.
DEBUG - 2016-05-21 11:57:17 --> User Agent Class Initialized
DEBUG - 2016-05-21 11:57:17 --> Model Class Initialized
DEBUG - 2016-05-21 11:57:17 --> Model Class Initialized
DEBUG - 2016-05-21 11:57:17 --> Model Class Initialized
DEBUG - 2016-05-21 11:57:17 --> Model Class Initialized
DEBUG - 2016-05-21 11:57:17 --> Model Class Initialized
ERROR - 2016-05-21 11:57:17 --> Severity: Warning  --> mkdir(): Invalid argument E:\www\lwscodeigniterwrapper\helpers\LWS_common_helper.php 823
DEBUG - 2016-05-21 11:58:26 --> Config Class Initialized
DEBUG - 2016-05-21 11:58:26 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:58:26 --> Utf8 Class Initialized
DEBUG - 2016-05-21 11:58:26 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 11:58:26 --> URI Class Initialized
DEBUG - 2016-05-21 11:58:26 --> Router Class Initialized
DEBUG - 2016-05-21 11:58:26 --> Output Class Initialized
DEBUG - 2016-05-21 11:58:26 --> Security Class Initialized
DEBUG - 2016-05-21 11:58:26 --> Input Class Initialized
DEBUG - 2016-05-21 11:58:26 --> XSS Filtering completed
DEBUG - 2016-05-21 11:58:26 --> XSS Filtering completed
DEBUG - 2016-05-21 11:58:26 --> XSS Filtering completed
DEBUG - 2016-05-21 11:58:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 11:58:26 --> Language Class Initialized
DEBUG - 2016-05-21 11:58:26 --> Loader Class Initialized
DEBUG - 2016-05-21 11:58:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 11:58:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 11:58:26 --> Helper loaded: url_helper
DEBUG - 2016-05-21 11:58:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 11:58:26 --> Helper loaded: file_helper
DEBUG - 2016-05-21 11:58:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 11:58:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 11:58:26 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 11:58:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 11:58:26 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 11:58:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 11:58:26 --> Helper loaded: common_helper
DEBUG - 2016-05-21 11:58:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 11:58:26 --> Helper loaded: common_helper
DEBUG - 2016-05-21 11:58:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 11:58:26 --> Helper loaded: form_helper
DEBUG - 2016-05-21 11:58:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 11:58:26 --> Helper loaded: security_helper
DEBUG - 2016-05-21 11:58:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 11:58:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 11:58:26 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 11:58:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 11:58:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 11:58:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 11:58:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 11:58:26 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 11:58:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 11:58:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 11:58:26 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 11:58:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 11:58:26 --> Database Driver Class Initialized
DEBUG - 2016-05-21 11:58:26 --> Session Class Initialized
DEBUG - 2016-05-21 11:58:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 11:58:26 --> Helper loaded: string_helper
DEBUG - 2016-05-21 11:58:26 --> Session routines successfully run
DEBUG - 2016-05-21 11:58:26 --> Native_session Class Initialized
DEBUG - 2016-05-21 11:58:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 11:58:26 --> Form Validation Class Initialized
DEBUG - 2016-05-21 11:58:26 --> Form Validation Class Initialized
DEBUG - 2016-05-21 11:58:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 11:58:26 --> Controller Class Initialized
DEBUG - 2016-05-21 11:58:26 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 11:58:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 11:58:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 11:58:26 --> Carabiner: library configured.
DEBUG - 2016-05-21 11:58:26 --> Carabiner: library configured.
DEBUG - 2016-05-21 11:58:26 --> User Agent Class Initialized
DEBUG - 2016-05-21 11:58:26 --> Model Class Initialized
DEBUG - 2016-05-21 11:58:26 --> Model Class Initialized
DEBUG - 2016-05-21 11:58:26 --> Model Class Initialized
DEBUG - 2016-05-21 11:58:26 --> Model Class Initialized
DEBUG - 2016-05-21 11:58:26 --> Model Class Initialized
ERROR - 2016-05-21 11:58:26 --> Severity: Warning  --> mkdir(): Invalid argument E:\www\lwscodeigniterwrapper\helpers\LWS_common_helper.php 823
DEBUG - 2016-05-21 11:58:45 --> Config Class Initialized
DEBUG - 2016-05-21 11:58:45 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:58:45 --> Utf8 Class Initialized
DEBUG - 2016-05-21 11:58:45 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 11:58:45 --> URI Class Initialized
DEBUG - 2016-05-21 11:58:45 --> Router Class Initialized
DEBUG - 2016-05-21 11:58:45 --> Output Class Initialized
DEBUG - 2016-05-21 11:58:45 --> Security Class Initialized
DEBUG - 2016-05-21 11:58:45 --> Input Class Initialized
DEBUG - 2016-05-21 11:58:45 --> XSS Filtering completed
DEBUG - 2016-05-21 11:58:45 --> XSS Filtering completed
DEBUG - 2016-05-21 11:58:45 --> XSS Filtering completed
DEBUG - 2016-05-21 11:58:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 11:58:45 --> Language Class Initialized
DEBUG - 2016-05-21 11:58:45 --> Loader Class Initialized
DEBUG - 2016-05-21 11:58:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 11:58:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 11:58:45 --> Helper loaded: url_helper
DEBUG - 2016-05-21 11:58:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 11:58:45 --> Helper loaded: file_helper
DEBUG - 2016-05-21 11:58:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 11:58:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 11:58:45 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 11:58:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 11:58:45 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 11:58:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 11:58:45 --> Helper loaded: common_helper
DEBUG - 2016-05-21 11:58:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 11:58:45 --> Helper loaded: common_helper
DEBUG - 2016-05-21 11:58:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 11:58:45 --> Helper loaded: form_helper
DEBUG - 2016-05-21 11:58:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 11:58:45 --> Helper loaded: security_helper
DEBUG - 2016-05-21 11:58:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 11:58:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 11:58:45 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 11:58:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 11:58:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 11:58:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 11:58:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 11:58:45 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 11:58:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 11:58:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 11:58:45 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 11:58:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 11:58:45 --> Database Driver Class Initialized
DEBUG - 2016-05-21 11:58:45 --> Session Class Initialized
DEBUG - 2016-05-21 11:58:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 11:58:46 --> Helper loaded: string_helper
DEBUG - 2016-05-21 11:58:46 --> Session routines successfully run
DEBUG - 2016-05-21 11:58:46 --> Native_session Class Initialized
DEBUG - 2016-05-21 11:58:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 11:58:46 --> Form Validation Class Initialized
DEBUG - 2016-05-21 11:58:46 --> Form Validation Class Initialized
DEBUG - 2016-05-21 11:58:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 11:58:46 --> Controller Class Initialized
DEBUG - 2016-05-21 11:58:46 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 11:58:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 11:58:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 11:58:46 --> Carabiner: library configured.
DEBUG - 2016-05-21 11:58:46 --> Carabiner: library configured.
DEBUG - 2016-05-21 11:58:46 --> User Agent Class Initialized
DEBUG - 2016-05-21 11:58:46 --> Model Class Initialized
DEBUG - 2016-05-21 11:58:46 --> Model Class Initialized
DEBUG - 2016-05-21 11:58:46 --> Model Class Initialized
DEBUG - 2016-05-21 11:58:46 --> Model Class Initialized
DEBUG - 2016-05-21 11:58:46 --> Model Class Initialized
ERROR - 2016-05-21 11:58:46 --> Severity: Warning  --> mkdir(): Invalid argument E:\www\lwscodeigniterwrapper\helpers\LWS_common_helper.php 823
DEBUG - 2016-05-21 11:58:58 --> Config Class Initialized
DEBUG - 2016-05-21 11:58:58 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:58:58 --> Utf8 Class Initialized
DEBUG - 2016-05-21 11:58:58 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 11:58:58 --> URI Class Initialized
DEBUG - 2016-05-21 11:58:58 --> Router Class Initialized
DEBUG - 2016-05-21 11:58:58 --> Output Class Initialized
DEBUG - 2016-05-21 11:58:58 --> Security Class Initialized
DEBUG - 2016-05-21 11:58:58 --> Input Class Initialized
DEBUG - 2016-05-21 11:58:58 --> XSS Filtering completed
DEBUG - 2016-05-21 11:58:58 --> XSS Filtering completed
DEBUG - 2016-05-21 11:58:58 --> XSS Filtering completed
DEBUG - 2016-05-21 11:58:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 11:58:58 --> Language Class Initialized
DEBUG - 2016-05-21 11:58:58 --> Loader Class Initialized
DEBUG - 2016-05-21 11:58:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 11:58:58 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 11:58:58 --> Helper loaded: url_helper
DEBUG - 2016-05-21 11:58:58 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 11:58:58 --> Helper loaded: file_helper
DEBUG - 2016-05-21 11:58:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 11:58:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 11:58:58 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 11:58:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 11:58:58 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 11:58:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 11:58:58 --> Helper loaded: common_helper
DEBUG - 2016-05-21 11:58:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 11:58:58 --> Helper loaded: common_helper
DEBUG - 2016-05-21 11:58:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 11:58:58 --> Helper loaded: form_helper
DEBUG - 2016-05-21 11:58:58 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 11:58:58 --> Helper loaded: security_helper
DEBUG - 2016-05-21 11:58:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 11:58:58 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 11:58:58 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 11:58:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 11:58:58 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 11:58:58 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 11:58:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 11:58:58 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 11:58:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 11:58:58 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 11:58:58 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 11:58:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 11:58:58 --> Database Driver Class Initialized
DEBUG - 2016-05-21 11:58:58 --> Session Class Initialized
DEBUG - 2016-05-21 11:58:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 11:58:58 --> Helper loaded: string_helper
DEBUG - 2016-05-21 11:58:58 --> Session routines successfully run
DEBUG - 2016-05-21 11:58:58 --> Native_session Class Initialized
DEBUG - 2016-05-21 11:58:58 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 11:58:58 --> Form Validation Class Initialized
DEBUG - 2016-05-21 11:58:58 --> Form Validation Class Initialized
DEBUG - 2016-05-21 11:58:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 11:58:58 --> Controller Class Initialized
DEBUG - 2016-05-21 11:58:58 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 11:58:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 11:58:58 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 11:58:58 --> Carabiner: library configured.
DEBUG - 2016-05-21 11:58:58 --> Carabiner: library configured.
DEBUG - 2016-05-21 11:58:58 --> User Agent Class Initialized
DEBUG - 2016-05-21 11:58:58 --> Model Class Initialized
DEBUG - 2016-05-21 11:58:58 --> Model Class Initialized
DEBUG - 2016-05-21 11:58:58 --> Model Class Initialized
DEBUG - 2016-05-21 11:58:58 --> Model Class Initialized
DEBUG - 2016-05-21 11:58:58 --> Model Class Initialized
DEBUG - 2016-05-21 12:00:45 --> Config Class Initialized
DEBUG - 2016-05-21 12:00:45 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:00:45 --> Utf8 Class Initialized
DEBUG - 2016-05-21 12:00:45 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 12:00:45 --> URI Class Initialized
DEBUG - 2016-05-21 12:00:45 --> Router Class Initialized
DEBUG - 2016-05-21 12:00:45 --> Output Class Initialized
DEBUG - 2016-05-21 12:00:45 --> Security Class Initialized
DEBUG - 2016-05-21 12:00:45 --> Input Class Initialized
DEBUG - 2016-05-21 12:00:45 --> XSS Filtering completed
DEBUG - 2016-05-21 12:00:45 --> XSS Filtering completed
DEBUG - 2016-05-21 12:00:45 --> XSS Filtering completed
DEBUG - 2016-05-21 12:00:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 12:00:45 --> Language Class Initialized
DEBUG - 2016-05-21 12:00:45 --> Loader Class Initialized
DEBUG - 2016-05-21 12:00:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 12:00:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 12:00:45 --> Helper loaded: url_helper
DEBUG - 2016-05-21 12:00:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 12:00:45 --> Helper loaded: file_helper
DEBUG - 2016-05-21 12:00:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:00:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 12:00:45 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 12:00:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:00:45 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 12:00:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 12:00:45 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:00:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 12:00:45 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:00:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 12:00:45 --> Helper loaded: form_helper
DEBUG - 2016-05-21 12:00:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 12:00:45 --> Helper loaded: security_helper
DEBUG - 2016-05-21 12:00:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:00:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 12:00:45 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 12:00:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:00:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 12:00:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 12:00:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 12:00:45 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 12:00:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:00:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 12:00:45 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 12:00:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:00:45 --> Database Driver Class Initialized
DEBUG - 2016-05-21 12:00:45 --> Session Class Initialized
DEBUG - 2016-05-21 12:00:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 12:00:45 --> Helper loaded: string_helper
DEBUG - 2016-05-21 12:00:45 --> Session routines successfully run
DEBUG - 2016-05-21 12:00:45 --> Native_session Class Initialized
DEBUG - 2016-05-21 12:00:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 12:00:45 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:00:45 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:00:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 12:00:45 --> Controller Class Initialized
DEBUG - 2016-05-21 12:00:45 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 12:00:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 12:00:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 12:00:45 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:00:45 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:00:45 --> User Agent Class Initialized
DEBUG - 2016-05-21 12:00:45 --> Model Class Initialized
DEBUG - 2016-05-21 12:00:45 --> Model Class Initialized
DEBUG - 2016-05-21 12:00:45 --> Model Class Initialized
DEBUG - 2016-05-21 12:00:45 --> Model Class Initialized
DEBUG - 2016-05-21 12:00:45 --> Model Class Initialized
DEBUG - 2016-05-21 12:01:06 --> Config Class Initialized
DEBUG - 2016-05-21 12:01:06 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:01:06 --> Utf8 Class Initialized
DEBUG - 2016-05-21 12:01:06 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 12:01:06 --> URI Class Initialized
DEBUG - 2016-05-21 12:01:06 --> Router Class Initialized
DEBUG - 2016-05-21 12:01:06 --> Output Class Initialized
DEBUG - 2016-05-21 12:01:06 --> Security Class Initialized
DEBUG - 2016-05-21 12:01:06 --> Input Class Initialized
DEBUG - 2016-05-21 12:01:06 --> XSS Filtering completed
DEBUG - 2016-05-21 12:01:06 --> XSS Filtering completed
DEBUG - 2016-05-21 12:01:06 --> XSS Filtering completed
DEBUG - 2016-05-21 12:01:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 12:01:06 --> Language Class Initialized
DEBUG - 2016-05-21 12:01:06 --> Loader Class Initialized
DEBUG - 2016-05-21 12:01:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 12:01:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 12:01:06 --> Helper loaded: url_helper
DEBUG - 2016-05-21 12:01:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 12:01:06 --> Helper loaded: file_helper
DEBUG - 2016-05-21 12:01:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:01:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 12:01:06 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 12:01:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:01:06 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 12:01:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 12:01:06 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:01:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 12:01:06 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:01:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 12:01:06 --> Helper loaded: form_helper
DEBUG - 2016-05-21 12:01:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 12:01:06 --> Helper loaded: security_helper
DEBUG - 2016-05-21 12:01:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:01:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 12:01:06 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 12:01:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:01:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 12:01:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 12:01:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 12:01:06 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 12:01:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:01:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 12:01:06 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 12:01:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:01:06 --> Database Driver Class Initialized
DEBUG - 2016-05-21 12:01:06 --> Session Class Initialized
DEBUG - 2016-05-21 12:01:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 12:01:06 --> Helper loaded: string_helper
DEBUG - 2016-05-21 12:01:06 --> Session routines successfully run
DEBUG - 2016-05-21 12:01:06 --> Native_session Class Initialized
DEBUG - 2016-05-21 12:01:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 12:01:06 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:01:06 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:01:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 12:01:06 --> Controller Class Initialized
DEBUG - 2016-05-21 12:01:06 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 12:01:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 12:01:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 12:01:06 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:01:06 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:01:06 --> User Agent Class Initialized
DEBUG - 2016-05-21 12:01:06 --> Model Class Initialized
DEBUG - 2016-05-21 12:01:07 --> Model Class Initialized
DEBUG - 2016-05-21 12:01:07 --> Model Class Initialized
DEBUG - 2016-05-21 12:01:07 --> Model Class Initialized
DEBUG - 2016-05-21 12:01:07 --> Model Class Initialized
ERROR - 2016-05-21 12:01:07 --> Severity: Warning  --> mkdir(): Invalid argument E:\www\lwscodeigniterwrapper\helpers\LWS_common_helper.php 825
DEBUG - 2016-05-21 12:12:57 --> Config Class Initialized
DEBUG - 2016-05-21 12:12:57 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:12:57 --> Utf8 Class Initialized
DEBUG - 2016-05-21 12:12:57 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 12:12:57 --> URI Class Initialized
DEBUG - 2016-05-21 12:12:57 --> Router Class Initialized
DEBUG - 2016-05-21 12:12:57 --> Output Class Initialized
DEBUG - 2016-05-21 12:12:57 --> Security Class Initialized
DEBUG - 2016-05-21 12:12:57 --> Input Class Initialized
DEBUG - 2016-05-21 12:12:57 --> XSS Filtering completed
DEBUG - 2016-05-21 12:12:57 --> XSS Filtering completed
DEBUG - 2016-05-21 12:12:57 --> XSS Filtering completed
DEBUG - 2016-05-21 12:12:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 12:12:57 --> Language Class Initialized
DEBUG - 2016-05-21 12:12:57 --> Loader Class Initialized
DEBUG - 2016-05-21 12:12:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 12:12:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 12:12:57 --> Helper loaded: url_helper
DEBUG - 2016-05-21 12:12:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 12:12:57 --> Helper loaded: file_helper
DEBUG - 2016-05-21 12:12:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:12:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 12:12:57 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 12:12:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:12:57 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 12:12:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 12:12:57 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:12:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 12:12:57 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:12:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 12:12:57 --> Helper loaded: form_helper
DEBUG - 2016-05-21 12:12:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 12:12:57 --> Helper loaded: security_helper
DEBUG - 2016-05-21 12:12:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:12:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 12:12:57 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 12:12:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:12:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 12:12:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 12:12:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 12:12:57 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 12:12:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:12:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 12:12:57 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 12:12:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:12:57 --> Database Driver Class Initialized
DEBUG - 2016-05-21 12:12:57 --> Session Class Initialized
DEBUG - 2016-05-21 12:12:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 12:12:57 --> Helper loaded: string_helper
DEBUG - 2016-05-21 12:12:57 --> Session routines successfully run
DEBUG - 2016-05-21 12:12:57 --> Native_session Class Initialized
DEBUG - 2016-05-21 12:12:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 12:12:57 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:12:57 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:12:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 12:12:57 --> Controller Class Initialized
DEBUG - 2016-05-21 12:12:57 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 12:12:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 12:12:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 12:12:57 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:12:57 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:12:57 --> User Agent Class Initialized
DEBUG - 2016-05-21 12:12:57 --> Model Class Initialized
DEBUG - 2016-05-21 12:12:57 --> Model Class Initialized
DEBUG - 2016-05-21 12:12:57 --> Model Class Initialized
DEBUG - 2016-05-21 12:12:57 --> Model Class Initialized
DEBUG - 2016-05-21 12:12:57 --> Model Class Initialized
DEBUG - 2016-05-21 12:13:57 --> Config Class Initialized
DEBUG - 2016-05-21 12:13:57 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:13:57 --> Utf8 Class Initialized
DEBUG - 2016-05-21 12:13:57 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 12:13:57 --> URI Class Initialized
DEBUG - 2016-05-21 12:13:57 --> Router Class Initialized
DEBUG - 2016-05-21 12:13:57 --> Output Class Initialized
DEBUG - 2016-05-21 12:13:57 --> Security Class Initialized
DEBUG - 2016-05-21 12:13:57 --> Input Class Initialized
DEBUG - 2016-05-21 12:13:57 --> XSS Filtering completed
DEBUG - 2016-05-21 12:13:57 --> XSS Filtering completed
DEBUG - 2016-05-21 12:13:57 --> XSS Filtering completed
DEBUG - 2016-05-21 12:13:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 12:13:57 --> Language Class Initialized
DEBUG - 2016-05-21 12:13:57 --> Loader Class Initialized
DEBUG - 2016-05-21 12:13:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 12:13:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 12:13:57 --> Helper loaded: url_helper
DEBUG - 2016-05-21 12:13:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 12:13:57 --> Helper loaded: file_helper
DEBUG - 2016-05-21 12:13:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:13:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 12:13:57 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 12:13:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:13:57 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 12:13:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 12:13:57 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:13:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 12:13:57 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:13:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 12:13:57 --> Helper loaded: form_helper
DEBUG - 2016-05-21 12:13:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 12:13:57 --> Helper loaded: security_helper
DEBUG - 2016-05-21 12:13:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:13:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 12:13:57 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 12:13:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:13:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 12:13:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 12:13:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 12:13:57 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 12:13:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:13:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 12:13:57 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 12:13:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:13:57 --> Database Driver Class Initialized
DEBUG - 2016-05-21 12:13:57 --> Session Class Initialized
DEBUG - 2016-05-21 12:13:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 12:13:57 --> Helper loaded: string_helper
DEBUG - 2016-05-21 12:13:57 --> Session routines successfully run
DEBUG - 2016-05-21 12:13:57 --> Native_session Class Initialized
DEBUG - 2016-05-21 12:13:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 12:13:57 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:13:57 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:13:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 12:13:57 --> Controller Class Initialized
DEBUG - 2016-05-21 12:13:57 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 12:13:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 12:13:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 12:13:57 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:13:57 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:13:58 --> User Agent Class Initialized
DEBUG - 2016-05-21 12:13:58 --> Model Class Initialized
DEBUG - 2016-05-21 12:13:58 --> Model Class Initialized
DEBUG - 2016-05-21 12:13:58 --> Model Class Initialized
DEBUG - 2016-05-21 12:13:58 --> Model Class Initialized
DEBUG - 2016-05-21 12:13:58 --> Model Class Initialized
DEBUG - 2016-05-21 12:14:32 --> Config Class Initialized
DEBUG - 2016-05-21 12:14:32 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:14:32 --> Utf8 Class Initialized
DEBUG - 2016-05-21 12:14:32 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 12:14:32 --> URI Class Initialized
DEBUG - 2016-05-21 12:14:32 --> Router Class Initialized
DEBUG - 2016-05-21 12:14:32 --> Output Class Initialized
DEBUG - 2016-05-21 12:14:32 --> Security Class Initialized
DEBUG - 2016-05-21 12:14:32 --> Input Class Initialized
DEBUG - 2016-05-21 12:14:32 --> XSS Filtering completed
DEBUG - 2016-05-21 12:14:32 --> XSS Filtering completed
DEBUG - 2016-05-21 12:14:32 --> XSS Filtering completed
DEBUG - 2016-05-21 12:14:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 12:14:32 --> Language Class Initialized
DEBUG - 2016-05-21 12:14:32 --> Loader Class Initialized
DEBUG - 2016-05-21 12:14:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 12:14:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 12:14:32 --> Helper loaded: url_helper
DEBUG - 2016-05-21 12:14:32 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 12:14:32 --> Helper loaded: file_helper
DEBUG - 2016-05-21 12:14:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:14:32 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 12:14:32 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 12:14:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:14:32 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 12:14:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 12:14:32 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:14:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 12:14:32 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:14:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 12:14:32 --> Helper loaded: form_helper
DEBUG - 2016-05-21 12:14:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 12:14:32 --> Helper loaded: security_helper
DEBUG - 2016-05-21 12:14:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:14:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 12:14:32 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 12:14:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:14:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 12:14:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 12:14:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 12:14:32 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 12:14:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:14:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 12:14:32 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 12:14:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:14:32 --> Database Driver Class Initialized
DEBUG - 2016-05-21 12:14:32 --> Session Class Initialized
DEBUG - 2016-05-21 12:14:32 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 12:14:32 --> Helper loaded: string_helper
DEBUG - 2016-05-21 12:14:32 --> Session routines successfully run
DEBUG - 2016-05-21 12:14:32 --> Native_session Class Initialized
DEBUG - 2016-05-21 12:14:32 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 12:14:32 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:14:32 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:14:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 12:14:32 --> Controller Class Initialized
DEBUG - 2016-05-21 12:14:32 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 12:14:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 12:14:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 12:14:32 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:14:32 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:14:32 --> User Agent Class Initialized
DEBUG - 2016-05-21 12:14:32 --> Model Class Initialized
DEBUG - 2016-05-21 12:14:32 --> Model Class Initialized
DEBUG - 2016-05-21 12:14:32 --> Model Class Initialized
DEBUG - 2016-05-21 12:14:32 --> Model Class Initialized
DEBUG - 2016-05-21 12:14:32 --> Model Class Initialized
DEBUG - 2016-05-21 12:14:53 --> Config Class Initialized
DEBUG - 2016-05-21 12:14:53 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:14:53 --> Utf8 Class Initialized
DEBUG - 2016-05-21 12:14:53 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 12:14:53 --> URI Class Initialized
DEBUG - 2016-05-21 12:14:53 --> Router Class Initialized
DEBUG - 2016-05-21 12:14:53 --> Output Class Initialized
DEBUG - 2016-05-21 12:14:53 --> Security Class Initialized
DEBUG - 2016-05-21 12:14:53 --> Input Class Initialized
DEBUG - 2016-05-21 12:14:53 --> XSS Filtering completed
DEBUG - 2016-05-21 12:14:53 --> XSS Filtering completed
DEBUG - 2016-05-21 12:14:53 --> XSS Filtering completed
DEBUG - 2016-05-21 12:14:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 12:14:53 --> Language Class Initialized
DEBUG - 2016-05-21 12:14:53 --> Loader Class Initialized
DEBUG - 2016-05-21 12:14:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 12:14:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 12:14:53 --> Helper loaded: url_helper
DEBUG - 2016-05-21 12:14:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 12:14:53 --> Helper loaded: file_helper
DEBUG - 2016-05-21 12:14:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:14:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 12:14:53 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 12:14:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:14:53 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 12:14:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 12:14:53 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:14:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 12:14:53 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:14:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 12:14:53 --> Helper loaded: form_helper
DEBUG - 2016-05-21 12:14:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 12:14:53 --> Helper loaded: security_helper
DEBUG - 2016-05-21 12:14:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:14:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 12:14:53 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 12:14:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:14:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 12:14:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 12:14:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 12:14:53 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 12:14:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:14:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 12:14:53 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 12:14:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:14:53 --> Database Driver Class Initialized
DEBUG - 2016-05-21 12:14:53 --> Session Class Initialized
DEBUG - 2016-05-21 12:14:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 12:14:53 --> Helper loaded: string_helper
DEBUG - 2016-05-21 12:14:53 --> Session routines successfully run
DEBUG - 2016-05-21 12:14:53 --> Native_session Class Initialized
DEBUG - 2016-05-21 12:14:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 12:14:53 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:14:53 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:14:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 12:14:53 --> Controller Class Initialized
DEBUG - 2016-05-21 12:14:53 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 12:14:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 12:14:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 12:14:53 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:14:53 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:14:53 --> User Agent Class Initialized
DEBUG - 2016-05-21 12:14:53 --> Model Class Initialized
DEBUG - 2016-05-21 12:14:53 --> Model Class Initialized
DEBUG - 2016-05-21 12:14:53 --> Model Class Initialized
DEBUG - 2016-05-21 12:14:53 --> Model Class Initialized
DEBUG - 2016-05-21 12:14:53 --> Model Class Initialized
DEBUG - 2016-05-21 12:15:49 --> Config Class Initialized
DEBUG - 2016-05-21 12:15:49 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:15:49 --> Utf8 Class Initialized
DEBUG - 2016-05-21 12:15:49 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 12:15:49 --> URI Class Initialized
DEBUG - 2016-05-21 12:15:49 --> Router Class Initialized
DEBUG - 2016-05-21 12:15:49 --> Output Class Initialized
DEBUG - 2016-05-21 12:15:49 --> Security Class Initialized
DEBUG - 2016-05-21 12:15:49 --> Input Class Initialized
DEBUG - 2016-05-21 12:15:49 --> XSS Filtering completed
DEBUG - 2016-05-21 12:15:49 --> XSS Filtering completed
DEBUG - 2016-05-21 12:15:49 --> XSS Filtering completed
DEBUG - 2016-05-21 12:15:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 12:15:49 --> Language Class Initialized
DEBUG - 2016-05-21 12:15:49 --> Loader Class Initialized
DEBUG - 2016-05-21 12:15:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 12:15:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 12:15:49 --> Helper loaded: url_helper
DEBUG - 2016-05-21 12:15:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 12:15:49 --> Helper loaded: file_helper
DEBUG - 2016-05-21 12:15:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:15:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 12:15:49 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 12:15:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:15:50 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 12:15:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 12:15:50 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:15:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 12:15:50 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:15:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 12:15:50 --> Helper loaded: form_helper
DEBUG - 2016-05-21 12:15:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 12:15:50 --> Helper loaded: security_helper
DEBUG - 2016-05-21 12:15:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:15:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 12:15:50 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 12:15:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:15:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 12:15:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 12:15:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 12:15:50 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 12:15:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:15:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 12:15:50 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 12:15:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:15:50 --> Database Driver Class Initialized
DEBUG - 2016-05-21 12:15:50 --> Session Class Initialized
DEBUG - 2016-05-21 12:15:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 12:15:50 --> Helper loaded: string_helper
DEBUG - 2016-05-21 12:15:50 --> Session routines successfully run
DEBUG - 2016-05-21 12:15:50 --> Native_session Class Initialized
DEBUG - 2016-05-21 12:15:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 12:15:50 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:15:50 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:15:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 12:15:50 --> Controller Class Initialized
DEBUG - 2016-05-21 12:15:50 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 12:15:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 12:15:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 12:15:50 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:15:50 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:15:50 --> User Agent Class Initialized
DEBUG - 2016-05-21 12:15:50 --> Model Class Initialized
DEBUG - 2016-05-21 12:15:50 --> Model Class Initialized
DEBUG - 2016-05-21 12:15:50 --> Model Class Initialized
DEBUG - 2016-05-21 12:15:50 --> Model Class Initialized
DEBUG - 2016-05-21 12:15:50 --> Model Class Initialized
DEBUG - 2016-05-21 12:16:20 --> Config Class Initialized
DEBUG - 2016-05-21 12:16:20 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:16:20 --> Utf8 Class Initialized
DEBUG - 2016-05-21 12:16:20 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 12:16:20 --> URI Class Initialized
DEBUG - 2016-05-21 12:16:20 --> Router Class Initialized
DEBUG - 2016-05-21 12:16:20 --> Output Class Initialized
DEBUG - 2016-05-21 12:16:20 --> Security Class Initialized
DEBUG - 2016-05-21 12:16:20 --> Input Class Initialized
DEBUG - 2016-05-21 12:16:20 --> XSS Filtering completed
DEBUG - 2016-05-21 12:16:20 --> XSS Filtering completed
DEBUG - 2016-05-21 12:16:20 --> XSS Filtering completed
DEBUG - 2016-05-21 12:16:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 12:16:20 --> Language Class Initialized
DEBUG - 2016-05-21 12:16:20 --> Loader Class Initialized
DEBUG - 2016-05-21 12:16:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 12:16:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 12:16:20 --> Helper loaded: url_helper
DEBUG - 2016-05-21 12:16:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 12:16:20 --> Helper loaded: file_helper
DEBUG - 2016-05-21 12:16:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:16:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 12:16:20 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 12:16:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:16:20 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 12:16:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 12:16:20 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:16:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 12:16:20 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:16:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 12:16:20 --> Helper loaded: form_helper
DEBUG - 2016-05-21 12:16:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 12:16:20 --> Helper loaded: security_helper
DEBUG - 2016-05-21 12:16:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:16:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 12:16:20 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 12:16:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:16:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 12:16:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 12:16:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 12:16:20 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 12:16:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:16:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 12:16:20 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 12:16:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:16:20 --> Database Driver Class Initialized
DEBUG - 2016-05-21 12:16:20 --> Session Class Initialized
DEBUG - 2016-05-21 12:16:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 12:16:20 --> Helper loaded: string_helper
DEBUG - 2016-05-21 12:16:20 --> Session routines successfully run
DEBUG - 2016-05-21 12:16:20 --> Native_session Class Initialized
DEBUG - 2016-05-21 12:16:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 12:16:20 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:16:20 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:16:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 12:16:20 --> Controller Class Initialized
DEBUG - 2016-05-21 12:16:20 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 12:16:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 12:16:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 12:16:20 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:16:20 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:16:20 --> User Agent Class Initialized
DEBUG - 2016-05-21 12:16:20 --> Model Class Initialized
DEBUG - 2016-05-21 12:16:20 --> Model Class Initialized
DEBUG - 2016-05-21 12:16:20 --> Model Class Initialized
DEBUG - 2016-05-21 12:16:20 --> Model Class Initialized
DEBUG - 2016-05-21 12:16:20 --> Model Class Initialized
DEBUG - 2016-05-21 12:16:56 --> Config Class Initialized
DEBUG - 2016-05-21 12:16:56 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:16:56 --> Utf8 Class Initialized
DEBUG - 2016-05-21 12:16:56 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 12:16:56 --> URI Class Initialized
DEBUG - 2016-05-21 12:16:56 --> Router Class Initialized
DEBUG - 2016-05-21 12:16:56 --> Output Class Initialized
DEBUG - 2016-05-21 12:16:56 --> Security Class Initialized
DEBUG - 2016-05-21 12:16:56 --> Input Class Initialized
DEBUG - 2016-05-21 12:16:56 --> XSS Filtering completed
DEBUG - 2016-05-21 12:16:56 --> XSS Filtering completed
DEBUG - 2016-05-21 12:16:56 --> XSS Filtering completed
DEBUG - 2016-05-21 12:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 12:16:56 --> Language Class Initialized
DEBUG - 2016-05-21 12:16:56 --> Loader Class Initialized
DEBUG - 2016-05-21 12:16:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 12:16:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 12:16:56 --> Helper loaded: url_helper
DEBUG - 2016-05-21 12:16:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 12:16:56 --> Helper loaded: file_helper
DEBUG - 2016-05-21 12:16:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:16:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 12:16:56 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 12:16:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:16:56 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 12:16:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 12:16:56 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:16:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 12:16:56 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:16:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 12:16:56 --> Helper loaded: form_helper
DEBUG - 2016-05-21 12:16:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 12:16:56 --> Helper loaded: security_helper
DEBUG - 2016-05-21 12:16:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:16:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 12:16:56 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 12:16:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:16:56 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 12:16:56 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 12:16:56 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 12:16:56 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 12:16:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:16:56 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 12:16:56 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 12:16:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:16:56 --> Database Driver Class Initialized
DEBUG - 2016-05-21 12:16:56 --> Session Class Initialized
DEBUG - 2016-05-21 12:16:56 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 12:16:56 --> Helper loaded: string_helper
DEBUG - 2016-05-21 12:16:56 --> Session routines successfully run
DEBUG - 2016-05-21 12:16:56 --> Native_session Class Initialized
DEBUG - 2016-05-21 12:16:56 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 12:16:56 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:16:56 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:16:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 12:16:56 --> Controller Class Initialized
DEBUG - 2016-05-21 12:16:56 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 12:16:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 12:16:56 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 12:16:56 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:16:56 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:16:56 --> User Agent Class Initialized
DEBUG - 2016-05-21 12:16:56 --> Model Class Initialized
DEBUG - 2016-05-21 12:16:56 --> Model Class Initialized
DEBUG - 2016-05-21 12:16:56 --> Model Class Initialized
DEBUG - 2016-05-21 12:16:56 --> Model Class Initialized
DEBUG - 2016-05-21 12:16:56 --> Model Class Initialized
DEBUG - 2016-05-21 12:17:18 --> Config Class Initialized
DEBUG - 2016-05-21 12:17:18 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:17:18 --> Utf8 Class Initialized
DEBUG - 2016-05-21 12:17:18 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 12:17:18 --> URI Class Initialized
DEBUG - 2016-05-21 12:17:18 --> Router Class Initialized
DEBUG - 2016-05-21 12:17:18 --> Output Class Initialized
DEBUG - 2016-05-21 12:17:18 --> Security Class Initialized
DEBUG - 2016-05-21 12:17:18 --> Input Class Initialized
DEBUG - 2016-05-21 12:17:18 --> XSS Filtering completed
DEBUG - 2016-05-21 12:17:18 --> XSS Filtering completed
DEBUG - 2016-05-21 12:17:18 --> XSS Filtering completed
DEBUG - 2016-05-21 12:17:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 12:17:18 --> Language Class Initialized
DEBUG - 2016-05-21 12:17:18 --> Loader Class Initialized
DEBUG - 2016-05-21 12:17:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 12:17:18 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 12:17:18 --> Helper loaded: url_helper
DEBUG - 2016-05-21 12:17:18 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 12:17:18 --> Helper loaded: file_helper
DEBUG - 2016-05-21 12:17:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:17:18 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 12:17:18 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 12:17:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:17:18 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 12:17:18 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 12:17:18 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:17:18 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 12:17:18 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:17:18 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 12:17:18 --> Helper loaded: form_helper
DEBUG - 2016-05-21 12:17:18 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 12:17:18 --> Helper loaded: security_helper
DEBUG - 2016-05-21 12:17:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:17:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 12:17:18 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 12:17:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:17:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 12:17:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 12:17:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 12:17:18 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 12:17:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:17:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 12:17:19 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 12:17:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:17:19 --> Database Driver Class Initialized
DEBUG - 2016-05-21 12:17:19 --> Session Class Initialized
DEBUG - 2016-05-21 12:17:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 12:17:19 --> Helper loaded: string_helper
DEBUG - 2016-05-21 12:17:19 --> Session routines successfully run
DEBUG - 2016-05-21 12:17:19 --> Native_session Class Initialized
DEBUG - 2016-05-21 12:17:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 12:17:19 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:17:19 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:17:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 12:17:19 --> Controller Class Initialized
DEBUG - 2016-05-21 12:17:19 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 12:17:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 12:17:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 12:17:19 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:17:19 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:17:19 --> User Agent Class Initialized
DEBUG - 2016-05-21 12:17:19 --> Model Class Initialized
DEBUG - 2016-05-21 12:17:19 --> Model Class Initialized
DEBUG - 2016-05-21 12:17:19 --> Model Class Initialized
DEBUG - 2016-05-21 12:17:19 --> Model Class Initialized
DEBUG - 2016-05-21 12:17:19 --> Model Class Initialized
DEBUG - 2016-05-21 12:18:43 --> Config Class Initialized
DEBUG - 2016-05-21 12:18:43 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:18:43 --> Utf8 Class Initialized
DEBUG - 2016-05-21 12:18:43 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 12:18:43 --> URI Class Initialized
DEBUG - 2016-05-21 12:18:43 --> Router Class Initialized
DEBUG - 2016-05-21 12:18:43 --> Output Class Initialized
DEBUG - 2016-05-21 12:18:43 --> Security Class Initialized
DEBUG - 2016-05-21 12:18:43 --> Input Class Initialized
DEBUG - 2016-05-21 12:18:43 --> XSS Filtering completed
DEBUG - 2016-05-21 12:18:43 --> XSS Filtering completed
DEBUG - 2016-05-21 12:18:43 --> XSS Filtering completed
DEBUG - 2016-05-21 12:18:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 12:18:43 --> Language Class Initialized
DEBUG - 2016-05-21 12:18:43 --> Loader Class Initialized
DEBUG - 2016-05-21 12:18:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 12:18:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 12:18:43 --> Helper loaded: url_helper
DEBUG - 2016-05-21 12:18:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 12:18:43 --> Helper loaded: file_helper
DEBUG - 2016-05-21 12:18:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:18:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 12:18:43 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 12:18:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:18:43 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 12:18:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 12:18:43 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:18:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 12:18:43 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:18:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 12:18:43 --> Helper loaded: form_helper
DEBUG - 2016-05-21 12:18:43 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 12:18:43 --> Helper loaded: security_helper
DEBUG - 2016-05-21 12:18:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:18:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 12:18:43 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 12:18:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:18:43 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 12:18:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 12:18:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 12:18:43 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 12:18:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:18:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 12:18:43 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 12:18:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:18:43 --> Database Driver Class Initialized
DEBUG - 2016-05-21 12:18:44 --> Session Class Initialized
DEBUG - 2016-05-21 12:18:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 12:18:44 --> Helper loaded: string_helper
DEBUG - 2016-05-21 12:18:44 --> Session routines successfully run
DEBUG - 2016-05-21 12:18:44 --> Native_session Class Initialized
DEBUG - 2016-05-21 12:18:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 12:18:44 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:18:44 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:18:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 12:18:44 --> Controller Class Initialized
DEBUG - 2016-05-21 12:18:44 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 12:18:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 12:18:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 12:18:44 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:18:44 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:18:44 --> User Agent Class Initialized
DEBUG - 2016-05-21 12:18:44 --> Model Class Initialized
DEBUG - 2016-05-21 12:18:44 --> Model Class Initialized
DEBUG - 2016-05-21 12:18:44 --> Model Class Initialized
DEBUG - 2016-05-21 12:18:44 --> Model Class Initialized
DEBUG - 2016-05-21 12:18:44 --> Model Class Initialized
DEBUG - 2016-05-21 12:19:48 --> Config Class Initialized
DEBUG - 2016-05-21 12:19:48 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:19:48 --> Utf8 Class Initialized
DEBUG - 2016-05-21 12:19:48 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 12:19:48 --> URI Class Initialized
DEBUG - 2016-05-21 12:19:48 --> Router Class Initialized
DEBUG - 2016-05-21 12:19:48 --> Output Class Initialized
DEBUG - 2016-05-21 12:19:48 --> Security Class Initialized
DEBUG - 2016-05-21 12:19:48 --> Input Class Initialized
DEBUG - 2016-05-21 12:19:48 --> XSS Filtering completed
DEBUG - 2016-05-21 12:19:48 --> XSS Filtering completed
DEBUG - 2016-05-21 12:19:48 --> XSS Filtering completed
DEBUG - 2016-05-21 12:19:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 12:19:48 --> Language Class Initialized
DEBUG - 2016-05-21 12:19:48 --> Loader Class Initialized
DEBUG - 2016-05-21 12:19:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 12:19:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 12:19:48 --> Helper loaded: url_helper
DEBUG - 2016-05-21 12:19:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 12:19:48 --> Helper loaded: file_helper
DEBUG - 2016-05-21 12:19:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:19:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 12:19:48 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 12:19:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:19:48 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 12:19:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 12:19:48 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:19:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 12:19:48 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:19:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 12:19:48 --> Helper loaded: form_helper
DEBUG - 2016-05-21 12:19:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 12:19:48 --> Helper loaded: security_helper
DEBUG - 2016-05-21 12:19:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:19:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 12:19:48 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 12:19:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:19:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 12:19:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 12:19:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 12:19:48 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 12:19:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:19:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 12:19:48 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 12:19:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:19:48 --> Database Driver Class Initialized
DEBUG - 2016-05-21 12:19:48 --> Session Class Initialized
DEBUG - 2016-05-21 12:19:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 12:19:48 --> Helper loaded: string_helper
DEBUG - 2016-05-21 12:19:48 --> Session routines successfully run
DEBUG - 2016-05-21 12:19:48 --> Native_session Class Initialized
DEBUG - 2016-05-21 12:19:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 12:19:48 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:19:48 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:19:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 12:19:48 --> Controller Class Initialized
DEBUG - 2016-05-21 12:19:49 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 12:19:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 12:19:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 12:19:49 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:19:49 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:19:49 --> User Agent Class Initialized
DEBUG - 2016-05-21 12:19:49 --> Model Class Initialized
DEBUG - 2016-05-21 12:19:49 --> Model Class Initialized
DEBUG - 2016-05-21 12:19:49 --> Model Class Initialized
DEBUG - 2016-05-21 12:19:49 --> Model Class Initialized
DEBUG - 2016-05-21 12:19:49 --> Model Class Initialized
DEBUG - 2016-05-21 12:20:20 --> Config Class Initialized
DEBUG - 2016-05-21 12:20:20 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:20:20 --> Utf8 Class Initialized
DEBUG - 2016-05-21 12:20:20 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 12:20:20 --> URI Class Initialized
DEBUG - 2016-05-21 12:20:20 --> Router Class Initialized
DEBUG - 2016-05-21 12:20:20 --> Output Class Initialized
DEBUG - 2016-05-21 12:20:20 --> Security Class Initialized
DEBUG - 2016-05-21 12:20:20 --> Input Class Initialized
DEBUG - 2016-05-21 12:20:20 --> XSS Filtering completed
DEBUG - 2016-05-21 12:20:20 --> XSS Filtering completed
DEBUG - 2016-05-21 12:20:20 --> XSS Filtering completed
DEBUG - 2016-05-21 12:20:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 12:20:20 --> Language Class Initialized
DEBUG - 2016-05-21 12:20:20 --> Loader Class Initialized
DEBUG - 2016-05-21 12:20:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 12:20:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 12:20:20 --> Helper loaded: url_helper
DEBUG - 2016-05-21 12:20:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 12:20:20 --> Helper loaded: file_helper
DEBUG - 2016-05-21 12:20:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:20:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 12:20:20 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 12:20:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:20:20 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 12:20:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 12:20:20 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:20:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 12:20:20 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:20:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 12:20:20 --> Helper loaded: form_helper
DEBUG - 2016-05-21 12:20:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 12:20:20 --> Helper loaded: security_helper
DEBUG - 2016-05-21 12:20:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:20:21 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 12:20:21 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 12:20:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:20:21 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 12:20:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 12:20:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 12:20:21 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 12:20:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:20:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 12:20:21 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 12:20:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:20:21 --> Database Driver Class Initialized
DEBUG - 2016-05-21 12:20:21 --> Session Class Initialized
DEBUG - 2016-05-21 12:20:21 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 12:20:21 --> Helper loaded: string_helper
DEBUG - 2016-05-21 12:20:21 --> Session routines successfully run
DEBUG - 2016-05-21 12:20:21 --> Native_session Class Initialized
DEBUG - 2016-05-21 12:20:21 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 12:20:21 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:20:21 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:20:21 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 12:20:21 --> Controller Class Initialized
DEBUG - 2016-05-21 12:20:21 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 12:20:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 12:20:21 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 12:20:21 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:20:21 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:20:21 --> User Agent Class Initialized
DEBUG - 2016-05-21 12:20:21 --> Model Class Initialized
DEBUG - 2016-05-21 12:20:21 --> Model Class Initialized
DEBUG - 2016-05-21 12:20:21 --> Model Class Initialized
DEBUG - 2016-05-21 12:20:21 --> Model Class Initialized
DEBUG - 2016-05-21 12:20:21 --> Model Class Initialized
DEBUG - 2016-05-21 12:20:58 --> Config Class Initialized
DEBUG - 2016-05-21 12:20:58 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:20:58 --> Utf8 Class Initialized
DEBUG - 2016-05-21 12:20:58 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 12:20:58 --> URI Class Initialized
DEBUG - 2016-05-21 12:20:58 --> Router Class Initialized
DEBUG - 2016-05-21 12:20:58 --> Output Class Initialized
DEBUG - 2016-05-21 12:20:58 --> Security Class Initialized
DEBUG - 2016-05-21 12:20:58 --> Input Class Initialized
DEBUG - 2016-05-21 12:20:58 --> XSS Filtering completed
DEBUG - 2016-05-21 12:20:58 --> XSS Filtering completed
DEBUG - 2016-05-21 12:20:58 --> XSS Filtering completed
DEBUG - 2016-05-21 12:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 12:20:58 --> Language Class Initialized
DEBUG - 2016-05-21 12:20:58 --> Loader Class Initialized
DEBUG - 2016-05-21 12:20:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 12:20:58 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 12:20:58 --> Helper loaded: url_helper
DEBUG - 2016-05-21 12:20:58 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 12:20:58 --> Helper loaded: file_helper
DEBUG - 2016-05-21 12:20:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:20:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 12:20:58 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 12:20:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:20:59 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 12:20:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 12:20:59 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:20:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 12:20:59 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:20:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 12:20:59 --> Helper loaded: form_helper
DEBUG - 2016-05-21 12:20:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 12:20:59 --> Helper loaded: security_helper
DEBUG - 2016-05-21 12:20:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:20:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 12:20:59 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 12:20:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:20:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 12:20:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 12:20:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 12:20:59 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 12:20:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:20:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 12:20:59 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 12:20:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:20:59 --> Database Driver Class Initialized
DEBUG - 2016-05-21 12:20:59 --> Session Class Initialized
DEBUG - 2016-05-21 12:20:59 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 12:20:59 --> Helper loaded: string_helper
DEBUG - 2016-05-21 12:20:59 --> Session routines successfully run
DEBUG - 2016-05-21 12:20:59 --> Native_session Class Initialized
DEBUG - 2016-05-21 12:20:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 12:20:59 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:20:59 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:20:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 12:20:59 --> Controller Class Initialized
DEBUG - 2016-05-21 12:20:59 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 12:20:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 12:20:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 12:20:59 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:20:59 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:20:59 --> User Agent Class Initialized
DEBUG - 2016-05-21 12:20:59 --> Model Class Initialized
DEBUG - 2016-05-21 12:20:59 --> Model Class Initialized
DEBUG - 2016-05-21 12:20:59 --> Model Class Initialized
DEBUG - 2016-05-21 12:20:59 --> Model Class Initialized
DEBUG - 2016-05-21 12:20:59 --> Model Class Initialized
DEBUG - 2016-05-21 12:21:16 --> Config Class Initialized
DEBUG - 2016-05-21 12:21:16 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:21:16 --> Utf8 Class Initialized
DEBUG - 2016-05-21 12:21:16 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 12:21:16 --> URI Class Initialized
DEBUG - 2016-05-21 12:21:16 --> Router Class Initialized
DEBUG - 2016-05-21 12:21:16 --> Output Class Initialized
DEBUG - 2016-05-21 12:21:16 --> Security Class Initialized
DEBUG - 2016-05-21 12:21:16 --> Input Class Initialized
DEBUG - 2016-05-21 12:21:16 --> XSS Filtering completed
DEBUG - 2016-05-21 12:21:16 --> XSS Filtering completed
DEBUG - 2016-05-21 12:21:16 --> XSS Filtering completed
DEBUG - 2016-05-21 12:21:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 12:21:16 --> Language Class Initialized
DEBUG - 2016-05-21 12:21:16 --> Loader Class Initialized
DEBUG - 2016-05-21 12:21:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 12:21:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 12:21:16 --> Helper loaded: url_helper
DEBUG - 2016-05-21 12:21:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 12:21:16 --> Helper loaded: file_helper
DEBUG - 2016-05-21 12:21:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:21:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 12:21:16 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 12:21:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:21:16 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 12:21:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 12:21:16 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:21:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 12:21:16 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:21:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 12:21:16 --> Helper loaded: form_helper
DEBUG - 2016-05-21 12:21:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 12:21:16 --> Helper loaded: security_helper
DEBUG - 2016-05-21 12:21:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:21:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 12:21:16 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 12:21:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:21:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 12:21:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 12:21:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 12:21:16 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 12:21:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:21:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 12:21:17 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 12:21:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:21:17 --> Database Driver Class Initialized
DEBUG - 2016-05-21 12:21:17 --> Session Class Initialized
DEBUG - 2016-05-21 12:21:17 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 12:21:17 --> Helper loaded: string_helper
DEBUG - 2016-05-21 12:21:17 --> Session routines successfully run
DEBUG - 2016-05-21 12:21:17 --> Native_session Class Initialized
DEBUG - 2016-05-21 12:21:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 12:21:17 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:21:17 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:21:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 12:21:17 --> Controller Class Initialized
DEBUG - 2016-05-21 12:21:17 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 12:21:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 12:21:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 12:21:17 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:21:17 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:21:17 --> User Agent Class Initialized
DEBUG - 2016-05-21 12:21:17 --> Model Class Initialized
DEBUG - 2016-05-21 12:21:17 --> Model Class Initialized
DEBUG - 2016-05-21 12:21:17 --> Model Class Initialized
DEBUG - 2016-05-21 12:21:17 --> Model Class Initialized
DEBUG - 2016-05-21 12:21:17 --> Model Class Initialized
DEBUG - 2016-05-21 12:22:04 --> Config Class Initialized
DEBUG - 2016-05-21 12:22:05 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:22:05 --> Utf8 Class Initialized
DEBUG - 2016-05-21 12:22:05 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 12:22:05 --> URI Class Initialized
DEBUG - 2016-05-21 12:22:05 --> Router Class Initialized
DEBUG - 2016-05-21 12:22:05 --> Output Class Initialized
DEBUG - 2016-05-21 12:22:05 --> Security Class Initialized
DEBUG - 2016-05-21 12:22:05 --> Input Class Initialized
DEBUG - 2016-05-21 12:22:05 --> XSS Filtering completed
DEBUG - 2016-05-21 12:22:05 --> XSS Filtering completed
DEBUG - 2016-05-21 12:22:05 --> XSS Filtering completed
DEBUG - 2016-05-21 12:22:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 12:22:05 --> Language Class Initialized
DEBUG - 2016-05-21 12:22:05 --> Loader Class Initialized
DEBUG - 2016-05-21 12:22:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 12:22:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 12:22:05 --> Helper loaded: url_helper
DEBUG - 2016-05-21 12:22:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 12:22:05 --> Helper loaded: file_helper
DEBUG - 2016-05-21 12:22:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:22:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 12:22:05 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 12:22:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:22:05 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 12:22:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 12:22:05 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:22:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 12:22:05 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:22:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 12:22:05 --> Helper loaded: form_helper
DEBUG - 2016-05-21 12:22:05 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 12:22:05 --> Helper loaded: security_helper
DEBUG - 2016-05-21 12:22:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:22:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 12:22:05 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 12:22:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:22:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 12:22:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 12:22:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 12:22:05 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 12:22:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:22:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 12:22:05 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 12:22:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:22:05 --> Database Driver Class Initialized
DEBUG - 2016-05-21 12:22:05 --> Session Class Initialized
DEBUG - 2016-05-21 12:22:05 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 12:22:05 --> Helper loaded: string_helper
DEBUG - 2016-05-21 12:22:05 --> Session routines successfully run
DEBUG - 2016-05-21 12:22:05 --> Native_session Class Initialized
DEBUG - 2016-05-21 12:22:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 12:22:05 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:22:05 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:22:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 12:22:05 --> Controller Class Initialized
DEBUG - 2016-05-21 12:22:05 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 12:22:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 12:22:05 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 12:22:05 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:22:05 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:22:05 --> User Agent Class Initialized
DEBUG - 2016-05-21 12:22:05 --> Model Class Initialized
DEBUG - 2016-05-21 12:22:05 --> Model Class Initialized
DEBUG - 2016-05-21 12:22:05 --> Model Class Initialized
DEBUG - 2016-05-21 12:22:05 --> Model Class Initialized
DEBUG - 2016-05-21 12:22:05 --> Model Class Initialized
DEBUG - 2016-05-21 12:24:47 --> Config Class Initialized
DEBUG - 2016-05-21 12:24:47 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:24:47 --> Utf8 Class Initialized
DEBUG - 2016-05-21 12:24:47 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 12:24:47 --> URI Class Initialized
DEBUG - 2016-05-21 12:24:47 --> Router Class Initialized
DEBUG - 2016-05-21 12:24:47 --> Output Class Initialized
DEBUG - 2016-05-21 12:24:47 --> Security Class Initialized
DEBUG - 2016-05-21 12:24:47 --> Input Class Initialized
DEBUG - 2016-05-21 12:24:47 --> XSS Filtering completed
DEBUG - 2016-05-21 12:24:47 --> XSS Filtering completed
DEBUG - 2016-05-21 12:24:47 --> XSS Filtering completed
DEBUG - 2016-05-21 12:24:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 12:24:47 --> Language Class Initialized
DEBUG - 2016-05-21 12:24:47 --> Loader Class Initialized
DEBUG - 2016-05-21 12:24:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 12:24:47 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 12:24:47 --> Helper loaded: url_helper
DEBUG - 2016-05-21 12:24:47 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 12:24:47 --> Helper loaded: file_helper
DEBUG - 2016-05-21 12:24:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:24:47 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 12:24:47 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 12:24:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:24:47 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 12:24:47 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 12:24:47 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:24:47 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 12:24:47 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:24:47 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 12:24:47 --> Helper loaded: form_helper
DEBUG - 2016-05-21 12:24:47 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 12:24:47 --> Helper loaded: security_helper
DEBUG - 2016-05-21 12:24:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:24:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 12:24:47 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 12:24:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:24:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 12:24:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 12:24:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 12:24:47 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 12:24:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:24:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 12:24:48 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 12:24:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:24:48 --> Database Driver Class Initialized
DEBUG - 2016-05-21 12:24:48 --> Session Class Initialized
DEBUG - 2016-05-21 12:24:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 12:24:48 --> Helper loaded: string_helper
DEBUG - 2016-05-21 12:24:48 --> Session routines successfully run
DEBUG - 2016-05-21 12:24:48 --> Native_session Class Initialized
DEBUG - 2016-05-21 12:24:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 12:24:48 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:24:48 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:24:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 12:24:48 --> Controller Class Initialized
DEBUG - 2016-05-21 12:24:48 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 12:24:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 12:24:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 12:24:48 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:24:48 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:24:48 --> User Agent Class Initialized
DEBUG - 2016-05-21 12:24:48 --> Model Class Initialized
DEBUG - 2016-05-21 12:24:48 --> Model Class Initialized
DEBUG - 2016-05-21 12:24:48 --> Model Class Initialized
DEBUG - 2016-05-21 12:24:48 --> Model Class Initialized
DEBUG - 2016-05-21 12:24:48 --> Model Class Initialized
DEBUG - 2016-05-21 12:25:05 --> Config Class Initialized
DEBUG - 2016-05-21 12:25:05 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:25:05 --> Utf8 Class Initialized
DEBUG - 2016-05-21 12:25:05 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 12:25:05 --> URI Class Initialized
DEBUG - 2016-05-21 12:25:05 --> Router Class Initialized
DEBUG - 2016-05-21 12:25:05 --> Output Class Initialized
DEBUG - 2016-05-21 12:25:05 --> Security Class Initialized
DEBUG - 2016-05-21 12:25:05 --> Input Class Initialized
DEBUG - 2016-05-21 12:25:05 --> XSS Filtering completed
DEBUG - 2016-05-21 12:25:05 --> XSS Filtering completed
DEBUG - 2016-05-21 12:25:05 --> XSS Filtering completed
DEBUG - 2016-05-21 12:25:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 12:25:05 --> Language Class Initialized
DEBUG - 2016-05-21 12:25:05 --> Loader Class Initialized
DEBUG - 2016-05-21 12:25:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 12:25:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 12:25:05 --> Helper loaded: url_helper
DEBUG - 2016-05-21 12:25:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 12:25:05 --> Helper loaded: file_helper
DEBUG - 2016-05-21 12:25:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:25:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 12:25:05 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 12:25:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:25:05 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 12:25:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 12:25:05 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:25:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 12:25:05 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:25:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 12:25:05 --> Helper loaded: form_helper
DEBUG - 2016-05-21 12:25:05 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 12:25:05 --> Helper loaded: security_helper
DEBUG - 2016-05-21 12:25:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:25:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 12:25:05 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 12:25:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:25:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 12:25:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 12:25:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 12:25:05 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 12:25:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:25:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 12:25:05 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 12:25:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:25:05 --> Database Driver Class Initialized
DEBUG - 2016-05-21 12:25:05 --> Session Class Initialized
DEBUG - 2016-05-21 12:25:05 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 12:25:05 --> Helper loaded: string_helper
DEBUG - 2016-05-21 12:25:05 --> Session routines successfully run
DEBUG - 2016-05-21 12:25:06 --> Native_session Class Initialized
DEBUG - 2016-05-21 12:25:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 12:25:06 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:25:06 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:25:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 12:25:06 --> Controller Class Initialized
DEBUG - 2016-05-21 12:25:06 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 12:25:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 12:25:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 12:25:06 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:25:06 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:25:06 --> User Agent Class Initialized
DEBUG - 2016-05-21 12:25:06 --> Model Class Initialized
DEBUG - 2016-05-21 12:25:06 --> Model Class Initialized
DEBUG - 2016-05-21 12:25:06 --> Model Class Initialized
DEBUG - 2016-05-21 12:25:06 --> Model Class Initialized
DEBUG - 2016-05-21 12:25:06 --> Model Class Initialized
DEBUG - 2016-05-21 12:25:31 --> Config Class Initialized
DEBUG - 2016-05-21 12:25:31 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:25:31 --> Utf8 Class Initialized
DEBUG - 2016-05-21 12:25:31 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 12:25:31 --> URI Class Initialized
DEBUG - 2016-05-21 12:25:31 --> Router Class Initialized
DEBUG - 2016-05-21 12:25:31 --> Output Class Initialized
DEBUG - 2016-05-21 12:25:31 --> Security Class Initialized
DEBUG - 2016-05-21 12:25:31 --> Input Class Initialized
DEBUG - 2016-05-21 12:25:31 --> XSS Filtering completed
DEBUG - 2016-05-21 12:25:31 --> XSS Filtering completed
DEBUG - 2016-05-21 12:25:31 --> XSS Filtering completed
DEBUG - 2016-05-21 12:25:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 12:25:31 --> Language Class Initialized
DEBUG - 2016-05-21 12:25:31 --> Loader Class Initialized
DEBUG - 2016-05-21 12:25:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 12:25:31 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 12:25:31 --> Helper loaded: url_helper
DEBUG - 2016-05-21 12:25:31 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 12:25:31 --> Helper loaded: file_helper
DEBUG - 2016-05-21 12:25:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:25:31 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 12:25:31 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 12:25:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:25:31 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 12:25:31 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 12:25:31 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:25:31 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 12:25:31 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:25:31 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 12:25:31 --> Helper loaded: form_helper
DEBUG - 2016-05-21 12:25:31 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 12:25:31 --> Helper loaded: security_helper
DEBUG - 2016-05-21 12:25:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:25:31 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 12:25:31 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 12:25:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:25:31 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 12:25:31 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 12:25:31 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 12:25:31 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 12:25:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:25:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 12:25:32 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 12:25:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:25:32 --> Database Driver Class Initialized
DEBUG - 2016-05-21 12:25:32 --> Session Class Initialized
DEBUG - 2016-05-21 12:25:32 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 12:25:32 --> Helper loaded: string_helper
DEBUG - 2016-05-21 12:25:32 --> Session routines successfully run
DEBUG - 2016-05-21 12:25:32 --> Native_session Class Initialized
DEBUG - 2016-05-21 12:25:32 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 12:25:32 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:25:32 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:25:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 12:25:32 --> Controller Class Initialized
DEBUG - 2016-05-21 12:25:32 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 12:25:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 12:25:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 12:25:32 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:25:32 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:25:32 --> User Agent Class Initialized
DEBUG - 2016-05-21 12:25:32 --> Model Class Initialized
DEBUG - 2016-05-21 12:25:32 --> Model Class Initialized
DEBUG - 2016-05-21 12:25:32 --> Model Class Initialized
DEBUG - 2016-05-21 12:25:32 --> Model Class Initialized
DEBUG - 2016-05-21 12:25:32 --> Model Class Initialized
DEBUG - 2016-05-21 12:57:13 --> Config Class Initialized
DEBUG - 2016-05-21 12:57:13 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:57:13 --> Utf8 Class Initialized
DEBUG - 2016-05-21 12:57:13 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 12:57:13 --> URI Class Initialized
DEBUG - 2016-05-21 12:57:13 --> Router Class Initialized
DEBUG - 2016-05-21 12:57:13 --> Output Class Initialized
DEBUG - 2016-05-21 12:57:13 --> Security Class Initialized
DEBUG - 2016-05-21 12:57:13 --> Input Class Initialized
DEBUG - 2016-05-21 12:57:13 --> XSS Filtering completed
DEBUG - 2016-05-21 12:57:13 --> XSS Filtering completed
DEBUG - 2016-05-21 12:57:13 --> XSS Filtering completed
DEBUG - 2016-05-21 12:57:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 12:57:13 --> Language Class Initialized
DEBUG - 2016-05-21 12:57:13 --> Loader Class Initialized
DEBUG - 2016-05-21 12:57:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 12:57:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 12:57:13 --> Helper loaded: url_helper
DEBUG - 2016-05-21 12:57:13 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 12:57:13 --> Helper loaded: file_helper
DEBUG - 2016-05-21 12:57:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:57:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 12:57:13 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 12:57:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 12:57:14 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 12:57:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 12:57:14 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:57:14 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 12:57:14 --> Helper loaded: common_helper
DEBUG - 2016-05-21 12:57:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 12:57:14 --> Helper loaded: form_helper
DEBUG - 2016-05-21 12:57:14 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 12:57:14 --> Helper loaded: security_helper
DEBUG - 2016-05-21 12:57:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:57:14 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 12:57:14 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 12:57:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 12:57:14 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 12:57:14 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 12:57:14 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 12:57:14 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 12:57:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:57:14 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 12:57:14 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 12:57:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 12:57:14 --> Database Driver Class Initialized
DEBUG - 2016-05-21 12:57:14 --> Session Class Initialized
DEBUG - 2016-05-21 12:57:14 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 12:57:14 --> Helper loaded: string_helper
DEBUG - 2016-05-21 12:57:14 --> Session routines successfully run
DEBUG - 2016-05-21 12:57:14 --> Native_session Class Initialized
DEBUG - 2016-05-21 12:57:14 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 12:57:14 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:57:14 --> Form Validation Class Initialized
DEBUG - 2016-05-21 12:57:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 12:57:14 --> Controller Class Initialized
DEBUG - 2016-05-21 12:57:14 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 12:57:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 12:57:14 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 12:57:14 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:57:14 --> Carabiner: library configured.
DEBUG - 2016-05-21 12:57:14 --> User Agent Class Initialized
DEBUG - 2016-05-21 12:57:14 --> Model Class Initialized
DEBUG - 2016-05-21 12:57:14 --> Model Class Initialized
DEBUG - 2016-05-21 12:57:14 --> Model Class Initialized
DEBUG - 2016-05-21 12:57:14 --> Model Class Initialized
DEBUG - 2016-05-21 12:57:14 --> Model Class Initialized
DEBUG - 2016-05-21 13:00:16 --> Config Class Initialized
DEBUG - 2016-05-21 13:00:16 --> Hooks Class Initialized
DEBUG - 2016-05-21 13:00:16 --> Utf8 Class Initialized
DEBUG - 2016-05-21 13:00:16 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 13:00:16 --> URI Class Initialized
DEBUG - 2016-05-21 13:00:16 --> Router Class Initialized
DEBUG - 2016-05-21 13:00:16 --> Output Class Initialized
DEBUG - 2016-05-21 13:00:16 --> Security Class Initialized
DEBUG - 2016-05-21 13:00:16 --> Input Class Initialized
DEBUG - 2016-05-21 13:00:16 --> XSS Filtering completed
DEBUG - 2016-05-21 13:00:16 --> XSS Filtering completed
DEBUG - 2016-05-21 13:00:16 --> XSS Filtering completed
DEBUG - 2016-05-21 13:00:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 13:00:16 --> Language Class Initialized
DEBUG - 2016-05-21 13:00:16 --> Loader Class Initialized
DEBUG - 2016-05-21 13:00:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 13:00:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 13:00:16 --> Helper loaded: url_helper
DEBUG - 2016-05-21 13:00:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 13:00:16 --> Helper loaded: file_helper
DEBUG - 2016-05-21 13:00:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:00:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 13:00:16 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 13:00:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:00:16 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 13:00:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 13:00:16 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:00:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 13:00:16 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:00:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 13:00:16 --> Helper loaded: form_helper
DEBUG - 2016-05-21 13:00:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 13:00:16 --> Helper loaded: security_helper
DEBUG - 2016-05-21 13:00:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:00:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 13:00:16 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 13:00:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:00:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 13:00:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 13:00:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 13:00:17 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 13:00:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:00:17 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 13:00:17 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 13:00:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:00:17 --> Database Driver Class Initialized
DEBUG - 2016-05-21 13:00:17 --> Session Class Initialized
DEBUG - 2016-05-21 13:00:17 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 13:00:17 --> Helper loaded: string_helper
DEBUG - 2016-05-21 13:00:17 --> Session routines successfully run
DEBUG - 2016-05-21 13:00:17 --> Native_session Class Initialized
DEBUG - 2016-05-21 13:00:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 13:00:17 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:00:17 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:00:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 13:00:17 --> Controller Class Initialized
DEBUG - 2016-05-21 13:00:17 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 13:00:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 13:00:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 13:00:17 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:00:17 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:00:17 --> User Agent Class Initialized
DEBUG - 2016-05-21 13:00:17 --> Model Class Initialized
DEBUG - 2016-05-21 13:00:17 --> Model Class Initialized
DEBUG - 2016-05-21 13:00:17 --> Model Class Initialized
DEBUG - 2016-05-21 13:00:17 --> Model Class Initialized
DEBUG - 2016-05-21 13:00:17 --> Model Class Initialized
DEBUG - 2016-05-21 13:02:38 --> Config Class Initialized
DEBUG - 2016-05-21 13:02:38 --> Hooks Class Initialized
DEBUG - 2016-05-21 13:02:38 --> Utf8 Class Initialized
DEBUG - 2016-05-21 13:02:38 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 13:02:38 --> URI Class Initialized
DEBUG - 2016-05-21 13:02:38 --> Router Class Initialized
DEBUG - 2016-05-21 13:02:38 --> Output Class Initialized
DEBUG - 2016-05-21 13:02:38 --> Security Class Initialized
DEBUG - 2016-05-21 13:02:38 --> Input Class Initialized
DEBUG - 2016-05-21 13:02:38 --> XSS Filtering completed
DEBUG - 2016-05-21 13:02:38 --> XSS Filtering completed
DEBUG - 2016-05-21 13:02:38 --> XSS Filtering completed
DEBUG - 2016-05-21 13:02:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 13:02:38 --> Language Class Initialized
DEBUG - 2016-05-21 13:02:38 --> Loader Class Initialized
DEBUG - 2016-05-21 13:02:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 13:02:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 13:02:38 --> Helper loaded: url_helper
DEBUG - 2016-05-21 13:02:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 13:02:38 --> Helper loaded: file_helper
DEBUG - 2016-05-21 13:02:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:02:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 13:02:38 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 13:02:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:02:38 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 13:02:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 13:02:38 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:02:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 13:02:38 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:02:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 13:02:38 --> Helper loaded: form_helper
DEBUG - 2016-05-21 13:02:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 13:02:38 --> Helper loaded: security_helper
DEBUG - 2016-05-21 13:02:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:02:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 13:02:38 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 13:02:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:02:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 13:02:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 13:02:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 13:02:38 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 13:02:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:02:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 13:02:38 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 13:02:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:02:38 --> Database Driver Class Initialized
DEBUG - 2016-05-21 13:02:38 --> Session Class Initialized
DEBUG - 2016-05-21 13:02:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 13:02:38 --> Helper loaded: string_helper
DEBUG - 2016-05-21 13:02:38 --> Session routines successfully run
DEBUG - 2016-05-21 13:02:38 --> Native_session Class Initialized
DEBUG - 2016-05-21 13:02:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 13:02:39 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:02:39 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:02:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 13:02:39 --> Controller Class Initialized
DEBUG - 2016-05-21 13:02:39 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 13:02:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 13:02:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 13:02:39 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:02:39 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:02:39 --> User Agent Class Initialized
DEBUG - 2016-05-21 13:02:39 --> Model Class Initialized
DEBUG - 2016-05-21 13:02:39 --> Model Class Initialized
DEBUG - 2016-05-21 13:02:39 --> Model Class Initialized
DEBUG - 2016-05-21 13:02:39 --> Model Class Initialized
DEBUG - 2016-05-21 13:02:39 --> Model Class Initialized
DEBUG - 2016-05-21 13:03:41 --> Config Class Initialized
DEBUG - 2016-05-21 13:03:41 --> Hooks Class Initialized
DEBUG - 2016-05-21 13:03:41 --> Utf8 Class Initialized
DEBUG - 2016-05-21 13:03:41 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 13:03:41 --> URI Class Initialized
DEBUG - 2016-05-21 13:03:41 --> Router Class Initialized
DEBUG - 2016-05-21 13:03:41 --> Output Class Initialized
DEBUG - 2016-05-21 13:03:41 --> Security Class Initialized
DEBUG - 2016-05-21 13:03:41 --> Input Class Initialized
DEBUG - 2016-05-21 13:03:41 --> XSS Filtering completed
DEBUG - 2016-05-21 13:03:41 --> XSS Filtering completed
DEBUG - 2016-05-21 13:03:41 --> XSS Filtering completed
DEBUG - 2016-05-21 13:03:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 13:03:41 --> Language Class Initialized
DEBUG - 2016-05-21 13:03:41 --> Loader Class Initialized
DEBUG - 2016-05-21 13:03:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 13:03:41 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 13:03:41 --> Helper loaded: url_helper
DEBUG - 2016-05-21 13:03:41 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 13:03:41 --> Helper loaded: file_helper
DEBUG - 2016-05-21 13:03:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:03:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 13:03:41 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 13:03:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:03:41 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 13:03:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 13:03:41 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:03:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 13:03:41 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:03:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 13:03:41 --> Helper loaded: form_helper
DEBUG - 2016-05-21 13:03:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 13:03:41 --> Helper loaded: security_helper
DEBUG - 2016-05-21 13:03:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:03:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 13:03:41 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 13:03:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:03:42 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 13:03:42 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 13:03:42 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 13:03:42 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 13:03:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:03:42 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 13:03:42 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 13:03:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:03:42 --> Database Driver Class Initialized
DEBUG - 2016-05-21 13:03:42 --> Session Class Initialized
DEBUG - 2016-05-21 13:03:42 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 13:03:42 --> Helper loaded: string_helper
DEBUG - 2016-05-21 13:03:42 --> Session routines successfully run
DEBUG - 2016-05-21 13:03:42 --> Native_session Class Initialized
DEBUG - 2016-05-21 13:03:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 13:03:42 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:03:42 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:03:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 13:03:42 --> Controller Class Initialized
DEBUG - 2016-05-21 13:03:42 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 13:03:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 13:03:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 13:03:42 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:03:42 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:03:42 --> User Agent Class Initialized
DEBUG - 2016-05-21 13:03:42 --> Model Class Initialized
DEBUG - 2016-05-21 13:03:42 --> Model Class Initialized
DEBUG - 2016-05-21 13:03:42 --> Model Class Initialized
DEBUG - 2016-05-21 13:03:42 --> Model Class Initialized
DEBUG - 2016-05-21 13:03:42 --> Model Class Initialized
DEBUG - 2016-05-21 13:17:08 --> Config Class Initialized
DEBUG - 2016-05-21 13:17:08 --> Hooks Class Initialized
DEBUG - 2016-05-21 13:17:08 --> Utf8 Class Initialized
DEBUG - 2016-05-21 13:17:08 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 13:17:08 --> URI Class Initialized
DEBUG - 2016-05-21 13:17:08 --> Router Class Initialized
DEBUG - 2016-05-21 13:17:08 --> Output Class Initialized
DEBUG - 2016-05-21 13:17:08 --> Security Class Initialized
DEBUG - 2016-05-21 13:17:08 --> Input Class Initialized
DEBUG - 2016-05-21 13:17:08 --> XSS Filtering completed
DEBUG - 2016-05-21 13:17:08 --> XSS Filtering completed
DEBUG - 2016-05-21 13:17:08 --> XSS Filtering completed
DEBUG - 2016-05-21 13:17:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 13:17:08 --> Language Class Initialized
DEBUG - 2016-05-21 13:17:08 --> Loader Class Initialized
DEBUG - 2016-05-21 13:17:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 13:17:08 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 13:17:08 --> Helper loaded: url_helper
DEBUG - 2016-05-21 13:17:08 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 13:17:08 --> Helper loaded: file_helper
DEBUG - 2016-05-21 13:17:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:17:08 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 13:17:08 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 13:17:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:17:08 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 13:17:08 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 13:17:08 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:17:08 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 13:17:08 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:17:08 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 13:17:08 --> Helper loaded: form_helper
DEBUG - 2016-05-21 13:17:08 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 13:17:08 --> Helper loaded: security_helper
DEBUG - 2016-05-21 13:17:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:17:08 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 13:17:08 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 13:17:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:17:08 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 13:17:08 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 13:17:08 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 13:17:08 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 13:17:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:17:08 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 13:17:08 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 13:17:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:17:08 --> Database Driver Class Initialized
DEBUG - 2016-05-21 13:17:08 --> Session Class Initialized
DEBUG - 2016-05-21 13:17:08 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 13:17:09 --> Helper loaded: string_helper
DEBUG - 2016-05-21 13:17:09 --> Session routines successfully run
DEBUG - 2016-05-21 13:17:09 --> Native_session Class Initialized
DEBUG - 2016-05-21 13:17:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 13:17:09 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:17:09 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:17:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 13:17:09 --> Controller Class Initialized
DEBUG - 2016-05-21 13:17:09 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 13:17:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 13:17:09 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 13:17:09 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:17:09 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:17:09 --> User Agent Class Initialized
DEBUG - 2016-05-21 13:17:09 --> Model Class Initialized
DEBUG - 2016-05-21 13:17:09 --> Model Class Initialized
DEBUG - 2016-05-21 13:17:09 --> Model Class Initialized
DEBUG - 2016-05-21 13:17:09 --> Model Class Initialized
DEBUG - 2016-05-21 13:17:09 --> Model Class Initialized
DEBUG - 2016-05-21 13:17:24 --> Config Class Initialized
DEBUG - 2016-05-21 13:17:24 --> Hooks Class Initialized
DEBUG - 2016-05-21 13:17:24 --> Utf8 Class Initialized
DEBUG - 2016-05-21 13:17:24 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 13:17:24 --> URI Class Initialized
DEBUG - 2016-05-21 13:17:24 --> Router Class Initialized
DEBUG - 2016-05-21 13:17:24 --> Output Class Initialized
DEBUG - 2016-05-21 13:17:24 --> Security Class Initialized
DEBUG - 2016-05-21 13:17:24 --> Input Class Initialized
DEBUG - 2016-05-21 13:17:24 --> XSS Filtering completed
DEBUG - 2016-05-21 13:17:24 --> XSS Filtering completed
DEBUG - 2016-05-21 13:17:24 --> XSS Filtering completed
DEBUG - 2016-05-21 13:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 13:17:24 --> Language Class Initialized
DEBUG - 2016-05-21 13:17:24 --> Loader Class Initialized
DEBUG - 2016-05-21 13:17:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 13:17:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 13:17:24 --> Helper loaded: url_helper
DEBUG - 2016-05-21 13:17:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 13:17:25 --> Helper loaded: file_helper
DEBUG - 2016-05-21 13:17:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:17:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 13:17:25 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 13:17:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:17:25 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 13:17:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 13:17:25 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:17:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 13:17:25 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:17:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 13:17:25 --> Helper loaded: form_helper
DEBUG - 2016-05-21 13:17:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 13:17:25 --> Helper loaded: security_helper
DEBUG - 2016-05-21 13:17:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:17:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 13:17:25 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 13:17:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:17:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 13:17:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 13:17:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 13:17:25 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 13:17:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:17:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 13:17:25 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 13:17:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:17:25 --> Database Driver Class Initialized
DEBUG - 2016-05-21 13:17:25 --> Session Class Initialized
DEBUG - 2016-05-21 13:17:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 13:17:25 --> Helper loaded: string_helper
DEBUG - 2016-05-21 13:17:25 --> Session routines successfully run
DEBUG - 2016-05-21 13:17:25 --> Native_session Class Initialized
DEBUG - 2016-05-21 13:17:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 13:17:25 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:17:25 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:17:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 13:17:25 --> Controller Class Initialized
DEBUG - 2016-05-21 13:17:25 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 13:17:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 13:17:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 13:17:25 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:17:25 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:17:25 --> User Agent Class Initialized
DEBUG - 2016-05-21 13:17:25 --> Model Class Initialized
DEBUG - 2016-05-21 13:17:25 --> Model Class Initialized
DEBUG - 2016-05-21 13:17:25 --> Model Class Initialized
DEBUG - 2016-05-21 13:17:25 --> Model Class Initialized
DEBUG - 2016-05-21 13:17:25 --> Model Class Initialized
DEBUG - 2016-05-21 13:17:36 --> Config Class Initialized
DEBUG - 2016-05-21 13:17:36 --> Hooks Class Initialized
DEBUG - 2016-05-21 13:17:36 --> Utf8 Class Initialized
DEBUG - 2016-05-21 13:17:36 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 13:17:36 --> URI Class Initialized
DEBUG - 2016-05-21 13:17:36 --> Router Class Initialized
DEBUG - 2016-05-21 13:17:36 --> Output Class Initialized
DEBUG - 2016-05-21 13:17:36 --> Security Class Initialized
DEBUG - 2016-05-21 13:17:36 --> Input Class Initialized
DEBUG - 2016-05-21 13:17:36 --> XSS Filtering completed
DEBUG - 2016-05-21 13:17:36 --> XSS Filtering completed
DEBUG - 2016-05-21 13:17:36 --> XSS Filtering completed
DEBUG - 2016-05-21 13:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 13:17:36 --> Language Class Initialized
DEBUG - 2016-05-21 13:17:36 --> Loader Class Initialized
DEBUG - 2016-05-21 13:17:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 13:17:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 13:17:36 --> Helper loaded: url_helper
DEBUG - 2016-05-21 13:17:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 13:17:36 --> Helper loaded: file_helper
DEBUG - 2016-05-21 13:17:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:17:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 13:17:36 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 13:17:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:17:36 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 13:17:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 13:17:36 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:17:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 13:17:36 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:17:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 13:17:36 --> Helper loaded: form_helper
DEBUG - 2016-05-21 13:17:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 13:17:36 --> Helper loaded: security_helper
DEBUG - 2016-05-21 13:17:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:17:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 13:17:36 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 13:17:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:17:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 13:17:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 13:17:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 13:17:36 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 13:17:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:17:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 13:17:36 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 13:17:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:17:36 --> Database Driver Class Initialized
DEBUG - 2016-05-21 13:17:37 --> Session Class Initialized
DEBUG - 2016-05-21 13:17:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 13:17:37 --> Helper loaded: string_helper
DEBUG - 2016-05-21 13:17:37 --> Session routines successfully run
DEBUG - 2016-05-21 13:17:37 --> Native_session Class Initialized
DEBUG - 2016-05-21 13:17:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 13:17:37 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:17:37 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:17:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 13:17:37 --> Controller Class Initialized
DEBUG - 2016-05-21 13:17:37 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 13:17:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 13:17:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 13:17:37 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:17:37 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:17:37 --> User Agent Class Initialized
DEBUG - 2016-05-21 13:17:37 --> Model Class Initialized
DEBUG - 2016-05-21 13:17:37 --> Model Class Initialized
DEBUG - 2016-05-21 13:17:37 --> Model Class Initialized
DEBUG - 2016-05-21 13:17:37 --> Model Class Initialized
DEBUG - 2016-05-21 13:17:37 --> Model Class Initialized
DEBUG - 2016-05-21 13:17:48 --> Config Class Initialized
DEBUG - 2016-05-21 13:17:48 --> Hooks Class Initialized
DEBUG - 2016-05-21 13:17:48 --> Utf8 Class Initialized
DEBUG - 2016-05-21 13:17:48 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 13:17:48 --> URI Class Initialized
DEBUG - 2016-05-21 13:17:48 --> Router Class Initialized
DEBUG - 2016-05-21 13:17:48 --> Output Class Initialized
DEBUG - 2016-05-21 13:17:48 --> Security Class Initialized
DEBUG - 2016-05-21 13:17:48 --> Input Class Initialized
DEBUG - 2016-05-21 13:17:48 --> XSS Filtering completed
DEBUG - 2016-05-21 13:17:48 --> XSS Filtering completed
DEBUG - 2016-05-21 13:17:48 --> XSS Filtering completed
DEBUG - 2016-05-21 13:17:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 13:17:48 --> Language Class Initialized
DEBUG - 2016-05-21 13:17:48 --> Loader Class Initialized
DEBUG - 2016-05-21 13:17:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 13:17:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 13:17:48 --> Helper loaded: url_helper
DEBUG - 2016-05-21 13:17:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 13:17:48 --> Helper loaded: file_helper
DEBUG - 2016-05-21 13:17:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:17:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 13:17:48 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 13:17:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:17:48 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 13:17:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 13:17:49 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:17:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 13:17:49 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:17:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 13:17:49 --> Helper loaded: form_helper
DEBUG - 2016-05-21 13:17:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 13:17:49 --> Helper loaded: security_helper
DEBUG - 2016-05-21 13:17:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:17:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 13:17:49 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 13:17:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:17:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 13:17:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 13:17:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 13:17:49 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 13:17:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:17:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 13:17:49 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 13:17:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:17:49 --> Database Driver Class Initialized
DEBUG - 2016-05-21 13:17:49 --> Session Class Initialized
DEBUG - 2016-05-21 13:17:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 13:17:49 --> Helper loaded: string_helper
DEBUG - 2016-05-21 13:17:49 --> Session routines successfully run
DEBUG - 2016-05-21 13:17:49 --> Native_session Class Initialized
DEBUG - 2016-05-21 13:17:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 13:17:49 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:17:49 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:17:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 13:17:49 --> Controller Class Initialized
DEBUG - 2016-05-21 13:17:49 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 13:17:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 13:17:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 13:17:49 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:17:49 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:17:49 --> User Agent Class Initialized
DEBUG - 2016-05-21 13:17:49 --> Model Class Initialized
DEBUG - 2016-05-21 13:17:49 --> Model Class Initialized
DEBUG - 2016-05-21 13:17:49 --> Model Class Initialized
DEBUG - 2016-05-21 13:17:49 --> Model Class Initialized
DEBUG - 2016-05-21 13:17:49 --> Model Class Initialized
DEBUG - 2016-05-21 13:18:07 --> Config Class Initialized
DEBUG - 2016-05-21 13:18:07 --> Hooks Class Initialized
DEBUG - 2016-05-21 13:18:07 --> Utf8 Class Initialized
DEBUG - 2016-05-21 13:18:07 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 13:18:07 --> URI Class Initialized
DEBUG - 2016-05-21 13:18:07 --> Router Class Initialized
DEBUG - 2016-05-21 13:18:07 --> Output Class Initialized
DEBUG - 2016-05-21 13:18:07 --> Security Class Initialized
DEBUG - 2016-05-21 13:18:07 --> Input Class Initialized
DEBUG - 2016-05-21 13:18:07 --> XSS Filtering completed
DEBUG - 2016-05-21 13:18:07 --> XSS Filtering completed
DEBUG - 2016-05-21 13:18:07 --> XSS Filtering completed
DEBUG - 2016-05-21 13:18:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 13:18:07 --> Language Class Initialized
DEBUG - 2016-05-21 13:18:07 --> Loader Class Initialized
DEBUG - 2016-05-21 13:18:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 13:18:07 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 13:18:07 --> Helper loaded: url_helper
DEBUG - 2016-05-21 13:18:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 13:18:07 --> Helper loaded: file_helper
DEBUG - 2016-05-21 13:18:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:18:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 13:18:07 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 13:18:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:18:07 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 13:18:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 13:18:07 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:18:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 13:18:07 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:18:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 13:18:07 --> Helper loaded: form_helper
DEBUG - 2016-05-21 13:18:07 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 13:18:07 --> Helper loaded: security_helper
DEBUG - 2016-05-21 13:18:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:18:07 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 13:18:07 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 13:18:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:18:07 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 13:18:07 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 13:18:07 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 13:18:07 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 13:18:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:18:07 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 13:18:07 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 13:18:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:18:07 --> Database Driver Class Initialized
DEBUG - 2016-05-21 13:18:08 --> Session Class Initialized
DEBUG - 2016-05-21 13:18:08 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 13:18:08 --> Helper loaded: string_helper
DEBUG - 2016-05-21 13:18:08 --> Session routines successfully run
DEBUG - 2016-05-21 13:18:08 --> Native_session Class Initialized
DEBUG - 2016-05-21 13:18:08 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 13:18:08 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:18:08 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:18:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 13:18:08 --> Controller Class Initialized
DEBUG - 2016-05-21 13:18:08 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 13:18:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 13:18:08 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 13:18:08 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:18:08 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:18:08 --> User Agent Class Initialized
DEBUG - 2016-05-21 13:18:08 --> Model Class Initialized
DEBUG - 2016-05-21 13:18:08 --> Model Class Initialized
DEBUG - 2016-05-21 13:18:08 --> Model Class Initialized
DEBUG - 2016-05-21 13:18:08 --> Model Class Initialized
DEBUG - 2016-05-21 13:18:08 --> Model Class Initialized
DEBUG - 2016-05-21 13:18:26 --> Config Class Initialized
DEBUG - 2016-05-21 13:18:26 --> Hooks Class Initialized
DEBUG - 2016-05-21 13:18:26 --> Utf8 Class Initialized
DEBUG - 2016-05-21 13:18:26 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 13:18:26 --> URI Class Initialized
DEBUG - 2016-05-21 13:18:26 --> Router Class Initialized
DEBUG - 2016-05-21 13:18:26 --> Output Class Initialized
DEBUG - 2016-05-21 13:18:26 --> Security Class Initialized
DEBUG - 2016-05-21 13:18:26 --> Input Class Initialized
DEBUG - 2016-05-21 13:18:26 --> XSS Filtering completed
DEBUG - 2016-05-21 13:18:27 --> XSS Filtering completed
DEBUG - 2016-05-21 13:18:27 --> XSS Filtering completed
DEBUG - 2016-05-21 13:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 13:18:27 --> Language Class Initialized
DEBUG - 2016-05-21 13:18:27 --> Loader Class Initialized
DEBUG - 2016-05-21 13:18:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 13:18:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 13:18:27 --> Helper loaded: url_helper
DEBUG - 2016-05-21 13:18:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 13:18:27 --> Helper loaded: file_helper
DEBUG - 2016-05-21 13:18:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:18:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 13:18:27 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 13:18:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:18:27 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 13:18:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 13:18:27 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:18:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 13:18:27 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:18:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 13:18:27 --> Helper loaded: form_helper
DEBUG - 2016-05-21 13:18:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 13:18:27 --> Helper loaded: security_helper
DEBUG - 2016-05-21 13:18:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:18:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 13:18:27 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 13:18:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:18:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 13:18:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 13:18:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 13:18:27 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 13:18:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:18:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 13:18:27 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 13:18:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:18:27 --> Database Driver Class Initialized
DEBUG - 2016-05-21 13:18:27 --> Session Class Initialized
DEBUG - 2016-05-21 13:18:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 13:18:27 --> Helper loaded: string_helper
DEBUG - 2016-05-21 13:18:27 --> Session routines successfully run
DEBUG - 2016-05-21 13:18:27 --> Native_session Class Initialized
DEBUG - 2016-05-21 13:18:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 13:18:27 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:18:27 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:18:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 13:18:27 --> Controller Class Initialized
DEBUG - 2016-05-21 13:18:27 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 13:18:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 13:18:27 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 13:18:27 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:18:27 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:18:27 --> User Agent Class Initialized
DEBUG - 2016-05-21 13:18:27 --> Model Class Initialized
DEBUG - 2016-05-21 13:18:27 --> Model Class Initialized
DEBUG - 2016-05-21 13:18:27 --> Model Class Initialized
DEBUG - 2016-05-21 13:18:27 --> Model Class Initialized
DEBUG - 2016-05-21 13:18:27 --> Model Class Initialized
DEBUG - 2016-05-21 13:18:57 --> Config Class Initialized
DEBUG - 2016-05-21 13:18:57 --> Hooks Class Initialized
DEBUG - 2016-05-21 13:18:57 --> Utf8 Class Initialized
DEBUG - 2016-05-21 13:18:57 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 13:18:57 --> URI Class Initialized
DEBUG - 2016-05-21 13:18:57 --> Router Class Initialized
DEBUG - 2016-05-21 13:18:57 --> Output Class Initialized
DEBUG - 2016-05-21 13:18:57 --> Security Class Initialized
DEBUG - 2016-05-21 13:18:57 --> Input Class Initialized
DEBUG - 2016-05-21 13:18:57 --> XSS Filtering completed
DEBUG - 2016-05-21 13:18:57 --> XSS Filtering completed
DEBUG - 2016-05-21 13:18:57 --> XSS Filtering completed
DEBUG - 2016-05-21 13:18:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 13:18:57 --> Language Class Initialized
DEBUG - 2016-05-21 13:18:57 --> Loader Class Initialized
DEBUG - 2016-05-21 13:18:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 13:18:58 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 13:18:58 --> Helper loaded: url_helper
DEBUG - 2016-05-21 13:18:58 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 13:18:58 --> Helper loaded: file_helper
DEBUG - 2016-05-21 13:18:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:18:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 13:18:58 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 13:18:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:18:58 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 13:18:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 13:18:58 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:18:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 13:18:58 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:18:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 13:18:58 --> Helper loaded: form_helper
DEBUG - 2016-05-21 13:18:58 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 13:18:58 --> Helper loaded: security_helper
DEBUG - 2016-05-21 13:18:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:18:58 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 13:18:58 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 13:18:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:18:58 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 13:18:58 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 13:18:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 13:18:58 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 13:18:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:18:58 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 13:18:58 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 13:18:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:18:58 --> Database Driver Class Initialized
DEBUG - 2016-05-21 13:18:58 --> Session Class Initialized
DEBUG - 2016-05-21 13:18:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 13:18:58 --> Helper loaded: string_helper
DEBUG - 2016-05-21 13:18:58 --> Session routines successfully run
DEBUG - 2016-05-21 13:18:58 --> Native_session Class Initialized
DEBUG - 2016-05-21 13:18:58 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 13:18:58 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:18:58 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:18:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 13:18:58 --> Controller Class Initialized
DEBUG - 2016-05-21 13:18:58 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 13:18:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 13:18:58 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 13:18:58 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:18:58 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:18:58 --> User Agent Class Initialized
DEBUG - 2016-05-21 13:18:58 --> Model Class Initialized
DEBUG - 2016-05-21 13:18:58 --> Model Class Initialized
DEBUG - 2016-05-21 13:18:58 --> Model Class Initialized
DEBUG - 2016-05-21 13:18:58 --> Model Class Initialized
DEBUG - 2016-05-21 13:18:58 --> Model Class Initialized
DEBUG - 2016-05-21 13:19:31 --> Config Class Initialized
DEBUG - 2016-05-21 13:19:31 --> Hooks Class Initialized
DEBUG - 2016-05-21 13:19:31 --> Utf8 Class Initialized
DEBUG - 2016-05-21 13:19:31 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 13:19:31 --> URI Class Initialized
DEBUG - 2016-05-21 13:19:31 --> Router Class Initialized
DEBUG - 2016-05-21 13:19:31 --> Output Class Initialized
DEBUG - 2016-05-21 13:19:31 --> Security Class Initialized
DEBUG - 2016-05-21 13:19:31 --> Input Class Initialized
DEBUG - 2016-05-21 13:19:31 --> XSS Filtering completed
DEBUG - 2016-05-21 13:19:31 --> XSS Filtering completed
DEBUG - 2016-05-21 13:19:31 --> XSS Filtering completed
DEBUG - 2016-05-21 13:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 13:19:31 --> Language Class Initialized
DEBUG - 2016-05-21 13:19:31 --> Loader Class Initialized
DEBUG - 2016-05-21 13:19:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 13:19:31 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 13:19:31 --> Helper loaded: url_helper
DEBUG - 2016-05-21 13:19:31 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 13:19:31 --> Helper loaded: file_helper
DEBUG - 2016-05-21 13:19:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:19:31 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 13:19:31 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 13:19:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:19:31 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 13:19:31 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 13:19:31 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:19:31 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 13:19:31 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:19:31 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 13:19:31 --> Helper loaded: form_helper
DEBUG - 2016-05-21 13:19:31 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 13:19:31 --> Helper loaded: security_helper
DEBUG - 2016-05-21 13:19:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:19:31 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 13:19:31 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 13:19:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:19:31 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 13:19:31 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 13:19:31 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 13:19:31 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 13:19:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:19:31 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 13:19:31 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 13:19:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:19:31 --> Database Driver Class Initialized
DEBUG - 2016-05-21 13:19:31 --> Session Class Initialized
DEBUG - 2016-05-21 13:19:31 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 13:19:31 --> Helper loaded: string_helper
DEBUG - 2016-05-21 13:19:31 --> Session routines successfully run
DEBUG - 2016-05-21 13:19:31 --> Native_session Class Initialized
DEBUG - 2016-05-21 13:19:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 13:19:31 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:19:31 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:19:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 13:19:31 --> Controller Class Initialized
DEBUG - 2016-05-21 13:19:31 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 13:19:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 13:19:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 13:19:31 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:19:31 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:19:31 --> User Agent Class Initialized
DEBUG - 2016-05-21 13:19:32 --> Model Class Initialized
DEBUG - 2016-05-21 13:19:32 --> Model Class Initialized
DEBUG - 2016-05-21 13:19:32 --> Model Class Initialized
DEBUG - 2016-05-21 13:19:32 --> Model Class Initialized
DEBUG - 2016-05-21 13:19:32 --> Model Class Initialized
DEBUG - 2016-05-21 13:20:01 --> Config Class Initialized
DEBUG - 2016-05-21 13:20:01 --> Hooks Class Initialized
DEBUG - 2016-05-21 13:20:01 --> Utf8 Class Initialized
DEBUG - 2016-05-21 13:20:01 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 13:20:01 --> URI Class Initialized
DEBUG - 2016-05-21 13:20:01 --> Router Class Initialized
DEBUG - 2016-05-21 13:20:01 --> Output Class Initialized
DEBUG - 2016-05-21 13:20:01 --> Security Class Initialized
DEBUG - 2016-05-21 13:20:01 --> Input Class Initialized
DEBUG - 2016-05-21 13:20:01 --> XSS Filtering completed
DEBUG - 2016-05-21 13:20:01 --> XSS Filtering completed
DEBUG - 2016-05-21 13:20:01 --> XSS Filtering completed
DEBUG - 2016-05-21 13:20:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 13:20:01 --> Language Class Initialized
DEBUG - 2016-05-21 13:20:01 --> Loader Class Initialized
DEBUG - 2016-05-21 13:20:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 13:20:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 13:20:01 --> Helper loaded: url_helper
DEBUG - 2016-05-21 13:20:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 13:20:01 --> Helper loaded: file_helper
DEBUG - 2016-05-21 13:20:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:20:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 13:20:01 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 13:20:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:20:01 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 13:20:02 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 13:20:02 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:20:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 13:20:02 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:20:02 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 13:20:02 --> Helper loaded: form_helper
DEBUG - 2016-05-21 13:20:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 13:20:02 --> Helper loaded: security_helper
DEBUG - 2016-05-21 13:20:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:20:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 13:20:02 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 13:20:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:20:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 13:20:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 13:20:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 13:20:02 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 13:20:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:20:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 13:20:02 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 13:20:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:20:02 --> Database Driver Class Initialized
DEBUG - 2016-05-21 13:20:02 --> Session Class Initialized
DEBUG - 2016-05-21 13:20:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 13:20:02 --> Helper loaded: string_helper
DEBUG - 2016-05-21 13:20:02 --> Session routines successfully run
DEBUG - 2016-05-21 13:20:02 --> Native_session Class Initialized
DEBUG - 2016-05-21 13:20:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 13:20:02 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:20:02 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:20:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 13:20:02 --> Controller Class Initialized
DEBUG - 2016-05-21 13:20:02 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 13:20:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 13:20:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 13:20:02 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:20:02 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:20:02 --> User Agent Class Initialized
DEBUG - 2016-05-21 13:20:02 --> Model Class Initialized
DEBUG - 2016-05-21 13:20:02 --> Model Class Initialized
DEBUG - 2016-05-21 13:20:02 --> Model Class Initialized
DEBUG - 2016-05-21 13:20:02 --> Model Class Initialized
DEBUG - 2016-05-21 13:20:02 --> Model Class Initialized
DEBUG - 2016-05-21 13:20:56 --> Config Class Initialized
DEBUG - 2016-05-21 13:20:56 --> Hooks Class Initialized
DEBUG - 2016-05-21 13:20:56 --> Utf8 Class Initialized
DEBUG - 2016-05-21 13:20:56 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 13:20:56 --> URI Class Initialized
DEBUG - 2016-05-21 13:20:56 --> Router Class Initialized
DEBUG - 2016-05-21 13:20:56 --> Output Class Initialized
DEBUG - 2016-05-21 13:20:56 --> Security Class Initialized
DEBUG - 2016-05-21 13:20:56 --> Input Class Initialized
DEBUG - 2016-05-21 13:20:56 --> XSS Filtering completed
DEBUG - 2016-05-21 13:20:56 --> XSS Filtering completed
DEBUG - 2016-05-21 13:20:56 --> XSS Filtering completed
DEBUG - 2016-05-21 13:20:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 13:20:56 --> Language Class Initialized
DEBUG - 2016-05-21 13:20:56 --> Loader Class Initialized
DEBUG - 2016-05-21 13:20:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 13:20:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 13:20:56 --> Helper loaded: url_helper
DEBUG - 2016-05-21 13:20:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 13:20:56 --> Helper loaded: file_helper
DEBUG - 2016-05-21 13:20:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:20:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 13:20:56 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 13:20:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:20:56 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 13:20:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 13:20:56 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:20:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 13:20:56 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:20:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 13:20:56 --> Helper loaded: form_helper
DEBUG - 2016-05-21 13:20:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 13:20:56 --> Helper loaded: security_helper
DEBUG - 2016-05-21 13:20:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:20:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 13:20:56 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 13:20:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:20:56 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 13:20:56 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 13:20:56 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 13:20:57 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 13:20:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:20:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 13:20:57 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 13:20:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:20:57 --> Database Driver Class Initialized
DEBUG - 2016-05-21 13:20:57 --> Session Class Initialized
DEBUG - 2016-05-21 13:20:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 13:20:57 --> Helper loaded: string_helper
DEBUG - 2016-05-21 13:20:57 --> Session routines successfully run
DEBUG - 2016-05-21 13:20:57 --> Native_session Class Initialized
DEBUG - 2016-05-21 13:20:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 13:20:57 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:20:57 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:20:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 13:20:57 --> Controller Class Initialized
DEBUG - 2016-05-21 13:20:57 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 13:20:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 13:20:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 13:20:57 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:20:57 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:20:57 --> User Agent Class Initialized
DEBUG - 2016-05-21 13:20:57 --> Model Class Initialized
DEBUG - 2016-05-21 13:20:57 --> Model Class Initialized
DEBUG - 2016-05-21 13:20:57 --> Model Class Initialized
DEBUG - 2016-05-21 13:20:57 --> Model Class Initialized
DEBUG - 2016-05-21 13:20:57 --> Model Class Initialized
DEBUG - 2016-05-21 13:22:38 --> Config Class Initialized
DEBUG - 2016-05-21 13:22:38 --> Hooks Class Initialized
DEBUG - 2016-05-21 13:22:38 --> Utf8 Class Initialized
DEBUG - 2016-05-21 13:22:38 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 13:22:38 --> URI Class Initialized
DEBUG - 2016-05-21 13:22:38 --> Router Class Initialized
DEBUG - 2016-05-21 13:22:38 --> Output Class Initialized
DEBUG - 2016-05-21 13:22:38 --> Security Class Initialized
DEBUG - 2016-05-21 13:22:38 --> Input Class Initialized
DEBUG - 2016-05-21 13:22:38 --> XSS Filtering completed
DEBUG - 2016-05-21 13:22:38 --> XSS Filtering completed
DEBUG - 2016-05-21 13:22:38 --> XSS Filtering completed
DEBUG - 2016-05-21 13:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 13:22:38 --> Language Class Initialized
DEBUG - 2016-05-21 13:22:38 --> Loader Class Initialized
DEBUG - 2016-05-21 13:22:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 13:22:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 13:22:38 --> Helper loaded: url_helper
DEBUG - 2016-05-21 13:22:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 13:22:38 --> Helper loaded: file_helper
DEBUG - 2016-05-21 13:22:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:22:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 13:22:38 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 13:22:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:22:38 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 13:22:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 13:22:38 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:22:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 13:22:38 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:22:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 13:22:38 --> Helper loaded: form_helper
DEBUG - 2016-05-21 13:22:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 13:22:38 --> Helper loaded: security_helper
DEBUG - 2016-05-21 13:22:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:22:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 13:22:39 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 13:22:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:22:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 13:22:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 13:22:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 13:22:39 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 13:22:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:22:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 13:22:39 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 13:22:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:22:39 --> Database Driver Class Initialized
DEBUG - 2016-05-21 13:22:39 --> Session Class Initialized
DEBUG - 2016-05-21 13:22:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 13:22:39 --> Helper loaded: string_helper
DEBUG - 2016-05-21 13:22:39 --> Session routines successfully run
DEBUG - 2016-05-21 13:22:39 --> Native_session Class Initialized
DEBUG - 2016-05-21 13:22:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 13:22:39 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:22:39 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:22:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 13:22:39 --> Controller Class Initialized
DEBUG - 2016-05-21 13:22:39 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 13:22:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 13:22:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 13:22:39 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:22:39 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:22:39 --> User Agent Class Initialized
DEBUG - 2016-05-21 13:22:39 --> Model Class Initialized
DEBUG - 2016-05-21 13:22:39 --> Model Class Initialized
DEBUG - 2016-05-21 13:22:39 --> Model Class Initialized
DEBUG - 2016-05-21 13:22:39 --> Model Class Initialized
DEBUG - 2016-05-21 13:22:39 --> Model Class Initialized
DEBUG - 2016-05-21 13:22:54 --> Config Class Initialized
DEBUG - 2016-05-21 13:22:54 --> Hooks Class Initialized
DEBUG - 2016-05-21 13:22:54 --> Utf8 Class Initialized
DEBUG - 2016-05-21 13:22:54 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 13:22:54 --> URI Class Initialized
DEBUG - 2016-05-21 13:22:54 --> Router Class Initialized
DEBUG - 2016-05-21 13:22:54 --> Output Class Initialized
DEBUG - 2016-05-21 13:22:54 --> Security Class Initialized
DEBUG - 2016-05-21 13:22:54 --> Input Class Initialized
DEBUG - 2016-05-21 13:22:54 --> XSS Filtering completed
DEBUG - 2016-05-21 13:22:54 --> XSS Filtering completed
DEBUG - 2016-05-21 13:22:54 --> XSS Filtering completed
DEBUG - 2016-05-21 13:22:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 13:22:54 --> Language Class Initialized
DEBUG - 2016-05-21 13:22:54 --> Loader Class Initialized
DEBUG - 2016-05-21 13:22:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 13:22:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 13:22:54 --> Helper loaded: url_helper
DEBUG - 2016-05-21 13:22:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 13:22:54 --> Helper loaded: file_helper
DEBUG - 2016-05-21 13:22:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:22:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 13:22:54 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 13:22:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:22:54 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 13:22:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 13:22:54 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:22:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 13:22:55 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:22:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 13:22:55 --> Helper loaded: form_helper
DEBUG - 2016-05-21 13:22:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 13:22:55 --> Helper loaded: security_helper
DEBUG - 2016-05-21 13:22:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:22:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 13:22:55 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 13:22:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:22:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 13:22:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 13:22:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 13:22:55 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 13:22:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:22:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 13:22:55 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 13:22:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:22:55 --> Database Driver Class Initialized
DEBUG - 2016-05-21 13:22:55 --> Session Class Initialized
DEBUG - 2016-05-21 13:22:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 13:22:55 --> Helper loaded: string_helper
DEBUG - 2016-05-21 13:22:55 --> Session routines successfully run
DEBUG - 2016-05-21 13:22:55 --> Native_session Class Initialized
DEBUG - 2016-05-21 13:22:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 13:22:55 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:22:55 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:22:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 13:22:55 --> Controller Class Initialized
DEBUG - 2016-05-21 13:22:55 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 13:22:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 13:22:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 13:22:55 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:22:55 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:22:55 --> User Agent Class Initialized
DEBUG - 2016-05-21 13:22:55 --> Model Class Initialized
DEBUG - 2016-05-21 13:22:55 --> Model Class Initialized
DEBUG - 2016-05-21 13:22:55 --> Model Class Initialized
DEBUG - 2016-05-21 13:22:55 --> Model Class Initialized
DEBUG - 2016-05-21 13:22:55 --> Model Class Initialized
DEBUG - 2016-05-21 13:23:10 --> Config Class Initialized
DEBUG - 2016-05-21 13:23:10 --> Hooks Class Initialized
DEBUG - 2016-05-21 13:23:10 --> Utf8 Class Initialized
DEBUG - 2016-05-21 13:23:10 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 13:23:10 --> URI Class Initialized
DEBUG - 2016-05-21 13:23:10 --> Router Class Initialized
DEBUG - 2016-05-21 13:23:10 --> Output Class Initialized
DEBUG - 2016-05-21 13:23:10 --> Security Class Initialized
DEBUG - 2016-05-21 13:23:10 --> Input Class Initialized
DEBUG - 2016-05-21 13:23:10 --> XSS Filtering completed
DEBUG - 2016-05-21 13:23:10 --> XSS Filtering completed
DEBUG - 2016-05-21 13:23:10 --> XSS Filtering completed
DEBUG - 2016-05-21 13:23:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 13:23:10 --> Language Class Initialized
DEBUG - 2016-05-21 13:23:10 --> Loader Class Initialized
DEBUG - 2016-05-21 13:23:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 13:23:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 13:23:10 --> Helper loaded: url_helper
DEBUG - 2016-05-21 13:23:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 13:23:10 --> Helper loaded: file_helper
DEBUG - 2016-05-21 13:23:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:23:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 13:23:10 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 13:23:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:23:10 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 13:23:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 13:23:10 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:23:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 13:23:10 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:23:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 13:23:10 --> Helper loaded: form_helper
DEBUG - 2016-05-21 13:23:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 13:23:10 --> Helper loaded: security_helper
DEBUG - 2016-05-21 13:23:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:23:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 13:23:10 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 13:23:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:23:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 13:23:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 13:23:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 13:23:10 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 13:23:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:23:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 13:23:10 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 13:23:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:23:10 --> Database Driver Class Initialized
DEBUG - 2016-05-21 13:23:11 --> Session Class Initialized
DEBUG - 2016-05-21 13:23:11 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 13:23:11 --> Helper loaded: string_helper
DEBUG - 2016-05-21 13:23:11 --> Session routines successfully run
DEBUG - 2016-05-21 13:23:11 --> Native_session Class Initialized
DEBUG - 2016-05-21 13:23:11 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 13:23:11 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:23:11 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:23:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 13:23:11 --> Controller Class Initialized
DEBUG - 2016-05-21 13:23:11 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 13:23:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 13:23:11 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 13:23:11 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:23:11 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:23:11 --> User Agent Class Initialized
DEBUG - 2016-05-21 13:23:11 --> Model Class Initialized
DEBUG - 2016-05-21 13:23:11 --> Model Class Initialized
DEBUG - 2016-05-21 13:23:11 --> Model Class Initialized
DEBUG - 2016-05-21 13:23:11 --> Model Class Initialized
DEBUG - 2016-05-21 13:23:11 --> Model Class Initialized
DEBUG - 2016-05-21 13:23:47 --> Config Class Initialized
DEBUG - 2016-05-21 13:23:47 --> Hooks Class Initialized
DEBUG - 2016-05-21 13:23:47 --> Utf8 Class Initialized
DEBUG - 2016-05-21 13:23:47 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 13:23:47 --> URI Class Initialized
DEBUG - 2016-05-21 13:23:47 --> Router Class Initialized
DEBUG - 2016-05-21 13:23:47 --> Output Class Initialized
DEBUG - 2016-05-21 13:23:47 --> Security Class Initialized
DEBUG - 2016-05-21 13:23:47 --> Input Class Initialized
DEBUG - 2016-05-21 13:23:47 --> XSS Filtering completed
DEBUG - 2016-05-21 13:23:47 --> XSS Filtering completed
DEBUG - 2016-05-21 13:23:47 --> XSS Filtering completed
DEBUG - 2016-05-21 13:23:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 13:23:47 --> Language Class Initialized
DEBUG - 2016-05-21 13:23:47 --> Loader Class Initialized
DEBUG - 2016-05-21 13:23:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 13:23:47 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 13:23:47 --> Helper loaded: url_helper
DEBUG - 2016-05-21 13:23:47 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 13:23:47 --> Helper loaded: file_helper
DEBUG - 2016-05-21 13:23:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:23:47 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 13:23:47 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 13:23:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:23:47 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 13:23:47 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 13:23:48 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:23:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 13:23:48 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:23:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 13:23:48 --> Helper loaded: form_helper
DEBUG - 2016-05-21 13:23:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 13:23:48 --> Helper loaded: security_helper
DEBUG - 2016-05-21 13:23:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:23:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 13:23:48 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 13:23:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:23:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 13:23:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 13:23:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 13:23:48 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 13:23:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:23:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 13:23:48 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 13:23:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:23:48 --> Database Driver Class Initialized
DEBUG - 2016-05-21 13:23:48 --> Session Class Initialized
DEBUG - 2016-05-21 13:23:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 13:23:48 --> Helper loaded: string_helper
DEBUG - 2016-05-21 13:23:48 --> Session routines successfully run
DEBUG - 2016-05-21 13:23:48 --> Native_session Class Initialized
DEBUG - 2016-05-21 13:23:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 13:23:48 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:23:48 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:23:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 13:23:48 --> Controller Class Initialized
DEBUG - 2016-05-21 13:23:48 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 13:23:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 13:23:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 13:23:48 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:23:48 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:23:48 --> User Agent Class Initialized
DEBUG - 2016-05-21 13:23:48 --> Model Class Initialized
DEBUG - 2016-05-21 13:23:48 --> Model Class Initialized
DEBUG - 2016-05-21 13:23:48 --> Model Class Initialized
DEBUG - 2016-05-21 13:23:48 --> Model Class Initialized
DEBUG - 2016-05-21 13:23:48 --> Model Class Initialized
DEBUG - 2016-05-21 13:25:04 --> Config Class Initialized
DEBUG - 2016-05-21 13:25:04 --> Hooks Class Initialized
DEBUG - 2016-05-21 13:25:04 --> Utf8 Class Initialized
DEBUG - 2016-05-21 13:25:04 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 13:25:04 --> URI Class Initialized
DEBUG - 2016-05-21 13:25:04 --> Router Class Initialized
DEBUG - 2016-05-21 13:25:04 --> Output Class Initialized
DEBUG - 2016-05-21 13:25:04 --> Security Class Initialized
DEBUG - 2016-05-21 13:25:04 --> Input Class Initialized
DEBUG - 2016-05-21 13:25:04 --> XSS Filtering completed
DEBUG - 2016-05-21 13:25:05 --> XSS Filtering completed
DEBUG - 2016-05-21 13:25:05 --> XSS Filtering completed
DEBUG - 2016-05-21 13:25:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 13:25:05 --> Language Class Initialized
DEBUG - 2016-05-21 13:25:05 --> Loader Class Initialized
DEBUG - 2016-05-21 13:25:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 13:25:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 13:25:05 --> Helper loaded: url_helper
DEBUG - 2016-05-21 13:25:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 13:25:05 --> Helper loaded: file_helper
DEBUG - 2016-05-21 13:25:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:25:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 13:25:05 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 13:25:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:25:05 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 13:25:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 13:25:05 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:25:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 13:25:05 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:25:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 13:25:05 --> Helper loaded: form_helper
DEBUG - 2016-05-21 13:25:05 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 13:25:05 --> Helper loaded: security_helper
DEBUG - 2016-05-21 13:25:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:25:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 13:25:05 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 13:25:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:25:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 13:25:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 13:25:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 13:25:05 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 13:25:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:25:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 13:25:05 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 13:25:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:25:05 --> Database Driver Class Initialized
DEBUG - 2016-05-21 13:25:05 --> Session Class Initialized
DEBUG - 2016-05-21 13:25:05 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 13:25:05 --> Helper loaded: string_helper
DEBUG - 2016-05-21 13:25:05 --> Session routines successfully run
DEBUG - 2016-05-21 13:25:05 --> Native_session Class Initialized
DEBUG - 2016-05-21 13:25:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 13:25:05 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:25:05 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:25:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 13:25:05 --> Controller Class Initialized
DEBUG - 2016-05-21 13:25:05 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 13:25:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 13:25:05 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 13:25:05 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:25:05 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:25:05 --> User Agent Class Initialized
DEBUG - 2016-05-21 13:25:05 --> Model Class Initialized
DEBUG - 2016-05-21 13:25:05 --> Model Class Initialized
DEBUG - 2016-05-21 13:25:05 --> Model Class Initialized
DEBUG - 2016-05-21 13:25:05 --> Model Class Initialized
DEBUG - 2016-05-21 13:25:05 --> Model Class Initialized
DEBUG - 2016-05-21 13:25:37 --> Config Class Initialized
DEBUG - 2016-05-21 13:25:37 --> Hooks Class Initialized
DEBUG - 2016-05-21 13:25:37 --> Utf8 Class Initialized
DEBUG - 2016-05-21 13:25:37 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 13:25:37 --> URI Class Initialized
DEBUG - 2016-05-21 13:25:37 --> Router Class Initialized
DEBUG - 2016-05-21 13:25:37 --> Output Class Initialized
DEBUG - 2016-05-21 13:25:37 --> Security Class Initialized
DEBUG - 2016-05-21 13:25:37 --> Input Class Initialized
DEBUG - 2016-05-21 13:25:37 --> XSS Filtering completed
DEBUG - 2016-05-21 13:25:37 --> XSS Filtering completed
DEBUG - 2016-05-21 13:25:37 --> XSS Filtering completed
DEBUG - 2016-05-21 13:25:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 13:25:37 --> Language Class Initialized
DEBUG - 2016-05-21 13:25:37 --> Loader Class Initialized
DEBUG - 2016-05-21 13:25:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 13:25:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 13:25:37 --> Helper loaded: url_helper
DEBUG - 2016-05-21 13:25:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 13:25:37 --> Helper loaded: file_helper
DEBUG - 2016-05-21 13:25:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:25:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 13:25:37 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 13:25:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:25:37 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 13:25:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 13:25:37 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:25:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 13:25:37 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:25:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 13:25:37 --> Helper loaded: form_helper
DEBUG - 2016-05-21 13:25:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 13:25:37 --> Helper loaded: security_helper
DEBUG - 2016-05-21 13:25:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:25:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 13:25:37 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 13:25:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:25:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 13:25:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 13:25:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 13:25:37 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 13:25:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:25:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 13:25:38 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 13:25:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:25:38 --> Database Driver Class Initialized
DEBUG - 2016-05-21 13:25:38 --> Session Class Initialized
DEBUG - 2016-05-21 13:25:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 13:25:38 --> Helper loaded: string_helper
DEBUG - 2016-05-21 13:25:38 --> Session routines successfully run
DEBUG - 2016-05-21 13:25:38 --> Native_session Class Initialized
DEBUG - 2016-05-21 13:25:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 13:25:38 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:25:38 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:25:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 13:25:38 --> Controller Class Initialized
DEBUG - 2016-05-21 13:25:38 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 13:25:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 13:25:38 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 13:25:38 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:25:38 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:25:38 --> User Agent Class Initialized
DEBUG - 2016-05-21 13:25:38 --> Model Class Initialized
DEBUG - 2016-05-21 13:25:38 --> Model Class Initialized
DEBUG - 2016-05-21 13:25:38 --> Model Class Initialized
DEBUG - 2016-05-21 13:25:38 --> Model Class Initialized
DEBUG - 2016-05-21 13:25:38 --> Model Class Initialized
DEBUG - 2016-05-21 13:27:50 --> Config Class Initialized
DEBUG - 2016-05-21 13:27:50 --> Hooks Class Initialized
DEBUG - 2016-05-21 13:27:50 --> Utf8 Class Initialized
DEBUG - 2016-05-21 13:27:50 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 13:27:50 --> URI Class Initialized
DEBUG - 2016-05-21 13:27:50 --> Router Class Initialized
DEBUG - 2016-05-21 13:27:50 --> Output Class Initialized
DEBUG - 2016-05-21 13:27:50 --> Security Class Initialized
DEBUG - 2016-05-21 13:27:50 --> Input Class Initialized
DEBUG - 2016-05-21 13:27:50 --> XSS Filtering completed
DEBUG - 2016-05-21 13:27:50 --> XSS Filtering completed
DEBUG - 2016-05-21 13:27:50 --> XSS Filtering completed
DEBUG - 2016-05-21 13:27:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 13:27:50 --> Language Class Initialized
DEBUG - 2016-05-21 13:27:50 --> Loader Class Initialized
DEBUG - 2016-05-21 13:27:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 13:27:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 13:27:50 --> Helper loaded: url_helper
DEBUG - 2016-05-21 13:27:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 13:27:50 --> Helper loaded: file_helper
DEBUG - 2016-05-21 13:27:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:27:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 13:27:50 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 13:27:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:27:50 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 13:27:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 13:27:50 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:27:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 13:27:50 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:27:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 13:27:50 --> Helper loaded: form_helper
DEBUG - 2016-05-21 13:27:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 13:27:50 --> Helper loaded: security_helper
DEBUG - 2016-05-21 13:27:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:27:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 13:27:50 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 13:27:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:27:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 13:27:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 13:27:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 13:27:50 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 13:27:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:27:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 13:27:51 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 13:27:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:27:51 --> Database Driver Class Initialized
DEBUG - 2016-05-21 13:27:51 --> Session Class Initialized
DEBUG - 2016-05-21 13:27:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 13:27:51 --> Helper loaded: string_helper
DEBUG - 2016-05-21 13:27:51 --> Session routines successfully run
DEBUG - 2016-05-21 13:27:51 --> Native_session Class Initialized
DEBUG - 2016-05-21 13:27:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 13:27:51 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:27:51 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:27:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 13:27:51 --> Controller Class Initialized
DEBUG - 2016-05-21 13:27:51 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 13:27:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 13:27:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 13:27:51 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:27:51 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:27:51 --> User Agent Class Initialized
DEBUG - 2016-05-21 13:27:51 --> Model Class Initialized
DEBUG - 2016-05-21 13:27:51 --> Model Class Initialized
DEBUG - 2016-05-21 13:27:51 --> Model Class Initialized
DEBUG - 2016-05-21 13:27:51 --> Model Class Initialized
DEBUG - 2016-05-21 13:27:51 --> Model Class Initialized
DEBUG - 2016-05-21 13:28:30 --> Config Class Initialized
DEBUG - 2016-05-21 13:28:30 --> Hooks Class Initialized
DEBUG - 2016-05-21 13:28:30 --> Utf8 Class Initialized
DEBUG - 2016-05-21 13:28:30 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 13:28:30 --> URI Class Initialized
DEBUG - 2016-05-21 13:28:30 --> Router Class Initialized
DEBUG - 2016-05-21 13:28:30 --> Output Class Initialized
DEBUG - 2016-05-21 13:28:30 --> Security Class Initialized
DEBUG - 2016-05-21 13:28:30 --> Input Class Initialized
DEBUG - 2016-05-21 13:28:30 --> XSS Filtering completed
DEBUG - 2016-05-21 13:28:30 --> XSS Filtering completed
DEBUG - 2016-05-21 13:28:30 --> XSS Filtering completed
DEBUG - 2016-05-21 13:28:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 13:28:30 --> Language Class Initialized
DEBUG - 2016-05-21 13:28:30 --> Loader Class Initialized
DEBUG - 2016-05-21 13:28:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 13:28:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 13:28:30 --> Helper loaded: url_helper
DEBUG - 2016-05-21 13:28:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 13:28:30 --> Helper loaded: file_helper
DEBUG - 2016-05-21 13:28:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:28:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 13:28:30 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 13:28:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 13:28:30 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 13:28:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 13:28:31 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:28:31 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 13:28:31 --> Helper loaded: common_helper
DEBUG - 2016-05-21 13:28:31 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 13:28:31 --> Helper loaded: form_helper
DEBUG - 2016-05-21 13:28:31 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 13:28:31 --> Helper loaded: security_helper
DEBUG - 2016-05-21 13:28:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:28:31 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 13:28:31 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 13:28:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 13:28:31 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 13:28:31 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 13:28:31 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 13:28:31 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 13:28:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:28:31 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 13:28:31 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 13:28:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 13:28:31 --> Database Driver Class Initialized
DEBUG - 2016-05-21 13:28:31 --> Session Class Initialized
DEBUG - 2016-05-21 13:28:31 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 13:28:31 --> Helper loaded: string_helper
DEBUG - 2016-05-21 13:28:31 --> Session routines successfully run
DEBUG - 2016-05-21 13:28:31 --> Native_session Class Initialized
DEBUG - 2016-05-21 13:28:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 13:28:31 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:28:31 --> Form Validation Class Initialized
DEBUG - 2016-05-21 13:28:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 13:28:31 --> Controller Class Initialized
DEBUG - 2016-05-21 13:28:31 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 13:28:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 13:28:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 13:28:31 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:28:31 --> Carabiner: library configured.
DEBUG - 2016-05-21 13:28:31 --> User Agent Class Initialized
DEBUG - 2016-05-21 13:28:31 --> Model Class Initialized
DEBUG - 2016-05-21 13:28:31 --> Model Class Initialized
DEBUG - 2016-05-21 13:28:31 --> Model Class Initialized
DEBUG - 2016-05-21 13:28:31 --> Model Class Initialized
DEBUG - 2016-05-21 13:28:31 --> Model Class Initialized
DEBUG - 2016-05-21 14:00:09 --> Config Class Initialized
DEBUG - 2016-05-21 14:00:09 --> Hooks Class Initialized
DEBUG - 2016-05-21 14:00:09 --> Utf8 Class Initialized
DEBUG - 2016-05-21 14:00:09 --> UTF-8 Support Enabled
DEBUG - 2016-05-21 14:00:09 --> URI Class Initialized
DEBUG - 2016-05-21 14:00:09 --> Router Class Initialized
DEBUG - 2016-05-21 14:00:09 --> Output Class Initialized
DEBUG - 2016-05-21 14:00:09 --> Security Class Initialized
DEBUG - 2016-05-21 14:00:09 --> Input Class Initialized
DEBUG - 2016-05-21 14:00:09 --> XSS Filtering completed
DEBUG - 2016-05-21 14:00:09 --> XSS Filtering completed
DEBUG - 2016-05-21 14:00:09 --> XSS Filtering completed
DEBUG - 2016-05-21 14:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-21 14:00:09 --> Language Class Initialized
DEBUG - 2016-05-21 14:00:09 --> Loader Class Initialized
DEBUG - 2016-05-21 14:00:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-21 14:00:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-21 14:00:09 --> Helper loaded: url_helper
DEBUG - 2016-05-21 14:00:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-21 14:00:09 --> Helper loaded: file_helper
DEBUG - 2016-05-21 14:00:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 14:00:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-21 14:00:09 --> Helper loaded: conf_helper
DEBUG - 2016-05-21 14:00:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-21 14:00:10 --> Check Exists common_helper.php: No
DEBUG - 2016-05-21 14:00:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-21 14:00:10 --> Helper loaded: common_helper
DEBUG - 2016-05-21 14:00:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-21 14:00:10 --> Helper loaded: common_helper
DEBUG - 2016-05-21 14:00:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-21 14:00:10 --> Helper loaded: form_helper
DEBUG - 2016-05-21 14:00:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-21 14:00:10 --> Helper loaded: security_helper
DEBUG - 2016-05-21 14:00:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 14:00:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-21 14:00:10 --> Helper loaded: lang_helper
DEBUG - 2016-05-21 14:00:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-21 14:00:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-21 14:00:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-21 14:00:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-21 14:00:10 --> Helper loaded: atlant_helper
DEBUG - 2016-05-21 14:00:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 14:00:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-21 14:00:10 --> Helper loaded: crypto_helper
DEBUG - 2016-05-21 14:00:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-21 14:00:10 --> Database Driver Class Initialized
DEBUG - 2016-05-21 14:00:10 --> Session Class Initialized
DEBUG - 2016-05-21 14:00:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-21 14:00:10 --> Helper loaded: string_helper
DEBUG - 2016-05-21 14:00:10 --> Session routines successfully run
DEBUG - 2016-05-21 14:00:10 --> Native_session Class Initialized
DEBUG - 2016-05-21 14:00:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-21 14:00:10 --> Form Validation Class Initialized
DEBUG - 2016-05-21 14:00:10 --> Form Validation Class Initialized
DEBUG - 2016-05-21 14:00:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-21 14:00:10 --> Controller Class Initialized
DEBUG - 2016-05-21 14:00:10 --> Carabiner: Library initialized.
DEBUG - 2016-05-21 14:00:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-21 14:00:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-21 14:00:10 --> Carabiner: library configured.
DEBUG - 2016-05-21 14:00:10 --> Carabiner: library configured.
DEBUG - 2016-05-21 14:00:10 --> User Agent Class Initialized
DEBUG - 2016-05-21 14:00:10 --> Model Class Initialized
DEBUG - 2016-05-21 14:00:10 --> Model Class Initialized
DEBUG - 2016-05-21 14:00:10 --> Model Class Initialized
DEBUG - 2016-05-21 14:00:10 --> Model Class Initialized
DEBUG - 2016-05-21 14:00:10 --> Model Class Initialized
