<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-09-17 14:33:33 --> Config Class Initialized
DEBUG - 2016-09-17 14:33:33 --> Hooks Class Initialized
DEBUG - 2016-09-17 14:33:33 --> Utf8 Class Initialized
DEBUG - 2016-09-17 14:33:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-17 14:33:33 --> URI Class Initialized
DEBUG - 2016-09-17 14:33:33 --> Router Class Initialized
DEBUG - 2016-09-17 14:33:33 --> No URI present. Default controller set.
DEBUG - 2016-09-17 14:33:33 --> Output Class Initialized
DEBUG - 2016-09-17 14:33:33 --> Cache file has expired. File deleted
DEBUG - 2016-09-17 14:33:33 --> Security Class Initialized
DEBUG - 2016-09-17 14:33:33 --> Input Class Initialized
DEBUG - 2016-09-17 14:33:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-17 14:33:33 --> Language Class Initialized
DEBUG - 2016-09-17 14:33:34 --> Loader Class Initialized
DEBUG - 2016-09-17 14:33:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-17 14:33:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-17 14:33:34 --> Helper loaded: url_helper
DEBUG - 2016-09-17 14:33:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-17 14:33:34 --> Helper loaded: file_helper
DEBUG - 2016-09-17 14:33:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-17 14:33:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-17 14:33:34 --> Helper loaded: conf_helper
DEBUG - 2016-09-17 14:33:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-17 14:33:34 --> Check Exists common_helper.php: No
DEBUG - 2016-09-17 14:33:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-17 14:33:34 --> Helper loaded: common_helper
DEBUG - 2016-09-17 14:33:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-17 14:33:34 --> Helper loaded: common_helper
DEBUG - 2016-09-17 14:33:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-17 14:33:34 --> Helper loaded: form_helper
DEBUG - 2016-09-17 14:33:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-17 14:33:34 --> Helper loaded: security_helper
DEBUG - 2016-09-17 14:33:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-17 14:33:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-17 14:33:34 --> Helper loaded: lang_helper
DEBUG - 2016-09-17 14:33:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-17 14:33:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-17 14:33:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-17 14:33:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-17 14:33:34 --> Helper loaded: atlant_helper
DEBUG - 2016-09-17 14:33:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-17 14:33:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-17 14:33:34 --> Helper loaded: crypto_helper
DEBUG - 2016-09-17 14:33:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-17 14:33:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-17 14:33:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-17 14:33:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-17 14:33:34 --> Helper loaded: sidika_helper
DEBUG - 2016-09-17 14:33:34 --> Database Driver Class Initialized
DEBUG - 2016-09-17 14:33:34 --> Session Class Initialized
DEBUG - 2016-09-17 14:33:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-17 14:33:34 --> Helper loaded: string_helper
DEBUG - 2016-09-17 14:33:34 --> A session cookie was not found.
DEBUG - 2016-09-17 14:33:34 --> Session routines successfully run
DEBUG - 2016-09-17 14:33:34 --> Native_session Class Initialized
DEBUG - 2016-09-17 14:33:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-17 14:33:34 --> Form Validation Class Initialized
DEBUG - 2016-09-17 14:33:34 --> Form Validation Class Initialized
DEBUG - 2016-09-17 14:33:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-17 14:33:35 --> Controller Class Initialized
DEBUG - 2016-09-17 14:33:35 --> Carabiner: Library initialized.
DEBUG - 2016-09-17 14:33:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-17 14:33:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-17 14:33:35 --> Carabiner: library configured.
DEBUG - 2016-09-17 14:33:35 --> Carabiner: library configured.
DEBUG - 2016-09-17 14:33:35 --> User Agent Class Initialized
DEBUG - 2016-09-17 14:33:35 --> Model Class Initialized
DEBUG - 2016-09-17 14:33:35 --> Model Class Initialized
DEBUG - 2016-09-17 14:33:35 --> Model Class Initialized
ERROR - 2016-09-17 14:33:35 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-17 14:33:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-17 14:33:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-17 14:33:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-17 14:33:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-17 14:33:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-17 14:33:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-17 14:33:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-17 14:33:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-17 14:33:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-17 14:33:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-17 14:33:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-17 14:33:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-17 14:33:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-17 14:33:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-17 14:33:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-17 14:33:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-17 14:33:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-17 14:33:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-17 14:33:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-17 14:33:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-17 14:33:36 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-17 14:33:36 --> Final output sent to browser
DEBUG - 2016-09-17 14:33:36 --> Total execution time: 2.4815
DEBUG - 2016-09-17 14:33:39 --> Config Class Initialized
DEBUG - 2016-09-17 14:33:39 --> Hooks Class Initialized
DEBUG - 2016-09-17 14:33:39 --> Utf8 Class Initialized
DEBUG - 2016-09-17 14:33:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-17 14:33:39 --> URI Class Initialized
DEBUG - 2016-09-17 14:33:39 --> Router Class Initialized
DEBUG - 2016-09-17 14:33:39 --> Output Class Initialized
DEBUG - 2016-09-17 14:33:39 --> Cache file has expired. File deleted
DEBUG - 2016-09-17 14:33:39 --> Security Class Initialized
DEBUG - 2016-09-17 14:33:39 --> Input Class Initialized
DEBUG - 2016-09-17 14:33:39 --> XSS Filtering completed
DEBUG - 2016-09-17 14:33:39 --> XSS Filtering completed
DEBUG - 2016-09-17 14:33:39 --> XSS Filtering completed
DEBUG - 2016-09-17 14:33:39 --> XSS Filtering completed
DEBUG - 2016-09-17 14:33:39 --> XSS Filtering completed
DEBUG - 2016-09-17 14:33:39 --> XSS Filtering completed
DEBUG - 2016-09-17 14:33:39 --> XSS Filtering completed
DEBUG - 2016-09-17 14:33:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-17 14:33:39 --> Language Class Initialized
DEBUG - 2016-09-17 14:33:39 --> Loader Class Initialized
DEBUG - 2016-09-17 14:33:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-17 14:33:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-17 14:33:39 --> Helper loaded: url_helper
DEBUG - 2016-09-17 14:33:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-17 14:33:39 --> Helper loaded: file_helper
DEBUG - 2016-09-17 14:33:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-17 14:33:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-17 14:33:39 --> Helper loaded: conf_helper
DEBUG - 2016-09-17 14:33:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-17 14:33:39 --> Check Exists common_helper.php: No
DEBUG - 2016-09-17 14:33:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-17 14:33:39 --> Helper loaded: common_helper
DEBUG - 2016-09-17 14:33:39 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-17 14:33:39 --> Helper loaded: common_helper
DEBUG - 2016-09-17 14:33:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-17 14:33:39 --> Helper loaded: form_helper
DEBUG - 2016-09-17 14:33:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-17 14:33:39 --> Helper loaded: security_helper
DEBUG - 2016-09-17 14:33:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-17 14:33:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-17 14:33:39 --> Helper loaded: lang_helper
DEBUG - 2016-09-17 14:33:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-17 14:33:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-17 14:33:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-17 14:33:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-17 14:33:39 --> Helper loaded: atlant_helper
DEBUG - 2016-09-17 14:33:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-17 14:33:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-17 14:33:39 --> Helper loaded: crypto_helper
DEBUG - 2016-09-17 14:33:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-17 14:33:39 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-17 14:33:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-17 14:33:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-17 14:33:39 --> Helper loaded: sidika_helper
DEBUG - 2016-09-17 14:33:39 --> Database Driver Class Initialized
DEBUG - 2016-09-17 14:33:39 --> Session Class Initialized
DEBUG - 2016-09-17 14:33:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-17 14:33:39 --> Helper loaded: string_helper
DEBUG - 2016-09-17 14:33:39 --> Session routines successfully run
DEBUG - 2016-09-17 14:33:39 --> Native_session Class Initialized
DEBUG - 2016-09-17 14:33:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-17 14:33:39 --> Form Validation Class Initialized
DEBUG - 2016-09-17 14:33:39 --> Form Validation Class Initialized
DEBUG - 2016-09-17 14:33:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-17 14:33:39 --> Controller Class Initialized
DEBUG - 2016-09-17 14:33:39 --> Carabiner: Library initialized.
DEBUG - 2016-09-17 14:33:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-17 14:33:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-17 14:33:39 --> Carabiner: library configured.
DEBUG - 2016-09-17 14:33:39 --> Carabiner: library configured.
DEBUG - 2016-09-17 14:33:39 --> User Agent Class Initialized
DEBUG - 2016-09-17 14:33:39 --> Model Class Initialized
DEBUG - 2016-09-17 14:33:39 --> Model Class Initialized
DEBUG - 2016-09-17 14:33:39 --> Model Class Initialized
DEBUG - 2016-09-17 14:33:39 --> Model Class Initialized
DEBUG - 2016-09-17 14:33:39 --> Model Class Initialized
DEBUG - 2016-09-17 14:33:39 --> Model Class Initialized
DEBUG - 2016-09-17 14:33:40 --> Model Class Initialized
DEBUG - 2016-09-17 14:33:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-17 14:33:40 --> Final output sent to browser
DEBUG - 2016-09-17 14:33:40 --> Total execution time: 0.8829
DEBUG - 2016-09-17 14:34:09 --> Config Class Initialized
DEBUG - 2016-09-17 14:34:09 --> Hooks Class Initialized
DEBUG - 2016-09-17 14:34:09 --> Utf8 Class Initialized
DEBUG - 2016-09-17 14:34:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-17 14:34:09 --> URI Class Initialized
DEBUG - 2016-09-17 14:34:09 --> Router Class Initialized
DEBUG - 2016-09-17 14:34:09 --> Output Class Initialized
DEBUG - 2016-09-17 14:34:09 --> Security Class Initialized
DEBUG - 2016-09-17 14:34:09 --> Input Class Initialized
DEBUG - 2016-09-17 14:34:09 --> XSS Filtering completed
DEBUG - 2016-09-17 14:34:09 --> XSS Filtering completed
DEBUG - 2016-09-17 14:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-17 14:34:09 --> Language Class Initialized
DEBUG - 2016-09-17 14:34:09 --> Loader Class Initialized
DEBUG - 2016-09-17 14:34:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-17 14:34:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-17 14:34:09 --> Helper loaded: url_helper
DEBUG - 2016-09-17 14:34:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-17 14:34:09 --> Helper loaded: file_helper
DEBUG - 2016-09-17 14:34:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-17 14:34:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-17 14:34:09 --> Helper loaded: conf_helper
DEBUG - 2016-09-17 14:34:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-17 14:34:09 --> Check Exists common_helper.php: No
DEBUG - 2016-09-17 14:34:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-17 14:34:09 --> Helper loaded: common_helper
DEBUG - 2016-09-17 14:34:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-17 14:34:09 --> Helper loaded: common_helper
DEBUG - 2016-09-17 14:34:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-17 14:34:09 --> Helper loaded: form_helper
DEBUG - 2016-09-17 14:34:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-17 14:34:09 --> Helper loaded: security_helper
DEBUG - 2016-09-17 14:34:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-17 14:34:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-17 14:34:09 --> Helper loaded: lang_helper
DEBUG - 2016-09-17 14:34:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-17 14:34:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-17 14:34:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-17 14:34:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-17 14:34:09 --> Helper loaded: atlant_helper
DEBUG - 2016-09-17 14:34:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-17 14:34:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-17 14:34:09 --> Helper loaded: crypto_helper
DEBUG - 2016-09-17 14:34:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-17 14:34:09 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-17 14:34:09 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-17 14:34:09 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-17 14:34:09 --> Helper loaded: sidika_helper
DEBUG - 2016-09-17 14:34:09 --> Database Driver Class Initialized
DEBUG - 2016-09-17 14:34:09 --> Session Class Initialized
DEBUG - 2016-09-17 14:34:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-17 14:34:09 --> Helper loaded: string_helper
DEBUG - 2016-09-17 14:34:09 --> Session routines successfully run
DEBUG - 2016-09-17 14:34:09 --> Native_session Class Initialized
DEBUG - 2016-09-17 14:34:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-17 14:34:09 --> Form Validation Class Initialized
DEBUG - 2016-09-17 14:34:09 --> Form Validation Class Initialized
DEBUG - 2016-09-17 14:34:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-17 14:34:09 --> Controller Class Initialized
DEBUG - 2016-09-17 14:34:09 --> Carabiner: Library initialized.
DEBUG - 2016-09-17 14:34:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-17 14:34:09 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-17 14:34:09 --> Carabiner: library configured.
DEBUG - 2016-09-17 14:34:09 --> Carabiner: library configured.
DEBUG - 2016-09-17 14:34:09 --> User Agent Class Initialized
DEBUG - 2016-09-17 14:34:09 --> Model Class Initialized
DEBUG - 2016-09-17 14:34:09 --> Model Class Initialized
DEBUG - 2016-09-17 14:34:09 --> Model Class Initialized
DEBUG - 2016-09-17 14:34:09 --> Model Class Initialized
DEBUG - 2016-09-17 14:34:09 --> Model Class Initialized
DEBUG - 2016-09-17 14:34:09 --> Model Class Initialized
DEBUG - 2016-09-17 14:34:09 --> Model Class Initialized
ERROR - 2016-09-17 14:34:09 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
