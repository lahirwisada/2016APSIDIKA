<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-09-19 00:23:43 --> Config Class Initialized
DEBUG - 2016-09-19 00:23:43 --> Hooks Class Initialized
DEBUG - 2016-09-19 00:23:43 --> Utf8 Class Initialized
DEBUG - 2016-09-19 00:23:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 00:23:43 --> URI Class Initialized
DEBUG - 2016-09-19 00:23:43 --> Router Class Initialized
DEBUG - 2016-09-19 00:23:43 --> No URI present. Default controller set.
DEBUG - 2016-09-19 00:23:43 --> Output Class Initialized
DEBUG - 2016-09-19 00:23:43 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 00:23:43 --> Security Class Initialized
DEBUG - 2016-09-19 00:23:43 --> Input Class Initialized
DEBUG - 2016-09-19 00:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 00:23:43 --> Language Class Initialized
DEBUG - 2016-09-19 00:23:43 --> Loader Class Initialized
DEBUG - 2016-09-19 00:23:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 00:23:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 00:23:43 --> Helper loaded: url_helper
DEBUG - 2016-09-19 00:23:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 00:23:43 --> Helper loaded: file_helper
DEBUG - 2016-09-19 00:23:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 00:23:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 00:23:43 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 00:23:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 00:23:43 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 00:23:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 00:23:43 --> Helper loaded: common_helper
DEBUG - 2016-09-19 00:23:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 00:23:43 --> Helper loaded: common_helper
DEBUG - 2016-09-19 00:23:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 00:23:44 --> Helper loaded: form_helper
DEBUG - 2016-09-19 00:23:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 00:23:44 --> Helper loaded: security_helper
DEBUG - 2016-09-19 00:23:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 00:23:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 00:23:44 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 00:23:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 00:23:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 00:23:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 00:23:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 00:23:44 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 00:23:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 00:23:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 00:23:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 00:23:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 00:23:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 00:23:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 00:23:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 00:23:44 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 00:23:44 --> Database Driver Class Initialized
DEBUG - 2016-09-19 00:23:44 --> Session Class Initialized
DEBUG - 2016-09-19 00:23:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 00:23:44 --> Helper loaded: string_helper
DEBUG - 2016-09-19 00:23:44 --> A session cookie was not found.
DEBUG - 2016-09-19 00:23:44 --> Session routines successfully run
DEBUG - 2016-09-19 00:23:44 --> Native_session Class Initialized
DEBUG - 2016-09-19 00:23:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 00:23:44 --> Form Validation Class Initialized
DEBUG - 2016-09-19 00:23:44 --> Form Validation Class Initialized
DEBUG - 2016-09-19 00:23:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 00:23:44 --> Controller Class Initialized
DEBUG - 2016-09-19 00:23:44 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 00:23:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 00:23:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 00:23:44 --> Carabiner: library configured.
DEBUG - 2016-09-19 00:23:44 --> Carabiner: library configured.
DEBUG - 2016-09-19 00:23:44 --> User Agent Class Initialized
DEBUG - 2016-09-19 00:23:44 --> Model Class Initialized
DEBUG - 2016-09-19 00:23:44 --> Model Class Initialized
DEBUG - 2016-09-19 00:23:44 --> Model Class Initialized
ERROR - 2016-09-19 00:23:44 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 00:23:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-19 00:23:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-19 00:23:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 00:23:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 00:23:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 00:23:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 00:23:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 00:23:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 00:23:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 00:23:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 00:23:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 00:23:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 00:23:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 00:23:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 00:23:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 00:23:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 00:23:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 00:23:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 00:23:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 00:23:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 00:23:44 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-19 00:23:44 --> Final output sent to browser
DEBUG - 2016-09-19 00:23:44 --> Total execution time: 0.8364
DEBUG - 2016-09-19 00:23:48 --> Config Class Initialized
DEBUG - 2016-09-19 00:23:48 --> Hooks Class Initialized
DEBUG - 2016-09-19 00:23:48 --> Utf8 Class Initialized
DEBUG - 2016-09-19 00:23:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 00:23:48 --> URI Class Initialized
DEBUG - 2016-09-19 00:23:48 --> Router Class Initialized
DEBUG - 2016-09-19 00:23:48 --> Output Class Initialized
DEBUG - 2016-09-19 00:23:48 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 00:23:48 --> Security Class Initialized
DEBUG - 2016-09-19 00:23:48 --> Input Class Initialized
DEBUG - 2016-09-19 00:23:48 --> XSS Filtering completed
DEBUG - 2016-09-19 00:23:48 --> XSS Filtering completed
DEBUG - 2016-09-19 00:23:48 --> XSS Filtering completed
DEBUG - 2016-09-19 00:23:48 --> XSS Filtering completed
DEBUG - 2016-09-19 00:23:48 --> XSS Filtering completed
DEBUG - 2016-09-19 00:23:48 --> XSS Filtering completed
DEBUG - 2016-09-19 00:23:48 --> XSS Filtering completed
DEBUG - 2016-09-19 00:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 00:23:48 --> Language Class Initialized
DEBUG - 2016-09-19 00:23:48 --> Loader Class Initialized
DEBUG - 2016-09-19 00:23:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 00:23:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 00:23:48 --> Helper loaded: url_helper
DEBUG - 2016-09-19 00:23:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 00:23:48 --> Helper loaded: file_helper
DEBUG - 2016-09-19 00:23:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 00:23:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 00:23:48 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 00:23:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 00:23:48 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 00:23:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 00:23:48 --> Helper loaded: common_helper
DEBUG - 2016-09-19 00:23:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 00:23:48 --> Helper loaded: common_helper
DEBUG - 2016-09-19 00:23:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 00:23:48 --> Helper loaded: form_helper
DEBUG - 2016-09-19 00:23:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 00:23:48 --> Helper loaded: security_helper
DEBUG - 2016-09-19 00:23:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 00:23:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 00:23:48 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 00:23:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 00:23:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 00:23:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 00:23:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 00:23:48 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 00:23:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 00:23:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 00:23:48 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 00:23:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 00:23:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 00:23:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 00:23:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 00:23:48 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 00:23:48 --> Database Driver Class Initialized
DEBUG - 2016-09-19 00:23:48 --> Session Class Initialized
DEBUG - 2016-09-19 00:23:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 00:23:48 --> Helper loaded: string_helper
DEBUG - 2016-09-19 00:23:48 --> Session routines successfully run
DEBUG - 2016-09-19 00:23:48 --> Native_session Class Initialized
DEBUG - 2016-09-19 00:23:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 00:23:48 --> Form Validation Class Initialized
DEBUG - 2016-09-19 00:23:48 --> Form Validation Class Initialized
DEBUG - 2016-09-19 00:23:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 00:23:48 --> Controller Class Initialized
DEBUG - 2016-09-19 00:23:48 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 00:23:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 00:23:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 00:23:48 --> Carabiner: library configured.
DEBUG - 2016-09-19 00:23:48 --> Carabiner: library configured.
DEBUG - 2016-09-19 00:23:48 --> User Agent Class Initialized
DEBUG - 2016-09-19 00:23:48 --> Model Class Initialized
DEBUG - 2016-09-19 00:23:48 --> Model Class Initialized
DEBUG - 2016-09-19 00:23:48 --> Model Class Initialized
DEBUG - 2016-09-19 00:23:48 --> Model Class Initialized
DEBUG - 2016-09-19 00:23:48 --> Model Class Initialized
DEBUG - 2016-09-19 00:23:48 --> Model Class Initialized
DEBUG - 2016-09-19 00:23:48 --> Model Class Initialized
DEBUG - 2016-09-19 00:23:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-19 00:23:48 --> Final output sent to browser
DEBUG - 2016-09-19 00:23:48 --> Total execution time: 0.3364
DEBUG - 2016-09-19 08:17:56 --> Config Class Initialized
DEBUG - 2016-09-19 08:17:56 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:17:56 --> Utf8 Class Initialized
DEBUG - 2016-09-19 08:17:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 08:17:56 --> URI Class Initialized
DEBUG - 2016-09-19 08:17:56 --> Router Class Initialized
DEBUG - 2016-09-19 08:17:56 --> No URI present. Default controller set.
DEBUG - 2016-09-19 08:17:56 --> Output Class Initialized
DEBUG - 2016-09-19 08:17:56 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 08:17:56 --> Security Class Initialized
DEBUG - 2016-09-19 08:17:56 --> Input Class Initialized
DEBUG - 2016-09-19 08:17:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 08:17:56 --> Language Class Initialized
DEBUG - 2016-09-19 08:17:56 --> Loader Class Initialized
DEBUG - 2016-09-19 08:17:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 08:17:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 08:17:56 --> Helper loaded: url_helper
DEBUG - 2016-09-19 08:17:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 08:17:56 --> Helper loaded: file_helper
DEBUG - 2016-09-19 08:17:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 08:17:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 08:17:56 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 08:17:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 08:17:56 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 08:17:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 08:17:56 --> Helper loaded: common_helper
DEBUG - 2016-09-19 08:17:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 08:17:56 --> Helper loaded: common_helper
DEBUG - 2016-09-19 08:17:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 08:17:56 --> Helper loaded: form_helper
DEBUG - 2016-09-19 08:17:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 08:17:56 --> Helper loaded: security_helper
DEBUG - 2016-09-19 08:17:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 08:17:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 08:17:56 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 08:17:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 08:17:56 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 08:17:56 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 08:17:56 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 08:17:56 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 08:17:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 08:17:56 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 08:17:56 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 08:17:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 08:17:56 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 08:17:56 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 08:17:56 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 08:17:56 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 08:17:56 --> Database Driver Class Initialized
DEBUG - 2016-09-19 08:17:56 --> Session Class Initialized
DEBUG - 2016-09-19 08:17:56 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 08:17:56 --> Helper loaded: string_helper
DEBUG - 2016-09-19 08:17:56 --> A session cookie was not found.
DEBUG - 2016-09-19 08:17:56 --> Session routines successfully run
DEBUG - 2016-09-19 08:17:56 --> Native_session Class Initialized
DEBUG - 2016-09-19 08:17:56 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 08:17:56 --> Form Validation Class Initialized
DEBUG - 2016-09-19 08:17:56 --> Form Validation Class Initialized
DEBUG - 2016-09-19 08:17:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 08:17:56 --> Controller Class Initialized
DEBUG - 2016-09-19 08:17:56 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 08:17:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 08:17:56 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 08:17:56 --> Carabiner: library configured.
DEBUG - 2016-09-19 08:17:56 --> Carabiner: library configured.
DEBUG - 2016-09-19 08:17:56 --> User Agent Class Initialized
DEBUG - 2016-09-19 08:17:56 --> Model Class Initialized
DEBUG - 2016-09-19 08:17:56 --> Model Class Initialized
DEBUG - 2016-09-19 08:17:56 --> Model Class Initialized
ERROR - 2016-09-19 08:17:56 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 08:17:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-19 08:17:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-19 08:17:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 08:17:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 08:17:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 08:17:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 08:17:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 08:17:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 08:17:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 08:17:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 08:17:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 08:17:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 08:17:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 08:17:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 08:17:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 08:17:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 08:17:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 08:17:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 08:17:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 08:17:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 08:17:56 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-19 08:17:56 --> Final output sent to browser
DEBUG - 2016-09-19 08:17:56 --> Total execution time: 0.1964
DEBUG - 2016-09-19 08:18:00 --> Config Class Initialized
DEBUG - 2016-09-19 08:18:00 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:18:00 --> Utf8 Class Initialized
DEBUG - 2016-09-19 08:18:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 08:18:00 --> URI Class Initialized
DEBUG - 2016-09-19 08:18:00 --> Router Class Initialized
DEBUG - 2016-09-19 08:18:00 --> Output Class Initialized
DEBUG - 2016-09-19 08:18:00 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 08:18:00 --> Security Class Initialized
DEBUG - 2016-09-19 08:18:00 --> Input Class Initialized
DEBUG - 2016-09-19 08:18:00 --> XSS Filtering completed
DEBUG - 2016-09-19 08:18:00 --> XSS Filtering completed
DEBUG - 2016-09-19 08:18:00 --> XSS Filtering completed
DEBUG - 2016-09-19 08:18:00 --> XSS Filtering completed
DEBUG - 2016-09-19 08:18:00 --> XSS Filtering completed
DEBUG - 2016-09-19 08:18:00 --> XSS Filtering completed
DEBUG - 2016-09-19 08:18:00 --> XSS Filtering completed
DEBUG - 2016-09-19 08:18:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 08:18:00 --> Language Class Initialized
DEBUG - 2016-09-19 08:18:00 --> Loader Class Initialized
DEBUG - 2016-09-19 08:18:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 08:18:00 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 08:18:00 --> Helper loaded: url_helper
DEBUG - 2016-09-19 08:18:00 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 08:18:00 --> Helper loaded: file_helper
DEBUG - 2016-09-19 08:18:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 08:18:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 08:18:00 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 08:18:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 08:18:00 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 08:18:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 08:18:00 --> Helper loaded: common_helper
DEBUG - 2016-09-19 08:18:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 08:18:00 --> Helper loaded: common_helper
DEBUG - 2016-09-19 08:18:00 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 08:18:00 --> Helper loaded: form_helper
DEBUG - 2016-09-19 08:18:00 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 08:18:00 --> Helper loaded: security_helper
DEBUG - 2016-09-19 08:18:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 08:18:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 08:18:00 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 08:18:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 08:18:00 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 08:18:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 08:18:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 08:18:00 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 08:18:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 08:18:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 08:18:00 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 08:18:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 08:18:00 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 08:18:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 08:18:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 08:18:00 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 08:18:00 --> Database Driver Class Initialized
DEBUG - 2016-09-19 08:18:00 --> Session Class Initialized
DEBUG - 2016-09-19 08:18:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 08:18:00 --> Helper loaded: string_helper
DEBUG - 2016-09-19 08:18:00 --> Session routines successfully run
DEBUG - 2016-09-19 08:18:00 --> Native_session Class Initialized
DEBUG - 2016-09-19 08:18:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 08:18:00 --> Form Validation Class Initialized
DEBUG - 2016-09-19 08:18:00 --> Form Validation Class Initialized
DEBUG - 2016-09-19 08:18:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 08:18:00 --> Controller Class Initialized
DEBUG - 2016-09-19 08:18:00 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 08:18:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 08:18:00 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 08:18:00 --> Carabiner: library configured.
DEBUG - 2016-09-19 08:18:00 --> Carabiner: library configured.
DEBUG - 2016-09-19 08:18:00 --> User Agent Class Initialized
DEBUG - 2016-09-19 08:18:00 --> Model Class Initialized
DEBUG - 2016-09-19 08:18:00 --> Model Class Initialized
DEBUG - 2016-09-19 08:18:00 --> Model Class Initialized
DEBUG - 2016-09-19 08:18:00 --> Model Class Initialized
DEBUG - 2016-09-19 08:18:00 --> Model Class Initialized
DEBUG - 2016-09-19 08:18:00 --> Model Class Initialized
DEBUG - 2016-09-19 08:18:00 --> Model Class Initialized
DEBUG - 2016-09-19 08:18:00 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-19 08:18:00 --> Final output sent to browser
DEBUG - 2016-09-19 08:18:00 --> Total execution time: 0.2702
DEBUG - 2016-09-19 08:18:03 --> Config Class Initialized
DEBUG - 2016-09-19 08:18:03 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:18:03 --> Utf8 Class Initialized
DEBUG - 2016-09-19 08:18:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 08:18:03 --> URI Class Initialized
DEBUG - 2016-09-19 08:18:03 --> Router Class Initialized
DEBUG - 2016-09-19 08:18:03 --> Output Class Initialized
DEBUG - 2016-09-19 08:18:03 --> Security Class Initialized
DEBUG - 2016-09-19 08:18:03 --> Input Class Initialized
DEBUG - 2016-09-19 08:18:03 --> XSS Filtering completed
DEBUG - 2016-09-19 08:18:03 --> XSS Filtering completed
DEBUG - 2016-09-19 08:18:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 08:18:03 --> Language Class Initialized
DEBUG - 2016-09-19 08:18:03 --> Loader Class Initialized
DEBUG - 2016-09-19 08:18:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 08:18:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 08:18:03 --> Helper loaded: url_helper
DEBUG - 2016-09-19 08:18:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 08:18:03 --> Helper loaded: file_helper
DEBUG - 2016-09-19 08:18:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 08:18:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 08:18:03 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 08:18:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 08:18:03 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 08:18:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 08:18:03 --> Helper loaded: common_helper
DEBUG - 2016-09-19 08:18:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 08:18:03 --> Helper loaded: common_helper
DEBUG - 2016-09-19 08:18:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 08:18:03 --> Helper loaded: form_helper
DEBUG - 2016-09-19 08:18:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 08:18:03 --> Helper loaded: security_helper
DEBUG - 2016-09-19 08:18:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 08:18:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 08:18:03 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 08:18:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 08:18:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 08:18:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 08:18:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 08:18:03 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 08:18:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 08:18:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 08:18:03 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 08:18:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 08:18:03 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 08:18:03 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 08:18:03 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 08:18:03 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 08:18:03 --> Database Driver Class Initialized
DEBUG - 2016-09-19 08:18:03 --> Session Class Initialized
DEBUG - 2016-09-19 08:18:03 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 08:18:03 --> Helper loaded: string_helper
DEBUG - 2016-09-19 08:18:03 --> Session routines successfully run
DEBUG - 2016-09-19 08:18:03 --> Native_session Class Initialized
DEBUG - 2016-09-19 08:18:03 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 08:18:03 --> Form Validation Class Initialized
DEBUG - 2016-09-19 08:18:03 --> Form Validation Class Initialized
DEBUG - 2016-09-19 08:18:03 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 08:18:03 --> Controller Class Initialized
DEBUG - 2016-09-19 08:18:03 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 08:18:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 08:18:03 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 08:18:03 --> Carabiner: library configured.
DEBUG - 2016-09-19 08:18:03 --> Carabiner: library configured.
DEBUG - 2016-09-19 08:18:03 --> User Agent Class Initialized
DEBUG - 2016-09-19 08:18:03 --> Model Class Initialized
DEBUG - 2016-09-19 08:18:03 --> Model Class Initialized
DEBUG - 2016-09-19 08:18:03 --> Model Class Initialized
DEBUG - 2016-09-19 08:18:03 --> Model Class Initialized
DEBUG - 2016-09-19 08:18:03 --> Model Class Initialized
DEBUG - 2016-09-19 08:18:03 --> Model Class Initialized
DEBUG - 2016-09-19 08:18:03 --> Model Class Initialized
DEBUG - 2016-09-19 08:18:03 --> Model Class Initialized
ERROR - 2016-09-19 08:18:03 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 08:18:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-19 08:18:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 08:18:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 08:18:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 08:18:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 08:18:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 08:18:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 08:18:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 08:18:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 08:18:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 08:18:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 08:18:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 08:18:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 08:18:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 08:18:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 08:18:03 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/26764e7c38cfdb071ebc36690ecd8747
DEBUG - 2016-09-19 08:18:03 --> Final output sent to browser
DEBUG - 2016-09-19 08:18:03 --> Total execution time: 0.2795
DEBUG - 2016-09-19 08:43:58 --> Config Class Initialized
DEBUG - 2016-09-19 08:43:58 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:43:58 --> Utf8 Class Initialized
DEBUG - 2016-09-19 08:43:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 08:43:58 --> URI Class Initialized
DEBUG - 2016-09-19 08:43:58 --> Router Class Initialized
DEBUG - 2016-09-19 08:43:58 --> Output Class Initialized
DEBUG - 2016-09-19 08:43:58 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 08:43:58 --> Security Class Initialized
DEBUG - 2016-09-19 08:43:58 --> Input Class Initialized
DEBUG - 2016-09-19 08:43:58 --> XSS Filtering completed
DEBUG - 2016-09-19 08:43:58 --> XSS Filtering completed
DEBUG - 2016-09-19 08:43:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 08:43:58 --> Language Class Initialized
DEBUG - 2016-09-19 08:43:58 --> Loader Class Initialized
DEBUG - 2016-09-19 08:43:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 08:43:58 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 08:43:58 --> Helper loaded: url_helper
DEBUG - 2016-09-19 08:43:58 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 08:43:58 --> Helper loaded: file_helper
DEBUG - 2016-09-19 08:43:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 08:43:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 08:43:58 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 08:43:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 08:43:58 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 08:43:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 08:43:58 --> Helper loaded: common_helper
DEBUG - 2016-09-19 08:43:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 08:43:58 --> Helper loaded: common_helper
DEBUG - 2016-09-19 08:43:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 08:43:58 --> Helper loaded: form_helper
DEBUG - 2016-09-19 08:43:58 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 08:43:58 --> Helper loaded: security_helper
DEBUG - 2016-09-19 08:43:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 08:43:58 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 08:43:58 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 08:43:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 08:43:58 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 08:43:58 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 08:43:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 08:43:58 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 08:43:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 08:43:58 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 08:43:58 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 08:43:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 08:43:58 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 08:43:58 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 08:43:58 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 08:43:58 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 08:43:58 --> Database Driver Class Initialized
DEBUG - 2016-09-19 08:43:58 --> Session Class Initialized
DEBUG - 2016-09-19 08:43:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 08:43:58 --> Helper loaded: string_helper
DEBUG - 2016-09-19 08:43:59 --> Session routines successfully run
DEBUG - 2016-09-19 08:43:59 --> Native_session Class Initialized
DEBUG - 2016-09-19 08:43:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 08:43:59 --> Form Validation Class Initialized
DEBUG - 2016-09-19 08:43:59 --> Form Validation Class Initialized
DEBUG - 2016-09-19 08:43:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 08:43:59 --> Controller Class Initialized
DEBUG - 2016-09-19 08:43:59 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 08:43:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 08:43:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 08:43:59 --> Carabiner: library configured.
DEBUG - 2016-09-19 08:43:59 --> Carabiner: library configured.
DEBUG - 2016-09-19 08:43:59 --> User Agent Class Initialized
DEBUG - 2016-09-19 08:43:59 --> Model Class Initialized
DEBUG - 2016-09-19 08:43:59 --> Model Class Initialized
DEBUG - 2016-09-19 08:43:59 --> Model Class Initialized
DEBUG - 2016-09-19 08:43:59 --> Model Class Initialized
DEBUG - 2016-09-19 08:43:59 --> Model Class Initialized
DEBUG - 2016-09-19 08:43:59 --> Model Class Initialized
DEBUG - 2016-09-19 08:43:59 --> Model Class Initialized
DEBUG - 2016-09-19 08:43:59 --> Model Class Initialized
ERROR - 2016-09-19 08:43:59 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 08:43:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-19 08:43:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 08:43:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 08:43:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 08:43:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 08:43:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 08:43:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 08:43:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 08:43:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 08:43:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 08:43:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 08:43:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 08:43:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 08:43:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 08:43:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 08:43:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/26764e7c38cfdb071ebc36690ecd8747
DEBUG - 2016-09-19 08:43:59 --> Final output sent to browser
DEBUG - 2016-09-19 08:43:59 --> Total execution time: 0.3009
DEBUG - 2016-09-19 08:44:03 --> Config Class Initialized
DEBUG - 2016-09-19 08:44:03 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:44:03 --> Utf8 Class Initialized
DEBUG - 2016-09-19 08:44:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 08:44:03 --> URI Class Initialized
DEBUG - 2016-09-19 08:44:03 --> Router Class Initialized
DEBUG - 2016-09-19 08:44:03 --> Output Class Initialized
DEBUG - 2016-09-19 08:44:03 --> Security Class Initialized
DEBUG - 2016-09-19 08:44:03 --> Input Class Initialized
DEBUG - 2016-09-19 08:44:03 --> XSS Filtering completed
DEBUG - 2016-09-19 08:44:03 --> XSS Filtering completed
DEBUG - 2016-09-19 08:44:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 08:44:03 --> Language Class Initialized
DEBUG - 2016-09-19 08:44:03 --> Loader Class Initialized
DEBUG - 2016-09-19 08:44:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 08:44:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 08:44:03 --> Helper loaded: url_helper
DEBUG - 2016-09-19 08:44:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 08:44:03 --> Helper loaded: file_helper
DEBUG - 2016-09-19 08:44:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 08:44:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 08:44:03 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 08:44:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 08:44:03 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 08:44:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 08:44:03 --> Helper loaded: common_helper
DEBUG - 2016-09-19 08:44:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 08:44:03 --> Helper loaded: common_helper
DEBUG - 2016-09-19 08:44:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 08:44:03 --> Helper loaded: form_helper
DEBUG - 2016-09-19 08:44:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 08:44:03 --> Helper loaded: security_helper
DEBUG - 2016-09-19 08:44:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 08:44:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 08:44:03 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 08:44:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 08:44:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 08:44:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 08:44:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 08:44:03 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 08:44:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 08:44:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 08:44:04 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 08:44:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 08:44:04 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 08:44:04 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 08:44:04 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 08:44:04 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 08:44:04 --> Database Driver Class Initialized
DEBUG - 2016-09-19 08:44:04 --> Session Class Initialized
DEBUG - 2016-09-19 08:44:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 08:44:04 --> Helper loaded: string_helper
DEBUG - 2016-09-19 08:44:04 --> Session routines successfully run
DEBUG - 2016-09-19 08:44:04 --> Native_session Class Initialized
DEBUG - 2016-09-19 08:44:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 08:44:04 --> Form Validation Class Initialized
DEBUG - 2016-09-19 08:44:04 --> Form Validation Class Initialized
DEBUG - 2016-09-19 08:44:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 08:44:04 --> Controller Class Initialized
DEBUG - 2016-09-19 08:44:04 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 08:44:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 08:44:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 08:44:04 --> Carabiner: library configured.
DEBUG - 2016-09-19 08:44:04 --> Carabiner: library configured.
DEBUG - 2016-09-19 08:44:04 --> User Agent Class Initialized
DEBUG - 2016-09-19 08:44:04 --> Model Class Initialized
DEBUG - 2016-09-19 08:44:04 --> Model Class Initialized
DEBUG - 2016-09-19 08:44:04 --> Model Class Initialized
DEBUG - 2016-09-19 08:44:04 --> Model Class Initialized
DEBUG - 2016-09-19 08:44:04 --> Model Class Initialized
DEBUG - 2016-09-19 08:44:04 --> Model Class Initialized
DEBUG - 2016-09-19 08:44:04 --> Model Class Initialized
DEBUG - 2016-09-19 08:44:04 --> Model Class Initialized
ERROR - 2016-09-19 08:44:04 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 08:44:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-19 08:44:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 08:44:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 08:44:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 08:44:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 08:44:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 08:44:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 08:44:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 08:44:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 08:44:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 08:44:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 08:44:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 08:44:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 08:44:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 08:44:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 08:44:04 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5f27c12046bed01bb5321ca8e8c8afc2
DEBUG - 2016-09-19 08:44:04 --> Final output sent to browser
DEBUG - 2016-09-19 08:44:04 --> Total execution time: 0.3051
DEBUG - 2016-09-19 08:44:07 --> Config Class Initialized
DEBUG - 2016-09-19 08:44:07 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:44:07 --> Utf8 Class Initialized
DEBUG - 2016-09-19 08:44:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 08:44:07 --> URI Class Initialized
DEBUG - 2016-09-19 08:44:07 --> Router Class Initialized
DEBUG - 2016-09-19 08:44:07 --> No URI present. Default controller set.
DEBUG - 2016-09-19 08:44:07 --> Output Class Initialized
DEBUG - 2016-09-19 08:44:07 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 08:44:07 --> Security Class Initialized
DEBUG - 2016-09-19 08:44:07 --> Input Class Initialized
DEBUG - 2016-09-19 08:44:07 --> XSS Filtering completed
DEBUG - 2016-09-19 08:44:07 --> XSS Filtering completed
DEBUG - 2016-09-19 08:44:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 08:44:07 --> Language Class Initialized
DEBUG - 2016-09-19 08:44:07 --> Loader Class Initialized
DEBUG - 2016-09-19 08:44:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 08:44:07 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 08:44:07 --> Helper loaded: url_helper
DEBUG - 2016-09-19 08:44:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 08:44:07 --> Helper loaded: file_helper
DEBUG - 2016-09-19 08:44:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 08:44:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 08:44:07 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 08:44:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 08:44:07 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 08:44:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 08:44:07 --> Helper loaded: common_helper
DEBUG - 2016-09-19 08:44:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 08:44:07 --> Helper loaded: common_helper
DEBUG - 2016-09-19 08:44:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 08:44:07 --> Helper loaded: form_helper
DEBUG - 2016-09-19 08:44:07 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 08:44:07 --> Helper loaded: security_helper
DEBUG - 2016-09-19 08:44:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 08:44:07 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 08:44:07 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 08:44:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 08:44:07 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 08:44:07 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 08:44:07 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 08:44:07 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 08:44:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 08:44:07 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 08:44:07 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 08:44:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 08:44:07 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 08:44:07 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 08:44:07 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 08:44:07 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 08:44:07 --> Database Driver Class Initialized
DEBUG - 2016-09-19 08:44:07 --> Session Class Initialized
DEBUG - 2016-09-19 08:44:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 08:44:07 --> Helper loaded: string_helper
DEBUG - 2016-09-19 08:44:07 --> Session routines successfully run
DEBUG - 2016-09-19 08:44:07 --> Native_session Class Initialized
DEBUG - 2016-09-19 08:44:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 08:44:07 --> Form Validation Class Initialized
DEBUG - 2016-09-19 08:44:07 --> Form Validation Class Initialized
DEBUG - 2016-09-19 08:44:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 08:44:07 --> Controller Class Initialized
DEBUG - 2016-09-19 08:44:07 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 08:44:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 08:44:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 08:44:07 --> Carabiner: library configured.
DEBUG - 2016-09-19 08:44:07 --> Carabiner: library configured.
DEBUG - 2016-09-19 08:44:07 --> User Agent Class Initialized
DEBUG - 2016-09-19 08:44:07 --> Model Class Initialized
DEBUG - 2016-09-19 08:44:07 --> Model Class Initialized
DEBUG - 2016-09-19 08:44:07 --> Model Class Initialized
ERROR - 2016-09-19 08:44:07 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 08:44:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-19 08:44:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-19 08:44:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 08:44:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 08:44:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 08:44:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 08:44:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 08:44:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 08:44:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 08:44:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 08:44:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 08:44:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 08:44:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 08:44:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 08:44:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 08:44:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 08:44:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 08:44:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 08:44:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 08:44:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 08:44:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-19 08:44:07 --> Final output sent to browser
DEBUG - 2016-09-19 08:44:07 --> Total execution time: 0.3092
DEBUG - 2016-09-19 08:44:07 --> Config Class Initialized
DEBUG - 2016-09-19 08:44:07 --> Hooks Class Initialized
DEBUG - 2016-09-19 08:44:07 --> Utf8 Class Initialized
DEBUG - 2016-09-19 08:44:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 08:44:07 --> URI Class Initialized
DEBUG - 2016-09-19 08:44:07 --> Router Class Initialized
DEBUG - 2016-09-19 08:44:07 --> Output Class Initialized
DEBUG - 2016-09-19 08:44:07 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 08:44:07 --> Security Class Initialized
DEBUG - 2016-09-19 08:44:07 --> Input Class Initialized
DEBUG - 2016-09-19 08:44:07 --> XSS Filtering completed
DEBUG - 2016-09-19 08:44:07 --> XSS Filtering completed
DEBUG - 2016-09-19 08:44:07 --> XSS Filtering completed
DEBUG - 2016-09-19 08:44:07 --> XSS Filtering completed
DEBUG - 2016-09-19 08:44:07 --> XSS Filtering completed
DEBUG - 2016-09-19 08:44:07 --> XSS Filtering completed
DEBUG - 2016-09-19 08:44:07 --> XSS Filtering completed
DEBUG - 2016-09-19 08:44:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 08:44:07 --> Language Class Initialized
DEBUG - 2016-09-19 08:44:07 --> Loader Class Initialized
DEBUG - 2016-09-19 08:44:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 08:44:07 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 08:44:07 --> Helper loaded: url_helper
DEBUG - 2016-09-19 08:44:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 08:44:07 --> Helper loaded: file_helper
DEBUG - 2016-09-19 08:44:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 08:44:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 08:44:07 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 08:44:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 08:44:07 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 08:44:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 08:44:07 --> Helper loaded: common_helper
DEBUG - 2016-09-19 08:44:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 08:44:07 --> Helper loaded: common_helper
DEBUG - 2016-09-19 08:44:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 08:44:07 --> Helper loaded: form_helper
DEBUG - 2016-09-19 08:44:07 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 08:44:07 --> Helper loaded: security_helper
DEBUG - 2016-09-19 08:44:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 08:44:07 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 08:44:07 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 08:44:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 08:44:07 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 08:44:07 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 08:44:07 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 08:44:07 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 08:44:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 08:44:07 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 08:44:07 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 08:44:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 08:44:07 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 08:44:07 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 08:44:07 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 08:44:07 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 08:44:07 --> Database Driver Class Initialized
DEBUG - 2016-09-19 08:44:07 --> Session Class Initialized
DEBUG - 2016-09-19 08:44:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 08:44:07 --> Helper loaded: string_helper
DEBUG - 2016-09-19 08:44:07 --> Session routines successfully run
DEBUG - 2016-09-19 08:44:07 --> Native_session Class Initialized
DEBUG - 2016-09-19 08:44:08 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 08:44:08 --> Form Validation Class Initialized
DEBUG - 2016-09-19 08:44:08 --> Form Validation Class Initialized
DEBUG - 2016-09-19 08:44:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 08:44:08 --> Controller Class Initialized
DEBUG - 2016-09-19 08:44:08 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 08:44:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 08:44:08 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 08:44:08 --> Carabiner: library configured.
DEBUG - 2016-09-19 08:44:08 --> Carabiner: library configured.
DEBUG - 2016-09-19 08:44:08 --> User Agent Class Initialized
DEBUG - 2016-09-19 08:44:08 --> Model Class Initialized
DEBUG - 2016-09-19 08:44:08 --> Model Class Initialized
DEBUG - 2016-09-19 08:44:08 --> Model Class Initialized
DEBUG - 2016-09-19 08:44:08 --> Model Class Initialized
DEBUG - 2016-09-19 08:44:08 --> Model Class Initialized
DEBUG - 2016-09-19 08:44:08 --> Model Class Initialized
DEBUG - 2016-09-19 08:44:08 --> Model Class Initialized
DEBUG - 2016-09-19 08:44:08 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-19 08:44:08 --> Final output sent to browser
DEBUG - 2016-09-19 08:44:08 --> Total execution time: 0.3450
DEBUG - 2016-09-19 10:20:25 --> Config Class Initialized
DEBUG - 2016-09-19 10:20:25 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:20:25 --> Utf8 Class Initialized
DEBUG - 2016-09-19 10:20:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 10:20:25 --> URI Class Initialized
DEBUG - 2016-09-19 10:20:25 --> Router Class Initialized
DEBUG - 2016-09-19 10:20:25 --> No URI present. Default controller set.
DEBUG - 2016-09-19 10:20:25 --> Output Class Initialized
DEBUG - 2016-09-19 10:20:25 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 10:20:25 --> Security Class Initialized
DEBUG - 2016-09-19 10:20:25 --> Input Class Initialized
DEBUG - 2016-09-19 10:20:25 --> XSS Filtering completed
DEBUG - 2016-09-19 10:20:25 --> XSS Filtering completed
DEBUG - 2016-09-19 10:20:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 10:20:25 --> Language Class Initialized
DEBUG - 2016-09-19 10:20:25 --> Loader Class Initialized
DEBUG - 2016-09-19 10:20:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 10:20:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 10:20:25 --> Helper loaded: url_helper
DEBUG - 2016-09-19 10:20:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 10:20:25 --> Helper loaded: file_helper
DEBUG - 2016-09-19 10:20:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 10:20:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 10:20:25 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 10:20:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 10:20:25 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 10:20:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 10:20:25 --> Helper loaded: common_helper
DEBUG - 2016-09-19 10:20:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 10:20:25 --> Helper loaded: common_helper
DEBUG - 2016-09-19 10:20:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 10:20:25 --> Helper loaded: form_helper
DEBUG - 2016-09-19 10:20:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 10:20:25 --> Helper loaded: security_helper
DEBUG - 2016-09-19 10:20:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 10:20:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 10:20:25 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 10:20:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 10:20:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 10:20:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 10:20:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 10:20:25 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 10:20:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 10:20:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 10:20:25 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 10:20:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 10:20:25 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 10:20:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 10:20:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 10:20:25 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 10:20:25 --> Database Driver Class Initialized
DEBUG - 2016-09-19 10:20:25 --> Session Class Initialized
DEBUG - 2016-09-19 10:20:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 10:20:25 --> Helper loaded: string_helper
DEBUG - 2016-09-19 10:20:25 --> Session routines successfully run
DEBUG - 2016-09-19 10:20:25 --> Native_session Class Initialized
DEBUG - 2016-09-19 10:20:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 10:20:25 --> Form Validation Class Initialized
DEBUG - 2016-09-19 10:20:25 --> Form Validation Class Initialized
DEBUG - 2016-09-19 10:20:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 10:20:25 --> Controller Class Initialized
DEBUG - 2016-09-19 10:20:25 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 10:20:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 10:20:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 10:20:25 --> Carabiner: library configured.
DEBUG - 2016-09-19 10:20:25 --> Carabiner: library configured.
DEBUG - 2016-09-19 10:20:25 --> User Agent Class Initialized
DEBUG - 2016-09-19 10:20:25 --> Model Class Initialized
DEBUG - 2016-09-19 10:20:25 --> Model Class Initialized
DEBUG - 2016-09-19 10:20:25 --> Model Class Initialized
ERROR - 2016-09-19 10:20:25 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 10:20:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-19 10:20:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-19 10:20:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 10:20:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 10:20:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 10:20:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 10:20:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 10:20:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 10:20:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 10:20:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 10:20:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 10:20:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 10:20:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 10:20:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 10:20:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 10:20:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 10:20:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 10:20:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 10:20:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 10:20:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 10:20:25 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-19 10:20:25 --> Final output sent to browser
DEBUG - 2016-09-19 10:20:25 --> Total execution time: 0.4038
DEBUG - 2016-09-19 10:20:26 --> Config Class Initialized
DEBUG - 2016-09-19 10:20:26 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:20:26 --> Utf8 Class Initialized
DEBUG - 2016-09-19 10:20:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 10:20:26 --> URI Class Initialized
DEBUG - 2016-09-19 10:20:26 --> Router Class Initialized
DEBUG - 2016-09-19 10:20:26 --> Output Class Initialized
DEBUG - 2016-09-19 10:20:26 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 10:20:26 --> Security Class Initialized
DEBUG - 2016-09-19 10:20:26 --> Input Class Initialized
DEBUG - 2016-09-19 10:20:26 --> XSS Filtering completed
DEBUG - 2016-09-19 10:20:26 --> XSS Filtering completed
DEBUG - 2016-09-19 10:20:26 --> XSS Filtering completed
DEBUG - 2016-09-19 10:20:26 --> XSS Filtering completed
DEBUG - 2016-09-19 10:20:26 --> XSS Filtering completed
DEBUG - 2016-09-19 10:20:26 --> XSS Filtering completed
DEBUG - 2016-09-19 10:20:26 --> XSS Filtering completed
DEBUG - 2016-09-19 10:20:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 10:20:26 --> Language Class Initialized
DEBUG - 2016-09-19 10:20:26 --> Loader Class Initialized
DEBUG - 2016-09-19 10:20:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 10:20:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 10:20:26 --> Helper loaded: url_helper
DEBUG - 2016-09-19 10:20:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 10:20:26 --> Helper loaded: file_helper
DEBUG - 2016-09-19 10:20:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 10:20:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 10:20:26 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 10:20:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 10:20:26 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 10:20:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 10:20:26 --> Helper loaded: common_helper
DEBUG - 2016-09-19 10:20:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 10:20:26 --> Helper loaded: common_helper
DEBUG - 2016-09-19 10:20:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 10:20:26 --> Helper loaded: form_helper
DEBUG - 2016-09-19 10:20:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 10:20:26 --> Helper loaded: security_helper
DEBUG - 2016-09-19 10:20:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 10:20:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 10:20:26 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 10:20:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 10:20:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 10:20:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 10:20:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 10:20:26 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 10:20:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 10:20:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 10:20:26 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 10:20:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 10:20:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 10:20:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 10:20:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 10:20:26 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 10:20:26 --> Database Driver Class Initialized
DEBUG - 2016-09-19 10:20:26 --> Session Class Initialized
DEBUG - 2016-09-19 10:20:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 10:20:26 --> Helper loaded: string_helper
DEBUG - 2016-09-19 10:20:26 --> Session routines successfully run
DEBUG - 2016-09-19 10:20:26 --> Native_session Class Initialized
DEBUG - 2016-09-19 10:20:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 10:20:26 --> Form Validation Class Initialized
DEBUG - 2016-09-19 10:20:26 --> Form Validation Class Initialized
DEBUG - 2016-09-19 10:20:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 10:20:26 --> Controller Class Initialized
DEBUG - 2016-09-19 10:20:26 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 10:20:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 10:20:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 10:20:26 --> Carabiner: library configured.
DEBUG - 2016-09-19 10:20:26 --> Carabiner: library configured.
DEBUG - 2016-09-19 10:20:26 --> User Agent Class Initialized
DEBUG - 2016-09-19 10:20:26 --> Model Class Initialized
DEBUG - 2016-09-19 10:20:26 --> Model Class Initialized
DEBUG - 2016-09-19 10:20:26 --> Model Class Initialized
DEBUG - 2016-09-19 10:20:26 --> Model Class Initialized
DEBUG - 2016-09-19 10:20:26 --> Model Class Initialized
DEBUG - 2016-09-19 10:20:26 --> Model Class Initialized
DEBUG - 2016-09-19 10:20:26 --> Model Class Initialized
DEBUG - 2016-09-19 10:20:26 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-19 10:20:26 --> Final output sent to browser
DEBUG - 2016-09-19 10:20:26 --> Total execution time: 0.4223
DEBUG - 2016-09-19 10:20:28 --> Config Class Initialized
DEBUG - 2016-09-19 10:20:28 --> Hooks Class Initialized
DEBUG - 2016-09-19 10:20:28 --> Utf8 Class Initialized
DEBUG - 2016-09-19 10:20:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 10:20:28 --> URI Class Initialized
DEBUG - 2016-09-19 10:20:28 --> Router Class Initialized
DEBUG - 2016-09-19 10:20:28 --> Output Class Initialized
DEBUG - 2016-09-19 10:20:28 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 10:20:28 --> Security Class Initialized
DEBUG - 2016-09-19 10:20:28 --> Input Class Initialized
DEBUG - 2016-09-19 10:20:28 --> XSS Filtering completed
DEBUG - 2016-09-19 10:20:28 --> XSS Filtering completed
DEBUG - 2016-09-19 10:20:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 10:20:28 --> Language Class Initialized
DEBUG - 2016-09-19 10:20:28 --> Loader Class Initialized
DEBUG - 2016-09-19 10:20:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 10:20:28 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 10:20:28 --> Helper loaded: url_helper
DEBUG - 2016-09-19 10:20:28 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 10:20:28 --> Helper loaded: file_helper
DEBUG - 2016-09-19 10:20:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 10:20:28 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 10:20:28 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 10:20:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 10:20:28 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 10:20:28 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 10:20:28 --> Helper loaded: common_helper
DEBUG - 2016-09-19 10:20:28 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 10:20:28 --> Helper loaded: common_helper
DEBUG - 2016-09-19 10:20:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 10:20:28 --> Helper loaded: form_helper
DEBUG - 2016-09-19 10:20:28 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 10:20:28 --> Helper loaded: security_helper
DEBUG - 2016-09-19 10:20:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 10:20:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 10:20:28 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 10:20:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 10:20:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 10:20:28 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 10:20:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 10:20:28 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 10:20:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 10:20:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 10:20:28 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 10:20:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 10:20:28 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 10:20:28 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 10:20:28 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 10:20:28 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 10:20:28 --> Database Driver Class Initialized
DEBUG - 2016-09-19 10:20:28 --> Session Class Initialized
DEBUG - 2016-09-19 10:20:28 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 10:20:28 --> Helper loaded: string_helper
DEBUG - 2016-09-19 10:20:28 --> Session routines successfully run
DEBUG - 2016-09-19 10:20:28 --> Native_session Class Initialized
DEBUG - 2016-09-19 10:20:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 10:20:28 --> Form Validation Class Initialized
DEBUG - 2016-09-19 10:20:28 --> Form Validation Class Initialized
DEBUG - 2016-09-19 10:20:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 10:20:28 --> Controller Class Initialized
DEBUG - 2016-09-19 10:20:28 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 10:20:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 10:20:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 10:20:28 --> Carabiner: library configured.
DEBUG - 2016-09-19 10:20:28 --> Carabiner: library configured.
DEBUG - 2016-09-19 10:20:28 --> User Agent Class Initialized
DEBUG - 2016-09-19 10:20:28 --> Model Class Initialized
DEBUG - 2016-09-19 10:20:28 --> Model Class Initialized
DEBUG - 2016-09-19 10:20:28 --> Model Class Initialized
DEBUG - 2016-09-19 10:20:28 --> Model Class Initialized
DEBUG - 2016-09-19 10:20:28 --> Model Class Initialized
DEBUG - 2016-09-19 10:20:28 --> Model Class Initialized
DEBUG - 2016-09-19 10:20:28 --> Model Class Initialized
DEBUG - 2016-09-19 10:20:28 --> Model Class Initialized
ERROR - 2016-09-19 10:20:28 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 11:35:56 --> Config Class Initialized
DEBUG - 2016-09-19 11:35:56 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:35:56 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:35:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:35:56 --> URI Class Initialized
DEBUG - 2016-09-19 11:35:56 --> Router Class Initialized
DEBUG - 2016-09-19 11:35:56 --> Output Class Initialized
DEBUG - 2016-09-19 11:35:56 --> Security Class Initialized
DEBUG - 2016-09-19 11:35:56 --> Input Class Initialized
DEBUG - 2016-09-19 11:35:56 --> XSS Filtering completed
DEBUG - 2016-09-19 11:35:56 --> XSS Filtering completed
DEBUG - 2016-09-19 11:35:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:35:56 --> Language Class Initialized
DEBUG - 2016-09-19 11:35:56 --> Loader Class Initialized
DEBUG - 2016-09-19 11:35:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:35:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:35:56 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:35:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:35:56 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:35:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:35:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:35:56 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:35:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:35:56 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:35:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:35:56 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:35:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:35:56 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:35:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:35:56 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:35:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:35:56 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:35:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:35:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:35:56 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:35:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:35:56 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:35:56 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:35:56 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:35:56 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:35:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:35:56 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:35:56 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:35:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:35:56 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:35:56 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:35:56 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:35:56 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:35:56 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:35:56 --> Session Class Initialized
DEBUG - 2016-09-19 11:35:56 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:35:56 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:35:56 --> Session routines successfully run
DEBUG - 2016-09-19 11:35:56 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:35:56 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:35:56 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:35:56 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:35:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:35:56 --> Controller Class Initialized
DEBUG - 2016-09-19 11:35:56 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:35:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:35:56 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:35:56 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:35:56 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:35:56 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:35:56 --> Model Class Initialized
DEBUG - 2016-09-19 11:35:56 --> Model Class Initialized
DEBUG - 2016-09-19 11:35:56 --> Model Class Initialized
DEBUG - 2016-09-19 11:35:56 --> Model Class Initialized
DEBUG - 2016-09-19 11:35:56 --> Model Class Initialized
DEBUG - 2016-09-19 11:35:56 --> Model Class Initialized
DEBUG - 2016-09-19 11:35:56 --> Model Class Initialized
DEBUG - 2016-09-19 11:35:56 --> Model Class Initialized
ERROR - 2016-09-19 11:35:56 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 11:35:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-19 11:35:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:35:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:35:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:35:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:35:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:35:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:35:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:35:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:35:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:35:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:35:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:35:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:35:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:35:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:35:56 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/26764e7c38cfdb071ebc36690ecd8747
DEBUG - 2016-09-19 11:35:56 --> Final output sent to browser
DEBUG - 2016-09-19 11:35:56 --> Total execution time: 0.5228
DEBUG - 2016-09-19 11:36:03 --> Config Class Initialized
DEBUG - 2016-09-19 11:36:03 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:36:03 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:36:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:36:03 --> URI Class Initialized
DEBUG - 2016-09-19 11:36:03 --> Router Class Initialized
ERROR - 2016-09-19 11:36:03 --> 404 Page Not Found --> front_end/login
DEBUG - 2016-09-19 11:36:03 --> Config Class Initialized
DEBUG - 2016-09-19 11:36:03 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:36:03 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:36:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:36:03 --> URI Class Initialized
DEBUG - 2016-09-19 11:36:03 --> Router Class Initialized
ERROR - 2016-09-19 11:36:03 --> 404 Page Not Found --> img
DEBUG - 2016-09-19 11:36:03 --> Config Class Initialized
DEBUG - 2016-09-19 11:36:03 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:36:03 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:36:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:36:03 --> URI Class Initialized
DEBUG - 2016-09-19 11:36:03 --> Router Class Initialized
ERROR - 2016-09-19 11:36:03 --> 404 Page Not Found --> front_end/favicon.ico
DEBUG - 2016-09-19 11:36:04 --> Config Class Initialized
DEBUG - 2016-09-19 11:36:04 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:36:04 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:36:04 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:36:04 --> URI Class Initialized
DEBUG - 2016-09-19 11:36:04 --> Router Class Initialized
DEBUG - 2016-09-19 11:36:04 --> Output Class Initialized
DEBUG - 2016-09-19 11:36:04 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:36:04 --> Security Class Initialized
DEBUG - 2016-09-19 11:36:04 --> Input Class Initialized
DEBUG - 2016-09-19 11:36:04 --> XSS Filtering completed
DEBUG - 2016-09-19 11:36:04 --> XSS Filtering completed
DEBUG - 2016-09-19 11:36:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:36:04 --> Language Class Initialized
DEBUG - 2016-09-19 11:36:04 --> Loader Class Initialized
DEBUG - 2016-09-19 11:36:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:36:04 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:36:04 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:36:04 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:36:04 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:36:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:36:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:36:04 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:36:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:36:04 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:36:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:36:05 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:36:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:36:05 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:36:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:36:05 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:36:05 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:36:05 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:36:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:36:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:36:05 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:36:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:36:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:36:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:36:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:36:05 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:36:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:36:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:36:05 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:36:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:36:05 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:36:05 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:36:05 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:36:05 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:36:05 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:36:05 --> Session Class Initialized
DEBUG - 2016-09-19 11:36:05 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:36:05 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:36:05 --> Session routines successfully run
DEBUG - 2016-09-19 11:36:05 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:36:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:36:05 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:36:05 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:36:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:36:05 --> Controller Class Initialized
DEBUG - 2016-09-19 11:36:05 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:36:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:36:05 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:36:05 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:36:05 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:36:05 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:36:05 --> Model Class Initialized
DEBUG - 2016-09-19 11:36:05 --> Model Class Initialized
DEBUG - 2016-09-19 11:36:05 --> Model Class Initialized
DEBUG - 2016-09-19 11:36:05 --> Model Class Initialized
DEBUG - 2016-09-19 11:36:05 --> Model Class Initialized
DEBUG - 2016-09-19 11:36:05 --> Model Class Initialized
DEBUG - 2016-09-19 11:36:05 --> Model Class Initialized
DEBUG - 2016-09-19 11:36:05 --> Model Class Initialized
ERROR - 2016-09-19 11:36:05 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 11:36:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-19 11:36:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:36:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:36:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:36:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:36:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:36:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:36:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:36:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:36:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:36:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:36:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:36:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:36:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:36:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:36:05 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/26764e7c38cfdb071ebc36690ecd8747
DEBUG - 2016-09-19 11:36:05 --> Final output sent to browser
DEBUG - 2016-09-19 11:36:05 --> Total execution time: 0.5597
DEBUG - 2016-09-19 11:37:14 --> Config Class Initialized
DEBUG - 2016-09-19 11:37:14 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:37:14 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:37:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:37:14 --> URI Class Initialized
DEBUG - 2016-09-19 11:37:14 --> Router Class Initialized
DEBUG - 2016-09-19 11:37:14 --> Output Class Initialized
DEBUG - 2016-09-19 11:37:14 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:37:14 --> Security Class Initialized
DEBUG - 2016-09-19 11:37:14 --> Input Class Initialized
DEBUG - 2016-09-19 11:37:14 --> XSS Filtering completed
DEBUG - 2016-09-19 11:37:14 --> XSS Filtering completed
DEBUG - 2016-09-19 11:37:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:37:14 --> Language Class Initialized
DEBUG - 2016-09-19 11:37:14 --> Loader Class Initialized
DEBUG - 2016-09-19 11:37:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:37:14 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:37:14 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:37:14 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:37:14 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:37:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:37:14 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:37:14 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:37:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:37:14 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:37:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:37:14 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:37:14 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:37:14 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:37:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:37:14 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:37:14 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:37:14 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:37:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:37:14 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:37:14 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:37:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:37:14 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:37:14 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:37:14 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:37:14 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:37:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:37:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:37:15 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:37:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:37:15 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:37:15 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:37:15 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:37:15 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:37:15 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:37:15 --> Session Class Initialized
DEBUG - 2016-09-19 11:37:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:37:15 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:37:15 --> Session routines successfully run
DEBUG - 2016-09-19 11:37:15 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:37:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:37:15 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:37:15 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:37:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:37:15 --> Controller Class Initialized
DEBUG - 2016-09-19 11:37:15 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:37:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:37:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:37:15 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:37:15 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:37:15 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:37:15 --> Model Class Initialized
DEBUG - 2016-09-19 11:37:15 --> Model Class Initialized
DEBUG - 2016-09-19 11:37:15 --> Model Class Initialized
DEBUG - 2016-09-19 11:37:15 --> Model Class Initialized
DEBUG - 2016-09-19 11:37:15 --> Model Class Initialized
DEBUG - 2016-09-19 11:37:15 --> Model Class Initialized
DEBUG - 2016-09-19 11:37:15 --> Model Class Initialized
DEBUG - 2016-09-19 11:37:15 --> Model Class Initialized
ERROR - 2016-09-19 11:37:15 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 11:37:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-19 11:37:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:37:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:37:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:37:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:37:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:37:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:37:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:37:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:37:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:37:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:37:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:37:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:37:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:37:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:37:15 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/26764e7c38cfdb071ebc36690ecd8747
DEBUG - 2016-09-19 11:37:15 --> Final output sent to browser
DEBUG - 2016-09-19 11:37:15 --> Total execution time: 0.5703
DEBUG - 2016-09-19 11:37:24 --> Config Class Initialized
DEBUG - 2016-09-19 11:37:24 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:37:24 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:37:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:37:24 --> URI Class Initialized
DEBUG - 2016-09-19 11:37:24 --> Router Class Initialized
DEBUG - 2016-09-19 11:37:24 --> Output Class Initialized
DEBUG - 2016-09-19 11:37:24 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:37:24 --> Security Class Initialized
DEBUG - 2016-09-19 11:37:24 --> Input Class Initialized
DEBUG - 2016-09-19 11:37:24 --> XSS Filtering completed
DEBUG - 2016-09-19 11:37:24 --> XSS Filtering completed
DEBUG - 2016-09-19 11:37:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:37:24 --> Language Class Initialized
DEBUG - 2016-09-19 11:37:24 --> Loader Class Initialized
DEBUG - 2016-09-19 11:37:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:37:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:37:24 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:37:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:37:24 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:37:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:37:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:37:24 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:37:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:37:24 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:37:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:37:24 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:37:24 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:37:24 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:37:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:37:24 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:37:24 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:37:24 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:37:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:37:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:37:24 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:37:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:37:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:37:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:37:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:37:24 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:37:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:37:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:37:24 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:37:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:37:24 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:37:24 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:37:24 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:37:24 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:37:24 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:37:24 --> Session Class Initialized
DEBUG - 2016-09-19 11:37:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:37:24 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:37:24 --> Session routines successfully run
DEBUG - 2016-09-19 11:37:24 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:37:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:37:24 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:37:24 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:37:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:37:24 --> Controller Class Initialized
DEBUG - 2016-09-19 11:37:24 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:37:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:37:24 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:37:24 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:37:24 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:37:24 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:37:24 --> Model Class Initialized
DEBUG - 2016-09-19 11:37:24 --> Model Class Initialized
DEBUG - 2016-09-19 11:37:24 --> Model Class Initialized
DEBUG - 2016-09-19 11:37:24 --> Model Class Initialized
DEBUG - 2016-09-19 11:37:24 --> Model Class Initialized
DEBUG - 2016-09-19 11:37:24 --> Model Class Initialized
DEBUG - 2016-09-19 11:37:24 --> Model Class Initialized
DEBUG - 2016-09-19 11:37:24 --> Model Class Initialized
ERROR - 2016-09-19 11:37:24 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 11:37:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-19 11:37:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:37:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:37:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:37:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:37:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:37:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:37:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:37:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:37:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:37:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:37:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:37:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:37:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:37:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:37:24 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/26764e7c38cfdb071ebc36690ecd8747
DEBUG - 2016-09-19 11:37:24 --> Final output sent to browser
DEBUG - 2016-09-19 11:37:24 --> Total execution time: 0.6106
DEBUG - 2016-09-19 11:42:12 --> Config Class Initialized
DEBUG - 2016-09-19 11:42:12 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:42:12 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:42:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:42:12 --> URI Class Initialized
DEBUG - 2016-09-19 11:42:12 --> Router Class Initialized
ERROR - 2016-09-19 11:42:12 --> 404 Page Not Found --> front_end/login
DEBUG - 2016-09-19 11:42:12 --> Config Class Initialized
DEBUG - 2016-09-19 11:42:12 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:42:12 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:42:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:42:12 --> URI Class Initialized
DEBUG - 2016-09-19 11:42:12 --> Router Class Initialized
ERROR - 2016-09-19 11:42:12 --> 404 Page Not Found --> img
DEBUG - 2016-09-19 11:42:12 --> Config Class Initialized
DEBUG - 2016-09-19 11:42:12 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:42:12 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:42:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:42:12 --> URI Class Initialized
DEBUG - 2016-09-19 11:42:12 --> Router Class Initialized
ERROR - 2016-09-19 11:42:12 --> 404 Page Not Found --> front_end/favicon.ico
DEBUG - 2016-09-19 11:43:01 --> Config Class Initialized
DEBUG - 2016-09-19 11:43:01 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:43:01 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:43:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:43:01 --> URI Class Initialized
DEBUG - 2016-09-19 11:43:01 --> Router Class Initialized
DEBUG - 2016-09-19 11:43:01 --> Output Class Initialized
DEBUG - 2016-09-19 11:43:01 --> Security Class Initialized
DEBUG - 2016-09-19 11:43:01 --> Input Class Initialized
DEBUG - 2016-09-19 11:43:01 --> XSS Filtering completed
DEBUG - 2016-09-19 11:43:01 --> XSS Filtering completed
DEBUG - 2016-09-19 11:43:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:43:01 --> Language Class Initialized
DEBUG - 2016-09-19 11:43:01 --> Loader Class Initialized
DEBUG - 2016-09-19 11:43:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:43:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:43:01 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:43:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:43:01 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:43:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:43:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:43:01 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:43:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:43:01 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:43:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:43:01 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:43:01 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:43:01 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:43:01 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:43:01 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:43:01 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:43:01 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:43:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:43:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:43:01 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:43:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:43:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:43:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:43:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:43:01 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:43:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:43:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:43:01 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:43:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:43:01 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:43:01 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:43:01 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:43:01 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:43:01 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:43:01 --> Session Class Initialized
DEBUG - 2016-09-19 11:43:01 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:43:01 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:43:01 --> Session routines successfully run
DEBUG - 2016-09-19 11:43:01 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:43:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:43:01 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:43:01 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:43:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:43:01 --> Controller Class Initialized
DEBUG - 2016-09-19 11:43:01 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:43:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:43:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:43:01 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:43:01 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:43:01 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:43:01 --> Model Class Initialized
DEBUG - 2016-09-19 11:43:01 --> Model Class Initialized
DEBUG - 2016-09-19 11:43:01 --> Model Class Initialized
ERROR - 2016-09-19 11:43:01 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 11:43:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-19 11:43:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:43:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:43:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:43:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:43:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:43:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:43:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:43:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:43:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:43:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:43:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:43:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:43:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:43:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:43:02 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ed91200c725ad69bced3873be02a282
DEBUG - 2016-09-19 11:43:02 --> Final output sent to browser
DEBUG - 2016-09-19 11:43:02 --> Total execution time: 0.5526
DEBUG - 2016-09-19 11:43:09 --> Config Class Initialized
DEBUG - 2016-09-19 11:43:09 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:43:09 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:43:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:43:09 --> URI Class Initialized
DEBUG - 2016-09-19 11:43:09 --> Router Class Initialized
DEBUG - 2016-09-19 11:43:09 --> Output Class Initialized
DEBUG - 2016-09-19 11:43:09 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:43:09 --> Security Class Initialized
DEBUG - 2016-09-19 11:43:09 --> Input Class Initialized
DEBUG - 2016-09-19 11:43:09 --> XSS Filtering completed
DEBUG - 2016-09-19 11:43:09 --> XSS Filtering completed
DEBUG - 2016-09-19 11:43:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:43:09 --> Language Class Initialized
DEBUG - 2016-09-19 11:43:09 --> Loader Class Initialized
DEBUG - 2016-09-19 11:43:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:43:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:43:09 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:43:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:43:09 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:43:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:43:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:43:09 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:43:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:43:09 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:43:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:43:09 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:43:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:43:09 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:43:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:43:09 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:43:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:43:09 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:43:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:43:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:43:09 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:43:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:43:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:43:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:43:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:43:09 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:43:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:43:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:43:09 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:43:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:43:09 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:43:09 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:43:09 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:43:09 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:43:09 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:43:09 --> Session Class Initialized
DEBUG - 2016-09-19 11:43:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:43:09 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:43:09 --> Session routines successfully run
DEBUG - 2016-09-19 11:43:09 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:43:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:43:09 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:43:09 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:43:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:43:09 --> Controller Class Initialized
DEBUG - 2016-09-19 11:43:09 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:43:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:43:09 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:43:09 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:43:09 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:43:09 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:43:09 --> Model Class Initialized
DEBUG - 2016-09-19 11:43:09 --> Model Class Initialized
DEBUG - 2016-09-19 11:43:09 --> Model Class Initialized
ERROR - 2016-09-19 11:43:09 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 11:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-19 11:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:43:09 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ed91200c725ad69bced3873be02a282
DEBUG - 2016-09-19 11:43:09 --> Final output sent to browser
DEBUG - 2016-09-19 11:43:09 --> Total execution time: 0.5980
DEBUG - 2016-09-19 11:45:21 --> Config Class Initialized
DEBUG - 2016-09-19 11:45:21 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:45:21 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:45:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:45:21 --> URI Class Initialized
DEBUG - 2016-09-19 11:45:21 --> Router Class Initialized
DEBUG - 2016-09-19 11:45:21 --> Output Class Initialized
DEBUG - 2016-09-19 11:45:21 --> Security Class Initialized
DEBUG - 2016-09-19 11:45:21 --> Input Class Initialized
DEBUG - 2016-09-19 11:45:21 --> XSS Filtering completed
DEBUG - 2016-09-19 11:45:21 --> XSS Filtering completed
DEBUG - 2016-09-19 11:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:45:21 --> Language Class Initialized
DEBUG - 2016-09-19 11:45:21 --> Loader Class Initialized
DEBUG - 2016-09-19 11:45:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:45:21 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:45:21 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:45:21 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:45:21 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:45:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:45:21 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:45:21 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:45:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:45:21 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:45:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:45:21 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:45:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:45:21 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:45:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:45:21 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:45:21 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:45:21 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:45:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:45:21 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:45:21 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:45:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:45:21 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:45:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:45:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:45:21 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:45:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:45:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:45:21 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:45:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:45:21 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:45:21 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:45:21 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:45:21 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:45:21 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:45:21 --> Session Class Initialized
DEBUG - 2016-09-19 11:45:21 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:45:21 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:45:21 --> Session routines successfully run
DEBUG - 2016-09-19 11:45:21 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:45:21 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:45:21 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:45:21 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:45:21 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:45:21 --> Controller Class Initialized
DEBUG - 2016-09-19 11:45:21 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:45:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:45:21 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:45:21 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:45:21 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:45:21 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:45:21 --> Model Class Initialized
DEBUG - 2016-09-19 11:45:21 --> Model Class Initialized
DEBUG - 2016-09-19 11:45:21 --> Model Class Initialized
ERROR - 2016-09-19 11:45:21 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 11:45:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-19 11:45:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:45:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:45:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:45:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:45:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:45:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:45:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:45:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:45:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:45:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:45:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:45:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:45:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:45:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:45:22 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-19 11:45:22 --> Final output sent to browser
DEBUG - 2016-09-19 11:45:22 --> Total execution time: 0.6252
DEBUG - 2016-09-19 11:45:33 --> Config Class Initialized
DEBUG - 2016-09-19 11:45:33 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:45:33 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:45:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:45:33 --> URI Class Initialized
DEBUG - 2016-09-19 11:45:33 --> Router Class Initialized
DEBUG - 2016-09-19 11:45:33 --> Output Class Initialized
DEBUG - 2016-09-19 11:45:33 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:45:33 --> Security Class Initialized
DEBUG - 2016-09-19 11:45:33 --> Input Class Initialized
DEBUG - 2016-09-19 11:45:33 --> XSS Filtering completed
DEBUG - 2016-09-19 11:45:33 --> XSS Filtering completed
DEBUG - 2016-09-19 11:45:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:45:33 --> Language Class Initialized
DEBUG - 2016-09-19 11:45:33 --> Loader Class Initialized
DEBUG - 2016-09-19 11:45:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:45:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:45:33 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:45:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:45:33 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:45:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:45:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:45:33 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:45:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:45:33 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:45:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:45:33 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:45:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:45:33 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:45:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:45:33 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:45:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:45:33 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:45:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:45:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:45:33 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:45:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:45:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:45:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:45:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:45:33 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:45:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:45:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:45:33 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:45:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:45:33 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:45:33 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:45:33 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:45:33 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:45:33 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:45:33 --> Session Class Initialized
DEBUG - 2016-09-19 11:45:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:45:33 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:45:33 --> Session routines successfully run
DEBUG - 2016-09-19 11:45:33 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:45:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:45:33 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:45:33 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:45:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:45:33 --> Controller Class Initialized
DEBUG - 2016-09-19 11:45:33 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:45:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:45:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:45:33 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:45:33 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:45:33 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:45:33 --> Model Class Initialized
DEBUG - 2016-09-19 11:45:33 --> Model Class Initialized
DEBUG - 2016-09-19 11:45:33 --> Model Class Initialized
ERROR - 2016-09-19 11:45:33 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
ERROR - 2016-09-19 11:45:34 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 17
DEBUG - 2016-09-19 11:45:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-19 11:45:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:45:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:45:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:45:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:45:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:45:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:45:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:45:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:45:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:45:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:45:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:45:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:45:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:45:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:45:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-19 11:45:34 --> Final output sent to browser
DEBUG - 2016-09-19 11:45:34 --> Total execution time: 0.6313
DEBUG - 2016-09-19 11:45:55 --> Config Class Initialized
DEBUG - 2016-09-19 11:45:55 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:45:55 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:45:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:45:55 --> URI Class Initialized
DEBUG - 2016-09-19 11:45:55 --> Router Class Initialized
DEBUG - 2016-09-19 11:45:55 --> Output Class Initialized
DEBUG - 2016-09-19 11:45:55 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:45:55 --> Security Class Initialized
DEBUG - 2016-09-19 11:45:55 --> Input Class Initialized
DEBUG - 2016-09-19 11:45:55 --> XSS Filtering completed
DEBUG - 2016-09-19 11:45:55 --> XSS Filtering completed
DEBUG - 2016-09-19 11:45:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:45:55 --> Language Class Initialized
DEBUG - 2016-09-19 11:45:55 --> Loader Class Initialized
DEBUG - 2016-09-19 11:45:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:45:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:45:55 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:45:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:45:55 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:45:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:45:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:45:55 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:45:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:45:55 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:45:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:45:55 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:45:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:45:55 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:45:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:45:55 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:45:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:45:55 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:45:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:45:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:45:55 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:45:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:45:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:45:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:45:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:45:55 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:45:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:45:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:45:55 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:45:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:45:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:45:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:45:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:45:55 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:45:55 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:45:55 --> Session Class Initialized
DEBUG - 2016-09-19 11:45:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:45:55 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:45:55 --> Session routines successfully run
DEBUG - 2016-09-19 11:45:55 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:45:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:45:55 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:45:55 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:45:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:45:55 --> Controller Class Initialized
DEBUG - 2016-09-19 11:45:55 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:45:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:45:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:45:55 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:45:55 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:45:55 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:45:55 --> Model Class Initialized
DEBUG - 2016-09-19 11:45:55 --> Model Class Initialized
DEBUG - 2016-09-19 11:45:55 --> Model Class Initialized
ERROR - 2016-09-19 11:45:55 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 11:45:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-19 11:45:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:45:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:45:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:45:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:45:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:45:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:45:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:45:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:45:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:45:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:45:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:45:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:45:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:45:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:45:55 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-19 11:45:55 --> Final output sent to browser
DEBUG - 2016-09-19 11:45:55 --> Total execution time: 0.6488
DEBUG - 2016-09-19 11:46:51 --> Config Class Initialized
DEBUG - 2016-09-19 11:46:51 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:46:51 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:46:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:46:51 --> URI Class Initialized
DEBUG - 2016-09-19 11:46:51 --> Router Class Initialized
DEBUG - 2016-09-19 11:46:51 --> Output Class Initialized
DEBUG - 2016-09-19 11:46:51 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:46:51 --> Security Class Initialized
DEBUG - 2016-09-19 11:46:51 --> Input Class Initialized
DEBUG - 2016-09-19 11:46:51 --> XSS Filtering completed
DEBUG - 2016-09-19 11:46:51 --> XSS Filtering completed
DEBUG - 2016-09-19 11:46:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:46:51 --> Language Class Initialized
DEBUG - 2016-09-19 11:46:51 --> Loader Class Initialized
DEBUG - 2016-09-19 11:46:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:46:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:46:51 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:46:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:46:51 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:46:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:46:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:46:51 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:46:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:46:51 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:46:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:46:51 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:46:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:46:51 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:46:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:46:51 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:46:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:46:51 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:46:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:46:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:46:51 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:46:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:46:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:46:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:46:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:46:51 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:46:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:46:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:46:51 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:46:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:46:51 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:46:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:46:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:46:51 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:46:51 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:46:51 --> Session Class Initialized
DEBUG - 2016-09-19 11:46:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:46:51 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:46:51 --> Session routines successfully run
DEBUG - 2016-09-19 11:46:51 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:46:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:46:51 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:46:51 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:46:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:46:51 --> Controller Class Initialized
DEBUG - 2016-09-19 11:46:51 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:46:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:46:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:46:51 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:46:51 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:46:51 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:46:51 --> Model Class Initialized
DEBUG - 2016-09-19 11:46:51 --> Model Class Initialized
DEBUG - 2016-09-19 11:46:51 --> Model Class Initialized
ERROR - 2016-09-19 11:46:51 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 11:46:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-19 11:46:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:46:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:46:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:46:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:46:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:46:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:46:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:46:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:46:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:46:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:46:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:46:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:46:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:46:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:46:51 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-19 11:46:51 --> Final output sent to browser
DEBUG - 2016-09-19 11:46:51 --> Total execution time: 0.6731
DEBUG - 2016-09-19 11:47:22 --> Config Class Initialized
DEBUG - 2016-09-19 11:47:22 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:47:22 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:47:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:47:22 --> URI Class Initialized
DEBUG - 2016-09-19 11:47:22 --> Router Class Initialized
DEBUG - 2016-09-19 11:47:22 --> Output Class Initialized
DEBUG - 2016-09-19 11:47:22 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:47:22 --> Security Class Initialized
DEBUG - 2016-09-19 11:47:22 --> Input Class Initialized
DEBUG - 2016-09-19 11:47:22 --> XSS Filtering completed
DEBUG - 2016-09-19 11:47:22 --> XSS Filtering completed
DEBUG - 2016-09-19 11:47:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:47:22 --> Language Class Initialized
DEBUG - 2016-09-19 11:47:22 --> Loader Class Initialized
DEBUG - 2016-09-19 11:47:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:47:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:47:22 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:47:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:47:22 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:47:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:47:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:47:22 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:47:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:47:22 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:47:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:47:22 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:47:22 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:47:22 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:47:22 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:47:22 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:47:22 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:47:22 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:47:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:47:22 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:47:22 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:47:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:47:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:47:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:47:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:47:23 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:47:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:47:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:47:23 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:47:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:47:23 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:47:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:47:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:47:23 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:47:23 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:47:23 --> Session Class Initialized
DEBUG - 2016-09-19 11:47:23 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:47:23 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:47:23 --> Session routines successfully run
DEBUG - 2016-09-19 11:47:23 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:47:23 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:47:23 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:47:23 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:47:23 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:47:23 --> Controller Class Initialized
DEBUG - 2016-09-19 11:47:23 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:47:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:47:23 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:47:23 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:47:23 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:47:23 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:47:23 --> Model Class Initialized
DEBUG - 2016-09-19 11:47:23 --> Model Class Initialized
DEBUG - 2016-09-19 11:47:23 --> Model Class Initialized
ERROR - 2016-09-19 11:47:23 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 11:47:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-19 11:47:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:47:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:47:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:47:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:47:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:47:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:47:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:47:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:47:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:47:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:47:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:47:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:47:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:47:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:47:23 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-19 11:47:23 --> Final output sent to browser
DEBUG - 2016-09-19 11:47:23 --> Total execution time: 0.6802
DEBUG - 2016-09-19 11:47:31 --> Config Class Initialized
DEBUG - 2016-09-19 11:47:31 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:47:31 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:47:31 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:47:31 --> URI Class Initialized
DEBUG - 2016-09-19 11:47:32 --> Router Class Initialized
DEBUG - 2016-09-19 11:47:32 --> Output Class Initialized
DEBUG - 2016-09-19 11:47:32 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:47:32 --> Security Class Initialized
DEBUG - 2016-09-19 11:47:32 --> Input Class Initialized
DEBUG - 2016-09-19 11:47:32 --> XSS Filtering completed
DEBUG - 2016-09-19 11:47:32 --> XSS Filtering completed
DEBUG - 2016-09-19 11:47:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:47:32 --> Language Class Initialized
DEBUG - 2016-09-19 11:47:32 --> Loader Class Initialized
DEBUG - 2016-09-19 11:47:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:47:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:47:32 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:47:32 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:47:32 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:47:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:47:32 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:47:32 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:47:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:47:32 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:47:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:47:32 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:47:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:47:32 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:47:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:47:32 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:47:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:47:32 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:47:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:47:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:47:32 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:47:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:47:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:47:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:47:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:47:32 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:47:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:47:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:47:32 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:47:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:47:32 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:47:32 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:47:32 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:47:32 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:47:32 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:47:32 --> Session Class Initialized
DEBUG - 2016-09-19 11:47:32 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:47:32 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:47:32 --> Session routines successfully run
DEBUG - 2016-09-19 11:47:32 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:47:32 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:47:32 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:47:32 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:47:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:47:32 --> Controller Class Initialized
DEBUG - 2016-09-19 11:47:32 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:47:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:47:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:47:32 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:47:32 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:47:32 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:47:32 --> Model Class Initialized
DEBUG - 2016-09-19 11:47:32 --> Model Class Initialized
DEBUG - 2016-09-19 11:47:32 --> Model Class Initialized
ERROR - 2016-09-19 11:47:32 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 11:47:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-19 11:47:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:47:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:47:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:47:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:47:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:47:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:47:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:47:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:47:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:47:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:47:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:47:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:47:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:47:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:47:32 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-19 11:47:32 --> Final output sent to browser
DEBUG - 2016-09-19 11:47:32 --> Total execution time: 0.7220
DEBUG - 2016-09-19 11:47:36 --> Config Class Initialized
DEBUG - 2016-09-19 11:47:36 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:47:36 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:47:36 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:47:36 --> URI Class Initialized
DEBUG - 2016-09-19 11:47:36 --> Router Class Initialized
DEBUG - 2016-09-19 11:47:36 --> No URI present. Default controller set.
DEBUG - 2016-09-19 11:47:36 --> Output Class Initialized
DEBUG - 2016-09-19 11:47:36 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:47:36 --> Security Class Initialized
DEBUG - 2016-09-19 11:47:36 --> Input Class Initialized
DEBUG - 2016-09-19 11:47:36 --> XSS Filtering completed
DEBUG - 2016-09-19 11:47:36 --> XSS Filtering completed
DEBUG - 2016-09-19 11:47:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:47:36 --> Language Class Initialized
DEBUG - 2016-09-19 11:47:36 --> Loader Class Initialized
DEBUG - 2016-09-19 11:47:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:47:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:47:36 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:47:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:47:36 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:47:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:47:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:47:36 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:47:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:47:36 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:47:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:47:36 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:47:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:47:36 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:47:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:47:36 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:47:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:47:36 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:47:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:47:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:47:36 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:47:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:47:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:47:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:47:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:47:36 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:47:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:47:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:47:36 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:47:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:47:36 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:47:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:47:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:47:36 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:47:36 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:47:36 --> Session Class Initialized
DEBUG - 2016-09-19 11:47:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:47:36 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:47:36 --> Session routines successfully run
DEBUG - 2016-09-19 11:47:36 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:47:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:47:36 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:47:36 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:47:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:47:36 --> Controller Class Initialized
DEBUG - 2016-09-19 11:47:36 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:47:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:47:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:47:36 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:47:36 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:47:36 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:47:36 --> Model Class Initialized
DEBUG - 2016-09-19 11:47:36 --> Model Class Initialized
DEBUG - 2016-09-19 11:47:36 --> Model Class Initialized
ERROR - 2016-09-19 11:47:36 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 11:47:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-19 11:47:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-19 11:47:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:47:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:47:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:47:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:47:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:47:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 11:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 11:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 11:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 11:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:47:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:47:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-19 11:47:37 --> Final output sent to browser
DEBUG - 2016-09-19 11:47:37 --> Total execution time: 0.6956
DEBUG - 2016-09-19 11:47:37 --> Config Class Initialized
DEBUG - 2016-09-19 11:47:37 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:47:37 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:47:37 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:47:37 --> URI Class Initialized
DEBUG - 2016-09-19 11:47:37 --> Router Class Initialized
DEBUG - 2016-09-19 11:47:37 --> Output Class Initialized
DEBUG - 2016-09-19 11:47:37 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:47:37 --> Security Class Initialized
DEBUG - 2016-09-19 11:47:37 --> Input Class Initialized
DEBUG - 2016-09-19 11:47:37 --> XSS Filtering completed
DEBUG - 2016-09-19 11:47:37 --> XSS Filtering completed
DEBUG - 2016-09-19 11:47:37 --> XSS Filtering completed
DEBUG - 2016-09-19 11:47:37 --> XSS Filtering completed
DEBUG - 2016-09-19 11:47:37 --> XSS Filtering completed
DEBUG - 2016-09-19 11:47:37 --> XSS Filtering completed
DEBUG - 2016-09-19 11:47:37 --> XSS Filtering completed
DEBUG - 2016-09-19 11:47:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:47:37 --> Language Class Initialized
DEBUG - 2016-09-19 11:47:37 --> Loader Class Initialized
DEBUG - 2016-09-19 11:47:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:47:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:47:37 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:47:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:47:37 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:47:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:47:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:47:37 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:47:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:47:37 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:47:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:47:37 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:47:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:47:37 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:47:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:47:37 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:47:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:47:37 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:47:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:47:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:47:37 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:47:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:47:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:47:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:47:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:47:37 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:47:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:47:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:47:37 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:47:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:47:37 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:47:37 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:47:37 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:47:37 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:47:37 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:47:37 --> Session Class Initialized
DEBUG - 2016-09-19 11:47:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:47:37 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:47:37 --> Session routines successfully run
DEBUG - 2016-09-19 11:47:37 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:47:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:47:37 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:47:37 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:47:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:47:37 --> Controller Class Initialized
DEBUG - 2016-09-19 11:47:37 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:47:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:47:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:47:37 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:47:37 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:47:37 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:47:37 --> Model Class Initialized
DEBUG - 2016-09-19 11:47:37 --> Model Class Initialized
DEBUG - 2016-09-19 11:47:37 --> Model Class Initialized
DEBUG - 2016-09-19 11:47:37 --> Model Class Initialized
DEBUG - 2016-09-19 11:47:37 --> Model Class Initialized
DEBUG - 2016-09-19 11:47:37 --> Model Class Initialized
DEBUG - 2016-09-19 11:47:37 --> Model Class Initialized
DEBUG - 2016-09-19 11:47:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-19 11:47:37 --> Final output sent to browser
DEBUG - 2016-09-19 11:47:37 --> Total execution time: 0.6907
DEBUG - 2016-09-19 11:47:41 --> Config Class Initialized
DEBUG - 2016-09-19 11:47:41 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:47:41 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:47:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:47:41 --> URI Class Initialized
DEBUG - 2016-09-19 11:47:41 --> Router Class Initialized
DEBUG - 2016-09-19 11:47:41 --> Output Class Initialized
DEBUG - 2016-09-19 11:47:41 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:47:41 --> Security Class Initialized
DEBUG - 2016-09-19 11:47:41 --> Input Class Initialized
DEBUG - 2016-09-19 11:47:41 --> XSS Filtering completed
DEBUG - 2016-09-19 11:47:41 --> XSS Filtering completed
DEBUG - 2016-09-19 11:47:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:47:41 --> Language Class Initialized
DEBUG - 2016-09-19 11:47:41 --> Loader Class Initialized
DEBUG - 2016-09-19 11:47:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:47:41 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:47:41 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:47:41 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:47:41 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:47:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:47:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:47:41 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:47:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:47:41 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:47:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:47:41 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:47:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:47:41 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:47:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:47:41 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:47:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:47:41 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:47:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:47:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:47:41 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:47:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:47:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:47:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:47:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:47:41 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:47:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:47:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:47:41 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:47:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:47:41 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:47:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:47:41 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:47:41 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:47:41 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:47:41 --> Session Class Initialized
DEBUG - 2016-09-19 11:47:41 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:47:41 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:47:41 --> Session routines successfully run
DEBUG - 2016-09-19 11:47:41 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:47:41 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:47:41 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:47:41 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:47:41 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:47:41 --> Controller Class Initialized
DEBUG - 2016-09-19 11:47:41 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:47:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:47:41 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:47:41 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:47:41 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:47:41 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:47:41 --> Model Class Initialized
DEBUG - 2016-09-19 11:47:41 --> Model Class Initialized
DEBUG - 2016-09-19 11:47:41 --> Model Class Initialized
DEBUG - 2016-09-19 11:47:41 --> Model Class Initialized
DEBUG - 2016-09-19 11:47:41 --> Model Class Initialized
DEBUG - 2016-09-19 11:47:41 --> Model Class Initialized
DEBUG - 2016-09-19 11:47:41 --> Model Class Initialized
DEBUG - 2016-09-19 11:47:41 --> Model Class Initialized
ERROR - 2016-09-19 11:47:41 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 11:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-19 11:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:47:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:47:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:47:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:47:42 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/26764e7c38cfdb071ebc36690ecd8747
DEBUG - 2016-09-19 11:47:42 --> Final output sent to browser
DEBUG - 2016-09-19 11:47:42 --> Total execution time: 0.8474
DEBUG - 2016-09-19 11:54:04 --> Config Class Initialized
DEBUG - 2016-09-19 11:54:04 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:54:04 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:54:04 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:54:04 --> URI Class Initialized
DEBUG - 2016-09-19 11:54:04 --> Router Class Initialized
DEBUG - 2016-09-19 11:54:04 --> No URI present. Default controller set.
DEBUG - 2016-09-19 11:54:04 --> Output Class Initialized
DEBUG - 2016-09-19 11:54:04 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:54:04 --> Security Class Initialized
DEBUG - 2016-09-19 11:54:04 --> Input Class Initialized
DEBUG - 2016-09-19 11:54:04 --> XSS Filtering completed
DEBUG - 2016-09-19 11:54:04 --> XSS Filtering completed
DEBUG - 2016-09-19 11:54:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:54:04 --> Language Class Initialized
DEBUG - 2016-09-19 11:54:04 --> Loader Class Initialized
DEBUG - 2016-09-19 11:54:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:54:04 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:54:04 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:54:04 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:54:04 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:54:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:54:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:54:04 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:54:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:54:04 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:54:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:54:04 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:54:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:54:04 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:54:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:54:04 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:54:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:54:04 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:54:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:54:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:54:04 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:54:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:54:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:54:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:54:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:54:04 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:54:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:54:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:54:04 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:54:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:54:04 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:54:04 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:54:04 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:54:04 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:54:04 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:54:05 --> Session Class Initialized
DEBUG - 2016-09-19 11:54:05 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:54:05 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:54:05 --> Session routines successfully run
DEBUG - 2016-09-19 11:54:05 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:54:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:54:05 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:54:05 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:54:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:54:05 --> Controller Class Initialized
DEBUG - 2016-09-19 11:54:05 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:54:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:54:05 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:54:05 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:54:05 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:54:05 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:54:05 --> Model Class Initialized
DEBUG - 2016-09-19 11:54:05 --> Model Class Initialized
DEBUG - 2016-09-19 11:54:05 --> Model Class Initialized
ERROR - 2016-09-19 11:54:05 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 11:54:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-19 11:54:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-19 11:54:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:54:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:54:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:54:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:54:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:54:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 11:54:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 11:54:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:54:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:54:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:54:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:54:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:54:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:54:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:54:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 11:54:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 11:54:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:54:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:54:05 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-19 11:54:05 --> Final output sent to browser
DEBUG - 2016-09-19 11:54:05 --> Total execution time: 0.8489
DEBUG - 2016-09-19 11:54:05 --> Config Class Initialized
DEBUG - 2016-09-19 11:54:05 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:54:05 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:54:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:54:05 --> URI Class Initialized
DEBUG - 2016-09-19 11:54:05 --> Router Class Initialized
DEBUG - 2016-09-19 11:54:05 --> Output Class Initialized
DEBUG - 2016-09-19 11:54:05 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:54:05 --> Security Class Initialized
DEBUG - 2016-09-19 11:54:05 --> Input Class Initialized
DEBUG - 2016-09-19 11:54:05 --> XSS Filtering completed
DEBUG - 2016-09-19 11:54:05 --> XSS Filtering completed
DEBUG - 2016-09-19 11:54:05 --> XSS Filtering completed
DEBUG - 2016-09-19 11:54:05 --> XSS Filtering completed
DEBUG - 2016-09-19 11:54:05 --> XSS Filtering completed
DEBUG - 2016-09-19 11:54:05 --> XSS Filtering completed
DEBUG - 2016-09-19 11:54:05 --> XSS Filtering completed
DEBUG - 2016-09-19 11:54:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:54:05 --> Language Class Initialized
DEBUG - 2016-09-19 11:54:05 --> Loader Class Initialized
DEBUG - 2016-09-19 11:54:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:54:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:54:05 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:54:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:54:05 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:54:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:54:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:54:05 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:54:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:54:05 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:54:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:54:05 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:54:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:54:05 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:54:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:54:05 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:54:05 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:54:05 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:54:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:54:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:54:05 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:54:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:54:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:54:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:54:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:54:05 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:54:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:54:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:54:05 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:54:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:54:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:54:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:54:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:54:06 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:54:06 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:54:06 --> Session Class Initialized
DEBUG - 2016-09-19 11:54:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:54:06 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:54:06 --> Session routines successfully run
DEBUG - 2016-09-19 11:54:06 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:54:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:54:06 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:54:06 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:54:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:54:06 --> Controller Class Initialized
DEBUG - 2016-09-19 11:54:06 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:54:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:54:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:54:06 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:54:06 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:54:06 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:54:06 --> Model Class Initialized
DEBUG - 2016-09-19 11:54:06 --> Model Class Initialized
DEBUG - 2016-09-19 11:54:06 --> Model Class Initialized
DEBUG - 2016-09-19 11:54:06 --> Model Class Initialized
DEBUG - 2016-09-19 11:54:06 --> Model Class Initialized
DEBUG - 2016-09-19 11:54:06 --> Model Class Initialized
DEBUG - 2016-09-19 11:54:06 --> Model Class Initialized
DEBUG - 2016-09-19 11:54:06 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-19 11:54:06 --> Final output sent to browser
DEBUG - 2016-09-19 11:54:06 --> Total execution time: 0.7554
DEBUG - 2016-09-19 11:54:17 --> Config Class Initialized
DEBUG - 2016-09-19 11:54:17 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:54:17 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:54:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:54:17 --> URI Class Initialized
DEBUG - 2016-09-19 11:54:17 --> Router Class Initialized
DEBUG - 2016-09-19 11:54:17 --> Output Class Initialized
DEBUG - 2016-09-19 11:54:17 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:54:17 --> Security Class Initialized
DEBUG - 2016-09-19 11:54:17 --> Input Class Initialized
DEBUG - 2016-09-19 11:54:17 --> XSS Filtering completed
DEBUG - 2016-09-19 11:54:17 --> XSS Filtering completed
DEBUG - 2016-09-19 11:54:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:54:17 --> Language Class Initialized
DEBUG - 2016-09-19 11:54:17 --> Loader Class Initialized
DEBUG - 2016-09-19 11:54:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:54:17 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:54:17 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:54:17 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:54:17 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:54:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:54:17 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:54:17 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:54:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:54:17 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:54:17 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:54:17 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:54:17 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:54:17 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:54:17 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:54:17 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:54:17 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:54:17 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:54:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:54:17 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:54:17 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:54:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:54:17 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:54:17 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:54:17 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:54:17 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:54:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:54:17 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:54:17 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:54:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:54:17 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:54:17 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:54:17 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:54:17 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:54:17 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:54:17 --> Session Class Initialized
DEBUG - 2016-09-19 11:54:17 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:54:17 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:54:17 --> Session routines successfully run
DEBUG - 2016-09-19 11:54:17 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:54:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:54:17 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:54:17 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:54:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:54:17 --> Controller Class Initialized
DEBUG - 2016-09-19 11:54:17 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:54:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:54:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:54:17 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:54:17 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:54:17 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:54:17 --> Model Class Initialized
DEBUG - 2016-09-19 11:54:17 --> Model Class Initialized
DEBUG - 2016-09-19 11:54:17 --> Model Class Initialized
DEBUG - 2016-09-19 11:54:17 --> Model Class Initialized
DEBUG - 2016-09-19 11:54:17 --> Model Class Initialized
DEBUG - 2016-09-19 11:54:17 --> Model Class Initialized
DEBUG - 2016-09-19 11:54:18 --> Model Class Initialized
DEBUG - 2016-09-19 11:54:18 --> Model Class Initialized
ERROR - 2016-09-19 11:54:18 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 11:54:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-19 11:54:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:54:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:54:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:54:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:54:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:54:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:54:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:54:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:54:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:54:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:54:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:54:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:54:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:54:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:54:18 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/26764e7c38cfdb071ebc36690ecd8747
DEBUG - 2016-09-19 11:54:18 --> Final output sent to browser
DEBUG - 2016-09-19 11:54:18 --> Total execution time: 0.8649
DEBUG - 2016-09-19 11:54:57 --> Config Class Initialized
DEBUG - 2016-09-19 11:54:57 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:54:58 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:54:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:54:58 --> URI Class Initialized
DEBUG - 2016-09-19 11:54:58 --> Router Class Initialized
DEBUG - 2016-09-19 11:54:58 --> No URI present. Default controller set.
DEBUG - 2016-09-19 11:54:58 --> Output Class Initialized
DEBUG - 2016-09-19 11:54:58 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:54:58 --> Security Class Initialized
DEBUG - 2016-09-19 11:54:58 --> Input Class Initialized
DEBUG - 2016-09-19 11:54:58 --> XSS Filtering completed
DEBUG - 2016-09-19 11:54:58 --> XSS Filtering completed
DEBUG - 2016-09-19 11:54:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:54:58 --> Language Class Initialized
DEBUG - 2016-09-19 11:54:58 --> Loader Class Initialized
DEBUG - 2016-09-19 11:54:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:54:58 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:54:58 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:54:58 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:54:58 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:54:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:54:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:54:58 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:54:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:54:58 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:54:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:54:58 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:54:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:54:58 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:54:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:54:58 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:54:58 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:54:58 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:54:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:54:58 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:54:58 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:54:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:54:58 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:54:58 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:54:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:54:58 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:54:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:54:58 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:54:58 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:54:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:54:58 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:54:58 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:54:58 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:54:58 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:54:58 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:54:58 --> Session Class Initialized
DEBUG - 2016-09-19 11:54:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:54:58 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:54:58 --> Session routines successfully run
DEBUG - 2016-09-19 11:54:58 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:54:58 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:54:58 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:54:58 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:54:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:54:58 --> Controller Class Initialized
DEBUG - 2016-09-19 11:54:58 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:54:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:54:58 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:54:58 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:54:58 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:54:58 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:54:58 --> Model Class Initialized
DEBUG - 2016-09-19 11:54:58 --> Model Class Initialized
DEBUG - 2016-09-19 11:54:58 --> Model Class Initialized
ERROR - 2016-09-19 11:54:58 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 11:54:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-19 11:54:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-19 11:54:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:54:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:54:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:54:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:54:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:54:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 11:54:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 11:54:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:54:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:54:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:54:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:54:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:54:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:54:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:54:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 11:54:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 11:54:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:54:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:54:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-19 11:54:59 --> Final output sent to browser
DEBUG - 2016-09-19 11:54:59 --> Total execution time: 0.8770
DEBUG - 2016-09-19 11:54:59 --> Config Class Initialized
DEBUG - 2016-09-19 11:54:59 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:54:59 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:54:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:54:59 --> URI Class Initialized
DEBUG - 2016-09-19 11:54:59 --> Router Class Initialized
DEBUG - 2016-09-19 11:54:59 --> Output Class Initialized
DEBUG - 2016-09-19 11:54:59 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:54:59 --> Security Class Initialized
DEBUG - 2016-09-19 11:54:59 --> Input Class Initialized
DEBUG - 2016-09-19 11:54:59 --> XSS Filtering completed
DEBUG - 2016-09-19 11:54:59 --> XSS Filtering completed
DEBUG - 2016-09-19 11:54:59 --> XSS Filtering completed
DEBUG - 2016-09-19 11:54:59 --> XSS Filtering completed
DEBUG - 2016-09-19 11:54:59 --> XSS Filtering completed
DEBUG - 2016-09-19 11:54:59 --> XSS Filtering completed
DEBUG - 2016-09-19 11:54:59 --> XSS Filtering completed
DEBUG - 2016-09-19 11:54:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:54:59 --> Language Class Initialized
DEBUG - 2016-09-19 11:54:59 --> Loader Class Initialized
DEBUG - 2016-09-19 11:54:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:54:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:54:59 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:54:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:54:59 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:54:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:54:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:54:59 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:54:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:54:59 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:54:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:54:59 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:54:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:54:59 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:54:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:54:59 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:54:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:54:59 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:54:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:54:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:54:59 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:54:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:54:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:54:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:54:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:54:59 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:54:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:54:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:54:59 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:54:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:54:59 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:54:59 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:54:59 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:54:59 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:54:59 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:54:59 --> Session Class Initialized
DEBUG - 2016-09-19 11:54:59 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:54:59 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:54:59 --> Session routines successfully run
DEBUG - 2016-09-19 11:54:59 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:54:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:54:59 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:54:59 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:54:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:54:59 --> Controller Class Initialized
DEBUG - 2016-09-19 11:54:59 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:54:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:54:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:54:59 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:54:59 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:54:59 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:54:59 --> Model Class Initialized
DEBUG - 2016-09-19 11:54:59 --> Model Class Initialized
DEBUG - 2016-09-19 11:54:59 --> Model Class Initialized
DEBUG - 2016-09-19 11:54:59 --> Model Class Initialized
DEBUG - 2016-09-19 11:54:59 --> Model Class Initialized
DEBUG - 2016-09-19 11:54:59 --> Model Class Initialized
DEBUG - 2016-09-19 11:54:59 --> Model Class Initialized
DEBUG - 2016-09-19 11:54:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-19 11:54:59 --> Final output sent to browser
DEBUG - 2016-09-19 11:54:59 --> Total execution time: 0.8059
DEBUG - 2016-09-19 11:55:17 --> Config Class Initialized
DEBUG - 2016-09-19 11:55:17 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:55:17 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:55:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:55:17 --> URI Class Initialized
DEBUG - 2016-09-19 11:55:17 --> Router Class Initialized
DEBUG - 2016-09-19 11:55:17 --> Output Class Initialized
DEBUG - 2016-09-19 11:55:17 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:55:17 --> Security Class Initialized
DEBUG - 2016-09-19 11:55:17 --> Input Class Initialized
DEBUG - 2016-09-19 11:55:17 --> XSS Filtering completed
DEBUG - 2016-09-19 11:55:17 --> XSS Filtering completed
DEBUG - 2016-09-19 11:55:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:55:17 --> Language Class Initialized
DEBUG - 2016-09-19 11:55:17 --> Loader Class Initialized
DEBUG - 2016-09-19 11:55:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:55:17 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:55:17 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:55:17 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:55:17 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:55:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:55:17 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:55:17 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:55:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:55:17 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:55:17 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:55:17 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:55:17 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:55:17 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:55:17 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:55:17 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:55:17 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:55:17 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:55:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:55:17 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:55:17 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:55:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:55:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:55:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:55:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:55:18 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:55:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:55:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:55:18 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:55:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:55:18 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:55:18 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:55:18 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:55:18 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:55:18 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:55:18 --> Session Class Initialized
DEBUG - 2016-09-19 11:55:18 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:55:18 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:55:18 --> Session routines successfully run
DEBUG - 2016-09-19 11:55:18 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:55:18 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:55:18 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:55:18 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:55:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:55:18 --> Controller Class Initialized
DEBUG - 2016-09-19 11:55:18 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:55:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:55:18 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:55:18 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:55:18 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:55:18 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:55:18 --> Model Class Initialized
DEBUG - 2016-09-19 11:55:18 --> Model Class Initialized
DEBUG - 2016-09-19 11:55:18 --> Model Class Initialized
DEBUG - 2016-09-19 11:55:18 --> Model Class Initialized
DEBUG - 2016-09-19 11:55:18 --> Model Class Initialized
DEBUG - 2016-09-19 11:55:18 --> Model Class Initialized
DEBUG - 2016-09-19 11:55:18 --> Model Class Initialized
DEBUG - 2016-09-19 11:55:18 --> Model Class Initialized
ERROR - 2016-09-19 11:55:18 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 11:55:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-19 11:55:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:55:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:55:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:55:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:55:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:55:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:55:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:55:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:55:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:55:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:55:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:55:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:55:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:55:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:55:18 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/26764e7c38cfdb071ebc36690ecd8747
DEBUG - 2016-09-19 11:55:18 --> Final output sent to browser
DEBUG - 2016-09-19 11:55:18 --> Total execution time: 0.9545
DEBUG - 2016-09-19 11:55:42 --> Config Class Initialized
DEBUG - 2016-09-19 11:55:42 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:55:42 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:55:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:55:42 --> URI Class Initialized
DEBUG - 2016-09-19 11:55:42 --> Router Class Initialized
DEBUG - 2016-09-19 11:55:42 --> No URI present. Default controller set.
DEBUG - 2016-09-19 11:55:42 --> Output Class Initialized
DEBUG - 2016-09-19 11:55:42 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:55:42 --> Security Class Initialized
DEBUG - 2016-09-19 11:55:42 --> Input Class Initialized
DEBUG - 2016-09-19 11:55:42 --> XSS Filtering completed
DEBUG - 2016-09-19 11:55:42 --> XSS Filtering completed
DEBUG - 2016-09-19 11:55:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:55:42 --> Language Class Initialized
DEBUG - 2016-09-19 11:55:42 --> Loader Class Initialized
DEBUG - 2016-09-19 11:55:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:55:42 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:55:42 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:55:42 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:55:42 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:55:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:55:42 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:55:42 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:55:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:55:42 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:55:42 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:55:43 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:55:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:55:43 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:55:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:55:43 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:55:43 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:55:43 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:55:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:55:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:55:43 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:55:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:55:43 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:55:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:55:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:55:43 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:55:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:55:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:55:43 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:55:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:55:43 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:55:43 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:55:43 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:55:43 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:55:43 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:55:43 --> Session Class Initialized
DEBUG - 2016-09-19 11:55:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:55:43 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:55:43 --> Session routines successfully run
DEBUG - 2016-09-19 11:55:43 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:55:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:55:43 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:55:43 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:55:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:55:43 --> Controller Class Initialized
DEBUG - 2016-09-19 11:55:43 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:55:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:55:43 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:55:43 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:55:43 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:55:43 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:55:43 --> Model Class Initialized
DEBUG - 2016-09-19 11:55:43 --> Model Class Initialized
DEBUG - 2016-09-19 11:55:43 --> Model Class Initialized
ERROR - 2016-09-19 11:55:43 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 11:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-19 11:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-19 11:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 11:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 11:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 11:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 11:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:55:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:55:43 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-19 11:55:43 --> Final output sent to browser
DEBUG - 2016-09-19 11:55:43 --> Total execution time: 0.8848
DEBUG - 2016-09-19 11:55:43 --> Config Class Initialized
DEBUG - 2016-09-19 11:55:43 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:55:43 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:55:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:55:43 --> URI Class Initialized
DEBUG - 2016-09-19 11:55:43 --> Router Class Initialized
DEBUG - 2016-09-19 11:55:43 --> Output Class Initialized
DEBUG - 2016-09-19 11:55:43 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:55:43 --> Security Class Initialized
DEBUG - 2016-09-19 11:55:43 --> Input Class Initialized
DEBUG - 2016-09-19 11:55:43 --> XSS Filtering completed
DEBUG - 2016-09-19 11:55:43 --> XSS Filtering completed
DEBUG - 2016-09-19 11:55:44 --> XSS Filtering completed
DEBUG - 2016-09-19 11:55:44 --> XSS Filtering completed
DEBUG - 2016-09-19 11:55:44 --> XSS Filtering completed
DEBUG - 2016-09-19 11:55:44 --> XSS Filtering completed
DEBUG - 2016-09-19 11:55:44 --> XSS Filtering completed
DEBUG - 2016-09-19 11:55:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:55:44 --> Language Class Initialized
DEBUG - 2016-09-19 11:55:44 --> Loader Class Initialized
DEBUG - 2016-09-19 11:55:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:55:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:55:44 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:55:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:55:44 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:55:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:55:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:55:44 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:55:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:55:44 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:55:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:55:44 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:55:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:55:44 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:55:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:55:44 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:55:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:55:44 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:55:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:55:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:55:44 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:55:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:55:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:55:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:55:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:55:44 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:55:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:55:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:55:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:55:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:55:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:55:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:55:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:55:44 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:55:44 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:55:44 --> Session Class Initialized
DEBUG - 2016-09-19 11:55:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:55:44 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:55:44 --> Session routines successfully run
DEBUG - 2016-09-19 11:55:44 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:55:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:55:44 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:55:44 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:55:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:55:44 --> Controller Class Initialized
DEBUG - 2016-09-19 11:55:44 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:55:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:55:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:55:44 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:55:44 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:55:44 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:55:44 --> Model Class Initialized
DEBUG - 2016-09-19 11:55:44 --> Model Class Initialized
DEBUG - 2016-09-19 11:55:44 --> Model Class Initialized
DEBUG - 2016-09-19 11:55:44 --> Model Class Initialized
DEBUG - 2016-09-19 11:55:44 --> Model Class Initialized
DEBUG - 2016-09-19 11:55:44 --> Model Class Initialized
DEBUG - 2016-09-19 11:55:44 --> Model Class Initialized
DEBUG - 2016-09-19 11:55:44 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-19 11:55:44 --> Final output sent to browser
DEBUG - 2016-09-19 11:55:44 --> Total execution time: 0.8729
DEBUG - 2016-09-19 11:56:08 --> Config Class Initialized
DEBUG - 2016-09-19 11:56:08 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:56:08 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:56:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:56:08 --> URI Class Initialized
DEBUG - 2016-09-19 11:56:08 --> Router Class Initialized
DEBUG - 2016-09-19 11:56:08 --> Output Class Initialized
DEBUG - 2016-09-19 11:56:08 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:56:08 --> Security Class Initialized
DEBUG - 2016-09-19 11:56:08 --> Input Class Initialized
DEBUG - 2016-09-19 11:56:08 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:08 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:08 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:08 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:08 --> Config Class Initialized
DEBUG - 2016-09-19 11:56:08 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:56:08 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:08 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:56:08 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:56:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:56:08 --> Language Class Initialized
DEBUG - 2016-09-19 11:56:08 --> URI Class Initialized
DEBUG - 2016-09-19 11:56:08 --> Router Class Initialized
DEBUG - 2016-09-19 11:56:08 --> Loader Class Initialized
DEBUG - 2016-09-19 11:56:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:56:08 --> Output Class Initialized
DEBUG - 2016-09-19 11:56:08 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:56:08 --> Security Class Initialized
DEBUG - 2016-09-19 11:56:08 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:56:08 --> Input Class Initialized
DEBUG - 2016-09-19 11:56:08 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:56:08 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:08 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:08 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:56:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:56:08 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:08 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:56:08 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:08 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:08 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:56:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:56:08 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:56:08 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:56:08 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:56:08 --> Language Class Initialized
DEBUG - 2016-09-19 11:56:08 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:56:08 --> Loader Class Initialized
DEBUG - 2016-09-19 11:56:08 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:56:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:56:08 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:56:08 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:56:08 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:56:08 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:56:08 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:56:08 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:56:08 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:56:08 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:56:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:56:08 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:56:08 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:56:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:56:08 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:56:08 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:56:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:56:08 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:56:08 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:56:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:56:08 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:56:08 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:56:08 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:56:08 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:56:08 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:56:08 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:56:08 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:56:08 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:56:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:56:08 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:56:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:56:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:56:09 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:56:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:56:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:56:09 --> Session Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:56:09 --> Session routines successfully run
DEBUG - 2016-09-19 11:56:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:56:09 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Config Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:56:09 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:56:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:56:09 --> Controller Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:56:09 --> URI Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:56:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:56:09 --> Router Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:56:09 --> Session Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Output Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:56:09 --> Security Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:56:09 --> Input Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Session routines successfully run
DEBUG - 2016-09-19 11:56:09 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:56:09 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:09 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:56:09 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:09 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:09 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:09 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:09 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:09 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:09 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:09 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:09 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:09 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:56:09 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Language Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-19 11:56:09 --> Loader Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Final output sent to browser
DEBUG - 2016-09-19 11:56:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:56:09 --> Config Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Total execution time: 1.0297
DEBUG - 2016-09-19 11:56:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:56:09 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:56:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:56:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:56:09 --> URI Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:56:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Router Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Controller Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Output Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:56:09 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:56:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:56:09 --> Security Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:56:09 --> Input Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:56:09 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:09 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:56:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:56:09 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:09 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:09 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:56:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:09 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:09 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:56:09 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:56:09 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Language Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Config Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Loader Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:56:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:56:09 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:56:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:56:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-19 11:56:09 --> URI Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:56:09 --> Final output sent to browser
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:56:09 --> Router Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Total execution time: 1.1040
DEBUG - 2016-09-19 11:56:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Output Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:56:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:56:09 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:56:09 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Security Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Input Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:56:09 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:56:09 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:56:09 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:09 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:56:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:56:09 --> Session Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Language Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Loader Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:56:09 --> Session routines successfully run
DEBUG - 2016-09-19 11:56:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:56:09 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:56:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:56:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:56:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:56:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:56:09 --> Controller Class Initialized
DEBUG - 2016-09-19 11:56:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:56:09 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:56:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:56:09 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:56:09 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:56:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:56:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:56:10 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:56:10 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:56:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:56:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:56:10 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:56:10 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:56:10 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:56:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:56:10 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:56:10 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:56:10 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:56:10 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Session Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:56:10 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:56:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:56:10 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:56:10 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Session routines successfully run
DEBUG - 2016-09-19 11:56:10 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:56:10 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:56:10 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:56:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:56:10 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-19 11:56:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:56:10 --> Final output sent to browser
DEBUG - 2016-09-19 11:56:10 --> Total execution time: 0.9001
DEBUG - 2016-09-19 11:56:10 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:56:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:56:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:56:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:56:10 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:56:10 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:56:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:56:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:56:10 --> Controller Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:56:10 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:56:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:56:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:56:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:56:10 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:56:10 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:56:10 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:56:10 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Session Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:56:10 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:56:10 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Session routines successfully run
DEBUG - 2016-09-19 11:56:10 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-19 11:56:10 --> Final output sent to browser
DEBUG - 2016-09-19 11:56:10 --> Total execution time: 0.9504
DEBUG - 2016-09-19 11:56:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:56:10 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:56:10 --> Controller Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:56:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:56:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:56:10 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:56:10 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:56:10 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:10 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-19 11:56:10 --> Final output sent to browser
DEBUG - 2016-09-19 11:56:10 --> Total execution time: 1.0152
DEBUG - 2016-09-19 11:56:11 --> Config Class Initialized
DEBUG - 2016-09-19 11:56:11 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:56:11 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:56:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:56:11 --> URI Class Initialized
DEBUG - 2016-09-19 11:56:11 --> Router Class Initialized
DEBUG - 2016-09-19 11:56:11 --> Output Class Initialized
DEBUG - 2016-09-19 11:56:11 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:56:11 --> Security Class Initialized
DEBUG - 2016-09-19 11:56:11 --> Input Class Initialized
DEBUG - 2016-09-19 11:56:11 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:11 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:11 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:11 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:11 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:11 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:56:11 --> Language Class Initialized
DEBUG - 2016-09-19 11:56:11 --> Loader Class Initialized
DEBUG - 2016-09-19 11:56:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:56:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:56:11 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:56:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:56:11 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:56:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:56:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:56:11 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:56:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:56:11 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:56:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:56:11 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:56:11 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:56:11 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:56:11 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:56:11 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:56:11 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:56:11 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:56:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:56:11 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:56:11 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:56:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:56:11 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:56:11 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:56:11 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:56:11 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:56:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:56:11 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:56:11 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:56:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:56:11 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:56:11 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:56:11 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:56:11 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:56:11 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:56:11 --> Session Class Initialized
DEBUG - 2016-09-19 11:56:11 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:56:11 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:56:11 --> Session routines successfully run
DEBUG - 2016-09-19 11:56:11 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:56:11 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:56:11 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:56:11 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:56:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:56:11 --> Controller Class Initialized
DEBUG - 2016-09-19 11:56:11 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:56:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:56:11 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:56:11 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:56:11 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:56:11 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:56:11 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:11 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:12 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:12 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:12 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:12 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:12 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:12 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-19 11:56:12 --> Final output sent to browser
DEBUG - 2016-09-19 11:56:12 --> Total execution time: 1.1944
DEBUG - 2016-09-19 11:56:25 --> Config Class Initialized
DEBUG - 2016-09-19 11:56:25 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:56:25 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:56:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:56:25 --> URI Class Initialized
DEBUG - 2016-09-19 11:56:25 --> Router Class Initialized
DEBUG - 2016-09-19 11:56:26 --> Output Class Initialized
DEBUG - 2016-09-19 11:56:26 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:56:26 --> Security Class Initialized
DEBUG - 2016-09-19 11:56:26 --> Input Class Initialized
DEBUG - 2016-09-19 11:56:26 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:26 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:26 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:26 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:26 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:26 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:56:26 --> Language Class Initialized
DEBUG - 2016-09-19 11:56:26 --> Loader Class Initialized
DEBUG - 2016-09-19 11:56:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:56:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:56:26 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:56:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:56:26 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:56:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:56:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:56:26 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:56:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:56:26 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:56:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:56:26 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:56:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:56:26 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:56:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:56:26 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:56:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:56:26 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:56:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:56:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:56:26 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:56:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:56:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:56:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:56:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:56:26 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:56:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:56:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:56:26 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:56:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:56:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:56:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:56:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:56:26 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:56:26 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:56:26 --> Session Class Initialized
DEBUG - 2016-09-19 11:56:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:56:26 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:56:26 --> Session routines successfully run
DEBUG - 2016-09-19 11:56:26 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:56:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:56:26 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:56:26 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:56:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:56:26 --> Controller Class Initialized
DEBUG - 2016-09-19 11:56:26 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:56:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:56:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:56:26 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:56:26 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:56:26 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:56:26 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:26 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:26 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:26 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:26 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:26 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:27 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-19 11:56:27 --> Final output sent to browser
DEBUG - 2016-09-19 11:56:27 --> Total execution time: 1.1271
DEBUG - 2016-09-19 11:56:29 --> Config Class Initialized
DEBUG - 2016-09-19 11:56:29 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:56:29 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:56:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:56:29 --> URI Class Initialized
DEBUG - 2016-09-19 11:56:29 --> Router Class Initialized
DEBUG - 2016-09-19 11:56:29 --> Output Class Initialized
DEBUG - 2016-09-19 11:56:29 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:56:29 --> Security Class Initialized
DEBUG - 2016-09-19 11:56:29 --> Input Class Initialized
DEBUG - 2016-09-19 11:56:29 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:29 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:29 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:29 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:29 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:29 --> XSS Filtering completed
DEBUG - 2016-09-19 11:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:56:29 --> Language Class Initialized
DEBUG - 2016-09-19 11:56:29 --> Loader Class Initialized
DEBUG - 2016-09-19 11:56:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:56:29 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:56:29 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:56:29 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:56:29 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:56:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:56:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:56:29 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:56:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:56:29 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:56:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:56:29 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:56:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:56:29 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:56:29 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:56:29 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:56:29 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:56:29 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:56:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:56:29 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:56:29 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:56:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:56:29 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:56:29 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:56:29 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:56:29 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:56:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:56:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:56:29 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:56:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:56:29 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:56:29 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:56:29 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:56:29 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:56:29 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:56:29 --> Session Class Initialized
DEBUG - 2016-09-19 11:56:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:56:29 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:56:29 --> Session routines successfully run
DEBUG - 2016-09-19 11:56:29 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:56:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:56:29 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:56:29 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:56:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:56:29 --> Controller Class Initialized
DEBUG - 2016-09-19 11:56:29 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:56:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:56:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:56:29 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:56:29 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:56:29 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:56:30 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:30 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:30 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:30 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:30 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:30 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:30 --> Model Class Initialized
DEBUG - 2016-09-19 11:56:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-19 11:56:30 --> Final output sent to browser
DEBUG - 2016-09-19 11:56:30 --> Total execution time: 1.1046
DEBUG - 2016-09-19 11:58:15 --> Config Class Initialized
DEBUG - 2016-09-19 11:58:15 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:58:15 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:58:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:58:15 --> URI Class Initialized
DEBUG - 2016-09-19 11:58:15 --> Router Class Initialized
DEBUG - 2016-09-19 11:58:15 --> Output Class Initialized
DEBUG - 2016-09-19 11:58:15 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:58:15 --> Security Class Initialized
DEBUG - 2016-09-19 11:58:15 --> Input Class Initialized
DEBUG - 2016-09-19 11:58:15 --> XSS Filtering completed
DEBUG - 2016-09-19 11:58:15 --> XSS Filtering completed
DEBUG - 2016-09-19 11:58:15 --> XSS Filtering completed
DEBUG - 2016-09-19 11:58:15 --> XSS Filtering completed
DEBUG - 2016-09-19 11:58:15 --> XSS Filtering completed
DEBUG - 2016-09-19 11:58:15 --> XSS Filtering completed
DEBUG - 2016-09-19 11:58:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:58:15 --> Language Class Initialized
DEBUG - 2016-09-19 11:58:15 --> Loader Class Initialized
DEBUG - 2016-09-19 11:58:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:58:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:58:15 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:58:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:58:15 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:58:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:58:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:58:16 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:58:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:58:16 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:58:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:58:16 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:58:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:58:16 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:58:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:58:16 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:58:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:58:16 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:58:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:58:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:58:16 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:58:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:58:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:58:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:58:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:58:16 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:58:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:58:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:58:16 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:58:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:58:16 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:58:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:58:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:58:16 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:58:16 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:58:16 --> Session Class Initialized
DEBUG - 2016-09-19 11:58:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:58:16 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:58:16 --> Session routines successfully run
DEBUG - 2016-09-19 11:58:16 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:58:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:58:16 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:58:16 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:58:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:58:16 --> Controller Class Initialized
DEBUG - 2016-09-19 11:58:16 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:58:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:58:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:58:16 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:58:16 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:58:16 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:58:16 --> Model Class Initialized
DEBUG - 2016-09-19 11:58:16 --> Model Class Initialized
DEBUG - 2016-09-19 11:58:16 --> Model Class Initialized
DEBUG - 2016-09-19 11:58:16 --> Model Class Initialized
DEBUG - 2016-09-19 11:58:16 --> Model Class Initialized
DEBUG - 2016-09-19 11:58:16 --> Model Class Initialized
DEBUG - 2016-09-19 11:58:16 --> Model Class Initialized
DEBUG - 2016-09-19 11:58:16 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-19 11:58:16 --> Final output sent to browser
DEBUG - 2016-09-19 11:58:16 --> Total execution time: 1.1060
DEBUG - 2016-09-19 11:58:26 --> Config Class Initialized
DEBUG - 2016-09-19 11:58:26 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:58:26 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:58:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:58:26 --> URI Class Initialized
DEBUG - 2016-09-19 11:58:26 --> Router Class Initialized
DEBUG - 2016-09-19 11:58:26 --> Output Class Initialized
DEBUG - 2016-09-19 11:58:26 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:58:26 --> Security Class Initialized
DEBUG - 2016-09-19 11:58:26 --> Input Class Initialized
DEBUG - 2016-09-19 11:58:26 --> XSS Filtering completed
DEBUG - 2016-09-19 11:58:26 --> XSS Filtering completed
DEBUG - 2016-09-19 11:58:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:58:27 --> Language Class Initialized
DEBUG - 2016-09-19 11:58:27 --> Loader Class Initialized
DEBUG - 2016-09-19 11:58:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:58:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:58:27 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:58:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:58:27 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:58:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:58:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:58:27 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:58:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:58:27 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:58:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:58:27 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:58:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:58:27 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:58:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:58:27 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:58:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:58:27 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:58:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:58:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:58:27 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:58:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:58:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:58:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:58:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:58:27 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:58:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:58:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:58:27 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:58:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:58:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:58:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:58:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:58:27 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:58:27 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:58:27 --> Session Class Initialized
DEBUG - 2016-09-19 11:58:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:58:27 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:58:27 --> Session routines successfully run
DEBUG - 2016-09-19 11:58:27 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:58:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:58:27 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:58:27 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:58:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:58:27 --> Controller Class Initialized
DEBUG - 2016-09-19 11:58:27 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:58:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:58:27 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:58:27 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:58:27 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:58:27 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:58:27 --> Model Class Initialized
DEBUG - 2016-09-19 11:58:27 --> Model Class Initialized
DEBUG - 2016-09-19 11:58:27 --> Model Class Initialized
ERROR - 2016-09-19 11:58:27 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 11:58:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-19 11:58:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:58:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:58:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:58:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:58:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:58:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:58:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:58:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:58:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:58:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:58:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:58:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:58:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:58:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:58:28 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-19 11:58:28 --> Final output sent to browser
DEBUG - 2016-09-19 11:58:28 --> Total execution time: 1.1090
DEBUG - 2016-09-19 11:59:17 --> Config Class Initialized
DEBUG - 2016-09-19 11:59:17 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:59:17 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:59:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:59:17 --> URI Class Initialized
DEBUG - 2016-09-19 11:59:17 --> Router Class Initialized
DEBUG - 2016-09-19 11:59:17 --> No URI present. Default controller set.
DEBUG - 2016-09-19 11:59:17 --> Output Class Initialized
DEBUG - 2016-09-19 11:59:17 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:59:17 --> Security Class Initialized
DEBUG - 2016-09-19 11:59:17 --> Input Class Initialized
DEBUG - 2016-09-19 11:59:17 --> XSS Filtering completed
DEBUG - 2016-09-19 11:59:17 --> XSS Filtering completed
DEBUG - 2016-09-19 11:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:59:17 --> Language Class Initialized
DEBUG - 2016-09-19 11:59:17 --> Loader Class Initialized
DEBUG - 2016-09-19 11:59:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:59:17 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:59:17 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:59:18 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:59:18 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:59:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:59:18 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:59:18 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:59:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:59:18 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:59:18 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:59:18 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:59:18 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:59:18 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:59:18 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:59:18 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:59:18 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:59:18 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:59:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:59:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:59:18 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:59:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:59:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:59:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:59:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:59:18 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:59:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:59:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:59:18 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:59:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:59:18 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:59:18 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:59:18 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:59:18 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:59:18 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:59:18 --> Session Class Initialized
DEBUG - 2016-09-19 11:59:18 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:59:18 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:59:18 --> Session routines successfully run
DEBUG - 2016-09-19 11:59:18 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:59:18 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:59:18 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:59:18 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:59:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:59:18 --> Controller Class Initialized
DEBUG - 2016-09-19 11:59:18 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:59:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:59:18 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:59:18 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:59:18 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:59:18 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:59:18 --> Model Class Initialized
DEBUG - 2016-09-19 11:59:18 --> Model Class Initialized
DEBUG - 2016-09-19 11:59:18 --> Model Class Initialized
ERROR - 2016-09-19 11:59:18 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 11:59:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-19 11:59:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-19 11:59:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:59:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:59:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:59:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:59:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:59:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 11:59:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 11:59:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:59:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:59:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:59:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:59:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:59:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:59:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:59:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 11:59:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 11:59:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:59:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:59:18 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-19 11:59:18 --> Final output sent to browser
DEBUG - 2016-09-19 11:59:19 --> Total execution time: 1.0434
DEBUG - 2016-09-19 11:59:19 --> Config Class Initialized
DEBUG - 2016-09-19 11:59:19 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:59:19 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:59:19 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:59:19 --> URI Class Initialized
DEBUG - 2016-09-19 11:59:19 --> Router Class Initialized
DEBUG - 2016-09-19 11:59:19 --> Output Class Initialized
DEBUG - 2016-09-19 11:59:19 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:59:19 --> Security Class Initialized
DEBUG - 2016-09-19 11:59:19 --> Input Class Initialized
DEBUG - 2016-09-19 11:59:19 --> XSS Filtering completed
DEBUG - 2016-09-19 11:59:19 --> XSS Filtering completed
DEBUG - 2016-09-19 11:59:19 --> XSS Filtering completed
DEBUG - 2016-09-19 11:59:19 --> XSS Filtering completed
DEBUG - 2016-09-19 11:59:19 --> XSS Filtering completed
DEBUG - 2016-09-19 11:59:19 --> XSS Filtering completed
DEBUG - 2016-09-19 11:59:19 --> XSS Filtering completed
DEBUG - 2016-09-19 11:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:59:19 --> Language Class Initialized
DEBUG - 2016-09-19 11:59:19 --> Loader Class Initialized
DEBUG - 2016-09-19 11:59:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:59:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:59:19 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:59:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:59:19 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:59:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:59:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:59:19 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:59:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:59:19 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:59:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:59:19 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:59:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:59:19 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:59:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:59:19 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:59:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:59:19 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:59:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:59:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:59:19 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:59:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:59:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:59:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:59:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:59:19 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:59:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:59:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:59:19 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:59:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:59:19 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:59:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:59:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:59:19 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:59:19 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:59:19 --> Session Class Initialized
DEBUG - 2016-09-19 11:59:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:59:19 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:59:19 --> Session routines successfully run
DEBUG - 2016-09-19 11:59:19 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:59:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:59:19 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:59:19 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:59:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:59:19 --> Controller Class Initialized
DEBUG - 2016-09-19 11:59:19 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:59:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:59:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:59:20 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:59:20 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:59:20 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:59:20 --> Model Class Initialized
DEBUG - 2016-09-19 11:59:20 --> Model Class Initialized
DEBUG - 2016-09-19 11:59:20 --> Model Class Initialized
DEBUG - 2016-09-19 11:59:20 --> Model Class Initialized
DEBUG - 2016-09-19 11:59:20 --> Model Class Initialized
DEBUG - 2016-09-19 11:59:20 --> Model Class Initialized
DEBUG - 2016-09-19 11:59:20 --> Model Class Initialized
DEBUG - 2016-09-19 11:59:20 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-19 11:59:20 --> Final output sent to browser
DEBUG - 2016-09-19 11:59:20 --> Total execution time: 1.0581
DEBUG - 2016-09-19 11:59:28 --> Config Class Initialized
DEBUG - 2016-09-19 11:59:28 --> Hooks Class Initialized
DEBUG - 2016-09-19 11:59:28 --> Utf8 Class Initialized
DEBUG - 2016-09-19 11:59:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 11:59:28 --> URI Class Initialized
DEBUG - 2016-09-19 11:59:28 --> Router Class Initialized
DEBUG - 2016-09-19 11:59:28 --> Output Class Initialized
DEBUG - 2016-09-19 11:59:28 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 11:59:28 --> Security Class Initialized
DEBUG - 2016-09-19 11:59:28 --> Input Class Initialized
DEBUG - 2016-09-19 11:59:28 --> XSS Filtering completed
DEBUG - 2016-09-19 11:59:28 --> XSS Filtering completed
DEBUG - 2016-09-19 11:59:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 11:59:28 --> Language Class Initialized
DEBUG - 2016-09-19 11:59:28 --> Loader Class Initialized
DEBUG - 2016-09-19 11:59:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 11:59:28 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 11:59:28 --> Helper loaded: url_helper
DEBUG - 2016-09-19 11:59:28 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 11:59:28 --> Helper loaded: file_helper
DEBUG - 2016-09-19 11:59:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:59:28 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 11:59:28 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 11:59:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 11:59:28 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 11:59:28 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 11:59:29 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:59:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 11:59:29 --> Helper loaded: common_helper
DEBUG - 2016-09-19 11:59:29 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 11:59:29 --> Helper loaded: form_helper
DEBUG - 2016-09-19 11:59:29 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 11:59:29 --> Helper loaded: security_helper
DEBUG - 2016-09-19 11:59:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:59:29 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 11:59:29 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 11:59:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 11:59:29 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 11:59:29 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 11:59:29 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 11:59:29 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 11:59:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:59:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 11:59:29 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 11:59:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 11:59:29 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 11:59:29 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 11:59:29 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 11:59:29 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 11:59:29 --> Database Driver Class Initialized
DEBUG - 2016-09-19 11:59:29 --> Session Class Initialized
DEBUG - 2016-09-19 11:59:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 11:59:29 --> Helper loaded: string_helper
DEBUG - 2016-09-19 11:59:29 --> Session routines successfully run
DEBUG - 2016-09-19 11:59:29 --> Native_session Class Initialized
DEBUG - 2016-09-19 11:59:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 11:59:29 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:59:29 --> Form Validation Class Initialized
DEBUG - 2016-09-19 11:59:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 11:59:29 --> Controller Class Initialized
DEBUG - 2016-09-19 11:59:29 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 11:59:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 11:59:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 11:59:29 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:59:29 --> Carabiner: library configured.
DEBUG - 2016-09-19 11:59:29 --> User Agent Class Initialized
DEBUG - 2016-09-19 11:59:29 --> Model Class Initialized
DEBUG - 2016-09-19 11:59:29 --> Model Class Initialized
DEBUG - 2016-09-19 11:59:29 --> Model Class Initialized
ERROR - 2016-09-19 11:59:29 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 11:59:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-19 11:59:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:59:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:59:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:59:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:59:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:59:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:59:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:59:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 11:59:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 11:59:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 11:59:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 11:59:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 11:59:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 11:59:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 11:59:29 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-19 11:59:29 --> Final output sent to browser
DEBUG - 2016-09-19 11:59:29 --> Total execution time: 1.1085
DEBUG - 2016-09-19 12:04:05 --> Config Class Initialized
DEBUG - 2016-09-19 12:04:05 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:04:05 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:04:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:04:05 --> URI Class Initialized
DEBUG - 2016-09-19 12:04:05 --> Router Class Initialized
DEBUG - 2016-09-19 12:04:05 --> No URI present. Default controller set.
DEBUG - 2016-09-19 12:04:05 --> Output Class Initialized
DEBUG - 2016-09-19 12:04:05 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:04:05 --> Security Class Initialized
DEBUG - 2016-09-19 12:04:05 --> Input Class Initialized
DEBUG - 2016-09-19 12:04:05 --> XSS Filtering completed
DEBUG - 2016-09-19 12:04:05 --> XSS Filtering completed
DEBUG - 2016-09-19 12:04:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:04:05 --> Language Class Initialized
DEBUG - 2016-09-19 12:04:05 --> Loader Class Initialized
DEBUG - 2016-09-19 12:04:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:04:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:04:05 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:04:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:04:05 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:04:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:04:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:04:06 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:04:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:04:06 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:04:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:04:06 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:04:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:04:06 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:04:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:04:06 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:04:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:04:06 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:04:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:04:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:04:06 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:04:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:04:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:04:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:04:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:04:06 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:04:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:04:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:04:06 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:04:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:04:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:04:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:04:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:04:06 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:04:06 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:04:06 --> Session Class Initialized
DEBUG - 2016-09-19 12:04:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:04:06 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:04:06 --> Session routines successfully run
DEBUG - 2016-09-19 12:04:06 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:04:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:04:06 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:04:06 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:04:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:04:06 --> Controller Class Initialized
DEBUG - 2016-09-19 12:04:06 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:04:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:04:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:04:06 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:04:06 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:04:06 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:04:06 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:06 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:06 --> Model Class Initialized
ERROR - 2016-09-19 12:04:06 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 12:04:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-19 12:04:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-19 12:04:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:04:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:04:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:04:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:04:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:04:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 12:04:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 12:04:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:04:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:04:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:04:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:04:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:04:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:04:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:04:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 12:04:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 12:04:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:04:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:04:06 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-19 12:04:06 --> Final output sent to browser
DEBUG - 2016-09-19 12:04:07 --> Total execution time: 1.1239
DEBUG - 2016-09-19 12:04:07 --> Config Class Initialized
DEBUG - 2016-09-19 12:04:07 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:04:07 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:04:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:04:07 --> URI Class Initialized
DEBUG - 2016-09-19 12:04:07 --> Router Class Initialized
DEBUG - 2016-09-19 12:04:07 --> Output Class Initialized
DEBUG - 2016-09-19 12:04:07 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:04:07 --> Security Class Initialized
DEBUG - 2016-09-19 12:04:07 --> Input Class Initialized
DEBUG - 2016-09-19 12:04:07 --> XSS Filtering completed
DEBUG - 2016-09-19 12:04:07 --> XSS Filtering completed
DEBUG - 2016-09-19 12:04:07 --> XSS Filtering completed
DEBUG - 2016-09-19 12:04:07 --> XSS Filtering completed
DEBUG - 2016-09-19 12:04:07 --> XSS Filtering completed
DEBUG - 2016-09-19 12:04:07 --> XSS Filtering completed
DEBUG - 2016-09-19 12:04:07 --> XSS Filtering completed
DEBUG - 2016-09-19 12:04:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:04:07 --> Language Class Initialized
DEBUG - 2016-09-19 12:04:07 --> Loader Class Initialized
DEBUG - 2016-09-19 12:04:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:04:07 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:04:07 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:04:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:04:07 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:04:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:04:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:04:07 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:04:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:04:07 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:04:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:04:07 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:04:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:04:07 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:04:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:04:07 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:04:07 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:04:07 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:04:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:04:07 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:04:07 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:04:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:04:07 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:04:07 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:04:07 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:04:07 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:04:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:04:07 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:04:07 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:04:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:04:07 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:04:07 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:04:07 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:04:07 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:04:07 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:04:07 --> Session Class Initialized
DEBUG - 2016-09-19 12:04:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:04:07 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:04:07 --> Session routines successfully run
DEBUG - 2016-09-19 12:04:08 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:04:08 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:04:08 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:04:08 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:04:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:04:08 --> Controller Class Initialized
DEBUG - 2016-09-19 12:04:08 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:04:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:04:08 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:04:08 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:04:08 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:04:08 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:04:08 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:08 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:08 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:08 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:08 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:08 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:08 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:08 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-19 12:04:08 --> Final output sent to browser
DEBUG - 2016-09-19 12:04:08 --> Total execution time: 1.1478
DEBUG - 2016-09-19 12:04:09 --> Config Class Initialized
DEBUG - 2016-09-19 12:04:09 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:04:09 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:04:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:04:09 --> URI Class Initialized
DEBUG - 2016-09-19 12:04:09 --> Router Class Initialized
DEBUG - 2016-09-19 12:04:09 --> Output Class Initialized
DEBUG - 2016-09-19 12:04:09 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:04:09 --> Security Class Initialized
DEBUG - 2016-09-19 12:04:09 --> Input Class Initialized
DEBUG - 2016-09-19 12:04:09 --> XSS Filtering completed
DEBUG - 2016-09-19 12:04:09 --> XSS Filtering completed
DEBUG - 2016-09-19 12:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:04:09 --> Language Class Initialized
DEBUG - 2016-09-19 12:04:09 --> Loader Class Initialized
DEBUG - 2016-09-19 12:04:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:04:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:04:09 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:04:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:04:09 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:04:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:04:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:04:10 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:04:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:04:10 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:04:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:04:10 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:04:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:04:10 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:04:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:04:10 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:04:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:04:10 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:04:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:04:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:04:10 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:04:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:04:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:04:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:04:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:04:10 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:04:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:04:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:04:10 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:04:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:04:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:04:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:04:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:04:10 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:04:10 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:04:10 --> Session Class Initialized
DEBUG - 2016-09-19 12:04:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:04:10 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:04:10 --> Session routines successfully run
DEBUG - 2016-09-19 12:04:10 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:04:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:04:10 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:04:10 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:04:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:04:10 --> Controller Class Initialized
DEBUG - 2016-09-19 12:04:10 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:04:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:04:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:04:10 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:04:10 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:04:10 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:04:10 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:10 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:10 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:10 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:10 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:10 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:10 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:10 --> Model Class Initialized
ERROR - 2016-09-19 12:04:10 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 12:04:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-19 12:04:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:04:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:04:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:04:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:04:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:04:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:04:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:04:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:04:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:04:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:04:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:04:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:04:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:04:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:04:11 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/26764e7c38cfdb071ebc36690ecd8747
DEBUG - 2016-09-19 12:04:11 --> Final output sent to browser
DEBUG - 2016-09-19 12:04:11 --> Total execution time: 1.2190
DEBUG - 2016-09-19 12:04:27 --> Config Class Initialized
DEBUG - 2016-09-19 12:04:27 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:04:27 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:04:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:04:27 --> URI Class Initialized
DEBUG - 2016-09-19 12:04:27 --> Router Class Initialized
DEBUG - 2016-09-19 12:04:27 --> Output Class Initialized
DEBUG - 2016-09-19 12:04:27 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:04:27 --> Security Class Initialized
DEBUG - 2016-09-19 12:04:27 --> Input Class Initialized
DEBUG - 2016-09-19 12:04:27 --> XSS Filtering completed
DEBUG - 2016-09-19 12:04:27 --> XSS Filtering completed
DEBUG - 2016-09-19 12:04:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:04:27 --> Language Class Initialized
DEBUG - 2016-09-19 12:04:27 --> Loader Class Initialized
DEBUG - 2016-09-19 12:04:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:04:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:04:27 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:04:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:04:27 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:04:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:04:28 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:04:28 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:04:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:04:28 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:04:28 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:04:28 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:04:28 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:04:28 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:04:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:04:28 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:04:28 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:04:28 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:04:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:04:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:04:28 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:04:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:04:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:04:28 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:04:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:04:28 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:04:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:04:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:04:28 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:04:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:04:28 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:04:28 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:04:28 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:04:28 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:04:28 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:04:28 --> Session Class Initialized
DEBUG - 2016-09-19 12:04:28 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:04:28 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:04:28 --> Session routines successfully run
DEBUG - 2016-09-19 12:04:28 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:04:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:04:28 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:04:28 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:04:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:04:28 --> Controller Class Initialized
DEBUG - 2016-09-19 12:04:28 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:04:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:04:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:04:28 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:04:28 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:04:28 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:04:28 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:28 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:28 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:28 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:28 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:28 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:28 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:28 --> Model Class Initialized
ERROR - 2016-09-19 12:04:28 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 12:04:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-19 12:04:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:04:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:04:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:04:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:04:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:04:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:04:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:04:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:04:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:04:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:04:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:04:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:04:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:04:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:04:29 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/26764e7c38cfdb071ebc36690ecd8747
DEBUG - 2016-09-19 12:04:29 --> Final output sent to browser
DEBUG - 2016-09-19 12:04:29 --> Total execution time: 1.2605
DEBUG - 2016-09-19 12:04:30 --> Config Class Initialized
DEBUG - 2016-09-19 12:04:30 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:04:30 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:04:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:04:30 --> URI Class Initialized
DEBUG - 2016-09-19 12:04:30 --> Router Class Initialized
DEBUG - 2016-09-19 12:04:30 --> Output Class Initialized
DEBUG - 2016-09-19 12:04:30 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:04:30 --> Security Class Initialized
DEBUG - 2016-09-19 12:04:30 --> Input Class Initialized
DEBUG - 2016-09-19 12:04:30 --> XSS Filtering completed
DEBUG - 2016-09-19 12:04:30 --> XSS Filtering completed
DEBUG - 2016-09-19 12:04:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:04:30 --> Language Class Initialized
DEBUG - 2016-09-19 12:04:31 --> Loader Class Initialized
DEBUG - 2016-09-19 12:04:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:04:31 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:04:31 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:04:31 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:04:31 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:04:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:04:31 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:04:31 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:04:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:04:31 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:04:31 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:04:31 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:04:31 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:04:31 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:04:31 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:04:31 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:04:31 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:04:31 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:04:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:04:31 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:04:31 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:04:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:04:31 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:04:31 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:04:31 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:04:31 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:04:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:04:31 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:04:31 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:04:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:04:31 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:04:31 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:04:31 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:04:31 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:04:31 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:04:31 --> Session Class Initialized
DEBUG - 2016-09-19 12:04:31 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:04:31 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:04:31 --> Session routines successfully run
DEBUG - 2016-09-19 12:04:31 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:04:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:04:31 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:04:31 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:04:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:04:31 --> Controller Class Initialized
DEBUG - 2016-09-19 12:04:31 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:04:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:04:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:04:31 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:04:31 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:04:31 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:04:31 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:31 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:31 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:31 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:31 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:31 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:31 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:31 --> Model Class Initialized
ERROR - 2016-09-19 12:04:31 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 12:04:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-19 12:04:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:04:32 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/26764e7c38cfdb071ebc36690ecd8747
DEBUG - 2016-09-19 12:04:32 --> Final output sent to browser
DEBUG - 2016-09-19 12:04:32 --> Total execution time: 1.2416
DEBUG - 2016-09-19 12:04:43 --> Config Class Initialized
DEBUG - 2016-09-19 12:04:43 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:04:43 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:04:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:04:43 --> URI Class Initialized
DEBUG - 2016-09-19 12:04:43 --> Router Class Initialized
DEBUG - 2016-09-19 12:04:43 --> Output Class Initialized
DEBUG - 2016-09-19 12:04:43 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:04:43 --> Security Class Initialized
DEBUG - 2016-09-19 12:04:43 --> Input Class Initialized
DEBUG - 2016-09-19 12:04:43 --> XSS Filtering completed
DEBUG - 2016-09-19 12:04:43 --> XSS Filtering completed
DEBUG - 2016-09-19 12:04:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:04:44 --> Language Class Initialized
DEBUG - 2016-09-19 12:04:44 --> Loader Class Initialized
DEBUG - 2016-09-19 12:04:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:04:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:04:44 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:04:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:04:44 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:04:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:04:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:04:44 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:04:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:04:44 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:04:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:04:44 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:04:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:04:44 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:04:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:04:44 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:04:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:04:44 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:04:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:04:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:04:44 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:04:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:04:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:04:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:04:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:04:44 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:04:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:04:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:04:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:04:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:04:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:04:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:04:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:04:44 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:04:44 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:04:44 --> Session Class Initialized
DEBUG - 2016-09-19 12:04:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:04:44 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:04:44 --> Session routines successfully run
DEBUG - 2016-09-19 12:04:44 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:04:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:04:44 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:04:44 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:04:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:04:44 --> Controller Class Initialized
DEBUG - 2016-09-19 12:04:44 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:04:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:04:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:04:44 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:04:44 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:04:44 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:04:44 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:44 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:44 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:44 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:44 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:44 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:44 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:44 --> Model Class Initialized
ERROR - 2016-09-19 12:04:45 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 12:04:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-19 12:04:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:04:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:04:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:04:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:04:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:04:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:04:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:04:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:04:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:04:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:04:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:04:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:04:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:04:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:04:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/26764e7c38cfdb071ebc36690ecd8747
DEBUG - 2016-09-19 12:04:45 --> Final output sent to browser
DEBUG - 2016-09-19 12:04:45 --> Total execution time: 1.2978
DEBUG - 2016-09-19 12:04:49 --> Config Class Initialized
DEBUG - 2016-09-19 12:04:50 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:04:50 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:04:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:04:50 --> URI Class Initialized
DEBUG - 2016-09-19 12:04:50 --> Router Class Initialized
DEBUG - 2016-09-19 12:04:50 --> Output Class Initialized
DEBUG - 2016-09-19 12:04:50 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:04:50 --> Security Class Initialized
DEBUG - 2016-09-19 12:04:50 --> Input Class Initialized
DEBUG - 2016-09-19 12:04:50 --> XSS Filtering completed
DEBUG - 2016-09-19 12:04:50 --> XSS Filtering completed
DEBUG - 2016-09-19 12:04:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:04:50 --> Language Class Initialized
DEBUG - 2016-09-19 12:04:50 --> Loader Class Initialized
DEBUG - 2016-09-19 12:04:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:04:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:04:50 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:04:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:04:50 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:04:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:04:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:04:50 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:04:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:04:50 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:04:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:04:50 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:04:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:04:50 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:04:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:04:50 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:04:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:04:50 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:04:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:04:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:04:50 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:04:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:04:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:04:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:04:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:04:50 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:04:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:04:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:04:50 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:04:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:04:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:04:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:04:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:04:50 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:04:50 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:04:50 --> Session Class Initialized
DEBUG - 2016-09-19 12:04:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:04:50 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:04:50 --> Session routines successfully run
DEBUG - 2016-09-19 12:04:50 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:04:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:04:51 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:04:51 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:04:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:04:51 --> Controller Class Initialized
DEBUG - 2016-09-19 12:04:51 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:04:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:04:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:04:51 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:04:51 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:04:51 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:04:51 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:51 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:51 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:51 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:51 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:51 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:51 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:51 --> Model Class Initialized
ERROR - 2016-09-19 12:04:51 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 12:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-19 12:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:04:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:04:51 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/26764e7c38cfdb071ebc36690ecd8747
DEBUG - 2016-09-19 12:04:51 --> Final output sent to browser
DEBUG - 2016-09-19 12:04:51 --> Total execution time: 1.3389
DEBUG - 2016-09-19 12:04:53 --> Config Class Initialized
DEBUG - 2016-09-19 12:04:53 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:04:53 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:04:53 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:04:53 --> URI Class Initialized
DEBUG - 2016-09-19 12:04:53 --> Router Class Initialized
DEBUG - 2016-09-19 12:04:53 --> Output Class Initialized
DEBUG - 2016-09-19 12:04:53 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:04:53 --> Security Class Initialized
DEBUG - 2016-09-19 12:04:53 --> Input Class Initialized
DEBUG - 2016-09-19 12:04:53 --> XSS Filtering completed
DEBUG - 2016-09-19 12:04:53 --> XSS Filtering completed
DEBUG - 2016-09-19 12:04:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:04:53 --> Language Class Initialized
DEBUG - 2016-09-19 12:04:53 --> Loader Class Initialized
DEBUG - 2016-09-19 12:04:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:04:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:04:53 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:04:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:04:53 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:04:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:04:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:04:53 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:04:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:04:53 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:04:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:04:54 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:04:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:04:54 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:04:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:04:54 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:04:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:04:54 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:04:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:04:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:04:54 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:04:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:04:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:04:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:04:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:04:54 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:04:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:04:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:04:54 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:04:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:04:54 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:04:54 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:04:54 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:04:54 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:04:54 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:04:54 --> Session Class Initialized
DEBUG - 2016-09-19 12:04:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:04:54 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:04:54 --> Session routines successfully run
DEBUG - 2016-09-19 12:04:54 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:04:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:04:54 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:04:54 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:04:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:04:54 --> Controller Class Initialized
DEBUG - 2016-09-19 12:04:54 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:04:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:04:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:04:54 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:04:54 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:04:54 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:04:54 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:54 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:54 --> Model Class Initialized
ERROR - 2016-09-19 12:04:54 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 12:04:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-19 12:04:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:04:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:04:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:04:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:04:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:04:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:04:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:04:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:04:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:04:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:04:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:04:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:04:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:04:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:04:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-19 12:04:55 --> Final output sent to browser
DEBUG - 2016-09-19 12:04:55 --> Total execution time: 1.2522
DEBUG - 2016-09-19 12:04:58 --> Config Class Initialized
DEBUG - 2016-09-19 12:04:58 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:04:58 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:04:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:04:58 --> URI Class Initialized
DEBUG - 2016-09-19 12:04:58 --> Router Class Initialized
DEBUG - 2016-09-19 12:04:58 --> No URI present. Default controller set.
DEBUG - 2016-09-19 12:04:58 --> Output Class Initialized
DEBUG - 2016-09-19 12:04:58 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:04:58 --> Security Class Initialized
DEBUG - 2016-09-19 12:04:58 --> Input Class Initialized
DEBUG - 2016-09-19 12:04:58 --> XSS Filtering completed
DEBUG - 2016-09-19 12:04:58 --> XSS Filtering completed
DEBUG - 2016-09-19 12:04:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:04:58 --> Language Class Initialized
DEBUG - 2016-09-19 12:04:58 --> Loader Class Initialized
DEBUG - 2016-09-19 12:04:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:04:58 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:04:58 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:04:58 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:04:58 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:04:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:04:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:04:58 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:04:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:04:58 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:04:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:04:58 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:04:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:04:58 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:04:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:04:58 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:04:58 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:04:58 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:04:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:04:58 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:04:58 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:04:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:04:58 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:04:58 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:04:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:04:58 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:04:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:04:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:04:59 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:04:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:04:59 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:04:59 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:04:59 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:04:59 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:04:59 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:04:59 --> Session Class Initialized
DEBUG - 2016-09-19 12:04:59 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:04:59 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:04:59 --> Session routines successfully run
DEBUG - 2016-09-19 12:04:59 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:04:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:04:59 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:04:59 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:04:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:04:59 --> Controller Class Initialized
DEBUG - 2016-09-19 12:04:59 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:04:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:04:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:04:59 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:04:59 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:04:59 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:04:59 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:59 --> Model Class Initialized
DEBUG - 2016-09-19 12:04:59 --> Model Class Initialized
ERROR - 2016-09-19 12:04:59 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 12:04:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-19 12:04:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-19 12:04:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:04:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:04:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:04:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:04:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:04:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 12:04:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 12:04:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:04:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:04:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:04:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:04:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:04:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:04:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:04:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 12:04:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 12:04:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:04:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:04:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-19 12:04:59 --> Final output sent to browser
DEBUG - 2016-09-19 12:04:59 --> Total execution time: 1.2642
DEBUG - 2016-09-19 12:04:59 --> Config Class Initialized
DEBUG - 2016-09-19 12:04:59 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:04:59 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:04:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:04:59 --> URI Class Initialized
DEBUG - 2016-09-19 12:05:00 --> Router Class Initialized
DEBUG - 2016-09-19 12:05:00 --> Output Class Initialized
DEBUG - 2016-09-19 12:05:00 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:05:00 --> Security Class Initialized
DEBUG - 2016-09-19 12:05:00 --> Input Class Initialized
DEBUG - 2016-09-19 12:05:00 --> XSS Filtering completed
DEBUG - 2016-09-19 12:05:00 --> XSS Filtering completed
DEBUG - 2016-09-19 12:05:00 --> XSS Filtering completed
DEBUG - 2016-09-19 12:05:00 --> XSS Filtering completed
DEBUG - 2016-09-19 12:05:00 --> XSS Filtering completed
DEBUG - 2016-09-19 12:05:00 --> XSS Filtering completed
DEBUG - 2016-09-19 12:05:00 --> XSS Filtering completed
DEBUG - 2016-09-19 12:05:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:05:00 --> Language Class Initialized
DEBUG - 2016-09-19 12:05:00 --> Loader Class Initialized
DEBUG - 2016-09-19 12:05:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:05:00 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:05:00 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:05:00 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:05:00 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:05:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:05:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:05:00 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:05:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:05:00 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:05:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:05:00 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:05:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:05:00 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:05:00 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:05:00 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:05:00 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:05:00 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:05:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:05:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:05:00 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:05:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:05:00 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:05:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:05:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:05:00 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:05:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:05:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:05:00 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:05:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:05:00 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:05:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:05:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:05:00 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:05:00 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:05:00 --> Session Class Initialized
DEBUG - 2016-09-19 12:05:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:05:00 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:05:00 --> Session routines successfully run
DEBUG - 2016-09-19 12:05:00 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:05:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:05:00 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:05:00 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:05:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:05:01 --> Controller Class Initialized
DEBUG - 2016-09-19 12:05:01 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:05:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:05:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:05:01 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:05:01 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:05:01 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:05:01 --> Model Class Initialized
DEBUG - 2016-09-19 12:05:01 --> Model Class Initialized
DEBUG - 2016-09-19 12:05:01 --> Model Class Initialized
DEBUG - 2016-09-19 12:05:01 --> Model Class Initialized
DEBUG - 2016-09-19 12:05:01 --> Model Class Initialized
DEBUG - 2016-09-19 12:05:01 --> Model Class Initialized
DEBUG - 2016-09-19 12:05:01 --> Model Class Initialized
DEBUG - 2016-09-19 12:05:01 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-19 12:05:01 --> Final output sent to browser
DEBUG - 2016-09-19 12:05:01 --> Total execution time: 1.3433
DEBUG - 2016-09-19 12:05:02 --> Config Class Initialized
DEBUG - 2016-09-19 12:05:02 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:05:02 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:05:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:05:02 --> URI Class Initialized
DEBUG - 2016-09-19 12:05:02 --> Router Class Initialized
DEBUG - 2016-09-19 12:05:02 --> Output Class Initialized
DEBUG - 2016-09-19 12:05:02 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:05:03 --> Security Class Initialized
DEBUG - 2016-09-19 12:05:03 --> Input Class Initialized
DEBUG - 2016-09-19 12:05:03 --> XSS Filtering completed
DEBUG - 2016-09-19 12:05:03 --> XSS Filtering completed
DEBUG - 2016-09-19 12:05:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:05:03 --> Language Class Initialized
DEBUG - 2016-09-19 12:05:03 --> Loader Class Initialized
DEBUG - 2016-09-19 12:05:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:05:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:05:03 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:05:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:05:03 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:05:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:05:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:05:03 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:05:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:05:03 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:05:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:05:03 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:05:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:05:03 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:05:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:05:03 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:05:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:05:03 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:05:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:05:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:05:03 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:05:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:05:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:05:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:05:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:05:03 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:05:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:05:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:05:03 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:05:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:05:03 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:05:03 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:05:03 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:05:03 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:05:03 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:05:03 --> Session Class Initialized
DEBUG - 2016-09-19 12:05:03 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:05:03 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:05:03 --> Session routines successfully run
DEBUG - 2016-09-19 12:05:03 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:05:03 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:05:03 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:05:03 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:05:03 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:05:03 --> Controller Class Initialized
DEBUG - 2016-09-19 12:05:03 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:05:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:05:03 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:05:03 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:05:03 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:05:03 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:05:03 --> Model Class Initialized
DEBUG - 2016-09-19 12:05:04 --> Model Class Initialized
DEBUG - 2016-09-19 12:05:04 --> Model Class Initialized
DEBUG - 2016-09-19 12:05:04 --> Model Class Initialized
DEBUG - 2016-09-19 12:05:04 --> Model Class Initialized
DEBUG - 2016-09-19 12:05:04 --> Model Class Initialized
DEBUG - 2016-09-19 12:05:04 --> Model Class Initialized
DEBUG - 2016-09-19 12:05:04 --> Model Class Initialized
ERROR - 2016-09-19 12:05:04 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 12:05:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-19 12:05:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:05:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:05:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:05:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:05:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:05:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:05:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:05:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:05:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:05:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:05:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:05:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:05:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:05:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:05:04 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/26764e7c38cfdb071ebc36690ecd8747
DEBUG - 2016-09-19 12:05:04 --> Final output sent to browser
DEBUG - 2016-09-19 12:05:04 --> Total execution time: 1.3224
DEBUG - 2016-09-19 12:08:35 --> Config Class Initialized
DEBUG - 2016-09-19 12:08:35 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:08:35 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:08:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:08:35 --> URI Class Initialized
DEBUG - 2016-09-19 12:08:35 --> Router Class Initialized
DEBUG - 2016-09-19 12:08:35 --> Output Class Initialized
DEBUG - 2016-09-19 12:08:35 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:08:35 --> Security Class Initialized
DEBUG - 2016-09-19 12:08:35 --> Input Class Initialized
DEBUG - 2016-09-19 12:08:35 --> XSS Filtering completed
DEBUG - 2016-09-19 12:08:36 --> XSS Filtering completed
DEBUG - 2016-09-19 12:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:08:36 --> Language Class Initialized
DEBUG - 2016-09-19 12:08:36 --> Loader Class Initialized
DEBUG - 2016-09-19 12:08:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:08:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:08:36 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:08:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:08:36 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:08:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:08:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:08:36 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:08:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:08:36 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:08:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:08:36 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:08:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:08:36 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:08:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:08:36 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:08:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:08:36 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:08:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:08:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:08:36 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:08:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:08:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:08:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:08:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:08:36 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:08:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:08:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:08:36 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:08:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:08:36 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:08:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:08:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:08:36 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:08:36 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:08:36 --> Session Class Initialized
DEBUG - 2016-09-19 12:08:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:08:36 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:08:36 --> Session routines successfully run
DEBUG - 2016-09-19 12:08:36 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:08:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:08:36 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:08:36 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:08:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:08:36 --> Controller Class Initialized
DEBUG - 2016-09-19 12:08:36 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:08:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:08:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:08:36 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:08:36 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:08:36 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:08:36 --> Model Class Initialized
DEBUG - 2016-09-19 12:08:36 --> Model Class Initialized
DEBUG - 2016-09-19 12:08:36 --> Model Class Initialized
DEBUG - 2016-09-19 12:08:37 --> Model Class Initialized
DEBUG - 2016-09-19 12:08:37 --> Model Class Initialized
DEBUG - 2016-09-19 12:08:37 --> Model Class Initialized
DEBUG - 2016-09-19 12:08:37 --> Model Class Initialized
DEBUG - 2016-09-19 12:08:37 --> Model Class Initialized
ERROR - 2016-09-19 12:08:37 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 12:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-19 12:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:08:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/26764e7c38cfdb071ebc36690ecd8747
DEBUG - 2016-09-19 12:08:37 --> Final output sent to browser
DEBUG - 2016-09-19 12:08:37 --> Total execution time: 1.3833
DEBUG - 2016-09-19 12:09:05 --> Config Class Initialized
DEBUG - 2016-09-19 12:09:05 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:09:05 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:09:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:09:05 --> URI Class Initialized
DEBUG - 2016-09-19 12:09:05 --> Router Class Initialized
DEBUG - 2016-09-19 12:09:05 --> Output Class Initialized
DEBUG - 2016-09-19 12:09:05 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:09:05 --> Security Class Initialized
DEBUG - 2016-09-19 12:09:05 --> Input Class Initialized
DEBUG - 2016-09-19 12:09:05 --> XSS Filtering completed
DEBUG - 2016-09-19 12:09:06 --> XSS Filtering completed
DEBUG - 2016-09-19 12:09:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:09:06 --> Language Class Initialized
DEBUG - 2016-09-19 12:09:06 --> Loader Class Initialized
DEBUG - 2016-09-19 12:09:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:09:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:09:06 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:09:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:09:06 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:09:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:09:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:09:06 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:09:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:09:06 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:09:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:09:06 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:09:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:09:06 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:09:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:09:06 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:09:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:09:06 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:09:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:09:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:09:06 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:09:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:09:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:09:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:09:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:09:06 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:09:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:09:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:09:06 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:09:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:09:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:09:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:09:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:09:06 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:09:06 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:09:06 --> Session Class Initialized
DEBUG - 2016-09-19 12:09:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:09:06 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:09:06 --> Session routines successfully run
DEBUG - 2016-09-19 12:09:06 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:09:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:09:06 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:09:06 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:09:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:09:06 --> Controller Class Initialized
DEBUG - 2016-09-19 12:09:06 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:09:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:09:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:09:06 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:09:06 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:09:06 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:09:06 --> Model Class Initialized
DEBUG - 2016-09-19 12:09:07 --> Model Class Initialized
DEBUG - 2016-09-19 12:09:07 --> Model Class Initialized
DEBUG - 2016-09-19 12:09:07 --> Model Class Initialized
DEBUG - 2016-09-19 12:09:07 --> Model Class Initialized
DEBUG - 2016-09-19 12:09:07 --> Model Class Initialized
DEBUG - 2016-09-19 12:09:07 --> Model Class Initialized
DEBUG - 2016-09-19 12:09:07 --> Model Class Initialized
ERROR - 2016-09-19 12:09:07 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 12:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-19 12:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:09:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:09:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/26764e7c38cfdb071ebc36690ecd8747
DEBUG - 2016-09-19 12:09:07 --> Final output sent to browser
DEBUG - 2016-09-19 12:09:07 --> Total execution time: 1.3859
DEBUG - 2016-09-19 12:09:16 --> Config Class Initialized
DEBUG - 2016-09-19 12:09:16 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:09:16 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:09:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:09:16 --> URI Class Initialized
DEBUG - 2016-09-19 12:09:16 --> Router Class Initialized
DEBUG - 2016-09-19 12:09:16 --> Output Class Initialized
DEBUG - 2016-09-19 12:09:16 --> Security Class Initialized
DEBUG - 2016-09-19 12:09:16 --> Input Class Initialized
DEBUG - 2016-09-19 12:09:16 --> XSS Filtering completed
DEBUG - 2016-09-19 12:09:16 --> XSS Filtering completed
DEBUG - 2016-09-19 12:09:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:09:16 --> Language Class Initialized
DEBUG - 2016-09-19 12:09:16 --> Loader Class Initialized
DEBUG - 2016-09-19 12:09:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:09:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:09:16 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:09:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:09:16 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:09:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:09:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:09:16 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:09:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:09:16 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:09:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:09:16 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:09:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:09:16 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:09:17 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:09:17 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:09:17 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:09:17 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:09:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:09:17 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:09:17 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:09:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:09:17 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:09:17 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:09:17 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:09:17 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:09:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:09:17 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:09:17 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:09:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:09:17 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:09:17 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:09:17 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:09:17 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:09:17 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:09:17 --> Session Class Initialized
DEBUG - 2016-09-19 12:09:17 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:09:17 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:09:17 --> Session routines successfully run
DEBUG - 2016-09-19 12:09:17 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:09:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:09:17 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:09:17 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:09:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:09:17 --> Controller Class Initialized
DEBUG - 2016-09-19 12:09:17 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:09:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:09:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:09:17 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:09:17 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:09:17 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:09:17 --> Model Class Initialized
DEBUG - 2016-09-19 12:09:17 --> Model Class Initialized
DEBUG - 2016-09-19 12:09:17 --> Model Class Initialized
DEBUG - 2016-09-19 12:09:17 --> Model Class Initialized
DEBUG - 2016-09-19 12:09:17 --> Model Class Initialized
DEBUG - 2016-09-19 12:09:17 --> Model Class Initialized
DEBUG - 2016-09-19 12:09:17 --> Model Class Initialized
ERROR - 2016-09-19 12:09:17 --> 404 Page Not Found --> 
DEBUG - 2016-09-19 12:09:17 --> Config Class Initialized
DEBUG - 2016-09-19 12:09:17 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:09:17 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:09:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:09:17 --> URI Class Initialized
DEBUG - 2016-09-19 12:09:18 --> Router Class Initialized
ERROR - 2016-09-19 12:09:18 --> 404 Page Not Found --> front_end/img
DEBUG - 2016-09-19 12:09:18 --> Config Class Initialized
DEBUG - 2016-09-19 12:09:18 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:09:18 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:09:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:09:18 --> URI Class Initialized
DEBUG - 2016-09-19 12:09:18 --> Router Class Initialized
DEBUG - 2016-09-19 12:09:18 --> Output Class Initialized
DEBUG - 2016-09-19 12:09:18 --> Security Class Initialized
DEBUG - 2016-09-19 12:09:18 --> Input Class Initialized
DEBUG - 2016-09-19 12:09:18 --> XSS Filtering completed
DEBUG - 2016-09-19 12:09:18 --> XSS Filtering completed
DEBUG - 2016-09-19 12:09:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:09:18 --> Language Class Initialized
DEBUG - 2016-09-19 12:09:18 --> Loader Class Initialized
DEBUG - 2016-09-19 12:09:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:09:18 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:09:18 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:09:18 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:09:18 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:09:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:09:18 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:09:18 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:09:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:09:18 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:09:18 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:09:18 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:09:18 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:09:18 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:09:18 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:09:18 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:09:18 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:09:18 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:09:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:09:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:09:18 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:09:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:09:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:09:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:09:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:09:18 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:09:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:09:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:09:18 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:09:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:09:18 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:09:18 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:09:18 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:09:18 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:09:18 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:09:19 --> Session Class Initialized
DEBUG - 2016-09-19 12:09:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:09:19 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:09:19 --> Session routines successfully run
DEBUG - 2016-09-19 12:09:19 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:09:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:09:19 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:09:19 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:09:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:09:19 --> Controller Class Initialized
DEBUG - 2016-09-19 12:09:19 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:09:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:09:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:09:19 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:09:19 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:09:19 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:09:19 --> Model Class Initialized
DEBUG - 2016-09-19 12:09:19 --> Model Class Initialized
DEBUG - 2016-09-19 12:09:19 --> Model Class Initialized
DEBUG - 2016-09-19 12:09:19 --> Model Class Initialized
DEBUG - 2016-09-19 12:09:19 --> Model Class Initialized
DEBUG - 2016-09-19 12:09:19 --> Model Class Initialized
DEBUG - 2016-09-19 12:09:19 --> Model Class Initialized
ERROR - 2016-09-19 12:09:19 --> 404 Page Not Found --> 
DEBUG - 2016-09-19 12:09:20 --> Config Class Initialized
DEBUG - 2016-09-19 12:09:20 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:09:20 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:09:20 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:09:20 --> URI Class Initialized
DEBUG - 2016-09-19 12:09:20 --> Router Class Initialized
DEBUG - 2016-09-19 12:09:20 --> Output Class Initialized
DEBUG - 2016-09-19 12:09:20 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:09:20 --> Security Class Initialized
DEBUG - 2016-09-19 12:09:20 --> Input Class Initialized
DEBUG - 2016-09-19 12:09:20 --> XSS Filtering completed
DEBUG - 2016-09-19 12:09:20 --> XSS Filtering completed
DEBUG - 2016-09-19 12:09:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:09:20 --> Language Class Initialized
DEBUG - 2016-09-19 12:09:20 --> Loader Class Initialized
DEBUG - 2016-09-19 12:09:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:09:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:09:20 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:09:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:09:20 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:09:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:09:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:09:21 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:09:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:09:21 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:09:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:09:21 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:09:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:09:21 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:09:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:09:21 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:09:21 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:09:21 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:09:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:09:21 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:09:21 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:09:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:09:21 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:09:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:09:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:09:21 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:09:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:09:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:09:21 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:09:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:09:21 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:09:21 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:09:21 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:09:21 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:09:21 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:09:21 --> Session Class Initialized
DEBUG - 2016-09-19 12:09:21 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:09:21 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:09:21 --> Session routines successfully run
DEBUG - 2016-09-19 12:09:21 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:09:21 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:09:21 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:09:21 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:09:21 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:09:21 --> Controller Class Initialized
DEBUG - 2016-09-19 12:09:21 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:09:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:09:21 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:09:21 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:09:21 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:09:21 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:09:21 --> Model Class Initialized
DEBUG - 2016-09-19 12:09:21 --> Model Class Initialized
DEBUG - 2016-09-19 12:09:21 --> Model Class Initialized
DEBUG - 2016-09-19 12:09:21 --> Model Class Initialized
DEBUG - 2016-09-19 12:09:21 --> Model Class Initialized
DEBUG - 2016-09-19 12:09:21 --> Model Class Initialized
DEBUG - 2016-09-19 12:09:21 --> Model Class Initialized
DEBUG - 2016-09-19 12:09:21 --> Model Class Initialized
ERROR - 2016-09-19 12:09:21 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 12:09:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-19 12:09:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:09:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:09:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:09:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:09:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:09:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:09:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:09:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:09:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:09:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:09:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:09:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:09:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:09:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:09:22 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/26764e7c38cfdb071ebc36690ecd8747
DEBUG - 2016-09-19 12:09:22 --> Final output sent to browser
DEBUG - 2016-09-19 12:09:22 --> Total execution time: 1.4977
DEBUG - 2016-09-19 12:16:05 --> Config Class Initialized
DEBUG - 2016-09-19 12:16:05 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:16:05 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:16:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:16:05 --> URI Class Initialized
DEBUG - 2016-09-19 12:16:05 --> Router Class Initialized
DEBUG - 2016-09-19 12:16:05 --> Output Class Initialized
DEBUG - 2016-09-19 12:16:05 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:16:06 --> Security Class Initialized
DEBUG - 2016-09-19 12:16:06 --> Input Class Initialized
DEBUG - 2016-09-19 12:16:06 --> XSS Filtering completed
DEBUG - 2016-09-19 12:16:06 --> XSS Filtering completed
DEBUG - 2016-09-19 12:16:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:16:06 --> Language Class Initialized
DEBUG - 2016-09-19 12:16:06 --> Loader Class Initialized
DEBUG - 2016-09-19 12:16:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:16:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:16:06 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:16:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:16:06 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:16:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:16:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:16:06 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:16:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:16:06 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:16:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:16:06 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:16:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:16:06 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:16:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:16:06 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:16:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:16:06 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:16:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:16:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:16:06 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:16:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:16:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:16:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:16:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:16:06 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:16:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:16:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:16:06 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:16:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:16:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:16:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:16:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:16:06 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:16:06 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:16:06 --> Session Class Initialized
DEBUG - 2016-09-19 12:16:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:16:06 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:16:06 --> Session routines successfully run
DEBUG - 2016-09-19 12:16:06 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:16:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:16:07 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:16:07 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:16:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:16:07 --> Controller Class Initialized
DEBUG - 2016-09-19 12:16:07 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:16:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:16:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:16:07 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:16:07 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:16:07 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:16:07 --> Model Class Initialized
DEBUG - 2016-09-19 12:16:07 --> Model Class Initialized
DEBUG - 2016-09-19 12:16:07 --> Model Class Initialized
ERROR - 2016-09-19 12:16:07 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 12:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-19 12:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:16:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-19 12:16:07 --> Final output sent to browser
DEBUG - 2016-09-19 12:16:07 --> Total execution time: 1.4744
DEBUG - 2016-09-19 12:19:13 --> Config Class Initialized
DEBUG - 2016-09-19 12:19:13 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:19:13 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:19:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:19:13 --> URI Class Initialized
DEBUG - 2016-09-19 12:19:13 --> Router Class Initialized
DEBUG - 2016-09-19 12:19:13 --> No URI present. Default controller set.
DEBUG - 2016-09-19 12:19:14 --> Output Class Initialized
DEBUG - 2016-09-19 12:19:14 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:19:14 --> Security Class Initialized
DEBUG - 2016-09-19 12:19:14 --> Input Class Initialized
DEBUG - 2016-09-19 12:19:14 --> XSS Filtering completed
DEBUG - 2016-09-19 12:19:14 --> XSS Filtering completed
DEBUG - 2016-09-19 12:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:19:14 --> Language Class Initialized
DEBUG - 2016-09-19 12:19:14 --> Loader Class Initialized
DEBUG - 2016-09-19 12:19:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:19:14 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:19:14 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:19:14 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:19:14 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:19:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:19:14 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:19:14 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:19:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:19:14 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:19:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:19:14 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:19:14 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:19:14 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:19:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:19:14 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:19:14 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:19:14 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:19:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:19:14 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:19:14 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:19:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:19:14 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:19:14 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:19:14 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:19:14 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:19:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:19:14 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:19:14 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:19:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:19:14 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:19:14 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:19:14 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:19:14 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:19:14 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:19:14 --> Session Class Initialized
DEBUG - 2016-09-19 12:19:14 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:19:15 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:19:15 --> Session routines successfully run
DEBUG - 2016-09-19 12:19:15 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:19:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:19:15 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:19:15 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:19:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:19:15 --> Controller Class Initialized
DEBUG - 2016-09-19 12:19:15 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:19:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:19:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:19:15 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:19:15 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:19:15 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:19:15 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:15 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:15 --> Model Class Initialized
ERROR - 2016-09-19 12:19:15 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 12:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-19 12:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-19 12:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 12:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 12:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 12:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 12:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:19:15 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-19 12:19:15 --> Final output sent to browser
DEBUG - 2016-09-19 12:19:15 --> Total execution time: 1.4913
DEBUG - 2016-09-19 12:19:15 --> Config Class Initialized
DEBUG - 2016-09-19 12:19:15 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:19:15 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:19:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:19:15 --> URI Class Initialized
DEBUG - 2016-09-19 12:19:15 --> Router Class Initialized
DEBUG - 2016-09-19 12:19:16 --> Output Class Initialized
DEBUG - 2016-09-19 12:19:16 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:19:16 --> Security Class Initialized
DEBUG - 2016-09-19 12:19:16 --> Input Class Initialized
DEBUG - 2016-09-19 12:19:16 --> XSS Filtering completed
DEBUG - 2016-09-19 12:19:16 --> XSS Filtering completed
DEBUG - 2016-09-19 12:19:16 --> XSS Filtering completed
DEBUG - 2016-09-19 12:19:16 --> XSS Filtering completed
DEBUG - 2016-09-19 12:19:16 --> XSS Filtering completed
DEBUG - 2016-09-19 12:19:16 --> XSS Filtering completed
DEBUG - 2016-09-19 12:19:16 --> XSS Filtering completed
DEBUG - 2016-09-19 12:19:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:19:16 --> Language Class Initialized
DEBUG - 2016-09-19 12:19:16 --> Loader Class Initialized
DEBUG - 2016-09-19 12:19:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:19:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:19:16 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:19:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:19:16 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:19:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:19:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:19:16 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:19:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:19:16 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:19:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:19:16 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:19:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:19:16 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:19:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:19:16 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:19:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:19:16 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:19:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:19:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:19:16 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:19:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:19:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:19:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:19:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:19:16 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:19:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:19:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:19:16 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:19:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:19:16 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:19:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:19:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:19:16 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:19:16 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:19:16 --> Session Class Initialized
DEBUG - 2016-09-19 12:19:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:19:16 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:19:16 --> Session routines successfully run
DEBUG - 2016-09-19 12:19:16 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:19:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:19:17 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:19:17 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:19:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:19:17 --> Controller Class Initialized
DEBUG - 2016-09-19 12:19:17 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:19:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:19:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:19:17 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:19:17 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:19:17 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:19:17 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:17 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:17 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:17 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:17 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:17 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:17 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:17 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-19 12:19:17 --> Final output sent to browser
DEBUG - 2016-09-19 12:19:17 --> Total execution time: 1.4501
DEBUG - 2016-09-19 12:19:18 --> Config Class Initialized
DEBUG - 2016-09-19 12:19:18 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:19:18 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:19:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:19:18 --> URI Class Initialized
DEBUG - 2016-09-19 12:19:18 --> Router Class Initialized
DEBUG - 2016-09-19 12:19:18 --> Output Class Initialized
DEBUG - 2016-09-19 12:19:18 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:19:18 --> Security Class Initialized
DEBUG - 2016-09-19 12:19:18 --> Input Class Initialized
DEBUG - 2016-09-19 12:19:18 --> XSS Filtering completed
DEBUG - 2016-09-19 12:19:18 --> XSS Filtering completed
DEBUG - 2016-09-19 12:19:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:19:18 --> Language Class Initialized
DEBUG - 2016-09-19 12:19:18 --> Loader Class Initialized
DEBUG - 2016-09-19 12:19:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:19:18 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:19:18 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:19:18 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:19:18 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:19:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:19:18 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:19:18 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:19:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:19:18 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:19:18 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:19:18 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:19:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:19:19 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:19:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:19:19 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:19:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:19:19 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:19:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:19:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:19:19 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:19:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:19:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:19:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:19:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:19:19 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:19:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:19:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:19:19 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:19:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:19:19 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:19:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:19:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:19:19 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:19:19 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:19:19 --> Session Class Initialized
DEBUG - 2016-09-19 12:19:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:19:19 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:19:19 --> Session routines successfully run
DEBUG - 2016-09-19 12:19:19 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:19:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:19:19 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:19:19 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:19:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:19:19 --> Controller Class Initialized
DEBUG - 2016-09-19 12:19:19 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:19:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:19:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:19:19 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:19:19 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:19:19 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:19:19 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:19 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:19 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:19 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:19 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:19 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:19 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:19 --> Model Class Initialized
ERROR - 2016-09-19 12:19:19 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 12:19:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-19 12:19:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:19:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:19:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:19:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:19:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:19:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:19:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:19:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:19:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:19:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:19:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:19:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:19:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:19:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:19:20 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/26764e7c38cfdb071ebc36690ecd8747
DEBUG - 2016-09-19 12:19:20 --> Final output sent to browser
DEBUG - 2016-09-19 12:19:20 --> Total execution time: 1.6302
DEBUG - 2016-09-19 12:19:21 --> Config Class Initialized
DEBUG - 2016-09-19 12:19:21 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:19:21 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:19:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:19:21 --> URI Class Initialized
DEBUG - 2016-09-19 12:19:21 --> Router Class Initialized
DEBUG - 2016-09-19 12:19:21 --> Output Class Initialized
DEBUG - 2016-09-19 12:19:21 --> Security Class Initialized
DEBUG - 2016-09-19 12:19:21 --> Input Class Initialized
DEBUG - 2016-09-19 12:19:21 --> XSS Filtering completed
DEBUG - 2016-09-19 12:19:22 --> XSS Filtering completed
DEBUG - 2016-09-19 12:19:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:19:22 --> Language Class Initialized
DEBUG - 2016-09-19 12:19:22 --> Loader Class Initialized
DEBUG - 2016-09-19 12:19:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:19:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:19:22 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:19:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:19:22 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:19:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:19:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:19:22 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:19:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:19:22 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:19:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:19:22 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:19:22 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:19:22 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:19:22 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:19:22 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:19:22 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:19:22 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:19:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:19:22 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:19:22 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:19:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:19:22 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:19:22 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:19:22 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:19:22 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:19:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:19:22 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:19:22 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:19:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:19:22 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:19:22 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:19:22 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:19:22 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:19:22 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:19:22 --> Session Class Initialized
DEBUG - 2016-09-19 12:19:22 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:19:22 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:19:22 --> Session routines successfully run
DEBUG - 2016-09-19 12:19:22 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:19:22 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:19:22 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:19:22 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:19:22 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:19:22 --> Controller Class Initialized
DEBUG - 2016-09-19 12:19:22 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:19:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:19:23 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:19:23 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:19:23 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:19:23 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:19:23 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:23 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:23 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:23 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:23 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:23 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:23 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:23 --> Model Class Initialized
ERROR - 2016-09-19 12:19:23 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 12:19:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/daftar.php
DEBUG - 2016-09-19 12:19:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:19:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:19:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:19:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:19:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:19:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:19:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:19:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:19:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:19:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:19:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:19:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:19:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:19:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:19:23 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4fb270c99c241a14b4304d7d2ceaf870
DEBUG - 2016-09-19 12:19:23 --> Final output sent to browser
DEBUG - 2016-09-19 12:19:23 --> Total execution time: 1.4687
DEBUG - 2016-09-19 12:19:28 --> Config Class Initialized
DEBUG - 2016-09-19 12:19:28 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:19:28 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:19:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:19:28 --> URI Class Initialized
DEBUG - 2016-09-19 12:19:28 --> Router Class Initialized
DEBUG - 2016-09-19 12:19:28 --> Output Class Initialized
DEBUG - 2016-09-19 12:19:28 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:19:28 --> Security Class Initialized
DEBUG - 2016-09-19 12:19:28 --> Input Class Initialized
DEBUG - 2016-09-19 12:19:28 --> XSS Filtering completed
DEBUG - 2016-09-19 12:19:28 --> XSS Filtering completed
DEBUG - 2016-09-19 12:19:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:19:28 --> Language Class Initialized
DEBUG - 2016-09-19 12:19:28 --> Loader Class Initialized
DEBUG - 2016-09-19 12:19:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:19:28 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:19:28 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:19:29 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:19:29 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:19:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:19:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:19:29 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:19:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:19:29 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:19:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:19:29 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:19:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:19:29 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:19:29 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:19:29 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:19:29 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:19:29 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:19:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:19:29 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:19:29 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:19:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:19:29 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:19:29 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:19:29 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:19:29 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:19:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:19:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:19:29 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:19:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:19:29 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:19:29 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:19:29 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:19:29 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:19:29 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:19:29 --> Session Class Initialized
DEBUG - 2016-09-19 12:19:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:19:29 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:19:29 --> Session routines successfully run
DEBUG - 2016-09-19 12:19:29 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:19:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:19:29 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:19:29 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:19:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:19:29 --> Controller Class Initialized
DEBUG - 2016-09-19 12:19:29 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:19:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:19:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:19:29 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:19:29 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:19:29 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:19:29 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:29 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:30 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:30 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:30 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:30 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:30 --> Model Class Initialized
DEBUG - 2016-09-19 12:19:30 --> Model Class Initialized
ERROR - 2016-09-19 12:19:30 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 12:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-19 12:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:19:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/26764e7c38cfdb071ebc36690ecd8747
DEBUG - 2016-09-19 12:19:30 --> Final output sent to browser
DEBUG - 2016-09-19 12:19:30 --> Total execution time: 1.6020
DEBUG - 2016-09-19 12:20:19 --> Config Class Initialized
DEBUG - 2016-09-19 12:20:19 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:20:19 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:20:19 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:20:19 --> URI Class Initialized
DEBUG - 2016-09-19 12:20:19 --> Router Class Initialized
DEBUG - 2016-09-19 12:20:19 --> Output Class Initialized
DEBUG - 2016-09-19 12:20:19 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:20:20 --> Security Class Initialized
DEBUG - 2016-09-19 12:20:20 --> Input Class Initialized
DEBUG - 2016-09-19 12:20:20 --> XSS Filtering completed
DEBUG - 2016-09-19 12:20:20 --> XSS Filtering completed
DEBUG - 2016-09-19 12:20:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:20:20 --> Language Class Initialized
DEBUG - 2016-09-19 12:20:20 --> Loader Class Initialized
DEBUG - 2016-09-19 12:20:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:20:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:20:20 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:20:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:20:20 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:20:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:20:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:20:20 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:20:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:20:20 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:20:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:20:20 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:20:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:20:20 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:20:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:20:20 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:20:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:20:20 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:20:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:20:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:20:20 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:20:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:20:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:20:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:20:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:20:20 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:20:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:20:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:20:20 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:20:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:20:20 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:20:20 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:20:20 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:20:20 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:20:20 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:20:20 --> Session Class Initialized
DEBUG - 2016-09-19 12:20:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:20:20 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:20:20 --> Session routines successfully run
DEBUG - 2016-09-19 12:20:20 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:20:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:20:20 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:20:21 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:20:21 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:20:21 --> Controller Class Initialized
DEBUG - 2016-09-19 12:20:21 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:20:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:20:21 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:20:21 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:20:21 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:20:21 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:20:21 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:21 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:21 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:21 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:21 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:21 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:21 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:21 --> Model Class Initialized
ERROR - 2016-09-19 12:20:21 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
ERROR - 2016-09-19 12:20:21 --> Severity: Notice  --> Undefined property: stdClass::$crypted_id_diklat E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 52
DEBUG - 2016-09-19 12:20:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-19 12:20:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:20:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:20:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:20:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:20:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:20:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:20:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:20:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:20:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:20:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:20:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:20:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:20:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:20:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:20:21 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/26764e7c38cfdb071ebc36690ecd8747
DEBUG - 2016-09-19 12:20:21 --> Final output sent to browser
DEBUG - 2016-09-19 12:20:21 --> Total execution time: 1.5734
DEBUG - 2016-09-19 12:20:37 --> Config Class Initialized
DEBUG - 2016-09-19 12:20:37 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:20:37 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:20:37 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:20:37 --> URI Class Initialized
DEBUG - 2016-09-19 12:20:37 --> Router Class Initialized
DEBUG - 2016-09-19 12:20:37 --> Output Class Initialized
DEBUG - 2016-09-19 12:20:37 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:20:37 --> Security Class Initialized
DEBUG - 2016-09-19 12:20:37 --> Input Class Initialized
DEBUG - 2016-09-19 12:20:37 --> XSS Filtering completed
DEBUG - 2016-09-19 12:20:37 --> XSS Filtering completed
DEBUG - 2016-09-19 12:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:20:37 --> Language Class Initialized
DEBUG - 2016-09-19 12:20:37 --> Loader Class Initialized
DEBUG - 2016-09-19 12:20:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:20:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:20:37 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:20:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:20:37 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:20:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:20:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:20:37 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:20:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:20:37 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:20:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:20:37 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:20:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:20:37 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:20:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:20:37 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:20:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:20:37 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:20:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:20:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:20:37 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:20:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:20:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:20:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:20:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:20:37 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:20:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:20:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:20:38 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:20:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:20:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:20:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:20:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:20:38 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:20:38 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:20:38 --> Session Class Initialized
DEBUG - 2016-09-19 12:20:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:20:38 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:20:38 --> Session routines successfully run
DEBUG - 2016-09-19 12:20:38 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:20:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:20:38 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:20:38 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:20:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:20:38 --> Controller Class Initialized
DEBUG - 2016-09-19 12:20:38 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:20:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:20:38 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:20:38 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:20:38 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:20:38 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:20:38 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:38 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:38 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:38 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:38 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:38 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:38 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:38 --> Model Class Initialized
ERROR - 2016-09-19 12:20:38 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 12:20:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-19 12:20:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:20:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:20:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:20:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:20:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:20:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:20:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:20:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:20:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:20:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:20:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:20:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:20:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:20:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:20:39 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/26764e7c38cfdb071ebc36690ecd8747
DEBUG - 2016-09-19 12:20:39 --> Final output sent to browser
DEBUG - 2016-09-19 12:20:39 --> Total execution time: 1.6592
DEBUG - 2016-09-19 12:20:42 --> Config Class Initialized
DEBUG - 2016-09-19 12:20:42 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:20:42 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:20:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:20:42 --> URI Class Initialized
DEBUG - 2016-09-19 12:20:42 --> Router Class Initialized
DEBUG - 2016-09-19 12:20:42 --> Output Class Initialized
DEBUG - 2016-09-19 12:20:42 --> Security Class Initialized
DEBUG - 2016-09-19 12:20:42 --> Input Class Initialized
DEBUG - 2016-09-19 12:20:42 --> XSS Filtering completed
DEBUG - 2016-09-19 12:20:42 --> XSS Filtering completed
DEBUG - 2016-09-19 12:20:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:20:42 --> Language Class Initialized
DEBUG - 2016-09-19 12:20:42 --> Loader Class Initialized
DEBUG - 2016-09-19 12:20:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:20:42 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:20:42 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:20:42 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:20:42 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:20:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:20:42 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:20:43 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:20:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:20:43 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:20:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:20:43 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:20:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:20:43 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:20:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:20:43 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:20:43 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:20:43 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:20:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:20:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:20:43 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:20:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:20:43 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:20:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:20:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:20:43 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:20:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:20:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:20:43 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:20:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:20:43 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:20:43 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:20:43 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:20:43 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:20:43 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:20:43 --> Session Class Initialized
DEBUG - 2016-09-19 12:20:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:20:43 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:20:43 --> Session routines successfully run
DEBUG - 2016-09-19 12:20:43 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:20:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:20:43 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:20:43 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:20:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:20:43 --> Controller Class Initialized
DEBUG - 2016-09-19 12:20:43 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:20:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:20:43 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:20:43 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:20:43 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:20:43 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:20:43 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:43 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:43 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:43 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:44 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:44 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:44 --> Model Class Initialized
ERROR - 2016-09-19 12:20:44 --> 404 Page Not Found --> 
DEBUG - 2016-09-19 12:20:44 --> Config Class Initialized
DEBUG - 2016-09-19 12:20:44 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:20:44 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:20:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:20:44 --> URI Class Initialized
DEBUG - 2016-09-19 12:20:44 --> Router Class Initialized
ERROR - 2016-09-19 12:20:44 --> 404 Page Not Found --> front_end/img
DEBUG - 2016-09-19 12:20:44 --> Config Class Initialized
DEBUG - 2016-09-19 12:20:44 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:20:44 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:20:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:20:44 --> URI Class Initialized
DEBUG - 2016-09-19 12:20:44 --> Router Class Initialized
DEBUG - 2016-09-19 12:20:44 --> Output Class Initialized
DEBUG - 2016-09-19 12:20:44 --> Security Class Initialized
DEBUG - 2016-09-19 12:20:44 --> Input Class Initialized
DEBUG - 2016-09-19 12:20:44 --> XSS Filtering completed
DEBUG - 2016-09-19 12:20:44 --> XSS Filtering completed
DEBUG - 2016-09-19 12:20:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:20:44 --> Language Class Initialized
DEBUG - 2016-09-19 12:20:44 --> Loader Class Initialized
DEBUG - 2016-09-19 12:20:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:20:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:20:44 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:20:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:20:44 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:20:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:20:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:20:44 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:20:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:20:44 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:20:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:20:44 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:20:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:20:44 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:20:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:20:44 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:20:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:20:45 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:20:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:20:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:20:45 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:20:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:20:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:20:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:20:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:20:45 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:20:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:20:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:20:45 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:20:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:20:45 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:20:45 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:20:45 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:20:45 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:20:45 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:20:45 --> Session Class Initialized
DEBUG - 2016-09-19 12:20:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:20:45 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:20:45 --> Session routines successfully run
DEBUG - 2016-09-19 12:20:45 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:20:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:20:45 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:20:45 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:20:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:20:45 --> Controller Class Initialized
DEBUG - 2016-09-19 12:20:45 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:20:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:20:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:20:45 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:20:45 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:20:45 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:20:45 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:45 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:45 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:45 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:45 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:45 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:45 --> Model Class Initialized
ERROR - 2016-09-19 12:20:45 --> 404 Page Not Found --> 
DEBUG - 2016-09-19 12:20:54 --> Config Class Initialized
DEBUG - 2016-09-19 12:20:54 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:20:54 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:20:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:20:55 --> URI Class Initialized
DEBUG - 2016-09-19 12:20:55 --> Router Class Initialized
DEBUG - 2016-09-19 12:20:55 --> Output Class Initialized
DEBUG - 2016-09-19 12:20:55 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:20:55 --> Security Class Initialized
DEBUG - 2016-09-19 12:20:55 --> Input Class Initialized
DEBUG - 2016-09-19 12:20:55 --> XSS Filtering completed
DEBUG - 2016-09-19 12:20:55 --> XSS Filtering completed
DEBUG - 2016-09-19 12:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:20:55 --> Language Class Initialized
DEBUG - 2016-09-19 12:20:55 --> Loader Class Initialized
DEBUG - 2016-09-19 12:20:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:20:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:20:55 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:20:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:20:55 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:20:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:20:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:20:55 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:20:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:20:55 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:20:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:20:55 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:20:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:20:55 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:20:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:20:55 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:20:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:20:55 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:20:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:20:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:20:55 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:20:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:20:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:20:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:20:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:20:55 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:20:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:20:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:20:55 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:20:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:20:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:20:56 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:20:56 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:20:56 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:20:56 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:20:56 --> Session Class Initialized
DEBUG - 2016-09-19 12:20:56 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:20:56 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:20:56 --> Session routines successfully run
DEBUG - 2016-09-19 12:20:56 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:20:56 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:20:56 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:20:56 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:20:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:20:56 --> Controller Class Initialized
DEBUG - 2016-09-19 12:20:56 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:20:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:20:56 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:20:56 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:20:56 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:20:56 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:20:56 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:56 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:56 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:56 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:56 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:56 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:56 --> Model Class Initialized
DEBUG - 2016-09-19 12:20:56 --> Model Class Initialized
ERROR - 2016-09-19 12:20:56 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 12:20:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-19 12:20:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:20:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:20:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:20:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:20:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:20:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:20:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:20:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:20:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:20:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:20:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:20:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:20:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:20:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:20:56 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/26764e7c38cfdb071ebc36690ecd8747
DEBUG - 2016-09-19 12:20:56 --> Final output sent to browser
DEBUG - 2016-09-19 12:20:57 --> Total execution time: 1.7445
DEBUG - 2016-09-19 12:20:59 --> Config Class Initialized
DEBUG - 2016-09-19 12:20:59 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:20:59 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:20:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:20:59 --> URI Class Initialized
DEBUG - 2016-09-19 12:20:59 --> Router Class Initialized
DEBUG - 2016-09-19 12:20:59 --> Output Class Initialized
DEBUG - 2016-09-19 12:20:59 --> Security Class Initialized
DEBUG - 2016-09-19 12:20:59 --> Input Class Initialized
DEBUG - 2016-09-19 12:20:59 --> XSS Filtering completed
DEBUG - 2016-09-19 12:20:59 --> XSS Filtering completed
DEBUG - 2016-09-19 12:20:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:20:59 --> Language Class Initialized
DEBUG - 2016-09-19 12:20:59 --> Loader Class Initialized
DEBUG - 2016-09-19 12:20:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:20:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:20:59 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:20:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:20:59 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:20:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:20:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:20:59 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:20:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:20:59 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:20:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:20:59 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:20:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:20:59 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:20:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:20:59 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:20:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:20:59 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:20:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:20:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:20:59 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:20:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:20:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:20:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:20:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:21:00 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:21:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:21:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:21:00 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:21:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:21:00 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:21:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:21:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:21:00 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:21:00 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:21:00 --> Session Class Initialized
DEBUG - 2016-09-19 12:21:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:21:00 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:21:00 --> Session routines successfully run
DEBUG - 2016-09-19 12:21:00 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:21:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:21:00 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:21:00 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:21:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:21:00 --> Controller Class Initialized
DEBUG - 2016-09-19 12:21:00 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:21:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:21:00 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:21:00 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:21:00 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:21:00 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:21:00 --> Model Class Initialized
DEBUG - 2016-09-19 12:21:00 --> Model Class Initialized
DEBUG - 2016-09-19 12:21:00 --> Model Class Initialized
DEBUG - 2016-09-19 12:21:00 --> Model Class Initialized
DEBUG - 2016-09-19 12:21:00 --> Model Class Initialized
DEBUG - 2016-09-19 12:21:00 --> Model Class Initialized
DEBUG - 2016-09-19 12:21:00 --> Model Class Initialized
DEBUG - 2016-09-19 12:21:00 --> Model Class Initialized
ERROR - 2016-09-19 12:21:00 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 12:21:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/daftar.php
DEBUG - 2016-09-19 12:21:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:21:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:21:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:21:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:21:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:21:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:21:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:21:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:21:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:21:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:21:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:21:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:21:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:21:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:21:01 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/bca08a22cb2ac4b6f004534879c0278e
DEBUG - 2016-09-19 12:21:01 --> Final output sent to browser
DEBUG - 2016-09-19 12:21:01 --> Total execution time: 1.6580
DEBUG - 2016-09-19 12:41:36 --> Config Class Initialized
DEBUG - 2016-09-19 12:41:36 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:41:36 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:41:36 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:41:36 --> URI Class Initialized
DEBUG - 2016-09-19 12:41:36 --> Router Class Initialized
DEBUG - 2016-09-19 12:41:36 --> No URI present. Default controller set.
DEBUG - 2016-09-19 12:41:36 --> Output Class Initialized
DEBUG - 2016-09-19 12:41:36 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:41:36 --> Security Class Initialized
DEBUG - 2016-09-19 12:41:36 --> Input Class Initialized
DEBUG - 2016-09-19 12:41:36 --> XSS Filtering completed
DEBUG - 2016-09-19 12:41:36 --> XSS Filtering completed
DEBUG - 2016-09-19 12:41:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:41:36 --> Language Class Initialized
DEBUG - 2016-09-19 12:41:36 --> Loader Class Initialized
DEBUG - 2016-09-19 12:41:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:41:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:41:36 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:41:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:41:36 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:41:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:41:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:41:37 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:41:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:41:37 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:41:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:41:37 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:41:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:41:37 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:41:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:41:37 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:41:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:41:37 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:41:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:41:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:41:37 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:41:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:41:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:41:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:41:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:41:37 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:41:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:41:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:41:37 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:41:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:41:37 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:41:37 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:41:37 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:41:37 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:41:37 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:41:37 --> Session Class Initialized
DEBUG - 2016-09-19 12:41:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:41:37 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:41:37 --> Session routines successfully run
DEBUG - 2016-09-19 12:41:37 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:41:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:41:37 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:41:37 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:41:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:41:37 --> Controller Class Initialized
DEBUG - 2016-09-19 12:41:37 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:41:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:41:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:41:37 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:41:37 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:41:37 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:41:37 --> Model Class Initialized
DEBUG - 2016-09-19 12:41:37 --> Model Class Initialized
DEBUG - 2016-09-19 12:41:38 --> Model Class Initialized
ERROR - 2016-09-19 12:41:38 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 12:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-19 12:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-19 12:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 12:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 12:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 12:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 12:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:41:38 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-19 12:41:38 --> Final output sent to browser
DEBUG - 2016-09-19 12:41:38 --> Total execution time: 1.6866
DEBUG - 2016-09-19 12:41:38 --> Config Class Initialized
DEBUG - 2016-09-19 12:41:38 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:41:38 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:41:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:41:38 --> URI Class Initialized
DEBUG - 2016-09-19 12:41:38 --> Router Class Initialized
DEBUG - 2016-09-19 12:41:38 --> Output Class Initialized
DEBUG - 2016-09-19 12:41:38 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:41:38 --> Security Class Initialized
DEBUG - 2016-09-19 12:41:38 --> Input Class Initialized
DEBUG - 2016-09-19 12:41:38 --> XSS Filtering completed
DEBUG - 2016-09-19 12:41:38 --> XSS Filtering completed
DEBUG - 2016-09-19 12:41:38 --> XSS Filtering completed
DEBUG - 2016-09-19 12:41:38 --> XSS Filtering completed
DEBUG - 2016-09-19 12:41:39 --> XSS Filtering completed
DEBUG - 2016-09-19 12:41:39 --> XSS Filtering completed
DEBUG - 2016-09-19 12:41:39 --> XSS Filtering completed
DEBUG - 2016-09-19 12:41:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:41:39 --> Language Class Initialized
DEBUG - 2016-09-19 12:41:39 --> Loader Class Initialized
DEBUG - 2016-09-19 12:41:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:41:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:41:39 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:41:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:41:39 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:41:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:41:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:41:39 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:41:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:41:39 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:41:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:41:39 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:41:39 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:41:39 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:41:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:41:39 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:41:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:41:39 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:41:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:41:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:41:39 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:41:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:41:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:41:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:41:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:41:39 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:41:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:41:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:41:39 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:41:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:41:39 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:41:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:41:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:41:39 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:41:39 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:41:39 --> Session Class Initialized
DEBUG - 2016-09-19 12:41:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:41:39 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:41:40 --> Session routines successfully run
DEBUG - 2016-09-19 12:41:40 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:41:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:41:40 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:41:40 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:41:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:41:40 --> Controller Class Initialized
DEBUG - 2016-09-19 12:41:40 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:41:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:41:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:41:40 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:41:40 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:41:40 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:41:40 --> Model Class Initialized
DEBUG - 2016-09-19 12:41:40 --> Model Class Initialized
DEBUG - 2016-09-19 12:41:40 --> Model Class Initialized
DEBUG - 2016-09-19 12:41:40 --> Model Class Initialized
DEBUG - 2016-09-19 12:41:40 --> Model Class Initialized
DEBUG - 2016-09-19 12:41:40 --> Model Class Initialized
DEBUG - 2016-09-19 12:41:40 --> Model Class Initialized
DEBUG - 2016-09-19 12:41:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-19 12:41:40 --> Final output sent to browser
DEBUG - 2016-09-19 12:41:40 --> Total execution time: 1.7758
DEBUG - 2016-09-19 12:41:49 --> Config Class Initialized
DEBUG - 2016-09-19 12:41:49 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:41:49 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:41:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:41:50 --> URI Class Initialized
DEBUG - 2016-09-19 12:41:50 --> Router Class Initialized
DEBUG - 2016-09-19 12:41:50 --> Output Class Initialized
DEBUG - 2016-09-19 12:41:50 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:41:50 --> Security Class Initialized
DEBUG - 2016-09-19 12:41:50 --> Input Class Initialized
DEBUG - 2016-09-19 12:41:50 --> XSS Filtering completed
DEBUG - 2016-09-19 12:41:50 --> XSS Filtering completed
DEBUG - 2016-09-19 12:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:41:50 --> Language Class Initialized
DEBUG - 2016-09-19 12:41:50 --> Loader Class Initialized
DEBUG - 2016-09-19 12:41:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:41:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:41:50 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:41:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:41:50 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:41:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:41:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:41:50 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:41:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:41:50 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:41:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:41:50 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:41:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:41:50 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:41:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:41:50 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:41:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:41:50 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:41:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:41:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:41:50 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:41:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:41:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:41:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:41:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:41:50 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:41:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:41:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:41:50 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:41:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:41:51 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:41:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:41:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:41:51 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:41:51 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:41:51 --> Session Class Initialized
DEBUG - 2016-09-19 12:41:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:41:51 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:41:51 --> Session routines successfully run
DEBUG - 2016-09-19 12:41:51 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:41:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:41:51 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:41:51 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:41:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:41:51 --> Controller Class Initialized
DEBUG - 2016-09-19 12:41:51 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:41:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:41:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:41:51 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:41:51 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:41:51 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:41:51 --> Model Class Initialized
DEBUG - 2016-09-19 12:41:51 --> Model Class Initialized
DEBUG - 2016-09-19 12:41:51 --> Model Class Initialized
DEBUG - 2016-09-19 12:41:51 --> Model Class Initialized
DEBUG - 2016-09-19 12:41:51 --> Model Class Initialized
DEBUG - 2016-09-19 12:41:51 --> Model Class Initialized
DEBUG - 2016-09-19 12:41:51 --> Model Class Initialized
DEBUG - 2016-09-19 12:41:51 --> Model Class Initialized
ERROR - 2016-09-19 12:41:51 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 12:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-19 12:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:41:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:41:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/26764e7c38cfdb071ebc36690ecd8747
DEBUG - 2016-09-19 12:41:52 --> Final output sent to browser
DEBUG - 2016-09-19 12:41:52 --> Total execution time: 1.8394
DEBUG - 2016-09-19 12:46:03 --> Config Class Initialized
DEBUG - 2016-09-19 12:46:03 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:46:03 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:46:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:46:03 --> URI Class Initialized
DEBUG - 2016-09-19 12:46:03 --> Router Class Initialized
DEBUG - 2016-09-19 12:46:03 --> Output Class Initialized
DEBUG - 2016-09-19 12:46:03 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:46:03 --> Security Class Initialized
DEBUG - 2016-09-19 12:46:03 --> Input Class Initialized
DEBUG - 2016-09-19 12:46:03 --> XSS Filtering completed
DEBUG - 2016-09-19 12:46:03 --> XSS Filtering completed
DEBUG - 2016-09-19 12:46:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:46:03 --> Language Class Initialized
DEBUG - 2016-09-19 12:46:03 --> Loader Class Initialized
DEBUG - 2016-09-19 12:46:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:46:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:46:03 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:46:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:46:03 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:46:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:46:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:46:03 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:46:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:46:03 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:46:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:46:03 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:46:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:46:04 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:46:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:46:04 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:46:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:46:04 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:46:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:46:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:46:04 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:46:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:46:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:46:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:46:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:46:04 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:46:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:46:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:46:04 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:46:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:46:04 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:46:04 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:46:04 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:46:04 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:46:04 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:46:04 --> Session Class Initialized
DEBUG - 2016-09-19 12:46:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:46:04 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:46:04 --> Session routines successfully run
DEBUG - 2016-09-19 12:46:04 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:46:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:46:04 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:46:04 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:46:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:46:04 --> Controller Class Initialized
DEBUG - 2016-09-19 12:46:04 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:46:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:46:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:46:04 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:46:04 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:46:04 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:46:04 --> Model Class Initialized
DEBUG - 2016-09-19 12:46:04 --> Model Class Initialized
DEBUG - 2016-09-19 12:46:04 --> Model Class Initialized
DEBUG - 2016-09-19 12:46:04 --> Model Class Initialized
DEBUG - 2016-09-19 12:46:04 --> Model Class Initialized
DEBUG - 2016-09-19 12:46:04 --> Model Class Initialized
DEBUG - 2016-09-19 12:46:05 --> Model Class Initialized
DEBUG - 2016-09-19 12:46:05 --> Model Class Initialized
ERROR - 2016-09-19 12:46:05 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 12:46:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/daftar.php
DEBUG - 2016-09-19 12:46:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:46:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:46:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:46:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:46:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:46:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:46:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:46:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:46:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:46:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:46:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:46:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:46:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:46:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:46:05 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/bca08a22cb2ac4b6f004534879c0278e
DEBUG - 2016-09-19 12:46:05 --> Final output sent to browser
DEBUG - 2016-09-19 12:46:05 --> Total execution time: 1.9049
DEBUG - 2016-09-19 12:53:54 --> Config Class Initialized
DEBUG - 2016-09-19 12:53:54 --> Hooks Class Initialized
DEBUG - 2016-09-19 12:53:54 --> Utf8 Class Initialized
DEBUG - 2016-09-19 12:53:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 12:53:54 --> URI Class Initialized
DEBUG - 2016-09-19 12:53:54 --> Router Class Initialized
DEBUG - 2016-09-19 12:53:54 --> Output Class Initialized
DEBUG - 2016-09-19 12:53:54 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 12:53:54 --> Security Class Initialized
DEBUG - 2016-09-19 12:53:54 --> Input Class Initialized
DEBUG - 2016-09-19 12:53:54 --> XSS Filtering completed
DEBUG - 2016-09-19 12:53:55 --> XSS Filtering completed
DEBUG - 2016-09-19 12:53:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 12:53:55 --> Language Class Initialized
DEBUG - 2016-09-19 12:53:55 --> Loader Class Initialized
DEBUG - 2016-09-19 12:53:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 12:53:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 12:53:55 --> Helper loaded: url_helper
DEBUG - 2016-09-19 12:53:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 12:53:55 --> Helper loaded: file_helper
DEBUG - 2016-09-19 12:53:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:53:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 12:53:55 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 12:53:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 12:53:55 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 12:53:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 12:53:55 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:53:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 12:53:55 --> Helper loaded: common_helper
DEBUG - 2016-09-19 12:53:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 12:53:55 --> Helper loaded: form_helper
DEBUG - 2016-09-19 12:53:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 12:53:55 --> Helper loaded: security_helper
DEBUG - 2016-09-19 12:53:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:53:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 12:53:55 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 12:53:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 12:53:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 12:53:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 12:53:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 12:53:55 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 12:53:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:53:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 12:53:55 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 12:53:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 12:53:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 12:53:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 12:53:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 12:53:55 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 12:53:55 --> Database Driver Class Initialized
DEBUG - 2016-09-19 12:53:56 --> Session Class Initialized
DEBUG - 2016-09-19 12:53:56 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 12:53:56 --> Helper loaded: string_helper
DEBUG - 2016-09-19 12:53:56 --> Session routines successfully run
DEBUG - 2016-09-19 12:53:56 --> Native_session Class Initialized
DEBUG - 2016-09-19 12:53:56 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 12:53:56 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:53:56 --> Form Validation Class Initialized
DEBUG - 2016-09-19 12:53:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 12:53:56 --> Controller Class Initialized
DEBUG - 2016-09-19 12:53:56 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 12:53:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 12:53:56 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 12:53:56 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:53:56 --> Carabiner: library configured.
DEBUG - 2016-09-19 12:53:56 --> User Agent Class Initialized
DEBUG - 2016-09-19 12:53:56 --> Model Class Initialized
DEBUG - 2016-09-19 12:53:56 --> Model Class Initialized
DEBUG - 2016-09-19 12:53:56 --> Model Class Initialized
ERROR - 2016-09-19 12:53:56 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 12:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-19 12:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 12:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 12:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 12:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 12:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 12:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 12:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 12:53:56 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-19 12:53:56 --> Final output sent to browser
DEBUG - 2016-09-19 12:53:56 --> Total execution time: 1.7798
DEBUG - 2016-09-19 13:29:50 --> Config Class Initialized
DEBUG - 2016-09-19 13:29:50 --> Hooks Class Initialized
DEBUG - 2016-09-19 13:29:50 --> Utf8 Class Initialized
DEBUG - 2016-09-19 13:29:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 13:29:51 --> URI Class Initialized
DEBUG - 2016-09-19 13:29:51 --> Router Class Initialized
DEBUG - 2016-09-19 13:29:51 --> Output Class Initialized
DEBUG - 2016-09-19 13:29:51 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 13:29:51 --> Security Class Initialized
DEBUG - 2016-09-19 13:29:51 --> Input Class Initialized
DEBUG - 2016-09-19 13:29:51 --> XSS Filtering completed
DEBUG - 2016-09-19 13:29:51 --> XSS Filtering completed
DEBUG - 2016-09-19 13:29:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 13:29:51 --> Language Class Initialized
DEBUG - 2016-09-19 13:29:51 --> Loader Class Initialized
DEBUG - 2016-09-19 13:29:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 13:29:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 13:29:51 --> Helper loaded: url_helper
DEBUG - 2016-09-19 13:29:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 13:29:51 --> Helper loaded: file_helper
DEBUG - 2016-09-19 13:29:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 13:29:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 13:29:51 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 13:29:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 13:29:51 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 13:29:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 13:29:51 --> Helper loaded: common_helper
DEBUG - 2016-09-19 13:29:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 13:29:51 --> Helper loaded: common_helper
DEBUG - 2016-09-19 13:29:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 13:29:51 --> Helper loaded: form_helper
DEBUG - 2016-09-19 13:29:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 13:29:51 --> Helper loaded: security_helper
DEBUG - 2016-09-19 13:29:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 13:29:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 13:29:51 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 13:29:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 13:29:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 13:29:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 13:29:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 13:29:51 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 13:29:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 13:29:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 13:29:51 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 13:29:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 13:29:52 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 13:29:52 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 13:29:52 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 13:29:52 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 13:29:52 --> Database Driver Class Initialized
DEBUG - 2016-09-19 13:29:52 --> Session Class Initialized
DEBUG - 2016-09-19 13:29:52 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 13:29:52 --> Helper loaded: string_helper
DEBUG - 2016-09-19 13:29:52 --> Session routines successfully run
DEBUG - 2016-09-19 13:29:52 --> Native_session Class Initialized
DEBUG - 2016-09-19 13:29:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 13:29:52 --> Form Validation Class Initialized
DEBUG - 2016-09-19 13:29:52 --> Form Validation Class Initialized
DEBUG - 2016-09-19 13:29:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 13:29:52 --> Controller Class Initialized
DEBUG - 2016-09-19 13:29:52 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 13:29:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 13:29:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 13:29:52 --> Carabiner: library configured.
DEBUG - 2016-09-19 13:29:52 --> Carabiner: library configured.
DEBUG - 2016-09-19 13:29:52 --> User Agent Class Initialized
DEBUG - 2016-09-19 13:29:52 --> Model Class Initialized
DEBUG - 2016-09-19 13:29:52 --> Model Class Initialized
DEBUG - 2016-09-19 13:29:52 --> Model Class Initialized
DEBUG - 2016-09-19 13:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-19 13:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-19 13:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-19 13:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 13:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-19 13:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 13:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-19 13:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-19 13:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-19 13:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 13:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-19 13:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 13:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-19 13:29:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-09-19 13:29:52 --> Final output sent to browser
DEBUG - 2016-09-19 13:29:52 --> Total execution time: 1.6215
DEBUG - 2016-09-19 18:35:29 --> Config Class Initialized
DEBUG - 2016-09-19 18:35:29 --> Hooks Class Initialized
DEBUG - 2016-09-19 18:35:29 --> Utf8 Class Initialized
DEBUG - 2016-09-19 18:35:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 18:35:29 --> URI Class Initialized
DEBUG - 2016-09-19 18:35:29 --> Router Class Initialized
DEBUG - 2016-09-19 18:35:29 --> No URI present. Default controller set.
DEBUG - 2016-09-19 18:35:29 --> Output Class Initialized
DEBUG - 2016-09-19 18:35:29 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 18:35:29 --> Security Class Initialized
DEBUG - 2016-09-19 18:35:29 --> Input Class Initialized
DEBUG - 2016-09-19 18:35:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 18:35:29 --> Language Class Initialized
DEBUG - 2016-09-19 18:35:29 --> Loader Class Initialized
DEBUG - 2016-09-19 18:35:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 18:35:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 18:35:30 --> Helper loaded: url_helper
DEBUG - 2016-09-19 18:35:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 18:35:30 --> Helper loaded: file_helper
DEBUG - 2016-09-19 18:35:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 18:35:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 18:35:30 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 18:35:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 18:35:30 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 18:35:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 18:35:30 --> Helper loaded: common_helper
DEBUG - 2016-09-19 18:35:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 18:35:30 --> Helper loaded: common_helper
DEBUG - 2016-09-19 18:35:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 18:35:30 --> Helper loaded: form_helper
DEBUG - 2016-09-19 18:35:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 18:35:30 --> Helper loaded: security_helper
DEBUG - 2016-09-19 18:35:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 18:35:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 18:35:30 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 18:35:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 18:35:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 18:35:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 18:35:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 18:35:30 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 18:35:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 18:35:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 18:35:30 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 18:35:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 18:35:31 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 18:35:31 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 18:35:31 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 18:35:31 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 18:35:31 --> Database Driver Class Initialized
DEBUG - 2016-09-19 18:35:31 --> Session Class Initialized
DEBUG - 2016-09-19 18:35:31 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 18:35:31 --> Helper loaded: string_helper
DEBUG - 2016-09-19 18:35:31 --> A session cookie was not found.
DEBUG - 2016-09-19 18:35:31 --> Session routines successfully run
DEBUG - 2016-09-19 18:35:31 --> Native_session Class Initialized
DEBUG - 2016-09-19 18:35:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 18:35:31 --> Form Validation Class Initialized
DEBUG - 2016-09-19 18:35:31 --> Form Validation Class Initialized
DEBUG - 2016-09-19 18:35:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 18:35:31 --> Controller Class Initialized
DEBUG - 2016-09-19 18:35:31 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 18:35:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 18:35:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 18:35:31 --> Carabiner: library configured.
DEBUG - 2016-09-19 18:35:31 --> Carabiner: library configured.
DEBUG - 2016-09-19 18:35:31 --> User Agent Class Initialized
DEBUG - 2016-09-19 18:35:31 --> Model Class Initialized
DEBUG - 2016-09-19 18:35:31 --> Model Class Initialized
DEBUG - 2016-09-19 18:35:31 --> Model Class Initialized
ERROR - 2016-09-19 18:35:32 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 18:35:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-19 18:35:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-19 18:35:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 18:35:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 18:35:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 18:35:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 18:35:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 18:35:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 18:35:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 18:35:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 18:35:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 18:35:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 18:35:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 18:35:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 18:35:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 18:35:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 18:35:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-19 18:35:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-19 18:35:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 18:35:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 18:35:32 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-19 18:35:32 --> Final output sent to browser
DEBUG - 2016-09-19 18:35:32 --> Total execution time: 2.5116
DEBUG - 2016-09-19 18:35:37 --> Config Class Initialized
DEBUG - 2016-09-19 18:35:37 --> Hooks Class Initialized
DEBUG - 2016-09-19 18:35:37 --> Utf8 Class Initialized
DEBUG - 2016-09-19 18:35:37 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 18:35:37 --> URI Class Initialized
DEBUG - 2016-09-19 18:35:38 --> Router Class Initialized
DEBUG - 2016-09-19 18:35:38 --> Output Class Initialized
DEBUG - 2016-09-19 18:35:38 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 18:35:38 --> Security Class Initialized
DEBUG - 2016-09-19 18:35:38 --> Input Class Initialized
DEBUG - 2016-09-19 18:35:38 --> XSS Filtering completed
DEBUG - 2016-09-19 18:35:38 --> XSS Filtering completed
DEBUG - 2016-09-19 18:35:38 --> XSS Filtering completed
DEBUG - 2016-09-19 18:35:38 --> XSS Filtering completed
DEBUG - 2016-09-19 18:35:38 --> XSS Filtering completed
DEBUG - 2016-09-19 18:35:38 --> XSS Filtering completed
DEBUG - 2016-09-19 18:35:38 --> XSS Filtering completed
DEBUG - 2016-09-19 18:35:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 18:35:38 --> Language Class Initialized
DEBUG - 2016-09-19 18:35:38 --> Loader Class Initialized
DEBUG - 2016-09-19 18:35:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 18:35:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 18:35:38 --> Helper loaded: url_helper
DEBUG - 2016-09-19 18:35:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 18:35:38 --> Helper loaded: file_helper
DEBUG - 2016-09-19 18:35:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 18:35:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 18:35:38 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 18:35:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 18:35:38 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 18:35:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 18:35:38 --> Helper loaded: common_helper
DEBUG - 2016-09-19 18:35:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 18:35:38 --> Helper loaded: common_helper
DEBUG - 2016-09-19 18:35:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 18:35:39 --> Helper loaded: form_helper
DEBUG - 2016-09-19 18:35:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 18:35:39 --> Helper loaded: security_helper
DEBUG - 2016-09-19 18:35:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 18:35:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 18:35:39 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 18:35:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 18:35:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 18:35:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 18:35:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 18:35:39 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 18:35:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 18:35:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 18:35:39 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 18:35:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 18:35:39 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 18:35:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 18:35:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 18:35:39 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 18:35:39 --> Database Driver Class Initialized
DEBUG - 2016-09-19 18:35:39 --> Session Class Initialized
DEBUG - 2016-09-19 18:35:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 18:35:39 --> Helper loaded: string_helper
DEBUG - 2016-09-19 18:35:39 --> Session routines successfully run
DEBUG - 2016-09-19 18:35:40 --> Native_session Class Initialized
DEBUG - 2016-09-19 18:35:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 18:35:40 --> Form Validation Class Initialized
DEBUG - 2016-09-19 18:35:40 --> Form Validation Class Initialized
DEBUG - 2016-09-19 18:35:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 18:35:40 --> Controller Class Initialized
DEBUG - 2016-09-19 18:35:40 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 18:35:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 18:35:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 18:35:40 --> Carabiner: library configured.
DEBUG - 2016-09-19 18:35:40 --> Carabiner: library configured.
DEBUG - 2016-09-19 18:35:40 --> User Agent Class Initialized
DEBUG - 2016-09-19 18:35:40 --> Model Class Initialized
DEBUG - 2016-09-19 18:35:40 --> Model Class Initialized
DEBUG - 2016-09-19 18:35:40 --> Model Class Initialized
DEBUG - 2016-09-19 18:35:40 --> Model Class Initialized
DEBUG - 2016-09-19 18:35:40 --> Model Class Initialized
DEBUG - 2016-09-19 18:35:40 --> Model Class Initialized
DEBUG - 2016-09-19 18:35:40 --> Model Class Initialized
DEBUG - 2016-09-19 18:35:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-19 18:35:40 --> Final output sent to browser
DEBUG - 2016-09-19 18:35:40 --> Total execution time: 2.9922
DEBUG - 2016-09-19 18:43:42 --> Config Class Initialized
DEBUG - 2016-09-19 18:43:42 --> Hooks Class Initialized
DEBUG - 2016-09-19 18:43:42 --> Utf8 Class Initialized
DEBUG - 2016-09-19 18:43:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 18:43:43 --> URI Class Initialized
DEBUG - 2016-09-19 18:43:43 --> Router Class Initialized
DEBUG - 2016-09-19 18:43:43 --> Output Class Initialized
DEBUG - 2016-09-19 18:43:43 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 18:43:43 --> Security Class Initialized
DEBUG - 2016-09-19 18:43:43 --> Input Class Initialized
DEBUG - 2016-09-19 18:43:43 --> XSS Filtering completed
DEBUG - 2016-09-19 18:43:43 --> XSS Filtering completed
DEBUG - 2016-09-19 18:43:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 18:43:43 --> Language Class Initialized
DEBUG - 2016-09-19 18:43:43 --> Loader Class Initialized
DEBUG - 2016-09-19 18:43:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 18:43:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 18:43:43 --> Helper loaded: url_helper
DEBUG - 2016-09-19 18:43:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 18:43:43 --> Helper loaded: file_helper
DEBUG - 2016-09-19 18:43:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 18:43:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 18:43:43 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 18:43:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 18:43:43 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 18:43:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 18:43:43 --> Helper loaded: common_helper
DEBUG - 2016-09-19 18:43:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 18:43:43 --> Helper loaded: common_helper
DEBUG - 2016-09-19 18:43:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 18:43:43 --> Helper loaded: form_helper
DEBUG - 2016-09-19 18:43:43 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 18:43:43 --> Helper loaded: security_helper
DEBUG - 2016-09-19 18:43:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 18:43:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 18:43:43 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 18:43:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 18:43:43 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 18:43:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 18:43:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 18:43:43 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 18:43:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 18:43:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 18:43:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 18:43:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 18:43:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 18:43:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 18:43:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 18:43:44 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 18:43:44 --> Database Driver Class Initialized
DEBUG - 2016-09-19 18:43:44 --> Session Class Initialized
DEBUG - 2016-09-19 18:43:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 18:43:44 --> Helper loaded: string_helper
DEBUG - 2016-09-19 18:43:44 --> Session routines successfully run
DEBUG - 2016-09-19 18:43:44 --> Native_session Class Initialized
DEBUG - 2016-09-19 18:43:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 18:43:44 --> Form Validation Class Initialized
DEBUG - 2016-09-19 18:43:44 --> Form Validation Class Initialized
DEBUG - 2016-09-19 18:43:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 18:43:44 --> Controller Class Initialized
DEBUG - 2016-09-19 18:43:44 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 18:43:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 18:43:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 18:43:44 --> Carabiner: library configured.
DEBUG - 2016-09-19 18:43:44 --> Carabiner: library configured.
DEBUG - 2016-09-19 18:43:44 --> User Agent Class Initialized
DEBUG - 2016-09-19 18:43:44 --> Model Class Initialized
DEBUG - 2016-09-19 18:43:44 --> Model Class Initialized
DEBUG - 2016-09-19 18:43:44 --> Model Class Initialized
ERROR - 2016-09-19 18:43:44 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 18:43:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-19 18:43:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 18:43:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 18:43:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 18:43:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 18:43:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 18:43:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 18:43:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 18:43:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 18:43:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 18:43:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 18:43:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 18:43:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 18:43:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 18:43:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 18:43:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-19 18:43:45 --> Final output sent to browser
DEBUG - 2016-09-19 18:43:45 --> Total execution time: 1.8310
DEBUG - 2016-09-19 18:45:45 --> Config Class Initialized
DEBUG - 2016-09-19 18:45:45 --> Hooks Class Initialized
DEBUG - 2016-09-19 18:45:45 --> Utf8 Class Initialized
DEBUG - 2016-09-19 18:45:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 18:45:45 --> URI Class Initialized
DEBUG - 2016-09-19 18:45:45 --> Router Class Initialized
DEBUG - 2016-09-19 18:45:45 --> Output Class Initialized
DEBUG - 2016-09-19 18:45:45 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 18:45:45 --> Security Class Initialized
DEBUG - 2016-09-19 18:45:45 --> Input Class Initialized
DEBUG - 2016-09-19 18:45:45 --> XSS Filtering completed
DEBUG - 2016-09-19 18:45:45 --> XSS Filtering completed
DEBUG - 2016-09-19 18:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 18:45:45 --> Language Class Initialized
DEBUG - 2016-09-19 18:45:45 --> Loader Class Initialized
DEBUG - 2016-09-19 18:45:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 18:45:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 18:45:46 --> Helper loaded: url_helper
DEBUG - 2016-09-19 18:45:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 18:45:46 --> Helper loaded: file_helper
DEBUG - 2016-09-19 18:45:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 18:45:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 18:45:46 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 18:45:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 18:45:46 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 18:45:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 18:45:46 --> Helper loaded: common_helper
DEBUG - 2016-09-19 18:45:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 18:45:46 --> Helper loaded: common_helper
DEBUG - 2016-09-19 18:45:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 18:45:46 --> Helper loaded: form_helper
DEBUG - 2016-09-19 18:45:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 18:45:46 --> Helper loaded: security_helper
DEBUG - 2016-09-19 18:45:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 18:45:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 18:45:46 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 18:45:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 18:45:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 18:45:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 18:45:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 18:45:46 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 18:45:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 18:45:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 18:45:46 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 18:45:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 18:45:46 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 18:45:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 18:45:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 18:45:47 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 18:45:47 --> Database Driver Class Initialized
DEBUG - 2016-09-19 18:45:47 --> Session Class Initialized
DEBUG - 2016-09-19 18:45:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 18:45:47 --> Helper loaded: string_helper
DEBUG - 2016-09-19 18:45:47 --> Session routines successfully run
DEBUG - 2016-09-19 18:45:47 --> Native_session Class Initialized
DEBUG - 2016-09-19 18:45:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 18:45:47 --> Form Validation Class Initialized
DEBUG - 2016-09-19 18:45:47 --> Form Validation Class Initialized
DEBUG - 2016-09-19 18:45:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 18:45:47 --> Controller Class Initialized
DEBUG - 2016-09-19 18:45:47 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 18:45:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 18:45:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 18:45:47 --> Carabiner: library configured.
DEBUG - 2016-09-19 18:45:47 --> Carabiner: library configured.
DEBUG - 2016-09-19 18:45:47 --> User Agent Class Initialized
DEBUG - 2016-09-19 18:45:47 --> Model Class Initialized
DEBUG - 2016-09-19 18:45:47 --> Model Class Initialized
DEBUG - 2016-09-19 18:45:47 --> Model Class Initialized
ERROR - 2016-09-19 18:45:47 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 18:45:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-19 18:45:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 18:45:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 18:45:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 18:45:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 18:45:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 18:45:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 18:45:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 18:45:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 18:45:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 18:45:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 18:45:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 18:45:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 18:45:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 18:45:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 18:45:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-19 18:45:48 --> Final output sent to browser
DEBUG - 2016-09-19 18:45:48 --> Total execution time: 2.2999
DEBUG - 2016-09-19 18:46:15 --> Config Class Initialized
DEBUG - 2016-09-19 18:46:15 --> Hooks Class Initialized
DEBUG - 2016-09-19 18:46:15 --> Utf8 Class Initialized
DEBUG - 2016-09-19 18:46:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 18:46:15 --> URI Class Initialized
DEBUG - 2016-09-19 18:46:15 --> Router Class Initialized
DEBUG - 2016-09-19 18:46:15 --> Output Class Initialized
DEBUG - 2016-09-19 18:46:15 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 18:46:15 --> Security Class Initialized
DEBUG - 2016-09-19 18:46:15 --> Input Class Initialized
DEBUG - 2016-09-19 18:46:15 --> XSS Filtering completed
DEBUG - 2016-09-19 18:46:15 --> XSS Filtering completed
DEBUG - 2016-09-19 18:46:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 18:46:15 --> Language Class Initialized
DEBUG - 2016-09-19 18:46:15 --> Loader Class Initialized
DEBUG - 2016-09-19 18:46:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 18:46:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 18:46:15 --> Helper loaded: url_helper
DEBUG - 2016-09-19 18:46:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 18:46:15 --> Helper loaded: file_helper
DEBUG - 2016-09-19 18:46:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 18:46:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 18:46:15 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 18:46:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 18:46:15 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 18:46:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 18:46:15 --> Helper loaded: common_helper
DEBUG - 2016-09-19 18:46:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 18:46:15 --> Helper loaded: common_helper
DEBUG - 2016-09-19 18:46:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 18:46:15 --> Helper loaded: form_helper
DEBUG - 2016-09-19 18:46:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 18:46:16 --> Helper loaded: security_helper
DEBUG - 2016-09-19 18:46:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 18:46:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 18:46:16 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 18:46:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 18:46:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 18:46:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 18:46:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 18:46:16 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 18:46:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 18:46:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 18:46:16 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 18:46:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 18:46:16 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 18:46:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 18:46:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 18:46:16 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 18:46:16 --> Database Driver Class Initialized
DEBUG - 2016-09-19 18:46:16 --> Session Class Initialized
DEBUG - 2016-09-19 18:46:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 18:46:16 --> Helper loaded: string_helper
DEBUG - 2016-09-19 18:46:16 --> Session routines successfully run
DEBUG - 2016-09-19 18:46:16 --> Native_session Class Initialized
DEBUG - 2016-09-19 18:46:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 18:46:16 --> Form Validation Class Initialized
DEBUG - 2016-09-19 18:46:16 --> Form Validation Class Initialized
DEBUG - 2016-09-19 18:46:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 18:46:16 --> Controller Class Initialized
DEBUG - 2016-09-19 18:46:16 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 18:46:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 18:46:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 18:46:16 --> Carabiner: library configured.
DEBUG - 2016-09-19 18:46:16 --> Carabiner: library configured.
DEBUG - 2016-09-19 18:46:16 --> User Agent Class Initialized
DEBUG - 2016-09-19 18:46:16 --> Model Class Initialized
DEBUG - 2016-09-19 18:46:16 --> Model Class Initialized
DEBUG - 2016-09-19 18:46:16 --> Model Class Initialized
ERROR - 2016-09-19 18:46:17 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 18:46:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-19 18:46:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 18:46:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 18:46:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 18:46:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 18:46:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 18:46:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 18:46:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 18:46:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 18:46:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 18:46:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 18:46:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 18:46:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 18:46:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 18:46:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 18:46:17 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-19 18:46:17 --> Final output sent to browser
DEBUG - 2016-09-19 18:46:17 --> Total execution time: 1.8361
DEBUG - 2016-09-19 18:54:40 --> Config Class Initialized
DEBUG - 2016-09-19 18:54:40 --> Hooks Class Initialized
DEBUG - 2016-09-19 18:54:40 --> Utf8 Class Initialized
DEBUG - 2016-09-19 18:54:40 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 18:54:40 --> URI Class Initialized
DEBUG - 2016-09-19 18:54:40 --> Router Class Initialized
DEBUG - 2016-09-19 18:54:40 --> Output Class Initialized
DEBUG - 2016-09-19 18:54:40 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 18:54:40 --> Security Class Initialized
DEBUG - 2016-09-19 18:54:40 --> Input Class Initialized
DEBUG - 2016-09-19 18:54:40 --> XSS Filtering completed
DEBUG - 2016-09-19 18:54:40 --> XSS Filtering completed
DEBUG - 2016-09-19 18:54:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 18:54:40 --> Language Class Initialized
DEBUG - 2016-09-19 18:54:40 --> Loader Class Initialized
DEBUG - 2016-09-19 18:54:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 18:54:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 18:54:40 --> Helper loaded: url_helper
DEBUG - 2016-09-19 18:54:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 18:54:41 --> Helper loaded: file_helper
DEBUG - 2016-09-19 18:54:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 18:54:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 18:54:41 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 18:54:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 18:54:41 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 18:54:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 18:54:41 --> Helper loaded: common_helper
DEBUG - 2016-09-19 18:54:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 18:54:41 --> Helper loaded: common_helper
DEBUG - 2016-09-19 18:54:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 18:54:41 --> Helper loaded: form_helper
DEBUG - 2016-09-19 18:54:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 18:54:41 --> Helper loaded: security_helper
DEBUG - 2016-09-19 18:54:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 18:54:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 18:54:41 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 18:54:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 18:54:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 18:54:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 18:54:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 18:54:41 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 18:54:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 18:54:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 18:54:41 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 18:54:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 18:54:41 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 18:54:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 18:54:42 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 18:54:42 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 18:54:42 --> Database Driver Class Initialized
DEBUG - 2016-09-19 18:54:42 --> Session Class Initialized
DEBUG - 2016-09-19 18:54:42 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 18:54:42 --> Helper loaded: string_helper
DEBUG - 2016-09-19 18:54:42 --> Session routines successfully run
DEBUG - 2016-09-19 18:54:42 --> Native_session Class Initialized
DEBUG - 2016-09-19 18:54:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 18:54:42 --> Form Validation Class Initialized
DEBUG - 2016-09-19 18:54:42 --> Form Validation Class Initialized
DEBUG - 2016-09-19 18:54:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 18:54:42 --> Controller Class Initialized
DEBUG - 2016-09-19 18:54:42 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 18:54:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 18:54:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 18:54:42 --> Carabiner: library configured.
DEBUG - 2016-09-19 18:54:42 --> Carabiner: library configured.
DEBUG - 2016-09-19 18:54:42 --> User Agent Class Initialized
DEBUG - 2016-09-19 18:54:42 --> Model Class Initialized
DEBUG - 2016-09-19 18:54:42 --> Model Class Initialized
DEBUG - 2016-09-19 18:54:42 --> Model Class Initialized
ERROR - 2016-09-19 18:54:42 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 18:54:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-19 18:54:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 18:54:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 18:54:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 18:54:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 18:54:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 18:54:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 18:54:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 18:54:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 18:54:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 18:54:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 18:54:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 18:54:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 18:54:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 18:54:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 18:54:43 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-19 18:54:43 --> Final output sent to browser
DEBUG - 2016-09-19 18:54:43 --> Total execution time: 2.5876
DEBUG - 2016-09-19 18:55:24 --> Config Class Initialized
DEBUG - 2016-09-19 18:55:24 --> Hooks Class Initialized
DEBUG - 2016-09-19 18:55:24 --> Utf8 Class Initialized
DEBUG - 2016-09-19 18:55:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 18:55:25 --> URI Class Initialized
DEBUG - 2016-09-19 18:55:25 --> Router Class Initialized
DEBUG - 2016-09-19 18:55:25 --> Output Class Initialized
DEBUG - 2016-09-19 18:55:25 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 18:55:25 --> Security Class Initialized
DEBUG - 2016-09-19 18:55:25 --> Input Class Initialized
DEBUG - 2016-09-19 18:55:25 --> XSS Filtering completed
DEBUG - 2016-09-19 18:55:25 --> XSS Filtering completed
DEBUG - 2016-09-19 18:55:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 18:55:25 --> Language Class Initialized
DEBUG - 2016-09-19 18:55:25 --> Loader Class Initialized
DEBUG - 2016-09-19 18:55:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 18:55:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 18:55:25 --> Helper loaded: url_helper
DEBUG - 2016-09-19 18:55:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 18:55:25 --> Helper loaded: file_helper
DEBUG - 2016-09-19 18:55:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 18:55:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 18:55:25 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 18:55:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 18:55:25 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 18:55:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 18:55:25 --> Helper loaded: common_helper
DEBUG - 2016-09-19 18:55:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 18:55:25 --> Helper loaded: common_helper
DEBUG - 2016-09-19 18:55:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 18:55:25 --> Helper loaded: form_helper
DEBUG - 2016-09-19 18:55:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 18:55:25 --> Helper loaded: security_helper
DEBUG - 2016-09-19 18:55:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 18:55:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 18:55:26 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 18:55:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 18:55:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 18:55:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 18:55:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 18:55:26 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 18:55:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 18:55:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 18:55:26 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 18:55:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 18:55:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 18:55:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 18:55:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 18:55:26 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 18:55:26 --> Database Driver Class Initialized
DEBUG - 2016-09-19 18:55:26 --> Session Class Initialized
DEBUG - 2016-09-19 18:55:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 18:55:26 --> Helper loaded: string_helper
DEBUG - 2016-09-19 18:55:26 --> Session routines successfully run
DEBUG - 2016-09-19 18:55:26 --> Native_session Class Initialized
DEBUG - 2016-09-19 18:55:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 18:55:26 --> Form Validation Class Initialized
DEBUG - 2016-09-19 18:55:26 --> Form Validation Class Initialized
DEBUG - 2016-09-19 18:55:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 18:55:26 --> Controller Class Initialized
DEBUG - 2016-09-19 18:55:26 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 18:55:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 18:55:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 18:55:27 --> Carabiner: library configured.
DEBUG - 2016-09-19 18:55:27 --> Carabiner: library configured.
DEBUG - 2016-09-19 18:55:27 --> User Agent Class Initialized
DEBUG - 2016-09-19 18:55:27 --> Model Class Initialized
DEBUG - 2016-09-19 18:55:27 --> Model Class Initialized
DEBUG - 2016-09-19 18:55:27 --> Model Class Initialized
ERROR - 2016-09-19 18:55:27 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 18:55:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-19 18:55:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 18:55:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 18:55:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 18:55:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 18:55:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 18:55:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 18:55:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 18:55:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 18:55:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 18:55:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 18:55:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 18:55:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 18:55:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 18:55:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 18:55:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-19 18:55:27 --> Final output sent to browser
DEBUG - 2016-09-19 18:55:27 --> Total execution time: 2.3445
DEBUG - 2016-09-19 19:54:26 --> Config Class Initialized
DEBUG - 2016-09-19 19:54:26 --> Hooks Class Initialized
DEBUG - 2016-09-19 19:54:26 --> Utf8 Class Initialized
DEBUG - 2016-09-19 19:54:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-19 19:54:26 --> URI Class Initialized
DEBUG - 2016-09-19 19:54:26 --> Router Class Initialized
DEBUG - 2016-09-19 19:54:26 --> Output Class Initialized
DEBUG - 2016-09-19 19:54:26 --> Cache file has expired. File deleted
DEBUG - 2016-09-19 19:54:26 --> Security Class Initialized
DEBUG - 2016-09-19 19:54:26 --> Input Class Initialized
DEBUG - 2016-09-19 19:54:26 --> XSS Filtering completed
DEBUG - 2016-09-19 19:54:26 --> XSS Filtering completed
DEBUG - 2016-09-19 19:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-19 19:54:27 --> Language Class Initialized
DEBUG - 2016-09-19 19:54:27 --> Loader Class Initialized
DEBUG - 2016-09-19 19:54:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-19 19:54:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-19 19:54:27 --> Helper loaded: url_helper
DEBUG - 2016-09-19 19:54:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-19 19:54:27 --> Helper loaded: file_helper
DEBUG - 2016-09-19 19:54:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 19:54:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-19 19:54:27 --> Helper loaded: conf_helper
DEBUG - 2016-09-19 19:54:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-19 19:54:27 --> Check Exists common_helper.php: No
DEBUG - 2016-09-19 19:54:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-19 19:54:27 --> Helper loaded: common_helper
DEBUG - 2016-09-19 19:54:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-19 19:54:27 --> Helper loaded: common_helper
DEBUG - 2016-09-19 19:54:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-19 19:54:27 --> Helper loaded: form_helper
DEBUG - 2016-09-19 19:54:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-19 19:54:27 --> Helper loaded: security_helper
DEBUG - 2016-09-19 19:54:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 19:54:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-19 19:54:27 --> Helper loaded: lang_helper
DEBUG - 2016-09-19 19:54:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-19 19:54:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-19 19:54:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-19 19:54:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-19 19:54:27 --> Helper loaded: atlant_helper
DEBUG - 2016-09-19 19:54:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 19:54:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-19 19:54:28 --> Helper loaded: crypto_helper
DEBUG - 2016-09-19 19:54:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-19 19:54:28 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-19 19:54:28 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-19 19:54:28 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-19 19:54:28 --> Helper loaded: sidika_helper
DEBUG - 2016-09-19 19:54:28 --> Database Driver Class Initialized
DEBUG - 2016-09-19 19:54:28 --> Session Class Initialized
DEBUG - 2016-09-19 19:54:28 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-19 19:54:28 --> Helper loaded: string_helper
DEBUG - 2016-09-19 19:54:28 --> Session routines successfully run
DEBUG - 2016-09-19 19:54:28 --> Native_session Class Initialized
DEBUG - 2016-09-19 19:54:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-19 19:54:28 --> Form Validation Class Initialized
DEBUG - 2016-09-19 19:54:28 --> Form Validation Class Initialized
DEBUG - 2016-09-19 19:54:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-19 19:54:28 --> Controller Class Initialized
DEBUG - 2016-09-19 19:54:28 --> Carabiner: Library initialized.
DEBUG - 2016-09-19 19:54:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-19 19:54:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-19 19:54:28 --> Carabiner: library configured.
DEBUG - 2016-09-19 19:54:28 --> Carabiner: library configured.
DEBUG - 2016-09-19 19:54:28 --> User Agent Class Initialized
DEBUG - 2016-09-19 19:54:29 --> Model Class Initialized
DEBUG - 2016-09-19 19:54:29 --> Model Class Initialized
DEBUG - 2016-09-19 19:54:29 --> Model Class Initialized
ERROR - 2016-09-19 19:54:29 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-19 19:54:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-19 19:54:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 19:54:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 19:54:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 19:54:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 19:54:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 19:54:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 19:54:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 19:54:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-19 19:54:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-19 19:54:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-19 19:54:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-19 19:54:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-19 19:54:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-19 19:54:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-19 19:54:29 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-19 19:54:29 --> Final output sent to browser
DEBUG - 2016-09-19 19:54:29 --> Total execution time: 2.6478
