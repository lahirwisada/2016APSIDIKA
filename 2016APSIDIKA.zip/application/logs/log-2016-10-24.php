<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-10-24 13:06:17 --> Config Class Initialized
DEBUG - 2016-10-24 13:06:17 --> Hooks Class Initialized
DEBUG - 2016-10-24 13:06:17 --> Utf8 Class Initialized
DEBUG - 2016-10-24 13:06:17 --> UTF-8 Support Enabled
DEBUG - 2016-10-24 13:06:17 --> URI Class Initialized
DEBUG - 2016-10-24 13:06:17 --> Router Class Initialized
DEBUG - 2016-10-24 13:06:17 --> No URI present. Default controller set.
DEBUG - 2016-10-24 13:06:17 --> Output Class Initialized
DEBUG - 2016-10-24 13:06:17 --> Security Class Initialized
DEBUG - 2016-10-24 13:06:17 --> Input Class Initialized
DEBUG - 2016-10-24 13:06:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-24 13:06:17 --> Language Class Initialized
DEBUG - 2016-10-24 13:06:17 --> Loader Class Initialized
DEBUG - 2016-10-24 13:06:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-24 13:06:18 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-24 13:06:18 --> Helper loaded: url_helper
DEBUG - 2016-10-24 13:06:18 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-24 13:06:18 --> Helper loaded: file_helper
DEBUG - 2016-10-24 13:06:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-24 13:06:18 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-24 13:06:18 --> Helper loaded: conf_helper
DEBUG - 2016-10-24 13:06:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-24 13:06:18 --> Check Exists common_helper.php: No
DEBUG - 2016-10-24 13:06:18 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-24 13:06:18 --> Helper loaded: common_helper
DEBUG - 2016-10-24 13:06:18 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-24 13:06:18 --> Helper loaded: common_helper
DEBUG - 2016-10-24 13:06:18 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-24 13:06:18 --> Helper loaded: form_helper
DEBUG - 2016-10-24 13:06:18 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-24 13:06:18 --> Helper loaded: security_helper
DEBUG - 2016-10-24 13:06:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-24 13:06:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-24 13:06:18 --> Helper loaded: lang_helper
DEBUG - 2016-10-24 13:06:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-24 13:06:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-24 13:06:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-24 13:06:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-24 13:06:18 --> Helper loaded: atlant_helper
DEBUG - 2016-10-24 13:06:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-24 13:06:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-24 13:06:18 --> Helper loaded: crypto_helper
DEBUG - 2016-10-24 13:06:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-24 13:06:18 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-24 13:06:18 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-24 13:06:18 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-24 13:06:18 --> Helper loaded: sidika_helper
DEBUG - 2016-10-24 13:06:18 --> Database Driver Class Initialized
ERROR - 2016-10-24 13:06:19 --> Severity: Warning  --> pg_connect(): Unable to connect to PostgreSQL server: could not connect to server: Connection refused (0x0000274D/10061)
	Is the server running on host &quot;127.0.0.1&quot; and accepting
	TCP/IP connections on port 5432? E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 87
ERROR - 2016-10-24 13:06:19 --> Unable to connect to the database
DEBUG - 2016-10-24 13:06:19 --> Language file loaded: language/indonesia/db_lang.php
