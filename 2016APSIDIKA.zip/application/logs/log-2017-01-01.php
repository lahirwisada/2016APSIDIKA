<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-01-01 22:05:23 --> Config Class Initialized
DEBUG - 2017-01-01 22:05:23 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:05:23 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:05:23 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:05:23 --> URI Class Initialized
DEBUG - 2017-01-01 22:05:23 --> Router Class Initialized
DEBUG - 2017-01-01 22:05:23 --> No URI present. Default controller set.
DEBUG - 2017-01-01 22:05:23 --> Output Class Initialized
DEBUG - 2017-01-01 22:05:23 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:05:23 --> Security Class Initialized
DEBUG - 2017-01-01 22:05:23 --> Input Class Initialized
DEBUG - 2017-01-01 22:05:23 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:05:23 --> Language Class Initialized
DEBUG - 2017-01-01 22:05:23 --> Loader Class Initialized
DEBUG - 2017-01-01 22:05:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:05:23 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:05:23 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:05:23 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:05:23 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:05:23 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:05:23 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:05:23 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:05:23 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:05:23 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:05:23 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:05:23 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:05:23 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:05:23 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:05:23 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:05:23 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:05:23 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:05:23 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:05:23 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:05:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:05:23 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:05:23 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:05:23 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:05:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:05:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:05:23 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:05:23 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:05:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:05:23 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:05:23 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:05:23 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:05:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:05:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:05:23 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:05:23 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:05:24 --> Session Class Initialized
DEBUG - 2017-01-01 22:05:24 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:05:24 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:05:24 --> A session cookie was not found.
DEBUG - 2017-01-01 22:05:24 --> Session routines successfully run
DEBUG - 2017-01-01 22:05:24 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:05:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:05:24 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:05:24 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:05:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:05:24 --> Controller Class Initialized
DEBUG - 2017-01-01 22:05:24 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:05:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:05:24 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:05:24 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:05:24 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:05:24 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:05:24 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:24 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:24 --> Model Class Initialized
ERROR - 2017-01-01 22:05:24 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2017-01-01 22:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2017-01-01 22:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2017-01-01 22:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-01 22:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-01 22:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-01 22:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-01 22:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-01 22:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-01 22:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-01 22:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-01 22:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-01 22:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-01 22:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-01 22:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-01 22:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-01 22:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-01 22:05:24 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2017-01-01 22:05:24 --> Final output sent to browser
DEBUG - 2017-01-01 22:05:24 --> Total execution time: 1.4198
DEBUG - 2017-01-01 22:05:25 --> Config Class Initialized
DEBUG - 2017-01-01 22:05:25 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:05:25 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:05:25 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:05:25 --> URI Class Initialized
DEBUG - 2017-01-01 22:05:25 --> Router Class Initialized
DEBUG - 2017-01-01 22:05:25 --> Output Class Initialized
DEBUG - 2017-01-01 22:05:25 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:05:25 --> Security Class Initialized
DEBUG - 2017-01-01 22:05:25 --> Input Class Initialized
DEBUG - 2017-01-01 22:05:25 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:25 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:25 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:25 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:25 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:25 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:25 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:05:25 --> Language Class Initialized
DEBUG - 2017-01-01 22:05:25 --> Loader Class Initialized
DEBUG - 2017-01-01 22:05:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:05:25 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:05:25 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:05:25 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:05:25 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:05:25 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:05:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:05:25 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:05:25 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:05:25 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:05:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:05:25 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:05:25 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:05:25 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:05:25 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:05:25 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:05:25 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:05:25 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:05:25 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:05:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:05:25 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:05:25 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:05:25 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:05:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:05:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:05:25 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:05:25 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:05:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:05:25 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:05:25 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:05:25 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:05:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:05:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:05:25 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:05:25 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:05:25 --> Session Class Initialized
DEBUG - 2017-01-01 22:05:25 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:05:25 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:05:25 --> Session routines successfully run
DEBUG - 2017-01-01 22:05:25 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:05:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:05:25 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:05:25 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:05:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:05:25 --> Controller Class Initialized
DEBUG - 2017-01-01 22:05:25 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:05:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:05:25 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:05:25 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:05:25 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:05:25 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:05:25 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:25 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:25 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:25 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:25 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:25 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:25 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:26 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2017-01-01 22:05:26 --> Final output sent to browser
DEBUG - 2017-01-01 22:05:26 --> Total execution time: 0.7707
DEBUG - 2017-01-01 22:05:27 --> Config Class Initialized
DEBUG - 2017-01-01 22:05:27 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:05:27 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:05:27 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:05:27 --> URI Class Initialized
DEBUG - 2017-01-01 22:05:27 --> Router Class Initialized
DEBUG - 2017-01-01 22:05:27 --> Output Class Initialized
DEBUG - 2017-01-01 22:05:27 --> Security Class Initialized
DEBUG - 2017-01-01 22:05:27 --> Input Class Initialized
DEBUG - 2017-01-01 22:05:27 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:27 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:05:27 --> Language Class Initialized
DEBUG - 2017-01-01 22:05:27 --> Loader Class Initialized
DEBUG - 2017-01-01 22:05:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:05:27 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:05:27 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:05:27 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:05:27 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:05:27 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:05:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:05:27 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:05:27 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:05:27 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:05:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:05:27 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:05:27 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:05:27 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:05:27 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:05:27 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:05:27 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:05:27 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:05:27 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:05:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:05:27 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:05:27 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:05:27 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:05:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:05:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:05:27 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:05:27 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:05:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:05:27 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:05:27 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:05:27 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:05:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:05:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:05:27 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:05:27 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:05:27 --> Session Class Initialized
DEBUG - 2017-01-01 22:05:27 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:05:27 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:05:27 --> Session routines successfully run
DEBUG - 2017-01-01 22:05:27 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:05:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:05:27 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:05:27 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:05:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:05:27 --> Controller Class Initialized
DEBUG - 2017-01-01 22:05:27 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:05:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:05:27 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:05:27 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:05:27 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:05:27 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:05:27 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:27 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:27 --> Model Class Initialized
ERROR - 2017-01-01 22:05:27 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2017-01-01 22:05:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2017-01-01 22:05:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-01 22:05:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:05:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-01 22:05:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-01 22:05:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-01 22:05:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:05:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-01 22:05:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-01 22:05:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:05:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-01 22:05:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-01 22:05:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-01 22:05:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:05:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-01 22:05:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2017-01-01 22:05:27 --> Final output sent to browser
DEBUG - 2017-01-01 22:05:27 --> Total execution time: 0.2410
DEBUG - 2017-01-01 22:05:30 --> Config Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:05:30 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:05:30 --> URI Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Router Class Initialized
DEBUG - 2017-01-01 22:05:30 --> No URI present. Default controller set.
DEBUG - 2017-01-01 22:05:30 --> Output Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:05:30 --> Security Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Input Class Initialized
DEBUG - 2017-01-01 22:05:30 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:30 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:05:30 --> Language Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Loader Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:05:30 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:05:30 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:05:30 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:05:30 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:05:30 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:05:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:05:30 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:05:30 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:05:30 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:05:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:05:30 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:05:30 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:05:30 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:05:30 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:05:30 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:05:30 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:05:30 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:05:30 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:05:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:05:30 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:05:30 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:05:30 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:05:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:05:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:05:30 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:05:30 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:05:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:05:30 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:05:30 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:05:30 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:05:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:05:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:05:30 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:05:30 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Session Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:05:30 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:05:30 --> Session routines successfully run
DEBUG - 2017-01-01 22:05:30 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:05:30 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:05:30 --> Controller Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:05:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:05:30 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:05:30 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:05:30 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:05:30 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Model Class Initialized
ERROR - 2017-01-01 22:05:30 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2017-01-01 22:05:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2017-01-01 22:05:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2017-01-01 22:05:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-01 22:05:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:05:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-01 22:05:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-01 22:05:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-01 22:05:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-01 22:05:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-01 22:05:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:05:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-01 22:05:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-01 22:05:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:05:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-01 22:05:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-01 22:05:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-01 22:05:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-01 22:05:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-01 22:05:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:05:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-01 22:05:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2017-01-01 22:05:30 --> Final output sent to browser
DEBUG - 2017-01-01 22:05:30 --> Total execution time: 0.2572
DEBUG - 2017-01-01 22:05:30 --> Config Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:05:30 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:05:30 --> URI Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Router Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Output Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:05:30 --> Security Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Input Class Initialized
DEBUG - 2017-01-01 22:05:30 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:30 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:30 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:30 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:30 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:30 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:30 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:05:30 --> Language Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Loader Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:05:30 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:05:30 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:05:30 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:05:30 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:05:30 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:05:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:05:30 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:05:30 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:05:30 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:05:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:05:30 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:05:30 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:05:30 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:05:30 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:05:30 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:05:30 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:05:30 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:05:30 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:05:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:05:30 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:05:30 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:05:30 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:05:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:05:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:05:30 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:05:30 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:05:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:05:30 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:05:30 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:05:30 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:05:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:05:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:05:30 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:05:30 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Session Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:05:30 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:05:30 --> Session routines successfully run
DEBUG - 2017-01-01 22:05:30 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:05:30 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:05:30 --> Controller Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:05:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:05:30 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:05:30 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:05:30 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:05:30 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2017-01-01 22:05:30 --> Final output sent to browser
DEBUG - 2017-01-01 22:05:30 --> Total execution time: 0.3208
DEBUG - 2017-01-01 22:05:40 --> Config Class Initialized
DEBUG - 2017-01-01 22:05:40 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:05:40 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:05:40 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:05:40 --> URI Class Initialized
DEBUG - 2017-01-01 22:05:40 --> Router Class Initialized
DEBUG - 2017-01-01 22:05:40 --> Output Class Initialized
DEBUG - 2017-01-01 22:05:40 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:05:40 --> Security Class Initialized
DEBUG - 2017-01-01 22:05:40 --> Input Class Initialized
DEBUG - 2017-01-01 22:05:40 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:40 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:05:40 --> Language Class Initialized
DEBUG - 2017-01-01 22:05:40 --> Loader Class Initialized
DEBUG - 2017-01-01 22:05:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:05:40 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:05:40 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:05:40 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:05:40 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:05:40 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:05:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:05:40 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:05:40 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:05:40 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:05:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:05:40 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:05:40 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:05:40 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:05:40 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:05:40 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:05:40 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:05:40 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:05:40 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:05:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:05:40 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:05:40 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:05:40 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:05:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:05:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:05:40 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:05:40 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:05:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:05:40 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:05:40 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:05:40 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:05:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:05:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:05:40 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:05:40 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:05:40 --> Session Class Initialized
DEBUG - 2017-01-01 22:05:40 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:05:40 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:05:40 --> Session routines successfully run
DEBUG - 2017-01-01 22:05:40 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:05:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:05:40 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:05:40 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:05:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:05:40 --> Controller Class Initialized
DEBUG - 2017-01-01 22:05:40 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:05:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:05:40 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:05:40 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:05:40 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:05:40 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:05:40 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:40 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:40 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2017-01-01 22:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:05:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:05:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2017-01-01 22:05:40 --> Final output sent to browser
DEBUG - 2017-01-01 22:05:40 --> Total execution time: 0.3522
DEBUG - 2017-01-01 22:05:43 --> Config Class Initialized
DEBUG - 2017-01-01 22:05:43 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:05:43 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:05:43 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:05:43 --> URI Class Initialized
DEBUG - 2017-01-01 22:05:43 --> Router Class Initialized
DEBUG - 2017-01-01 22:05:43 --> Output Class Initialized
DEBUG - 2017-01-01 22:05:43 --> Security Class Initialized
DEBUG - 2017-01-01 22:05:43 --> Input Class Initialized
DEBUG - 2017-01-01 22:05:43 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:43 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:05:43 --> Language Class Initialized
DEBUG - 2017-01-01 22:05:43 --> Loader Class Initialized
DEBUG - 2017-01-01 22:05:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:05:43 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:05:43 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:05:43 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:05:43 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:05:43 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:05:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:05:43 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:05:43 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:05:43 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:05:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:05:43 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:05:43 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:05:43 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:05:43 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:05:43 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:05:43 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:05:43 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:05:43 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:05:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:05:43 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:05:43 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:05:43 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:05:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:05:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:05:43 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:05:43 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:05:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:05:43 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:05:43 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:05:43 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:05:43 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:05:43 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:05:43 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:05:43 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:05:43 --> Session Class Initialized
DEBUG - 2017-01-01 22:05:43 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:05:43 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:05:43 --> Session routines successfully run
DEBUG - 2017-01-01 22:05:43 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:05:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:05:43 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:05:43 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:05:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:05:43 --> Controller Class Initialized
DEBUG - 2017-01-01 22:05:43 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:05:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:05:43 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:05:43 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:05:43 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:05:43 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:05:43 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:43 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:43 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:43 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:43 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:43 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:43 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:43 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2017-01-01 22:05:43 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2017-01-01 22:05:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2017-01-01 22:05:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2017-01-01 22:05:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2017-01-01 22:05:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2017-01-01 22:05:43 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2017-01-01 22:05:43 --> Final output sent to browser
DEBUG - 2017-01-01 22:05:43 --> Total execution time: 0.3214
DEBUG - 2017-01-01 22:05:43 --> Config Class Initialized
DEBUG - 2017-01-01 22:05:43 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:05:43 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:05:43 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:05:43 --> URI Class Initialized
DEBUG - 2017-01-01 22:05:43 --> Router Class Initialized
ERROR - 2017-01-01 22:05:43 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2017-01-01 22:05:50 --> Config Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:05:50 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:05:50 --> URI Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Router Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Output Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:05:50 --> Security Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Input Class Initialized
DEBUG - 2017-01-01 22:05:50 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:50 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:50 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:50 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:50 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:05:50 --> Language Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Loader Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:05:50 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:05:50 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:05:50 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:05:50 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:05:50 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:05:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:05:50 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:05:50 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:05:50 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:05:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:05:50 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:05:50 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:05:50 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:05:50 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:05:50 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:05:50 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:05:50 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:05:50 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:05:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:05:50 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:05:50 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:05:50 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:05:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:05:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:05:50 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:05:50 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:05:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:05:50 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:05:50 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:05:50 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:05:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:05:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:05:50 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:05:50 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Session Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:05:50 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:05:50 --> Session routines successfully run
DEBUG - 2017-01-01 22:05:50 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:05:50 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:05:50 --> Controller Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:05:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:05:50 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:05:50 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:05:50 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:05:50 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2017-01-01 22:05:50 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:05:50 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2017-01-01 22:05:50 --> Config Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:05:50 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:05:50 --> URI Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Router Class Initialized
DEBUG - 2017-01-01 22:05:50 --> No URI present. Default controller set.
DEBUG - 2017-01-01 22:05:50 --> Output Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:05:50 --> Security Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Input Class Initialized
DEBUG - 2017-01-01 22:05:50 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:50 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:50 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:05:50 --> Language Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Loader Class Initialized
DEBUG - 2017-01-01 22:05:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:05:50 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:05:50 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:05:50 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:05:50 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:05:50 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:05:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:05:50 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:05:50 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:05:50 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:05:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:05:50 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:05:50 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:05:50 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:05:50 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:05:50 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:05:50 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:05:50 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:05:50 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:05:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:05:51 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:05:51 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:05:51 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:05:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:05:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:05:51 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:05:51 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:05:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:05:51 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:05:51 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:05:51 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:05:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:05:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:05:51 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:05:51 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Session Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:05:51 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:05:51 --> Session routines successfully run
DEBUG - 2017-01-01 22:05:51 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:05:51 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:05:51 --> Controller Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:05:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:05:51 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:05:51 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:05:51 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:05:51 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Model Class Initialized
ERROR - 2017-01-01 22:05:51 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2017-01-01 22:05:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2017-01-01 22:05:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2017-01-01 22:05:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-01 22:05:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:05:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-01 22:05:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-01 22:05:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-01 22:05:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-01 22:05:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-01 22:05:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:05:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-01 22:05:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-01 22:05:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:05:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-01 22:05:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-01 22:05:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-01 22:05:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-01 22:05:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-01 22:05:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:05:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-01 22:05:51 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2017-01-01 22:05:51 --> Final output sent to browser
DEBUG - 2017-01-01 22:05:51 --> Total execution time: 0.3581
DEBUG - 2017-01-01 22:05:51 --> Config Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:05:51 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:05:51 --> URI Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Router Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Output Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:05:51 --> Security Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Input Class Initialized
DEBUG - 2017-01-01 22:05:51 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:51 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:51 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:51 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:51 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:51 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:51 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:51 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:05:51 --> Language Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Loader Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:05:51 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:05:51 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:05:51 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:05:51 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:05:51 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:05:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:05:51 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:05:51 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:05:51 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:05:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:05:51 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:05:51 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:05:51 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:05:51 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:05:51 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:05:51 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:05:51 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:05:51 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:05:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:05:51 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:05:51 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:05:51 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:05:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:05:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:05:51 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:05:51 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:05:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:05:51 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:05:51 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:05:51 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:05:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:05:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:05:51 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:05:51 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Session Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:05:51 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:05:51 --> Session routines successfully run
DEBUG - 2017-01-01 22:05:51 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:05:51 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:05:51 --> Controller Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:05:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:05:51 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:05:51 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:05:51 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:05:51 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:51 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2017-01-01 22:05:51 --> Final output sent to browser
DEBUG - 2017-01-01 22:05:51 --> Total execution time: 0.4621
DEBUG - 2017-01-01 22:05:55 --> Config Class Initialized
DEBUG - 2017-01-01 22:05:55 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:05:55 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:05:55 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:05:55 --> URI Class Initialized
DEBUG - 2017-01-01 22:05:55 --> Router Class Initialized
DEBUG - 2017-01-01 22:05:55 --> Output Class Initialized
DEBUG - 2017-01-01 22:05:55 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:05:55 --> Security Class Initialized
DEBUG - 2017-01-01 22:05:55 --> Input Class Initialized
DEBUG - 2017-01-01 22:05:55 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:55 --> XSS Filtering completed
DEBUG - 2017-01-01 22:05:55 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:05:55 --> Language Class Initialized
DEBUG - 2017-01-01 22:05:56 --> Loader Class Initialized
DEBUG - 2017-01-01 22:05:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:05:56 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:05:56 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:05:56 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:05:56 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:05:56 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:05:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:05:56 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:05:56 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:05:56 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:05:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:05:56 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:05:56 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:05:56 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:05:56 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:05:56 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:05:56 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:05:56 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:05:56 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:05:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:05:56 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:05:56 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:05:56 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:05:56 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:05:56 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:05:56 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:05:56 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:05:56 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:05:56 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:05:56 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:05:56 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:05:56 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:05:56 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:05:56 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:05:56 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:05:56 --> Session Class Initialized
DEBUG - 2017-01-01 22:05:56 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:05:56 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:05:56 --> Session routines successfully run
DEBUG - 2017-01-01 22:05:56 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:05:56 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:05:56 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:05:56 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:05:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:05:56 --> Controller Class Initialized
DEBUG - 2017-01-01 22:05:56 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:05:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:05:56 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:05:56 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:05:56 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:05:56 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:05:56 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:56 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:56 --> Model Class Initialized
DEBUG - 2017-01-01 22:05:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2017-01-01 22:05:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:05:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:05:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:05:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:05:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:05:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:05:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:05:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:05:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:05:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:05:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:05:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:05:56 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2017-01-01 22:05:56 --> Final output sent to browser
DEBUG - 2017-01-01 22:05:56 --> Total execution time: 0.3823
DEBUG - 2017-01-01 22:06:00 --> Config Class Initialized
DEBUG - 2017-01-01 22:06:00 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:06:00 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:06:00 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:06:00 --> URI Class Initialized
DEBUG - 2017-01-01 22:06:00 --> Router Class Initialized
DEBUG - 2017-01-01 22:06:00 --> Output Class Initialized
DEBUG - 2017-01-01 22:06:00 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:06:00 --> Security Class Initialized
DEBUG - 2017-01-01 22:06:00 --> Input Class Initialized
DEBUG - 2017-01-01 22:06:00 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:00 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:00 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:06:00 --> Language Class Initialized
DEBUG - 2017-01-01 22:06:00 --> Loader Class Initialized
DEBUG - 2017-01-01 22:06:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:06:00 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:06:00 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:06:00 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:06:00 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:06:00 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:06:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:06:00 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:06:00 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:06:00 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:06:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:06:00 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:06:00 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:06:00 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:06:00 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:06:00 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:06:00 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:06:00 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:06:00 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:06:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:06:00 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:06:00 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:06:00 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:06:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:06:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:06:00 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:06:00 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:06:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:06:00 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:06:00 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:06:00 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:06:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:06:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:06:00 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:06:00 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:06:00 --> Session Class Initialized
DEBUG - 2017-01-01 22:06:00 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:06:00 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:06:00 --> Session routines successfully run
DEBUG - 2017-01-01 22:06:00 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:06:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:06:00 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:06:00 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:06:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:06:00 --> Controller Class Initialized
DEBUG - 2017-01-01 22:06:00 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:06:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:06:00 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:06:00 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:06:00 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:06:00 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:06:00 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:00 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:00 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:00 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:00 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:00 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:00 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:00 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:00 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:00 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2017-01-01 22:06:00 --> Pagination Class Initialized
DEBUG - 2017-01-01 22:06:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2017-01-01 22:06:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2017-01-01 22:06:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:06:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:06:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:06:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:06:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2017-01-01 22:06:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:06:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:06:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:06:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:06:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:06:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:06:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2017-01-01 22:06:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:06:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:06:00 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2017-01-01 22:06:00 --> Final output sent to browser
DEBUG - 2017-01-01 22:06:00 --> Total execution time: 0.6504
DEBUG - 2017-01-01 22:06:12 --> Config Class Initialized
DEBUG - 2017-01-01 22:06:12 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:06:12 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:06:12 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:06:12 --> URI Class Initialized
DEBUG - 2017-01-01 22:06:12 --> Router Class Initialized
DEBUG - 2017-01-01 22:06:12 --> Output Class Initialized
DEBUG - 2017-01-01 22:06:12 --> Security Class Initialized
DEBUG - 2017-01-01 22:06:12 --> Input Class Initialized
DEBUG - 2017-01-01 22:06:12 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:12 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:12 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:06:12 --> Language Class Initialized
DEBUG - 2017-01-01 22:06:12 --> Loader Class Initialized
DEBUG - 2017-01-01 22:06:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:06:12 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:06:12 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:06:12 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:06:12 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:06:12 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:06:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:06:12 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:06:12 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:06:12 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:06:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:06:12 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:06:12 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:06:12 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:06:12 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:06:12 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:06:12 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:06:12 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:06:12 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:06:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:06:12 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:06:12 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:06:12 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:06:13 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:06:13 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:06:13 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:06:13 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:06:13 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:06:13 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:06:13 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:06:13 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:06:13 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:06:13 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:06:13 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:06:13 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Session Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:06:13 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:06:13 --> Session routines successfully run
DEBUG - 2017-01-01 22:06:13 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:06:13 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:06:13 --> Controller Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:06:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:06:13 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:06:13 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:06:13 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:06:13 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Config Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:06:13 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:06:13 --> URI Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Router Class Initialized
DEBUG - 2017-01-01 22:06:13 --> No URI present. Default controller set.
DEBUG - 2017-01-01 22:06:13 --> Output Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:06:13 --> Security Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Input Class Initialized
DEBUG - 2017-01-01 22:06:13 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:13 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:13 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:06:13 --> Language Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Loader Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:06:13 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:06:13 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:06:13 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:06:13 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:06:13 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:06:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:06:13 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:06:13 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:06:13 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:06:13 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:06:13 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:06:13 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:06:13 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:06:13 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:06:13 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:06:13 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:06:13 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:06:13 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:06:13 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:06:13 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:06:13 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:06:13 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:06:13 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:06:13 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:06:13 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:06:13 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:06:13 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:06:13 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:06:13 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:06:13 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:06:13 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:06:13 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:06:13 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:06:13 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Session Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:06:13 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:06:13 --> Session routines successfully run
DEBUG - 2017-01-01 22:06:13 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:06:13 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:06:13 --> Controller Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:06:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:06:13 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:06:13 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:06:13 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:06:13 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Model Class Initialized
ERROR - 2017-01-01 22:06:13 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2017-01-01 22:06:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2017-01-01 22:06:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2017-01-01 22:06:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-01 22:06:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:06:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-01 22:06:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-01 22:06:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-01 22:06:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-01 22:06:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-01 22:06:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:06:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-01 22:06:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-01 22:06:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:06:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-01 22:06:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-01 22:06:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-01 22:06:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-01 22:06:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-01 22:06:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:06:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-01 22:06:13 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2017-01-01 22:06:13 --> Final output sent to browser
DEBUG - 2017-01-01 22:06:13 --> Total execution time: 0.4720
DEBUG - 2017-01-01 22:06:13 --> Config Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:06:13 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:06:14 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:06:14 --> URI Class Initialized
DEBUG - 2017-01-01 22:06:14 --> Router Class Initialized
DEBUG - 2017-01-01 22:06:14 --> Output Class Initialized
DEBUG - 2017-01-01 22:06:14 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:06:14 --> Security Class Initialized
DEBUG - 2017-01-01 22:06:14 --> Input Class Initialized
DEBUG - 2017-01-01 22:06:14 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:14 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:14 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:14 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:14 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:14 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:14 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:14 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:06:14 --> Language Class Initialized
DEBUG - 2017-01-01 22:06:14 --> Loader Class Initialized
DEBUG - 2017-01-01 22:06:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:06:14 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:06:14 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:06:14 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:06:14 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:06:14 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:06:14 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:06:14 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:06:14 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:06:14 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:06:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:06:14 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:06:14 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:06:14 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:06:14 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:06:14 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:06:14 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:06:14 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:06:14 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:06:14 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:06:14 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:06:14 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:06:14 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:06:14 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:06:14 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:06:14 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:06:14 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:06:14 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:06:14 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:06:14 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:06:14 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:06:14 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:06:14 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:06:14 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:06:14 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:06:14 --> Session Class Initialized
DEBUG - 2017-01-01 22:06:14 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:06:14 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:06:14 --> Session routines successfully run
DEBUG - 2017-01-01 22:06:14 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:06:14 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:06:14 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:06:14 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:06:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:06:14 --> Controller Class Initialized
DEBUG - 2017-01-01 22:06:14 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:06:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:06:14 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:06:14 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:06:14 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:06:14 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:06:14 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:14 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:14 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:14 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:14 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:14 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:14 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:14 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2017-01-01 22:06:14 --> Final output sent to browser
DEBUG - 2017-01-01 22:06:14 --> Total execution time: 0.6485
DEBUG - 2017-01-01 22:06:27 --> Config Class Initialized
DEBUG - 2017-01-01 22:06:27 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:06:27 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:06:27 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:06:27 --> URI Class Initialized
DEBUG - 2017-01-01 22:06:27 --> Router Class Initialized
DEBUG - 2017-01-01 22:06:27 --> Output Class Initialized
DEBUG - 2017-01-01 22:06:27 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:06:27 --> Security Class Initialized
DEBUG - 2017-01-01 22:06:27 --> Input Class Initialized
DEBUG - 2017-01-01 22:06:27 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:27 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:27 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:06:27 --> Language Class Initialized
DEBUG - 2017-01-01 22:06:27 --> Loader Class Initialized
DEBUG - 2017-01-01 22:06:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:06:27 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:06:27 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:06:27 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:06:27 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:06:27 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:06:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:06:27 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:06:27 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:06:27 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:06:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:06:27 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:06:27 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:06:27 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:06:27 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:06:27 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:06:27 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:06:27 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:06:27 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:06:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:06:27 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:06:27 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:06:27 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:06:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:06:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:06:27 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:06:27 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:06:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:06:27 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:06:27 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:06:27 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:06:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:06:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:06:27 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:06:27 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:06:27 --> Session Class Initialized
DEBUG - 2017-01-01 22:06:27 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:06:27 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:06:27 --> Session routines successfully run
DEBUG - 2017-01-01 22:06:27 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:06:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:06:27 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:06:27 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:06:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:06:27 --> Controller Class Initialized
DEBUG - 2017-01-01 22:06:27 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:06:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:06:27 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:06:27 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:06:27 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:06:27 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:06:27 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:27 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:27 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2017-01-01 22:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:06:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:06:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:06:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:06:28 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2017-01-01 22:06:28 --> Final output sent to browser
DEBUG - 2017-01-01 22:06:28 --> Total execution time: 0.4972
DEBUG - 2017-01-01 22:06:30 --> Config Class Initialized
DEBUG - 2017-01-01 22:06:30 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:06:30 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:06:30 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:06:30 --> URI Class Initialized
DEBUG - 2017-01-01 22:06:30 --> Router Class Initialized
DEBUG - 2017-01-01 22:06:30 --> Output Class Initialized
DEBUG - 2017-01-01 22:06:30 --> Security Class Initialized
DEBUG - 2017-01-01 22:06:30 --> Input Class Initialized
DEBUG - 2017-01-01 22:06:30 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:30 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:06:30 --> Language Class Initialized
DEBUG - 2017-01-01 22:06:30 --> Loader Class Initialized
DEBUG - 2017-01-01 22:06:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:06:30 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:06:30 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:06:30 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:06:30 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:06:30 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:06:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:06:30 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:06:30 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:06:30 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:06:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:06:30 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:06:30 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:06:30 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:06:30 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:06:30 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:06:30 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:06:30 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:06:30 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:06:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:06:30 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:06:30 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:06:30 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:06:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:06:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:06:30 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:06:30 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:06:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:06:30 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:06:30 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:06:30 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:06:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:06:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:06:30 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:06:30 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:06:30 --> Session Class Initialized
DEBUG - 2017-01-01 22:06:30 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:06:30 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:06:30 --> Session routines successfully run
DEBUG - 2017-01-01 22:06:30 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:06:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:06:30 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:06:30 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:06:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:06:30 --> Controller Class Initialized
DEBUG - 2017-01-01 22:06:30 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:06:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:06:30 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:06:30 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:06:30 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:06:30 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:06:30 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:31 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:31 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:31 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:31 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:31 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:31 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:31 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2017-01-01 22:06:31 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2017-01-01 22:06:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2017-01-01 22:06:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2017-01-01 22:06:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2017-01-01 22:06:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2017-01-01 22:06:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2017-01-01 22:06:31 --> Final output sent to browser
DEBUG - 2017-01-01 22:06:31 --> Total execution time: 0.5396
DEBUG - 2017-01-01 22:06:38 --> Config Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:06:38 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:06:38 --> URI Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Router Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Output Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:06:38 --> Security Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Input Class Initialized
DEBUG - 2017-01-01 22:06:38 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:38 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:38 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:38 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:06:38 --> Language Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Loader Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:06:38 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:06:38 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:06:38 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:06:38 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:06:38 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:06:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:06:38 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:06:38 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:06:38 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:06:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:06:38 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:06:38 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:06:38 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:06:38 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:06:38 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:06:38 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:06:38 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:06:38 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:06:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:06:38 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:06:38 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:06:38 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:06:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:06:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:06:38 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:06:38 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:06:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:06:38 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:06:38 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:06:38 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:06:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:06:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:06:38 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:06:38 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Session Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:06:38 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:06:38 --> Session routines successfully run
DEBUG - 2017-01-01 22:06:38 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:06:38 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:06:38 --> Controller Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:06:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:06:38 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:06:38 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:06:38 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:06:38 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2017-01-01 22:06:38 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:06:38 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2017-01-01 22:06:38 --> Config Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:06:38 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:06:38 --> URI Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Router Class Initialized
DEBUG - 2017-01-01 22:06:38 --> No URI present. Default controller set.
DEBUG - 2017-01-01 22:06:38 --> Output Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:06:38 --> Security Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Input Class Initialized
DEBUG - 2017-01-01 22:06:38 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:38 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:06:38 --> Language Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Loader Class Initialized
DEBUG - 2017-01-01 22:06:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:06:38 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:06:38 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:06:38 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:06:38 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:06:38 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:06:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:06:38 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:06:38 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:06:38 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:06:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:06:38 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:06:38 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:06:38 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:06:38 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:06:38 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:06:38 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:06:38 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:06:38 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:06:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:06:38 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:06:38 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:06:38 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:06:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:06:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:06:39 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:06:39 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:06:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:06:39 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:06:39 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:06:39 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:06:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:06:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:06:39 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:06:39 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:06:39 --> Session Class Initialized
DEBUG - 2017-01-01 22:06:39 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:06:39 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:06:39 --> Session routines successfully run
DEBUG - 2017-01-01 22:06:39 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:06:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:06:39 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:06:39 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:06:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:06:39 --> Controller Class Initialized
DEBUG - 2017-01-01 22:06:39 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:06:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:06:39 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:06:39 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:06:39 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:06:39 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:06:39 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:39 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:39 --> Model Class Initialized
ERROR - 2017-01-01 22:06:39 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2017-01-01 22:06:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2017-01-01 22:06:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2017-01-01 22:06:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-01 22:06:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:06:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-01 22:06:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-01 22:06:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-01 22:06:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-01 22:06:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-01 22:06:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:06:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-01 22:06:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-01 22:06:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:06:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-01 22:06:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-01 22:06:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-01 22:06:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-01 22:06:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-01 22:06:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:06:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-01 22:06:39 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2017-01-01 22:06:39 --> Final output sent to browser
DEBUG - 2017-01-01 22:06:39 --> Total execution time: 0.5780
DEBUG - 2017-01-01 22:06:39 --> Config Class Initialized
DEBUG - 2017-01-01 22:06:39 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:06:39 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:06:39 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:06:39 --> URI Class Initialized
DEBUG - 2017-01-01 22:06:39 --> Router Class Initialized
DEBUG - 2017-01-01 22:06:39 --> Output Class Initialized
DEBUG - 2017-01-01 22:06:39 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:06:39 --> Security Class Initialized
DEBUG - 2017-01-01 22:06:39 --> Input Class Initialized
DEBUG - 2017-01-01 22:06:39 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:39 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:39 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:39 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:39 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:39 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:39 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:39 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:06:39 --> Language Class Initialized
DEBUG - 2017-01-01 22:06:39 --> Loader Class Initialized
DEBUG - 2017-01-01 22:06:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:06:39 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:06:39 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:06:39 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:06:39 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:06:39 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:06:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:06:39 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:06:39 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:06:39 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:06:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:06:39 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:06:39 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:06:39 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:06:39 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:06:39 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:06:39 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:06:39 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:06:39 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:06:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:06:39 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:06:39 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:06:39 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:06:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:06:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:06:39 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:06:39 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:06:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:06:39 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:06:39 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:06:39 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:06:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:06:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:06:39 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:06:40 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:06:40 --> Session Class Initialized
DEBUG - 2017-01-01 22:06:40 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:06:40 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:06:40 --> Session routines successfully run
DEBUG - 2017-01-01 22:06:40 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:06:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:06:40 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:06:40 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:06:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:06:40 --> Controller Class Initialized
DEBUG - 2017-01-01 22:06:40 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:06:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:06:40 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:06:40 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:06:40 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:06:40 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:06:40 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:40 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:40 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:40 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:40 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:40 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:40 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2017-01-01 22:06:40 --> Final output sent to browser
DEBUG - 2017-01-01 22:06:40 --> Total execution time: 0.6927
DEBUG - 2017-01-01 22:06:41 --> Config Class Initialized
DEBUG - 2017-01-01 22:06:41 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:06:41 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:06:41 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:06:41 --> URI Class Initialized
DEBUG - 2017-01-01 22:06:41 --> Router Class Initialized
DEBUG - 2017-01-01 22:06:41 --> Output Class Initialized
DEBUG - 2017-01-01 22:06:41 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:06:41 --> Security Class Initialized
DEBUG - 2017-01-01 22:06:41 --> Input Class Initialized
DEBUG - 2017-01-01 22:06:41 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:41 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:06:41 --> Language Class Initialized
DEBUG - 2017-01-01 22:06:41 --> Loader Class Initialized
DEBUG - 2017-01-01 22:06:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:06:41 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:06:41 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:06:41 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:06:41 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:06:41 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:06:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:06:41 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:06:41 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:06:41 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:06:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:06:41 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:06:41 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:06:41 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:06:41 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:06:41 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:06:41 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:06:41 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:06:41 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:06:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:06:41 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:06:41 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:06:41 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:06:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:06:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:06:41 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:06:41 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:06:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:06:41 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:06:41 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:06:41 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:06:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:06:41 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:06:41 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:06:41 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:06:41 --> Session Class Initialized
DEBUG - 2017-01-01 22:06:41 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:06:41 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:06:41 --> Session routines successfully run
DEBUG - 2017-01-01 22:06:41 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:06:41 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:06:41 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:06:41 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:06:41 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:06:41 --> Controller Class Initialized
DEBUG - 2017-01-01 22:06:41 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:06:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:06:41 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:06:41 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:06:41 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:06:42 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:06:42 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:42 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:42 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2017-01-01 22:06:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:06:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:06:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:06:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:06:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:06:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:06:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:06:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:06:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:06:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:06:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:06:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:06:42 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2017-01-01 22:06:42 --> Final output sent to browser
DEBUG - 2017-01-01 22:06:42 --> Total execution time: 0.6001
DEBUG - 2017-01-01 22:06:45 --> Config Class Initialized
DEBUG - 2017-01-01 22:06:45 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:06:45 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:06:45 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:06:45 --> URI Class Initialized
DEBUG - 2017-01-01 22:06:45 --> Router Class Initialized
DEBUG - 2017-01-01 22:06:45 --> Output Class Initialized
DEBUG - 2017-01-01 22:06:45 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:06:45 --> Security Class Initialized
DEBUG - 2017-01-01 22:06:45 --> Input Class Initialized
DEBUG - 2017-01-01 22:06:45 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:45 --> XSS Filtering completed
DEBUG - 2017-01-01 22:06:45 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:06:45 --> Language Class Initialized
DEBUG - 2017-01-01 22:06:45 --> Loader Class Initialized
DEBUG - 2017-01-01 22:06:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:06:45 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:06:45 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:06:45 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:06:45 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:06:45 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:06:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:06:45 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:06:45 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:06:45 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:06:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:06:45 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:06:45 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:06:45 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:06:45 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:06:45 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:06:45 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:06:45 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:06:45 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:06:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:06:45 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:06:45 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:06:45 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:06:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:06:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:06:45 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:06:45 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:06:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:06:45 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:06:45 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:06:45 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:06:45 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:06:45 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:06:45 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:06:45 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:06:45 --> Session Class Initialized
DEBUG - 2017-01-01 22:06:45 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:06:45 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:06:45 --> Session routines successfully run
DEBUG - 2017-01-01 22:06:45 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:06:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:06:45 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:06:45 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:06:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:06:45 --> Controller Class Initialized
DEBUG - 2017-01-01 22:06:45 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:06:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:06:45 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:06:45 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:06:45 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:06:45 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:06:45 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:45 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:45 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:45 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:45 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:45 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:45 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:45 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:45 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:45 --> Model Class Initialized
DEBUG - 2017-01-01 22:06:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2017-01-01 22:06:45 --> Pagination Class Initialized
DEBUG - 2017-01-01 22:06:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2017-01-01 22:06:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2017-01-01 22:06:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:06:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:06:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:06:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:06:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2017-01-01 22:06:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:06:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:06:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:06:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:06:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:06:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:06:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2017-01-01 22:06:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:06:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:06:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2017-01-01 22:06:46 --> Final output sent to browser
DEBUG - 2017-01-01 22:06:46 --> Total execution time: 0.7588
DEBUG - 2017-01-01 22:07:15 --> Config Class Initialized
DEBUG - 2017-01-01 22:07:15 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:07:15 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:07:15 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:07:15 --> URI Class Initialized
DEBUG - 2017-01-01 22:07:15 --> Router Class Initialized
DEBUG - 2017-01-01 22:07:15 --> Output Class Initialized
DEBUG - 2017-01-01 22:07:15 --> Security Class Initialized
DEBUG - 2017-01-01 22:07:15 --> Input Class Initialized
DEBUG - 2017-01-01 22:07:15 --> XSS Filtering completed
DEBUG - 2017-01-01 22:07:15 --> XSS Filtering completed
DEBUG - 2017-01-01 22:07:15 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:07:15 --> Language Class Initialized
DEBUG - 2017-01-01 22:07:15 --> Loader Class Initialized
DEBUG - 2017-01-01 22:07:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:07:15 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:07:15 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:07:15 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:07:15 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:07:15 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:07:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:07:15 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:07:15 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:07:15 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:07:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:07:15 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:07:15 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:07:15 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:07:15 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:07:15 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:07:15 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:07:15 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:07:15 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:07:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:07:15 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:07:15 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:07:15 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:07:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:07:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:07:15 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:07:15 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:07:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:07:15 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:07:15 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:07:15 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:07:15 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:07:15 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:07:15 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:07:15 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:07:15 --> Session Class Initialized
DEBUG - 2017-01-01 22:07:15 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:07:15 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:07:16 --> Session routines successfully run
DEBUG - 2017-01-01 22:07:16 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:07:16 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:07:16 --> Controller Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:07:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:07:16 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:07:16 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:07:16 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:07:16 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Model Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Model Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Model Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Model Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Model Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Model Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Model Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Config Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:07:16 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:07:16 --> URI Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Router Class Initialized
DEBUG - 2017-01-01 22:07:16 --> No URI present. Default controller set.
DEBUG - 2017-01-01 22:07:16 --> Output Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:07:16 --> Security Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Input Class Initialized
DEBUG - 2017-01-01 22:07:16 --> XSS Filtering completed
DEBUG - 2017-01-01 22:07:16 --> XSS Filtering completed
DEBUG - 2017-01-01 22:07:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:07:16 --> Language Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Loader Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:07:16 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:07:16 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:07:16 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:07:16 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:07:16 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:07:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:07:16 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:07:16 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:07:16 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:07:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:07:16 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:07:16 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:07:16 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:07:16 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:07:16 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:07:16 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:07:16 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:07:16 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:07:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:07:16 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:07:16 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:07:16 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:07:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:07:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:07:16 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:07:16 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:07:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:07:16 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:07:16 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:07:16 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:07:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:07:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:07:16 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:07:16 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Session Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:07:16 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:07:16 --> Session routines successfully run
DEBUG - 2017-01-01 22:07:16 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:07:16 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:07:16 --> Controller Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:07:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:07:16 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:07:16 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:07:16 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:07:16 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Model Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Model Class Initialized
DEBUG - 2017-01-01 22:07:16 --> Model Class Initialized
ERROR - 2017-01-01 22:07:16 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2017-01-01 22:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2017-01-01 22:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2017-01-01 22:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-01 22:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-01 22:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-01 22:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-01 22:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-01 22:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-01 22:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-01 22:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-01 22:07:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:07:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-01 22:07:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-01 22:07:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-01 22:07:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-01 22:07:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-01 22:07:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:07:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-01 22:07:17 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2017-01-01 22:07:17 --> Final output sent to browser
DEBUG - 2017-01-01 22:07:17 --> Total execution time: 0.6800
DEBUG - 2017-01-01 22:07:17 --> Config Class Initialized
DEBUG - 2017-01-01 22:07:17 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:07:17 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:07:17 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:07:17 --> URI Class Initialized
DEBUG - 2017-01-01 22:07:17 --> Router Class Initialized
DEBUG - 2017-01-01 22:07:17 --> Output Class Initialized
DEBUG - 2017-01-01 22:07:17 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:07:17 --> Security Class Initialized
DEBUG - 2017-01-01 22:07:17 --> Input Class Initialized
DEBUG - 2017-01-01 22:07:17 --> XSS Filtering completed
DEBUG - 2017-01-01 22:07:17 --> XSS Filtering completed
DEBUG - 2017-01-01 22:07:17 --> XSS Filtering completed
DEBUG - 2017-01-01 22:07:17 --> XSS Filtering completed
DEBUG - 2017-01-01 22:07:17 --> XSS Filtering completed
DEBUG - 2017-01-01 22:07:17 --> XSS Filtering completed
DEBUG - 2017-01-01 22:07:17 --> XSS Filtering completed
DEBUG - 2017-01-01 22:07:17 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:07:17 --> Language Class Initialized
DEBUG - 2017-01-01 22:07:17 --> Loader Class Initialized
DEBUG - 2017-01-01 22:07:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:07:17 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:07:17 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:07:17 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:07:17 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:07:17 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:07:17 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:07:17 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:07:17 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:07:17 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:07:17 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:07:17 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:07:17 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:07:17 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:07:17 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:07:17 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:07:17 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:07:17 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:07:17 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:07:17 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:07:17 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:07:17 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:07:17 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:07:17 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:07:17 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:07:17 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:07:17 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:07:17 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:07:17 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:07:17 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:07:17 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:07:17 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:07:17 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:07:17 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:07:17 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:07:17 --> Session Class Initialized
DEBUG - 2017-01-01 22:07:17 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:07:17 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:07:17 --> Session routines successfully run
DEBUG - 2017-01-01 22:07:17 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:07:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:07:17 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:07:17 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:07:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:07:17 --> Controller Class Initialized
DEBUG - 2017-01-01 22:07:17 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:07:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:07:17 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:07:17 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:07:17 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:07:17 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:07:17 --> Model Class Initialized
DEBUG - 2017-01-01 22:07:17 --> Model Class Initialized
DEBUG - 2017-01-01 22:07:17 --> Model Class Initialized
DEBUG - 2017-01-01 22:07:17 --> Model Class Initialized
DEBUG - 2017-01-01 22:07:17 --> Model Class Initialized
DEBUG - 2017-01-01 22:07:17 --> Model Class Initialized
DEBUG - 2017-01-01 22:07:18 --> Model Class Initialized
DEBUG - 2017-01-01 22:07:18 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2017-01-01 22:07:18 --> Final output sent to browser
DEBUG - 2017-01-01 22:07:18 --> Total execution time: 0.7993
DEBUG - 2017-01-01 22:08:30 --> Config Class Initialized
DEBUG - 2017-01-01 22:08:30 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:08:30 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:08:30 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:08:30 --> URI Class Initialized
DEBUG - 2017-01-01 22:08:30 --> Router Class Initialized
DEBUG - 2017-01-01 22:08:30 --> Output Class Initialized
DEBUG - 2017-01-01 22:08:30 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:08:30 --> Security Class Initialized
DEBUG - 2017-01-01 22:08:30 --> Input Class Initialized
DEBUG - 2017-01-01 22:08:30 --> XSS Filtering completed
DEBUG - 2017-01-01 22:08:30 --> XSS Filtering completed
DEBUG - 2017-01-01 22:08:30 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:08:30 --> Language Class Initialized
DEBUG - 2017-01-01 22:08:30 --> Loader Class Initialized
DEBUG - 2017-01-01 22:08:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:08:30 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:08:30 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:08:30 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:08:30 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:08:30 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:08:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:08:30 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:08:30 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:08:30 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:08:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:08:30 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:08:30 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:08:30 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:08:30 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:08:30 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:08:30 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:08:30 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:08:30 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:08:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:08:30 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:08:30 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:08:30 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:08:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:08:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:08:31 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:08:31 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:08:31 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:08:31 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:08:31 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:08:31 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:08:31 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:08:31 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:08:31 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:08:31 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:08:31 --> Session Class Initialized
DEBUG - 2017-01-01 22:08:31 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:08:31 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:08:31 --> Session routines successfully run
DEBUG - 2017-01-01 22:08:31 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:08:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:08:31 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:08:31 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:08:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:08:31 --> Controller Class Initialized
DEBUG - 2017-01-01 22:08:31 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:08:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:08:31 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:08:31 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:08:31 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:08:31 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:08:31 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:31 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:31 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2017-01-01 22:08:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:08:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:08:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:08:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:08:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:08:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:08:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:08:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:08:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:08:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:08:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:08:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:08:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2017-01-01 22:08:31 --> Final output sent to browser
DEBUG - 2017-01-01 22:08:31 --> Total execution time: 0.7448
DEBUG - 2017-01-01 22:08:34 --> Config Class Initialized
DEBUG - 2017-01-01 22:08:34 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:08:34 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:08:34 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:08:34 --> URI Class Initialized
DEBUG - 2017-01-01 22:08:34 --> Router Class Initialized
DEBUG - 2017-01-01 22:08:34 --> Output Class Initialized
DEBUG - 2017-01-01 22:08:34 --> Security Class Initialized
DEBUG - 2017-01-01 22:08:34 --> Input Class Initialized
DEBUG - 2017-01-01 22:08:34 --> XSS Filtering completed
DEBUG - 2017-01-01 22:08:34 --> XSS Filtering completed
DEBUG - 2017-01-01 22:08:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:08:34 --> Language Class Initialized
DEBUG - 2017-01-01 22:08:34 --> Loader Class Initialized
DEBUG - 2017-01-01 22:08:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:08:34 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:08:34 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:08:34 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:08:34 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:08:34 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:08:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:08:34 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:08:34 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:08:34 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:08:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:08:34 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:08:34 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:08:34 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:08:34 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:08:34 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:08:34 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:08:34 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:08:34 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:08:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:08:34 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:08:34 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:08:34 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:08:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:08:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:08:34 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:08:34 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:08:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:08:34 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:08:34 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:08:34 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:08:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:08:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:08:34 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:08:34 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:08:34 --> Session Class Initialized
DEBUG - 2017-01-01 22:08:34 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:08:34 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:08:34 --> Session routines successfully run
DEBUG - 2017-01-01 22:08:34 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:08:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:08:34 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:08:34 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:08:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:08:34 --> Controller Class Initialized
DEBUG - 2017-01-01 22:08:34 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:08:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:08:34 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:08:34 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:08:34 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:08:34 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:08:34 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:34 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:34 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:35 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:35 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:35 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:35 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:35 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2017-01-01 22:08:35 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2017-01-01 22:08:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2017-01-01 22:08:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2017-01-01 22:08:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2017-01-01 22:08:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2017-01-01 22:08:35 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2017-01-01 22:08:35 --> Final output sent to browser
DEBUG - 2017-01-01 22:08:35 --> Total execution time: 0.7907
DEBUG - 2017-01-01 22:08:43 --> Config Class Initialized
DEBUG - 2017-01-01 22:08:43 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:08:43 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:08:43 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:08:43 --> URI Class Initialized
DEBUG - 2017-01-01 22:08:43 --> Router Class Initialized
DEBUG - 2017-01-01 22:08:43 --> Output Class Initialized
DEBUG - 2017-01-01 22:08:43 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:08:43 --> Security Class Initialized
DEBUG - 2017-01-01 22:08:43 --> Input Class Initialized
DEBUG - 2017-01-01 22:08:43 --> XSS Filtering completed
DEBUG - 2017-01-01 22:08:43 --> XSS Filtering completed
DEBUG - 2017-01-01 22:08:43 --> XSS Filtering completed
DEBUG - 2017-01-01 22:08:43 --> XSS Filtering completed
DEBUG - 2017-01-01 22:08:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:08:43 --> Language Class Initialized
DEBUG - 2017-01-01 22:08:43 --> Loader Class Initialized
DEBUG - 2017-01-01 22:08:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:08:43 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:08:43 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:08:43 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:08:43 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:08:43 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:08:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:08:43 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:08:43 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:08:43 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:08:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:08:44 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:08:44 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:08:44 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:08:44 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:08:44 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:08:44 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:08:44 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:08:44 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:08:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:08:44 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:08:44 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:08:44 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:08:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:08:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:08:44 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:08:44 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:08:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:08:44 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:08:44 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:08:44 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:08:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:08:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:08:44 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:08:44 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:08:44 --> Session Class Initialized
DEBUG - 2017-01-01 22:08:44 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:08:44 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:08:44 --> Session routines successfully run
DEBUG - 2017-01-01 22:08:44 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:08:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:08:44 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:08:44 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:08:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:08:44 --> Controller Class Initialized
DEBUG - 2017-01-01 22:08:44 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:08:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:08:44 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:08:44 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:08:44 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:08:44 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:08:44 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:44 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:44 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:44 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:44 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:44 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:44 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2017-01-01 22:08:44 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:08:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:08:44 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2017-01-01 22:08:44 --> Config Class Initialized
DEBUG - 2017-01-01 22:08:44 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:08:44 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:08:44 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:08:44 --> URI Class Initialized
DEBUG - 2017-01-01 22:08:44 --> Router Class Initialized
DEBUG - 2017-01-01 22:08:44 --> No URI present. Default controller set.
DEBUG - 2017-01-01 22:08:44 --> Output Class Initialized
DEBUG - 2017-01-01 22:08:44 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:08:44 --> Security Class Initialized
DEBUG - 2017-01-01 22:08:44 --> Input Class Initialized
DEBUG - 2017-01-01 22:08:44 --> XSS Filtering completed
DEBUG - 2017-01-01 22:08:44 --> XSS Filtering completed
DEBUG - 2017-01-01 22:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:08:44 --> Language Class Initialized
DEBUG - 2017-01-01 22:08:44 --> Loader Class Initialized
DEBUG - 2017-01-01 22:08:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:08:44 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:08:44 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:08:44 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:08:44 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:08:44 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:08:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:08:44 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:08:44 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:08:44 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:08:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:08:44 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:08:44 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:08:44 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:08:44 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:08:44 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:08:44 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:08:44 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:08:45 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:08:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:08:45 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:08:45 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:08:45 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:08:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:08:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:08:45 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:08:45 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:08:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:08:45 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:08:45 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:08:45 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:08:45 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:08:45 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:08:45 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:08:45 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:08:45 --> Session Class Initialized
DEBUG - 2017-01-01 22:08:45 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:08:45 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:08:45 --> Session routines successfully run
DEBUG - 2017-01-01 22:08:45 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:08:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:08:45 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:08:45 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:08:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:08:45 --> Controller Class Initialized
DEBUG - 2017-01-01 22:08:45 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:08:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:08:45 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:08:45 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:08:45 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:08:45 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:08:45 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:45 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:45 --> Model Class Initialized
ERROR - 2017-01-01 22:08:45 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2017-01-01 22:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2017-01-01 22:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2017-01-01 22:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-01 22:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-01 22:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-01 22:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-01 22:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-01 22:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-01 22:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-01 22:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-01 22:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-01 22:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-01 22:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-01 22:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-01 22:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-01 22:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:08:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-01 22:08:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2017-01-01 22:08:45 --> Final output sent to browser
DEBUG - 2017-01-01 22:08:45 --> Total execution time: 0.8569
DEBUG - 2017-01-01 22:08:45 --> Config Class Initialized
DEBUG - 2017-01-01 22:08:45 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:08:45 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:08:45 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:08:45 --> URI Class Initialized
DEBUG - 2017-01-01 22:08:45 --> Router Class Initialized
DEBUG - 2017-01-01 22:08:45 --> Output Class Initialized
DEBUG - 2017-01-01 22:08:45 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:08:45 --> Security Class Initialized
DEBUG - 2017-01-01 22:08:45 --> Input Class Initialized
DEBUG - 2017-01-01 22:08:45 --> XSS Filtering completed
DEBUG - 2017-01-01 22:08:46 --> XSS Filtering completed
DEBUG - 2017-01-01 22:08:46 --> XSS Filtering completed
DEBUG - 2017-01-01 22:08:46 --> XSS Filtering completed
DEBUG - 2017-01-01 22:08:46 --> XSS Filtering completed
DEBUG - 2017-01-01 22:08:46 --> XSS Filtering completed
DEBUG - 2017-01-01 22:08:46 --> XSS Filtering completed
DEBUG - 2017-01-01 22:08:46 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:08:46 --> Language Class Initialized
DEBUG - 2017-01-01 22:08:46 --> Loader Class Initialized
DEBUG - 2017-01-01 22:08:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:08:46 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:08:46 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:08:46 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:08:46 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:08:46 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:08:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:08:46 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:08:46 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:08:46 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:08:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:08:46 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:08:46 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:08:46 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:08:46 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:08:46 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:08:46 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:08:46 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:08:46 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:08:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:08:46 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:08:46 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:08:46 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:08:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:08:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:08:46 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:08:46 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:08:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:08:46 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:08:46 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:08:46 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:08:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:08:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:08:46 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:08:46 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:08:46 --> Session Class Initialized
DEBUG - 2017-01-01 22:08:46 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:08:46 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:08:46 --> Session routines successfully run
DEBUG - 2017-01-01 22:08:46 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:08:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:08:46 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:08:46 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:08:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:08:46 --> Controller Class Initialized
DEBUG - 2017-01-01 22:08:46 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:08:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:08:46 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:08:46 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:08:46 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:08:46 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:08:46 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:46 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:46 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:46 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:46 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:46 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:46 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2017-01-01 22:08:46 --> Final output sent to browser
DEBUG - 2017-01-01 22:08:46 --> Total execution time: 0.9687
DEBUG - 2017-01-01 22:08:48 --> Config Class Initialized
DEBUG - 2017-01-01 22:08:48 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:08:48 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:08:48 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:08:48 --> URI Class Initialized
DEBUG - 2017-01-01 22:08:48 --> Router Class Initialized
DEBUG - 2017-01-01 22:08:48 --> Output Class Initialized
DEBUG - 2017-01-01 22:08:48 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:08:48 --> Security Class Initialized
DEBUG - 2017-01-01 22:08:48 --> Input Class Initialized
DEBUG - 2017-01-01 22:08:48 --> XSS Filtering completed
DEBUG - 2017-01-01 22:08:48 --> XSS Filtering completed
DEBUG - 2017-01-01 22:08:48 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:08:48 --> Language Class Initialized
DEBUG - 2017-01-01 22:08:48 --> Loader Class Initialized
DEBUG - 2017-01-01 22:08:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:08:48 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:08:48 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:08:48 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:08:48 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:08:48 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:08:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:08:48 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:08:48 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:08:48 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:08:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:08:48 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:08:48 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:08:48 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:08:48 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:08:48 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:08:48 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:08:48 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:08:48 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:08:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:08:48 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:08:48 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:08:48 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:08:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:08:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:08:48 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:08:48 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:08:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:08:48 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:08:48 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:08:48 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:08:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:08:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:08:48 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:08:48 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:08:48 --> Session Class Initialized
DEBUG - 2017-01-01 22:08:48 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:08:48 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:08:48 --> Session routines successfully run
DEBUG - 2017-01-01 22:08:48 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:08:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:08:48 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:08:48 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:08:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:08:49 --> Controller Class Initialized
DEBUG - 2017-01-01 22:08:49 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:08:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:08:49 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:08:49 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:08:49 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:08:49 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:08:49 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:49 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:49 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2017-01-01 22:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:08:49 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2017-01-01 22:08:49 --> Final output sent to browser
DEBUG - 2017-01-01 22:08:49 --> Total execution time: 0.8593
DEBUG - 2017-01-01 22:08:52 --> Config Class Initialized
DEBUG - 2017-01-01 22:08:52 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:08:52 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:08:52 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:08:52 --> URI Class Initialized
DEBUG - 2017-01-01 22:08:52 --> Router Class Initialized
DEBUG - 2017-01-01 22:08:52 --> Output Class Initialized
DEBUG - 2017-01-01 22:08:52 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:08:52 --> Security Class Initialized
DEBUG - 2017-01-01 22:08:52 --> Input Class Initialized
DEBUG - 2017-01-01 22:08:52 --> XSS Filtering completed
DEBUG - 2017-01-01 22:08:52 --> XSS Filtering completed
DEBUG - 2017-01-01 22:08:52 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:08:52 --> Language Class Initialized
DEBUG - 2017-01-01 22:08:52 --> Loader Class Initialized
DEBUG - 2017-01-01 22:08:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:08:52 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:08:52 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:08:52 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:08:53 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:08:53 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:08:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:08:53 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:08:53 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:08:53 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:08:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:08:53 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:08:53 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:08:53 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:08:53 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:08:53 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:08:53 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:08:53 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:08:53 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:08:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:08:53 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:08:53 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:08:53 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:08:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:08:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:08:53 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:08:53 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:08:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:08:53 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:08:53 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:08:53 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:08:53 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:08:53 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:08:53 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:08:53 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:08:53 --> Session Class Initialized
DEBUG - 2017-01-01 22:08:53 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:08:53 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:08:53 --> Session routines successfully run
DEBUG - 2017-01-01 22:08:53 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:08:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:08:53 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:08:53 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:08:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:08:53 --> Controller Class Initialized
DEBUG - 2017-01-01 22:08:53 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:08:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:08:53 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:08:53 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:08:53 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:08:53 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:08:53 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:53 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:53 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:53 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:53 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:53 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:53 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:53 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:53 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:53 --> Model Class Initialized
DEBUG - 2017-01-01 22:08:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2017-01-01 22:08:53 --> Pagination Class Initialized
DEBUG - 2017-01-01 22:08:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2017-01-01 22:08:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2017-01-01 22:08:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:08:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:08:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:08:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:08:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2017-01-01 22:08:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:08:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:08:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:08:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:08:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:08:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:08:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2017-01-01 22:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:08:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2017-01-01 22:08:54 --> Final output sent to browser
DEBUG - 2017-01-01 22:08:54 --> Total execution time: 1.0527
DEBUG - 2017-01-01 22:09:00 --> Config Class Initialized
DEBUG - 2017-01-01 22:09:00 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:09:00 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:09:00 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:09:00 --> URI Class Initialized
DEBUG - 2017-01-01 22:09:00 --> Router Class Initialized
DEBUG - 2017-01-01 22:09:00 --> Output Class Initialized
DEBUG - 2017-01-01 22:09:00 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:09:00 --> Security Class Initialized
DEBUG - 2017-01-01 22:09:00 --> Input Class Initialized
DEBUG - 2017-01-01 22:09:00 --> XSS Filtering completed
DEBUG - 2017-01-01 22:09:00 --> XSS Filtering completed
DEBUG - 2017-01-01 22:09:00 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:09:00 --> Language Class Initialized
DEBUG - 2017-01-01 22:09:00 --> Loader Class Initialized
DEBUG - 2017-01-01 22:09:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:09:01 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:09:01 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:09:01 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:09:01 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:09:01 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:09:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:09:01 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:09:01 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:09:01 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:09:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:09:01 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:09:01 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:09:01 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:09:01 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:09:01 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:09:01 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:09:01 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:09:01 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:09:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:09:01 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:09:01 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:09:01 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:09:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:09:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:09:01 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:09:01 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:09:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:09:01 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:09:01 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:09:01 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:09:01 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:09:01 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:09:01 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:09:01 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:09:01 --> Session Class Initialized
DEBUG - 2017-01-01 22:09:01 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:09:01 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:09:01 --> Session routines successfully run
DEBUG - 2017-01-01 22:09:01 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:09:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:09:01 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:09:01 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:09:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:09:01 --> Controller Class Initialized
DEBUG - 2017-01-01 22:09:01 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:09:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:09:01 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:09:01 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:09:01 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:09:01 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:09:01 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:01 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:01 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:01 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:01 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:01 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:01 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:01 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:01 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:01 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2017-01-01 22:09:01 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:09:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:09:01 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2017-01-01 22:09:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2017-01-01 22:09:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2017-01-01 22:09:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2017-01-01 22:09:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2017-01-01 22:09:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2017-01-01 22:09:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2017-01-01 22:09:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2017-01-01 22:09:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2017-01-01 22:09:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:09:02 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8f8e2926e3f1cbfc3aa536b43cdd0626
DEBUG - 2017-01-01 22:09:02 --> Final output sent to browser
DEBUG - 2017-01-01 22:09:02 --> Total execution time: 1.1277
DEBUG - 2017-01-01 22:09:35 --> Config Class Initialized
DEBUG - 2017-01-01 22:09:35 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:09:35 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:09:35 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:09:35 --> URI Class Initialized
DEBUG - 2017-01-01 22:09:35 --> Router Class Initialized
DEBUG - 2017-01-01 22:09:35 --> Output Class Initialized
DEBUG - 2017-01-01 22:09:35 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:09:35 --> Security Class Initialized
DEBUG - 2017-01-01 22:09:35 --> Input Class Initialized
DEBUG - 2017-01-01 22:09:35 --> XSS Filtering completed
DEBUG - 2017-01-01 22:09:35 --> XSS Filtering completed
DEBUG - 2017-01-01 22:09:35 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:09:35 --> Language Class Initialized
DEBUG - 2017-01-01 22:09:35 --> Loader Class Initialized
DEBUG - 2017-01-01 22:09:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:09:36 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:09:36 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:09:36 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:09:36 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:09:36 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:09:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:09:36 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:09:36 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:09:36 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:09:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:09:36 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:09:36 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:09:36 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:09:36 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:09:36 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:09:36 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:09:36 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:09:36 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:09:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:09:36 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:09:36 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:09:36 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:09:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:09:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:09:36 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:09:36 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:09:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:09:36 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:09:36 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:09:36 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:09:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:09:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:09:36 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:09:36 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:09:36 --> Session Class Initialized
DEBUG - 2017-01-01 22:09:36 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:09:36 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:09:36 --> Session routines successfully run
DEBUG - 2017-01-01 22:09:36 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:09:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:09:36 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:09:36 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:09:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:09:36 --> Controller Class Initialized
DEBUG - 2017-01-01 22:09:36 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:09:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:09:36 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:09:36 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:09:36 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:09:36 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:09:36 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:36 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:36 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:36 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:36 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:36 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:36 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:36 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:36 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:36 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2017-01-01 22:09:36 --> Pagination Class Initialized
DEBUG - 2017-01-01 22:09:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2017-01-01 22:09:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2017-01-01 22:09:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:09:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:09:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:09:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:09:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2017-01-01 22:09:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:09:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:09:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:09:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:09:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:09:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:09:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2017-01-01 22:09:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:09:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:09:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6ab8b0e8914e7f77c92d629ba6bdd93f
DEBUG - 2017-01-01 22:09:37 --> Final output sent to browser
DEBUG - 2017-01-01 22:09:37 --> Total execution time: 1.1319
DEBUG - 2017-01-01 22:09:43 --> Config Class Initialized
DEBUG - 2017-01-01 22:09:43 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:09:43 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:09:43 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:09:43 --> URI Class Initialized
DEBUG - 2017-01-01 22:09:43 --> Router Class Initialized
DEBUG - 2017-01-01 22:09:43 --> Output Class Initialized
DEBUG - 2017-01-01 22:09:43 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:09:43 --> Security Class Initialized
DEBUG - 2017-01-01 22:09:43 --> Input Class Initialized
DEBUG - 2017-01-01 22:09:43 --> XSS Filtering completed
DEBUG - 2017-01-01 22:09:43 --> XSS Filtering completed
DEBUG - 2017-01-01 22:09:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:09:43 --> Language Class Initialized
DEBUG - 2017-01-01 22:09:43 --> Loader Class Initialized
DEBUG - 2017-01-01 22:09:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:09:43 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:09:43 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:09:43 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:09:43 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:09:43 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:09:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:09:44 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:09:44 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:09:44 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:09:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:09:44 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:09:44 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:09:44 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:09:44 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:09:44 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:09:44 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:09:44 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:09:44 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:09:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:09:44 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:09:44 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:09:44 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:09:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:09:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:09:44 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:09:44 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:09:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:09:44 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:09:44 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:09:44 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:09:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:09:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:09:44 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:09:44 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:09:44 --> Session Class Initialized
DEBUG - 2017-01-01 22:09:44 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:09:44 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:09:44 --> Session routines successfully run
DEBUG - 2017-01-01 22:09:44 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:09:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:09:44 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:09:44 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:09:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:09:44 --> Controller Class Initialized
DEBUG - 2017-01-01 22:09:44 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:09:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:09:44 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:09:44 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:09:44 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:09:44 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:09:44 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:44 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:44 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:44 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:44 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:44 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2017-01-01 22:09:44 --> Pagination Class Initialized
DEBUG - 2017-01-01 22:09:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2017-01-01 22:09:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2017-01-01 22:09:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:09:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:09:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:09:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:09:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2017-01-01 22:09:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:09:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:09:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:09:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:09:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:09:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:09:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2017-01-01 22:09:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:09:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:09:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2017-01-01 22:09:45 --> Final output sent to browser
DEBUG - 2017-01-01 22:09:45 --> Total execution time: 1.1666
DEBUG - 2017-01-01 22:09:50 --> Config Class Initialized
DEBUG - 2017-01-01 22:09:50 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:09:50 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:09:50 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:09:50 --> URI Class Initialized
DEBUG - 2017-01-01 22:09:50 --> Router Class Initialized
DEBUG - 2017-01-01 22:09:50 --> Output Class Initialized
DEBUG - 2017-01-01 22:09:50 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:09:50 --> Security Class Initialized
DEBUG - 2017-01-01 22:09:50 --> Input Class Initialized
DEBUG - 2017-01-01 22:09:50 --> XSS Filtering completed
DEBUG - 2017-01-01 22:09:50 --> XSS Filtering completed
DEBUG - 2017-01-01 22:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:09:50 --> Language Class Initialized
DEBUG - 2017-01-01 22:09:50 --> Loader Class Initialized
DEBUG - 2017-01-01 22:09:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:09:50 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:09:50 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:09:50 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:09:50 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:09:50 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:09:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:09:50 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:09:50 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:09:50 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:09:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:09:50 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:09:50 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:09:50 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:09:50 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:09:50 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:09:51 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:09:51 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:09:51 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:09:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:09:51 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:09:51 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:09:51 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:09:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:09:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:09:51 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:09:51 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:09:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:09:51 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:09:51 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:09:51 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:09:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:09:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:09:51 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:09:51 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:09:51 --> Session Class Initialized
DEBUG - 2017-01-01 22:09:51 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:09:51 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:09:51 --> Session routines successfully run
DEBUG - 2017-01-01 22:09:51 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:09:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:09:51 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:09:51 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:09:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:09:51 --> Controller Class Initialized
DEBUG - 2017-01-01 22:09:51 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:09:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:09:51 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:09:51 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:09:51 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:09:51 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:09:51 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:51 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:51 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:51 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:51 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:51 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:51 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:51 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:51 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:51 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2017-01-01 22:09:51 --> Pagination Class Initialized
DEBUG - 2017-01-01 22:09:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2017-01-01 22:09:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2017-01-01 22:09:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:09:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:09:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:09:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:09:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2017-01-01 22:09:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:09:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:09:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:09:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:09:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:09:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:09:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2017-01-01 22:09:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:09:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:09:51 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2017-01-01 22:09:51 --> Final output sent to browser
DEBUG - 2017-01-01 22:09:52 --> Total execution time: 1.1588
DEBUG - 2017-01-01 22:09:57 --> Config Class Initialized
DEBUG - 2017-01-01 22:09:57 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:09:57 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:09:57 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:09:57 --> URI Class Initialized
DEBUG - 2017-01-01 22:09:57 --> Router Class Initialized
DEBUG - 2017-01-01 22:09:57 --> Output Class Initialized
DEBUG - 2017-01-01 22:09:57 --> Security Class Initialized
DEBUG - 2017-01-01 22:09:57 --> Input Class Initialized
DEBUG - 2017-01-01 22:09:57 --> XSS Filtering completed
DEBUG - 2017-01-01 22:09:57 --> XSS Filtering completed
DEBUG - 2017-01-01 22:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:09:57 --> Language Class Initialized
DEBUG - 2017-01-01 22:09:57 --> Loader Class Initialized
DEBUG - 2017-01-01 22:09:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:09:57 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:09:57 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:09:57 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:09:57 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:09:57 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:09:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:09:57 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:09:57 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:09:57 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:09:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:09:57 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:09:57 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:09:57 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:09:57 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:09:57 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:09:57 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:09:57 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:09:57 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:09:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:09:57 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:09:57 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:09:57 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:09:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:09:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:09:57 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:09:57 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:09:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:09:57 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:09:57 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:09:57 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:09:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:09:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:09:57 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:09:57 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:09:57 --> Session Class Initialized
DEBUG - 2017-01-01 22:09:57 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:09:57 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:09:57 --> Session routines successfully run
DEBUG - 2017-01-01 22:09:57 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:09:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:09:58 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:09:58 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:09:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:09:58 --> Controller Class Initialized
DEBUG - 2017-01-01 22:09:58 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:09:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:09:58 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:09:58 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:09:58 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:09:58 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:09:58 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:58 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:58 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:58 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:58 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:58 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:58 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:58 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:58 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:58 --> Model Class Initialized
DEBUG - 2017-01-01 22:09:58 --> Model Class Initialized
ERROR - 2017-01-01 22:09:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:177) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2017-01-01 22:10:34 --> Config Class Initialized
DEBUG - 2017-01-01 22:10:34 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:10:34 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:10:34 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:10:34 --> URI Class Initialized
DEBUG - 2017-01-01 22:10:34 --> Router Class Initialized
DEBUG - 2017-01-01 22:10:34 --> Output Class Initialized
DEBUG - 2017-01-01 22:10:34 --> Security Class Initialized
DEBUG - 2017-01-01 22:10:34 --> Input Class Initialized
DEBUG - 2017-01-01 22:10:34 --> XSS Filtering completed
DEBUG - 2017-01-01 22:10:34 --> XSS Filtering completed
DEBUG - 2017-01-01 22:10:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:10:34 --> Language Class Initialized
DEBUG - 2017-01-01 22:10:34 --> Loader Class Initialized
DEBUG - 2017-01-01 22:10:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:10:34 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:10:34 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:10:34 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:10:34 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:10:34 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:10:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:10:34 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:10:34 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:10:34 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:10:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:10:34 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:10:34 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:10:34 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:10:34 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:10:34 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:10:34 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:10:34 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:10:34 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:10:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:10:34 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:10:34 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:10:34 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:10:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:10:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:10:34 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:10:34 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:10:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:10:34 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:10:34 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:10:34 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:10:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:10:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:10:34 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:10:34 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:10:34 --> Session Class Initialized
DEBUG - 2017-01-01 22:10:34 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:10:34 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:10:34 --> Session routines successfully run
DEBUG - 2017-01-01 22:10:34 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:10:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:10:34 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:10:34 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:10:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:10:34 --> Controller Class Initialized
DEBUG - 2017-01-01 22:10:34 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:10:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:10:34 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:10:35 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:10:35 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:10:35 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:10:35 --> Model Class Initialized
DEBUG - 2017-01-01 22:10:35 --> Model Class Initialized
DEBUG - 2017-01-01 22:10:35 --> Model Class Initialized
DEBUG - 2017-01-01 22:10:35 --> Model Class Initialized
DEBUG - 2017-01-01 22:10:35 --> Model Class Initialized
DEBUG - 2017-01-01 22:10:35 --> Model Class Initialized
DEBUG - 2017-01-01 22:10:35 --> Model Class Initialized
DEBUG - 2017-01-01 22:10:35 --> Model Class Initialized
DEBUG - 2017-01-01 22:10:35 --> Model Class Initialized
DEBUG - 2017-01-01 22:10:35 --> Model Class Initialized
DEBUG - 2017-01-01 22:10:35 --> Model Class Initialized
ERROR - 2017-01-01 22:10:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:177) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2017-01-01 22:10:55 --> Config Class Initialized
DEBUG - 2017-01-01 22:10:55 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:10:55 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:10:55 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:10:55 --> URI Class Initialized
DEBUG - 2017-01-01 22:10:55 --> Router Class Initialized
DEBUG - 2017-01-01 22:10:55 --> Output Class Initialized
DEBUG - 2017-01-01 22:10:55 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:10:55 --> Security Class Initialized
DEBUG - 2017-01-01 22:10:55 --> Input Class Initialized
DEBUG - 2017-01-01 22:10:55 --> XSS Filtering completed
DEBUG - 2017-01-01 22:10:55 --> XSS Filtering completed
DEBUG - 2017-01-01 22:10:55 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:10:55 --> Language Class Initialized
DEBUG - 2017-01-01 22:10:55 --> Loader Class Initialized
DEBUG - 2017-01-01 22:10:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:10:55 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:10:55 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:10:55 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:10:55 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:10:55 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:10:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:10:55 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:10:55 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:10:55 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:10:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:10:55 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:10:55 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:10:55 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:10:55 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:10:55 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:10:55 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:10:55 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:10:55 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:10:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:10:55 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:10:55 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:10:55 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:10:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:10:56 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:10:56 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:10:56 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:10:56 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:10:56 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:10:56 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:10:56 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:10:56 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:10:56 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:10:56 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:10:56 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:10:56 --> Session Class Initialized
DEBUG - 2017-01-01 22:10:56 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:10:56 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:10:56 --> Session routines successfully run
DEBUG - 2017-01-01 22:10:56 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:10:56 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:10:56 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:10:56 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:10:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:10:56 --> Controller Class Initialized
DEBUG - 2017-01-01 22:10:56 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:10:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:10:56 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:10:56 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:10:56 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:10:56 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:10:56 --> Model Class Initialized
DEBUG - 2017-01-01 22:10:56 --> Model Class Initialized
DEBUG - 2017-01-01 22:10:56 --> Model Class Initialized
DEBUG - 2017-01-01 22:10:56 --> Model Class Initialized
DEBUG - 2017-01-01 22:10:56 --> Model Class Initialized
DEBUG - 2017-01-01 22:10:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2017-01-01 22:10:56 --> Pagination Class Initialized
DEBUG - 2017-01-01 22:10:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2017-01-01 22:10:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_tingkat_pendidikan/index.php
DEBUG - 2017-01-01 22:10:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:10:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:10:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:10:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:10:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_tingkat_pendidikan/js/index_js.php
DEBUG - 2017-01-01 22:10:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:10:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:10:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:10:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:10:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:10:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:10:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_tingkat_pendidikan/js/index_js.php
DEBUG - 2017-01-01 22:10:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:10:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:10:56 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c75a32d2afef33dce35572ed7fc68d18
DEBUG - 2017-01-01 22:10:56 --> Final output sent to browser
DEBUG - 2017-01-01 22:10:56 --> Total execution time: 1.1660
DEBUG - 2017-01-01 22:11:00 --> Config Class Initialized
DEBUG - 2017-01-01 22:11:00 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:11:00 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:11:00 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:11:00 --> URI Class Initialized
DEBUG - 2017-01-01 22:11:00 --> Router Class Initialized
DEBUG - 2017-01-01 22:11:00 --> Output Class Initialized
DEBUG - 2017-01-01 22:11:00 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:11:00 --> Security Class Initialized
DEBUG - 2017-01-01 22:11:00 --> Input Class Initialized
DEBUG - 2017-01-01 22:11:00 --> XSS Filtering completed
DEBUG - 2017-01-01 22:11:00 --> XSS Filtering completed
DEBUG - 2017-01-01 22:11:00 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:11:00 --> Language Class Initialized
DEBUG - 2017-01-01 22:11:00 --> Loader Class Initialized
DEBUG - 2017-01-01 22:11:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:11:00 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:11:00 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:11:01 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:11:01 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:11:01 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:11:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:11:01 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:11:01 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:11:01 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:11:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:11:01 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:11:01 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:11:01 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:11:01 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:11:01 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:11:01 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:11:01 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:11:01 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:11:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:11:01 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:11:01 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:11:01 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:11:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:11:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:11:01 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:11:01 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:11:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:11:01 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:11:01 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:11:01 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:11:01 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:11:01 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:11:01 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:11:01 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:11:01 --> Session Class Initialized
DEBUG - 2017-01-01 22:11:01 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:11:01 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:11:01 --> Session routines successfully run
DEBUG - 2017-01-01 22:11:01 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:11:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:11:01 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:11:01 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:11:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:11:01 --> Controller Class Initialized
DEBUG - 2017-01-01 22:11:01 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:11:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:11:01 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:11:01 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:11:01 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:11:01 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:11:01 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:01 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:01 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:01 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:01 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2017-01-01 22:11:01 --> Pagination Class Initialized
DEBUG - 2017-01-01 22:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2017-01-01 22:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_golongan/index.php
DEBUG - 2017-01-01 22:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:11:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_golongan/js/index_js.php
DEBUG - 2017-01-01 22:11:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:11:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:11:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:11:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:11:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:11:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:11:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_golongan/js/index_js.php
DEBUG - 2017-01-01 22:11:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:11:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:11:02 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0a9f345e7377389319d1a253f860e8a1
DEBUG - 2017-01-01 22:11:02 --> Final output sent to browser
DEBUG - 2017-01-01 22:11:02 --> Total execution time: 1.1894
DEBUG - 2017-01-01 22:11:06 --> Config Class Initialized
DEBUG - 2017-01-01 22:11:06 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:11:06 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:11:06 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:11:06 --> URI Class Initialized
DEBUG - 2017-01-01 22:11:06 --> Router Class Initialized
DEBUG - 2017-01-01 22:11:06 --> Output Class Initialized
DEBUG - 2017-01-01 22:11:07 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:11:07 --> Security Class Initialized
DEBUG - 2017-01-01 22:11:07 --> Input Class Initialized
DEBUG - 2017-01-01 22:11:07 --> XSS Filtering completed
DEBUG - 2017-01-01 22:11:07 --> XSS Filtering completed
DEBUG - 2017-01-01 22:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:11:07 --> Language Class Initialized
DEBUG - 2017-01-01 22:11:07 --> Loader Class Initialized
DEBUG - 2017-01-01 22:11:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:11:07 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:11:07 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:11:07 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:11:07 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:11:07 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:11:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:11:07 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:11:07 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:11:07 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:11:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:11:07 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:11:07 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:11:07 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:11:07 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:11:07 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:11:07 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:11:07 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:11:07 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:11:07 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:11:07 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:11:07 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:11:07 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:11:07 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:11:07 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:11:07 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:11:07 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:11:07 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:11:07 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:11:07 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:11:07 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:11:07 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:11:07 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:11:07 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:11:07 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:11:07 --> Session Class Initialized
DEBUG - 2017-01-01 22:11:07 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:11:07 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:11:07 --> Session routines successfully run
DEBUG - 2017-01-01 22:11:07 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:11:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:11:07 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:11:07 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:11:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:11:07 --> Controller Class Initialized
DEBUG - 2017-01-01 22:11:07 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:11:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:11:07 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:11:07 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:11:07 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:11:07 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:11:07 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:07 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:08 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:08 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:08 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2017-01-01 22:11:08 --> Pagination Class Initialized
DEBUG - 2017-01-01 22:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2017-01-01 22:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/index.php
DEBUG - 2017-01-01 22:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2017-01-01 22:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2017-01-01 22:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:11:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:11:08 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/860bebf57fee032e24acce1c64d1c3e7
DEBUG - 2017-01-01 22:11:08 --> Final output sent to browser
DEBUG - 2017-01-01 22:11:08 --> Total execution time: 1.2850
DEBUG - 2017-01-01 22:11:14 --> Config Class Initialized
DEBUG - 2017-01-01 22:11:14 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:11:14 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:11:14 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:11:14 --> URI Class Initialized
DEBUG - 2017-01-01 22:11:14 --> Router Class Initialized
DEBUG - 2017-01-01 22:11:14 --> Output Class Initialized
DEBUG - 2017-01-01 22:11:14 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:11:14 --> Security Class Initialized
DEBUG - 2017-01-01 22:11:14 --> Input Class Initialized
DEBUG - 2017-01-01 22:11:14 --> XSS Filtering completed
DEBUG - 2017-01-01 22:11:14 --> XSS Filtering completed
DEBUG - 2017-01-01 22:11:14 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:11:14 --> Language Class Initialized
DEBUG - 2017-01-01 22:11:14 --> Loader Class Initialized
DEBUG - 2017-01-01 22:11:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:11:14 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:11:14 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:11:14 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:11:14 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:11:14 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:11:14 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:11:14 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:11:14 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:11:14 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:11:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:11:14 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:11:14 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:11:14 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:11:14 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:11:14 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:11:14 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:11:14 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:11:14 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:11:14 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:11:14 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:11:14 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:11:14 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:11:14 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:11:14 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:11:14 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:11:14 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:11:14 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:11:14 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:11:14 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:11:14 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:11:14 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:11:14 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:11:14 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:11:14 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:11:15 --> Session Class Initialized
DEBUG - 2017-01-01 22:11:15 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:11:15 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:11:15 --> Session routines successfully run
DEBUG - 2017-01-01 22:11:15 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:11:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:11:15 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:11:15 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:11:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:11:15 --> Controller Class Initialized
DEBUG - 2017-01-01 22:11:15 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:11:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:11:15 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:11:15 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:11:15 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:11:15 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:11:15 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:15 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:15 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:15 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:15 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2017-01-01 22:11:15 --> Pagination Class Initialized
DEBUG - 2017-01-01 22:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2017-01-01 22:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/index.php
DEBUG - 2017-01-01 22:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2017-01-01 22:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2017-01-01 22:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:11:15 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c2a3e0401bd35d4fcac4bae5f9412231
DEBUG - 2017-01-01 22:11:15 --> Final output sent to browser
DEBUG - 2017-01-01 22:11:15 --> Total execution time: 1.2510
DEBUG - 2017-01-01 22:11:19 --> Config Class Initialized
DEBUG - 2017-01-01 22:11:19 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:11:19 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:11:19 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:11:19 --> URI Class Initialized
DEBUG - 2017-01-01 22:11:19 --> Router Class Initialized
DEBUG - 2017-01-01 22:11:19 --> Output Class Initialized
DEBUG - 2017-01-01 22:11:19 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:11:19 --> Security Class Initialized
DEBUG - 2017-01-01 22:11:19 --> Input Class Initialized
DEBUG - 2017-01-01 22:11:19 --> XSS Filtering completed
DEBUG - 2017-01-01 22:11:19 --> XSS Filtering completed
DEBUG - 2017-01-01 22:11:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:11:19 --> Language Class Initialized
DEBUG - 2017-01-01 22:11:19 --> Loader Class Initialized
DEBUG - 2017-01-01 22:11:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:11:19 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:11:19 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:11:19 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:11:19 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:11:19 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:11:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:11:19 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:11:19 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:11:19 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:11:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:11:19 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:11:19 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:11:19 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:11:19 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:11:19 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:11:19 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:11:19 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:11:19 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:11:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:11:19 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:11:19 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:11:19 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:11:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:11:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:11:19 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:11:19 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:11:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:11:19 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:11:19 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:11:19 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:11:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:11:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:11:19 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:11:19 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:11:19 --> Session Class Initialized
DEBUG - 2017-01-01 22:11:19 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:11:19 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:11:19 --> Session routines successfully run
DEBUG - 2017-01-01 22:11:19 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:11:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:11:20 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:11:20 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:11:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:11:20 --> Controller Class Initialized
DEBUG - 2017-01-01 22:11:20 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:11:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:11:20 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:11:20 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:11:20 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:11:20 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:11:20 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:20 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:20 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:20 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:20 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2017-01-01 22:11:20 --> Pagination Class Initialized
DEBUG - 2017-01-01 22:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2017-01-01 22:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_kabupaten_kota/index.php
DEBUG - 2017-01-01 22:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_kabupaten_kota/js/index_js.php
DEBUG - 2017-01-01 22:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_kabupaten_kota/js/index_js.php
DEBUG - 2017-01-01 22:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:11:20 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/67a9fbaf55b76491201f96f5102e0b64
DEBUG - 2017-01-01 22:11:20 --> Final output sent to browser
DEBUG - 2017-01-01 22:11:20 --> Total execution time: 1.2408
DEBUG - 2017-01-01 22:11:24 --> Config Class Initialized
DEBUG - 2017-01-01 22:11:24 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:11:24 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:11:24 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:11:24 --> URI Class Initialized
DEBUG - 2017-01-01 22:11:24 --> Router Class Initialized
DEBUG - 2017-01-01 22:11:24 --> Output Class Initialized
DEBUG - 2017-01-01 22:11:24 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:11:24 --> Security Class Initialized
DEBUG - 2017-01-01 22:11:24 --> Input Class Initialized
DEBUG - 2017-01-01 22:11:24 --> XSS Filtering completed
DEBUG - 2017-01-01 22:11:24 --> XSS Filtering completed
DEBUG - 2017-01-01 22:11:24 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:11:24 --> Language Class Initialized
DEBUG - 2017-01-01 22:11:24 --> Loader Class Initialized
DEBUG - 2017-01-01 22:11:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:11:24 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:11:24 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:11:24 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:11:24 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:11:24 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:11:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:11:24 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:11:24 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:11:24 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:11:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:11:24 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:11:24 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:11:24 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:11:24 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:11:24 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:11:24 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:11:24 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:11:24 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:11:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:11:24 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:11:24 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:11:24 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:11:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:11:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:11:24 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:11:24 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:11:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:11:24 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:11:24 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:11:25 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:11:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:11:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:11:25 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:11:25 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:11:25 --> Session Class Initialized
DEBUG - 2017-01-01 22:11:25 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:11:25 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:11:25 --> Session routines successfully run
DEBUG - 2017-01-01 22:11:25 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:11:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:11:25 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:11:25 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:11:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:11:25 --> Controller Class Initialized
DEBUG - 2017-01-01 22:11:25 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:11:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:11:25 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:11:25 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:11:25 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:11:25 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:11:25 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:25 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:25 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:25 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:25 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2017-01-01 22:11:25 --> Pagination Class Initialized
DEBUG - 2017-01-01 22:11:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2017-01-01 22:11:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/index.php
DEBUG - 2017-01-01 22:11:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:11:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:11:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:11:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:11:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2017-01-01 22:11:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:11:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:11:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:11:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:11:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:11:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:11:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2017-01-01 22:11:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:11:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:11:25 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0afc8ae14bdb2df5b4e2fbf4366db4fc
DEBUG - 2017-01-01 22:11:25 --> Final output sent to browser
DEBUG - 2017-01-01 22:11:25 --> Total execution time: 1.2561
DEBUG - 2017-01-01 22:11:28 --> Config Class Initialized
DEBUG - 2017-01-01 22:11:28 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:11:28 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:11:29 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:11:29 --> URI Class Initialized
DEBUG - 2017-01-01 22:11:29 --> Router Class Initialized
DEBUG - 2017-01-01 22:11:29 --> Output Class Initialized
DEBUG - 2017-01-01 22:11:29 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:11:29 --> Security Class Initialized
DEBUG - 2017-01-01 22:11:29 --> Input Class Initialized
DEBUG - 2017-01-01 22:11:29 --> XSS Filtering completed
DEBUG - 2017-01-01 22:11:29 --> XSS Filtering completed
DEBUG - 2017-01-01 22:11:29 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:11:29 --> Language Class Initialized
DEBUG - 2017-01-01 22:11:29 --> Loader Class Initialized
DEBUG - 2017-01-01 22:11:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:11:29 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:11:29 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:11:29 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:11:29 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:11:29 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:11:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:11:29 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:11:29 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:11:29 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:11:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:11:29 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:11:29 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:11:29 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:11:29 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:11:29 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:11:29 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:11:29 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:11:29 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:11:29 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:11:29 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:11:29 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:11:29 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:11:29 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:11:29 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:11:29 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:11:29 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:11:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:11:29 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:11:29 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:11:29 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:11:29 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:11:29 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:11:29 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:11:29 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:11:29 --> Session Class Initialized
DEBUG - 2017-01-01 22:11:29 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:11:29 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:11:29 --> Session routines successfully run
DEBUG - 2017-01-01 22:11:29 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:11:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:11:29 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:11:29 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:11:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:11:29 --> Controller Class Initialized
DEBUG - 2017-01-01 22:11:29 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:11:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:11:30 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:11:30 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:11:30 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:11:30 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:11:30 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:30 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:30 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:30 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:30 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2017-01-01 22:11:30 --> Pagination Class Initialized
DEBUG - 2017-01-01 22:11:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2017-01-01 22:11:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_ttd/index.php
DEBUG - 2017-01-01 22:11:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:11:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:11:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:11:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:11:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_ttd/js/index_js.php
DEBUG - 2017-01-01 22:11:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:11:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:11:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:11:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:11:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:11:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:11:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_ttd/js/index_js.php
DEBUG - 2017-01-01 22:11:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:11:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:11:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/57d0db215062cedca2b4c7c8b724c691
DEBUG - 2017-01-01 22:11:30 --> Final output sent to browser
DEBUG - 2017-01-01 22:11:30 --> Total execution time: 1.2705
DEBUG - 2017-01-01 22:11:34 --> Config Class Initialized
DEBUG - 2017-01-01 22:11:34 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:11:34 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:11:34 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:11:34 --> URI Class Initialized
DEBUG - 2017-01-01 22:11:34 --> Router Class Initialized
DEBUG - 2017-01-01 22:11:34 --> Output Class Initialized
DEBUG - 2017-01-01 22:11:34 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:11:34 --> Security Class Initialized
DEBUG - 2017-01-01 22:11:34 --> Input Class Initialized
DEBUG - 2017-01-01 22:11:34 --> XSS Filtering completed
DEBUG - 2017-01-01 22:11:34 --> XSS Filtering completed
DEBUG - 2017-01-01 22:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:11:34 --> Language Class Initialized
DEBUG - 2017-01-01 22:11:34 --> Loader Class Initialized
DEBUG - 2017-01-01 22:11:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:11:34 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:11:34 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:11:34 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:11:34 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:11:34 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:11:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:11:34 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:11:34 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:11:34 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:11:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:11:34 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:11:34 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:11:34 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:11:34 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:11:34 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:11:34 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:11:34 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:11:34 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:11:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:11:34 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:11:35 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:11:35 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:11:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:11:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:11:35 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:11:35 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:11:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:11:35 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:11:35 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:11:35 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:11:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:11:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:11:35 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:11:35 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:11:35 --> Session Class Initialized
DEBUG - 2017-01-01 22:11:35 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:11:35 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:11:35 --> Session routines successfully run
DEBUG - 2017-01-01 22:11:35 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:11:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:11:35 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:11:35 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:11:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:11:35 --> Controller Class Initialized
DEBUG - 2017-01-01 22:11:35 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:11:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:11:35 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:11:35 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:11:35 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:11:35 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:11:35 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:35 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:35 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:35 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:35 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2017-01-01 22:11:35 --> Pagination Class Initialized
DEBUG - 2017-01-01 22:11:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2017-01-01 22:11:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_jabatan/index.php
DEBUG - 2017-01-01 22:11:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:11:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:11:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:11:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:11:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_jabatan/js/index_js.php
DEBUG - 2017-01-01 22:11:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:11:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:11:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:11:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:11:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:11:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:11:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_jabatan/js/index_js.php
DEBUG - 2017-01-01 22:11:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:11:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:11:35 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ba4994ce93fe7c31a0d1ab59dc6a7701
DEBUG - 2017-01-01 22:11:36 --> Final output sent to browser
DEBUG - 2017-01-01 22:11:36 --> Total execution time: 1.3166
DEBUG - 2017-01-01 22:11:44 --> Config Class Initialized
DEBUG - 2017-01-01 22:11:44 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:11:44 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:11:44 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:11:44 --> URI Class Initialized
DEBUG - 2017-01-01 22:11:44 --> Router Class Initialized
DEBUG - 2017-01-01 22:11:44 --> Output Class Initialized
DEBUG - 2017-01-01 22:11:44 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:11:44 --> Security Class Initialized
DEBUG - 2017-01-01 22:11:44 --> Input Class Initialized
DEBUG - 2017-01-01 22:11:44 --> XSS Filtering completed
DEBUG - 2017-01-01 22:11:44 --> XSS Filtering completed
DEBUG - 2017-01-01 22:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:11:44 --> Language Class Initialized
DEBUG - 2017-01-01 22:11:44 --> Loader Class Initialized
DEBUG - 2017-01-01 22:11:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:11:44 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:11:44 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:11:44 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:11:44 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:11:44 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:11:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:11:44 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:11:45 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:11:45 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:11:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:11:45 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:11:45 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:11:45 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:11:45 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:11:45 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:11:45 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:11:45 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:11:45 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:11:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:11:45 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:11:45 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:11:45 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:11:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:11:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:11:45 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:11:45 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:11:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:11:45 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:11:45 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:11:45 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:11:45 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:11:45 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:11:45 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:11:45 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:11:45 --> Session Class Initialized
DEBUG - 2017-01-01 22:11:45 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:11:45 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:11:45 --> Session routines successfully run
DEBUG - 2017-01-01 22:11:45 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:11:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:11:45 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:11:45 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:11:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:11:45 --> Controller Class Initialized
DEBUG - 2017-01-01 22:11:45 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:11:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:11:45 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:11:45 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:11:45 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:11:45 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:11:45 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:45 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:45 --> Model Class Initialized
DEBUG - 2017-01-01 22:11:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2017-01-01 22:11:45 --> Pagination Class Initialized
DEBUG - 2017-01-01 22:11:45 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2017-01-01 22:11:45 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/index.php
DEBUG - 2017-01-01 22:11:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:11:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:11:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:11:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:11:45 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2017-01-01 22:11:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:11:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:11:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:11:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:11:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:11:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:11:46 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2017-01-01 22:11:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:11:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:11:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8118d087c6d6c5bac3947ef2cf7a3513
DEBUG - 2017-01-01 22:11:46 --> Final output sent to browser
DEBUG - 2017-01-01 22:11:46 --> Total execution time: 1.2822
DEBUG - 2017-01-01 22:12:08 --> Config Class Initialized
DEBUG - 2017-01-01 22:12:08 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:12:08 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:12:08 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:12:08 --> URI Class Initialized
DEBUG - 2017-01-01 22:12:08 --> Router Class Initialized
DEBUG - 2017-01-01 22:12:08 --> Output Class Initialized
DEBUG - 2017-01-01 22:12:08 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:12:08 --> Security Class Initialized
DEBUG - 2017-01-01 22:12:08 --> Input Class Initialized
DEBUG - 2017-01-01 22:12:08 --> XSS Filtering completed
DEBUG - 2017-01-01 22:12:08 --> XSS Filtering completed
DEBUG - 2017-01-01 22:12:08 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:12:08 --> Language Class Initialized
DEBUG - 2017-01-01 22:12:08 --> Loader Class Initialized
DEBUG - 2017-01-01 22:12:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:12:08 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:12:08 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:12:08 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:12:08 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:12:08 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:12:08 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:12:08 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:12:08 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:12:08 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:12:08 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:12:08 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:12:08 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:12:08 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:12:08 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:12:08 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:12:08 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:12:08 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:12:08 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:12:08 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:12:08 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:12:08 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:12:08 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:12:08 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:12:08 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:12:08 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:12:08 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:12:08 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:12:08 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:12:08 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:12:09 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:12:09 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:12:09 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:12:09 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:12:09 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:12:09 --> Session Class Initialized
DEBUG - 2017-01-01 22:12:09 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:12:09 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:12:09 --> Session routines successfully run
DEBUG - 2017-01-01 22:12:09 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:12:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:12:09 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:12:09 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:12:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:12:09 --> Controller Class Initialized
DEBUG - 2017-01-01 22:12:09 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:12:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:12:09 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:12:09 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:12:09 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:12:09 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:12:09 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:09 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:09 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:09 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:09 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:09 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:09 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2017-01-01 22:12:09 --> Pagination Class Initialized
DEBUG - 2017-01-01 22:12:09 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2017-01-01 22:12:09 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/index.php
DEBUG - 2017-01-01 22:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:12:09 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2017-01-01 22:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:12:09 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2017-01-01 22:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:12:09 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55961f1d1ca16fdfc4239ae1901a174e
DEBUG - 2017-01-01 22:12:09 --> Final output sent to browser
DEBUG - 2017-01-01 22:12:09 --> Total execution time: 1.3969
DEBUG - 2017-01-01 22:12:15 --> Config Class Initialized
DEBUG - 2017-01-01 22:12:15 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:12:15 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:12:15 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:12:15 --> URI Class Initialized
DEBUG - 2017-01-01 22:12:15 --> Router Class Initialized
DEBUG - 2017-01-01 22:12:16 --> Output Class Initialized
DEBUG - 2017-01-01 22:12:16 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:12:16 --> Security Class Initialized
DEBUG - 2017-01-01 22:12:16 --> Input Class Initialized
DEBUG - 2017-01-01 22:12:16 --> XSS Filtering completed
DEBUG - 2017-01-01 22:12:16 --> XSS Filtering completed
DEBUG - 2017-01-01 22:12:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:12:16 --> Language Class Initialized
DEBUG - 2017-01-01 22:12:16 --> Loader Class Initialized
DEBUG - 2017-01-01 22:12:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:12:16 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:12:16 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:12:16 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:12:16 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:12:16 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:12:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:12:16 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:12:16 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:12:16 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:12:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:12:16 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:12:16 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:12:16 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:12:16 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:12:16 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:12:16 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:12:16 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:12:16 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:12:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:12:16 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:12:16 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:12:16 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:12:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:12:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:12:16 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:12:16 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:12:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:12:16 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:12:16 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:12:16 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:12:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:12:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:12:16 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:12:16 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:12:16 --> Session Class Initialized
DEBUG - 2017-01-01 22:12:16 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:12:16 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:12:16 --> Session routines successfully run
DEBUG - 2017-01-01 22:12:16 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:12:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:12:16 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:12:16 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:12:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:12:16 --> Controller Class Initialized
DEBUG - 2017-01-01 22:12:17 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:12:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:12:17 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:12:17 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:12:17 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:12:17 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:12:17 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:17 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:17 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:17 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2017-01-01 22:12:17 --> Pagination Class Initialized
DEBUG - 2017-01-01 22:12:17 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2017-01-01 22:12:17 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/role/atlant/index.php
DEBUG - 2017-01-01 22:12:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:12:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:12:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:12:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:12:17 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/role/atlant/js/index_js.php
DEBUG - 2017-01-01 22:12:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:12:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:12:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:12:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:12:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:12:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:12:17 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/role/atlant/js/index_js.php
DEBUG - 2017-01-01 22:12:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:12:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:12:17 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/bc71e124988d1eb532a929fcbfe4318b
DEBUG - 2017-01-01 22:12:17 --> Final output sent to browser
DEBUG - 2017-01-01 22:12:17 --> Total execution time: 1.3496
DEBUG - 2017-01-01 22:12:22 --> Config Class Initialized
DEBUG - 2017-01-01 22:12:22 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:12:22 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:12:22 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:12:22 --> URI Class Initialized
DEBUG - 2017-01-01 22:12:22 --> Router Class Initialized
DEBUG - 2017-01-01 22:12:22 --> Output Class Initialized
DEBUG - 2017-01-01 22:12:22 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:12:22 --> Security Class Initialized
DEBUG - 2017-01-01 22:12:22 --> Input Class Initialized
DEBUG - 2017-01-01 22:12:22 --> XSS Filtering completed
DEBUG - 2017-01-01 22:12:22 --> XSS Filtering completed
DEBUG - 2017-01-01 22:12:22 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:12:22 --> Language Class Initialized
DEBUG - 2017-01-01 22:12:22 --> Loader Class Initialized
DEBUG - 2017-01-01 22:12:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:12:22 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:12:22 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:12:22 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:12:22 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:12:22 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:12:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:12:22 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:12:22 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:12:22 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:12:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:12:22 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:12:22 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:12:22 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:12:22 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:12:22 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:12:22 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:12:22 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:12:22 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:12:22 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:12:22 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:12:22 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:12:22 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:12:22 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:12:22 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:12:22 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:12:22 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:12:22 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:12:22 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:12:22 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:12:22 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:12:22 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:12:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:12:23 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:12:23 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:12:23 --> Session Class Initialized
DEBUG - 2017-01-01 22:12:23 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:12:23 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:12:23 --> Session routines successfully run
DEBUG - 2017-01-01 22:12:23 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:12:23 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:12:23 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:12:23 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:12:23 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:12:23 --> Controller Class Initialized
DEBUG - 2017-01-01 22:12:23 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:12:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:12:23 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:12:23 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:12:23 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:12:23 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:12:23 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:23 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:23 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:23 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:23 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:23 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2017-01-01 22:12:23 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/role/atlant/detail.php
DEBUG - 2017-01-01 22:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:12:23 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/role/atlant/js/detail_js.php
DEBUG - 2017-01-01 22:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:12:23 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/role/atlant/js/detail_js.php
DEBUG - 2017-01-01 22:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:12:23 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8cdb829d3d6f4b64486cc3380cd99617
DEBUG - 2017-01-01 22:12:23 --> Final output sent to browser
DEBUG - 2017-01-01 22:12:23 --> Total execution time: 1.3632
DEBUG - 2017-01-01 22:12:45 --> Config Class Initialized
DEBUG - 2017-01-01 22:12:45 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:12:45 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:12:45 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:12:45 --> URI Class Initialized
DEBUG - 2017-01-01 22:12:45 --> Router Class Initialized
DEBUG - 2017-01-01 22:12:45 --> Output Class Initialized
DEBUG - 2017-01-01 22:12:45 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:12:45 --> Security Class Initialized
DEBUG - 2017-01-01 22:12:45 --> Input Class Initialized
DEBUG - 2017-01-01 22:12:45 --> XSS Filtering completed
DEBUG - 2017-01-01 22:12:45 --> XSS Filtering completed
DEBUG - 2017-01-01 22:12:45 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:12:45 --> Language Class Initialized
DEBUG - 2017-01-01 22:12:45 --> Loader Class Initialized
DEBUG - 2017-01-01 22:12:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:12:45 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:12:45 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:12:45 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:12:45 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:12:45 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:12:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:12:45 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:12:45 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:12:45 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:12:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:12:45 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:12:45 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:12:45 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:12:45 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:12:45 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:12:45 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:12:45 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:12:45 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:12:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:12:45 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:12:46 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:12:46 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:12:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:12:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:12:46 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:12:46 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:12:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:12:46 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:12:46 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:12:46 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:12:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:12:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:12:46 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:12:46 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:12:46 --> Session Class Initialized
DEBUG - 2017-01-01 22:12:46 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:12:46 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:12:46 --> Session routines successfully run
DEBUG - 2017-01-01 22:12:46 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:12:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:12:46 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:12:46 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:12:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:12:46 --> Controller Class Initialized
DEBUG - 2017-01-01 22:12:46 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:12:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:12:46 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:12:46 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:12:46 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:12:46 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:12:46 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:46 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:46 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:46 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:46 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:46 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:46 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:46 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:46 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:46 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2017-01-01 22:12:46 --> Pagination Class Initialized
DEBUG - 2017-01-01 22:12:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2017-01-01 22:12:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2017-01-01 22:12:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:12:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:12:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:12:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:12:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2017-01-01 22:12:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:12:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:12:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-01 22:12:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-01 22:12:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:12:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-01 22:12:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2017-01-01 22:12:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:12:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-01 22:12:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2017-01-01 22:12:47 --> Final output sent to browser
DEBUG - 2017-01-01 22:12:47 --> Total execution time: 1.5146
DEBUG - 2017-01-01 22:12:56 --> Config Class Initialized
DEBUG - 2017-01-01 22:12:56 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:12:56 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:12:56 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:12:56 --> URI Class Initialized
DEBUG - 2017-01-01 22:12:56 --> Router Class Initialized
DEBUG - 2017-01-01 22:12:56 --> Output Class Initialized
DEBUG - 2017-01-01 22:12:56 --> Security Class Initialized
DEBUG - 2017-01-01 22:12:56 --> Input Class Initialized
DEBUG - 2017-01-01 22:12:56 --> XSS Filtering completed
DEBUG - 2017-01-01 22:12:56 --> XSS Filtering completed
DEBUG - 2017-01-01 22:12:56 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:12:56 --> Language Class Initialized
DEBUG - 2017-01-01 22:12:56 --> Loader Class Initialized
DEBUG - 2017-01-01 22:12:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:12:56 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:12:56 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:12:56 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:12:56 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:12:56 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:12:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:12:56 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:12:56 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:12:56 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:12:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:12:56 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:12:56 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:12:56 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:12:56 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:12:56 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:12:56 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:12:57 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:12:57 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:12:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:12:57 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:12:57 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:12:57 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:12:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:12:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:12:57 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:12:57 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:12:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:12:57 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:12:57 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:12:57 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:12:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:12:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:12:57 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:12:57 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:12:57 --> Session Class Initialized
DEBUG - 2017-01-01 22:12:57 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:12:57 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:12:57 --> Session routines successfully run
DEBUG - 2017-01-01 22:12:57 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:12:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:12:57 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:12:57 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:12:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:12:57 --> Controller Class Initialized
DEBUG - 2017-01-01 22:12:57 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:12:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:12:57 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:12:57 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:12:57 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:12:57 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:12:57 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:57 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:57 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:57 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:57 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:57 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:57 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:57 --> Config Class Initialized
DEBUG - 2017-01-01 22:12:57 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:12:57 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:12:57 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:12:57 --> URI Class Initialized
DEBUG - 2017-01-01 22:12:57 --> Router Class Initialized
DEBUG - 2017-01-01 22:12:57 --> No URI present. Default controller set.
DEBUG - 2017-01-01 22:12:57 --> Output Class Initialized
DEBUG - 2017-01-01 22:12:57 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:12:57 --> Security Class Initialized
DEBUG - 2017-01-01 22:12:58 --> Input Class Initialized
DEBUG - 2017-01-01 22:12:58 --> XSS Filtering completed
DEBUG - 2017-01-01 22:12:58 --> XSS Filtering completed
DEBUG - 2017-01-01 22:12:58 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:12:58 --> Language Class Initialized
DEBUG - 2017-01-01 22:12:58 --> Loader Class Initialized
DEBUG - 2017-01-01 22:12:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:12:58 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:12:58 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:12:58 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:12:58 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:12:58 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:12:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:12:58 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:12:58 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:12:58 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:12:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:12:58 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:12:58 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:12:58 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:12:58 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:12:58 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:12:58 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:12:58 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:12:58 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:12:58 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:12:58 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:12:58 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:12:58 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:12:58 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:12:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:12:58 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:12:58 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:12:58 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:12:58 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:12:58 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:12:58 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:12:58 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:12:58 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:12:58 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:12:58 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:12:58 --> Session Class Initialized
DEBUG - 2017-01-01 22:12:58 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:12:58 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:12:58 --> Session routines successfully run
DEBUG - 2017-01-01 22:12:58 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:12:58 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:12:58 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:12:58 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:12:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:12:58 --> Controller Class Initialized
DEBUG - 2017-01-01 22:12:59 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:12:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:12:59 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:12:59 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:12:59 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:12:59 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:12:59 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:59 --> Model Class Initialized
DEBUG - 2017-01-01 22:12:59 --> Model Class Initialized
ERROR - 2017-01-01 22:12:59 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2017-01-01 22:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2017-01-01 22:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2017-01-01 22:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-01 22:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-01 22:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-01 22:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-01 22:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-01 22:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-01 22:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-01 22:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-01 22:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-01 22:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-01 22:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-01 22:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-01 22:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-01 22:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-01 22:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-01 22:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-01 22:12:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2017-01-01 22:12:59 --> Final output sent to browser
DEBUG - 2017-01-01 22:12:59 --> Total execution time: 1.3926
DEBUG - 2017-01-01 22:12:59 --> Config Class Initialized
DEBUG - 2017-01-01 22:12:59 --> Hooks Class Initialized
DEBUG - 2017-01-01 22:12:59 --> Utf8 Class Initialized
DEBUG - 2017-01-01 22:12:59 --> UTF-8 Support Enabled
DEBUG - 2017-01-01 22:12:59 --> URI Class Initialized
DEBUG - 2017-01-01 22:12:59 --> Router Class Initialized
DEBUG - 2017-01-01 22:12:59 --> Output Class Initialized
DEBUG - 2017-01-01 22:12:59 --> Cache file has expired. File deleted
DEBUG - 2017-01-01 22:12:59 --> Security Class Initialized
DEBUG - 2017-01-01 22:12:59 --> Input Class Initialized
DEBUG - 2017-01-01 22:13:00 --> XSS Filtering completed
DEBUG - 2017-01-01 22:13:00 --> XSS Filtering completed
DEBUG - 2017-01-01 22:13:00 --> XSS Filtering completed
DEBUG - 2017-01-01 22:13:00 --> XSS Filtering completed
DEBUG - 2017-01-01 22:13:00 --> XSS Filtering completed
DEBUG - 2017-01-01 22:13:00 --> XSS Filtering completed
DEBUG - 2017-01-01 22:13:00 --> XSS Filtering completed
DEBUG - 2017-01-01 22:13:00 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-01 22:13:00 --> Language Class Initialized
DEBUG - 2017-01-01 22:13:00 --> Loader Class Initialized
DEBUG - 2017-01-01 22:13:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-01 22:13:00 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-01 22:13:00 --> Helper loaded: url_helper
DEBUG - 2017-01-01 22:13:00 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-01 22:13:00 --> Helper loaded: file_helper
DEBUG - 2017-01-01 22:13:00 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:13:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-01 22:13:00 --> Helper loaded: conf_helper
DEBUG - 2017-01-01 22:13:00 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-01 22:13:00 --> Check Exists common_helper.php: No
DEBUG - 2017-01-01 22:13:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-01 22:13:00 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:13:00 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-01 22:13:00 --> Helper loaded: common_helper
DEBUG - 2017-01-01 22:13:00 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-01 22:13:00 --> Helper loaded: form_helper
DEBUG - 2017-01-01 22:13:00 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-01 22:13:00 --> Helper loaded: security_helper
DEBUG - 2017-01-01 22:13:00 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:13:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-01 22:13:00 --> Helper loaded: lang_helper
DEBUG - 2017-01-01 22:13:00 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-01 22:13:00 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-01 22:13:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-01 22:13:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-01 22:13:00 --> Helper loaded: atlant_helper
DEBUG - 2017-01-01 22:13:00 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:13:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-01 22:13:00 --> Helper loaded: crypto_helper
DEBUG - 2017-01-01 22:13:00 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-01 22:13:00 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-01 22:13:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-01 22:13:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-01 22:13:00 --> Helper loaded: sidika_helper
DEBUG - 2017-01-01 22:13:00 --> Database Driver Class Initialized
DEBUG - 2017-01-01 22:13:00 --> Session Class Initialized
DEBUG - 2017-01-01 22:13:00 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-01 22:13:00 --> Helper loaded: string_helper
DEBUG - 2017-01-01 22:13:01 --> Session routines successfully run
DEBUG - 2017-01-01 22:13:01 --> Native_session Class Initialized
DEBUG - 2017-01-01 22:13:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-01 22:13:01 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:13:01 --> Form Validation Class Initialized
DEBUG - 2017-01-01 22:13:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-01 22:13:01 --> Controller Class Initialized
DEBUG - 2017-01-01 22:13:01 --> Carabiner: Library initialized.
DEBUG - 2017-01-01 22:13:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-01 22:13:01 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-01 22:13:01 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:13:01 --> Carabiner: library configured.
DEBUG - 2017-01-01 22:13:01 --> User Agent Class Initialized
DEBUG - 2017-01-01 22:13:01 --> Model Class Initialized
DEBUG - 2017-01-01 22:13:01 --> Model Class Initialized
DEBUG - 2017-01-01 22:13:01 --> Model Class Initialized
DEBUG - 2017-01-01 22:13:01 --> Model Class Initialized
DEBUG - 2017-01-01 22:13:01 --> Model Class Initialized
DEBUG - 2017-01-01 22:13:01 --> Model Class Initialized
DEBUG - 2017-01-01 22:13:01 --> Model Class Initialized
DEBUG - 2017-01-01 22:13:01 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2017-01-01 22:13:01 --> Final output sent to browser
DEBUG - 2017-01-01 22:13:01 --> Total execution time: 1.6366
