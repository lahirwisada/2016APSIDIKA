<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-11-14 12:10:36 --> Config Class Initialized
DEBUG - 2016-11-14 12:10:36 --> Hooks Class Initialized
DEBUG - 2016-11-14 12:10:36 --> Utf8 Class Initialized
DEBUG - 2016-11-14 12:10:36 --> UTF-8 Support Enabled
DEBUG - 2016-11-14 12:10:36 --> URI Class Initialized
DEBUG - 2016-11-14 12:10:36 --> Router Class Initialized
DEBUG - 2016-11-14 12:10:36 --> No URI present. Default controller set.
DEBUG - 2016-11-14 12:10:36 --> Output Class Initialized
DEBUG - 2016-11-14 12:10:36 --> Cache file has expired. File deleted
DEBUG - 2016-11-14 12:10:36 --> Security Class Initialized
DEBUG - 2016-11-14 12:10:36 --> Input Class Initialized
DEBUG - 2016-11-14 12:10:36 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:36 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-14 12:10:36 --> Language Class Initialized
DEBUG - 2016-11-14 12:10:36 --> Loader Class Initialized
DEBUG - 2016-11-14 12:10:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-14 12:10:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-14 12:10:36 --> Helper loaded: url_helper
DEBUG - 2016-11-14 12:10:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-14 12:10:36 --> Helper loaded: file_helper
DEBUG - 2016-11-14 12:10:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:10:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-14 12:10:36 --> Helper loaded: conf_helper
DEBUG - 2016-11-14 12:10:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:10:36 --> Check Exists common_helper.php: No
DEBUG - 2016-11-14 12:10:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-14 12:10:36 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:10:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-14 12:10:36 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:10:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-14 12:10:36 --> Helper loaded: form_helper
DEBUG - 2016-11-14 12:10:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-14 12:10:36 --> Helper loaded: security_helper
DEBUG - 2016-11-14 12:10:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:10:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-14 12:10:36 --> Helper loaded: lang_helper
DEBUG - 2016-11-14 12:10:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:10:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-14 12:10:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-14 12:10:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-14 12:10:36 --> Helper loaded: atlant_helper
DEBUG - 2016-11-14 12:10:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:10:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-14 12:10:36 --> Helper loaded: crypto_helper
DEBUG - 2016-11-14 12:10:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:10:36 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-14 12:10:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-14 12:10:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-14 12:10:36 --> Helper loaded: sidika_helper
DEBUG - 2016-11-14 12:10:36 --> Database Driver Class Initialized
DEBUG - 2016-11-14 12:10:36 --> Session Class Initialized
DEBUG - 2016-11-14 12:10:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-14 12:10:36 --> Helper loaded: string_helper
DEBUG - 2016-11-14 12:10:36 --> Session routines successfully run
DEBUG - 2016-11-14 12:10:36 --> Native_session Class Initialized
DEBUG - 2016-11-14 12:10:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-14 12:10:36 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:10:36 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:10:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-14 12:10:36 --> Controller Class Initialized
DEBUG - 2016-11-14 12:10:36 --> Carabiner: Library initialized.
DEBUG - 2016-11-14 12:10:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-14 12:10:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-14 12:10:36 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:10:36 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:10:36 --> User Agent Class Initialized
DEBUG - 2016-11-14 12:10:36 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:36 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:36 --> Model Class Initialized
ERROR - 2016-11-14 12:10:37 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-11-14 12:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-11-14 12:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-11-14 12:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-14 12:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-14 12:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-14 12:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-14 12:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-14 12:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-11-14 12:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-11-14 12:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-14 12:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-14 12:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-14 12:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-14 12:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-14 12:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-14 12:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-14 12:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-11-14 12:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-11-14 12:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-14 12:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-14 12:10:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-11-14 12:10:37 --> Final output sent to browser
DEBUG - 2016-11-14 12:10:37 --> Total execution time: 0.9300
DEBUG - 2016-11-14 12:10:38 --> Config Class Initialized
DEBUG - 2016-11-14 12:10:38 --> Hooks Class Initialized
DEBUG - 2016-11-14 12:10:38 --> Utf8 Class Initialized
DEBUG - 2016-11-14 12:10:38 --> UTF-8 Support Enabled
DEBUG - 2016-11-14 12:10:38 --> URI Class Initialized
DEBUG - 2016-11-14 12:10:38 --> Router Class Initialized
DEBUG - 2016-11-14 12:10:38 --> Output Class Initialized
DEBUG - 2016-11-14 12:10:38 --> Cache file has expired. File deleted
DEBUG - 2016-11-14 12:10:38 --> Security Class Initialized
DEBUG - 2016-11-14 12:10:38 --> Input Class Initialized
DEBUG - 2016-11-14 12:10:38 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:38 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:38 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:38 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:38 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:38 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:38 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-14 12:10:38 --> Language Class Initialized
DEBUG - 2016-11-14 12:10:38 --> Loader Class Initialized
DEBUG - 2016-11-14 12:10:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-14 12:10:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-14 12:10:38 --> Helper loaded: url_helper
DEBUG - 2016-11-14 12:10:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-14 12:10:38 --> Helper loaded: file_helper
DEBUG - 2016-11-14 12:10:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:10:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-14 12:10:38 --> Helper loaded: conf_helper
DEBUG - 2016-11-14 12:10:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:10:38 --> Check Exists common_helper.php: No
DEBUG - 2016-11-14 12:10:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-14 12:10:38 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:10:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-14 12:10:38 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:10:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-14 12:10:38 --> Helper loaded: form_helper
DEBUG - 2016-11-14 12:10:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-14 12:10:38 --> Helper loaded: security_helper
DEBUG - 2016-11-14 12:10:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:10:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-14 12:10:38 --> Helper loaded: lang_helper
DEBUG - 2016-11-14 12:10:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:10:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-14 12:10:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-14 12:10:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-14 12:10:38 --> Helper loaded: atlant_helper
DEBUG - 2016-11-14 12:10:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:10:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-14 12:10:38 --> Helper loaded: crypto_helper
DEBUG - 2016-11-14 12:10:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:10:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-14 12:10:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-14 12:10:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-14 12:10:38 --> Helper loaded: sidika_helper
DEBUG - 2016-11-14 12:10:38 --> Database Driver Class Initialized
DEBUG - 2016-11-14 12:10:38 --> Session Class Initialized
DEBUG - 2016-11-14 12:10:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-14 12:10:38 --> Helper loaded: string_helper
DEBUG - 2016-11-14 12:10:38 --> Session routines successfully run
DEBUG - 2016-11-14 12:10:38 --> Native_session Class Initialized
DEBUG - 2016-11-14 12:10:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-14 12:10:38 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:10:38 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:10:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-14 12:10:38 --> Controller Class Initialized
DEBUG - 2016-11-14 12:10:38 --> Carabiner: Library initialized.
DEBUG - 2016-11-14 12:10:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-14 12:10:38 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-14 12:10:38 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:10:38 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:10:38 --> User Agent Class Initialized
DEBUG - 2016-11-14 12:10:38 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:38 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:38 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:38 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:38 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:38 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:38 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:39 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-11-14 12:10:39 --> Final output sent to browser
DEBUG - 2016-11-14 12:10:39 --> Total execution time: 1.4036
DEBUG - 2016-11-14 12:10:40 --> Config Class Initialized
DEBUG - 2016-11-14 12:10:40 --> Hooks Class Initialized
DEBUG - 2016-11-14 12:10:40 --> Utf8 Class Initialized
DEBUG - 2016-11-14 12:10:40 --> UTF-8 Support Enabled
DEBUG - 2016-11-14 12:10:40 --> URI Class Initialized
DEBUG - 2016-11-14 12:10:40 --> Router Class Initialized
DEBUG - 2016-11-14 12:10:40 --> Output Class Initialized
DEBUG - 2016-11-14 12:10:40 --> Cache file has expired. File deleted
DEBUG - 2016-11-14 12:10:40 --> Security Class Initialized
DEBUG - 2016-11-14 12:10:40 --> Input Class Initialized
DEBUG - 2016-11-14 12:10:40 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:40 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-14 12:10:40 --> Language Class Initialized
DEBUG - 2016-11-14 12:10:40 --> Loader Class Initialized
DEBUG - 2016-11-14 12:10:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-14 12:10:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-14 12:10:40 --> Helper loaded: url_helper
DEBUG - 2016-11-14 12:10:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-14 12:10:40 --> Helper loaded: file_helper
DEBUG - 2016-11-14 12:10:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:10:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-14 12:10:40 --> Helper loaded: conf_helper
DEBUG - 2016-11-14 12:10:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:10:40 --> Check Exists common_helper.php: No
DEBUG - 2016-11-14 12:10:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-14 12:10:41 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:10:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-14 12:10:41 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:10:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-14 12:10:41 --> Helper loaded: form_helper
DEBUG - 2016-11-14 12:10:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-14 12:10:41 --> Helper loaded: security_helper
DEBUG - 2016-11-14 12:10:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:10:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-14 12:10:41 --> Helper loaded: lang_helper
DEBUG - 2016-11-14 12:10:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:10:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-14 12:10:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-14 12:10:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-14 12:10:41 --> Helper loaded: atlant_helper
DEBUG - 2016-11-14 12:10:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:10:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-14 12:10:41 --> Helper loaded: crypto_helper
DEBUG - 2016-11-14 12:10:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:10:41 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-14 12:10:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-14 12:10:41 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-14 12:10:41 --> Helper loaded: sidika_helper
DEBUG - 2016-11-14 12:10:41 --> Database Driver Class Initialized
DEBUG - 2016-11-14 12:10:41 --> Session Class Initialized
DEBUG - 2016-11-14 12:10:41 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-14 12:10:41 --> Helper loaded: string_helper
DEBUG - 2016-11-14 12:10:41 --> Session routines successfully run
DEBUG - 2016-11-14 12:10:41 --> Native_session Class Initialized
DEBUG - 2016-11-14 12:10:41 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-14 12:10:41 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:10:41 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:10:41 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-14 12:10:41 --> Controller Class Initialized
DEBUG - 2016-11-14 12:10:41 --> Carabiner: Library initialized.
DEBUG - 2016-11-14 12:10:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-14 12:10:41 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-14 12:10:41 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:10:41 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:10:41 --> User Agent Class Initialized
DEBUG - 2016-11-14 12:10:41 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:41 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:41 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-11-14 12:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-14 12:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-14 12:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-14 12:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-14 12:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-14 12:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-14 12:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-14 12:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-14 12:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-14 12:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-14 12:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-14 12:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-14 12:10:41 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-11-14 12:10:41 --> Final output sent to browser
DEBUG - 2016-11-14 12:10:41 --> Total execution time: 0.2376
DEBUG - 2016-11-14 12:10:43 --> Config Class Initialized
DEBUG - 2016-11-14 12:10:43 --> Hooks Class Initialized
DEBUG - 2016-11-14 12:10:43 --> Utf8 Class Initialized
DEBUG - 2016-11-14 12:10:43 --> UTF-8 Support Enabled
DEBUG - 2016-11-14 12:10:43 --> URI Class Initialized
DEBUG - 2016-11-14 12:10:43 --> Router Class Initialized
DEBUG - 2016-11-14 12:10:43 --> Output Class Initialized
DEBUG - 2016-11-14 12:10:43 --> Security Class Initialized
DEBUG - 2016-11-14 12:10:43 --> Input Class Initialized
DEBUG - 2016-11-14 12:10:43 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:43 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-14 12:10:43 --> Language Class Initialized
DEBUG - 2016-11-14 12:10:43 --> Loader Class Initialized
DEBUG - 2016-11-14 12:10:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-14 12:10:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-14 12:10:43 --> Helper loaded: url_helper
DEBUG - 2016-11-14 12:10:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-14 12:10:43 --> Helper loaded: file_helper
DEBUG - 2016-11-14 12:10:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:10:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-14 12:10:43 --> Helper loaded: conf_helper
DEBUG - 2016-11-14 12:10:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:10:43 --> Check Exists common_helper.php: No
DEBUG - 2016-11-14 12:10:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-14 12:10:43 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:10:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-14 12:10:43 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:10:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-14 12:10:43 --> Helper loaded: form_helper
DEBUG - 2016-11-14 12:10:43 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-14 12:10:43 --> Helper loaded: security_helper
DEBUG - 2016-11-14 12:10:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:10:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-14 12:10:43 --> Helper loaded: lang_helper
DEBUG - 2016-11-14 12:10:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:10:43 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-14 12:10:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-14 12:10:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-14 12:10:43 --> Helper loaded: atlant_helper
DEBUG - 2016-11-14 12:10:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:10:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-14 12:10:43 --> Helper loaded: crypto_helper
DEBUG - 2016-11-14 12:10:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:10:43 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-14 12:10:43 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-14 12:10:43 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-14 12:10:43 --> Helper loaded: sidika_helper
DEBUG - 2016-11-14 12:10:43 --> Database Driver Class Initialized
DEBUG - 2016-11-14 12:10:43 --> Session Class Initialized
DEBUG - 2016-11-14 12:10:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-14 12:10:43 --> Helper loaded: string_helper
DEBUG - 2016-11-14 12:10:43 --> Session routines successfully run
DEBUG - 2016-11-14 12:10:43 --> Native_session Class Initialized
DEBUG - 2016-11-14 12:10:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-14 12:10:43 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:10:43 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:10:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-14 12:10:43 --> Controller Class Initialized
DEBUG - 2016-11-14 12:10:43 --> Carabiner: Library initialized.
DEBUG - 2016-11-14 12:10:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-14 12:10:43 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-14 12:10:43 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:10:43 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:10:43 --> User Agent Class Initialized
DEBUG - 2016-11-14 12:10:43 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:43 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:43 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:43 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:43 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:43 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:43 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:43 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-11-14 12:10:43 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-11-14 12:10:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-11-14 12:10:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-11-14 12:10:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-11-14 12:10:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-11-14 12:10:43 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-11-14 12:10:43 --> Final output sent to browser
DEBUG - 2016-11-14 12:10:43 --> Total execution time: 0.2272
DEBUG - 2016-11-14 12:10:43 --> Config Class Initialized
DEBUG - 2016-11-14 12:10:43 --> Hooks Class Initialized
DEBUG - 2016-11-14 12:10:43 --> Utf8 Class Initialized
DEBUG - 2016-11-14 12:10:43 --> UTF-8 Support Enabled
DEBUG - 2016-11-14 12:10:43 --> URI Class Initialized
DEBUG - 2016-11-14 12:10:43 --> Router Class Initialized
ERROR - 2016-11-14 12:10:43 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-11-14 12:10:48 --> Config Class Initialized
DEBUG - 2016-11-14 12:10:48 --> Hooks Class Initialized
DEBUG - 2016-11-14 12:10:48 --> Utf8 Class Initialized
DEBUG - 2016-11-14 12:10:48 --> UTF-8 Support Enabled
DEBUG - 2016-11-14 12:10:48 --> URI Class Initialized
DEBUG - 2016-11-14 12:10:48 --> Router Class Initialized
DEBUG - 2016-11-14 12:10:48 --> Output Class Initialized
DEBUG - 2016-11-14 12:10:48 --> Cache file has expired. File deleted
DEBUG - 2016-11-14 12:10:48 --> Security Class Initialized
DEBUG - 2016-11-14 12:10:48 --> Input Class Initialized
DEBUG - 2016-11-14 12:10:48 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:48 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:48 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:48 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-14 12:10:48 --> Language Class Initialized
DEBUG - 2016-11-14 12:10:48 --> Loader Class Initialized
DEBUG - 2016-11-14 12:10:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-14 12:10:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-14 12:10:48 --> Helper loaded: url_helper
DEBUG - 2016-11-14 12:10:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-14 12:10:48 --> Helper loaded: file_helper
DEBUG - 2016-11-14 12:10:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:10:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-14 12:10:48 --> Helper loaded: conf_helper
DEBUG - 2016-11-14 12:10:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:10:48 --> Check Exists common_helper.php: No
DEBUG - 2016-11-14 12:10:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-14 12:10:48 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:10:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-14 12:10:48 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:10:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-14 12:10:48 --> Helper loaded: form_helper
DEBUG - 2016-11-14 12:10:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-14 12:10:48 --> Helper loaded: security_helper
DEBUG - 2016-11-14 12:10:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:10:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-14 12:10:48 --> Helper loaded: lang_helper
DEBUG - 2016-11-14 12:10:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:10:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-14 12:10:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-14 12:10:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-14 12:10:48 --> Helper loaded: atlant_helper
DEBUG - 2016-11-14 12:10:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:10:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-14 12:10:48 --> Helper loaded: crypto_helper
DEBUG - 2016-11-14 12:10:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:10:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-14 12:10:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-14 12:10:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-14 12:10:48 --> Helper loaded: sidika_helper
DEBUG - 2016-11-14 12:10:48 --> Database Driver Class Initialized
DEBUG - 2016-11-14 12:10:48 --> Session Class Initialized
DEBUG - 2016-11-14 12:10:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-14 12:10:48 --> Helper loaded: string_helper
DEBUG - 2016-11-14 12:10:48 --> Session routines successfully run
DEBUG - 2016-11-14 12:10:48 --> Native_session Class Initialized
DEBUG - 2016-11-14 12:10:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-14 12:10:48 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:10:48 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:10:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-14 12:10:48 --> Controller Class Initialized
DEBUG - 2016-11-14 12:10:48 --> Carabiner: Library initialized.
DEBUG - 2016-11-14 12:10:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-14 12:10:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-14 12:10:48 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:10:48 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:10:48 --> User Agent Class Initialized
DEBUG - 2016-11-14 12:10:48 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:48 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:48 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:48 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:48 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:48 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:48 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-11-14 12:10:48 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:10:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-14 12:10:48 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-11-14 12:10:49 --> Config Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Hooks Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Utf8 Class Initialized
DEBUG - 2016-11-14 12:10:49 --> UTF-8 Support Enabled
DEBUG - 2016-11-14 12:10:49 --> URI Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Router Class Initialized
DEBUG - 2016-11-14 12:10:49 --> No URI present. Default controller set.
DEBUG - 2016-11-14 12:10:49 --> Output Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Cache file has expired. File deleted
DEBUG - 2016-11-14 12:10:49 --> Security Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Input Class Initialized
DEBUG - 2016-11-14 12:10:49 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:49 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-14 12:10:49 --> Language Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Loader Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-14 12:10:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-14 12:10:49 --> Helper loaded: url_helper
DEBUG - 2016-11-14 12:10:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-14 12:10:49 --> Helper loaded: file_helper
DEBUG - 2016-11-14 12:10:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:10:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-14 12:10:49 --> Helper loaded: conf_helper
DEBUG - 2016-11-14 12:10:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:10:49 --> Check Exists common_helper.php: No
DEBUG - 2016-11-14 12:10:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-14 12:10:49 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:10:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-14 12:10:49 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:10:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-14 12:10:49 --> Helper loaded: form_helper
DEBUG - 2016-11-14 12:10:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-14 12:10:49 --> Helper loaded: security_helper
DEBUG - 2016-11-14 12:10:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:10:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-14 12:10:49 --> Helper loaded: lang_helper
DEBUG - 2016-11-14 12:10:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:10:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-14 12:10:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-14 12:10:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-14 12:10:49 --> Helper loaded: atlant_helper
DEBUG - 2016-11-14 12:10:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:10:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-14 12:10:49 --> Helper loaded: crypto_helper
DEBUG - 2016-11-14 12:10:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:10:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-14 12:10:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-14 12:10:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-14 12:10:49 --> Helper loaded: sidika_helper
DEBUG - 2016-11-14 12:10:49 --> Database Driver Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Session Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-14 12:10:49 --> Helper loaded: string_helper
DEBUG - 2016-11-14 12:10:49 --> Session routines successfully run
DEBUG - 2016-11-14 12:10:49 --> Native_session Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-14 12:10:49 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-14 12:10:49 --> Controller Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Carabiner: Library initialized.
DEBUG - 2016-11-14 12:10:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-14 12:10:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-14 12:10:49 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:10:49 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:10:49 --> User Agent Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Model Class Initialized
ERROR - 2016-11-14 12:10:49 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-11-14 12:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-11-14 12:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-11-14 12:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-14 12:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-14 12:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-14 12:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-14 12:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-14 12:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-11-14 12:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-11-14 12:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-14 12:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-14 12:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-14 12:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-14 12:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-14 12:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-14 12:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-14 12:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-11-14 12:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-11-14 12:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-14 12:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-14 12:10:49 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-11-14 12:10:49 --> Final output sent to browser
DEBUG - 2016-11-14 12:10:49 --> Total execution time: 0.2685
DEBUG - 2016-11-14 12:10:49 --> Config Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Hooks Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Utf8 Class Initialized
DEBUG - 2016-11-14 12:10:49 --> UTF-8 Support Enabled
DEBUG - 2016-11-14 12:10:49 --> URI Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Router Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Output Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Cache file has expired. File deleted
DEBUG - 2016-11-14 12:10:49 --> Security Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Input Class Initialized
DEBUG - 2016-11-14 12:10:49 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:49 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:49 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:49 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:49 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:49 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:49 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-14 12:10:49 --> Language Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Loader Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-14 12:10:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-14 12:10:49 --> Helper loaded: url_helper
DEBUG - 2016-11-14 12:10:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-14 12:10:49 --> Helper loaded: file_helper
DEBUG - 2016-11-14 12:10:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:10:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-14 12:10:49 --> Helper loaded: conf_helper
DEBUG - 2016-11-14 12:10:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:10:49 --> Check Exists common_helper.php: No
DEBUG - 2016-11-14 12:10:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-14 12:10:49 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:10:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-14 12:10:49 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:10:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-14 12:10:49 --> Helper loaded: form_helper
DEBUG - 2016-11-14 12:10:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-14 12:10:49 --> Helper loaded: security_helper
DEBUG - 2016-11-14 12:10:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:10:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-14 12:10:49 --> Helper loaded: lang_helper
DEBUG - 2016-11-14 12:10:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:10:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-14 12:10:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-14 12:10:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-14 12:10:49 --> Helper loaded: atlant_helper
DEBUG - 2016-11-14 12:10:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:10:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-14 12:10:49 --> Helper loaded: crypto_helper
DEBUG - 2016-11-14 12:10:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:10:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-14 12:10:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-14 12:10:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-14 12:10:49 --> Helper loaded: sidika_helper
DEBUG - 2016-11-14 12:10:49 --> Database Driver Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Session Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-14 12:10:49 --> Helper loaded: string_helper
DEBUG - 2016-11-14 12:10:49 --> Session routines successfully run
DEBUG - 2016-11-14 12:10:49 --> Native_session Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-14 12:10:49 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-14 12:10:49 --> Controller Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Carabiner: Library initialized.
DEBUG - 2016-11-14 12:10:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-14 12:10:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-14 12:10:49 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:10:49 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:10:49 --> User Agent Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:49 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:50 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:50 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:50 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:50 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:50 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-11-14 12:10:50 --> Final output sent to browser
DEBUG - 2016-11-14 12:10:50 --> Total execution time: 0.3135
DEBUG - 2016-11-14 12:10:51 --> Config Class Initialized
DEBUG - 2016-11-14 12:10:51 --> Hooks Class Initialized
DEBUG - 2016-11-14 12:10:51 --> Utf8 Class Initialized
DEBUG - 2016-11-14 12:10:51 --> UTF-8 Support Enabled
DEBUG - 2016-11-14 12:10:51 --> URI Class Initialized
DEBUG - 2016-11-14 12:10:51 --> Router Class Initialized
DEBUG - 2016-11-14 12:10:51 --> Output Class Initialized
DEBUG - 2016-11-14 12:10:51 --> Cache file has expired. File deleted
DEBUG - 2016-11-14 12:10:51 --> Security Class Initialized
DEBUG - 2016-11-14 12:10:51 --> Input Class Initialized
DEBUG - 2016-11-14 12:10:51 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:51 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-14 12:10:51 --> Language Class Initialized
DEBUG - 2016-11-14 12:10:51 --> Loader Class Initialized
DEBUG - 2016-11-14 12:10:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-14 12:10:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-14 12:10:51 --> Helper loaded: url_helper
DEBUG - 2016-11-14 12:10:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-14 12:10:51 --> Helper loaded: file_helper
DEBUG - 2016-11-14 12:10:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:10:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-14 12:10:51 --> Helper loaded: conf_helper
DEBUG - 2016-11-14 12:10:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:10:51 --> Check Exists common_helper.php: No
DEBUG - 2016-11-14 12:10:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-14 12:10:51 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:10:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-14 12:10:51 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:10:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-14 12:10:51 --> Helper loaded: form_helper
DEBUG - 2016-11-14 12:10:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-14 12:10:51 --> Helper loaded: security_helper
DEBUG - 2016-11-14 12:10:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:10:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-14 12:10:51 --> Helper loaded: lang_helper
DEBUG - 2016-11-14 12:10:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:10:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-14 12:10:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-14 12:10:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-14 12:10:51 --> Helper loaded: atlant_helper
DEBUG - 2016-11-14 12:10:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:10:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-14 12:10:51 --> Helper loaded: crypto_helper
DEBUG - 2016-11-14 12:10:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:10:51 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-14 12:10:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-14 12:10:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-14 12:10:51 --> Helper loaded: sidika_helper
DEBUG - 2016-11-14 12:10:51 --> Database Driver Class Initialized
DEBUG - 2016-11-14 12:10:51 --> Session Class Initialized
DEBUG - 2016-11-14 12:10:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-14 12:10:51 --> Helper loaded: string_helper
DEBUG - 2016-11-14 12:10:51 --> Session routines successfully run
DEBUG - 2016-11-14 12:10:51 --> Native_session Class Initialized
DEBUG - 2016-11-14 12:10:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-14 12:10:51 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:10:51 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:10:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-14 12:10:51 --> Controller Class Initialized
DEBUG - 2016-11-14 12:10:51 --> Carabiner: Library initialized.
DEBUG - 2016-11-14 12:10:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-14 12:10:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-14 12:10:51 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:10:51 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:10:51 --> User Agent Class Initialized
DEBUG - 2016-11-14 12:10:51 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:51 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:51 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-11-14 12:10:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-14 12:10:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-14 12:10:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-14 12:10:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-14 12:10:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-14 12:10:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-14 12:10:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-14 12:10:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-14 12:10:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-14 12:10:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-14 12:10:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-14 12:10:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-14 12:10:51 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-11-14 12:10:51 --> Final output sent to browser
DEBUG - 2016-11-14 12:10:51 --> Total execution time: 0.2825
DEBUG - 2016-11-14 12:10:53 --> Config Class Initialized
DEBUG - 2016-11-14 12:10:53 --> Hooks Class Initialized
DEBUG - 2016-11-14 12:10:53 --> Utf8 Class Initialized
DEBUG - 2016-11-14 12:10:53 --> UTF-8 Support Enabled
DEBUG - 2016-11-14 12:10:53 --> URI Class Initialized
DEBUG - 2016-11-14 12:10:53 --> Router Class Initialized
DEBUG - 2016-11-14 12:10:53 --> Output Class Initialized
DEBUG - 2016-11-14 12:10:53 --> Cache file has expired. File deleted
DEBUG - 2016-11-14 12:10:53 --> Security Class Initialized
DEBUG - 2016-11-14 12:10:53 --> Input Class Initialized
DEBUG - 2016-11-14 12:10:53 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:53 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-14 12:10:53 --> Language Class Initialized
DEBUG - 2016-11-14 12:10:53 --> Loader Class Initialized
DEBUG - 2016-11-14 12:10:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-14 12:10:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-14 12:10:53 --> Helper loaded: url_helper
DEBUG - 2016-11-14 12:10:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-14 12:10:53 --> Helper loaded: file_helper
DEBUG - 2016-11-14 12:10:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:10:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-14 12:10:53 --> Helper loaded: conf_helper
DEBUG - 2016-11-14 12:10:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:10:53 --> Check Exists common_helper.php: No
DEBUG - 2016-11-14 12:10:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-14 12:10:53 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:10:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-14 12:10:53 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:10:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-14 12:10:53 --> Helper loaded: form_helper
DEBUG - 2016-11-14 12:10:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-14 12:10:53 --> Helper loaded: security_helper
DEBUG - 2016-11-14 12:10:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:10:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-14 12:10:53 --> Helper loaded: lang_helper
DEBUG - 2016-11-14 12:10:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:10:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-14 12:10:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-14 12:10:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-14 12:10:53 --> Helper loaded: atlant_helper
DEBUG - 2016-11-14 12:10:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:10:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-14 12:10:53 --> Helper loaded: crypto_helper
DEBUG - 2016-11-14 12:10:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:10:53 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-14 12:10:53 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-14 12:10:53 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-14 12:10:53 --> Helper loaded: sidika_helper
DEBUG - 2016-11-14 12:10:53 --> Database Driver Class Initialized
DEBUG - 2016-11-14 12:10:53 --> Session Class Initialized
DEBUG - 2016-11-14 12:10:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-14 12:10:53 --> Helper loaded: string_helper
DEBUG - 2016-11-14 12:10:53 --> Session routines successfully run
DEBUG - 2016-11-14 12:10:53 --> Native_session Class Initialized
DEBUG - 2016-11-14 12:10:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-14 12:10:53 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:10:53 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:10:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-14 12:10:53 --> Controller Class Initialized
DEBUG - 2016-11-14 12:10:53 --> Carabiner: Library initialized.
DEBUG - 2016-11-14 12:10:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-14 12:10:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-14 12:10:53 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:10:53 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:10:53 --> User Agent Class Initialized
DEBUG - 2016-11-14 12:10:53 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:53 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:53 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:53 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:53 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-11-14 12:10:53 --> Pagination Class Initialized
DEBUG - 2016-11-14 12:10:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-14 12:10:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_golongan/index.php
DEBUG - 2016-11-14 12:10:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-14 12:10:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-14 12:10:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-14 12:10:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-14 12:10:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_golongan/js/index_js.php
DEBUG - 2016-11-14 12:10:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-14 12:10:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-14 12:10:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-14 12:10:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-14 12:10:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-14 12:10:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-14 12:10:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_golongan/js/index_js.php
DEBUG - 2016-11-14 12:10:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-14 12:10:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-14 12:10:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0a9f345e7377389319d1a253f860e8a1
DEBUG - 2016-11-14 12:10:54 --> Final output sent to browser
DEBUG - 2016-11-14 12:10:54 --> Total execution time: 0.3720
DEBUG - 2016-11-14 12:10:55 --> Config Class Initialized
DEBUG - 2016-11-14 12:10:55 --> Hooks Class Initialized
DEBUG - 2016-11-14 12:10:55 --> Utf8 Class Initialized
DEBUG - 2016-11-14 12:10:55 --> UTF-8 Support Enabled
DEBUG - 2016-11-14 12:10:55 --> URI Class Initialized
DEBUG - 2016-11-14 12:10:55 --> Router Class Initialized
DEBUG - 2016-11-14 12:10:55 --> Output Class Initialized
DEBUG - 2016-11-14 12:10:55 --> Security Class Initialized
DEBUG - 2016-11-14 12:10:55 --> Input Class Initialized
DEBUG - 2016-11-14 12:10:55 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:55 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-14 12:10:55 --> Language Class Initialized
DEBUG - 2016-11-14 12:10:55 --> Loader Class Initialized
DEBUG - 2016-11-14 12:10:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-14 12:10:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-14 12:10:55 --> Helper loaded: url_helper
DEBUG - 2016-11-14 12:10:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-14 12:10:55 --> Helper loaded: file_helper
DEBUG - 2016-11-14 12:10:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:10:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-14 12:10:55 --> Helper loaded: conf_helper
DEBUG - 2016-11-14 12:10:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:10:55 --> Check Exists common_helper.php: No
DEBUG - 2016-11-14 12:10:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-14 12:10:55 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:10:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-14 12:10:55 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:10:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-14 12:10:55 --> Helper loaded: form_helper
DEBUG - 2016-11-14 12:10:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-14 12:10:55 --> Helper loaded: security_helper
DEBUG - 2016-11-14 12:10:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:10:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-14 12:10:55 --> Helper loaded: lang_helper
DEBUG - 2016-11-14 12:10:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:10:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-14 12:10:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-14 12:10:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-14 12:10:55 --> Helper loaded: atlant_helper
DEBUG - 2016-11-14 12:10:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:10:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-14 12:10:55 --> Helper loaded: crypto_helper
DEBUG - 2016-11-14 12:10:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:10:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-14 12:10:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-14 12:10:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-14 12:10:55 --> Helper loaded: sidika_helper
DEBUG - 2016-11-14 12:10:55 --> Database Driver Class Initialized
DEBUG - 2016-11-14 12:10:55 --> Session Class Initialized
DEBUG - 2016-11-14 12:10:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-14 12:10:55 --> Helper loaded: string_helper
DEBUG - 2016-11-14 12:10:55 --> Session routines successfully run
DEBUG - 2016-11-14 12:10:55 --> Native_session Class Initialized
DEBUG - 2016-11-14 12:10:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-14 12:10:55 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:10:55 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:10:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-14 12:10:55 --> Controller Class Initialized
DEBUG - 2016-11-14 12:10:55 --> Carabiner: Library initialized.
DEBUG - 2016-11-14 12:10:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-14 12:10:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-14 12:10:55 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:10:55 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:10:55 --> User Agent Class Initialized
DEBUG - 2016-11-14 12:10:55 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:55 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:55 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:55 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:55 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-14 12:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_golongan/detail.php
DEBUG - 2016-11-14 12:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-14 12:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-14 12:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-14 12:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-14 12:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-14 12:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-14 12:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-14 12:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-14 12:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-14 12:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-14 12:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-14 12:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-14 12:10:55 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/f0014d2c34620cb3bf77e34971619444
DEBUG - 2016-11-14 12:10:55 --> Final output sent to browser
DEBUG - 2016-11-14 12:10:55 --> Total execution time: 0.3360
DEBUG - 2016-11-14 12:10:59 --> Config Class Initialized
DEBUG - 2016-11-14 12:10:59 --> Hooks Class Initialized
DEBUG - 2016-11-14 12:10:59 --> Utf8 Class Initialized
DEBUG - 2016-11-14 12:10:59 --> UTF-8 Support Enabled
DEBUG - 2016-11-14 12:10:59 --> URI Class Initialized
DEBUG - 2016-11-14 12:10:59 --> Router Class Initialized
DEBUG - 2016-11-14 12:10:59 --> Output Class Initialized
DEBUG - 2016-11-14 12:10:59 --> Cache file has expired. File deleted
DEBUG - 2016-11-14 12:10:59 --> Security Class Initialized
DEBUG - 2016-11-14 12:10:59 --> Input Class Initialized
DEBUG - 2016-11-14 12:10:59 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:59 --> XSS Filtering completed
DEBUG - 2016-11-14 12:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-14 12:10:59 --> Language Class Initialized
DEBUG - 2016-11-14 12:10:59 --> Loader Class Initialized
DEBUG - 2016-11-14 12:10:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-14 12:10:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-14 12:10:59 --> Helper loaded: url_helper
DEBUG - 2016-11-14 12:10:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-14 12:10:59 --> Helper loaded: file_helper
DEBUG - 2016-11-14 12:10:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:10:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-14 12:10:59 --> Helper loaded: conf_helper
DEBUG - 2016-11-14 12:10:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:10:59 --> Check Exists common_helper.php: No
DEBUG - 2016-11-14 12:10:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-14 12:10:59 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:10:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-14 12:10:59 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:10:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-14 12:10:59 --> Helper loaded: form_helper
DEBUG - 2016-11-14 12:10:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-14 12:10:59 --> Helper loaded: security_helper
DEBUG - 2016-11-14 12:10:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:10:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-14 12:10:59 --> Helper loaded: lang_helper
DEBUG - 2016-11-14 12:10:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:10:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-14 12:10:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-14 12:10:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-14 12:10:59 --> Helper loaded: atlant_helper
DEBUG - 2016-11-14 12:10:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:10:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-14 12:10:59 --> Helper loaded: crypto_helper
DEBUG - 2016-11-14 12:10:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:10:59 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-14 12:10:59 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-14 12:10:59 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-14 12:10:59 --> Helper loaded: sidika_helper
DEBUG - 2016-11-14 12:10:59 --> Database Driver Class Initialized
DEBUG - 2016-11-14 12:10:59 --> Session Class Initialized
DEBUG - 2016-11-14 12:10:59 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-14 12:10:59 --> Helper loaded: string_helper
DEBUG - 2016-11-14 12:10:59 --> Session routines successfully run
DEBUG - 2016-11-14 12:10:59 --> Native_session Class Initialized
DEBUG - 2016-11-14 12:10:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-14 12:10:59 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:10:59 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:10:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-14 12:10:59 --> Controller Class Initialized
DEBUG - 2016-11-14 12:10:59 --> Carabiner: Library initialized.
DEBUG - 2016-11-14 12:10:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-14 12:10:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-14 12:10:59 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:10:59 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:10:59 --> User Agent Class Initialized
DEBUG - 2016-11-14 12:10:59 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:59 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:59 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:59 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:59 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:59 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:59 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:59 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:59 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:59 --> Model Class Initialized
DEBUG - 2016-11-14 12:10:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-11-14 12:10:59 --> Pagination Class Initialized
DEBUG - 2016-11-14 12:10:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-14 12:10:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-11-14 12:10:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-14 12:10:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-14 12:10:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-14 12:10:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-14 12:10:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-11-14 12:10:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-14 12:10:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-14 12:10:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-14 12:10:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-14 12:10:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-14 12:10:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-14 12:10:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-11-14 12:10:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-14 12:10:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-14 12:10:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-11-14 12:10:59 --> Final output sent to browser
DEBUG - 2016-11-14 12:10:59 --> Total execution time: 0.5805
DEBUG - 2016-11-14 12:11:01 --> Config Class Initialized
DEBUG - 2016-11-14 12:11:01 --> Hooks Class Initialized
DEBUG - 2016-11-14 12:11:01 --> Utf8 Class Initialized
DEBUG - 2016-11-14 12:11:01 --> UTF-8 Support Enabled
DEBUG - 2016-11-14 12:11:01 --> URI Class Initialized
DEBUG - 2016-11-14 12:11:01 --> Router Class Initialized
DEBUG - 2016-11-14 12:11:01 --> Output Class Initialized
DEBUG - 2016-11-14 12:11:01 --> Cache file has expired. File deleted
DEBUG - 2016-11-14 12:11:01 --> Security Class Initialized
DEBUG - 2016-11-14 12:11:01 --> Input Class Initialized
DEBUG - 2016-11-14 12:11:01 --> XSS Filtering completed
DEBUG - 2016-11-14 12:11:01 --> XSS Filtering completed
DEBUG - 2016-11-14 12:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-14 12:11:01 --> Language Class Initialized
DEBUG - 2016-11-14 12:11:01 --> Loader Class Initialized
DEBUG - 2016-11-14 12:11:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-14 12:11:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-14 12:11:01 --> Helper loaded: url_helper
DEBUG - 2016-11-14 12:11:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-14 12:11:01 --> Helper loaded: file_helper
DEBUG - 2016-11-14 12:11:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:11:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-14 12:11:01 --> Helper loaded: conf_helper
DEBUG - 2016-11-14 12:11:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:11:01 --> Check Exists common_helper.php: No
DEBUG - 2016-11-14 12:11:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-14 12:11:01 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:11:01 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-14 12:11:01 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:11:01 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-14 12:11:01 --> Helper loaded: form_helper
DEBUG - 2016-11-14 12:11:01 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-14 12:11:01 --> Helper loaded: security_helper
DEBUG - 2016-11-14 12:11:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:11:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-14 12:11:01 --> Helper loaded: lang_helper
DEBUG - 2016-11-14 12:11:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:11:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-14 12:11:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-14 12:11:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-14 12:11:01 --> Helper loaded: atlant_helper
DEBUG - 2016-11-14 12:11:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:11:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-14 12:11:01 --> Helper loaded: crypto_helper
DEBUG - 2016-11-14 12:11:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:11:01 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-14 12:11:01 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-14 12:11:01 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-14 12:11:01 --> Helper loaded: sidika_helper
DEBUG - 2016-11-14 12:11:01 --> Database Driver Class Initialized
DEBUG - 2016-11-14 12:11:01 --> Session Class Initialized
DEBUG - 2016-11-14 12:11:01 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-14 12:11:01 --> Helper loaded: string_helper
DEBUG - 2016-11-14 12:11:01 --> Session routines successfully run
DEBUG - 2016-11-14 12:11:01 --> Native_session Class Initialized
DEBUG - 2016-11-14 12:11:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-14 12:11:01 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:11:01 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:11:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-14 12:11:01 --> Controller Class Initialized
DEBUG - 2016-11-14 12:11:01 --> Carabiner: Library initialized.
DEBUG - 2016-11-14 12:11:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-14 12:11:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-14 12:11:01 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:11:01 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:11:01 --> User Agent Class Initialized
DEBUG - 2016-11-14 12:11:01 --> Model Class Initialized
DEBUG - 2016-11-14 12:11:01 --> Model Class Initialized
DEBUG - 2016-11-14 12:11:01 --> Model Class Initialized
DEBUG - 2016-11-14 12:11:01 --> Model Class Initialized
DEBUG - 2016-11-14 12:11:01 --> Model Class Initialized
DEBUG - 2016-11-14 12:11:01 --> Model Class Initialized
DEBUG - 2016-11-14 12:11:01 --> Model Class Initialized
DEBUG - 2016-11-14 12:11:01 --> Model Class Initialized
DEBUG - 2016-11-14 12:11:01 --> Model Class Initialized
DEBUG - 2016-11-14 12:11:01 --> Model Class Initialized
DEBUG - 2016-11-14 12:11:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-11-14 12:11:01 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:11:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-14 12:11:01 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-14 12:11:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-14 12:11:01 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8f8e2926e3f1cbfc3aa536b43cdd0626
DEBUG - 2016-11-14 12:11:01 --> Final output sent to browser
DEBUG - 2016-11-14 12:11:01 --> Total execution time: 0.5377
DEBUG - 2016-11-14 12:30:34 --> Config Class Initialized
DEBUG - 2016-11-14 12:30:34 --> Hooks Class Initialized
DEBUG - 2016-11-14 12:30:34 --> Utf8 Class Initialized
DEBUG - 2016-11-14 12:30:34 --> UTF-8 Support Enabled
DEBUG - 2016-11-14 12:30:34 --> URI Class Initialized
DEBUG - 2016-11-14 12:30:34 --> Router Class Initialized
DEBUG - 2016-11-14 12:30:34 --> No URI present. Default controller set.
DEBUG - 2016-11-14 12:30:34 --> Output Class Initialized
DEBUG - 2016-11-14 12:30:34 --> Cache file has expired. File deleted
DEBUG - 2016-11-14 12:30:34 --> Security Class Initialized
DEBUG - 2016-11-14 12:30:34 --> Input Class Initialized
DEBUG - 2016-11-14 12:30:34 --> XSS Filtering completed
DEBUG - 2016-11-14 12:30:34 --> XSS Filtering completed
DEBUG - 2016-11-14 12:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-14 12:30:34 --> Language Class Initialized
DEBUG - 2016-11-14 12:30:34 --> Loader Class Initialized
DEBUG - 2016-11-14 12:30:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-14 12:30:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-14 12:30:34 --> Helper loaded: url_helper
DEBUG - 2016-11-14 12:30:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-14 12:30:34 --> Helper loaded: file_helper
DEBUG - 2016-11-14 12:30:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:30:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-14 12:30:34 --> Helper loaded: conf_helper
DEBUG - 2016-11-14 12:30:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:30:34 --> Check Exists common_helper.php: No
DEBUG - 2016-11-14 12:30:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-14 12:30:34 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:30:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-14 12:30:34 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:30:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-14 12:30:34 --> Helper loaded: form_helper
DEBUG - 2016-11-14 12:30:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-14 12:30:34 --> Helper loaded: security_helper
DEBUG - 2016-11-14 12:30:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:30:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-14 12:30:34 --> Helper loaded: lang_helper
DEBUG - 2016-11-14 12:30:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:30:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-14 12:30:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-14 12:30:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-14 12:30:34 --> Helper loaded: atlant_helper
DEBUG - 2016-11-14 12:30:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:30:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-14 12:30:34 --> Helper loaded: crypto_helper
DEBUG - 2016-11-14 12:30:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:30:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-14 12:30:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-14 12:30:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-14 12:30:34 --> Helper loaded: sidika_helper
DEBUG - 2016-11-14 12:30:34 --> Database Driver Class Initialized
DEBUG - 2016-11-14 12:30:34 --> Session Class Initialized
DEBUG - 2016-11-14 12:30:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-14 12:30:34 --> Helper loaded: string_helper
DEBUG - 2016-11-14 12:30:34 --> Session routines successfully run
DEBUG - 2016-11-14 12:30:34 --> Native_session Class Initialized
DEBUG - 2016-11-14 12:30:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-14 12:30:34 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:30:34 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:30:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-14 12:30:34 --> Controller Class Initialized
DEBUG - 2016-11-14 12:30:34 --> Carabiner: Library initialized.
DEBUG - 2016-11-14 12:30:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-14 12:30:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-14 12:30:34 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:30:34 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:30:34 --> User Agent Class Initialized
DEBUG - 2016-11-14 12:30:34 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:34 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:34 --> Model Class Initialized
ERROR - 2016-11-14 12:30:34 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-11-14 12:30:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-11-14 12:30:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-11-14 12:30:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-14 12:30:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-14 12:30:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-14 12:30:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-14 12:30:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-14 12:30:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-11-14 12:30:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-11-14 12:30:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-14 12:30:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-14 12:30:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-14 12:30:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-14 12:30:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-14 12:30:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-14 12:30:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-14 12:30:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-11-14 12:30:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-11-14 12:30:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-14 12:30:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-14 12:30:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-11-14 12:30:34 --> Final output sent to browser
DEBUG - 2016-11-14 12:30:34 --> Total execution time: 0.4214
DEBUG - 2016-11-14 12:30:34 --> Config Class Initialized
DEBUG - 2016-11-14 12:30:34 --> Hooks Class Initialized
DEBUG - 2016-11-14 12:30:34 --> Utf8 Class Initialized
DEBUG - 2016-11-14 12:30:35 --> UTF-8 Support Enabled
DEBUG - 2016-11-14 12:30:35 --> URI Class Initialized
DEBUG - 2016-11-14 12:30:35 --> Router Class Initialized
DEBUG - 2016-11-14 12:30:35 --> Output Class Initialized
DEBUG - 2016-11-14 12:30:35 --> Cache file has expired. File deleted
DEBUG - 2016-11-14 12:30:35 --> Security Class Initialized
DEBUG - 2016-11-14 12:30:35 --> Input Class Initialized
DEBUG - 2016-11-14 12:30:35 --> XSS Filtering completed
DEBUG - 2016-11-14 12:30:35 --> XSS Filtering completed
DEBUG - 2016-11-14 12:30:35 --> XSS Filtering completed
DEBUG - 2016-11-14 12:30:35 --> XSS Filtering completed
DEBUG - 2016-11-14 12:30:35 --> XSS Filtering completed
DEBUG - 2016-11-14 12:30:35 --> XSS Filtering completed
DEBUG - 2016-11-14 12:30:35 --> XSS Filtering completed
DEBUG - 2016-11-14 12:30:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-14 12:30:35 --> Language Class Initialized
DEBUG - 2016-11-14 12:30:35 --> Loader Class Initialized
DEBUG - 2016-11-14 12:30:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-14 12:30:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-14 12:30:35 --> Helper loaded: url_helper
DEBUG - 2016-11-14 12:30:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-14 12:30:35 --> Helper loaded: file_helper
DEBUG - 2016-11-14 12:30:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:30:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-14 12:30:35 --> Helper loaded: conf_helper
DEBUG - 2016-11-14 12:30:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:30:35 --> Check Exists common_helper.php: No
DEBUG - 2016-11-14 12:30:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-14 12:30:35 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:30:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-14 12:30:35 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:30:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-14 12:30:35 --> Helper loaded: form_helper
DEBUG - 2016-11-14 12:30:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-14 12:30:35 --> Helper loaded: security_helper
DEBUG - 2016-11-14 12:30:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:30:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-14 12:30:35 --> Helper loaded: lang_helper
DEBUG - 2016-11-14 12:30:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:30:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-14 12:30:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-14 12:30:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-14 12:30:35 --> Helper loaded: atlant_helper
DEBUG - 2016-11-14 12:30:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:30:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-14 12:30:35 --> Helper loaded: crypto_helper
DEBUG - 2016-11-14 12:30:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:30:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-14 12:30:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-14 12:30:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-14 12:30:35 --> Helper loaded: sidika_helper
DEBUG - 2016-11-14 12:30:35 --> Database Driver Class Initialized
DEBUG - 2016-11-14 12:30:35 --> Session Class Initialized
DEBUG - 2016-11-14 12:30:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-14 12:30:35 --> Helper loaded: string_helper
DEBUG - 2016-11-14 12:30:35 --> Session routines successfully run
DEBUG - 2016-11-14 12:30:35 --> Native_session Class Initialized
DEBUG - 2016-11-14 12:30:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-14 12:30:35 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:30:35 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:30:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-14 12:30:35 --> Controller Class Initialized
DEBUG - 2016-11-14 12:30:35 --> Carabiner: Library initialized.
DEBUG - 2016-11-14 12:30:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-14 12:30:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-14 12:30:35 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:30:35 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:30:35 --> User Agent Class Initialized
DEBUG - 2016-11-14 12:30:35 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:35 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:35 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:35 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:35 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:35 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:35 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:35 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-11-14 12:30:35 --> Final output sent to browser
DEBUG - 2016-11-14 12:30:35 --> Total execution time: 0.5071
DEBUG - 2016-11-14 12:30:36 --> Config Class Initialized
DEBUG - 2016-11-14 12:30:36 --> Hooks Class Initialized
DEBUG - 2016-11-14 12:30:36 --> Utf8 Class Initialized
DEBUG - 2016-11-14 12:30:36 --> UTF-8 Support Enabled
DEBUG - 2016-11-14 12:30:36 --> URI Class Initialized
DEBUG - 2016-11-14 12:30:36 --> Router Class Initialized
DEBUG - 2016-11-14 12:30:36 --> No URI present. Default controller set.
DEBUG - 2016-11-14 12:30:36 --> Output Class Initialized
DEBUG - 2016-11-14 12:30:36 --> Cache file has expired. File deleted
DEBUG - 2016-11-14 12:30:36 --> Security Class Initialized
DEBUG - 2016-11-14 12:30:36 --> Input Class Initialized
DEBUG - 2016-11-14 12:30:36 --> XSS Filtering completed
DEBUG - 2016-11-14 12:30:36 --> XSS Filtering completed
DEBUG - 2016-11-14 12:30:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-14 12:30:36 --> Language Class Initialized
DEBUG - 2016-11-14 12:30:36 --> Loader Class Initialized
DEBUG - 2016-11-14 12:30:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-14 12:30:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-14 12:30:36 --> Helper loaded: url_helper
DEBUG - 2016-11-14 12:30:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-14 12:30:36 --> Helper loaded: file_helper
DEBUG - 2016-11-14 12:30:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:30:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-14 12:30:36 --> Helper loaded: conf_helper
DEBUG - 2016-11-14 12:30:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:30:36 --> Check Exists common_helper.php: No
DEBUG - 2016-11-14 12:30:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-14 12:30:36 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:30:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-14 12:30:36 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:30:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-14 12:30:36 --> Helper loaded: form_helper
DEBUG - 2016-11-14 12:30:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-14 12:30:36 --> Helper loaded: security_helper
DEBUG - 2016-11-14 12:30:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:30:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-14 12:30:36 --> Helper loaded: lang_helper
DEBUG - 2016-11-14 12:30:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:30:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-14 12:30:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-14 12:30:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-14 12:30:36 --> Helper loaded: atlant_helper
DEBUG - 2016-11-14 12:30:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:30:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-14 12:30:36 --> Helper loaded: crypto_helper
DEBUG - 2016-11-14 12:30:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:30:36 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-14 12:30:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-14 12:30:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-14 12:30:36 --> Helper loaded: sidika_helper
DEBUG - 2016-11-14 12:30:36 --> Database Driver Class Initialized
DEBUG - 2016-11-14 12:30:36 --> Session Class Initialized
DEBUG - 2016-11-14 12:30:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-14 12:30:36 --> Helper loaded: string_helper
DEBUG - 2016-11-14 12:30:36 --> Session routines successfully run
DEBUG - 2016-11-14 12:30:36 --> Native_session Class Initialized
DEBUG - 2016-11-14 12:30:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-14 12:30:36 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:30:36 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:30:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-14 12:30:36 --> Controller Class Initialized
DEBUG - 2016-11-14 12:30:36 --> Carabiner: Library initialized.
DEBUG - 2016-11-14 12:30:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-14 12:30:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-14 12:30:36 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:30:36 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:30:36 --> User Agent Class Initialized
DEBUG - 2016-11-14 12:30:36 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:36 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:36 --> Model Class Initialized
ERROR - 2016-11-14 12:30:36 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-11-14 12:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-11-14 12:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-11-14 12:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-14 12:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-14 12:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-14 12:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-14 12:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-14 12:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-11-14 12:30:36 --> Config Class Initialized
DEBUG - 2016-11-14 12:30:36 --> Hooks Class Initialized
DEBUG - 2016-11-14 12:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-11-14 12:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-14 12:30:36 --> Utf8 Class Initialized
DEBUG - 2016-11-14 12:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-14 12:30:36 --> UTF-8 Support Enabled
DEBUG - 2016-11-14 12:30:36 --> URI Class Initialized
DEBUG - 2016-11-14 12:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-14 12:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-14 12:30:36 --> Router Class Initialized
DEBUG - 2016-11-14 12:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-14 12:30:36 --> Output Class Initialized
DEBUG - 2016-11-14 12:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-14 12:30:36 --> Cache file has expired. File deleted
DEBUG - 2016-11-14 12:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-14 12:30:36 --> Security Class Initialized
DEBUG - 2016-11-14 12:30:36 --> Input Class Initialized
DEBUG - 2016-11-14 12:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-11-14 12:30:36 --> XSS Filtering completed
DEBUG - 2016-11-14 12:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-11-14 12:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-14 12:30:36 --> XSS Filtering completed
DEBUG - 2016-11-14 12:30:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-14 12:30:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-14 12:30:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-11-14 12:30:37 --> Language Class Initialized
DEBUG - 2016-11-14 12:30:37 --> Loader Class Initialized
DEBUG - 2016-11-14 12:30:37 --> Final output sent to browser
DEBUG - 2016-11-14 12:30:37 --> Total execution time: 0.4639
DEBUG - 2016-11-14 12:30:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-14 12:30:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-14 12:30:37 --> Helper loaded: url_helper
DEBUG - 2016-11-14 12:30:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-14 12:30:37 --> Helper loaded: file_helper
DEBUG - 2016-11-14 12:30:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:30:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-14 12:30:37 --> Helper loaded: conf_helper
DEBUG - 2016-11-14 12:30:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:30:37 --> Check Exists common_helper.php: No
DEBUG - 2016-11-14 12:30:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-14 12:30:37 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:30:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-14 12:30:37 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:30:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-14 12:30:37 --> Helper loaded: form_helper
DEBUG - 2016-11-14 12:30:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-14 12:30:37 --> Helper loaded: security_helper
DEBUG - 2016-11-14 12:30:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:30:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-14 12:30:37 --> Helper loaded: lang_helper
DEBUG - 2016-11-14 12:30:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:30:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-14 12:30:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-14 12:30:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-14 12:30:37 --> Helper loaded: atlant_helper
DEBUG - 2016-11-14 12:30:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:30:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-14 12:30:37 --> Helper loaded: crypto_helper
DEBUG - 2016-11-14 12:30:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:30:37 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-14 12:30:37 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-14 12:30:37 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-14 12:30:37 --> Helper loaded: sidika_helper
DEBUG - 2016-11-14 12:30:37 --> Database Driver Class Initialized
DEBUG - 2016-11-14 12:30:37 --> Session Class Initialized
DEBUG - 2016-11-14 12:30:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-14 12:30:37 --> Helper loaded: string_helper
DEBUG - 2016-11-14 12:30:37 --> Session routines successfully run
DEBUG - 2016-11-14 12:30:37 --> Native_session Class Initialized
DEBUG - 2016-11-14 12:30:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-14 12:30:37 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:30:37 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:30:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-14 12:30:37 --> Controller Class Initialized
DEBUG - 2016-11-14 12:30:37 --> Carabiner: Library initialized.
DEBUG - 2016-11-14 12:30:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-14 12:30:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-14 12:30:37 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:30:37 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:30:37 --> User Agent Class Initialized
DEBUG - 2016-11-14 12:30:37 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:37 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:37 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-11-14 12:30:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-14 12:30:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-14 12:30:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-14 12:30:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-14 12:30:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-14 12:30:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-14 12:30:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-14 12:30:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-14 12:30:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-14 12:30:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-14 12:30:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-14 12:30:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-14 12:30:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-11-14 12:30:37 --> Final output sent to browser
DEBUG - 2016-11-14 12:30:37 --> Total execution time: 0.4441
DEBUG - 2016-11-14 12:30:40 --> Config Class Initialized
DEBUG - 2016-11-14 12:30:40 --> Hooks Class Initialized
DEBUG - 2016-11-14 12:30:40 --> Utf8 Class Initialized
DEBUG - 2016-11-14 12:30:40 --> UTF-8 Support Enabled
DEBUG - 2016-11-14 12:30:40 --> URI Class Initialized
DEBUG - 2016-11-14 12:30:40 --> Router Class Initialized
DEBUG - 2016-11-14 12:30:40 --> Output Class Initialized
DEBUG - 2016-11-14 12:30:40 --> Cache file has expired. File deleted
DEBUG - 2016-11-14 12:30:40 --> Security Class Initialized
DEBUG - 2016-11-14 12:30:40 --> Input Class Initialized
DEBUG - 2016-11-14 12:30:40 --> XSS Filtering completed
DEBUG - 2016-11-14 12:30:40 --> XSS Filtering completed
DEBUG - 2016-11-14 12:30:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-14 12:30:40 --> Language Class Initialized
DEBUG - 2016-11-14 12:30:40 --> Loader Class Initialized
DEBUG - 2016-11-14 12:30:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-14 12:30:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-14 12:30:40 --> Helper loaded: url_helper
DEBUG - 2016-11-14 12:30:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-14 12:30:40 --> Helper loaded: file_helper
DEBUG - 2016-11-14 12:30:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:30:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-14 12:30:40 --> Helper loaded: conf_helper
DEBUG - 2016-11-14 12:30:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:30:40 --> Check Exists common_helper.php: No
DEBUG - 2016-11-14 12:30:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-14 12:30:40 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:30:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-14 12:30:40 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:30:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-14 12:30:40 --> Helper loaded: form_helper
DEBUG - 2016-11-14 12:30:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-14 12:30:40 --> Helper loaded: security_helper
DEBUG - 2016-11-14 12:30:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:30:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-14 12:30:40 --> Helper loaded: lang_helper
DEBUG - 2016-11-14 12:30:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:30:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-14 12:30:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-14 12:30:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-14 12:30:40 --> Helper loaded: atlant_helper
DEBUG - 2016-11-14 12:30:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:30:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-14 12:30:40 --> Helper loaded: crypto_helper
DEBUG - 2016-11-14 12:30:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:30:40 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-14 12:30:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-14 12:30:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-14 12:30:40 --> Helper loaded: sidika_helper
DEBUG - 2016-11-14 12:30:40 --> Database Driver Class Initialized
DEBUG - 2016-11-14 12:30:40 --> Session Class Initialized
DEBUG - 2016-11-14 12:30:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-14 12:30:40 --> Helper loaded: string_helper
DEBUG - 2016-11-14 12:30:40 --> Session routines successfully run
DEBUG - 2016-11-14 12:30:40 --> Native_session Class Initialized
DEBUG - 2016-11-14 12:30:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-14 12:30:40 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:30:40 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:30:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-14 12:30:40 --> Controller Class Initialized
DEBUG - 2016-11-14 12:30:40 --> Carabiner: Library initialized.
DEBUG - 2016-11-14 12:30:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-14 12:30:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-14 12:30:40 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:30:40 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:30:40 --> User Agent Class Initialized
DEBUG - 2016-11-14 12:30:40 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:40 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:40 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:40 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:40 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:40 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:40 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:40 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:40 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:40 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-11-14 12:30:40 --> Pagination Class Initialized
DEBUG - 2016-11-14 12:30:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-14 12:30:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-11-14 12:30:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-14 12:30:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-14 12:30:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-14 12:30:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-14 12:30:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-11-14 12:30:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-14 12:30:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-14 12:30:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-14 12:30:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-14 12:30:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-14 12:30:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-14 12:30:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-11-14 12:30:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-14 12:30:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-14 12:30:41 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-11-14 12:30:41 --> Final output sent to browser
DEBUG - 2016-11-14 12:30:41 --> Total execution time: 0.5835
DEBUG - 2016-11-14 12:30:43 --> Config Class Initialized
DEBUG - 2016-11-14 12:30:43 --> Hooks Class Initialized
DEBUG - 2016-11-14 12:30:43 --> Utf8 Class Initialized
DEBUG - 2016-11-14 12:30:43 --> UTF-8 Support Enabled
DEBUG - 2016-11-14 12:30:43 --> URI Class Initialized
DEBUG - 2016-11-14 12:30:43 --> Router Class Initialized
DEBUG - 2016-11-14 12:30:43 --> Output Class Initialized
DEBUG - 2016-11-14 12:30:43 --> Cache file has expired. File deleted
DEBUG - 2016-11-14 12:30:43 --> Security Class Initialized
DEBUG - 2016-11-14 12:30:43 --> Input Class Initialized
DEBUG - 2016-11-14 12:30:43 --> XSS Filtering completed
DEBUG - 2016-11-14 12:30:43 --> XSS Filtering completed
DEBUG - 2016-11-14 12:30:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-14 12:30:43 --> Language Class Initialized
DEBUG - 2016-11-14 12:30:43 --> Loader Class Initialized
DEBUG - 2016-11-14 12:30:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-14 12:30:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-14 12:30:43 --> Helper loaded: url_helper
DEBUG - 2016-11-14 12:30:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-14 12:30:43 --> Helper loaded: file_helper
DEBUG - 2016-11-14 12:30:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:30:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-14 12:30:43 --> Helper loaded: conf_helper
DEBUG - 2016-11-14 12:30:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-14 12:30:43 --> Check Exists common_helper.php: No
DEBUG - 2016-11-14 12:30:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-14 12:30:43 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:30:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-14 12:30:43 --> Helper loaded: common_helper
DEBUG - 2016-11-14 12:30:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-14 12:30:43 --> Helper loaded: form_helper
DEBUG - 2016-11-14 12:30:43 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-14 12:30:43 --> Helper loaded: security_helper
DEBUG - 2016-11-14 12:30:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:30:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-14 12:30:43 --> Helper loaded: lang_helper
DEBUG - 2016-11-14 12:30:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-14 12:30:43 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-14 12:30:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-14 12:30:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-14 12:30:43 --> Helper loaded: atlant_helper
DEBUG - 2016-11-14 12:30:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:30:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-14 12:30:43 --> Helper loaded: crypto_helper
DEBUG - 2016-11-14 12:30:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-14 12:30:43 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-14 12:30:43 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-14 12:30:43 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-14 12:30:43 --> Helper loaded: sidika_helper
DEBUG - 2016-11-14 12:30:43 --> Database Driver Class Initialized
DEBUG - 2016-11-14 12:30:43 --> Session Class Initialized
DEBUG - 2016-11-14 12:30:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-14 12:30:43 --> Helper loaded: string_helper
DEBUG - 2016-11-14 12:30:43 --> Session routines successfully run
DEBUG - 2016-11-14 12:30:43 --> Native_session Class Initialized
DEBUG - 2016-11-14 12:30:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-14 12:30:43 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:30:43 --> Form Validation Class Initialized
DEBUG - 2016-11-14 12:30:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-14 12:30:43 --> Controller Class Initialized
DEBUG - 2016-11-14 12:30:43 --> Carabiner: Library initialized.
DEBUG - 2016-11-14 12:30:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-14 12:30:43 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-14 12:30:43 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:30:43 --> Carabiner: library configured.
DEBUG - 2016-11-14 12:30:43 --> User Agent Class Initialized
DEBUG - 2016-11-14 12:30:43 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:43 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:43 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:43 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:43 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:43 --> Model Class Initialized
DEBUG - 2016-11-14 12:30:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-14 12:30:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-11-14 12:30:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-14 12:30:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-14 12:30:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-14 12:30:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-14 12:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-11-14 12:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-14 12:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-14 12:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-14 12:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-14 12:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-14 12:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-14 12:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-11-14 12:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-14 12:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-14 12:30:44 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/37bfe9d383fa3714edfd5c3493032fc5
DEBUG - 2016-11-14 12:30:44 --> Final output sent to browser
DEBUG - 2016-11-14 12:30:44 --> Total execution time: 0.5790
