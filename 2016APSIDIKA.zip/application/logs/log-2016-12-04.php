<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-12-04 12:18:22 --> Config Class Initialized
DEBUG - 2016-12-04 12:18:22 --> Hooks Class Initialized
DEBUG - 2016-12-04 12:18:22 --> Utf8 Class Initialized
DEBUG - 2016-12-04 12:18:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-04 12:18:22 --> URI Class Initialized
DEBUG - 2016-12-04 12:18:22 --> Router Class Initialized
DEBUG - 2016-12-04 12:18:22 --> No URI present. Default controller set.
DEBUG - 2016-12-04 12:18:22 --> Output Class Initialized
DEBUG - 2016-12-04 12:18:23 --> Cache file has expired. File deleted
DEBUG - 2016-12-04 12:18:23 --> Security Class Initialized
DEBUG - 2016-12-04 12:18:23 --> Input Class Initialized
DEBUG - 2016-12-04 12:18:23 --> XSS Filtering completed
DEBUG - 2016-12-04 12:18:23 --> XSS Filtering completed
DEBUG - 2016-12-04 12:18:23 --> XSS Filtering completed
DEBUG - 2016-12-04 12:18:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-04 12:18:23 --> Language Class Initialized
DEBUG - 2016-12-04 12:18:23 --> Loader Class Initialized
DEBUG - 2016-12-04 12:18:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-04 12:18:23 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-04 12:18:23 --> Helper loaded: url_helper
DEBUG - 2016-12-04 12:18:23 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-04 12:18:23 --> Helper loaded: file_helper
DEBUG - 2016-12-04 12:18:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-04 12:18:23 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-04 12:18:23 --> Helper loaded: conf_helper
DEBUG - 2016-12-04 12:18:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-04 12:18:23 --> Check Exists common_helper.php: No
DEBUG - 2016-12-04 12:18:23 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-04 12:18:23 --> Helper loaded: common_helper
DEBUG - 2016-12-04 12:18:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-04 12:18:23 --> Helper loaded: common_helper
DEBUG - 2016-12-04 12:18:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-04 12:18:23 --> Helper loaded: form_helper
DEBUG - 2016-12-04 12:18:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-04 12:18:23 --> Helper loaded: security_helper
DEBUG - 2016-12-04 12:18:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-04 12:18:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-04 12:18:23 --> Helper loaded: lang_helper
DEBUG - 2016-12-04 12:18:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-04 12:18:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-04 12:18:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-04 12:18:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-04 12:18:23 --> Helper loaded: atlant_helper
DEBUG - 2016-12-04 12:18:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-04 12:18:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-04 12:18:23 --> Helper loaded: crypto_helper
DEBUG - 2016-12-04 12:18:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-04 12:18:23 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-04 12:18:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-04 12:18:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-04 12:18:23 --> Helper loaded: sidika_helper
DEBUG - 2016-12-04 12:18:23 --> Database Driver Class Initialized
DEBUG - 2016-12-04 12:18:23 --> Session Class Initialized
DEBUG - 2016-12-04 12:18:23 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-04 12:18:23 --> Helper loaded: string_helper
DEBUG - 2016-12-04 12:18:23 --> Session routines successfully run
DEBUG - 2016-12-04 12:18:23 --> Native_session Class Initialized
DEBUG - 2016-12-04 12:18:23 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-04 12:18:23 --> Form Validation Class Initialized
DEBUG - 2016-12-04 12:18:23 --> Form Validation Class Initialized
DEBUG - 2016-12-04 12:18:23 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-04 12:18:23 --> Controller Class Initialized
DEBUG - 2016-12-04 12:18:23 --> Carabiner: Library initialized.
DEBUG - 2016-12-04 12:18:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-04 12:18:23 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-04 12:18:23 --> Carabiner: library configured.
DEBUG - 2016-12-04 12:18:23 --> Carabiner: library configured.
DEBUG - 2016-12-04 12:18:23 --> User Agent Class Initialized
DEBUG - 2016-12-04 12:18:23 --> Model Class Initialized
DEBUG - 2016-12-04 12:18:23 --> Model Class Initialized
DEBUG - 2016-12-04 12:18:23 --> Model Class Initialized
ERROR - 2016-12-04 12:18:23 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-12-04 12:18:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-12-04 12:18:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-12-04 12:18:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-04 12:18:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-04 12:18:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-04 12:18:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-04 12:18:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-04 12:18:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-12-04 12:18:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-12-04 12:18:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-04 12:18:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-04 12:18:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-04 12:18:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-04 12:18:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-04 12:18:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-04 12:18:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-04 12:18:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-12-04 12:18:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-12-04 12:18:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-04 12:18:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-04 12:18:23 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-12-04 12:18:23 --> Final output sent to browser
DEBUG - 2016-12-04 12:18:23 --> Total execution time: 0.8989
DEBUG - 2016-12-04 12:18:24 --> Config Class Initialized
DEBUG - 2016-12-04 12:18:24 --> Hooks Class Initialized
DEBUG - 2016-12-04 12:18:24 --> Utf8 Class Initialized
DEBUG - 2016-12-04 12:18:24 --> UTF-8 Support Enabled
DEBUG - 2016-12-04 12:18:24 --> URI Class Initialized
DEBUG - 2016-12-04 12:18:24 --> Router Class Initialized
DEBUG - 2016-12-04 12:18:24 --> Output Class Initialized
DEBUG - 2016-12-04 12:18:24 --> Cache file has expired. File deleted
DEBUG - 2016-12-04 12:18:24 --> Security Class Initialized
DEBUG - 2016-12-04 12:18:24 --> Input Class Initialized
DEBUG - 2016-12-04 12:18:24 --> XSS Filtering completed
DEBUG - 2016-12-04 12:18:24 --> XSS Filtering completed
DEBUG - 2016-12-04 12:18:24 --> XSS Filtering completed
DEBUG - 2016-12-04 12:18:24 --> XSS Filtering completed
DEBUG - 2016-12-04 12:18:24 --> XSS Filtering completed
DEBUG - 2016-12-04 12:18:24 --> XSS Filtering completed
DEBUG - 2016-12-04 12:18:24 --> XSS Filtering completed
DEBUG - 2016-12-04 12:18:24 --> XSS Filtering completed
DEBUG - 2016-12-04 12:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-04 12:18:24 --> Language Class Initialized
DEBUG - 2016-12-04 12:18:24 --> Loader Class Initialized
DEBUG - 2016-12-04 12:18:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-04 12:18:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-04 12:18:24 --> Helper loaded: url_helper
DEBUG - 2016-12-04 12:18:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-04 12:18:24 --> Helper loaded: file_helper
DEBUG - 2016-12-04 12:18:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-04 12:18:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-04 12:18:24 --> Helper loaded: conf_helper
DEBUG - 2016-12-04 12:18:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-04 12:18:24 --> Check Exists common_helper.php: No
DEBUG - 2016-12-04 12:18:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-04 12:18:24 --> Helper loaded: common_helper
DEBUG - 2016-12-04 12:18:24 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-04 12:18:24 --> Helper loaded: common_helper
DEBUG - 2016-12-04 12:18:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-04 12:18:24 --> Helper loaded: form_helper
DEBUG - 2016-12-04 12:18:24 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-04 12:18:24 --> Helper loaded: security_helper
DEBUG - 2016-12-04 12:18:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-04 12:18:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-04 12:18:24 --> Helper loaded: lang_helper
DEBUG - 2016-12-04 12:18:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-04 12:18:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-04 12:18:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-04 12:18:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-04 12:18:24 --> Helper loaded: atlant_helper
DEBUG - 2016-12-04 12:18:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-04 12:18:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-04 12:18:24 --> Helper loaded: crypto_helper
DEBUG - 2016-12-04 12:18:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-04 12:18:24 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-04 12:18:24 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-04 12:18:24 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-04 12:18:24 --> Helper loaded: sidika_helper
DEBUG - 2016-12-04 12:18:24 --> Database Driver Class Initialized
DEBUG - 2016-12-04 12:18:24 --> Session Class Initialized
DEBUG - 2016-12-04 12:18:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-04 12:18:24 --> Helper loaded: string_helper
DEBUG - 2016-12-04 12:18:24 --> Session routines successfully run
DEBUG - 2016-12-04 12:18:24 --> Native_session Class Initialized
DEBUG - 2016-12-04 12:18:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-04 12:18:24 --> Form Validation Class Initialized
DEBUG - 2016-12-04 12:18:24 --> Form Validation Class Initialized
DEBUG - 2016-12-04 12:18:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-04 12:18:24 --> Controller Class Initialized
DEBUG - 2016-12-04 12:18:24 --> Carabiner: Library initialized.
DEBUG - 2016-12-04 12:18:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-04 12:18:24 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-04 12:18:24 --> Carabiner: library configured.
DEBUG - 2016-12-04 12:18:24 --> Carabiner: library configured.
DEBUG - 2016-12-04 12:18:24 --> User Agent Class Initialized
DEBUG - 2016-12-04 12:18:24 --> Model Class Initialized
DEBUG - 2016-12-04 12:18:24 --> Model Class Initialized
DEBUG - 2016-12-04 12:18:24 --> Model Class Initialized
DEBUG - 2016-12-04 12:18:24 --> Model Class Initialized
DEBUG - 2016-12-04 12:18:24 --> Model Class Initialized
DEBUG - 2016-12-04 12:18:24 --> Model Class Initialized
DEBUG - 2016-12-04 12:18:24 --> Model Class Initialized
DEBUG - 2016-12-04 12:18:25 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-12-04 12:18:25 --> Final output sent to browser
DEBUG - 2016-12-04 12:18:25 --> Total execution time: 1.0637
