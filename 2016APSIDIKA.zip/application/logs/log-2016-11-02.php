<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-11-02 12:00:29 --> Config Class Initialized
DEBUG - 2016-11-02 12:00:29 --> Hooks Class Initialized
DEBUG - 2016-11-02 12:00:29 --> Utf8 Class Initialized
DEBUG - 2016-11-02 12:00:29 --> UTF-8 Support Enabled
DEBUG - 2016-11-02 12:00:29 --> URI Class Initialized
DEBUG - 2016-11-02 12:00:29 --> Router Class Initialized
DEBUG - 2016-11-02 12:00:29 --> No URI present. Default controller set.
DEBUG - 2016-11-02 12:00:29 --> Output Class Initialized
DEBUG - 2016-11-02 12:00:29 --> Cache file has expired. File deleted
DEBUG - 2016-11-02 12:00:29 --> Security Class Initialized
DEBUG - 2016-11-02 12:00:29 --> Input Class Initialized
DEBUG - 2016-11-02 12:00:29 --> XSS Filtering completed
DEBUG - 2016-11-02 12:00:29 --> XSS Filtering completed
DEBUG - 2016-11-02 12:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-02 12:00:29 --> Language Class Initialized
DEBUG - 2016-11-02 12:00:29 --> Loader Class Initialized
DEBUG - 2016-11-02 12:00:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-02 12:00:29 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-02 12:00:29 --> Helper loaded: url_helper
DEBUG - 2016-11-02 12:00:29 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-02 12:00:29 --> Helper loaded: file_helper
DEBUG - 2016-11-02 12:00:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-02 12:00:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-02 12:00:29 --> Helper loaded: conf_helper
DEBUG - 2016-11-02 12:00:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-02 12:00:29 --> Check Exists common_helper.php: No
DEBUG - 2016-11-02 12:00:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-02 12:00:29 --> Helper loaded: common_helper
DEBUG - 2016-11-02 12:00:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-02 12:00:29 --> Helper loaded: common_helper
DEBUG - 2016-11-02 12:00:29 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-02 12:00:29 --> Helper loaded: form_helper
DEBUG - 2016-11-02 12:00:29 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-02 12:00:29 --> Helper loaded: security_helper
DEBUG - 2016-11-02 12:00:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-02 12:00:29 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-02 12:00:29 --> Helper loaded: lang_helper
DEBUG - 2016-11-02 12:00:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-02 12:00:29 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-02 12:00:29 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-02 12:00:29 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-02 12:00:29 --> Helper loaded: atlant_helper
DEBUG - 2016-11-02 12:00:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-02 12:00:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-02 12:00:29 --> Helper loaded: crypto_helper
DEBUG - 2016-11-02 12:00:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-02 12:00:29 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-02 12:00:29 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-02 12:00:29 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-02 12:00:29 --> Helper loaded: sidika_helper
DEBUG - 2016-11-02 12:00:29 --> Database Driver Class Initialized
DEBUG - 2016-11-02 12:00:29 --> Session Class Initialized
DEBUG - 2016-11-02 12:00:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-02 12:00:29 --> Helper loaded: string_helper
DEBUG - 2016-11-02 12:00:29 --> Session routines successfully run
DEBUG - 2016-11-02 12:00:29 --> Native_session Class Initialized
DEBUG - 2016-11-02 12:00:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-02 12:00:29 --> Form Validation Class Initialized
DEBUG - 2016-11-02 12:00:29 --> Form Validation Class Initialized
DEBUG - 2016-11-02 12:00:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-02 12:00:29 --> Controller Class Initialized
DEBUG - 2016-11-02 12:00:29 --> Carabiner: Library initialized.
DEBUG - 2016-11-02 12:00:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-02 12:00:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-02 12:00:29 --> Carabiner: library configured.
DEBUG - 2016-11-02 12:00:29 --> Carabiner: library configured.
DEBUG - 2016-11-02 12:00:29 --> User Agent Class Initialized
DEBUG - 2016-11-02 12:00:29 --> Model Class Initialized
DEBUG - 2016-11-02 12:00:29 --> Model Class Initialized
DEBUG - 2016-11-02 12:00:29 --> Model Class Initialized
ERROR - 2016-11-02 12:00:29 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-11-02 12:00:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-11-02 12:00:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-11-02 12:00:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-02 12:00:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-02 12:00:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-02 12:00:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-02 12:00:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-02 12:00:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-11-02 12:00:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-11-02 12:00:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-02 12:00:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-02 12:00:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-02 12:00:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-02 12:00:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-02 12:00:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-02 12:00:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-02 12:00:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-11-02 12:00:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-11-02 12:00:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-02 12:00:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-02 12:00:29 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-11-02 12:00:29 --> Final output sent to browser
DEBUG - 2016-11-02 12:00:29 --> Total execution time: 0.2163
DEBUG - 2016-11-02 12:00:30 --> Config Class Initialized
DEBUG - 2016-11-02 12:00:30 --> Hooks Class Initialized
DEBUG - 2016-11-02 12:00:30 --> Utf8 Class Initialized
DEBUG - 2016-11-02 12:00:30 --> UTF-8 Support Enabled
DEBUG - 2016-11-02 12:00:30 --> URI Class Initialized
DEBUG - 2016-11-02 12:00:30 --> Router Class Initialized
DEBUG - 2016-11-02 12:00:30 --> Output Class Initialized
DEBUG - 2016-11-02 12:00:30 --> Cache file has expired. File deleted
DEBUG - 2016-11-02 12:00:30 --> Security Class Initialized
DEBUG - 2016-11-02 12:00:30 --> Input Class Initialized
DEBUG - 2016-11-02 12:00:30 --> XSS Filtering completed
DEBUG - 2016-11-02 12:00:30 --> XSS Filtering completed
DEBUG - 2016-11-02 12:00:30 --> XSS Filtering completed
DEBUG - 2016-11-02 12:00:30 --> XSS Filtering completed
DEBUG - 2016-11-02 12:00:30 --> XSS Filtering completed
DEBUG - 2016-11-02 12:00:30 --> XSS Filtering completed
DEBUG - 2016-11-02 12:00:30 --> XSS Filtering completed
DEBUG - 2016-11-02 12:00:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-02 12:00:30 --> Language Class Initialized
DEBUG - 2016-11-02 12:00:30 --> Loader Class Initialized
DEBUG - 2016-11-02 12:00:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-02 12:00:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-02 12:00:30 --> Helper loaded: url_helper
DEBUG - 2016-11-02 12:00:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-02 12:00:30 --> Helper loaded: file_helper
DEBUG - 2016-11-02 12:00:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-02 12:00:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-02 12:00:30 --> Helper loaded: conf_helper
DEBUG - 2016-11-02 12:00:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-02 12:00:30 --> Check Exists common_helper.php: No
DEBUG - 2016-11-02 12:00:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-02 12:00:30 --> Helper loaded: common_helper
DEBUG - 2016-11-02 12:00:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-02 12:00:30 --> Helper loaded: common_helper
DEBUG - 2016-11-02 12:00:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-02 12:00:30 --> Helper loaded: form_helper
DEBUG - 2016-11-02 12:00:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-02 12:00:30 --> Helper loaded: security_helper
DEBUG - 2016-11-02 12:00:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-02 12:00:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-02 12:00:30 --> Helper loaded: lang_helper
DEBUG - 2016-11-02 12:00:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-02 12:00:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-02 12:00:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-02 12:00:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-02 12:00:30 --> Helper loaded: atlant_helper
DEBUG - 2016-11-02 12:00:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-02 12:00:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-02 12:00:30 --> Helper loaded: crypto_helper
DEBUG - 2016-11-02 12:00:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-02 12:00:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-02 12:00:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-02 12:00:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-02 12:00:30 --> Helper loaded: sidika_helper
DEBUG - 2016-11-02 12:00:30 --> Database Driver Class Initialized
DEBUG - 2016-11-02 12:00:30 --> Session Class Initialized
DEBUG - 2016-11-02 12:00:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-02 12:00:30 --> Helper loaded: string_helper
DEBUG - 2016-11-02 12:00:30 --> Session routines successfully run
DEBUG - 2016-11-02 12:00:30 --> Native_session Class Initialized
DEBUG - 2016-11-02 12:00:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-02 12:00:30 --> Form Validation Class Initialized
DEBUG - 2016-11-02 12:00:30 --> Form Validation Class Initialized
DEBUG - 2016-11-02 12:00:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-02 12:00:30 --> Controller Class Initialized
DEBUG - 2016-11-02 12:00:30 --> Carabiner: Library initialized.
DEBUG - 2016-11-02 12:00:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-02 12:00:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-02 12:00:30 --> Carabiner: library configured.
DEBUG - 2016-11-02 12:00:30 --> Carabiner: library configured.
DEBUG - 2016-11-02 12:00:30 --> User Agent Class Initialized
DEBUG - 2016-11-02 12:00:30 --> Model Class Initialized
DEBUG - 2016-11-02 12:00:30 --> Model Class Initialized
DEBUG - 2016-11-02 12:00:30 --> Model Class Initialized
DEBUG - 2016-11-02 12:00:30 --> Model Class Initialized
DEBUG - 2016-11-02 12:00:30 --> Model Class Initialized
DEBUG - 2016-11-02 12:00:30 --> Model Class Initialized
DEBUG - 2016-11-02 12:00:30 --> Model Class Initialized
DEBUG - 2016-11-02 12:00:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-11-02 12:00:30 --> Final output sent to browser
DEBUG - 2016-11-02 12:00:30 --> Total execution time: 0.3490
DEBUG - 2016-11-02 12:00:34 --> Config Class Initialized
DEBUG - 2016-11-02 12:00:34 --> Hooks Class Initialized
DEBUG - 2016-11-02 12:00:34 --> Utf8 Class Initialized
DEBUG - 2016-11-02 12:00:34 --> UTF-8 Support Enabled
DEBUG - 2016-11-02 12:00:34 --> URI Class Initialized
DEBUG - 2016-11-02 12:00:34 --> Router Class Initialized
DEBUG - 2016-11-02 12:00:34 --> Output Class Initialized
DEBUG - 2016-11-02 12:00:34 --> Cache file has expired. File deleted
DEBUG - 2016-11-02 12:00:34 --> Security Class Initialized
DEBUG - 2016-11-02 12:00:34 --> Input Class Initialized
DEBUG - 2016-11-02 12:00:34 --> XSS Filtering completed
DEBUG - 2016-11-02 12:00:34 --> XSS Filtering completed
DEBUG - 2016-11-02 12:00:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-02 12:00:34 --> Language Class Initialized
DEBUG - 2016-11-02 12:00:34 --> Loader Class Initialized
DEBUG - 2016-11-02 12:00:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-02 12:00:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-02 12:00:34 --> Helper loaded: url_helper
DEBUG - 2016-11-02 12:00:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-02 12:00:34 --> Helper loaded: file_helper
DEBUG - 2016-11-02 12:00:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-02 12:00:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-02 12:00:34 --> Helper loaded: conf_helper
DEBUG - 2016-11-02 12:00:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-02 12:00:34 --> Check Exists common_helper.php: No
DEBUG - 2016-11-02 12:00:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-02 12:00:34 --> Helper loaded: common_helper
DEBUG - 2016-11-02 12:00:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-02 12:00:34 --> Helper loaded: common_helper
DEBUG - 2016-11-02 12:00:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-02 12:00:34 --> Helper loaded: form_helper
DEBUG - 2016-11-02 12:00:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-02 12:00:34 --> Helper loaded: security_helper
DEBUG - 2016-11-02 12:00:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-02 12:00:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-02 12:00:34 --> Helper loaded: lang_helper
DEBUG - 2016-11-02 12:00:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-02 12:00:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-02 12:00:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-02 12:00:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-02 12:00:34 --> Helper loaded: atlant_helper
DEBUG - 2016-11-02 12:00:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-02 12:00:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-02 12:00:34 --> Helper loaded: crypto_helper
DEBUG - 2016-11-02 12:00:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-02 12:00:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-02 12:00:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-02 12:00:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-02 12:00:34 --> Helper loaded: sidika_helper
DEBUG - 2016-11-02 12:00:34 --> Database Driver Class Initialized
DEBUG - 2016-11-02 12:00:34 --> Session Class Initialized
DEBUG - 2016-11-02 12:00:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-02 12:00:34 --> Helper loaded: string_helper
DEBUG - 2016-11-02 12:00:34 --> Session routines successfully run
DEBUG - 2016-11-02 12:00:34 --> Native_session Class Initialized
DEBUG - 2016-11-02 12:00:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-02 12:00:34 --> Form Validation Class Initialized
DEBUG - 2016-11-02 12:00:34 --> Form Validation Class Initialized
DEBUG - 2016-11-02 12:00:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-02 12:00:34 --> Controller Class Initialized
DEBUG - 2016-11-02 12:00:34 --> Carabiner: Library initialized.
DEBUG - 2016-11-02 12:00:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-02 12:00:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-02 12:00:34 --> Carabiner: library configured.
DEBUG - 2016-11-02 12:00:34 --> Carabiner: library configured.
DEBUG - 2016-11-02 12:00:34 --> User Agent Class Initialized
DEBUG - 2016-11-02 12:00:34 --> Model Class Initialized
DEBUG - 2016-11-02 12:00:34 --> Model Class Initialized
DEBUG - 2016-11-02 12:00:34 --> Model Class Initialized
DEBUG - 2016-11-02 12:00:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-11-02 12:00:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-02 12:00:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-02 12:00:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-02 12:00:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-02 12:00:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-02 12:00:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-02 12:00:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-02 12:00:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-02 12:00:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-02 12:00:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-02 12:00:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-02 12:00:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-02 12:00:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-11-02 12:00:34 --> Final output sent to browser
DEBUG - 2016-11-02 12:00:34 --> Total execution time: 0.2620
DEBUG - 2016-11-02 12:01:19 --> Config Class Initialized
DEBUG - 2016-11-02 12:01:19 --> Hooks Class Initialized
DEBUG - 2016-11-02 12:01:19 --> Utf8 Class Initialized
DEBUG - 2016-11-02 12:01:19 --> UTF-8 Support Enabled
DEBUG - 2016-11-02 12:01:19 --> URI Class Initialized
DEBUG - 2016-11-02 12:01:19 --> Router Class Initialized
DEBUG - 2016-11-02 12:01:19 --> Output Class Initialized
DEBUG - 2016-11-02 12:01:19 --> Cache file has expired. File deleted
DEBUG - 2016-11-02 12:01:19 --> Security Class Initialized
DEBUG - 2016-11-02 12:01:19 --> Input Class Initialized
DEBUG - 2016-11-02 12:01:19 --> XSS Filtering completed
DEBUG - 2016-11-02 12:01:19 --> XSS Filtering completed
DEBUG - 2016-11-02 12:01:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-02 12:01:19 --> Language Class Initialized
DEBUG - 2016-11-02 12:01:19 --> Loader Class Initialized
DEBUG - 2016-11-02 12:01:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-02 12:01:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-02 12:01:19 --> Helper loaded: url_helper
DEBUG - 2016-11-02 12:01:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-02 12:01:19 --> Helper loaded: file_helper
DEBUG - 2016-11-02 12:01:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-02 12:01:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-02 12:01:19 --> Helper loaded: conf_helper
DEBUG - 2016-11-02 12:01:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-02 12:01:19 --> Check Exists common_helper.php: No
DEBUG - 2016-11-02 12:01:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-02 12:01:19 --> Helper loaded: common_helper
DEBUG - 2016-11-02 12:01:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-02 12:01:19 --> Helper loaded: common_helper
DEBUG - 2016-11-02 12:01:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-02 12:01:19 --> Helper loaded: form_helper
DEBUG - 2016-11-02 12:01:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-02 12:01:19 --> Helper loaded: security_helper
DEBUG - 2016-11-02 12:01:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-02 12:01:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-02 12:01:19 --> Helper loaded: lang_helper
DEBUG - 2016-11-02 12:01:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-02 12:01:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-02 12:01:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-02 12:01:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-02 12:01:19 --> Helper loaded: atlant_helper
DEBUG - 2016-11-02 12:01:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-02 12:01:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-02 12:01:19 --> Helper loaded: crypto_helper
DEBUG - 2016-11-02 12:01:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-02 12:01:19 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-02 12:01:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-02 12:01:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-02 12:01:19 --> Helper loaded: sidika_helper
DEBUG - 2016-11-02 12:01:19 --> Database Driver Class Initialized
DEBUG - 2016-11-02 12:01:19 --> Session Class Initialized
DEBUG - 2016-11-02 12:01:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-02 12:01:19 --> Helper loaded: string_helper
DEBUG - 2016-11-02 12:01:19 --> Session routines successfully run
DEBUG - 2016-11-02 12:01:19 --> Native_session Class Initialized
DEBUG - 2016-11-02 12:01:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-02 12:01:19 --> Form Validation Class Initialized
DEBUG - 2016-11-02 12:01:19 --> Form Validation Class Initialized
DEBUG - 2016-11-02 12:01:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-02 12:01:19 --> Controller Class Initialized
DEBUG - 2016-11-02 12:01:19 --> Carabiner: Library initialized.
DEBUG - 2016-11-02 12:01:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-02 12:01:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-02 12:01:19 --> Carabiner: library configured.
DEBUG - 2016-11-02 12:01:19 --> Carabiner: library configured.
DEBUG - 2016-11-02 12:01:19 --> User Agent Class Initialized
DEBUG - 2016-11-02 12:01:19 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:19 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:19 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:19 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:19 --> Model Class Initialized
ERROR - 2016-11-02 12:01:19 --> Hak Akses modul/kontroller 'cref_tingkat_pendidikan' untuk role 'unkown' belum di set.
DEBUG - 2016-11-02 12:01:20 --> Config Class Initialized
DEBUG - 2016-11-02 12:01:20 --> Hooks Class Initialized
DEBUG - 2016-11-02 12:01:20 --> Utf8 Class Initialized
DEBUG - 2016-11-02 12:01:20 --> UTF-8 Support Enabled
DEBUG - 2016-11-02 12:01:20 --> URI Class Initialized
DEBUG - 2016-11-02 12:01:20 --> Router Class Initialized
DEBUG - 2016-11-02 12:01:20 --> Output Class Initialized
DEBUG - 2016-11-02 12:01:20 --> Security Class Initialized
DEBUG - 2016-11-02 12:01:20 --> Input Class Initialized
DEBUG - 2016-11-02 12:01:20 --> XSS Filtering completed
DEBUG - 2016-11-02 12:01:20 --> XSS Filtering completed
DEBUG - 2016-11-02 12:01:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-02 12:01:20 --> Language Class Initialized
DEBUG - 2016-11-02 12:01:20 --> Loader Class Initialized
DEBUG - 2016-11-02 12:01:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-02 12:01:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-02 12:01:20 --> Helper loaded: url_helper
DEBUG - 2016-11-02 12:01:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-02 12:01:20 --> Helper loaded: file_helper
DEBUG - 2016-11-02 12:01:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-02 12:01:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-02 12:01:20 --> Helper loaded: conf_helper
DEBUG - 2016-11-02 12:01:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-02 12:01:20 --> Check Exists common_helper.php: No
DEBUG - 2016-11-02 12:01:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-02 12:01:20 --> Helper loaded: common_helper
DEBUG - 2016-11-02 12:01:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-02 12:01:20 --> Helper loaded: common_helper
DEBUG - 2016-11-02 12:01:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-02 12:01:20 --> Helper loaded: form_helper
DEBUG - 2016-11-02 12:01:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-02 12:01:20 --> Helper loaded: security_helper
DEBUG - 2016-11-02 12:01:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-02 12:01:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-02 12:01:20 --> Helper loaded: lang_helper
DEBUG - 2016-11-02 12:01:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-02 12:01:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-02 12:01:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-02 12:01:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-02 12:01:20 --> Helper loaded: atlant_helper
DEBUG - 2016-11-02 12:01:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-02 12:01:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-02 12:01:20 --> Helper loaded: crypto_helper
DEBUG - 2016-11-02 12:01:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-02 12:01:20 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-02 12:01:20 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-02 12:01:20 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-02 12:01:20 --> Helper loaded: sidika_helper
DEBUG - 2016-11-02 12:01:20 --> Database Driver Class Initialized
DEBUG - 2016-11-02 12:01:20 --> Session Class Initialized
DEBUG - 2016-11-02 12:01:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-02 12:01:20 --> Helper loaded: string_helper
DEBUG - 2016-11-02 12:01:20 --> Session routines successfully run
DEBUG - 2016-11-02 12:01:20 --> Native_session Class Initialized
DEBUG - 2016-11-02 12:01:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-02 12:01:20 --> Form Validation Class Initialized
DEBUG - 2016-11-02 12:01:20 --> Form Validation Class Initialized
DEBUG - 2016-11-02 12:01:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-02 12:01:20 --> Controller Class Initialized
DEBUG - 2016-11-02 12:01:20 --> Carabiner: Library initialized.
DEBUG - 2016-11-02 12:01:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-02 12:01:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-02 12:01:20 --> Carabiner: library configured.
DEBUG - 2016-11-02 12:01:20 --> Carabiner: library configured.
DEBUG - 2016-11-02 12:01:20 --> User Agent Class Initialized
DEBUG - 2016-11-02 12:01:20 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:20 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:20 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:20 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:20 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:20 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:20 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:20 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-11-02 12:01:20 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-11-02 12:01:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-11-02 12:01:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-11-02 12:01:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-11-02 12:01:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-11-02 12:01:20 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-11-02 12:01:20 --> Final output sent to browser
DEBUG - 2016-11-02 12:01:20 --> Total execution time: 0.2346
DEBUG - 2016-11-02 12:01:20 --> Config Class Initialized
DEBUG - 2016-11-02 12:01:20 --> Hooks Class Initialized
DEBUG - 2016-11-02 12:01:20 --> Utf8 Class Initialized
DEBUG - 2016-11-02 12:01:20 --> UTF-8 Support Enabled
DEBUG - 2016-11-02 12:01:20 --> URI Class Initialized
DEBUG - 2016-11-02 12:01:20 --> Router Class Initialized
ERROR - 2016-11-02 12:01:20 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-11-02 12:01:25 --> Config Class Initialized
DEBUG - 2016-11-02 12:01:25 --> Hooks Class Initialized
DEBUG - 2016-11-02 12:01:25 --> Utf8 Class Initialized
DEBUG - 2016-11-02 12:01:25 --> UTF-8 Support Enabled
DEBUG - 2016-11-02 12:01:25 --> URI Class Initialized
DEBUG - 2016-11-02 12:01:25 --> Router Class Initialized
DEBUG - 2016-11-02 12:01:25 --> Output Class Initialized
DEBUG - 2016-11-02 12:01:25 --> Cache file has expired. File deleted
DEBUG - 2016-11-02 12:01:25 --> Security Class Initialized
DEBUG - 2016-11-02 12:01:25 --> Input Class Initialized
DEBUG - 2016-11-02 12:01:25 --> XSS Filtering completed
DEBUG - 2016-11-02 12:01:25 --> XSS Filtering completed
DEBUG - 2016-11-02 12:01:25 --> XSS Filtering completed
DEBUG - 2016-11-02 12:01:25 --> XSS Filtering completed
DEBUG - 2016-11-02 12:01:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-02 12:01:25 --> Language Class Initialized
DEBUG - 2016-11-02 12:01:25 --> Loader Class Initialized
DEBUG - 2016-11-02 12:01:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-02 12:01:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-02 12:01:25 --> Helper loaded: url_helper
DEBUG - 2016-11-02 12:01:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-02 12:01:25 --> Helper loaded: file_helper
DEBUG - 2016-11-02 12:01:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-02 12:01:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-02 12:01:25 --> Helper loaded: conf_helper
DEBUG - 2016-11-02 12:01:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-02 12:01:25 --> Check Exists common_helper.php: No
DEBUG - 2016-11-02 12:01:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-02 12:01:25 --> Helper loaded: common_helper
DEBUG - 2016-11-02 12:01:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-02 12:01:25 --> Helper loaded: common_helper
DEBUG - 2016-11-02 12:01:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-02 12:01:25 --> Helper loaded: form_helper
DEBUG - 2016-11-02 12:01:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-02 12:01:25 --> Helper loaded: security_helper
DEBUG - 2016-11-02 12:01:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-02 12:01:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-02 12:01:25 --> Helper loaded: lang_helper
DEBUG - 2016-11-02 12:01:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-02 12:01:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-02 12:01:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-02 12:01:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-02 12:01:25 --> Helper loaded: atlant_helper
DEBUG - 2016-11-02 12:01:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-02 12:01:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-02 12:01:25 --> Helper loaded: crypto_helper
DEBUG - 2016-11-02 12:01:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-02 12:01:25 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-02 12:01:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-02 12:01:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-02 12:01:25 --> Helper loaded: sidika_helper
DEBUG - 2016-11-02 12:01:25 --> Database Driver Class Initialized
DEBUG - 2016-11-02 12:01:25 --> Session Class Initialized
DEBUG - 2016-11-02 12:01:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-02 12:01:25 --> Helper loaded: string_helper
DEBUG - 2016-11-02 12:01:25 --> Session routines successfully run
DEBUG - 2016-11-02 12:01:25 --> Native_session Class Initialized
DEBUG - 2016-11-02 12:01:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-02 12:01:25 --> Form Validation Class Initialized
DEBUG - 2016-11-02 12:01:25 --> Form Validation Class Initialized
DEBUG - 2016-11-02 12:01:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-02 12:01:25 --> Controller Class Initialized
DEBUG - 2016-11-02 12:01:25 --> Carabiner: Library initialized.
DEBUG - 2016-11-02 12:01:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-02 12:01:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-02 12:01:25 --> Carabiner: library configured.
DEBUG - 2016-11-02 12:01:25 --> Carabiner: library configured.
DEBUG - 2016-11-02 12:01:25 --> User Agent Class Initialized
DEBUG - 2016-11-02 12:01:25 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:25 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:25 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:25 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:25 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:25 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:25 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-11-02 12:01:25 --> Form Validation Class Initialized
DEBUG - 2016-11-02 12:01:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-02 12:01:25 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-11-02 12:01:25 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-11-02 12:01:25 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-11-02 12:01:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-11-02 12:01:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-11-02 12:01:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-11-02 12:01:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-11-02 12:01:25 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-11-02 12:01:25 --> Final output sent to browser
DEBUG - 2016-11-02 12:01:25 --> Total execution time: 0.4107
DEBUG - 2016-11-02 12:01:39 --> Config Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Hooks Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Utf8 Class Initialized
DEBUG - 2016-11-02 12:01:39 --> UTF-8 Support Enabled
DEBUG - 2016-11-02 12:01:39 --> URI Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Router Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Output Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Cache file has expired. File deleted
DEBUG - 2016-11-02 12:01:39 --> Security Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Input Class Initialized
DEBUG - 2016-11-02 12:01:39 --> XSS Filtering completed
DEBUG - 2016-11-02 12:01:39 --> XSS Filtering completed
DEBUG - 2016-11-02 12:01:39 --> XSS Filtering completed
DEBUG - 2016-11-02 12:01:39 --> XSS Filtering completed
DEBUG - 2016-11-02 12:01:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-02 12:01:39 --> Language Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Loader Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-02 12:01:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-02 12:01:39 --> Helper loaded: url_helper
DEBUG - 2016-11-02 12:01:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-02 12:01:39 --> Helper loaded: file_helper
DEBUG - 2016-11-02 12:01:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-02 12:01:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-02 12:01:39 --> Helper loaded: conf_helper
DEBUG - 2016-11-02 12:01:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-02 12:01:39 --> Check Exists common_helper.php: No
DEBUG - 2016-11-02 12:01:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-02 12:01:39 --> Helper loaded: common_helper
DEBUG - 2016-11-02 12:01:39 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-02 12:01:39 --> Helper loaded: common_helper
DEBUG - 2016-11-02 12:01:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-02 12:01:39 --> Helper loaded: form_helper
DEBUG - 2016-11-02 12:01:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-02 12:01:39 --> Helper loaded: security_helper
DEBUG - 2016-11-02 12:01:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-02 12:01:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-02 12:01:39 --> Helper loaded: lang_helper
DEBUG - 2016-11-02 12:01:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-02 12:01:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-02 12:01:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-02 12:01:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-02 12:01:39 --> Helper loaded: atlant_helper
DEBUG - 2016-11-02 12:01:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-02 12:01:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-02 12:01:39 --> Helper loaded: crypto_helper
DEBUG - 2016-11-02 12:01:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-02 12:01:39 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-02 12:01:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-02 12:01:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-02 12:01:39 --> Helper loaded: sidika_helper
DEBUG - 2016-11-02 12:01:39 --> Database Driver Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Session Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-02 12:01:39 --> Helper loaded: string_helper
DEBUG - 2016-11-02 12:01:39 --> Session routines successfully run
DEBUG - 2016-11-02 12:01:39 --> Native_session Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-02 12:01:39 --> Form Validation Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Form Validation Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-02 12:01:39 --> Controller Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Carabiner: Library initialized.
DEBUG - 2016-11-02 12:01:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-02 12:01:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-02 12:01:39 --> Carabiner: library configured.
DEBUG - 2016-11-02 12:01:39 --> Carabiner: library configured.
DEBUG - 2016-11-02 12:01:39 --> User Agent Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-11-02 12:01:39 --> Form Validation Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-02 12:01:39 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-11-02 12:01:39 --> Config Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Hooks Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Utf8 Class Initialized
DEBUG - 2016-11-02 12:01:39 --> UTF-8 Support Enabled
DEBUG - 2016-11-02 12:01:39 --> URI Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Router Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Output Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Security Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Input Class Initialized
DEBUG - 2016-11-02 12:01:39 --> XSS Filtering completed
DEBUG - 2016-11-02 12:01:39 --> XSS Filtering completed
DEBUG - 2016-11-02 12:01:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-02 12:01:39 --> Language Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Loader Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-02 12:01:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-02 12:01:39 --> Helper loaded: url_helper
DEBUG - 2016-11-02 12:01:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-02 12:01:39 --> Helper loaded: file_helper
DEBUG - 2016-11-02 12:01:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-02 12:01:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-02 12:01:39 --> Helper loaded: conf_helper
DEBUG - 2016-11-02 12:01:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-02 12:01:39 --> Check Exists common_helper.php: No
DEBUG - 2016-11-02 12:01:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-02 12:01:39 --> Helper loaded: common_helper
DEBUG - 2016-11-02 12:01:39 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-02 12:01:39 --> Helper loaded: common_helper
DEBUG - 2016-11-02 12:01:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-02 12:01:39 --> Helper loaded: form_helper
DEBUG - 2016-11-02 12:01:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-02 12:01:39 --> Helper loaded: security_helper
DEBUG - 2016-11-02 12:01:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-02 12:01:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-02 12:01:39 --> Helper loaded: lang_helper
DEBUG - 2016-11-02 12:01:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-02 12:01:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-02 12:01:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-02 12:01:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-02 12:01:39 --> Helper loaded: atlant_helper
DEBUG - 2016-11-02 12:01:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-02 12:01:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-02 12:01:39 --> Helper loaded: crypto_helper
DEBUG - 2016-11-02 12:01:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-02 12:01:39 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-02 12:01:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-02 12:01:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-02 12:01:39 --> Helper loaded: sidika_helper
DEBUG - 2016-11-02 12:01:39 --> Database Driver Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Session Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-02 12:01:39 --> Helper loaded: string_helper
DEBUG - 2016-11-02 12:01:39 --> Session routines successfully run
DEBUG - 2016-11-02 12:01:39 --> Native_session Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-02 12:01:39 --> Form Validation Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Form Validation Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-02 12:01:39 --> Controller Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Carabiner: Library initialized.
DEBUG - 2016-11-02 12:01:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-02 12:01:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-02 12:01:39 --> Carabiner: library configured.
DEBUG - 2016-11-02 12:01:39 --> Carabiner: library configured.
DEBUG - 2016-11-02 12:01:39 --> User Agent Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Model Class Initialized
DEBUG - 2016-11-02 12:01:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-11-02 12:01:39 --> Pagination Class Initialized
DEBUG - 2016-11-02 12:01:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-02 12:01:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_tingkat_pendidikan/index.php
DEBUG - 2016-11-02 12:01:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-02 12:01:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-02 12:01:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-02 12:01:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-02 12:01:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_tingkat_pendidikan/js/index_js.php
DEBUG - 2016-11-02 12:01:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-02 12:01:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-02 12:01:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-02 12:01:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-02 12:01:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-02 12:01:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-02 12:01:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_tingkat_pendidikan/js/index_js.php
DEBUG - 2016-11-02 12:01:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-02 12:01:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-02 12:01:39 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c75a32d2afef33dce35572ed7fc68d18
DEBUG - 2016-11-02 12:01:39 --> Final output sent to browser
DEBUG - 2016-11-02 12:01:39 --> Total execution time: 0.3179
