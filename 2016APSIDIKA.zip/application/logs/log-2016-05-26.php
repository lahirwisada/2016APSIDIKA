<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-05-26 14:32:42 --> Config Class Initialized
DEBUG - 2016-05-26 14:32:42 --> Hooks Class Initialized
DEBUG - 2016-05-26 14:32:42 --> Utf8 Class Initialized
DEBUG - 2016-05-26 14:32:42 --> UTF-8 Support Enabled
DEBUG - 2016-05-26 14:32:42 --> URI Class Initialized
DEBUG - 2016-05-26 14:32:42 --> Router Class Initialized
DEBUG - 2016-05-26 14:32:43 --> Output Class Initialized
DEBUG - 2016-05-26 14:32:43 --> Cache file has expired. File deleted
DEBUG - 2016-05-26 14:32:43 --> Security Class Initialized
DEBUG - 2016-05-26 14:32:43 --> Input Class Initialized
DEBUG - 2016-05-26 14:32:43 --> XSS Filtering completed
DEBUG - 2016-05-26 14:32:43 --> XSS Filtering completed
DEBUG - 2016-05-26 14:32:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-26 14:32:43 --> Language Class Initialized
DEBUG - 2016-05-26 14:32:43 --> Loader Class Initialized
DEBUG - 2016-05-26 14:32:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-26 14:32:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-26 14:32:43 --> Helper loaded: url_helper
DEBUG - 2016-05-26 14:32:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-26 14:32:43 --> Helper loaded: file_helper
DEBUG - 2016-05-26 14:32:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-26 14:32:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-26 14:32:43 --> Helper loaded: conf_helper
DEBUG - 2016-05-26 14:32:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-26 14:32:43 --> Check Exists common_helper.php: No
DEBUG - 2016-05-26 14:32:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-26 14:32:43 --> Helper loaded: common_helper
DEBUG - 2016-05-26 14:32:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-26 14:32:43 --> Helper loaded: common_helper
DEBUG - 2016-05-26 14:32:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-26 14:32:43 --> Helper loaded: form_helper
DEBUG - 2016-05-26 14:32:43 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-26 14:32:43 --> Helper loaded: security_helper
DEBUG - 2016-05-26 14:32:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-26 14:32:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-26 14:32:43 --> Helper loaded: lang_helper
DEBUG - 2016-05-26 14:32:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-26 14:32:43 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-26 14:32:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-26 14:32:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-26 14:32:43 --> Helper loaded: atlant_helper
DEBUG - 2016-05-26 14:32:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-26 14:32:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-26 14:32:43 --> Helper loaded: crypto_helper
DEBUG - 2016-05-26 14:32:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-26 14:32:43 --> Database Driver Class Initialized
DEBUG - 2016-05-26 14:32:43 --> Session Class Initialized
DEBUG - 2016-05-26 14:32:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-26 14:32:43 --> Helper loaded: string_helper
DEBUG - 2016-05-26 14:32:43 --> Session routines successfully run
DEBUG - 2016-05-26 14:32:43 --> Native_session Class Initialized
DEBUG - 2016-05-26 14:32:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-26 14:32:43 --> Form Validation Class Initialized
DEBUG - 2016-05-26 14:32:43 --> Form Validation Class Initialized
DEBUG - 2016-05-26 14:32:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-26 14:32:43 --> Controller Class Initialized
DEBUG - 2016-05-26 14:32:44 --> Carabiner: Library initialized.
DEBUG - 2016-05-26 14:32:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-26 14:32:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-26 14:32:44 --> Carabiner: library configured.
DEBUG - 2016-05-26 14:32:44 --> Carabiner: library configured.
DEBUG - 2016-05-26 14:32:44 --> User Agent Class Initialized
DEBUG - 2016-05-26 14:32:44 --> Model Class Initialized
DEBUG - 2016-05-26 14:32:44 --> Model Class Initialized
DEBUG - 2016-05-26 14:32:44 --> Model Class Initialized
DEBUG - 2016-05-26 14:32:44 --> Model Class Initialized
DEBUG - 2016-05-26 14:32:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-26 14:32:44 --> Pagination Class Initialized
DEBUG - 2016-05-26 14:32:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-26 14:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/index.php
DEBUG - 2016-05-26 14:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-26 14:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-26 14:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-26 14:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-26 14:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-05-26 14:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-26 14:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-26 14:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-26 14:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-26 14:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-26 14:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-26 14:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-05-26 14:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-26 14:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-26 14:32:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0afc8ae14bdb2df5b4e2fbf4366db4fc
DEBUG - 2016-05-26 14:32:45 --> Final output sent to browser
DEBUG - 2016-05-26 14:32:45 --> Total execution time: 1.8712
DEBUG - 2016-05-26 14:32:58 --> Config Class Initialized
DEBUG - 2016-05-26 14:32:58 --> Hooks Class Initialized
DEBUG - 2016-05-26 14:32:58 --> Utf8 Class Initialized
DEBUG - 2016-05-26 14:32:58 --> UTF-8 Support Enabled
DEBUG - 2016-05-26 14:32:58 --> URI Class Initialized
DEBUG - 2016-05-26 14:32:58 --> Router Class Initialized
ERROR - 2016-05-26 14:32:58 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-05-26 14:32:59 --> Config Class Initialized
DEBUG - 2016-05-26 14:32:59 --> Hooks Class Initialized
DEBUG - 2016-05-26 14:32:59 --> Utf8 Class Initialized
DEBUG - 2016-05-26 14:32:59 --> UTF-8 Support Enabled
DEBUG - 2016-05-26 14:32:59 --> URI Class Initialized
DEBUG - 2016-05-26 14:32:59 --> Router Class Initialized
DEBUG - 2016-05-26 14:32:59 --> Output Class Initialized
DEBUG - 2016-05-26 14:32:59 --> Security Class Initialized
DEBUG - 2016-05-26 14:32:59 --> Input Class Initialized
DEBUG - 2016-05-26 14:32:59 --> XSS Filtering completed
DEBUG - 2016-05-26 14:32:59 --> XSS Filtering completed
DEBUG - 2016-05-26 14:32:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-26 14:32:59 --> Language Class Initialized
DEBUG - 2016-05-26 14:32:59 --> Loader Class Initialized
DEBUG - 2016-05-26 14:32:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-26 14:32:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-26 14:33:00 --> Helper loaded: url_helper
DEBUG - 2016-05-26 14:33:00 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-26 14:33:00 --> Helper loaded: file_helper
DEBUG - 2016-05-26 14:33:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-26 14:33:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-26 14:33:00 --> Helper loaded: conf_helper
DEBUG - 2016-05-26 14:33:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-26 14:33:00 --> Check Exists common_helper.php: No
DEBUG - 2016-05-26 14:33:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-26 14:33:00 --> Helper loaded: common_helper
DEBUG - 2016-05-26 14:33:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-26 14:33:00 --> Helper loaded: common_helper
DEBUG - 2016-05-26 14:33:00 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-26 14:33:00 --> Helper loaded: form_helper
DEBUG - 2016-05-26 14:33:00 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-26 14:33:00 --> Helper loaded: security_helper
DEBUG - 2016-05-26 14:33:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-26 14:33:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-26 14:33:00 --> Helper loaded: lang_helper
DEBUG - 2016-05-26 14:33:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-26 14:33:00 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-26 14:33:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-26 14:33:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-26 14:33:00 --> Helper loaded: atlant_helper
DEBUG - 2016-05-26 14:33:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-26 14:33:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-26 14:33:00 --> Helper loaded: crypto_helper
DEBUG - 2016-05-26 14:33:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-26 14:33:00 --> Database Driver Class Initialized
DEBUG - 2016-05-26 14:33:00 --> Session Class Initialized
DEBUG - 2016-05-26 14:33:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-26 14:33:00 --> Helper loaded: string_helper
DEBUG - 2016-05-26 14:33:00 --> Session routines successfully run
DEBUG - 2016-05-26 14:33:00 --> Native_session Class Initialized
DEBUG - 2016-05-26 14:33:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-26 14:33:00 --> Form Validation Class Initialized
DEBUG - 2016-05-26 14:33:00 --> Form Validation Class Initialized
DEBUG - 2016-05-26 14:33:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-26 14:33:00 --> Controller Class Initialized
DEBUG - 2016-05-26 14:33:00 --> Carabiner: Library initialized.
DEBUG - 2016-05-26 14:33:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-26 14:33:00 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-26 14:33:00 --> Carabiner: library configured.
DEBUG - 2016-05-26 14:33:00 --> Carabiner: library configured.
DEBUG - 2016-05-26 14:33:00 --> User Agent Class Initialized
DEBUG - 2016-05-26 14:33:00 --> Model Class Initialized
DEBUG - 2016-05-26 14:33:01 --> Model Class Initialized
DEBUG - 2016-05-26 14:33:01 --> Model Class Initialized
DEBUG - 2016-05-26 14:33:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-26 14:33:01 --> Pagination Class Initialized
DEBUG - 2016-05-26 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-26 14:33:01 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/index.php
DEBUG - 2016-05-26 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-26 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-26 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-26 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-26 14:33:01 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2016-05-26 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-26 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-26 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-26 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-26 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-26 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-26 14:33:01 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2016-05-26 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-26 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-26 14:33:01 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8118d087c6d6c5bac3947ef2cf7a3513
DEBUG - 2016-05-26 14:33:01 --> Final output sent to browser
DEBUG - 2016-05-26 14:33:01 --> Total execution time: 1.4843
DEBUG - 2016-05-26 14:33:02 --> Config Class Initialized
DEBUG - 2016-05-26 14:33:02 --> Hooks Class Initialized
DEBUG - 2016-05-26 14:33:02 --> Utf8 Class Initialized
DEBUG - 2016-05-26 14:33:02 --> UTF-8 Support Enabled
DEBUG - 2016-05-26 14:33:02 --> URI Class Initialized
DEBUG - 2016-05-26 14:33:02 --> Router Class Initialized
ERROR - 2016-05-26 14:33:02 --> 404 Page Not Found --> back_bone/favicon.ico
