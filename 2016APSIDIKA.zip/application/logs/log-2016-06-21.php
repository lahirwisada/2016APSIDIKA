<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-06-21 09:17:25 --> Config Class Initialized
DEBUG - 2016-06-21 09:17:25 --> Hooks Class Initialized
DEBUG - 2016-06-21 09:17:25 --> Utf8 Class Initialized
DEBUG - 2016-06-21 09:17:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-21 09:17:25 --> URI Class Initialized
DEBUG - 2016-06-21 09:17:25 --> Router Class Initialized
DEBUG - 2016-06-21 09:17:26 --> Output Class Initialized
DEBUG - 2016-06-21 09:17:26 --> Cache file has expired. File deleted
DEBUG - 2016-06-21 09:17:26 --> Security Class Initialized
DEBUG - 2016-06-21 09:17:26 --> Input Class Initialized
DEBUG - 2016-06-21 09:17:26 --> XSS Filtering completed
DEBUG - 2016-06-21 09:17:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-21 09:17:26 --> Language Class Initialized
DEBUG - 2016-06-21 09:17:27 --> Loader Class Initialized
DEBUG - 2016-06-21 09:17:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-21 09:17:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-21 09:17:27 --> Helper loaded: url_helper
DEBUG - 2016-06-21 09:17:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-21 09:17:27 --> Helper loaded: file_helper
DEBUG - 2016-06-21 09:17:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-21 09:17:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-21 09:17:27 --> Helper loaded: conf_helper
DEBUG - 2016-06-21 09:17:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-21 09:17:27 --> Check Exists common_helper.php: No
DEBUG - 2016-06-21 09:17:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-21 09:17:27 --> Helper loaded: common_helper
DEBUG - 2016-06-21 09:17:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-21 09:17:27 --> Helper loaded: common_helper
DEBUG - 2016-06-21 09:17:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-21 09:17:27 --> Helper loaded: form_helper
DEBUG - 2016-06-21 09:17:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-21 09:17:27 --> Helper loaded: security_helper
DEBUG - 2016-06-21 09:17:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-21 09:17:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-21 09:17:27 --> Helper loaded: lang_helper
DEBUG - 2016-06-21 09:17:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-21 09:17:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-21 09:17:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-21 09:17:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-21 09:17:27 --> Helper loaded: atlant_helper
DEBUG - 2016-06-21 09:17:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-21 09:17:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-21 09:17:28 --> Helper loaded: crypto_helper
DEBUG - 2016-06-21 09:17:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-21 09:17:28 --> Database Driver Class Initialized
DEBUG - 2016-06-21 09:17:29 --> Session Class Initialized
DEBUG - 2016-06-21 09:17:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-21 09:17:29 --> Helper loaded: string_helper
DEBUG - 2016-06-21 09:17:29 --> A session cookie was not found.
DEBUG - 2016-06-21 09:17:29 --> Session routines successfully run
DEBUG - 2016-06-21 09:17:29 --> Native_session Class Initialized
DEBUG - 2016-06-21 09:17:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-21 09:17:29 --> Form Validation Class Initialized
DEBUG - 2016-06-21 09:17:29 --> Form Validation Class Initialized
DEBUG - 2016-06-21 09:17:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-21 09:17:29 --> Controller Class Initialized
DEBUG - 2016-06-21 09:17:29 --> Carabiner: Library initialized.
DEBUG - 2016-06-21 09:17:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-21 09:17:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-21 09:17:29 --> Carabiner: library configured.
DEBUG - 2016-06-21 09:17:29 --> Carabiner: library configured.
DEBUG - 2016-06-21 09:17:30 --> User Agent Class Initialized
DEBUG - 2016-06-21 09:17:30 --> Model Class Initialized
DEBUG - 2016-06-21 09:17:30 --> Model Class Initialized
DEBUG - 2016-06-21 09:17:30 --> Model Class Initialized
DEBUG - 2016-06-21 09:17:33 --> Model Class Initialized
DEBUG - 2016-06-21 09:17:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-06-21 09:17:34 --> Pagination Class Initialized
DEBUG - 2016-06-21 09:17:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-21 09:17:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/index.php
DEBUG - 2016-06-21 09:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-21 09:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-21 09:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-21 09:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-21 09:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-06-21 09:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-21 09:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-21 09:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-21 09:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-21 09:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-21 09:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-21 09:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-06-21 09:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-21 09:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-21 09:17:35 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0afc8ae14bdb2df5b4e2fbf4366db4fc
DEBUG - 2016-06-21 09:17:35 --> Final output sent to browser
DEBUG - 2016-06-21 09:17:35 --> Total execution time: 9.4001
DEBUG - 2016-06-21 09:17:46 --> Config Class Initialized
DEBUG - 2016-06-21 09:17:46 --> Hooks Class Initialized
DEBUG - 2016-06-21 09:17:46 --> Utf8 Class Initialized
DEBUG - 2016-06-21 09:17:46 --> UTF-8 Support Enabled
DEBUG - 2016-06-21 09:17:46 --> URI Class Initialized
DEBUG - 2016-06-21 09:17:46 --> Router Class Initialized
ERROR - 2016-06-21 09:17:46 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-06-21 09:21:49 --> Config Class Initialized
DEBUG - 2016-06-21 09:21:49 --> Hooks Class Initialized
DEBUG - 2016-06-21 09:21:49 --> Utf8 Class Initialized
DEBUG - 2016-06-21 09:21:49 --> UTF-8 Support Enabled
DEBUG - 2016-06-21 09:21:49 --> URI Class Initialized
DEBUG - 2016-06-21 09:21:49 --> Router Class Initialized
DEBUG - 2016-06-21 09:21:49 --> Output Class Initialized
DEBUG - 2016-06-21 09:21:49 --> Cache file has expired. File deleted
DEBUG - 2016-06-21 09:21:49 --> Security Class Initialized
DEBUG - 2016-06-21 09:21:49 --> Input Class Initialized
DEBUG - 2016-06-21 09:21:49 --> XSS Filtering completed
DEBUG - 2016-06-21 09:21:49 --> XSS Filtering completed
DEBUG - 2016-06-21 09:21:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-21 09:21:49 --> Language Class Initialized
DEBUG - 2016-06-21 09:21:49 --> Loader Class Initialized
DEBUG - 2016-06-21 09:21:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-21 09:21:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-21 09:21:49 --> Helper loaded: url_helper
DEBUG - 2016-06-21 09:21:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-21 09:21:49 --> Helper loaded: file_helper
DEBUG - 2016-06-21 09:21:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-21 09:21:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-21 09:21:49 --> Helper loaded: conf_helper
DEBUG - 2016-06-21 09:21:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-21 09:21:49 --> Check Exists common_helper.php: No
DEBUG - 2016-06-21 09:21:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-21 09:21:49 --> Helper loaded: common_helper
DEBUG - 2016-06-21 09:21:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-21 09:21:49 --> Helper loaded: common_helper
DEBUG - 2016-06-21 09:21:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-21 09:21:49 --> Helper loaded: form_helper
DEBUG - 2016-06-21 09:21:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-21 09:21:49 --> Helper loaded: security_helper
DEBUG - 2016-06-21 09:21:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-21 09:21:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-21 09:21:49 --> Helper loaded: lang_helper
DEBUG - 2016-06-21 09:21:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-21 09:21:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-21 09:21:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-21 09:21:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-21 09:21:49 --> Helper loaded: atlant_helper
DEBUG - 2016-06-21 09:21:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-21 09:21:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-21 09:21:49 --> Helper loaded: crypto_helper
DEBUG - 2016-06-21 09:21:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-21 09:21:49 --> Database Driver Class Initialized
DEBUG - 2016-06-21 09:21:49 --> Session Class Initialized
DEBUG - 2016-06-21 09:21:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-21 09:21:49 --> Helper loaded: string_helper
DEBUG - 2016-06-21 09:21:50 --> Session routines successfully run
DEBUG - 2016-06-21 09:21:50 --> Native_session Class Initialized
DEBUG - 2016-06-21 09:21:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-21 09:21:50 --> Form Validation Class Initialized
DEBUG - 2016-06-21 09:21:50 --> Form Validation Class Initialized
DEBUG - 2016-06-21 09:21:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-21 09:21:50 --> Controller Class Initialized
DEBUG - 2016-06-21 09:21:50 --> Carabiner: Library initialized.
DEBUG - 2016-06-21 09:21:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-21 09:21:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-21 09:21:50 --> Carabiner: library configured.
DEBUG - 2016-06-21 09:21:50 --> Carabiner: library configured.
DEBUG - 2016-06-21 09:21:50 --> User Agent Class Initialized
DEBUG - 2016-06-21 09:21:50 --> Model Class Initialized
DEBUG - 2016-06-21 09:21:50 --> Model Class Initialized
DEBUG - 2016-06-21 09:21:50 --> Model Class Initialized
DEBUG - 2016-06-21 09:21:50 --> Model Class Initialized
DEBUG - 2016-06-21 09:21:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-06-21 09:21:50 --> Pagination Class Initialized
DEBUG - 2016-06-21 09:21:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-21 09:21:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/index.php
DEBUG - 2016-06-21 09:21:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-21 09:21:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-21 09:21:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-21 09:21:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-21 09:21:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-06-21 09:21:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-21 09:21:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-21 09:21:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-21 09:21:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-21 09:21:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-21 09:21:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-21 09:21:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-06-21 09:21:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-21 09:21:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-21 09:21:50 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c2a3e0401bd35d4fcac4bae5f9412231
DEBUG - 2016-06-21 09:21:50 --> Final output sent to browser
DEBUG - 2016-06-21 09:21:50 --> Total execution time: 0.5388
DEBUG - 2016-06-21 09:21:51 --> Config Class Initialized
DEBUG - 2016-06-21 09:21:51 --> Hooks Class Initialized
DEBUG - 2016-06-21 09:21:51 --> Utf8 Class Initialized
DEBUG - 2016-06-21 09:21:51 --> UTF-8 Support Enabled
DEBUG - 2016-06-21 09:21:51 --> URI Class Initialized
DEBUG - 2016-06-21 09:21:51 --> Router Class Initialized
ERROR - 2016-06-21 09:21:51 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-06-21 09:21:56 --> Config Class Initialized
DEBUG - 2016-06-21 09:21:56 --> Hooks Class Initialized
DEBUG - 2016-06-21 09:21:56 --> Utf8 Class Initialized
DEBUG - 2016-06-21 09:21:56 --> UTF-8 Support Enabled
DEBUG - 2016-06-21 09:21:56 --> URI Class Initialized
DEBUG - 2016-06-21 09:21:56 --> Router Class Initialized
DEBUG - 2016-06-21 09:21:56 --> Output Class Initialized
DEBUG - 2016-06-21 09:21:56 --> Cache file has expired. File deleted
DEBUG - 2016-06-21 09:21:56 --> Security Class Initialized
DEBUG - 2016-06-21 09:21:56 --> Input Class Initialized
DEBUG - 2016-06-21 09:21:56 --> XSS Filtering completed
DEBUG - 2016-06-21 09:21:56 --> XSS Filtering completed
DEBUG - 2016-06-21 09:21:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-21 09:21:56 --> Language Class Initialized
DEBUG - 2016-06-21 09:21:56 --> Loader Class Initialized
DEBUG - 2016-06-21 09:21:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-21 09:21:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-21 09:21:56 --> Helper loaded: url_helper
DEBUG - 2016-06-21 09:21:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-21 09:21:56 --> Helper loaded: file_helper
DEBUG - 2016-06-21 09:21:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-21 09:21:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-21 09:21:56 --> Helper loaded: conf_helper
DEBUG - 2016-06-21 09:21:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-21 09:21:57 --> Check Exists common_helper.php: No
DEBUG - 2016-06-21 09:21:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-21 09:21:57 --> Helper loaded: common_helper
DEBUG - 2016-06-21 09:21:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-21 09:21:57 --> Helper loaded: common_helper
DEBUG - 2016-06-21 09:21:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-21 09:21:57 --> Helper loaded: form_helper
DEBUG - 2016-06-21 09:21:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-21 09:21:57 --> Helper loaded: security_helper
DEBUG - 2016-06-21 09:21:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-21 09:21:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-21 09:21:57 --> Helper loaded: lang_helper
DEBUG - 2016-06-21 09:21:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-21 09:21:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-21 09:21:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-21 09:21:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-21 09:21:57 --> Helper loaded: atlant_helper
DEBUG - 2016-06-21 09:21:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-21 09:21:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-21 09:21:57 --> Helper loaded: crypto_helper
DEBUG - 2016-06-21 09:21:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-21 09:21:57 --> Database Driver Class Initialized
DEBUG - 2016-06-21 09:21:57 --> Session Class Initialized
DEBUG - 2016-06-21 09:21:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-21 09:21:57 --> Helper loaded: string_helper
DEBUG - 2016-06-21 09:21:57 --> Session routines successfully run
DEBUG - 2016-06-21 09:21:57 --> Native_session Class Initialized
DEBUG - 2016-06-21 09:21:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-21 09:21:57 --> Form Validation Class Initialized
DEBUG - 2016-06-21 09:21:57 --> Form Validation Class Initialized
DEBUG - 2016-06-21 09:21:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-21 09:21:57 --> Controller Class Initialized
DEBUG - 2016-06-21 09:21:57 --> Carabiner: Library initialized.
DEBUG - 2016-06-21 09:21:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-21 09:21:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-21 09:21:57 --> Carabiner: library configured.
DEBUG - 2016-06-21 09:21:57 --> Carabiner: library configured.
DEBUG - 2016-06-21 09:21:57 --> User Agent Class Initialized
DEBUG - 2016-06-21 09:21:57 --> Model Class Initialized
DEBUG - 2016-06-21 09:21:57 --> Model Class Initialized
DEBUG - 2016-06-21 09:21:57 --> Model Class Initialized
DEBUG - 2016-06-21 09:21:57 --> Model Class Initialized
DEBUG - 2016-06-21 09:21:57 --> Model Class Initialized
DEBUG - 2016-06-21 09:21:57 --> Model Class Initialized
DEBUG - 2016-06-21 09:21:57 --> Model Class Initialized
DEBUG - 2016-06-21 09:21:57 --> Model Class Initialized
DEBUG - 2016-06-21 09:21:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-06-21 09:21:58 --> Pagination Class Initialized
DEBUG - 2016-06-21 09:21:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-21 09:21:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-06-21 09:21:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-21 09:21:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-21 09:21:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-21 09:21:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-21 09:21:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-06-21 09:21:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-21 09:21:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-21 09:21:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-21 09:21:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-21 09:21:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-21 09:21:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-21 09:21:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-06-21 09:21:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-21 09:21:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-21 09:21:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-06-21 09:21:59 --> Final output sent to browser
DEBUG - 2016-06-21 09:21:59 --> Total execution time: 2.2014
DEBUG - 2016-06-21 09:22:02 --> Config Class Initialized
DEBUG - 2016-06-21 09:22:02 --> Hooks Class Initialized
DEBUG - 2016-06-21 09:22:02 --> Utf8 Class Initialized
DEBUG - 2016-06-21 09:22:02 --> UTF-8 Support Enabled
DEBUG - 2016-06-21 09:22:02 --> URI Class Initialized
DEBUG - 2016-06-21 09:22:02 --> Router Class Initialized
DEBUG - 2016-06-21 09:22:02 --> Output Class Initialized
DEBUG - 2016-06-21 09:22:02 --> Cache file has expired. File deleted
DEBUG - 2016-06-21 09:22:02 --> Security Class Initialized
DEBUG - 2016-06-21 09:22:02 --> Input Class Initialized
DEBUG - 2016-06-21 09:22:02 --> XSS Filtering completed
DEBUG - 2016-06-21 09:22:02 --> XSS Filtering completed
DEBUG - 2016-06-21 09:22:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-21 09:22:02 --> Language Class Initialized
DEBUG - 2016-06-21 09:22:02 --> Loader Class Initialized
DEBUG - 2016-06-21 09:22:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-21 09:22:02 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-21 09:22:02 --> Helper loaded: url_helper
DEBUG - 2016-06-21 09:22:02 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-21 09:22:02 --> Helper loaded: file_helper
DEBUG - 2016-06-21 09:22:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-21 09:22:02 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-21 09:22:02 --> Helper loaded: conf_helper
DEBUG - 2016-06-21 09:22:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-21 09:22:02 --> Check Exists common_helper.php: No
DEBUG - 2016-06-21 09:22:02 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-21 09:22:02 --> Helper loaded: common_helper
DEBUG - 2016-06-21 09:22:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-21 09:22:02 --> Helper loaded: common_helper
DEBUG - 2016-06-21 09:22:02 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-21 09:22:02 --> Helper loaded: form_helper
DEBUG - 2016-06-21 09:22:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-21 09:22:02 --> Helper loaded: security_helper
DEBUG - 2016-06-21 09:22:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-21 09:22:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-21 09:22:02 --> Helper loaded: lang_helper
DEBUG - 2016-06-21 09:22:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-21 09:22:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-21 09:22:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-21 09:22:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-21 09:22:02 --> Helper loaded: atlant_helper
DEBUG - 2016-06-21 09:22:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-21 09:22:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-21 09:22:02 --> Helper loaded: crypto_helper
DEBUG - 2016-06-21 09:22:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-21 09:22:02 --> Database Driver Class Initialized
DEBUG - 2016-06-21 09:22:02 --> Session Class Initialized
DEBUG - 2016-06-21 09:22:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-21 09:22:02 --> Helper loaded: string_helper
DEBUG - 2016-06-21 09:22:02 --> Session routines successfully run
DEBUG - 2016-06-21 09:22:02 --> Native_session Class Initialized
DEBUG - 2016-06-21 09:22:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-21 09:22:02 --> Form Validation Class Initialized
DEBUG - 2016-06-21 09:22:02 --> Form Validation Class Initialized
DEBUG - 2016-06-21 09:22:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-21 09:22:02 --> Controller Class Initialized
DEBUG - 2016-06-21 09:22:02 --> Carabiner: Library initialized.
DEBUG - 2016-06-21 09:22:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-21 09:22:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-21 09:22:02 --> Carabiner: library configured.
DEBUG - 2016-06-21 09:22:02 --> Carabiner: library configured.
DEBUG - 2016-06-21 09:22:02 --> User Agent Class Initialized
DEBUG - 2016-06-21 09:22:02 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:02 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:02 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:02 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:02 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-06-21 09:22:02 --> Pagination Class Initialized
DEBUG - 2016-06-21 09:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-21 09:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-06-21 09:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-21 09:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-21 09:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-21 09:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-21 09:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-06-21 09:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-21 09:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-21 09:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-21 09:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-21 09:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-21 09:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-21 09:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-06-21 09:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-21 09:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-21 09:22:02 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5cf2ac055215a66f98ba4d6c33c8329d
DEBUG - 2016-06-21 09:22:02 --> Final output sent to browser
DEBUG - 2016-06-21 09:22:02 --> Total execution time: 0.7559
DEBUG - 2016-06-21 09:22:03 --> Config Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Hooks Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Utf8 Class Initialized
DEBUG - 2016-06-21 09:22:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-21 09:22:03 --> URI Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Router Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Output Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Security Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Input Class Initialized
DEBUG - 2016-06-21 09:22:03 --> XSS Filtering completed
DEBUG - 2016-06-21 09:22:03 --> XSS Filtering completed
DEBUG - 2016-06-21 09:22:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-21 09:22:03 --> Language Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Loader Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-21 09:22:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-21 09:22:03 --> Helper loaded: url_helper
DEBUG - 2016-06-21 09:22:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-21 09:22:03 --> Helper loaded: file_helper
DEBUG - 2016-06-21 09:22:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-21 09:22:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-21 09:22:03 --> Helper loaded: conf_helper
DEBUG - 2016-06-21 09:22:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-21 09:22:03 --> Check Exists common_helper.php: No
DEBUG - 2016-06-21 09:22:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-21 09:22:03 --> Helper loaded: common_helper
DEBUG - 2016-06-21 09:22:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-21 09:22:03 --> Helper loaded: common_helper
DEBUG - 2016-06-21 09:22:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-21 09:22:03 --> Helper loaded: form_helper
DEBUG - 2016-06-21 09:22:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-21 09:22:03 --> Helper loaded: security_helper
DEBUG - 2016-06-21 09:22:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-21 09:22:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-21 09:22:03 --> Helper loaded: lang_helper
DEBUG - 2016-06-21 09:22:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-21 09:22:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-21 09:22:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-21 09:22:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-21 09:22:03 --> Helper loaded: atlant_helper
DEBUG - 2016-06-21 09:22:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-21 09:22:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-21 09:22:03 --> Helper loaded: crypto_helper
DEBUG - 2016-06-21 09:22:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-21 09:22:03 --> Database Driver Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Session Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-21 09:22:03 --> Helper loaded: string_helper
DEBUG - 2016-06-21 09:22:03 --> Session routines successfully run
DEBUG - 2016-06-21 09:22:03 --> Native_session Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-21 09:22:03 --> Form Validation Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Form Validation Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-21 09:22:03 --> Controller Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Carabiner: Library initialized.
DEBUG - 2016-06-21 09:22:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-21 09:22:03 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-21 09:22:03 --> Carabiner: library configured.
DEBUG - 2016-06-21 09:22:03 --> Carabiner: library configured.
DEBUG - 2016-06-21 09:22:03 --> User Agent Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Config Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Hooks Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Utf8 Class Initialized
DEBUG - 2016-06-21 09:22:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-21 09:22:03 --> URI Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Router Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Output Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Cache file has expired. File deleted
DEBUG - 2016-06-21 09:22:03 --> Security Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Input Class Initialized
DEBUG - 2016-06-21 09:22:03 --> XSS Filtering completed
DEBUG - 2016-06-21 09:22:03 --> XSS Filtering completed
DEBUG - 2016-06-21 09:22:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-21 09:22:03 --> Language Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Loader Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-21 09:22:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-21 09:22:03 --> Helper loaded: url_helper
DEBUG - 2016-06-21 09:22:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-21 09:22:03 --> Helper loaded: file_helper
DEBUG - 2016-06-21 09:22:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-21 09:22:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-21 09:22:03 --> Helper loaded: conf_helper
DEBUG - 2016-06-21 09:22:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-21 09:22:03 --> Check Exists common_helper.php: No
DEBUG - 2016-06-21 09:22:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-21 09:22:03 --> Helper loaded: common_helper
DEBUG - 2016-06-21 09:22:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-21 09:22:03 --> Helper loaded: common_helper
DEBUG - 2016-06-21 09:22:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-21 09:22:03 --> Helper loaded: form_helper
DEBUG - 2016-06-21 09:22:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-21 09:22:03 --> Helper loaded: security_helper
DEBUG - 2016-06-21 09:22:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-21 09:22:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-21 09:22:03 --> Helper loaded: lang_helper
DEBUG - 2016-06-21 09:22:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-21 09:22:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-21 09:22:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-21 09:22:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-21 09:22:03 --> Helper loaded: atlant_helper
DEBUG - 2016-06-21 09:22:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-21 09:22:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-21 09:22:03 --> Helper loaded: crypto_helper
DEBUG - 2016-06-21 09:22:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-21 09:22:03 --> Database Driver Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Session Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-21 09:22:03 --> Helper loaded: string_helper
DEBUG - 2016-06-21 09:22:03 --> Session routines successfully run
DEBUG - 2016-06-21 09:22:03 --> Native_session Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-21 09:22:03 --> Form Validation Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Form Validation Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-21 09:22:03 --> Controller Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Carabiner: Library initialized.
DEBUG - 2016-06-21 09:22:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-21 09:22:03 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-21 09:22:03 --> Carabiner: library configured.
DEBUG - 2016-06-21 09:22:03 --> Carabiner: library configured.
DEBUG - 2016-06-21 09:22:03 --> User Agent Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-06-21 09:22:03 --> Pagination Class Initialized
DEBUG - 2016-06-21 09:22:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-21 09:22:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-06-21 09:22:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-21 09:22:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-21 09:22:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-21 09:22:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-21 09:22:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-06-21 09:22:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-21 09:22:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-21 09:22:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-21 09:22:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-21 09:22:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-21 09:22:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-21 09:22:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-06-21 09:22:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-21 09:22:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-21 09:22:03 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-06-21 09:22:03 --> Final output sent to browser
DEBUG - 2016-06-21 09:22:03 --> Total execution time: 0.2932
DEBUG - 2016-06-21 09:22:09 --> Config Class Initialized
DEBUG - 2016-06-21 09:22:09 --> Hooks Class Initialized
DEBUG - 2016-06-21 09:22:09 --> Utf8 Class Initialized
DEBUG - 2016-06-21 09:22:09 --> UTF-8 Support Enabled
DEBUG - 2016-06-21 09:22:09 --> URI Class Initialized
DEBUG - 2016-06-21 09:22:09 --> Router Class Initialized
DEBUG - 2016-06-21 09:22:09 --> Output Class Initialized
DEBUG - 2016-06-21 09:22:09 --> Cache file has expired. File deleted
DEBUG - 2016-06-21 09:22:09 --> Security Class Initialized
DEBUG - 2016-06-21 09:22:09 --> Input Class Initialized
DEBUG - 2016-06-21 09:22:09 --> XSS Filtering completed
DEBUG - 2016-06-21 09:22:09 --> XSS Filtering completed
DEBUG - 2016-06-21 09:22:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-21 09:22:09 --> Language Class Initialized
DEBUG - 2016-06-21 09:22:09 --> Loader Class Initialized
DEBUG - 2016-06-21 09:22:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-21 09:22:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-21 09:22:09 --> Helper loaded: url_helper
DEBUG - 2016-06-21 09:22:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-21 09:22:09 --> Helper loaded: file_helper
DEBUG - 2016-06-21 09:22:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-21 09:22:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-21 09:22:09 --> Helper loaded: conf_helper
DEBUG - 2016-06-21 09:22:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-21 09:22:09 --> Check Exists common_helper.php: No
DEBUG - 2016-06-21 09:22:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-21 09:22:09 --> Helper loaded: common_helper
DEBUG - 2016-06-21 09:22:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-21 09:22:09 --> Helper loaded: common_helper
DEBUG - 2016-06-21 09:22:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-21 09:22:09 --> Helper loaded: form_helper
DEBUG - 2016-06-21 09:22:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-21 09:22:09 --> Helper loaded: security_helper
DEBUG - 2016-06-21 09:22:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-21 09:22:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-21 09:22:09 --> Helper loaded: lang_helper
DEBUG - 2016-06-21 09:22:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-21 09:22:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-21 09:22:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-21 09:22:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-21 09:22:09 --> Helper loaded: atlant_helper
DEBUG - 2016-06-21 09:22:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-21 09:22:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-21 09:22:09 --> Helper loaded: crypto_helper
DEBUG - 2016-06-21 09:22:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-21 09:22:09 --> Database Driver Class Initialized
DEBUG - 2016-06-21 09:22:09 --> Session Class Initialized
DEBUG - 2016-06-21 09:22:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-21 09:22:09 --> Helper loaded: string_helper
DEBUG - 2016-06-21 09:22:09 --> Session routines successfully run
DEBUG - 2016-06-21 09:22:09 --> Native_session Class Initialized
DEBUG - 2016-06-21 09:22:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-21 09:22:09 --> Form Validation Class Initialized
DEBUG - 2016-06-21 09:22:09 --> Form Validation Class Initialized
DEBUG - 2016-06-21 09:22:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-21 09:22:09 --> Controller Class Initialized
DEBUG - 2016-06-21 09:22:09 --> Carabiner: Library initialized.
DEBUG - 2016-06-21 09:22:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-21 09:22:09 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-21 09:22:09 --> Carabiner: library configured.
DEBUG - 2016-06-21 09:22:09 --> Carabiner: library configured.
DEBUG - 2016-06-21 09:22:09 --> User Agent Class Initialized
DEBUG - 2016-06-21 09:22:09 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:09 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:09 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:09 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:09 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-21 09:22:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/detail.php
DEBUG - 2016-06-21 09:22:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-21 09:22:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-21 09:22:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-21 09:22:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-21 09:22:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_js.php
DEBUG - 2016-06-21 09:22:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_isian_js.php
DEBUG - 2016-06-21 09:22:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-21 09:22:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-21 09:22:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-21 09:22:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-21 09:22:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-21 09:22:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-21 09:22:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_js.php
DEBUG - 2016-06-21 09:22:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_isian_js.php
DEBUG - 2016-06-21 09:22:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-21 09:22:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-21 09:22:10 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/69a0bddb6cf23277c5f8caeb26e810f0
DEBUG - 2016-06-21 09:22:10 --> Final output sent to browser
DEBUG - 2016-06-21 09:22:10 --> Total execution time: 0.3792
DEBUG - 2016-06-21 09:22:10 --> Config Class Initialized
DEBUG - 2016-06-21 09:22:10 --> Hooks Class Initialized
DEBUG - 2016-06-21 09:22:10 --> Utf8 Class Initialized
DEBUG - 2016-06-21 09:22:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-21 09:22:10 --> URI Class Initialized
DEBUG - 2016-06-21 09:22:10 --> Router Class Initialized
DEBUG - 2016-06-21 09:22:10 --> Output Class Initialized
DEBUG - 2016-06-21 09:22:10 --> Security Class Initialized
DEBUG - 2016-06-21 09:22:10 --> Input Class Initialized
DEBUG - 2016-06-21 09:22:10 --> XSS Filtering completed
DEBUG - 2016-06-21 09:22:10 --> XSS Filtering completed
DEBUG - 2016-06-21 09:22:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-21 09:22:10 --> Language Class Initialized
DEBUG - 2016-06-21 09:22:10 --> Loader Class Initialized
DEBUG - 2016-06-21 09:22:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-21 09:22:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-21 09:22:10 --> Helper loaded: url_helper
DEBUG - 2016-06-21 09:22:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-21 09:22:10 --> Helper loaded: file_helper
DEBUG - 2016-06-21 09:22:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-21 09:22:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-21 09:22:10 --> Helper loaded: conf_helper
DEBUG - 2016-06-21 09:22:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-21 09:22:10 --> Check Exists common_helper.php: No
DEBUG - 2016-06-21 09:22:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-21 09:22:10 --> Helper loaded: common_helper
DEBUG - 2016-06-21 09:22:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-21 09:22:10 --> Helper loaded: common_helper
DEBUG - 2016-06-21 09:22:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-21 09:22:10 --> Helper loaded: form_helper
DEBUG - 2016-06-21 09:22:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-21 09:22:10 --> Helper loaded: security_helper
DEBUG - 2016-06-21 09:22:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-21 09:22:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-21 09:22:10 --> Helper loaded: lang_helper
DEBUG - 2016-06-21 09:22:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-21 09:22:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-21 09:22:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-21 09:22:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-21 09:22:10 --> Helper loaded: atlant_helper
DEBUG - 2016-06-21 09:22:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-21 09:22:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-21 09:22:10 --> Helper loaded: crypto_helper
DEBUG - 2016-06-21 09:22:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-21 09:22:10 --> Database Driver Class Initialized
DEBUG - 2016-06-21 09:22:10 --> Session Class Initialized
DEBUG - 2016-06-21 09:22:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-21 09:22:10 --> Helper loaded: string_helper
DEBUG - 2016-06-21 09:22:10 --> Session routines successfully run
DEBUG - 2016-06-21 09:22:10 --> Native_session Class Initialized
DEBUG - 2016-06-21 09:22:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-21 09:22:10 --> Form Validation Class Initialized
DEBUG - 2016-06-21 09:22:10 --> Form Validation Class Initialized
DEBUG - 2016-06-21 09:22:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-21 09:22:10 --> Controller Class Initialized
DEBUG - 2016-06-21 09:22:10 --> Carabiner: Library initialized.
DEBUG - 2016-06-21 09:22:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-21 09:22:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-21 09:22:10 --> Carabiner: library configured.
DEBUG - 2016-06-21 09:22:10 --> Carabiner: library configured.
DEBUG - 2016-06-21 09:22:10 --> User Agent Class Initialized
DEBUG - 2016-06-21 09:22:10 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:10 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:10 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:10 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:10 --> Model Class Initialized
ERROR - 2016-06-21 09:22:10 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;favicon.ico&quot;
LINE 9: ...sidika&quot;.&quot;tr_peserta_diklat&quot;.&quot;id_peserta_diklat&quot; = 'favicon.i...
                                                             ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-06-21 09:22:10 --> DB Transaction Failure
ERROR - 2016-06-21 09:22:10 --> Query error: ERROR:  invalid input syntax for integer: "favicon.ico"
LINE 9: ...sidika"."tr_peserta_diklat"."id_peserta_diklat" = 'favicon.i...
                                                             ^
DEBUG - 2016-06-21 09:22:11 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-06-21 09:22:12 --> Config Class Initialized
DEBUG - 2016-06-21 09:22:12 --> Hooks Class Initialized
DEBUG - 2016-06-21 09:22:12 --> Utf8 Class Initialized
DEBUG - 2016-06-21 09:22:12 --> UTF-8 Support Enabled
DEBUG - 2016-06-21 09:22:13 --> URI Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Router Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Output Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Cache file has expired. File deleted
DEBUG - 2016-06-21 09:22:13 --> Security Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Input Class Initialized
DEBUG - 2016-06-21 09:22:13 --> XSS Filtering completed
DEBUG - 2016-06-21 09:22:13 --> XSS Filtering completed
DEBUG - 2016-06-21 09:22:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-21 09:22:13 --> Language Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Loader Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-21 09:22:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-21 09:22:13 --> Helper loaded: url_helper
DEBUG - 2016-06-21 09:22:13 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-21 09:22:13 --> Helper loaded: file_helper
DEBUG - 2016-06-21 09:22:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-21 09:22:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-21 09:22:13 --> Helper loaded: conf_helper
DEBUG - 2016-06-21 09:22:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-21 09:22:13 --> Check Exists common_helper.php: No
DEBUG - 2016-06-21 09:22:13 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-21 09:22:13 --> Helper loaded: common_helper
DEBUG - 2016-06-21 09:22:13 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-21 09:22:13 --> Helper loaded: common_helper
DEBUG - 2016-06-21 09:22:13 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-21 09:22:13 --> Helper loaded: form_helper
DEBUG - 2016-06-21 09:22:13 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-21 09:22:13 --> Helper loaded: security_helper
DEBUG - 2016-06-21 09:22:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-21 09:22:13 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-21 09:22:13 --> Helper loaded: lang_helper
DEBUG - 2016-06-21 09:22:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-21 09:22:13 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-21 09:22:13 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-21 09:22:13 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-21 09:22:13 --> Helper loaded: atlant_helper
DEBUG - 2016-06-21 09:22:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-21 09:22:13 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-21 09:22:13 --> Helper loaded: crypto_helper
DEBUG - 2016-06-21 09:22:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-21 09:22:13 --> Database Driver Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Session Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-21 09:22:13 --> Helper loaded: string_helper
DEBUG - 2016-06-21 09:22:13 --> Session routines successfully run
DEBUG - 2016-06-21 09:22:13 --> Native_session Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-21 09:22:13 --> Form Validation Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Form Validation Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-21 09:22:13 --> Controller Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Carabiner: Library initialized.
DEBUG - 2016-06-21 09:22:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-21 09:22:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-21 09:22:13 --> Carabiner: library configured.
DEBUG - 2016-06-21 09:22:13 --> Carabiner: library configured.
DEBUG - 2016-06-21 09:22:13 --> User Agent Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-06-21 09:22:13 --> Pagination Class Initialized
DEBUG - 2016-06-21 09:22:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-21 09:22:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-06-21 09:22:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-21 09:22:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-21 09:22:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-21 09:22:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-21 09:22:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-06-21 09:22:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-21 09:22:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-21 09:22:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-21 09:22:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-21 09:22:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-21 09:22:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-21 09:22:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-06-21 09:22:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-21 09:22:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-21 09:22:13 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5cf2ac055215a66f98ba4d6c33c8329d
DEBUG - 2016-06-21 09:22:13 --> Final output sent to browser
DEBUG - 2016-06-21 09:22:13 --> Total execution time: 0.3412
DEBUG - 2016-06-21 09:22:13 --> Config Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Hooks Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Utf8 Class Initialized
DEBUG - 2016-06-21 09:22:13 --> UTF-8 Support Enabled
DEBUG - 2016-06-21 09:22:13 --> URI Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Router Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Output Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Security Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Input Class Initialized
DEBUG - 2016-06-21 09:22:13 --> XSS Filtering completed
DEBUG - 2016-06-21 09:22:13 --> XSS Filtering completed
DEBUG - 2016-06-21 09:22:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-21 09:22:13 --> Language Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Loader Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-21 09:22:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-21 09:22:13 --> Helper loaded: url_helper
DEBUG - 2016-06-21 09:22:13 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-21 09:22:13 --> Helper loaded: file_helper
DEBUG - 2016-06-21 09:22:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-21 09:22:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-21 09:22:13 --> Helper loaded: conf_helper
DEBUG - 2016-06-21 09:22:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-21 09:22:13 --> Check Exists common_helper.php: No
DEBUG - 2016-06-21 09:22:13 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-21 09:22:13 --> Helper loaded: common_helper
DEBUG - 2016-06-21 09:22:13 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-21 09:22:13 --> Helper loaded: common_helper
DEBUG - 2016-06-21 09:22:13 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-21 09:22:13 --> Helper loaded: form_helper
DEBUG - 2016-06-21 09:22:13 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-21 09:22:13 --> Helper loaded: security_helper
DEBUG - 2016-06-21 09:22:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-21 09:22:13 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-21 09:22:13 --> Helper loaded: lang_helper
DEBUG - 2016-06-21 09:22:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-21 09:22:13 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-21 09:22:13 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-21 09:22:13 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-21 09:22:13 --> Helper loaded: atlant_helper
DEBUG - 2016-06-21 09:22:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-21 09:22:13 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-21 09:22:13 --> Helper loaded: crypto_helper
DEBUG - 2016-06-21 09:22:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-21 09:22:13 --> Database Driver Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Session Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-21 09:22:13 --> Helper loaded: string_helper
DEBUG - 2016-06-21 09:22:13 --> Session routines successfully run
DEBUG - 2016-06-21 09:22:13 --> Native_session Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-21 09:22:13 --> Form Validation Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Form Validation Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-21 09:22:13 --> Controller Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Carabiner: Library initialized.
DEBUG - 2016-06-21 09:22:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-21 09:22:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-21 09:22:13 --> Carabiner: library configured.
DEBUG - 2016-06-21 09:22:13 --> Carabiner: library configured.
DEBUG - 2016-06-21 09:22:13 --> User Agent Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Config Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Hooks Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Utf8 Class Initialized
DEBUG - 2016-06-21 09:22:13 --> UTF-8 Support Enabled
DEBUG - 2016-06-21 09:22:13 --> URI Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Router Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Output Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Cache file has expired. File deleted
DEBUG - 2016-06-21 09:22:13 --> Security Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Input Class Initialized
DEBUG - 2016-06-21 09:22:13 --> XSS Filtering completed
DEBUG - 2016-06-21 09:22:13 --> XSS Filtering completed
DEBUG - 2016-06-21 09:22:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-21 09:22:13 --> Language Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Loader Class Initialized
DEBUG - 2016-06-21 09:22:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-21 09:22:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-21 09:22:13 --> Helper loaded: url_helper
DEBUG - 2016-06-21 09:22:13 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-21 09:22:13 --> Helper loaded: file_helper
DEBUG - 2016-06-21 09:22:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-21 09:22:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-21 09:22:13 --> Helper loaded: conf_helper
DEBUG - 2016-06-21 09:22:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-21 09:22:13 --> Check Exists common_helper.php: No
DEBUG - 2016-06-21 09:22:13 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-21 09:22:14 --> Helper loaded: common_helper
DEBUG - 2016-06-21 09:22:14 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-21 09:22:14 --> Helper loaded: common_helper
DEBUG - 2016-06-21 09:22:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-21 09:22:14 --> Helper loaded: form_helper
DEBUG - 2016-06-21 09:22:14 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-21 09:22:14 --> Helper loaded: security_helper
DEBUG - 2016-06-21 09:22:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-21 09:22:14 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-21 09:22:14 --> Helper loaded: lang_helper
DEBUG - 2016-06-21 09:22:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-21 09:22:14 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-21 09:22:14 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-21 09:22:14 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-21 09:22:14 --> Helper loaded: atlant_helper
DEBUG - 2016-06-21 09:22:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-21 09:22:14 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-21 09:22:14 --> Helper loaded: crypto_helper
DEBUG - 2016-06-21 09:22:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-21 09:22:14 --> Database Driver Class Initialized
DEBUG - 2016-06-21 09:22:14 --> Session Class Initialized
DEBUG - 2016-06-21 09:22:14 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-21 09:22:14 --> Helper loaded: string_helper
DEBUG - 2016-06-21 09:22:14 --> Session routines successfully run
DEBUG - 2016-06-21 09:22:14 --> Native_session Class Initialized
DEBUG - 2016-06-21 09:22:14 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-21 09:22:14 --> Form Validation Class Initialized
DEBUG - 2016-06-21 09:22:14 --> Form Validation Class Initialized
DEBUG - 2016-06-21 09:22:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-21 09:22:14 --> Controller Class Initialized
DEBUG - 2016-06-21 09:22:14 --> Carabiner: Library initialized.
DEBUG - 2016-06-21 09:22:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-21 09:22:14 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-21 09:22:14 --> Carabiner: library configured.
DEBUG - 2016-06-21 09:22:14 --> Carabiner: library configured.
DEBUG - 2016-06-21 09:22:14 --> User Agent Class Initialized
DEBUG - 2016-06-21 09:22:14 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:14 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:14 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:14 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:14 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:14 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:14 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:14 --> Model Class Initialized
DEBUG - 2016-06-21 09:22:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-06-21 09:22:14 --> Pagination Class Initialized
DEBUG - 2016-06-21 09:22:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-21 09:22:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-06-21 09:22:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-21 09:22:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-21 09:22:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-21 09:22:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-21 09:22:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-06-21 09:22:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-21 09:22:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-21 09:22:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-21 09:22:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-21 09:22:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-21 09:22:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-21 09:22:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-06-21 09:22:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-21 09:22:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-21 09:22:14 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-06-21 09:22:14 --> Final output sent to browser
DEBUG - 2016-06-21 09:22:14 --> Total execution time: 0.3667
