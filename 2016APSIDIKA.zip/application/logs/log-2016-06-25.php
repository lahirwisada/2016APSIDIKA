<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-06-25 10:26:10 --> Config Class Initialized
DEBUG - 2016-06-25 10:26:10 --> Hooks Class Initialized
DEBUG - 2016-06-25 10:26:10 --> Utf8 Class Initialized
DEBUG - 2016-06-25 10:26:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 10:26:10 --> URI Class Initialized
DEBUG - 2016-06-25 10:26:10 --> Router Class Initialized
DEBUG - 2016-06-25 10:26:10 --> Output Class Initialized
DEBUG - 2016-06-25 10:26:10 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 10:26:10 --> Security Class Initialized
DEBUG - 2016-06-25 10:26:10 --> Input Class Initialized
DEBUG - 2016-06-25 10:26:10 --> XSS Filtering completed
DEBUG - 2016-06-25 10:26:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 10:26:10 --> Language Class Initialized
DEBUG - 2016-06-25 10:26:11 --> Loader Class Initialized
DEBUG - 2016-06-25 10:26:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 10:26:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 10:26:11 --> Helper loaded: url_helper
DEBUG - 2016-06-25 10:26:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 10:26:11 --> Helper loaded: file_helper
DEBUG - 2016-06-25 10:26:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 10:26:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 10:26:11 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 10:26:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 10:26:11 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 10:26:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 10:26:11 --> Helper loaded: common_helper
DEBUG - 2016-06-25 10:26:11 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 10:26:11 --> Helper loaded: common_helper
DEBUG - 2016-06-25 10:26:11 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 10:26:11 --> Helper loaded: form_helper
DEBUG - 2016-06-25 10:26:11 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 10:26:11 --> Helper loaded: security_helper
DEBUG - 2016-06-25 10:26:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 10:26:11 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 10:26:11 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 10:26:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 10:26:11 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 10:26:11 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 10:26:11 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 10:26:11 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 10:26:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 10:26:11 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 10:26:11 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 10:26:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 10:26:11 --> Database Driver Class Initialized
DEBUG - 2016-06-25 10:26:11 --> Session Class Initialized
DEBUG - 2016-06-25 10:26:11 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 10:26:11 --> Helper loaded: string_helper
DEBUG - 2016-06-25 10:26:11 --> A session cookie was not found.
DEBUG - 2016-06-25 10:26:11 --> Session routines successfully run
DEBUG - 2016-06-25 10:26:11 --> Native_session Class Initialized
DEBUG - 2016-06-25 10:26:11 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 10:26:11 --> Form Validation Class Initialized
DEBUG - 2016-06-25 10:26:11 --> Form Validation Class Initialized
DEBUG - 2016-06-25 10:26:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 10:26:11 --> Controller Class Initialized
DEBUG - 2016-06-25 10:26:11 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 10:26:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 10:26:11 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 10:26:11 --> Carabiner: library configured.
DEBUG - 2016-06-25 10:26:11 --> Carabiner: library configured.
DEBUG - 2016-06-25 10:26:12 --> User Agent Class Initialized
DEBUG - 2016-06-25 10:26:12 --> Model Class Initialized
DEBUG - 2016-06-25 10:26:12 --> Model Class Initialized
DEBUG - 2016-06-25 10:26:12 --> Model Class Initialized
DEBUG - 2016-06-25 10:26:15 --> Model Class Initialized
DEBUG - 2016-06-25 10:26:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-06-25 10:26:15 --> Pagination Class Initialized
DEBUG - 2016-06-25 10:26:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 10:26:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/index.php
DEBUG - 2016-06-25 10:26:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 10:26:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 10:26:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 10:26:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 10:26:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-06-25 10:26:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 10:26:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 10:26:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 10:26:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 10:26:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 10:26:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 10:26:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-06-25 10:26:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 10:26:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 10:26:16 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0afc8ae14bdb2df5b4e2fbf4366db4fc
DEBUG - 2016-06-25 10:26:16 --> Final output sent to browser
DEBUG - 2016-06-25 10:26:16 --> Total execution time: 5.1676
DEBUG - 2016-06-25 10:26:23 --> Config Class Initialized
DEBUG - 2016-06-25 10:26:23 --> Hooks Class Initialized
DEBUG - 2016-06-25 10:26:23 --> Utf8 Class Initialized
DEBUG - 2016-06-25 10:26:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 10:26:23 --> URI Class Initialized
DEBUG - 2016-06-25 10:26:23 --> Router Class Initialized
DEBUG - 2016-06-25 10:26:23 --> Output Class Initialized
DEBUG - 2016-06-25 10:26:23 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 10:26:23 --> Security Class Initialized
DEBUG - 2016-06-25 10:26:23 --> Input Class Initialized
DEBUG - 2016-06-25 10:26:23 --> XSS Filtering completed
DEBUG - 2016-06-25 10:26:23 --> XSS Filtering completed
DEBUG - 2016-06-25 10:26:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 10:26:23 --> Language Class Initialized
DEBUG - 2016-06-25 10:26:23 --> Loader Class Initialized
DEBUG - 2016-06-25 10:26:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 10:26:23 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 10:26:23 --> Helper loaded: url_helper
DEBUG - 2016-06-25 10:26:23 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 10:26:23 --> Helper loaded: file_helper
DEBUG - 2016-06-25 10:26:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 10:26:23 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 10:26:23 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 10:26:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 10:26:23 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 10:26:23 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 10:26:23 --> Helper loaded: common_helper
DEBUG - 2016-06-25 10:26:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 10:26:23 --> Helper loaded: common_helper
DEBUG - 2016-06-25 10:26:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 10:26:23 --> Helper loaded: form_helper
DEBUG - 2016-06-25 10:26:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 10:26:23 --> Helper loaded: security_helper
DEBUG - 2016-06-25 10:26:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 10:26:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 10:26:23 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 10:26:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 10:26:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 10:26:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 10:26:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 10:26:23 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 10:26:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 10:26:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 10:26:23 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 10:26:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 10:26:23 --> Database Driver Class Initialized
DEBUG - 2016-06-25 10:26:24 --> Session Class Initialized
DEBUG - 2016-06-25 10:26:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 10:26:24 --> Helper loaded: string_helper
DEBUG - 2016-06-25 10:26:24 --> Session routines successfully run
DEBUG - 2016-06-25 10:26:24 --> Native_session Class Initialized
DEBUG - 2016-06-25 10:26:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 10:26:24 --> Form Validation Class Initialized
DEBUG - 2016-06-25 10:26:24 --> Form Validation Class Initialized
DEBUG - 2016-06-25 10:26:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 10:26:24 --> Controller Class Initialized
DEBUG - 2016-06-25 10:26:24 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 10:26:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 10:26:24 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 10:26:24 --> Carabiner: library configured.
DEBUG - 2016-06-25 10:26:24 --> Carabiner: library configured.
DEBUG - 2016-06-25 10:26:24 --> User Agent Class Initialized
DEBUG - 2016-06-25 10:26:24 --> Model Class Initialized
DEBUG - 2016-06-25 10:26:24 --> Model Class Initialized
DEBUG - 2016-06-25 10:26:24 --> Model Class Initialized
DEBUG - 2016-06-25 10:26:24 --> Model Class Initialized
DEBUG - 2016-06-25 10:26:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-06-25 10:26:24 --> Pagination Class Initialized
DEBUG - 2016-06-25 10:26:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 10:26:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/index.php
DEBUG - 2016-06-25 10:26:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 10:26:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 10:26:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 10:26:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 10:26:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-06-25 10:26:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 10:26:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 10:26:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 10:26:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 10:26:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 10:26:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 10:26:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-06-25 10:26:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 10:26:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 10:26:24 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0afc8ae14bdb2df5b4e2fbf4366db4fc
DEBUG - 2016-06-25 10:26:24 --> Final output sent to browser
DEBUG - 2016-06-25 10:26:24 --> Total execution time: 0.2246
DEBUG - 2016-06-25 10:26:25 --> Config Class Initialized
DEBUG - 2016-06-25 10:26:25 --> Hooks Class Initialized
DEBUG - 2016-06-25 10:26:25 --> Utf8 Class Initialized
DEBUG - 2016-06-25 10:26:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 10:26:25 --> URI Class Initialized
DEBUG - 2016-06-25 10:26:25 --> Router Class Initialized
ERROR - 2016-06-25 10:26:26 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-06-25 10:26:27 --> Config Class Initialized
DEBUG - 2016-06-25 10:26:27 --> Hooks Class Initialized
DEBUG - 2016-06-25 10:26:27 --> Utf8 Class Initialized
DEBUG - 2016-06-25 10:26:27 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 10:26:27 --> URI Class Initialized
DEBUG - 2016-06-25 10:26:27 --> Router Class Initialized
DEBUG - 2016-06-25 10:26:27 --> Output Class Initialized
DEBUG - 2016-06-25 10:26:27 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 10:26:27 --> Security Class Initialized
DEBUG - 2016-06-25 10:26:27 --> Input Class Initialized
DEBUG - 2016-06-25 10:26:27 --> XSS Filtering completed
DEBUG - 2016-06-25 10:26:27 --> XSS Filtering completed
DEBUG - 2016-06-25 10:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 10:26:27 --> Language Class Initialized
DEBUG - 2016-06-25 10:26:27 --> Loader Class Initialized
DEBUG - 2016-06-25 10:26:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 10:26:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 10:26:27 --> Helper loaded: url_helper
DEBUG - 2016-06-25 10:26:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 10:26:27 --> Helper loaded: file_helper
DEBUG - 2016-06-25 10:26:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 10:26:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 10:26:27 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 10:26:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 10:26:27 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 10:26:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 10:26:27 --> Helper loaded: common_helper
DEBUG - 2016-06-25 10:26:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 10:26:27 --> Helper loaded: common_helper
DEBUG - 2016-06-25 10:26:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 10:26:27 --> Helper loaded: form_helper
DEBUG - 2016-06-25 10:26:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 10:26:27 --> Helper loaded: security_helper
DEBUG - 2016-06-25 10:26:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 10:26:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 10:26:27 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 10:26:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 10:26:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 10:26:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 10:26:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 10:26:27 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 10:26:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 10:26:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 10:26:27 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 10:26:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 10:26:27 --> Database Driver Class Initialized
DEBUG - 2016-06-25 10:26:27 --> Session Class Initialized
DEBUG - 2016-06-25 10:26:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 10:26:27 --> Helper loaded: string_helper
DEBUG - 2016-06-25 10:26:27 --> Session routines successfully run
DEBUG - 2016-06-25 10:26:27 --> Native_session Class Initialized
DEBUG - 2016-06-25 10:26:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 10:26:27 --> Form Validation Class Initialized
DEBUG - 2016-06-25 10:26:27 --> Form Validation Class Initialized
DEBUG - 2016-06-25 10:26:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 10:26:27 --> Controller Class Initialized
DEBUG - 2016-06-25 10:26:27 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 10:26:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 10:26:27 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 10:26:27 --> Carabiner: library configured.
DEBUG - 2016-06-25 10:26:27 --> Carabiner: library configured.
DEBUG - 2016-06-25 10:26:27 --> User Agent Class Initialized
DEBUG - 2016-06-25 10:26:27 --> Model Class Initialized
DEBUG - 2016-06-25 10:26:27 --> Model Class Initialized
DEBUG - 2016-06-25 10:26:27 --> Model Class Initialized
DEBUG - 2016-06-25 10:26:27 --> Model Class Initialized
DEBUG - 2016-06-25 10:26:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-06-25 10:26:27 --> Pagination Class Initialized
DEBUG - 2016-06-25 10:26:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 10:26:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/index.php
DEBUG - 2016-06-25 10:26:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 10:26:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 10:26:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 10:26:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 10:26:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-06-25 10:26:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 10:26:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 10:26:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 10:26:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 10:26:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 10:26:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 10:26:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-06-25 10:26:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 10:26:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 10:26:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0afc8ae14bdb2df5b4e2fbf4366db4fc
DEBUG - 2016-06-25 10:26:27 --> Final output sent to browser
DEBUG - 2016-06-25 10:26:27 --> Total execution time: 0.2561
DEBUG - 2016-06-25 10:51:53 --> Config Class Initialized
DEBUG - 2016-06-25 10:51:53 --> Hooks Class Initialized
DEBUG - 2016-06-25 10:51:53 --> Utf8 Class Initialized
DEBUG - 2016-06-25 10:51:53 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 10:51:53 --> URI Class Initialized
DEBUG - 2016-06-25 10:51:53 --> Router Class Initialized
DEBUG - 2016-06-25 10:51:53 --> Output Class Initialized
DEBUG - 2016-06-25 10:51:53 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 10:51:53 --> Security Class Initialized
DEBUG - 2016-06-25 10:51:53 --> Input Class Initialized
DEBUG - 2016-06-25 10:51:53 --> XSS Filtering completed
DEBUG - 2016-06-25 10:51:53 --> XSS Filtering completed
DEBUG - 2016-06-25 10:51:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 10:51:54 --> Language Class Initialized
DEBUG - 2016-06-25 10:51:54 --> Loader Class Initialized
DEBUG - 2016-06-25 10:51:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 10:51:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 10:51:54 --> Helper loaded: url_helper
DEBUG - 2016-06-25 10:51:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 10:51:54 --> Helper loaded: file_helper
DEBUG - 2016-06-25 10:51:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 10:51:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 10:51:54 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 10:51:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 10:51:54 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 10:51:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 10:51:54 --> Helper loaded: common_helper
DEBUG - 2016-06-25 10:51:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 10:51:54 --> Helper loaded: common_helper
DEBUG - 2016-06-25 10:51:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 10:51:54 --> Helper loaded: form_helper
DEBUG - 2016-06-25 10:51:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 10:51:54 --> Helper loaded: security_helper
DEBUG - 2016-06-25 10:51:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 10:51:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 10:51:54 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 10:51:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 10:51:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 10:51:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 10:51:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 10:51:54 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 10:51:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 10:51:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 10:51:54 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 10:51:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 10:51:55 --> Database Driver Class Initialized
DEBUG - 2016-06-25 10:51:55 --> Session Class Initialized
DEBUG - 2016-06-25 10:51:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 10:51:55 --> Helper loaded: string_helper
DEBUG - 2016-06-25 10:51:55 --> Session routines successfully run
DEBUG - 2016-06-25 10:51:55 --> Native_session Class Initialized
DEBUG - 2016-06-25 10:51:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 10:51:55 --> Form Validation Class Initialized
DEBUG - 2016-06-25 10:51:55 --> Form Validation Class Initialized
DEBUG - 2016-06-25 10:51:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 10:51:55 --> Controller Class Initialized
DEBUG - 2016-06-25 10:51:55 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 10:51:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 10:51:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 10:51:55 --> Carabiner: library configured.
DEBUG - 2016-06-25 10:51:55 --> Carabiner: library configured.
DEBUG - 2016-06-25 10:51:56 --> User Agent Class Initialized
DEBUG - 2016-06-25 10:51:56 --> Model Class Initialized
DEBUG - 2016-06-25 10:51:56 --> Model Class Initialized
DEBUG - 2016-06-25 10:51:56 --> Model Class Initialized
DEBUG - 2016-06-25 10:51:57 --> Model Class Initialized
DEBUG - 2016-06-25 10:51:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-06-25 10:51:57 --> Pagination Class Initialized
DEBUG - 2016-06-25 10:51:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 10:51:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/index.php
DEBUG - 2016-06-25 10:51:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 10:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 10:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 10:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 10:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-06-25 10:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 10:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 10:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 10:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 10:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 10:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 10:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-06-25 10:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 10:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 10:51:58 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0afc8ae14bdb2df5b4e2fbf4366db4fc
DEBUG - 2016-06-25 10:51:58 --> Final output sent to browser
DEBUG - 2016-06-25 10:51:58 --> Total execution time: 4.5490
DEBUG - 2016-06-25 14:49:43 --> Config Class Initialized
DEBUG - 2016-06-25 14:49:43 --> Hooks Class Initialized
DEBUG - 2016-06-25 14:49:43 --> Utf8 Class Initialized
DEBUG - 2016-06-25 14:49:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 14:49:43 --> URI Class Initialized
DEBUG - 2016-06-25 14:49:43 --> Router Class Initialized
DEBUG - 2016-06-25 14:49:43 --> Output Class Initialized
DEBUG - 2016-06-25 14:49:43 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 14:49:43 --> Security Class Initialized
DEBUG - 2016-06-25 14:49:43 --> Input Class Initialized
DEBUG - 2016-06-25 14:49:43 --> XSS Filtering completed
DEBUG - 2016-06-25 14:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 14:49:43 --> Language Class Initialized
DEBUG - 2016-06-25 14:49:43 --> Loader Class Initialized
DEBUG - 2016-06-25 14:49:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 14:49:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 14:49:43 --> Helper loaded: url_helper
DEBUG - 2016-06-25 14:49:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 14:49:43 --> Helper loaded: file_helper
DEBUG - 2016-06-25 14:49:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:49:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 14:49:43 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 14:49:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:49:43 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 14:49:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 14:49:43 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:49:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 14:49:43 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:49:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 14:49:43 --> Helper loaded: form_helper
DEBUG - 2016-06-25 14:49:43 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 14:49:44 --> Helper loaded: security_helper
DEBUG - 2016-06-25 14:49:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:49:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 14:49:44 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 14:49:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:49:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 14:49:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 14:49:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 14:49:44 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 14:49:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:49:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 14:49:44 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 14:49:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:49:44 --> Database Driver Class Initialized
DEBUG - 2016-06-25 14:49:44 --> Session Class Initialized
DEBUG - 2016-06-25 14:49:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 14:49:44 --> Helper loaded: string_helper
DEBUG - 2016-06-25 14:49:44 --> A session cookie was not found.
DEBUG - 2016-06-25 14:49:44 --> Session routines successfully run
DEBUG - 2016-06-25 14:49:44 --> Native_session Class Initialized
DEBUG - 2016-06-25 14:49:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 14:49:45 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:49:45 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:49:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 14:49:45 --> Controller Class Initialized
DEBUG - 2016-06-25 14:49:45 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 14:49:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 14:49:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 14:49:45 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:49:45 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:49:45 --> User Agent Class Initialized
DEBUG - 2016-06-25 14:49:46 --> Model Class Initialized
DEBUG - 2016-06-25 14:49:46 --> Model Class Initialized
DEBUG - 2016-06-25 14:49:46 --> Model Class Initialized
DEBUG - 2016-06-25 14:49:47 --> Model Class Initialized
DEBUG - 2016-06-25 14:49:47 --> Model Class Initialized
DEBUG - 2016-06-25 14:49:47 --> Model Class Initialized
DEBUG - 2016-06-25 14:49:47 --> Model Class Initialized
DEBUG - 2016-06-25 14:49:48 --> Model Class Initialized
DEBUG - 2016-06-25 14:49:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-06-25 14:49:48 --> Pagination Class Initialized
DEBUG - 2016-06-25 14:49:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 14:49:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-06-25 14:49:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 14:49:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 14:49:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 14:49:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 14:49:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-06-25 14:49:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 14:49:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 14:49:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 14:49:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 14:49:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 14:49:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 14:49:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-06-25 14:49:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 14:49:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 14:49:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-06-25 14:49:48 --> Final output sent to browser
DEBUG - 2016-06-25 14:49:48 --> Total execution time: 5.4947
DEBUG - 2016-06-25 14:49:59 --> Config Class Initialized
DEBUG - 2016-06-25 14:49:59 --> Hooks Class Initialized
DEBUG - 2016-06-25 14:49:59 --> Utf8 Class Initialized
DEBUG - 2016-06-25 14:49:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 14:49:59 --> URI Class Initialized
DEBUG - 2016-06-25 14:49:59 --> Router Class Initialized
DEBUG - 2016-06-25 14:49:59 --> Output Class Initialized
DEBUG - 2016-06-25 14:49:59 --> Security Class Initialized
DEBUG - 2016-06-25 14:49:59 --> Input Class Initialized
DEBUG - 2016-06-25 14:49:59 --> XSS Filtering completed
DEBUG - 2016-06-25 14:49:59 --> XSS Filtering completed
DEBUG - 2016-06-25 14:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 14:50:00 --> Language Class Initialized
DEBUG - 2016-06-25 14:50:00 --> Loader Class Initialized
DEBUG - 2016-06-25 14:50:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 14:50:00 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 14:50:00 --> Helper loaded: url_helper
DEBUG - 2016-06-25 14:50:00 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 14:50:00 --> Helper loaded: file_helper
DEBUG - 2016-06-25 14:50:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:50:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 14:50:00 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 14:50:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:50:00 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 14:50:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 14:50:00 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:50:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 14:50:00 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:50:00 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 14:50:00 --> Helper loaded: form_helper
DEBUG - 2016-06-25 14:50:00 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 14:50:00 --> Helper loaded: security_helper
DEBUG - 2016-06-25 14:50:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:50:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 14:50:00 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 14:50:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:50:00 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 14:50:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 14:50:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 14:50:00 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 14:50:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:50:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 14:50:00 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 14:50:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:50:00 --> Database Driver Class Initialized
DEBUG - 2016-06-25 14:50:00 --> Session Class Initialized
DEBUG - 2016-06-25 14:50:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 14:50:00 --> Helper loaded: string_helper
DEBUG - 2016-06-25 14:50:00 --> Session routines successfully run
DEBUG - 2016-06-25 14:50:00 --> Native_session Class Initialized
DEBUG - 2016-06-25 14:50:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 14:50:00 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:50:00 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:50:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 14:50:00 --> Controller Class Initialized
DEBUG - 2016-06-25 14:50:00 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 14:50:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 14:50:00 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 14:50:00 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:50:00 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:50:00 --> User Agent Class Initialized
DEBUG - 2016-06-25 14:50:00 --> Model Class Initialized
DEBUG - 2016-06-25 14:50:00 --> Model Class Initialized
DEBUG - 2016-06-25 14:50:00 --> Model Class Initialized
DEBUG - 2016-06-25 14:50:00 --> Model Class Initialized
DEBUG - 2016-06-25 14:50:00 --> Model Class Initialized
DEBUG - 2016-06-25 14:50:14 --> Config Class Initialized
DEBUG - 2016-06-25 14:50:14 --> Hooks Class Initialized
DEBUG - 2016-06-25 14:50:14 --> Utf8 Class Initialized
DEBUG - 2016-06-25 14:50:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 14:50:14 --> URI Class Initialized
DEBUG - 2016-06-25 14:50:14 --> Router Class Initialized
DEBUG - 2016-06-25 14:50:14 --> Output Class Initialized
DEBUG - 2016-06-25 14:50:14 --> Security Class Initialized
DEBUG - 2016-06-25 14:50:14 --> Input Class Initialized
DEBUG - 2016-06-25 14:50:14 --> XSS Filtering completed
DEBUG - 2016-06-25 14:50:14 --> XSS Filtering completed
DEBUG - 2016-06-25 14:50:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 14:50:14 --> Language Class Initialized
DEBUG - 2016-06-25 14:50:14 --> Loader Class Initialized
DEBUG - 2016-06-25 14:50:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 14:50:14 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 14:50:14 --> Helper loaded: url_helper
DEBUG - 2016-06-25 14:50:14 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 14:50:14 --> Helper loaded: file_helper
DEBUG - 2016-06-25 14:50:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:50:14 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 14:50:14 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 14:50:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:50:14 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 14:50:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 14:50:14 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:50:14 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 14:50:14 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:50:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 14:50:14 --> Helper loaded: form_helper
DEBUG - 2016-06-25 14:50:14 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 14:50:14 --> Helper loaded: security_helper
DEBUG - 2016-06-25 14:50:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:50:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 14:50:15 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 14:50:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:50:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 14:50:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 14:50:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 14:50:15 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 14:50:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:50:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 14:50:15 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 14:50:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:50:15 --> Database Driver Class Initialized
DEBUG - 2016-06-25 14:50:15 --> Session Class Initialized
DEBUG - 2016-06-25 14:50:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 14:50:15 --> Helper loaded: string_helper
DEBUG - 2016-06-25 14:50:15 --> Session routines successfully run
DEBUG - 2016-06-25 14:50:15 --> Native_session Class Initialized
DEBUG - 2016-06-25 14:50:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 14:50:15 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:50:15 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:50:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 14:50:15 --> Controller Class Initialized
DEBUG - 2016-06-25 14:50:15 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 14:50:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 14:50:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 14:50:15 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:50:15 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:50:15 --> User Agent Class Initialized
DEBUG - 2016-06-25 14:50:15 --> Model Class Initialized
DEBUG - 2016-06-25 14:50:15 --> Model Class Initialized
DEBUG - 2016-06-25 14:50:15 --> Model Class Initialized
DEBUG - 2016-06-25 14:50:15 --> Model Class Initialized
DEBUG - 2016-06-25 14:50:15 --> Model Class Initialized
DEBUG - 2016-06-25 14:50:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 14:50:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 14:50:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 14:50:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 14:50:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 14:50:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 14:50:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 14:50:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 14:50:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 14:50:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 14:50:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 14:50:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 14:50:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 14:50:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 14:50:15 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 14:50:15 --> Final output sent to browser
DEBUG - 2016-06-25 14:50:15 --> Total execution time: 0.2910
DEBUG - 2016-06-25 14:50:17 --> Config Class Initialized
DEBUG - 2016-06-25 14:50:17 --> Hooks Class Initialized
DEBUG - 2016-06-25 14:50:17 --> Utf8 Class Initialized
DEBUG - 2016-06-25 14:50:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 14:50:17 --> URI Class Initialized
DEBUG - 2016-06-25 14:50:17 --> Router Class Initialized
DEBUG - 2016-06-25 14:50:17 --> Output Class Initialized
DEBUG - 2016-06-25 14:50:17 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 14:50:17 --> Security Class Initialized
DEBUG - 2016-06-25 14:50:17 --> Input Class Initialized
DEBUG - 2016-06-25 14:50:17 --> XSS Filtering completed
DEBUG - 2016-06-25 14:50:17 --> XSS Filtering completed
DEBUG - 2016-06-25 14:50:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 14:50:17 --> Language Class Initialized
DEBUG - 2016-06-25 14:50:17 --> Loader Class Initialized
DEBUG - 2016-06-25 14:50:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 14:50:17 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 14:50:17 --> Helper loaded: url_helper
DEBUG - 2016-06-25 14:50:17 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 14:50:17 --> Helper loaded: file_helper
DEBUG - 2016-06-25 14:50:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:50:17 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 14:50:17 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 14:50:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:50:17 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 14:50:17 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 14:50:17 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:50:17 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 14:50:17 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:50:17 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 14:50:17 --> Helper loaded: form_helper
DEBUG - 2016-06-25 14:50:17 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 14:50:17 --> Helper loaded: security_helper
DEBUG - 2016-06-25 14:50:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:50:17 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 14:50:17 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 14:50:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:50:17 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 14:50:17 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 14:50:17 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 14:50:17 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 14:50:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:50:17 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 14:50:17 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 14:50:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:50:17 --> Database Driver Class Initialized
DEBUG - 2016-06-25 14:50:17 --> Session Class Initialized
DEBUG - 2016-06-25 14:50:17 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 14:50:17 --> Helper loaded: string_helper
DEBUG - 2016-06-25 14:50:17 --> Session routines successfully run
DEBUG - 2016-06-25 14:50:17 --> Native_session Class Initialized
DEBUG - 2016-06-25 14:50:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 14:50:17 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:50:17 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:50:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 14:50:17 --> Controller Class Initialized
DEBUG - 2016-06-25 14:50:17 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 14:50:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 14:50:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 14:50:17 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:50:17 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:50:17 --> User Agent Class Initialized
DEBUG - 2016-06-25 14:50:17 --> Model Class Initialized
DEBUG - 2016-06-25 14:50:17 --> Model Class Initialized
DEBUG - 2016-06-25 14:50:17 --> Model Class Initialized
DEBUG - 2016-06-25 14:50:17 --> Model Class Initialized
DEBUG - 2016-06-25 14:50:17 --> Model Class Initialized
ERROR - 2016-06-25 14:50:18 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 14:50:18 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 14:50:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 14:50:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 14:50:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 14:50:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 14:50:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 14:50:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 14:50:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 14:50:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 14:50:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 14:50:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 14:50:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 14:50:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 14:50:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 14:50:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 14:50:18 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 14:50:18 --> Final output sent to browser
DEBUG - 2016-06-25 14:50:18 --> Total execution time: 0.4687
DEBUG - 2016-06-25 14:50:35 --> Config Class Initialized
DEBUG - 2016-06-25 14:50:35 --> Hooks Class Initialized
DEBUG - 2016-06-25 14:50:35 --> Utf8 Class Initialized
DEBUG - 2016-06-25 14:50:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 14:50:35 --> URI Class Initialized
DEBUG - 2016-06-25 14:50:35 --> Router Class Initialized
DEBUG - 2016-06-25 14:50:35 --> Output Class Initialized
DEBUG - 2016-06-25 14:50:35 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 14:50:35 --> Security Class Initialized
DEBUG - 2016-06-25 14:50:35 --> Input Class Initialized
DEBUG - 2016-06-25 14:50:35 --> XSS Filtering completed
DEBUG - 2016-06-25 14:50:35 --> XSS Filtering completed
DEBUG - 2016-06-25 14:50:35 --> XSS Filtering completed
DEBUG - 2016-06-25 14:50:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 14:50:35 --> Language Class Initialized
DEBUG - 2016-06-25 14:50:35 --> Loader Class Initialized
DEBUG - 2016-06-25 14:50:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 14:50:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 14:50:35 --> Helper loaded: url_helper
DEBUG - 2016-06-25 14:50:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 14:50:35 --> Helper loaded: file_helper
DEBUG - 2016-06-25 14:50:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:50:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 14:50:35 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 14:50:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:50:35 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 14:50:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 14:50:35 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:50:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 14:50:35 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:50:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 14:50:35 --> Helper loaded: form_helper
DEBUG - 2016-06-25 14:50:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 14:50:35 --> Helper loaded: security_helper
DEBUG - 2016-06-25 14:50:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:50:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 14:50:35 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 14:50:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:50:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 14:50:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 14:50:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 14:50:35 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 14:50:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:50:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 14:50:35 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 14:50:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:50:35 --> Database Driver Class Initialized
DEBUG - 2016-06-25 14:50:35 --> Session Class Initialized
DEBUG - 2016-06-25 14:50:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 14:50:35 --> Helper loaded: string_helper
DEBUG - 2016-06-25 14:50:35 --> Session routines successfully run
DEBUG - 2016-06-25 14:50:35 --> Native_session Class Initialized
DEBUG - 2016-06-25 14:50:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 14:50:35 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:50:35 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:50:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 14:50:35 --> Controller Class Initialized
DEBUG - 2016-06-25 14:50:35 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 14:50:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 14:50:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 14:50:35 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:50:35 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:50:35 --> User Agent Class Initialized
DEBUG - 2016-06-25 14:50:35 --> Model Class Initialized
DEBUG - 2016-06-25 14:50:35 --> Model Class Initialized
DEBUG - 2016-06-25 14:50:35 --> Model Class Initialized
DEBUG - 2016-06-25 14:50:35 --> Model Class Initialized
DEBUG - 2016-06-25 14:50:35 --> Model Class Initialized
DEBUG - 2016-06-25 14:51:01 --> Config Class Initialized
DEBUG - 2016-06-25 14:51:01 --> Hooks Class Initialized
DEBUG - 2016-06-25 14:51:01 --> Utf8 Class Initialized
DEBUG - 2016-06-25 14:51:01 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 14:51:01 --> URI Class Initialized
DEBUG - 2016-06-25 14:51:01 --> Router Class Initialized
DEBUG - 2016-06-25 14:51:01 --> Output Class Initialized
DEBUG - 2016-06-25 14:51:01 --> Security Class Initialized
DEBUG - 2016-06-25 14:51:01 --> Input Class Initialized
DEBUG - 2016-06-25 14:51:01 --> XSS Filtering completed
DEBUG - 2016-06-25 14:51:01 --> XSS Filtering completed
DEBUG - 2016-06-25 14:51:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 14:51:01 --> Language Class Initialized
DEBUG - 2016-06-25 14:51:01 --> Loader Class Initialized
DEBUG - 2016-06-25 14:51:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 14:51:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 14:51:01 --> Helper loaded: url_helper
DEBUG - 2016-06-25 14:51:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 14:51:01 --> Helper loaded: file_helper
DEBUG - 2016-06-25 14:51:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:51:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 14:51:01 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 14:51:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:51:01 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 14:51:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 14:51:01 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:51:01 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 14:51:01 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:51:01 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 14:51:01 --> Helper loaded: form_helper
DEBUG - 2016-06-25 14:51:01 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 14:51:01 --> Helper loaded: security_helper
DEBUG - 2016-06-25 14:51:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:51:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 14:51:01 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 14:51:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:51:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 14:51:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 14:51:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 14:51:01 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 14:51:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:51:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 14:51:01 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 14:51:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:51:01 --> Database Driver Class Initialized
DEBUG - 2016-06-25 14:51:01 --> Session Class Initialized
DEBUG - 2016-06-25 14:51:01 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 14:51:01 --> Helper loaded: string_helper
DEBUG - 2016-06-25 14:51:01 --> Session routines successfully run
DEBUG - 2016-06-25 14:51:01 --> Native_session Class Initialized
DEBUG - 2016-06-25 14:51:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 14:51:01 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:51:01 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:51:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 14:51:01 --> Controller Class Initialized
DEBUG - 2016-06-25 14:51:01 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 14:51:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 14:51:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 14:51:01 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:51:01 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:51:01 --> User Agent Class Initialized
DEBUG - 2016-06-25 14:51:01 --> Model Class Initialized
DEBUG - 2016-06-25 14:51:01 --> Model Class Initialized
DEBUG - 2016-06-25 14:51:01 --> Model Class Initialized
DEBUG - 2016-06-25 14:51:01 --> Model Class Initialized
DEBUG - 2016-06-25 14:51:01 --> Model Class Initialized
DEBUG - 2016-06-25 14:51:08 --> Config Class Initialized
DEBUG - 2016-06-25 14:51:08 --> Hooks Class Initialized
DEBUG - 2016-06-25 14:51:08 --> Utf8 Class Initialized
DEBUG - 2016-06-25 14:51:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 14:51:08 --> URI Class Initialized
DEBUG - 2016-06-25 14:51:08 --> Router Class Initialized
DEBUG - 2016-06-25 14:51:08 --> Output Class Initialized
DEBUG - 2016-06-25 14:51:08 --> Security Class Initialized
DEBUG - 2016-06-25 14:51:08 --> Input Class Initialized
DEBUG - 2016-06-25 14:51:08 --> XSS Filtering completed
DEBUG - 2016-06-25 14:51:08 --> XSS Filtering completed
DEBUG - 2016-06-25 14:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 14:51:08 --> Language Class Initialized
DEBUG - 2016-06-25 14:51:08 --> Loader Class Initialized
DEBUG - 2016-06-25 14:51:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 14:51:08 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 14:51:08 --> Helper loaded: url_helper
DEBUG - 2016-06-25 14:51:08 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 14:51:08 --> Helper loaded: file_helper
DEBUG - 2016-06-25 14:51:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:51:08 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 14:51:08 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 14:51:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:51:08 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 14:51:08 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 14:51:08 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:51:08 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 14:51:08 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:51:08 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 14:51:08 --> Helper loaded: form_helper
DEBUG - 2016-06-25 14:51:08 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 14:51:08 --> Helper loaded: security_helper
DEBUG - 2016-06-25 14:51:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:51:08 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 14:51:08 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 14:51:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:51:08 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 14:51:08 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 14:51:08 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 14:51:08 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 14:51:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:51:08 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 14:51:08 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 14:51:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:51:08 --> Database Driver Class Initialized
DEBUG - 2016-06-25 14:51:08 --> Session Class Initialized
DEBUG - 2016-06-25 14:51:08 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 14:51:08 --> Helper loaded: string_helper
DEBUG - 2016-06-25 14:51:08 --> Session routines successfully run
DEBUG - 2016-06-25 14:51:08 --> Native_session Class Initialized
DEBUG - 2016-06-25 14:51:08 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 14:51:08 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:51:08 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:51:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 14:51:08 --> Controller Class Initialized
DEBUG - 2016-06-25 14:51:08 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 14:51:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 14:51:08 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 14:51:08 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:51:08 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:51:08 --> User Agent Class Initialized
DEBUG - 2016-06-25 14:51:08 --> Model Class Initialized
DEBUG - 2016-06-25 14:51:08 --> Model Class Initialized
DEBUG - 2016-06-25 14:51:08 --> Model Class Initialized
DEBUG - 2016-06-25 14:51:08 --> Model Class Initialized
DEBUG - 2016-06-25 14:51:08 --> Model Class Initialized
DEBUG - 2016-06-25 14:51:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 14:51:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 14:51:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 14:51:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 14:51:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 14:51:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 14:51:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 14:51:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 14:51:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 14:51:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 14:51:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 14:51:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 14:51:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 14:51:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 14:51:08 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 14:51:08 --> Final output sent to browser
DEBUG - 2016-06-25 14:51:08 --> Total execution time: 0.3236
DEBUG - 2016-06-25 14:51:09 --> Config Class Initialized
DEBUG - 2016-06-25 14:51:09 --> Hooks Class Initialized
DEBUG - 2016-06-25 14:51:09 --> Utf8 Class Initialized
DEBUG - 2016-06-25 14:51:09 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 14:51:09 --> URI Class Initialized
DEBUG - 2016-06-25 14:51:09 --> Router Class Initialized
DEBUG - 2016-06-25 14:51:09 --> Output Class Initialized
DEBUG - 2016-06-25 14:51:09 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 14:51:09 --> Security Class Initialized
DEBUG - 2016-06-25 14:51:09 --> Input Class Initialized
DEBUG - 2016-06-25 14:51:09 --> XSS Filtering completed
DEBUG - 2016-06-25 14:51:09 --> XSS Filtering completed
DEBUG - 2016-06-25 14:51:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 14:51:09 --> Language Class Initialized
DEBUG - 2016-06-25 14:51:09 --> Loader Class Initialized
DEBUG - 2016-06-25 14:51:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 14:51:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 14:51:09 --> Helper loaded: url_helper
DEBUG - 2016-06-25 14:51:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 14:51:09 --> Helper loaded: file_helper
DEBUG - 2016-06-25 14:51:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:51:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 14:51:09 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 14:51:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:51:09 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 14:51:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 14:51:09 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:51:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 14:51:09 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:51:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 14:51:09 --> Helper loaded: form_helper
DEBUG - 2016-06-25 14:51:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 14:51:09 --> Helper loaded: security_helper
DEBUG - 2016-06-25 14:51:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:51:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 14:51:09 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 14:51:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:51:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 14:51:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 14:51:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 14:51:09 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 14:51:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:51:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 14:51:09 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 14:51:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:51:09 --> Database Driver Class Initialized
DEBUG - 2016-06-25 14:51:09 --> Session Class Initialized
DEBUG - 2016-06-25 14:51:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 14:51:09 --> Helper loaded: string_helper
DEBUG - 2016-06-25 14:51:09 --> Session routines successfully run
DEBUG - 2016-06-25 14:51:09 --> Native_session Class Initialized
DEBUG - 2016-06-25 14:51:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 14:51:09 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:51:09 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:51:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 14:51:09 --> Controller Class Initialized
DEBUG - 2016-06-25 14:51:09 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 14:51:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 14:51:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 14:51:10 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:51:10 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:51:10 --> User Agent Class Initialized
DEBUG - 2016-06-25 14:51:10 --> Model Class Initialized
DEBUG - 2016-06-25 14:51:10 --> Model Class Initialized
DEBUG - 2016-06-25 14:51:10 --> Model Class Initialized
DEBUG - 2016-06-25 14:51:10 --> Model Class Initialized
DEBUG - 2016-06-25 14:51:10 --> Model Class Initialized
ERROR - 2016-06-25 14:51:10 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 14:51:10 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 14:51:10 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 14:51:10 --> Final output sent to browser
DEBUG - 2016-06-25 14:51:10 --> Total execution time: 0.4961
DEBUG - 2016-06-25 14:51:58 --> Config Class Initialized
DEBUG - 2016-06-25 14:51:58 --> Hooks Class Initialized
DEBUG - 2016-06-25 14:51:58 --> Utf8 Class Initialized
DEBUG - 2016-06-25 14:51:58 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 14:51:58 --> URI Class Initialized
DEBUG - 2016-06-25 14:51:58 --> Router Class Initialized
DEBUG - 2016-06-25 14:51:58 --> Output Class Initialized
DEBUG - 2016-06-25 14:51:58 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 14:51:58 --> Security Class Initialized
DEBUG - 2016-06-25 14:51:58 --> Input Class Initialized
DEBUG - 2016-06-25 14:51:58 --> XSS Filtering completed
DEBUG - 2016-06-25 14:51:58 --> XSS Filtering completed
DEBUG - 2016-06-25 14:51:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 14:51:58 --> Language Class Initialized
DEBUG - 2016-06-25 14:51:58 --> Loader Class Initialized
DEBUG - 2016-06-25 14:51:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 14:51:58 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 14:51:58 --> Helper loaded: url_helper
DEBUG - 2016-06-25 14:51:58 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 14:51:58 --> Helper loaded: file_helper
DEBUG - 2016-06-25 14:51:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:51:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 14:51:58 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 14:51:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:51:58 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 14:51:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 14:51:58 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:51:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 14:51:58 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:51:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 14:51:58 --> Helper loaded: form_helper
DEBUG - 2016-06-25 14:51:58 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 14:51:58 --> Helper loaded: security_helper
DEBUG - 2016-06-25 14:51:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:51:58 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 14:51:58 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 14:51:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:51:58 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 14:51:58 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 14:51:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 14:51:58 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 14:51:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:51:58 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 14:51:58 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 14:51:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:51:58 --> Database Driver Class Initialized
DEBUG - 2016-06-25 14:51:58 --> Session Class Initialized
DEBUG - 2016-06-25 14:51:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 14:51:58 --> Helper loaded: string_helper
DEBUG - 2016-06-25 14:51:58 --> Session routines successfully run
DEBUG - 2016-06-25 14:51:58 --> Native_session Class Initialized
DEBUG - 2016-06-25 14:51:58 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 14:51:58 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:51:58 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:51:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 14:51:58 --> Controller Class Initialized
DEBUG - 2016-06-25 14:51:58 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 14:51:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 14:51:58 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 14:51:58 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:51:58 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:51:58 --> User Agent Class Initialized
DEBUG - 2016-06-25 14:51:58 --> Model Class Initialized
DEBUG - 2016-06-25 14:51:58 --> Model Class Initialized
DEBUG - 2016-06-25 14:51:58 --> Model Class Initialized
DEBUG - 2016-06-25 14:51:58 --> Model Class Initialized
DEBUG - 2016-06-25 14:51:58 --> Model Class Initialized
DEBUG - 2016-06-25 14:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 14:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 14:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 14:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 14:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 14:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 14:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_js.php
DEBUG - 2016-06-25 14:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_isian_js.php
DEBUG - 2016-06-25 14:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 14:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 14:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 14:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 14:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 14:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 14:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_js.php
DEBUG - 2016-06-25 14:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_isian_js.php
DEBUG - 2016-06-25 14:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 14:51:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 14:51:58 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 14:51:58 --> Final output sent to browser
DEBUG - 2016-06-25 14:51:58 --> Total execution time: 0.3904
DEBUG - 2016-06-25 14:52:17 --> Config Class Initialized
DEBUG - 2016-06-25 14:52:17 --> Hooks Class Initialized
DEBUG - 2016-06-25 14:52:17 --> Utf8 Class Initialized
DEBUG - 2016-06-25 14:52:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 14:52:17 --> URI Class Initialized
DEBUG - 2016-06-25 14:52:17 --> Router Class Initialized
DEBUG - 2016-06-25 14:52:17 --> Output Class Initialized
DEBUG - 2016-06-25 14:52:17 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 14:52:17 --> Security Class Initialized
DEBUG - 2016-06-25 14:52:17 --> Input Class Initialized
DEBUG - 2016-06-25 14:52:17 --> XSS Filtering completed
DEBUG - 2016-06-25 14:52:17 --> XSS Filtering completed
DEBUG - 2016-06-25 14:52:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 14:52:17 --> Language Class Initialized
DEBUG - 2016-06-25 14:52:17 --> Loader Class Initialized
DEBUG - 2016-06-25 14:52:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 14:52:17 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 14:52:17 --> Helper loaded: url_helper
DEBUG - 2016-06-25 14:52:17 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 14:52:17 --> Helper loaded: file_helper
DEBUG - 2016-06-25 14:52:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:52:17 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 14:52:17 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 14:52:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:52:17 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 14:52:17 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 14:52:17 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:52:17 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 14:52:17 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:52:17 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 14:52:17 --> Helper loaded: form_helper
DEBUG - 2016-06-25 14:52:17 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 14:52:17 --> Helper loaded: security_helper
DEBUG - 2016-06-25 14:52:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:52:17 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 14:52:17 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 14:52:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:52:17 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 14:52:17 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 14:52:17 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 14:52:17 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 14:52:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:52:17 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 14:52:17 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 14:52:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:52:17 --> Database Driver Class Initialized
DEBUG - 2016-06-25 14:52:17 --> Session Class Initialized
DEBUG - 2016-06-25 14:52:17 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 14:52:18 --> Helper loaded: string_helper
DEBUG - 2016-06-25 14:52:18 --> Session routines successfully run
DEBUG - 2016-06-25 14:52:18 --> Native_session Class Initialized
DEBUG - 2016-06-25 14:52:18 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 14:52:18 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:52:18 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:52:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 14:52:18 --> Controller Class Initialized
DEBUG - 2016-06-25 14:52:18 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 14:52:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 14:52:18 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 14:52:18 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:52:18 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:52:18 --> User Agent Class Initialized
DEBUG - 2016-06-25 14:52:18 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:18 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:18 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:18 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:18 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 14:52:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 14:52:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 14:52:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 14:52:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 14:52:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 14:52:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 14:52:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 14:52:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 14:52:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 14:52:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 14:52:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 14:52:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 14:52:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 14:52:18 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 14:52:18 --> Final output sent to browser
DEBUG - 2016-06-25 14:52:18 --> Total execution time: 0.3839
DEBUG - 2016-06-25 14:52:18 --> Config Class Initialized
DEBUG - 2016-06-25 14:52:18 --> Hooks Class Initialized
DEBUG - 2016-06-25 14:52:18 --> Utf8 Class Initialized
DEBUG - 2016-06-25 14:52:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 14:52:19 --> URI Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Router Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Output Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 14:52:19 --> Security Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Input Class Initialized
DEBUG - 2016-06-25 14:52:19 --> XSS Filtering completed
DEBUG - 2016-06-25 14:52:19 --> XSS Filtering completed
DEBUG - 2016-06-25 14:52:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 14:52:19 --> Language Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Loader Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 14:52:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 14:52:19 --> Helper loaded: url_helper
DEBUG - 2016-06-25 14:52:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 14:52:19 --> Helper loaded: file_helper
DEBUG - 2016-06-25 14:52:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:52:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 14:52:19 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 14:52:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:52:19 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 14:52:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 14:52:19 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:52:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 14:52:19 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:52:19 --> Config Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 14:52:19 --> Hooks Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Helper loaded: form_helper
DEBUG - 2016-06-25 14:52:19 --> Utf8 Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 14:52:19 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 14:52:19 --> URI Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Helper loaded: security_helper
DEBUG - 2016-06-25 14:52:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:52:19 --> Router Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 14:52:19 --> Output Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 14:52:19 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 14:52:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:52:19 --> Security Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 14:52:19 --> Input Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 14:52:19 --> XSS Filtering completed
DEBUG - 2016-06-25 14:52:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 14:52:19 --> XSS Filtering completed
DEBUG - 2016-06-25 14:52:19 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 14:52:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 14:52:19 --> Language Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:52:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 14:52:19 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 14:52:19 --> Loader Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:52:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 14:52:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 14:52:19 --> Database Driver Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Helper loaded: url_helper
DEBUG - 2016-06-25 14:52:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 14:52:19 --> Helper loaded: file_helper
DEBUG - 2016-06-25 14:52:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:52:19 --> Session Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 14:52:19 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 14:52:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 14:52:19 --> Helper loaded: string_helper
DEBUG - 2016-06-25 14:52:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:52:19 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 14:52:19 --> Session routines successfully run
DEBUG - 2016-06-25 14:52:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 14:52:19 --> Native_session Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 14:52:19 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:52:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 14:52:19 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:52:19 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 14:52:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 14:52:19 --> Helper loaded: form_helper
DEBUG - 2016-06-25 14:52:19 --> Controller Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 14:52:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 14:52:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 14:52:19 --> Helper loaded: security_helper
DEBUG - 2016-06-25 14:52:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:52:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 14:52:19 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:52:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 14:52:19 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 14:52:19 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:52:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:52:19 --> User Agent Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 14:52:19 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 14:52:19 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 14:52:19 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 14:52:19 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:52:19 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 14:52:19 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 14:52:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:52:19 --> Database Driver Class Initialized
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 14:52:19 --> Session Class Initialized
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 14:52:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 14:52:19 --> Helper loaded: string_helper
DEBUG - 2016-06-25 14:52:19 --> Session routines successfully run
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 14:52:19 --> Native_session Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 14:52:19 --> Final output sent to browser
DEBUG - 2016-06-25 14:52:19 --> Total execution time: 0.4118
DEBUG - 2016-06-25 14:52:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 14:52:19 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 14:52:19 --> Controller Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 14:52:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 14:52:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 14:52:19 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:52:19 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:52:19 --> User Agent Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:19 --> Model Class Initialized
ERROR - 2016-06-25 14:52:19 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 14:52:19 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 14:52:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 14:52:19 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 14:52:19 --> Final output sent to browser
DEBUG - 2016-06-25 14:52:19 --> Total execution time: 0.4709
DEBUG - 2016-06-25 14:52:40 --> Config Class Initialized
DEBUG - 2016-06-25 14:52:40 --> Hooks Class Initialized
DEBUG - 2016-06-25 14:52:40 --> Utf8 Class Initialized
DEBUG - 2016-06-25 14:52:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 14:52:40 --> URI Class Initialized
DEBUG - 2016-06-25 14:52:40 --> Router Class Initialized
DEBUG - 2016-06-25 14:52:40 --> Output Class Initialized
DEBUG - 2016-06-25 14:52:40 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 14:52:40 --> Security Class Initialized
DEBUG - 2016-06-25 14:52:40 --> Input Class Initialized
DEBUG - 2016-06-25 14:52:40 --> XSS Filtering completed
DEBUG - 2016-06-25 14:52:40 --> XSS Filtering completed
DEBUG - 2016-06-25 14:52:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 14:52:40 --> Language Class Initialized
DEBUG - 2016-06-25 14:52:40 --> Loader Class Initialized
DEBUG - 2016-06-25 14:52:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 14:52:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 14:52:40 --> Helper loaded: url_helper
DEBUG - 2016-06-25 14:52:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 14:52:40 --> Helper loaded: file_helper
DEBUG - 2016-06-25 14:52:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:52:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 14:52:40 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 14:52:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:52:40 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 14:52:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 14:52:40 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:52:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 14:52:40 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:52:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 14:52:40 --> Helper loaded: form_helper
DEBUG - 2016-06-25 14:52:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 14:52:40 --> Helper loaded: security_helper
DEBUG - 2016-06-25 14:52:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:52:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 14:52:40 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 14:52:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:52:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 14:52:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 14:52:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 14:52:40 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 14:52:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:52:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 14:52:40 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 14:52:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:52:40 --> Database Driver Class Initialized
DEBUG - 2016-06-25 14:52:40 --> Session Class Initialized
DEBUG - 2016-06-25 14:52:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 14:52:40 --> Helper loaded: string_helper
DEBUG - 2016-06-25 14:52:40 --> Session routines successfully run
DEBUG - 2016-06-25 14:52:40 --> Native_session Class Initialized
DEBUG - 2016-06-25 14:52:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 14:52:40 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:52:40 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:52:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 14:52:40 --> Controller Class Initialized
DEBUG - 2016-06-25 14:52:40 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 14:52:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 14:52:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 14:52:40 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:52:40 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:52:40 --> User Agent Class Initialized
DEBUG - 2016-06-25 14:52:40 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:40 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:40 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:40 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:40 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 14:52:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 14:52:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 14:52:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 14:52:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 14:52:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 14:52:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 14:52:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 14:52:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 14:52:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 14:52:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 14:52:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 14:52:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 14:52:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 14:52:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 14:52:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 14:52:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 14:52:40 --> Final output sent to browser
DEBUG - 2016-06-25 14:52:40 --> Total execution time: 0.4545
DEBUG - 2016-06-25 14:52:43 --> Config Class Initialized
DEBUG - 2016-06-25 14:52:43 --> Hooks Class Initialized
DEBUG - 2016-06-25 14:52:43 --> Utf8 Class Initialized
DEBUG - 2016-06-25 14:52:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 14:52:43 --> URI Class Initialized
DEBUG - 2016-06-25 14:52:43 --> Router Class Initialized
DEBUG - 2016-06-25 14:52:43 --> Output Class Initialized
DEBUG - 2016-06-25 14:52:43 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 14:52:43 --> Security Class Initialized
DEBUG - 2016-06-25 14:52:43 --> Input Class Initialized
DEBUG - 2016-06-25 14:52:43 --> XSS Filtering completed
DEBUG - 2016-06-25 14:52:43 --> XSS Filtering completed
DEBUG - 2016-06-25 14:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 14:52:43 --> Language Class Initialized
DEBUG - 2016-06-25 14:52:43 --> Loader Class Initialized
DEBUG - 2016-06-25 14:52:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 14:52:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 14:52:43 --> Helper loaded: url_helper
DEBUG - 2016-06-25 14:52:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 14:52:43 --> Helper loaded: file_helper
DEBUG - 2016-06-25 14:52:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:52:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 14:52:43 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 14:52:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:52:43 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 14:52:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 14:52:43 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:52:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 14:52:43 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:52:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 14:52:43 --> Helper loaded: form_helper
DEBUG - 2016-06-25 14:52:43 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 14:52:43 --> Helper loaded: security_helper
DEBUG - 2016-06-25 14:52:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:52:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 14:52:43 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 14:52:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:52:43 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 14:52:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 14:52:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 14:52:43 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 14:52:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:52:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 14:52:43 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 14:52:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:52:43 --> Database Driver Class Initialized
DEBUG - 2016-06-25 14:52:43 --> Session Class Initialized
DEBUG - 2016-06-25 14:52:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 14:52:43 --> Helper loaded: string_helper
DEBUG - 2016-06-25 14:52:43 --> Session routines successfully run
DEBUG - 2016-06-25 14:52:43 --> Native_session Class Initialized
DEBUG - 2016-06-25 14:52:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 14:52:43 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:52:43 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:52:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 14:52:43 --> Controller Class Initialized
DEBUG - 2016-06-25 14:52:43 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 14:52:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 14:52:43 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 14:52:43 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:52:43 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:52:43 --> User Agent Class Initialized
DEBUG - 2016-06-25 14:52:43 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:43 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:43 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:43 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:44 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 14:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 14:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 14:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 14:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 14:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 14:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 14:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 14:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 14:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 14:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 14:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 14:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 14:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 14:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 14:52:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 14:52:44 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 14:52:44 --> Final output sent to browser
DEBUG - 2016-06-25 14:52:44 --> Total execution time: 0.4487
DEBUG - 2016-06-25 14:52:44 --> Config Class Initialized
DEBUG - 2016-06-25 14:52:45 --> Hooks Class Initialized
DEBUG - 2016-06-25 14:52:45 --> Utf8 Class Initialized
DEBUG - 2016-06-25 14:52:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 14:52:45 --> URI Class Initialized
DEBUG - 2016-06-25 14:52:45 --> Router Class Initialized
DEBUG - 2016-06-25 14:52:45 --> Output Class Initialized
DEBUG - 2016-06-25 14:52:45 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 14:52:45 --> Security Class Initialized
DEBUG - 2016-06-25 14:52:45 --> Input Class Initialized
DEBUG - 2016-06-25 14:52:45 --> XSS Filtering completed
DEBUG - 2016-06-25 14:52:45 --> XSS Filtering completed
DEBUG - 2016-06-25 14:52:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 14:52:45 --> Language Class Initialized
DEBUG - 2016-06-25 14:52:45 --> Loader Class Initialized
DEBUG - 2016-06-25 14:52:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 14:52:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 14:52:45 --> Helper loaded: url_helper
DEBUG - 2016-06-25 14:52:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 14:52:45 --> Helper loaded: file_helper
DEBUG - 2016-06-25 14:52:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:52:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 14:52:45 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 14:52:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 14:52:45 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 14:52:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 14:52:45 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:52:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 14:52:45 --> Helper loaded: common_helper
DEBUG - 2016-06-25 14:52:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 14:52:45 --> Helper loaded: form_helper
DEBUG - 2016-06-25 14:52:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 14:52:45 --> Helper loaded: security_helper
DEBUG - 2016-06-25 14:52:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:52:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 14:52:45 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 14:52:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 14:52:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 14:52:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 14:52:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 14:52:45 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 14:52:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:52:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 14:52:45 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 14:52:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 14:52:45 --> Database Driver Class Initialized
DEBUG - 2016-06-25 14:52:45 --> Session Class Initialized
DEBUG - 2016-06-25 14:52:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 14:52:45 --> Helper loaded: string_helper
DEBUG - 2016-06-25 14:52:45 --> Session routines successfully run
DEBUG - 2016-06-25 14:52:45 --> Native_session Class Initialized
DEBUG - 2016-06-25 14:52:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 14:52:45 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:52:45 --> Form Validation Class Initialized
DEBUG - 2016-06-25 14:52:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 14:52:45 --> Controller Class Initialized
DEBUG - 2016-06-25 14:52:45 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 14:52:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 14:52:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 14:52:45 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:52:45 --> Carabiner: library configured.
DEBUG - 2016-06-25 14:52:45 --> User Agent Class Initialized
DEBUG - 2016-06-25 14:52:45 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:45 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:45 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:45 --> Model Class Initialized
DEBUG - 2016-06-25 14:52:45 --> Model Class Initialized
ERROR - 2016-06-25 14:52:45 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 14:52:45 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 14:52:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 14:52:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 14:52:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 14:52:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 14:52:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 14:52:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 14:52:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 14:52:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 14:52:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 14:52:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 14:52:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 14:52:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 14:52:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 14:52:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 14:52:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 14:52:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 14:52:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 14:52:45 --> Final output sent to browser
DEBUG - 2016-06-25 14:52:45 --> Total execution time: 0.5084
DEBUG - 2016-06-25 15:01:11 --> Config Class Initialized
DEBUG - 2016-06-25 15:01:11 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:01:11 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:01:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:01:11 --> URI Class Initialized
DEBUG - 2016-06-25 15:01:11 --> Router Class Initialized
DEBUG - 2016-06-25 15:01:11 --> Output Class Initialized
DEBUG - 2016-06-25 15:01:11 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:01:11 --> Security Class Initialized
DEBUG - 2016-06-25 15:01:11 --> Input Class Initialized
DEBUG - 2016-06-25 15:01:11 --> XSS Filtering completed
DEBUG - 2016-06-25 15:01:11 --> XSS Filtering completed
DEBUG - 2016-06-25 15:01:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:01:11 --> Language Class Initialized
DEBUG - 2016-06-25 15:01:11 --> Loader Class Initialized
DEBUG - 2016-06-25 15:01:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:01:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:01:11 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:01:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:01:11 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:01:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:01:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:01:11 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:01:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:01:11 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:01:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:01:11 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:01:11 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:01:11 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:01:11 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:01:11 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:01:11 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:01:11 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:01:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:01:11 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:01:11 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:01:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:01:11 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:01:11 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:01:11 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:01:11 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:01:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:01:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:01:12 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:01:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:01:12 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:01:12 --> Session Class Initialized
DEBUG - 2016-06-25 15:01:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:01:12 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:01:12 --> Session routines successfully run
DEBUG - 2016-06-25 15:01:12 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:01:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:01:12 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:01:12 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:01:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:01:12 --> Controller Class Initialized
DEBUG - 2016-06-25 15:01:12 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:01:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:01:12 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:01:12 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:01:12 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:01:12 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:01:12 --> Model Class Initialized
DEBUG - 2016-06-25 15:01:12 --> Model Class Initialized
DEBUG - 2016-06-25 15:01:12 --> Model Class Initialized
DEBUG - 2016-06-25 15:01:12 --> Model Class Initialized
DEBUG - 2016-06-25 15:01:12 --> Model Class Initialized
DEBUG - 2016-06-25 15:01:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:01:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:01:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:01:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:01:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:01:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:01:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:01:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:01:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:01:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:01:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:01:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:01:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:01:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:01:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:01:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:01:12 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 15:01:12 --> Final output sent to browser
DEBUG - 2016-06-25 15:01:12 --> Total execution time: 0.5018
DEBUG - 2016-06-25 15:01:13 --> Config Class Initialized
DEBUG - 2016-06-25 15:01:13 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:01:13 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:01:13 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:01:13 --> URI Class Initialized
DEBUG - 2016-06-25 15:01:13 --> Router Class Initialized
DEBUG - 2016-06-25 15:01:13 --> Output Class Initialized
DEBUG - 2016-06-25 15:01:13 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:01:13 --> Security Class Initialized
DEBUG - 2016-06-25 15:01:13 --> Input Class Initialized
DEBUG - 2016-06-25 15:01:13 --> XSS Filtering completed
DEBUG - 2016-06-25 15:01:13 --> XSS Filtering completed
DEBUG - 2016-06-25 15:01:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:01:13 --> Language Class Initialized
DEBUG - 2016-06-25 15:01:13 --> Loader Class Initialized
DEBUG - 2016-06-25 15:01:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:01:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:01:13 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:01:13 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:01:13 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:01:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:01:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:01:13 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:01:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:01:13 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:01:13 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:01:13 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:01:13 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:01:13 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:01:13 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:01:13 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:01:13 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:01:13 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:01:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:01:13 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:01:13 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:01:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:01:13 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:01:13 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:01:13 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:01:13 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:01:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:01:13 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:01:13 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:01:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:01:13 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:01:13 --> Session Class Initialized
DEBUG - 2016-06-25 15:01:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:01:13 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:01:13 --> Session routines successfully run
DEBUG - 2016-06-25 15:01:13 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:01:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:01:13 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:01:13 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:01:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:01:13 --> Controller Class Initialized
DEBUG - 2016-06-25 15:01:13 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:01:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:01:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:01:13 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:01:13 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:01:13 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:01:13 --> Model Class Initialized
DEBUG - 2016-06-25 15:01:13 --> Model Class Initialized
DEBUG - 2016-06-25 15:01:13 --> Model Class Initialized
DEBUG - 2016-06-25 15:01:13 --> Model Class Initialized
DEBUG - 2016-06-25 15:01:13 --> Model Class Initialized
ERROR - 2016-06-25 15:01:13 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 15:01:13 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 15:01:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:01:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:01:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:01:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:01:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:01:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:01:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:01:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:01:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:01:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:01:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:01:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:01:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:01:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:01:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:01:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:01:13 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 15:01:14 --> Final output sent to browser
DEBUG - 2016-06-25 15:01:14 --> Total execution time: 0.5669
DEBUG - 2016-06-25 15:03:46 --> Config Class Initialized
DEBUG - 2016-06-25 15:03:46 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:03:46 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:03:46 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:03:46 --> URI Class Initialized
DEBUG - 2016-06-25 15:03:46 --> Router Class Initialized
DEBUG - 2016-06-25 15:03:46 --> Output Class Initialized
DEBUG - 2016-06-25 15:03:46 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:03:46 --> Security Class Initialized
DEBUG - 2016-06-25 15:03:46 --> Input Class Initialized
DEBUG - 2016-06-25 15:03:46 --> XSS Filtering completed
DEBUG - 2016-06-25 15:03:46 --> XSS Filtering completed
DEBUG - 2016-06-25 15:03:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:03:46 --> Language Class Initialized
DEBUG - 2016-06-25 15:03:46 --> Loader Class Initialized
DEBUG - 2016-06-25 15:03:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:03:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:03:46 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:03:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:03:46 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:03:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:03:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:03:46 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:03:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:03:46 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:03:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:03:46 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:03:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:03:46 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:03:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:03:46 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:03:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:03:46 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:03:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:03:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:03:46 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:03:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:03:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:03:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:03:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:03:46 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:03:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:03:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:03:46 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:03:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:03:46 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:03:46 --> Session Class Initialized
DEBUG - 2016-06-25 15:03:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:03:46 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:03:46 --> Session routines successfully run
DEBUG - 2016-06-25 15:03:46 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:03:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:03:46 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:03:46 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:03:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:03:46 --> Controller Class Initialized
DEBUG - 2016-06-25 15:03:46 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:03:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:03:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:03:46 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:03:46 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:03:47 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:03:47 --> Model Class Initialized
DEBUG - 2016-06-25 15:03:47 --> Model Class Initialized
DEBUG - 2016-06-25 15:03:47 --> Model Class Initialized
DEBUG - 2016-06-25 15:03:47 --> Model Class Initialized
DEBUG - 2016-06-25 15:03:47 --> Model Class Initialized
DEBUG - 2016-06-25 15:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:03:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 15:03:47 --> Final output sent to browser
DEBUG - 2016-06-25 15:03:47 --> Total execution time: 0.5439
DEBUG - 2016-06-25 15:03:48 --> Config Class Initialized
DEBUG - 2016-06-25 15:03:48 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:03:48 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:03:48 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:03:48 --> URI Class Initialized
DEBUG - 2016-06-25 15:03:48 --> Router Class Initialized
DEBUG - 2016-06-25 15:03:48 --> Output Class Initialized
DEBUG - 2016-06-25 15:03:48 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:03:48 --> Security Class Initialized
DEBUG - 2016-06-25 15:03:48 --> Input Class Initialized
DEBUG - 2016-06-25 15:03:48 --> XSS Filtering completed
DEBUG - 2016-06-25 15:03:48 --> XSS Filtering completed
DEBUG - 2016-06-25 15:03:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:03:48 --> Language Class Initialized
DEBUG - 2016-06-25 15:03:48 --> Loader Class Initialized
DEBUG - 2016-06-25 15:03:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:03:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:03:48 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:03:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:03:48 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:03:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:03:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:03:48 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:03:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:03:48 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:03:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:03:48 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:03:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:03:48 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:03:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:03:48 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:03:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:03:48 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:03:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:03:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:03:48 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:03:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:03:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:03:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:03:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:03:48 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:03:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:03:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:03:48 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:03:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:03:48 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:03:48 --> Session Class Initialized
DEBUG - 2016-06-25 15:03:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:03:48 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:03:48 --> Session routines successfully run
DEBUG - 2016-06-25 15:03:48 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:03:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:03:48 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:03:48 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:03:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:03:48 --> Controller Class Initialized
DEBUG - 2016-06-25 15:03:48 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:03:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:03:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:03:48 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:03:48 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:03:48 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:03:48 --> Model Class Initialized
DEBUG - 2016-06-25 15:03:48 --> Model Class Initialized
DEBUG - 2016-06-25 15:03:48 --> Model Class Initialized
DEBUG - 2016-06-25 15:03:48 --> Model Class Initialized
DEBUG - 2016-06-25 15:03:48 --> Model Class Initialized
ERROR - 2016-06-25 15:03:48 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 15:03:48 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 15:03:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:03:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:03:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:03:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:03:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:03:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:03:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:03:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:03:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:03:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:03:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:03:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:03:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:03:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:03:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:03:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:03:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 15:03:48 --> Final output sent to browser
DEBUG - 2016-06-25 15:03:48 --> Total execution time: 0.5819
DEBUG - 2016-06-25 15:07:05 --> Config Class Initialized
DEBUG - 2016-06-25 15:07:05 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:07:05 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:07:05 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:07:05 --> URI Class Initialized
DEBUG - 2016-06-25 15:07:05 --> Router Class Initialized
DEBUG - 2016-06-25 15:07:05 --> Output Class Initialized
DEBUG - 2016-06-25 15:07:05 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:07:05 --> Security Class Initialized
DEBUG - 2016-06-25 15:07:05 --> Input Class Initialized
DEBUG - 2016-06-25 15:07:05 --> XSS Filtering completed
DEBUG - 2016-06-25 15:07:05 --> XSS Filtering completed
DEBUG - 2016-06-25 15:07:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:07:05 --> Language Class Initialized
DEBUG - 2016-06-25 15:07:05 --> Loader Class Initialized
DEBUG - 2016-06-25 15:07:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:07:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:07:05 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:07:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:07:05 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:07:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:07:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:07:05 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:07:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:07:05 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:07:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:07:05 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:07:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:07:05 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:07:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:07:06 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:07:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:07:06 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:07:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:07:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:07:06 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:07:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:07:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:07:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:07:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:07:06 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:07:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:07:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:07:06 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:07:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:07:06 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:07:06 --> Session Class Initialized
DEBUG - 2016-06-25 15:07:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:07:06 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:07:06 --> Session routines successfully run
DEBUG - 2016-06-25 15:07:06 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:07:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:07:06 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:07:06 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:07:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:07:06 --> Controller Class Initialized
DEBUG - 2016-06-25 15:07:06 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:07:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:07:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:07:06 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:07:06 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:07:06 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:07:06 --> Model Class Initialized
DEBUG - 2016-06-25 15:07:06 --> Model Class Initialized
DEBUG - 2016-06-25 15:07:06 --> Model Class Initialized
DEBUG - 2016-06-25 15:07:06 --> Model Class Initialized
DEBUG - 2016-06-25 15:07:06 --> Model Class Initialized
DEBUG - 2016-06-25 15:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:07:06 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 15:07:06 --> Final output sent to browser
DEBUG - 2016-06-25 15:07:06 --> Total execution time: 0.5655
DEBUG - 2016-06-25 15:07:06 --> Config Class Initialized
DEBUG - 2016-06-25 15:07:06 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:07:06 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:07:06 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:07:06 --> URI Class Initialized
DEBUG - 2016-06-25 15:07:06 --> Router Class Initialized
DEBUG - 2016-06-25 15:07:06 --> Output Class Initialized
DEBUG - 2016-06-25 15:07:06 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:07:06 --> Security Class Initialized
DEBUG - 2016-06-25 15:07:07 --> Input Class Initialized
DEBUG - 2016-06-25 15:07:07 --> XSS Filtering completed
DEBUG - 2016-06-25 15:07:07 --> XSS Filtering completed
DEBUG - 2016-06-25 15:07:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:07:07 --> Language Class Initialized
DEBUG - 2016-06-25 15:07:07 --> Loader Class Initialized
DEBUG - 2016-06-25 15:07:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:07:07 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:07:07 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:07:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:07:07 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:07:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:07:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:07:07 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:07:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:07:07 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:07:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:07:07 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:07:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:07:07 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:07:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:07:07 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:07:07 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:07:07 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:07:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:07:07 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:07:07 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:07:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:07:07 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:07:07 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:07:07 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:07:07 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:07:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:07:07 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:07:07 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:07:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:07:07 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:07:07 --> Session Class Initialized
DEBUG - 2016-06-25 15:07:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:07:07 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:07:07 --> Session routines successfully run
DEBUG - 2016-06-25 15:07:07 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:07:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:07:07 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:07:07 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:07:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:07:07 --> Controller Class Initialized
DEBUG - 2016-06-25 15:07:07 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:07:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:07:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:07:07 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:07:07 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:07:07 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:07:07 --> Model Class Initialized
DEBUG - 2016-06-25 15:07:07 --> Model Class Initialized
DEBUG - 2016-06-25 15:07:07 --> Model Class Initialized
DEBUG - 2016-06-25 15:07:07 --> Model Class Initialized
DEBUG - 2016-06-25 15:07:07 --> Model Class Initialized
ERROR - 2016-06-25 15:07:07 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 15:07:07 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 15:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:07:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:07:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 15:07:07 --> Final output sent to browser
DEBUG - 2016-06-25 15:07:07 --> Total execution time: 0.6136
DEBUG - 2016-06-25 15:07:17 --> Config Class Initialized
DEBUG - 2016-06-25 15:07:17 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:07:17 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:07:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:07:17 --> URI Class Initialized
DEBUG - 2016-06-25 15:07:17 --> Router Class Initialized
DEBUG - 2016-06-25 15:07:17 --> Output Class Initialized
DEBUG - 2016-06-25 15:07:17 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:07:17 --> Security Class Initialized
DEBUG - 2016-06-25 15:07:17 --> Input Class Initialized
DEBUG - 2016-06-25 15:07:17 --> XSS Filtering completed
DEBUG - 2016-06-25 15:07:17 --> XSS Filtering completed
DEBUG - 2016-06-25 15:07:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:07:17 --> Language Class Initialized
DEBUG - 2016-06-25 15:07:17 --> Loader Class Initialized
DEBUG - 2016-06-25 15:07:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:07:17 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:07:17 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:07:17 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:07:17 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:07:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:07:17 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:07:17 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:07:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:07:17 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:07:17 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:07:17 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:07:17 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:07:17 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:07:17 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:07:18 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:07:18 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:07:18 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:07:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:07:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:07:18 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:07:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:07:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:07:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:07:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:07:18 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:07:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:07:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:07:18 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:07:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:07:18 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:07:18 --> Session Class Initialized
DEBUG - 2016-06-25 15:07:18 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:07:18 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:07:18 --> Session routines successfully run
DEBUG - 2016-06-25 15:07:18 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:07:18 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:07:18 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:07:18 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:07:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:07:18 --> Controller Class Initialized
DEBUG - 2016-06-25 15:07:18 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:07:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:07:18 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:07:18 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:07:18 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:07:18 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:07:18 --> Model Class Initialized
DEBUG - 2016-06-25 15:07:18 --> Model Class Initialized
DEBUG - 2016-06-25 15:07:18 --> Model Class Initialized
DEBUG - 2016-06-25 15:07:18 --> Model Class Initialized
DEBUG - 2016-06-25 15:07:18 --> Model Class Initialized
DEBUG - 2016-06-25 15:07:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:07:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:07:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:07:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:07:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:07:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:07:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:07:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:07:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:07:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:07:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:07:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:07:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:07:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:07:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:07:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:07:18 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 15:07:18 --> Final output sent to browser
DEBUG - 2016-06-25 15:07:18 --> Total execution time: 0.6071
DEBUG - 2016-06-25 15:07:19 --> Config Class Initialized
DEBUG - 2016-06-25 15:07:19 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:07:19 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:07:19 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:07:19 --> URI Class Initialized
DEBUG - 2016-06-25 15:07:19 --> Router Class Initialized
DEBUG - 2016-06-25 15:07:19 --> Output Class Initialized
DEBUG - 2016-06-25 15:07:19 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:07:19 --> Security Class Initialized
DEBUG - 2016-06-25 15:07:19 --> Input Class Initialized
DEBUG - 2016-06-25 15:07:19 --> XSS Filtering completed
DEBUG - 2016-06-25 15:07:19 --> XSS Filtering completed
DEBUG - 2016-06-25 15:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:07:19 --> Language Class Initialized
DEBUG - 2016-06-25 15:07:19 --> Loader Class Initialized
DEBUG - 2016-06-25 15:07:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:07:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:07:19 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:07:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:07:20 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:07:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:07:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:07:20 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:07:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:07:20 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:07:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:07:20 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:07:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:07:20 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:07:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:07:20 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:07:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:07:20 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:07:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:07:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:07:20 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:07:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:07:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:07:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:07:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:07:20 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:07:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:07:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:07:20 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:07:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:07:20 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:07:20 --> Session Class Initialized
DEBUG - 2016-06-25 15:07:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:07:20 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:07:20 --> Session routines successfully run
DEBUG - 2016-06-25 15:07:20 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:07:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:07:20 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:07:20 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:07:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:07:20 --> Controller Class Initialized
DEBUG - 2016-06-25 15:07:20 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:07:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:07:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:07:20 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:07:20 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:07:20 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:07:20 --> Model Class Initialized
DEBUG - 2016-06-25 15:07:20 --> Model Class Initialized
DEBUG - 2016-06-25 15:07:20 --> Model Class Initialized
DEBUG - 2016-06-25 15:07:20 --> Model Class Initialized
DEBUG - 2016-06-25 15:07:20 --> Model Class Initialized
ERROR - 2016-06-25 15:07:20 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 15:07:20 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 15:07:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:07:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:07:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:07:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:07:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:07:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:07:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:07:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:07:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:07:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:07:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:07:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:07:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:07:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:07:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:07:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:07:20 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 15:07:20 --> Final output sent to browser
DEBUG - 2016-06-25 15:07:20 --> Total execution time: 0.6307
DEBUG - 2016-06-25 15:08:04 --> Config Class Initialized
DEBUG - 2016-06-25 15:08:04 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:08:04 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:08:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:08:04 --> URI Class Initialized
DEBUG - 2016-06-25 15:08:04 --> Router Class Initialized
DEBUG - 2016-06-25 15:08:04 --> Output Class Initialized
DEBUG - 2016-06-25 15:08:04 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:08:04 --> Security Class Initialized
DEBUG - 2016-06-25 15:08:04 --> Input Class Initialized
DEBUG - 2016-06-25 15:08:04 --> XSS Filtering completed
DEBUG - 2016-06-25 15:08:04 --> XSS Filtering completed
DEBUG - 2016-06-25 15:08:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:08:04 --> Language Class Initialized
DEBUG - 2016-06-25 15:08:04 --> Loader Class Initialized
DEBUG - 2016-06-25 15:08:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:08:04 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:08:04 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:08:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:08:05 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:08:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:08:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:08:05 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:08:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:08:05 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:08:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:08:05 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:08:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:08:05 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:08:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:08:05 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:08:05 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:08:05 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:08:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:08:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:08:05 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:08:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:08:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:08:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:08:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:08:05 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:08:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:08:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:08:05 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:08:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:08:05 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:08:05 --> Session Class Initialized
DEBUG - 2016-06-25 15:08:05 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:08:05 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:08:05 --> Session routines successfully run
DEBUG - 2016-06-25 15:08:05 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:08:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:08:05 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:08:05 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:08:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:08:05 --> Controller Class Initialized
DEBUG - 2016-06-25 15:08:05 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:08:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:08:05 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:08:05 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:08:05 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:08:05 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:08:05 --> Model Class Initialized
DEBUG - 2016-06-25 15:08:05 --> Model Class Initialized
DEBUG - 2016-06-25 15:08:05 --> Model Class Initialized
DEBUG - 2016-06-25 15:08:05 --> Model Class Initialized
DEBUG - 2016-06-25 15:08:05 --> Model Class Initialized
DEBUG - 2016-06-25 15:08:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:08:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:08:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:08:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:08:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:08:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:08:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:08:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:08:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:08:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:08:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:08:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:08:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:08:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:08:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:08:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:08:05 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 15:08:05 --> Final output sent to browser
DEBUG - 2016-06-25 15:08:05 --> Total execution time: 0.6397
DEBUG - 2016-06-25 15:08:06 --> Config Class Initialized
DEBUG - 2016-06-25 15:08:06 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:08:06 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:08:06 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:08:06 --> URI Class Initialized
DEBUG - 2016-06-25 15:08:06 --> Router Class Initialized
DEBUG - 2016-06-25 15:08:06 --> Output Class Initialized
DEBUG - 2016-06-25 15:08:06 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:08:06 --> Security Class Initialized
DEBUG - 2016-06-25 15:08:06 --> Input Class Initialized
DEBUG - 2016-06-25 15:08:06 --> XSS Filtering completed
DEBUG - 2016-06-25 15:08:06 --> XSS Filtering completed
DEBUG - 2016-06-25 15:08:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:08:06 --> Language Class Initialized
DEBUG - 2016-06-25 15:08:06 --> Loader Class Initialized
DEBUG - 2016-06-25 15:08:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:08:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:08:06 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:08:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:08:06 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:08:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:08:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:08:06 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:08:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:08:06 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:08:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:08:06 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:08:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:08:06 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:08:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:08:06 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:08:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:08:06 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:08:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:08:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:08:06 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:08:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:08:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:08:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:08:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:08:06 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:08:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:08:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:08:06 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:08:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:08:06 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:08:07 --> Session Class Initialized
DEBUG - 2016-06-25 15:08:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:08:07 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:08:07 --> Session routines successfully run
DEBUG - 2016-06-25 15:08:07 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:08:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:08:07 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:08:07 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:08:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:08:07 --> Controller Class Initialized
DEBUG - 2016-06-25 15:08:07 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:08:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:08:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:08:07 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:08:07 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:08:07 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:08:07 --> Model Class Initialized
DEBUG - 2016-06-25 15:08:07 --> Model Class Initialized
DEBUG - 2016-06-25 15:08:07 --> Model Class Initialized
DEBUG - 2016-06-25 15:08:07 --> Model Class Initialized
DEBUG - 2016-06-25 15:08:07 --> Model Class Initialized
ERROR - 2016-06-25 15:08:07 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 15:08:07 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 15:08:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:08:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:08:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:08:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:08:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:08:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:08:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:08:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:08:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:08:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:08:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:08:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:08:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:08:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:08:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:08:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:08:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 15:08:07 --> Final output sent to browser
DEBUG - 2016-06-25 15:08:07 --> Total execution time: 0.6626
DEBUG - 2016-06-25 15:11:14 --> Config Class Initialized
DEBUG - 2016-06-25 15:11:14 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:11:14 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:11:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:11:14 --> URI Class Initialized
DEBUG - 2016-06-25 15:11:14 --> Router Class Initialized
DEBUG - 2016-06-25 15:11:14 --> Output Class Initialized
DEBUG - 2016-06-25 15:11:14 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:11:14 --> Security Class Initialized
DEBUG - 2016-06-25 15:11:14 --> Input Class Initialized
DEBUG - 2016-06-25 15:11:15 --> XSS Filtering completed
DEBUG - 2016-06-25 15:11:15 --> XSS Filtering completed
DEBUG - 2016-06-25 15:11:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:11:15 --> Language Class Initialized
DEBUG - 2016-06-25 15:11:15 --> Loader Class Initialized
DEBUG - 2016-06-25 15:11:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:11:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:11:15 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:11:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:11:15 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:11:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:11:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:11:15 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:11:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:11:15 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:11:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:11:15 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:11:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:11:15 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:11:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:11:15 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:11:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:11:15 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:11:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:11:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:11:15 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:11:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:11:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:11:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:11:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:11:15 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:11:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:11:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:11:15 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:11:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:11:15 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:11:15 --> Session Class Initialized
DEBUG - 2016-06-25 15:11:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:11:15 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:11:15 --> Session routines successfully run
DEBUG - 2016-06-25 15:11:15 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:11:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:11:15 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:11:15 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:11:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:11:15 --> Controller Class Initialized
DEBUG - 2016-06-25 15:11:15 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:11:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:11:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:11:15 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:11:15 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:11:15 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:11:15 --> Model Class Initialized
DEBUG - 2016-06-25 15:11:15 --> Model Class Initialized
DEBUG - 2016-06-25 15:11:15 --> Model Class Initialized
DEBUG - 2016-06-25 15:11:15 --> Model Class Initialized
DEBUG - 2016-06-25 15:11:15 --> Model Class Initialized
DEBUG - 2016-06-25 15:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:11:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:11:15 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 15:11:15 --> Final output sent to browser
DEBUG - 2016-06-25 15:11:15 --> Total execution time: 0.6698
DEBUG - 2016-06-25 15:11:16 --> Config Class Initialized
DEBUG - 2016-06-25 15:11:16 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:11:16 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:11:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:11:16 --> URI Class Initialized
DEBUG - 2016-06-25 15:11:16 --> Router Class Initialized
DEBUG - 2016-06-25 15:11:16 --> Output Class Initialized
DEBUG - 2016-06-25 15:11:16 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:11:16 --> Security Class Initialized
DEBUG - 2016-06-25 15:11:16 --> Input Class Initialized
DEBUG - 2016-06-25 15:11:16 --> XSS Filtering completed
DEBUG - 2016-06-25 15:11:16 --> XSS Filtering completed
DEBUG - 2016-06-25 15:11:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:11:16 --> Language Class Initialized
DEBUG - 2016-06-25 15:11:16 --> Loader Class Initialized
DEBUG - 2016-06-25 15:11:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:11:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:11:16 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:11:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:11:16 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:11:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:11:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:11:16 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:11:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:11:16 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:11:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:11:16 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:11:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:11:17 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:11:17 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:11:17 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:11:17 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:11:17 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:11:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:11:17 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:11:17 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:11:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:11:17 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:11:17 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:11:17 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:11:17 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:11:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:11:17 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:11:17 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:11:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:11:17 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:11:17 --> Session Class Initialized
DEBUG - 2016-06-25 15:11:17 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:11:17 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:11:17 --> Session routines successfully run
DEBUG - 2016-06-25 15:11:17 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:11:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:11:17 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:11:17 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:11:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:11:17 --> Controller Class Initialized
DEBUG - 2016-06-25 15:11:17 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:11:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:11:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:11:17 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:11:17 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:11:17 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:11:17 --> Model Class Initialized
DEBUG - 2016-06-25 15:11:17 --> Model Class Initialized
DEBUG - 2016-06-25 15:11:17 --> Model Class Initialized
DEBUG - 2016-06-25 15:11:17 --> Model Class Initialized
DEBUG - 2016-06-25 15:11:17 --> Model Class Initialized
ERROR - 2016-06-25 15:11:17 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 15:11:17 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 15:11:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:11:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:11:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:11:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:11:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:11:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:11:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:11:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:11:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:11:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:11:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:11:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:11:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:11:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:11:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:11:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:11:17 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 15:11:17 --> Final output sent to browser
DEBUG - 2016-06-25 15:11:17 --> Total execution time: 0.7549
DEBUG - 2016-06-25 15:11:52 --> Config Class Initialized
DEBUG - 2016-06-25 15:11:52 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:11:52 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:11:52 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:11:52 --> URI Class Initialized
DEBUG - 2016-06-25 15:11:52 --> Router Class Initialized
DEBUG - 2016-06-25 15:11:52 --> Output Class Initialized
DEBUG - 2016-06-25 15:11:52 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:11:52 --> Security Class Initialized
DEBUG - 2016-06-25 15:11:52 --> Input Class Initialized
DEBUG - 2016-06-25 15:11:52 --> XSS Filtering completed
DEBUG - 2016-06-25 15:11:52 --> XSS Filtering completed
DEBUG - 2016-06-25 15:11:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:11:52 --> Language Class Initialized
DEBUG - 2016-06-25 15:11:52 --> Loader Class Initialized
DEBUG - 2016-06-25 15:11:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:11:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:11:52 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:11:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:11:52 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:11:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:11:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:11:52 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:11:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:11:52 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:11:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:11:52 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:11:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:11:52 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:11:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:11:52 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:11:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:11:52 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:11:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:11:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:11:52 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:11:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:11:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:11:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:11:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:11:52 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:11:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:11:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:11:52 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:11:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:11:52 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:11:52 --> Session Class Initialized
DEBUG - 2016-06-25 15:11:52 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:11:52 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:11:52 --> Session routines successfully run
DEBUG - 2016-06-25 15:11:52 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:11:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:11:52 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:11:52 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:11:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:11:52 --> Controller Class Initialized
DEBUG - 2016-06-25 15:11:52 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:11:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:11:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:11:52 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:11:52 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:11:52 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:11:52 --> Model Class Initialized
DEBUG - 2016-06-25 15:11:52 --> Model Class Initialized
DEBUG - 2016-06-25 15:11:52 --> Model Class Initialized
DEBUG - 2016-06-25 15:11:52 --> Model Class Initialized
DEBUG - 2016-06-25 15:11:52 --> Model Class Initialized
DEBUG - 2016-06-25 15:11:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:11:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:11:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:11:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:11:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:11:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:11:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:11:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:11:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:11:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:11:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:11:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:11:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:11:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:11:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:11:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:11:53 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 15:11:53 --> Final output sent to browser
DEBUG - 2016-06-25 15:11:53 --> Total execution time: 0.7000
DEBUG - 2016-06-25 15:11:54 --> Config Class Initialized
DEBUG - 2016-06-25 15:11:54 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:11:54 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:11:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:11:54 --> URI Class Initialized
DEBUG - 2016-06-25 15:11:54 --> Router Class Initialized
DEBUG - 2016-06-25 15:11:54 --> Output Class Initialized
DEBUG - 2016-06-25 15:11:54 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:11:54 --> Security Class Initialized
DEBUG - 2016-06-25 15:11:54 --> Input Class Initialized
DEBUG - 2016-06-25 15:11:54 --> XSS Filtering completed
DEBUG - 2016-06-25 15:11:54 --> XSS Filtering completed
DEBUG - 2016-06-25 15:11:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:11:54 --> Language Class Initialized
DEBUG - 2016-06-25 15:11:54 --> Loader Class Initialized
DEBUG - 2016-06-25 15:11:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:11:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:11:54 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:11:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:11:54 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:11:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:11:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:11:54 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:11:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:11:54 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:11:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:11:54 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:11:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:11:54 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:11:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:11:54 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:11:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:11:54 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:11:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:11:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:11:54 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:11:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:11:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:11:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:11:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:11:54 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:11:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:11:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:11:54 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:11:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:11:54 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:11:54 --> Session Class Initialized
DEBUG - 2016-06-25 15:11:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:11:54 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:11:54 --> Session routines successfully run
DEBUG - 2016-06-25 15:11:54 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:11:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:11:54 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:11:54 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:11:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:11:54 --> Controller Class Initialized
DEBUG - 2016-06-25 15:11:54 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:11:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:11:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:11:54 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:11:54 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:11:54 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:11:54 --> Model Class Initialized
DEBUG - 2016-06-25 15:11:54 --> Model Class Initialized
DEBUG - 2016-06-25 15:11:54 --> Model Class Initialized
DEBUG - 2016-06-25 15:11:54 --> Model Class Initialized
DEBUG - 2016-06-25 15:11:54 --> Model Class Initialized
ERROR - 2016-06-25 15:11:54 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 15:11:54 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 15:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:11:55 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 15:11:55 --> Final output sent to browser
DEBUG - 2016-06-25 15:11:55 --> Total execution time: 0.7513
DEBUG - 2016-06-25 15:14:30 --> Config Class Initialized
DEBUG - 2016-06-25 15:14:30 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:14:30 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:14:30 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:14:30 --> URI Class Initialized
DEBUG - 2016-06-25 15:14:30 --> Router Class Initialized
DEBUG - 2016-06-25 15:14:30 --> Output Class Initialized
DEBUG - 2016-06-25 15:14:30 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:14:30 --> Security Class Initialized
DEBUG - 2016-06-25 15:14:30 --> Input Class Initialized
DEBUG - 2016-06-25 15:14:30 --> XSS Filtering completed
DEBUG - 2016-06-25 15:14:30 --> XSS Filtering completed
DEBUG - 2016-06-25 15:14:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:14:30 --> Language Class Initialized
DEBUG - 2016-06-25 15:14:30 --> Loader Class Initialized
DEBUG - 2016-06-25 15:14:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:14:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:14:30 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:14:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:14:30 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:14:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:14:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:14:30 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:14:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:14:30 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:14:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:14:30 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:14:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:14:30 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:14:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:14:30 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:14:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:14:30 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:14:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:14:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:14:30 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:14:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:14:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:14:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:14:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:14:30 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:14:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:14:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:14:30 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:14:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:14:30 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:14:30 --> Session Class Initialized
DEBUG - 2016-06-25 15:14:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:14:30 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:14:30 --> Session routines successfully run
DEBUG - 2016-06-25 15:14:30 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:14:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:14:30 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:14:30 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:14:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:14:30 --> Controller Class Initialized
DEBUG - 2016-06-25 15:14:30 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:14:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:14:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:14:30 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:14:30 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:14:30 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:14:30 --> Model Class Initialized
DEBUG - 2016-06-25 15:14:30 --> Model Class Initialized
DEBUG - 2016-06-25 15:14:30 --> Model Class Initialized
DEBUG - 2016-06-25 15:14:30 --> Model Class Initialized
DEBUG - 2016-06-25 15:14:30 --> Model Class Initialized
DEBUG - 2016-06-25 15:14:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:14:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:14:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:14:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:14:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:14:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:14:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:14:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:14:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:14:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:14:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:14:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:14:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:14:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:14:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:14:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:14:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 15:14:31 --> Final output sent to browser
DEBUG - 2016-06-25 15:14:31 --> Total execution time: 0.7342
DEBUG - 2016-06-25 15:14:31 --> Config Class Initialized
DEBUG - 2016-06-25 15:14:32 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:14:32 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:14:32 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:14:32 --> URI Class Initialized
DEBUG - 2016-06-25 15:14:32 --> Router Class Initialized
DEBUG - 2016-06-25 15:14:32 --> Output Class Initialized
DEBUG - 2016-06-25 15:14:32 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:14:32 --> Security Class Initialized
DEBUG - 2016-06-25 15:14:32 --> Input Class Initialized
DEBUG - 2016-06-25 15:14:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:14:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:14:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:14:32 --> Language Class Initialized
DEBUG - 2016-06-25 15:14:32 --> Loader Class Initialized
DEBUG - 2016-06-25 15:14:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:14:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:14:32 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:14:32 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:14:32 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:14:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:14:32 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:14:32 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:14:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:14:32 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:14:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:14:32 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:14:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:14:32 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:14:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:14:32 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:14:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:14:32 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:14:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:14:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:14:32 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:14:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:14:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:14:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:14:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:14:32 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:14:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:14:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:14:32 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:14:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:14:32 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:14:32 --> Session Class Initialized
DEBUG - 2016-06-25 15:14:32 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:14:32 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:14:32 --> Session routines successfully run
DEBUG - 2016-06-25 15:14:32 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:14:32 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:14:32 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:14:32 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:14:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:14:32 --> Controller Class Initialized
DEBUG - 2016-06-25 15:14:32 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:14:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:14:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:14:32 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:14:32 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:14:32 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:14:32 --> Model Class Initialized
DEBUG - 2016-06-25 15:14:32 --> Model Class Initialized
DEBUG - 2016-06-25 15:14:32 --> Model Class Initialized
DEBUG - 2016-06-25 15:14:32 --> Model Class Initialized
DEBUG - 2016-06-25 15:14:32 --> Model Class Initialized
ERROR - 2016-06-25 15:14:32 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 15:14:32 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 15:14:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:14:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:14:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:14:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:14:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:14:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:14:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:14:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:14:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:14:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:14:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:14:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:14:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:14:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:14:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:14:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:14:32 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 15:14:32 --> Final output sent to browser
DEBUG - 2016-06-25 15:14:32 --> Total execution time: 0.7663
DEBUG - 2016-06-25 15:15:51 --> Config Class Initialized
DEBUG - 2016-06-25 15:15:51 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:15:51 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:15:51 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:15:51 --> URI Class Initialized
DEBUG - 2016-06-25 15:15:51 --> Router Class Initialized
DEBUG - 2016-06-25 15:15:51 --> Output Class Initialized
DEBUG - 2016-06-25 15:15:51 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:15:51 --> Security Class Initialized
DEBUG - 2016-06-25 15:15:51 --> Input Class Initialized
DEBUG - 2016-06-25 15:15:51 --> XSS Filtering completed
DEBUG - 2016-06-25 15:15:51 --> XSS Filtering completed
DEBUG - 2016-06-25 15:15:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:15:51 --> Language Class Initialized
DEBUG - 2016-06-25 15:15:51 --> Loader Class Initialized
DEBUG - 2016-06-25 15:15:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:15:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:15:51 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:15:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:15:51 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:15:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:15:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:15:51 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:15:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:15:51 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:15:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:15:51 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:15:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:15:51 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:15:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:15:51 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:15:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:15:51 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:15:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:15:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:15:51 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:15:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:15:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:15:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:15:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:15:51 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:15:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:15:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:15:51 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:15:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:15:51 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:15:51 --> Session Class Initialized
DEBUG - 2016-06-25 15:15:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:15:52 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:15:52 --> Session routines successfully run
DEBUG - 2016-06-25 15:15:52 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:15:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:15:52 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:15:52 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:15:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:15:52 --> Controller Class Initialized
DEBUG - 2016-06-25 15:15:52 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:15:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:15:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:15:52 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:15:52 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:15:52 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:15:52 --> Model Class Initialized
DEBUG - 2016-06-25 15:15:52 --> Model Class Initialized
DEBUG - 2016-06-25 15:15:52 --> Model Class Initialized
DEBUG - 2016-06-25 15:15:52 --> Model Class Initialized
DEBUG - 2016-06-25 15:15:52 --> Model Class Initialized
DEBUG - 2016-06-25 15:15:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:15:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:15:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:15:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:15:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:15:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:15:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:15:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:15:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:15:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:15:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:15:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:15:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:15:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:15:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:15:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:15:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 15:15:52 --> Final output sent to browser
DEBUG - 2016-06-25 15:15:52 --> Total execution time: 0.7731
DEBUG - 2016-06-25 15:15:53 --> Config Class Initialized
DEBUG - 2016-06-25 15:15:53 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:15:53 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:15:53 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:15:53 --> URI Class Initialized
DEBUG - 2016-06-25 15:15:53 --> Router Class Initialized
DEBUG - 2016-06-25 15:15:53 --> Output Class Initialized
DEBUG - 2016-06-25 15:15:53 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:15:53 --> Security Class Initialized
DEBUG - 2016-06-25 15:15:53 --> Input Class Initialized
DEBUG - 2016-06-25 15:15:53 --> XSS Filtering completed
DEBUG - 2016-06-25 15:15:53 --> XSS Filtering completed
DEBUG - 2016-06-25 15:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:15:53 --> Language Class Initialized
DEBUG - 2016-06-25 15:15:53 --> Loader Class Initialized
DEBUG - 2016-06-25 15:15:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:15:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:15:53 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:15:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:15:53 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:15:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:15:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:15:53 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:15:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:15:53 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:15:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:15:53 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:15:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:15:53 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:15:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:15:53 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:15:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:15:53 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:15:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:15:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:15:53 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:15:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:15:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:15:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:15:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:15:53 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:15:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:15:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:15:53 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:15:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:15:53 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:15:53 --> Session Class Initialized
DEBUG - 2016-06-25 15:15:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:15:53 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:15:53 --> Session routines successfully run
DEBUG - 2016-06-25 15:15:53 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:15:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:15:53 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:15:53 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:15:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:15:53 --> Controller Class Initialized
DEBUG - 2016-06-25 15:15:53 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:15:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:15:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:15:54 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:15:54 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:15:54 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:15:54 --> Model Class Initialized
DEBUG - 2016-06-25 15:15:54 --> Model Class Initialized
DEBUG - 2016-06-25 15:15:54 --> Model Class Initialized
DEBUG - 2016-06-25 15:15:54 --> Model Class Initialized
DEBUG - 2016-06-25 15:15:54 --> Model Class Initialized
ERROR - 2016-06-25 15:15:54 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 15:15:54 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 15:15:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:15:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:15:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:15:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:15:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:15:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:15:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:15:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:15:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:15:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:15:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:15:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:15:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:15:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:15:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:15:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:15:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 15:15:54 --> Final output sent to browser
DEBUG - 2016-06-25 15:15:54 --> Total execution time: 0.8213
DEBUG - 2016-06-25 15:20:28 --> Config Class Initialized
DEBUG - 2016-06-25 15:20:28 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:20:28 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:20:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:20:28 --> URI Class Initialized
DEBUG - 2016-06-25 15:20:28 --> Router Class Initialized
DEBUG - 2016-06-25 15:20:28 --> Output Class Initialized
DEBUG - 2016-06-25 15:20:28 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:20:28 --> Security Class Initialized
DEBUG - 2016-06-25 15:20:28 --> Input Class Initialized
DEBUG - 2016-06-25 15:20:28 --> XSS Filtering completed
DEBUG - 2016-06-25 15:20:28 --> XSS Filtering completed
DEBUG - 2016-06-25 15:20:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:20:28 --> Language Class Initialized
DEBUG - 2016-06-25 15:20:28 --> Loader Class Initialized
DEBUG - 2016-06-25 15:20:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:20:28 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:20:28 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:20:28 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:20:29 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:20:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:20:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:20:29 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:20:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:20:29 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:20:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:20:29 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:20:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:20:29 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:20:29 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:20:29 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:20:29 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:20:29 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:20:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:20:29 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:20:29 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:20:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:20:29 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:20:29 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:20:29 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:20:29 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:20:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:20:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:20:29 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:20:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:20:29 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:20:29 --> Session Class Initialized
DEBUG - 2016-06-25 15:20:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:20:29 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:20:29 --> Session routines successfully run
DEBUG - 2016-06-25 15:20:29 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:20:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:20:29 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:20:29 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:20:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:20:29 --> Controller Class Initialized
DEBUG - 2016-06-25 15:20:29 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:20:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:20:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:20:29 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:20:29 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:20:29 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:20:29 --> Model Class Initialized
DEBUG - 2016-06-25 15:20:29 --> Model Class Initialized
DEBUG - 2016-06-25 15:20:29 --> Model Class Initialized
DEBUG - 2016-06-25 15:20:29 --> Model Class Initialized
DEBUG - 2016-06-25 15:20:29 --> Model Class Initialized
DEBUG - 2016-06-25 15:20:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:20:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:20:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:20:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:20:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:20:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:20:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:20:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:20:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:20:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:20:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:20:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:20:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:20:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:20:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:20:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:20:29 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 15:20:29 --> Final output sent to browser
DEBUG - 2016-06-25 15:20:29 --> Total execution time: 0.7898
DEBUG - 2016-06-25 15:20:31 --> Config Class Initialized
DEBUG - 2016-06-25 15:20:31 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:20:31 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:20:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:20:31 --> URI Class Initialized
DEBUG - 2016-06-25 15:20:31 --> Router Class Initialized
DEBUG - 2016-06-25 15:20:31 --> Output Class Initialized
DEBUG - 2016-06-25 15:20:31 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:20:31 --> Security Class Initialized
DEBUG - 2016-06-25 15:20:31 --> Input Class Initialized
DEBUG - 2016-06-25 15:20:31 --> XSS Filtering completed
DEBUG - 2016-06-25 15:20:31 --> XSS Filtering completed
DEBUG - 2016-06-25 15:20:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:20:31 --> Language Class Initialized
DEBUG - 2016-06-25 15:20:31 --> Loader Class Initialized
DEBUG - 2016-06-25 15:20:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:20:31 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:20:31 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:20:31 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:20:31 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:20:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:20:31 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:20:32 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:20:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:20:32 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:20:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:20:32 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:20:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:20:32 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:20:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:20:32 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:20:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:20:32 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:20:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:20:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:20:32 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:20:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:20:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:20:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:20:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:20:32 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:20:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:20:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:20:32 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:20:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:20:32 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:20:32 --> Session Class Initialized
DEBUG - 2016-06-25 15:20:32 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:20:32 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:20:32 --> Session routines successfully run
DEBUG - 2016-06-25 15:20:32 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:20:32 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:20:32 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:20:32 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:20:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:20:32 --> Controller Class Initialized
DEBUG - 2016-06-25 15:20:32 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:20:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:20:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:20:32 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:20:32 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:20:32 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:20:32 --> Model Class Initialized
DEBUG - 2016-06-25 15:20:32 --> Model Class Initialized
DEBUG - 2016-06-25 15:20:32 --> Model Class Initialized
DEBUG - 2016-06-25 15:20:32 --> Model Class Initialized
DEBUG - 2016-06-25 15:20:32 --> Model Class Initialized
ERROR - 2016-06-25 15:20:32 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 15:20:32 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 15:20:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:20:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:20:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:20:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:20:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:20:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:20:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:20:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:20:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:20:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:20:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:20:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:20:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:20:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:20:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:20:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:20:32 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 15:20:32 --> Final output sent to browser
DEBUG - 2016-06-25 15:20:32 --> Total execution time: 0.8950
DEBUG - 2016-06-25 15:22:58 --> Config Class Initialized
DEBUG - 2016-06-25 15:22:58 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:22:58 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:22:58 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:22:58 --> URI Class Initialized
DEBUG - 2016-06-25 15:22:58 --> Router Class Initialized
DEBUG - 2016-06-25 15:22:58 --> Output Class Initialized
DEBUG - 2016-06-25 15:22:58 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:22:58 --> Security Class Initialized
DEBUG - 2016-06-25 15:22:58 --> Input Class Initialized
DEBUG - 2016-06-25 15:22:58 --> XSS Filtering completed
DEBUG - 2016-06-25 15:22:58 --> XSS Filtering completed
DEBUG - 2016-06-25 15:22:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:22:58 --> Language Class Initialized
DEBUG - 2016-06-25 15:22:58 --> Loader Class Initialized
DEBUG - 2016-06-25 15:22:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:22:58 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:22:58 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:22:58 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:22:58 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:22:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:22:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:22:58 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:22:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:22:58 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:22:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:22:58 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:22:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:22:58 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:22:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:22:58 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:22:58 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:22:58 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:22:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:22:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:22:59 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:22:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:22:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:22:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:22:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:22:59 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:22:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:22:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:22:59 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:22:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:22:59 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:22:59 --> Session Class Initialized
DEBUG - 2016-06-25 15:22:59 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:22:59 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:22:59 --> Session routines successfully run
DEBUG - 2016-06-25 15:22:59 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:22:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:22:59 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:22:59 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:22:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:22:59 --> Controller Class Initialized
DEBUG - 2016-06-25 15:22:59 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:22:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:22:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:22:59 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:22:59 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:22:59 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:22:59 --> Model Class Initialized
DEBUG - 2016-06-25 15:22:59 --> Model Class Initialized
DEBUG - 2016-06-25 15:22:59 --> Model Class Initialized
DEBUG - 2016-06-25 15:22:59 --> Model Class Initialized
DEBUG - 2016-06-25 15:22:59 --> Model Class Initialized
DEBUG - 2016-06-25 15:22:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:22:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:22:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:22:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:22:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:22:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:22:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:22:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:22:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:22:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:22:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:22:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:22:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:22:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:22:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:22:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:22:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 15:22:59 --> Final output sent to browser
DEBUG - 2016-06-25 15:22:59 --> Total execution time: 0.8301
DEBUG - 2016-06-25 15:23:00 --> Config Class Initialized
DEBUG - 2016-06-25 15:23:00 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:23:00 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:23:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:23:00 --> URI Class Initialized
DEBUG - 2016-06-25 15:23:00 --> Router Class Initialized
DEBUG - 2016-06-25 15:23:00 --> Output Class Initialized
DEBUG - 2016-06-25 15:23:00 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:23:00 --> Security Class Initialized
DEBUG - 2016-06-25 15:23:00 --> Input Class Initialized
DEBUG - 2016-06-25 15:23:00 --> XSS Filtering completed
DEBUG - 2016-06-25 15:23:00 --> XSS Filtering completed
DEBUG - 2016-06-25 15:23:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:23:00 --> Language Class Initialized
DEBUG - 2016-06-25 15:23:00 --> Loader Class Initialized
DEBUG - 2016-06-25 15:23:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:23:00 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:23:00 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:23:00 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:23:00 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:23:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:23:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:23:00 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:23:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:23:00 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:23:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:23:00 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:23:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:23:00 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:23:00 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:23:00 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:23:00 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:23:00 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:23:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:23:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:23:01 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:23:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:23:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:23:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:23:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:23:01 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:23:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:23:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:23:01 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:23:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:23:01 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:23:01 --> Session Class Initialized
DEBUG - 2016-06-25 15:23:01 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:23:01 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:23:01 --> Session routines successfully run
DEBUG - 2016-06-25 15:23:01 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:23:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:23:01 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:23:01 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:23:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:23:01 --> Controller Class Initialized
DEBUG - 2016-06-25 15:23:01 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:23:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:23:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:23:01 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:23:01 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:23:01 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:23:01 --> Model Class Initialized
DEBUG - 2016-06-25 15:23:01 --> Model Class Initialized
DEBUG - 2016-06-25 15:23:01 --> Model Class Initialized
DEBUG - 2016-06-25 15:23:01 --> Model Class Initialized
DEBUG - 2016-06-25 15:23:01 --> Model Class Initialized
ERROR - 2016-06-25 15:23:01 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 15:23:01 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 15:23:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:23:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:23:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:23:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:23:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:23:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:23:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:23:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:23:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:23:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:23:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:23:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:23:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:23:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:23:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:23:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:23:01 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 15:23:01 --> Final output sent to browser
DEBUG - 2016-06-25 15:23:01 --> Total execution time: 0.9347
DEBUG - 2016-06-25 15:23:22 --> Config Class Initialized
DEBUG - 2016-06-25 15:23:22 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:23:22 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:23:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:23:22 --> URI Class Initialized
DEBUG - 2016-06-25 15:23:22 --> Router Class Initialized
DEBUG - 2016-06-25 15:23:22 --> Output Class Initialized
DEBUG - 2016-06-25 15:23:22 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:23:22 --> Security Class Initialized
DEBUG - 2016-06-25 15:23:22 --> Input Class Initialized
DEBUG - 2016-06-25 15:23:22 --> XSS Filtering completed
DEBUG - 2016-06-25 15:23:22 --> XSS Filtering completed
DEBUG - 2016-06-25 15:23:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:23:22 --> Language Class Initialized
DEBUG - 2016-06-25 15:23:22 --> Loader Class Initialized
DEBUG - 2016-06-25 15:23:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:23:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:23:22 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:23:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:23:22 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:23:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:23:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:23:22 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:23:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:23:22 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:23:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:23:22 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:23:22 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:23:22 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:23:22 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:23:22 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:23:22 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:23:22 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:23:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:23:22 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:23:22 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:23:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:23:22 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:23:22 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:23:22 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:23:22 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:23:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:23:22 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:23:22 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:23:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:23:22 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:23:22 --> Session Class Initialized
DEBUG - 2016-06-25 15:23:22 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:23:22 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:23:23 --> Session routines successfully run
DEBUG - 2016-06-25 15:23:23 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:23:23 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:23:23 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:23:23 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:23:23 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:23:23 --> Controller Class Initialized
DEBUG - 2016-06-25 15:23:23 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:23:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:23:23 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:23:23 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:23:23 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:23:23 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:23:23 --> Model Class Initialized
DEBUG - 2016-06-25 15:23:23 --> Model Class Initialized
DEBUG - 2016-06-25 15:23:23 --> Model Class Initialized
DEBUG - 2016-06-25 15:23:23 --> Model Class Initialized
DEBUG - 2016-06-25 15:23:23 --> Model Class Initialized
DEBUG - 2016-06-25 15:23:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:23:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:23:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:23:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:23:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:23:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:23:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:23:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:23:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:23:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:23:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:23:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:23:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:23:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:23:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:23:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:23:23 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 15:23:23 --> Final output sent to browser
DEBUG - 2016-06-25 15:23:23 --> Total execution time: 0.8761
DEBUG - 2016-06-25 15:23:24 --> Config Class Initialized
DEBUG - 2016-06-25 15:23:24 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:23:24 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:23:24 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:23:24 --> URI Class Initialized
DEBUG - 2016-06-25 15:23:24 --> Router Class Initialized
DEBUG - 2016-06-25 15:23:24 --> Output Class Initialized
DEBUG - 2016-06-25 15:23:24 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:23:24 --> Security Class Initialized
DEBUG - 2016-06-25 15:23:24 --> Input Class Initialized
DEBUG - 2016-06-25 15:23:24 --> XSS Filtering completed
DEBUG - 2016-06-25 15:23:24 --> XSS Filtering completed
DEBUG - 2016-06-25 15:23:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:23:24 --> Language Class Initialized
DEBUG - 2016-06-25 15:23:24 --> Loader Class Initialized
DEBUG - 2016-06-25 15:23:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:23:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:23:24 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:23:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:23:24 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:23:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:23:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:23:24 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:23:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:23:24 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:23:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:23:24 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:23:24 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:23:24 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:23:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:23:24 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:23:24 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:23:24 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:23:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:23:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:23:24 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:23:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:23:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:23:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:23:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:23:24 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:23:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:23:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:23:24 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:23:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:23:24 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:23:24 --> Session Class Initialized
DEBUG - 2016-06-25 15:23:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:23:24 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:23:25 --> Session routines successfully run
DEBUG - 2016-06-25 15:23:25 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:23:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:23:25 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:23:25 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:23:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:23:25 --> Controller Class Initialized
DEBUG - 2016-06-25 15:23:25 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:23:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:23:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:23:25 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:23:25 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:23:25 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:23:25 --> Model Class Initialized
DEBUG - 2016-06-25 15:23:25 --> Model Class Initialized
DEBUG - 2016-06-25 15:23:25 --> Model Class Initialized
DEBUG - 2016-06-25 15:23:25 --> Model Class Initialized
DEBUG - 2016-06-25 15:23:25 --> Model Class Initialized
ERROR - 2016-06-25 15:23:25 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 15:23:25 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 15:23:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:23:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:23:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:23:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:23:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:23:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:23:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:23:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:23:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:23:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:23:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:23:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:23:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:23:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:23:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:23:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:23:25 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 15:23:25 --> Final output sent to browser
DEBUG - 2016-06-25 15:23:25 --> Total execution time: 0.9233
DEBUG - 2016-06-25 15:24:30 --> Config Class Initialized
DEBUG - 2016-06-25 15:24:30 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:24:30 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:24:30 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:24:30 --> URI Class Initialized
DEBUG - 2016-06-25 15:24:30 --> Router Class Initialized
DEBUG - 2016-06-25 15:24:30 --> Output Class Initialized
DEBUG - 2016-06-25 15:24:30 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:24:30 --> Security Class Initialized
DEBUG - 2016-06-25 15:24:30 --> Input Class Initialized
DEBUG - 2016-06-25 15:24:30 --> XSS Filtering completed
DEBUG - 2016-06-25 15:24:30 --> XSS Filtering completed
DEBUG - 2016-06-25 15:24:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:24:30 --> Language Class Initialized
DEBUG - 2016-06-25 15:24:30 --> Loader Class Initialized
DEBUG - 2016-06-25 15:24:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:24:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:24:30 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:24:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:24:30 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:24:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:24:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:24:30 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:24:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:24:30 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:24:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:24:30 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:24:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:24:30 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:24:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:24:30 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:24:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:24:30 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:24:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:24:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:24:30 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:24:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:24:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:24:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:24:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:24:30 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:24:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:24:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:24:30 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:24:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:24:30 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:24:30 --> Session Class Initialized
DEBUG - 2016-06-25 15:24:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:24:30 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:24:30 --> Session routines successfully run
DEBUG - 2016-06-25 15:24:30 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:24:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:24:30 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:24:30 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:24:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:24:30 --> Controller Class Initialized
DEBUG - 2016-06-25 15:24:30 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:24:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:24:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:24:30 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:24:30 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:24:30 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:24:30 --> Model Class Initialized
DEBUG - 2016-06-25 15:24:30 --> Model Class Initialized
DEBUG - 2016-06-25 15:24:30 --> Model Class Initialized
DEBUG - 2016-06-25 15:24:30 --> Model Class Initialized
DEBUG - 2016-06-25 15:24:30 --> Model Class Initialized
DEBUG - 2016-06-25 15:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:24:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 15:24:31 --> Final output sent to browser
DEBUG - 2016-06-25 15:24:31 --> Total execution time: 0.9006
DEBUG - 2016-06-25 15:24:32 --> Config Class Initialized
DEBUG - 2016-06-25 15:24:32 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:24:32 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:24:32 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:24:32 --> URI Class Initialized
DEBUG - 2016-06-25 15:24:32 --> Router Class Initialized
DEBUG - 2016-06-25 15:24:32 --> Output Class Initialized
DEBUG - 2016-06-25 15:24:32 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:24:32 --> Security Class Initialized
DEBUG - 2016-06-25 15:24:32 --> Input Class Initialized
DEBUG - 2016-06-25 15:24:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:24:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:24:32 --> Language Class Initialized
DEBUG - 2016-06-25 15:24:32 --> Loader Class Initialized
DEBUG - 2016-06-25 15:24:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:24:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:24:32 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:24:32 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:24:32 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:24:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:24:32 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:24:32 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:24:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:24:32 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:24:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:24:33 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:24:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:24:33 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:24:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:24:33 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:24:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:24:33 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:24:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:24:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:24:33 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:24:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:24:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:24:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:24:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:24:33 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:24:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:24:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:24:33 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:24:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:24:33 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:24:33 --> Session Class Initialized
DEBUG - 2016-06-25 15:24:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:24:33 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:24:33 --> Session routines successfully run
DEBUG - 2016-06-25 15:24:33 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:24:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:24:33 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:24:33 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:24:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:24:33 --> Controller Class Initialized
DEBUG - 2016-06-25 15:24:33 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:24:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:24:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:24:33 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:24:33 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:24:33 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:24:33 --> Model Class Initialized
DEBUG - 2016-06-25 15:24:33 --> Model Class Initialized
DEBUG - 2016-06-25 15:24:33 --> Model Class Initialized
DEBUG - 2016-06-25 15:24:33 --> Model Class Initialized
DEBUG - 2016-06-25 15:24:33 --> Model Class Initialized
ERROR - 2016-06-25 15:24:33 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 15:24:33 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 15:24:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:24:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:24:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:24:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:24:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:24:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:24:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:24:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:24:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:24:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:24:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:24:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:24:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:24:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:24:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:24:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:24:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 15:24:33 --> Final output sent to browser
DEBUG - 2016-06-25 15:24:33 --> Total execution time: 0.9620
DEBUG - 2016-06-25 15:28:46 --> Config Class Initialized
DEBUG - 2016-06-25 15:28:46 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:28:46 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:28:46 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:28:46 --> URI Class Initialized
DEBUG - 2016-06-25 15:28:46 --> Router Class Initialized
DEBUG - 2016-06-25 15:28:46 --> Output Class Initialized
DEBUG - 2016-06-25 15:28:46 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:28:46 --> Security Class Initialized
DEBUG - 2016-06-25 15:28:46 --> Input Class Initialized
DEBUG - 2016-06-25 15:28:46 --> XSS Filtering completed
DEBUG - 2016-06-25 15:28:46 --> XSS Filtering completed
DEBUG - 2016-06-25 15:28:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:28:46 --> Language Class Initialized
DEBUG - 2016-06-25 15:28:46 --> Loader Class Initialized
DEBUG - 2016-06-25 15:28:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:28:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:28:46 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:28:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:28:46 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:28:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:28:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:28:46 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:28:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:28:46 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:28:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:28:46 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:28:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:28:46 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:28:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:28:46 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:28:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:28:46 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:28:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:28:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:28:46 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:28:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:28:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:28:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:28:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:28:46 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:28:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:28:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:28:46 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:28:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:28:46 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:28:46 --> Session Class Initialized
DEBUG - 2016-06-25 15:28:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:28:46 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:28:46 --> Session routines successfully run
DEBUG - 2016-06-25 15:28:46 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:28:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:28:46 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:28:46 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:28:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:28:47 --> Controller Class Initialized
DEBUG - 2016-06-25 15:28:47 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:28:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:28:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:28:47 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:28:47 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:28:47 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:28:47 --> Model Class Initialized
DEBUG - 2016-06-25 15:28:47 --> Model Class Initialized
DEBUG - 2016-06-25 15:28:47 --> Model Class Initialized
DEBUG - 2016-06-25 15:28:47 --> Model Class Initialized
DEBUG - 2016-06-25 15:28:47 --> Model Class Initialized
DEBUG - 2016-06-25 15:28:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:28:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:28:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:28:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:28:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:28:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:28:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:28:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:28:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:28:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:28:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:28:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:28:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:28:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:28:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:28:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:28:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 15:28:47 --> Final output sent to browser
DEBUG - 2016-06-25 15:28:47 --> Total execution time: 0.9407
DEBUG - 2016-06-25 15:28:49 --> Config Class Initialized
DEBUG - 2016-06-25 15:28:49 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:28:49 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:28:49 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:28:49 --> URI Class Initialized
DEBUG - 2016-06-25 15:28:49 --> Router Class Initialized
DEBUG - 2016-06-25 15:28:49 --> Output Class Initialized
DEBUG - 2016-06-25 15:28:49 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:28:49 --> Security Class Initialized
DEBUG - 2016-06-25 15:28:49 --> Input Class Initialized
DEBUG - 2016-06-25 15:28:49 --> XSS Filtering completed
DEBUG - 2016-06-25 15:28:49 --> XSS Filtering completed
DEBUG - 2016-06-25 15:28:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:28:49 --> Language Class Initialized
DEBUG - 2016-06-25 15:28:49 --> Loader Class Initialized
DEBUG - 2016-06-25 15:28:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:28:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:28:49 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:28:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:28:49 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:28:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:28:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:28:50 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:28:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:28:50 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:28:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:28:50 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:28:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:28:50 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:28:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:28:50 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:28:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:28:50 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:28:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:28:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:28:50 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:28:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:28:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:28:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:28:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:28:50 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:28:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:28:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:28:50 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:28:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:28:50 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:28:50 --> Session Class Initialized
DEBUG - 2016-06-25 15:28:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:28:50 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:28:50 --> Session routines successfully run
DEBUG - 2016-06-25 15:28:50 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:28:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:28:50 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:28:50 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:28:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:28:50 --> Controller Class Initialized
DEBUG - 2016-06-25 15:28:50 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:28:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:28:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:28:50 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:28:50 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:28:50 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:28:50 --> Model Class Initialized
DEBUG - 2016-06-25 15:28:50 --> Model Class Initialized
DEBUG - 2016-06-25 15:28:50 --> Model Class Initialized
DEBUG - 2016-06-25 15:28:50 --> Model Class Initialized
DEBUG - 2016-06-25 15:28:50 --> Model Class Initialized
ERROR - 2016-06-25 15:28:50 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 15:28:50 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 15:28:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:28:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:28:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:28:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:28:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:28:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:28:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:28:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:28:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:28:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:28:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:28:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:28:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:28:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:28:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:28:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:28:50 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 15:28:50 --> Final output sent to browser
DEBUG - 2016-06-25 15:28:50 --> Total execution time: 0.9419
DEBUG - 2016-06-25 15:30:16 --> Config Class Initialized
DEBUG - 2016-06-25 15:30:16 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:30:16 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:30:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:30:16 --> URI Class Initialized
DEBUG - 2016-06-25 15:30:16 --> Router Class Initialized
DEBUG - 2016-06-25 15:30:16 --> Output Class Initialized
DEBUG - 2016-06-25 15:30:16 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:30:16 --> Security Class Initialized
DEBUG - 2016-06-25 15:30:16 --> Input Class Initialized
DEBUG - 2016-06-25 15:30:16 --> XSS Filtering completed
DEBUG - 2016-06-25 15:30:16 --> XSS Filtering completed
DEBUG - 2016-06-25 15:30:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:30:16 --> Language Class Initialized
DEBUG - 2016-06-25 15:30:16 --> Loader Class Initialized
DEBUG - 2016-06-25 15:30:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:30:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:30:16 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:30:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:30:16 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:30:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:30:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:30:16 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:30:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:30:16 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:30:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:30:16 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:30:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:30:16 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:30:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:30:16 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:30:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:30:16 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:30:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:30:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:30:16 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:30:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:30:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:30:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:30:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:30:16 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:30:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:30:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:30:16 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:30:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:30:16 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:30:16 --> Session Class Initialized
DEBUG - 2016-06-25 15:30:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:30:16 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:30:16 --> Session routines successfully run
DEBUG - 2016-06-25 15:30:16 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:30:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:30:16 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:30:16 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:30:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:30:17 --> Controller Class Initialized
DEBUG - 2016-06-25 15:30:17 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:30:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:30:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:30:17 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:30:17 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:30:17 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:30:17 --> Model Class Initialized
DEBUG - 2016-06-25 15:30:17 --> Model Class Initialized
DEBUG - 2016-06-25 15:30:17 --> Model Class Initialized
DEBUG - 2016-06-25 15:30:17 --> Model Class Initialized
DEBUG - 2016-06-25 15:30:17 --> Model Class Initialized
DEBUG - 2016-06-25 15:30:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:30:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:30:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:30:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:30:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:30:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:30:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:30:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:30:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:30:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:30:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:30:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:30:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:30:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:30:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:30:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:30:17 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 15:30:17 --> Final output sent to browser
DEBUG - 2016-06-25 15:30:17 --> Total execution time: 1.0218
DEBUG - 2016-06-25 15:30:18 --> Config Class Initialized
DEBUG - 2016-06-25 15:30:18 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:30:18 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:30:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:30:18 --> URI Class Initialized
DEBUG - 2016-06-25 15:30:18 --> Router Class Initialized
DEBUG - 2016-06-25 15:30:18 --> Output Class Initialized
DEBUG - 2016-06-25 15:30:18 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:30:18 --> Security Class Initialized
DEBUG - 2016-06-25 15:30:18 --> Input Class Initialized
DEBUG - 2016-06-25 15:30:18 --> XSS Filtering completed
DEBUG - 2016-06-25 15:30:18 --> XSS Filtering completed
DEBUG - 2016-06-25 15:30:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:30:18 --> Language Class Initialized
DEBUG - 2016-06-25 15:30:18 --> Loader Class Initialized
DEBUG - 2016-06-25 15:30:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:30:18 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:30:18 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:30:18 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:30:18 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:30:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:30:18 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:30:18 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:30:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:30:18 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:30:18 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:30:18 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:30:18 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:30:18 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:30:18 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:30:18 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:30:18 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:30:18 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:30:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:30:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:30:18 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:30:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:30:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:30:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:30:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:30:18 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:30:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:30:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:30:18 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:30:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:30:18 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:30:18 --> Session Class Initialized
DEBUG - 2016-06-25 15:30:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:30:19 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:30:19 --> Session routines successfully run
DEBUG - 2016-06-25 15:30:19 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:30:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:30:19 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:30:19 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:30:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:30:19 --> Controller Class Initialized
DEBUG - 2016-06-25 15:30:19 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:30:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:30:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:30:19 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:30:19 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:30:19 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:30:19 --> Model Class Initialized
DEBUG - 2016-06-25 15:30:19 --> Model Class Initialized
DEBUG - 2016-06-25 15:30:19 --> Model Class Initialized
DEBUG - 2016-06-25 15:30:19 --> Model Class Initialized
DEBUG - 2016-06-25 15:30:19 --> Model Class Initialized
ERROR - 2016-06-25 15:30:19 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 15:30:19 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 15:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:30:19 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 15:30:19 --> Final output sent to browser
DEBUG - 2016-06-25 15:30:19 --> Total execution time: 1.0144
DEBUG - 2016-06-25 15:31:11 --> Config Class Initialized
DEBUG - 2016-06-25 15:31:11 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:31:11 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:31:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:31:11 --> URI Class Initialized
DEBUG - 2016-06-25 15:31:11 --> Router Class Initialized
DEBUG - 2016-06-25 15:31:11 --> Output Class Initialized
DEBUG - 2016-06-25 15:31:11 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:31:11 --> Security Class Initialized
DEBUG - 2016-06-25 15:31:11 --> Input Class Initialized
DEBUG - 2016-06-25 15:31:11 --> XSS Filtering completed
DEBUG - 2016-06-25 15:31:11 --> XSS Filtering completed
DEBUG - 2016-06-25 15:31:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:31:12 --> Language Class Initialized
DEBUG - 2016-06-25 15:31:12 --> Loader Class Initialized
DEBUG - 2016-06-25 15:31:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:31:12 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:31:12 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:31:12 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:31:12 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:31:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:31:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:31:12 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:31:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:31:12 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:31:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:31:12 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:31:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:31:12 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:31:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:31:12 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:31:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:31:12 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:31:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:31:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:31:12 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:31:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:31:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:31:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:31:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:31:12 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:31:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:31:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:31:12 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:31:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:31:12 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:31:12 --> Session Class Initialized
DEBUG - 2016-06-25 15:31:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:31:12 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:31:12 --> Session routines successfully run
DEBUG - 2016-06-25 15:31:12 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:31:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:31:12 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:31:12 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:31:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:31:12 --> Controller Class Initialized
DEBUG - 2016-06-25 15:31:12 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:31:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:31:12 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:31:12 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:31:12 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:31:12 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:31:12 --> Model Class Initialized
DEBUG - 2016-06-25 15:31:12 --> Model Class Initialized
DEBUG - 2016-06-25 15:31:12 --> Model Class Initialized
DEBUG - 2016-06-25 15:31:12 --> Model Class Initialized
DEBUG - 2016-06-25 15:31:12 --> Model Class Initialized
DEBUG - 2016-06-25 15:31:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:31:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:31:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:31:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:31:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:31:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:31:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:31:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:31:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:31:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:31:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:31:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:31:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:31:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:31:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:31:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:31:13 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 15:31:13 --> Final output sent to browser
DEBUG - 2016-06-25 15:31:13 --> Total execution time: 1.0147
DEBUG - 2016-06-25 15:31:13 --> Config Class Initialized
DEBUG - 2016-06-25 15:31:13 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:31:13 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:31:13 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:31:14 --> URI Class Initialized
DEBUG - 2016-06-25 15:31:14 --> Router Class Initialized
DEBUG - 2016-06-25 15:31:14 --> Output Class Initialized
DEBUG - 2016-06-25 15:31:14 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:31:14 --> Security Class Initialized
DEBUG - 2016-06-25 15:31:14 --> Input Class Initialized
DEBUG - 2016-06-25 15:31:14 --> XSS Filtering completed
DEBUG - 2016-06-25 15:31:14 --> XSS Filtering completed
DEBUG - 2016-06-25 15:31:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:31:14 --> Language Class Initialized
DEBUG - 2016-06-25 15:31:14 --> Loader Class Initialized
DEBUG - 2016-06-25 15:31:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:31:14 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:31:14 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:31:14 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:31:14 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:31:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:31:14 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:31:14 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:31:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:31:14 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:31:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:31:14 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:31:14 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:31:14 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:31:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:31:14 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:31:14 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:31:14 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:31:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:31:14 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:31:14 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:31:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:31:14 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:31:14 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:31:14 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:31:14 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:31:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:31:14 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:31:14 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:31:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:31:14 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:31:14 --> Session Class Initialized
DEBUG - 2016-06-25 15:31:14 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:31:14 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:31:14 --> Session routines successfully run
DEBUG - 2016-06-25 15:31:14 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:31:14 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:31:14 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:31:14 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:31:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:31:14 --> Controller Class Initialized
DEBUG - 2016-06-25 15:31:14 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:31:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:31:14 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:31:14 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:31:14 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:31:14 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:31:14 --> Model Class Initialized
DEBUG - 2016-06-25 15:31:14 --> Model Class Initialized
DEBUG - 2016-06-25 15:31:14 --> Model Class Initialized
DEBUG - 2016-06-25 15:31:14 --> Model Class Initialized
DEBUG - 2016-06-25 15:31:14 --> Model Class Initialized
ERROR - 2016-06-25 15:31:15 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 15:31:15 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 15:31:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:31:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:31:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:31:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:31:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:31:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:31:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:31:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:31:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:31:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:31:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:31:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:31:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:31:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:31:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:31:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:31:15 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 15:31:15 --> Final output sent to browser
DEBUG - 2016-06-25 15:31:15 --> Total execution time: 1.0508
DEBUG - 2016-06-25 15:36:44 --> Config Class Initialized
DEBUG - 2016-06-25 15:36:44 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:36:44 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:36:44 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:36:44 --> URI Class Initialized
DEBUG - 2016-06-25 15:36:44 --> Router Class Initialized
DEBUG - 2016-06-25 15:36:44 --> Output Class Initialized
DEBUG - 2016-06-25 15:36:44 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:36:44 --> Security Class Initialized
DEBUG - 2016-06-25 15:36:44 --> Input Class Initialized
DEBUG - 2016-06-25 15:36:44 --> XSS Filtering completed
DEBUG - 2016-06-25 15:36:44 --> XSS Filtering completed
DEBUG - 2016-06-25 15:36:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:36:44 --> Language Class Initialized
DEBUG - 2016-06-25 15:36:44 --> Loader Class Initialized
DEBUG - 2016-06-25 15:36:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:36:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:36:44 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:36:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:36:44 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:36:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:36:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:36:45 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:36:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:36:45 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:36:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:36:45 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:36:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:36:45 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:36:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:36:45 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:36:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:36:45 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:36:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:36:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:36:45 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:36:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:36:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:36:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:36:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:36:45 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:36:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:36:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:36:45 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:36:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:36:45 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:36:45 --> Session Class Initialized
DEBUG - 2016-06-25 15:36:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:36:45 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:36:45 --> Session routines successfully run
DEBUG - 2016-06-25 15:36:45 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:36:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:36:45 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:36:45 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:36:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:36:45 --> Controller Class Initialized
DEBUG - 2016-06-25 15:36:45 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:36:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:36:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:36:45 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:36:45 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:36:45 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:36:45 --> Model Class Initialized
DEBUG - 2016-06-25 15:36:45 --> Model Class Initialized
DEBUG - 2016-06-25 15:36:45 --> Model Class Initialized
DEBUG - 2016-06-25 15:36:45 --> Model Class Initialized
DEBUG - 2016-06-25 15:36:45 --> Model Class Initialized
DEBUG - 2016-06-25 15:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:36:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 15:36:45 --> Final output sent to browser
DEBUG - 2016-06-25 15:36:45 --> Total execution time: 1.0306
DEBUG - 2016-06-25 15:36:47 --> Config Class Initialized
DEBUG - 2016-06-25 15:36:47 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:36:47 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:36:48 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:36:48 --> URI Class Initialized
DEBUG - 2016-06-25 15:36:48 --> Router Class Initialized
DEBUG - 2016-06-25 15:36:48 --> Output Class Initialized
DEBUG - 2016-06-25 15:36:48 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:36:48 --> Security Class Initialized
DEBUG - 2016-06-25 15:36:48 --> Input Class Initialized
DEBUG - 2016-06-25 15:36:48 --> XSS Filtering completed
DEBUG - 2016-06-25 15:36:48 --> XSS Filtering completed
DEBUG - 2016-06-25 15:36:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:36:48 --> Language Class Initialized
DEBUG - 2016-06-25 15:36:48 --> Loader Class Initialized
DEBUG - 2016-06-25 15:36:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:36:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:36:48 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:36:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:36:48 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:36:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:36:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:36:48 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:36:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:36:48 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:36:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:36:48 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:36:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:36:48 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:36:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:36:48 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:36:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:36:48 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:36:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:36:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:36:48 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:36:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:36:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:36:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:36:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:36:48 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:36:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:36:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:36:48 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:36:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:36:48 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:36:48 --> Session Class Initialized
DEBUG - 2016-06-25 15:36:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:36:48 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:36:48 --> Session routines successfully run
DEBUG - 2016-06-25 15:36:48 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:36:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:36:48 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:36:48 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:36:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:36:48 --> Controller Class Initialized
DEBUG - 2016-06-25 15:36:48 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:36:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:36:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:36:48 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:36:48 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:36:48 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:36:48 --> Model Class Initialized
DEBUG - 2016-06-25 15:36:48 --> Model Class Initialized
DEBUG - 2016-06-25 15:36:48 --> Model Class Initialized
DEBUG - 2016-06-25 15:36:49 --> Model Class Initialized
DEBUG - 2016-06-25 15:36:49 --> Model Class Initialized
ERROR - 2016-06-25 15:36:49 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 15:36:49 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 15:36:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:36:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:36:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:36:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:36:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:36:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:36:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:36:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:36:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:36:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:36:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:36:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:36:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:36:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:36:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:36:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:36:49 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 15:36:49 --> Final output sent to browser
DEBUG - 2016-06-25 15:36:49 --> Total execution time: 1.0754
DEBUG - 2016-06-25 15:37:35 --> Config Class Initialized
DEBUG - 2016-06-25 15:37:35 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:37:35 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:37:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:37:35 --> URI Class Initialized
DEBUG - 2016-06-25 15:37:35 --> Router Class Initialized
DEBUG - 2016-06-25 15:37:35 --> Output Class Initialized
DEBUG - 2016-06-25 15:37:35 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:37:35 --> Security Class Initialized
DEBUG - 2016-06-25 15:37:35 --> Input Class Initialized
DEBUG - 2016-06-25 15:37:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:37:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:37:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:37:35 --> Language Class Initialized
DEBUG - 2016-06-25 15:37:35 --> Loader Class Initialized
DEBUG - 2016-06-25 15:37:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:37:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:37:35 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:37:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:37:35 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:37:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:37:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:37:35 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:37:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:37:35 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:37:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:37:35 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:37:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:37:35 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:37:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:37:35 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:37:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:37:35 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:37:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:37:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:37:35 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:37:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:37:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:37:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:37:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:37:35 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:37:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:37:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:37:35 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:37:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:37:35 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:37:35 --> Session Class Initialized
DEBUG - 2016-06-25 15:37:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:37:35 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:37:35 --> Session routines successfully run
DEBUG - 2016-06-25 15:37:35 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:37:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:37:35 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:37:35 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:37:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:37:35 --> Controller Class Initialized
DEBUG - 2016-06-25 15:37:35 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:37:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:37:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:37:36 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:37:36 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:37:36 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:37:36 --> Model Class Initialized
DEBUG - 2016-06-25 15:37:36 --> Model Class Initialized
DEBUG - 2016-06-25 15:37:36 --> Model Class Initialized
DEBUG - 2016-06-25 15:37:36 --> Model Class Initialized
DEBUG - 2016-06-25 15:37:36 --> Model Class Initialized
DEBUG - 2016-06-25 15:37:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:37:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:37:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:37:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:37:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:37:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:37:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:37:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:37:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:37:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:37:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:37:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:37:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:37:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:37:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:37:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:37:36 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 15:37:36 --> Final output sent to browser
DEBUG - 2016-06-25 15:37:36 --> Total execution time: 1.0850
DEBUG - 2016-06-25 15:37:37 --> Config Class Initialized
DEBUG - 2016-06-25 15:37:37 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:37:37 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:37:37 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:37:37 --> URI Class Initialized
DEBUG - 2016-06-25 15:37:37 --> Router Class Initialized
DEBUG - 2016-06-25 15:37:37 --> Output Class Initialized
DEBUG - 2016-06-25 15:37:37 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:37:37 --> Security Class Initialized
DEBUG - 2016-06-25 15:37:37 --> Input Class Initialized
DEBUG - 2016-06-25 15:37:37 --> XSS Filtering completed
DEBUG - 2016-06-25 15:37:37 --> XSS Filtering completed
DEBUG - 2016-06-25 15:37:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:37:37 --> Language Class Initialized
DEBUG - 2016-06-25 15:37:37 --> Loader Class Initialized
DEBUG - 2016-06-25 15:37:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:37:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:37:37 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:37:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:37:37 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:37:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:37:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:37:37 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:37:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:37:37 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:37:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:37:37 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:37:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:37:37 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:37:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:37:37 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:37:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:37:37 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:37:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:37:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:37:37 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:37:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:37:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:37:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:37:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:37:38 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:37:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:37:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:37:38 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:37:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:37:38 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:37:38 --> Session Class Initialized
DEBUG - 2016-06-25 15:37:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:37:38 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:37:38 --> Session routines successfully run
DEBUG - 2016-06-25 15:37:38 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:37:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:37:38 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:37:38 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:37:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:37:38 --> Controller Class Initialized
DEBUG - 2016-06-25 15:37:38 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:37:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:37:38 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:37:38 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:37:38 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:37:38 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:37:38 --> Model Class Initialized
DEBUG - 2016-06-25 15:37:38 --> Model Class Initialized
DEBUG - 2016-06-25 15:37:38 --> Model Class Initialized
DEBUG - 2016-06-25 15:37:38 --> Model Class Initialized
DEBUG - 2016-06-25 15:37:38 --> Model Class Initialized
ERROR - 2016-06-25 15:37:38 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 15:37:38 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:37:38 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 15:37:38 --> Final output sent to browser
DEBUG - 2016-06-25 15:37:38 --> Total execution time: 1.2025
DEBUG - 2016-06-25 15:38:00 --> Config Class Initialized
DEBUG - 2016-06-25 15:38:00 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:38:00 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:38:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:38:00 --> URI Class Initialized
DEBUG - 2016-06-25 15:38:00 --> Router Class Initialized
DEBUG - 2016-06-25 15:38:00 --> Output Class Initialized
DEBUG - 2016-06-25 15:38:00 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:38:00 --> Security Class Initialized
DEBUG - 2016-06-25 15:38:00 --> Input Class Initialized
DEBUG - 2016-06-25 15:38:00 --> XSS Filtering completed
DEBUG - 2016-06-25 15:38:00 --> XSS Filtering completed
DEBUG - 2016-06-25 15:38:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:38:00 --> Language Class Initialized
DEBUG - 2016-06-25 15:38:00 --> Loader Class Initialized
DEBUG - 2016-06-25 15:38:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:38:00 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:38:00 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:38:00 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:38:00 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:38:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:38:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:38:00 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:38:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:38:00 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:38:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:38:00 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:38:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:38:00 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:38:00 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:38:01 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:38:01 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:38:01 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:38:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:38:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:38:01 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:38:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:38:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:38:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:38:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:38:01 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:38:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:38:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:38:01 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:38:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:38:01 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:38:01 --> Session Class Initialized
DEBUG - 2016-06-25 15:38:01 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:38:01 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:38:01 --> Session routines successfully run
DEBUG - 2016-06-25 15:38:01 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:38:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:38:01 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:38:01 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:38:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:38:01 --> Controller Class Initialized
DEBUG - 2016-06-25 15:38:01 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:38:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:38:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:38:01 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:38:01 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:38:01 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:38:01 --> Model Class Initialized
DEBUG - 2016-06-25 15:38:01 --> Model Class Initialized
DEBUG - 2016-06-25 15:38:01 --> Model Class Initialized
DEBUG - 2016-06-25 15:38:01 --> Model Class Initialized
DEBUG - 2016-06-25 15:38:01 --> Model Class Initialized
DEBUG - 2016-06-25 15:38:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:38:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:38:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:38:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:38:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:38:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:38:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:38:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:38:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:38:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:38:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:38:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:38:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:38:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:38:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:38:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:38:01 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 15:38:01 --> Final output sent to browser
DEBUG - 2016-06-25 15:38:01 --> Total execution time: 1.1066
DEBUG - 2016-06-25 15:38:02 --> Config Class Initialized
DEBUG - 2016-06-25 15:38:02 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:38:02 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:38:02 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:38:02 --> URI Class Initialized
DEBUG - 2016-06-25 15:38:02 --> Router Class Initialized
DEBUG - 2016-06-25 15:38:02 --> Output Class Initialized
DEBUG - 2016-06-25 15:38:02 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:38:02 --> Security Class Initialized
DEBUG - 2016-06-25 15:38:02 --> Input Class Initialized
DEBUG - 2016-06-25 15:38:02 --> XSS Filtering completed
DEBUG - 2016-06-25 15:38:02 --> XSS Filtering completed
DEBUG - 2016-06-25 15:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:38:02 --> Language Class Initialized
DEBUG - 2016-06-25 15:38:03 --> Loader Class Initialized
DEBUG - 2016-06-25 15:38:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:38:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:38:03 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:38:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:38:03 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:38:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:38:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:38:03 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:38:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:38:03 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:38:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:38:03 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:38:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:38:03 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:38:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:38:03 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:38:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:38:03 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:38:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:38:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:38:03 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:38:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:38:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:38:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:38:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:38:03 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:38:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:38:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:38:03 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:38:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:38:03 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:38:03 --> Session Class Initialized
DEBUG - 2016-06-25 15:38:03 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:38:03 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:38:03 --> Session routines successfully run
DEBUG - 2016-06-25 15:38:03 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:38:03 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:38:03 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:38:03 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:38:03 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:38:03 --> Controller Class Initialized
DEBUG - 2016-06-25 15:38:03 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:38:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:38:03 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:38:03 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:38:03 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:38:03 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:38:03 --> Model Class Initialized
DEBUG - 2016-06-25 15:38:03 --> Model Class Initialized
DEBUG - 2016-06-25 15:38:03 --> Model Class Initialized
DEBUG - 2016-06-25 15:38:03 --> Model Class Initialized
DEBUG - 2016-06-25 15:38:03 --> Model Class Initialized
ERROR - 2016-06-25 15:38:03 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 15:38:03 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 15:38:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:38:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:38:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:38:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:38:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:38:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:38:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:38:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:38:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:38:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:38:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:38:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:38:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:38:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:38:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:38:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:38:04 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 15:38:04 --> Final output sent to browser
DEBUG - 2016-06-25 15:38:04 --> Total execution time: 1.1739
DEBUG - 2016-06-25 15:40:50 --> Config Class Initialized
DEBUG - 2016-06-25 15:40:50 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:40:50 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:40:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:40:50 --> URI Class Initialized
DEBUG - 2016-06-25 15:40:50 --> Router Class Initialized
DEBUG - 2016-06-25 15:40:50 --> Output Class Initialized
DEBUG - 2016-06-25 15:40:50 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:40:50 --> Security Class Initialized
DEBUG - 2016-06-25 15:40:50 --> Input Class Initialized
DEBUG - 2016-06-25 15:40:50 --> XSS Filtering completed
DEBUG - 2016-06-25 15:40:50 --> XSS Filtering completed
DEBUG - 2016-06-25 15:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:40:50 --> Language Class Initialized
DEBUG - 2016-06-25 15:40:50 --> Loader Class Initialized
DEBUG - 2016-06-25 15:40:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:40:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:40:50 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:40:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:40:50 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:40:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:40:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:40:50 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:40:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:40:50 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:40:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:40:51 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:40:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:40:51 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:40:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:40:51 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:40:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:40:51 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:40:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:40:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:40:51 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:40:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:40:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:40:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:40:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:40:51 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:40:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:40:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:40:51 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:40:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:40:51 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:40:51 --> Session Class Initialized
DEBUG - 2016-06-25 15:40:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:40:51 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:40:51 --> Session routines successfully run
DEBUG - 2016-06-25 15:40:51 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:40:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:40:51 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:40:51 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:40:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:40:51 --> Controller Class Initialized
DEBUG - 2016-06-25 15:40:51 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:40:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:40:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:40:51 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:40:51 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:40:51 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:40:51 --> Model Class Initialized
DEBUG - 2016-06-25 15:40:51 --> Model Class Initialized
DEBUG - 2016-06-25 15:40:51 --> Model Class Initialized
DEBUG - 2016-06-25 15:40:51 --> Model Class Initialized
DEBUG - 2016-06-25 15:40:51 --> Model Class Initialized
DEBUG - 2016-06-25 15:40:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:40:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:40:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:40:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:40:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:40:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:40:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:40:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:40:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:40:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:40:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:40:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:40:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:40:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:40:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:40:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:40:51 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 15:40:51 --> Final output sent to browser
DEBUG - 2016-06-25 15:40:52 --> Total execution time: 1.1398
DEBUG - 2016-06-25 15:40:53 --> Config Class Initialized
DEBUG - 2016-06-25 15:40:53 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:40:53 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:40:53 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:40:53 --> URI Class Initialized
DEBUG - 2016-06-25 15:40:53 --> Router Class Initialized
DEBUG - 2016-06-25 15:40:53 --> Output Class Initialized
DEBUG - 2016-06-25 15:40:53 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:40:53 --> Security Class Initialized
DEBUG - 2016-06-25 15:40:53 --> Input Class Initialized
DEBUG - 2016-06-25 15:40:53 --> XSS Filtering completed
DEBUG - 2016-06-25 15:40:53 --> XSS Filtering completed
DEBUG - 2016-06-25 15:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:40:53 --> Language Class Initialized
DEBUG - 2016-06-25 15:40:53 --> Loader Class Initialized
DEBUG - 2016-06-25 15:40:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:40:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:40:53 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:40:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:40:53 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:40:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:40:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:40:53 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:40:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:40:53 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:40:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:40:53 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:40:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:40:53 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:40:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:40:53 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:40:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:40:53 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:40:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:40:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:40:53 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:40:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:40:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:40:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:40:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:40:53 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:40:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:40:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:40:53 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:40:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:40:53 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:40:54 --> Session Class Initialized
DEBUG - 2016-06-25 15:40:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:40:54 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:40:54 --> Session routines successfully run
DEBUG - 2016-06-25 15:40:54 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:40:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:40:54 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:40:54 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:40:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:40:54 --> Controller Class Initialized
DEBUG - 2016-06-25 15:40:54 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:40:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:40:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:40:54 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:40:54 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:40:54 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:40:54 --> Model Class Initialized
DEBUG - 2016-06-25 15:40:54 --> Model Class Initialized
DEBUG - 2016-06-25 15:40:54 --> Model Class Initialized
DEBUG - 2016-06-25 15:40:54 --> Model Class Initialized
DEBUG - 2016-06-25 15:40:54 --> Model Class Initialized
ERROR - 2016-06-25 15:40:54 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 15:40:54 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 15:40:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:40:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:40:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:40:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:40:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:40:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:40:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:40:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:40:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:40:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:40:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:40:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:40:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:40:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:40:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:40:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:40:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 15:40:54 --> Final output sent to browser
DEBUG - 2016-06-25 15:40:54 --> Total execution time: 1.1988
DEBUG - 2016-06-25 15:41:27 --> Config Class Initialized
DEBUG - 2016-06-25 15:41:27 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:41:27 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:41:27 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:41:27 --> URI Class Initialized
DEBUG - 2016-06-25 15:41:27 --> Router Class Initialized
DEBUG - 2016-06-25 15:41:27 --> Output Class Initialized
DEBUG - 2016-06-25 15:41:27 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:41:27 --> Security Class Initialized
DEBUG - 2016-06-25 15:41:27 --> Input Class Initialized
DEBUG - 2016-06-25 15:41:27 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:27 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:41:27 --> Language Class Initialized
DEBUG - 2016-06-25 15:41:27 --> Loader Class Initialized
DEBUG - 2016-06-25 15:41:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:41:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:41:27 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:41:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:41:27 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:41:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:41:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:41:27 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:41:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:41:27 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:41:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:41:27 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:41:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:41:27 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:41:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:41:27 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:41:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:41:27 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:41:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:41:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:41:28 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:41:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:41:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:41:28 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:41:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:41:28 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:41:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:41:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:41:28 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:41:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:41:28 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:41:28 --> Session Class Initialized
DEBUG - 2016-06-25 15:41:28 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:41:28 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:41:28 --> Session routines successfully run
DEBUG - 2016-06-25 15:41:28 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:41:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:41:28 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:41:28 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:41:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:41:28 --> Controller Class Initialized
DEBUG - 2016-06-25 15:41:28 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:41:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:41:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:41:28 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:41:28 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:41:28 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:41:28 --> Model Class Initialized
DEBUG - 2016-06-25 15:41:28 --> Model Class Initialized
DEBUG - 2016-06-25 15:41:28 --> Model Class Initialized
DEBUG - 2016-06-25 15:41:28 --> Model Class Initialized
DEBUG - 2016-06-25 15:41:28 --> Model Class Initialized
DEBUG - 2016-06-25 15:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:41:28 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 15:41:28 --> Final output sent to browser
DEBUG - 2016-06-25 15:41:28 --> Total execution time: 1.1776
DEBUG - 2016-06-25 15:41:29 --> Config Class Initialized
DEBUG - 2016-06-25 15:41:29 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:41:29 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:41:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:41:29 --> URI Class Initialized
DEBUG - 2016-06-25 15:41:29 --> Router Class Initialized
DEBUG - 2016-06-25 15:41:30 --> Output Class Initialized
DEBUG - 2016-06-25 15:41:30 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:41:30 --> Security Class Initialized
DEBUG - 2016-06-25 15:41:30 --> Input Class Initialized
DEBUG - 2016-06-25 15:41:30 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:30 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:41:30 --> Language Class Initialized
DEBUG - 2016-06-25 15:41:30 --> Loader Class Initialized
DEBUG - 2016-06-25 15:41:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:41:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:41:30 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:41:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:41:30 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:41:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:41:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:41:30 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:41:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:41:30 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:41:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:41:30 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:41:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:41:30 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:41:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:41:30 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:41:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:41:30 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:41:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:41:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:41:30 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:41:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:41:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:41:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:41:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:41:30 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:41:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:41:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:41:30 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:41:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:41:30 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:41:30 --> Session Class Initialized
DEBUG - 2016-06-25 15:41:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:41:30 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:41:30 --> Session routines successfully run
DEBUG - 2016-06-25 15:41:30 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:41:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:41:30 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:41:30 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:41:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:41:30 --> Controller Class Initialized
DEBUG - 2016-06-25 15:41:30 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:41:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:41:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:41:31 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:41:31 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:41:31 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:41:31 --> Model Class Initialized
DEBUG - 2016-06-25 15:41:31 --> Model Class Initialized
DEBUG - 2016-06-25 15:41:31 --> Model Class Initialized
DEBUG - 2016-06-25 15:41:31 --> Model Class Initialized
DEBUG - 2016-06-25 15:41:31 --> Model Class Initialized
ERROR - 2016-06-25 15:41:31 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 15:41:31 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 15:41:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:41:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:41:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:41:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:41:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:41:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:41:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:41:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:41:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:41:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:41:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:41:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:41:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:41:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:41:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:41:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:41:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 15:41:31 --> Final output sent to browser
DEBUG - 2016-06-25 15:41:31 --> Total execution time: 1.2704
DEBUG - 2016-06-25 15:41:35 --> Config Class Initialized
DEBUG - 2016-06-25 15:41:35 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:41:35 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:41:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:41:35 --> URI Class Initialized
DEBUG - 2016-06-25 15:41:35 --> Router Class Initialized
DEBUG - 2016-06-25 15:41:35 --> Output Class Initialized
DEBUG - 2016-06-25 15:41:35 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:41:35 --> Security Class Initialized
DEBUG - 2016-06-25 15:41:35 --> Input Class Initialized
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:36 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:37 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:37 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:37 --> XSS Filtering completed
DEBUG - 2016-06-25 15:41:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:41:37 --> Language Class Initialized
DEBUG - 2016-06-25 15:41:37 --> Loader Class Initialized
DEBUG - 2016-06-25 15:41:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:41:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:41:37 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:41:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:41:37 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:41:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:41:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:41:37 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:41:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:41:37 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:41:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:41:37 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:41:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:41:37 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:41:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:41:37 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:41:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:41:37 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:41:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:41:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:41:37 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:41:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:41:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:41:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:41:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:41:37 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:41:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:41:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:41:37 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:41:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:41:37 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:41:37 --> Session Class Initialized
DEBUG - 2016-06-25 15:41:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:41:37 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:41:37 --> Session routines successfully run
DEBUG - 2016-06-25 15:41:37 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:41:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:41:37 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:41:37 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:41:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:41:37 --> Controller Class Initialized
DEBUG - 2016-06-25 15:41:37 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:41:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:41:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:41:37 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:41:37 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:41:37 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:41:37 --> Model Class Initialized
DEBUG - 2016-06-25 15:41:37 --> Model Class Initialized
DEBUG - 2016-06-25 15:41:38 --> Model Class Initialized
DEBUG - 2016-06-25 15:41:38 --> Model Class Initialized
DEBUG - 2016-06-25 15:41:38 --> Model Class Initialized
DEBUG - 2016-06-25 15:42:32 --> Config Class Initialized
DEBUG - 2016-06-25 15:42:32 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:42:32 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:42:32 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:42:32 --> URI Class Initialized
DEBUG - 2016-06-25 15:42:32 --> Router Class Initialized
DEBUG - 2016-06-25 15:42:32 --> Output Class Initialized
DEBUG - 2016-06-25 15:42:32 --> Security Class Initialized
DEBUG - 2016-06-25 15:42:32 --> Input Class Initialized
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:32 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:42:33 --> Language Class Initialized
DEBUG - 2016-06-25 15:42:33 --> Loader Class Initialized
DEBUG - 2016-06-25 15:42:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:42:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:42:33 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:42:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:42:33 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:42:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:42:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:42:33 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:42:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:42:33 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:42:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:42:34 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:42:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:42:34 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:42:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:42:34 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:42:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:42:34 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:42:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:42:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:42:34 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:42:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:42:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:42:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:42:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:42:34 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:42:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:42:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:42:34 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:42:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:42:34 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:42:34 --> Session Class Initialized
DEBUG - 2016-06-25 15:42:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:42:34 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:42:34 --> Session routines successfully run
DEBUG - 2016-06-25 15:42:34 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:42:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:42:34 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:42:34 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:42:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:42:34 --> Controller Class Initialized
DEBUG - 2016-06-25 15:42:34 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:42:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:42:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:42:34 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:42:34 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:42:34 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:42:34 --> Model Class Initialized
DEBUG - 2016-06-25 15:42:34 --> Model Class Initialized
DEBUG - 2016-06-25 15:42:34 --> Model Class Initialized
DEBUG - 2016-06-25 15:42:34 --> Model Class Initialized
DEBUG - 2016-06-25 15:42:34 --> Model Class Initialized
DEBUG - 2016-06-25 15:56:32 --> Config Class Initialized
DEBUG - 2016-06-25 15:56:32 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:56:32 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:56:32 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:56:32 --> URI Class Initialized
DEBUG - 2016-06-25 15:56:32 --> Router Class Initialized
DEBUG - 2016-06-25 15:56:32 --> Output Class Initialized
DEBUG - 2016-06-25 15:56:32 --> Security Class Initialized
DEBUG - 2016-06-25 15:56:32 --> Input Class Initialized
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:33 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> XSS Filtering completed
DEBUG - 2016-06-25 15:56:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:56:34 --> Language Class Initialized
DEBUG - 2016-06-25 15:56:34 --> Loader Class Initialized
DEBUG - 2016-06-25 15:56:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:56:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:56:35 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:56:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:56:35 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:56:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:56:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:56:35 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:56:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:56:35 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:56:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:56:35 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:56:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:56:35 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:56:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:56:35 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:56:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:56:35 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:56:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:56:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:56:35 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:56:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:56:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:56:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:56:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:56:35 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:56:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:56:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:56:36 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:56:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:56:36 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:56:36 --> Session Class Initialized
DEBUG - 2016-06-25 15:56:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:56:36 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:56:36 --> Session routines successfully run
DEBUG - 2016-06-25 15:56:36 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:56:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:56:37 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:56:37 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:56:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:56:37 --> Controller Class Initialized
DEBUG - 2016-06-25 15:56:37 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:56:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:56:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:56:37 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:56:37 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:56:37 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:56:37 --> Model Class Initialized
DEBUG - 2016-06-25 15:56:37 --> Model Class Initialized
DEBUG - 2016-06-25 15:56:38 --> Model Class Initialized
DEBUG - 2016-06-25 15:56:40 --> Model Class Initialized
DEBUG - 2016-06-25 15:56:40 --> Model Class Initialized
DEBUG - 2016-06-25 15:58:34 --> Config Class Initialized
DEBUG - 2016-06-25 15:58:34 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:58:34 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:58:34 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:58:34 --> URI Class Initialized
DEBUG - 2016-06-25 15:58:34 --> Router Class Initialized
DEBUG - 2016-06-25 15:58:35 --> Output Class Initialized
DEBUG - 2016-06-25 15:58:35 --> Security Class Initialized
DEBUG - 2016-06-25 15:58:35 --> Input Class Initialized
DEBUG - 2016-06-25 15:58:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:58:35 --> XSS Filtering completed
DEBUG - 2016-06-25 15:58:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:58:35 --> Language Class Initialized
DEBUG - 2016-06-25 15:58:35 --> Loader Class Initialized
DEBUG - 2016-06-25 15:58:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:58:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:58:35 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:58:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:58:35 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:58:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:58:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:58:35 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:58:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:58:35 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:58:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:58:35 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:58:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:58:35 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:58:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:58:35 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:58:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:58:35 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:58:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:58:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:58:35 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:58:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:58:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:58:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:58:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:58:35 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:58:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:58:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:58:35 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:58:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:58:35 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:58:35 --> Session Class Initialized
DEBUG - 2016-06-25 15:58:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:58:35 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:58:35 --> Session routines successfully run
DEBUG - 2016-06-25 15:58:35 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:58:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:58:35 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:58:35 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:58:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:58:35 --> Controller Class Initialized
DEBUG - 2016-06-25 15:58:35 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:58:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:58:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:58:35 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:58:35 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:58:36 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:58:36 --> Model Class Initialized
DEBUG - 2016-06-25 15:58:36 --> Model Class Initialized
DEBUG - 2016-06-25 15:58:36 --> Model Class Initialized
DEBUG - 2016-06-25 15:58:36 --> Model Class Initialized
DEBUG - 2016-06-25 15:58:36 --> Model Class Initialized
DEBUG - 2016-06-25 15:58:50 --> Config Class Initialized
DEBUG - 2016-06-25 15:58:50 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:58:50 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:58:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:58:50 --> URI Class Initialized
DEBUG - 2016-06-25 15:58:50 --> Router Class Initialized
DEBUG - 2016-06-25 15:58:50 --> Output Class Initialized
DEBUG - 2016-06-25 15:58:50 --> Security Class Initialized
DEBUG - 2016-06-25 15:58:50 --> Input Class Initialized
DEBUG - 2016-06-25 15:58:50 --> XSS Filtering completed
DEBUG - 2016-06-25 15:58:50 --> XSS Filtering completed
DEBUG - 2016-06-25 15:58:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:58:50 --> Language Class Initialized
DEBUG - 2016-06-25 15:58:50 --> Loader Class Initialized
DEBUG - 2016-06-25 15:58:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:58:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:58:50 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:58:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:58:50 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:58:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:58:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:58:51 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:58:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:58:51 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:58:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:58:51 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:58:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:58:51 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:58:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:58:51 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:58:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:58:51 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:58:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:58:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:58:51 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:58:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:58:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:58:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:58:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:58:51 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:58:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:58:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:58:51 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:58:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:58:51 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:58:51 --> Session Class Initialized
DEBUG - 2016-06-25 15:58:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:58:51 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:58:51 --> Session routines successfully run
DEBUG - 2016-06-25 15:58:51 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:58:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:58:51 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:58:51 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:58:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:58:51 --> Controller Class Initialized
DEBUG - 2016-06-25 15:58:51 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:58:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:58:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:58:51 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:58:51 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:58:51 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:58:51 --> Model Class Initialized
DEBUG - 2016-06-25 15:58:51 --> Model Class Initialized
DEBUG - 2016-06-25 15:58:51 --> Model Class Initialized
DEBUG - 2016-06-25 15:58:51 --> Model Class Initialized
DEBUG - 2016-06-25 15:58:51 --> Model Class Initialized
DEBUG - 2016-06-25 15:58:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:58:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:58:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:58:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:58:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:58:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:58:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:58:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:58:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:58:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:58:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:58:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:58:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:58:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:58:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:58:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:58:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 15:58:52 --> Final output sent to browser
DEBUG - 2016-06-25 15:58:52 --> Total execution time: 1.2240
DEBUG - 2016-06-25 15:58:54 --> Config Class Initialized
DEBUG - 2016-06-25 15:58:54 --> Hooks Class Initialized
DEBUG - 2016-06-25 15:58:54 --> Utf8 Class Initialized
DEBUG - 2016-06-25 15:58:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 15:58:54 --> URI Class Initialized
DEBUG - 2016-06-25 15:58:54 --> Router Class Initialized
DEBUG - 2016-06-25 15:58:54 --> Output Class Initialized
DEBUG - 2016-06-25 15:58:54 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 15:58:54 --> Security Class Initialized
DEBUG - 2016-06-25 15:58:54 --> Input Class Initialized
DEBUG - 2016-06-25 15:58:54 --> XSS Filtering completed
DEBUG - 2016-06-25 15:58:54 --> XSS Filtering completed
DEBUG - 2016-06-25 15:58:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 15:58:54 --> Language Class Initialized
DEBUG - 2016-06-25 15:58:54 --> Loader Class Initialized
DEBUG - 2016-06-25 15:58:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 15:58:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 15:58:54 --> Helper loaded: url_helper
DEBUG - 2016-06-25 15:58:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 15:58:54 --> Helper loaded: file_helper
DEBUG - 2016-06-25 15:58:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:58:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 15:58:54 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 15:58:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 15:58:54 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 15:58:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 15:58:54 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:58:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 15:58:55 --> Helper loaded: common_helper
DEBUG - 2016-06-25 15:58:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 15:58:55 --> Helper loaded: form_helper
DEBUG - 2016-06-25 15:58:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 15:58:55 --> Helper loaded: security_helper
DEBUG - 2016-06-25 15:58:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:58:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 15:58:55 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 15:58:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 15:58:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 15:58:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 15:58:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 15:58:55 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 15:58:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:58:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 15:58:55 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 15:58:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 15:58:55 --> Database Driver Class Initialized
DEBUG - 2016-06-25 15:58:55 --> Session Class Initialized
DEBUG - 2016-06-25 15:58:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 15:58:55 --> Helper loaded: string_helper
DEBUG - 2016-06-25 15:58:55 --> Session routines successfully run
DEBUG - 2016-06-25 15:58:55 --> Native_session Class Initialized
DEBUG - 2016-06-25 15:58:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 15:58:55 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:58:55 --> Form Validation Class Initialized
DEBUG - 2016-06-25 15:58:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 15:58:55 --> Controller Class Initialized
DEBUG - 2016-06-25 15:58:55 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 15:58:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 15:58:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 15:58:55 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:58:55 --> Carabiner: library configured.
DEBUG - 2016-06-25 15:58:55 --> User Agent Class Initialized
DEBUG - 2016-06-25 15:58:55 --> Model Class Initialized
DEBUG - 2016-06-25 15:58:55 --> Model Class Initialized
DEBUG - 2016-06-25 15:58:55 --> Model Class Initialized
DEBUG - 2016-06-25 15:58:55 --> Model Class Initialized
DEBUG - 2016-06-25 15:58:55 --> Model Class Initialized
ERROR - 2016-06-25 15:58:55 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 15:58:55 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 15:58:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 15:58:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 15:58:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:58:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:58:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:58:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:58:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:58:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:58:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:58:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 15:58:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 15:58:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 15:58:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 15:58:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 15:58:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 15:58:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 15:58:56 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 15:58:56 --> Final output sent to browser
DEBUG - 2016-06-25 15:58:56 --> Total execution time: 1.3070
DEBUG - 2016-06-25 16:00:20 --> Config Class Initialized
DEBUG - 2016-06-25 16:00:20 --> Hooks Class Initialized
DEBUG - 2016-06-25 16:00:20 --> Utf8 Class Initialized
DEBUG - 2016-06-25 16:00:20 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 16:00:20 --> URI Class Initialized
DEBUG - 2016-06-25 16:00:20 --> Router Class Initialized
DEBUG - 2016-06-25 16:00:20 --> Output Class Initialized
DEBUG - 2016-06-25 16:00:20 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 16:00:20 --> Security Class Initialized
DEBUG - 2016-06-25 16:00:20 --> Input Class Initialized
DEBUG - 2016-06-25 16:00:20 --> XSS Filtering completed
DEBUG - 2016-06-25 16:00:20 --> XSS Filtering completed
DEBUG - 2016-06-25 16:00:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 16:00:20 --> Language Class Initialized
DEBUG - 2016-06-25 16:00:20 --> Loader Class Initialized
DEBUG - 2016-06-25 16:00:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 16:00:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 16:00:20 --> Helper loaded: url_helper
DEBUG - 2016-06-25 16:00:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 16:00:20 --> Helper loaded: file_helper
DEBUG - 2016-06-25 16:00:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 16:00:21 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 16:00:21 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 16:00:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 16:00:21 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 16:00:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 16:00:21 --> Helper loaded: common_helper
DEBUG - 2016-06-25 16:00:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 16:00:21 --> Helper loaded: common_helper
DEBUG - 2016-06-25 16:00:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 16:00:21 --> Helper loaded: form_helper
DEBUG - 2016-06-25 16:00:21 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 16:00:21 --> Helper loaded: security_helper
DEBUG - 2016-06-25 16:00:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 16:00:21 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 16:00:21 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 16:00:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 16:00:21 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 16:00:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 16:00:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 16:00:21 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 16:00:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 16:00:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 16:00:21 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 16:00:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 16:00:21 --> Database Driver Class Initialized
DEBUG - 2016-06-25 16:00:21 --> Session Class Initialized
DEBUG - 2016-06-25 16:00:21 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 16:00:21 --> Helper loaded: string_helper
DEBUG - 2016-06-25 16:00:21 --> Session routines successfully run
DEBUG - 2016-06-25 16:00:21 --> Native_session Class Initialized
DEBUG - 2016-06-25 16:00:21 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 16:00:21 --> Form Validation Class Initialized
DEBUG - 2016-06-25 16:00:21 --> Form Validation Class Initialized
DEBUG - 2016-06-25 16:00:21 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 16:00:21 --> Controller Class Initialized
DEBUG - 2016-06-25 16:00:21 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 16:00:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 16:00:21 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 16:00:21 --> Carabiner: library configured.
DEBUG - 2016-06-25 16:00:21 --> Carabiner: library configured.
DEBUG - 2016-06-25 16:00:21 --> User Agent Class Initialized
DEBUG - 2016-06-25 16:00:21 --> Model Class Initialized
DEBUG - 2016-06-25 16:00:21 --> Model Class Initialized
DEBUG - 2016-06-25 16:00:21 --> Model Class Initialized
DEBUG - 2016-06-25 16:00:21 --> Model Class Initialized
DEBUG - 2016-06-25 16:00:21 --> Model Class Initialized
DEBUG - 2016-06-25 16:00:25 --> Config Class Initialized
DEBUG - 2016-06-25 16:00:25 --> Hooks Class Initialized
DEBUG - 2016-06-25 16:00:25 --> Utf8 Class Initialized
DEBUG - 2016-06-25 16:00:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 16:00:25 --> URI Class Initialized
DEBUG - 2016-06-25 16:00:25 --> Router Class Initialized
DEBUG - 2016-06-25 16:00:25 --> Output Class Initialized
DEBUG - 2016-06-25 16:00:25 --> Security Class Initialized
DEBUG - 2016-06-25 16:00:25 --> Input Class Initialized
DEBUG - 2016-06-25 16:00:25 --> XSS Filtering completed
DEBUG - 2016-06-25 16:00:25 --> XSS Filtering completed
DEBUG - 2016-06-25 16:00:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 16:00:25 --> Language Class Initialized
DEBUG - 2016-06-25 16:00:25 --> Loader Class Initialized
DEBUG - 2016-06-25 16:00:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 16:00:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 16:00:26 --> Helper loaded: url_helper
DEBUG - 2016-06-25 16:00:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 16:00:26 --> Helper loaded: file_helper
DEBUG - 2016-06-25 16:00:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 16:00:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 16:00:26 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 16:00:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 16:00:26 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 16:00:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 16:00:26 --> Helper loaded: common_helper
DEBUG - 2016-06-25 16:00:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 16:00:26 --> Helper loaded: common_helper
DEBUG - 2016-06-25 16:00:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 16:00:26 --> Helper loaded: form_helper
DEBUG - 2016-06-25 16:00:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 16:00:26 --> Helper loaded: security_helper
DEBUG - 2016-06-25 16:00:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 16:00:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 16:00:26 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 16:00:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 16:00:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 16:00:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 16:00:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 16:00:26 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 16:00:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 16:00:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 16:00:26 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 16:00:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 16:00:26 --> Database Driver Class Initialized
DEBUG - 2016-06-25 16:00:26 --> Session Class Initialized
DEBUG - 2016-06-25 16:00:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 16:00:26 --> Helper loaded: string_helper
DEBUG - 2016-06-25 16:00:26 --> Session routines successfully run
DEBUG - 2016-06-25 16:00:26 --> Native_session Class Initialized
DEBUG - 2016-06-25 16:00:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 16:00:26 --> Form Validation Class Initialized
DEBUG - 2016-06-25 16:00:26 --> Form Validation Class Initialized
DEBUG - 2016-06-25 16:00:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 16:00:26 --> Controller Class Initialized
DEBUG - 2016-06-25 16:00:26 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 16:00:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 16:00:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 16:00:26 --> Carabiner: library configured.
DEBUG - 2016-06-25 16:00:26 --> Carabiner: library configured.
DEBUG - 2016-06-25 16:00:26 --> User Agent Class Initialized
DEBUG - 2016-06-25 16:00:26 --> Model Class Initialized
DEBUG - 2016-06-25 16:00:26 --> Model Class Initialized
DEBUG - 2016-06-25 16:00:26 --> Model Class Initialized
DEBUG - 2016-06-25 16:00:26 --> Model Class Initialized
DEBUG - 2016-06-25 16:00:26 --> Model Class Initialized
DEBUG - 2016-06-25 16:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 16:00:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 16:00:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 16:00:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 16:00:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 16:00:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 16:00:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 16:00:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 16:00:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 16:00:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 16:00:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 16:00:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 16:00:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 16:00:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 16:00:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 16:00:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 16:00:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 16:00:27 --> Final output sent to browser
DEBUG - 2016-06-25 16:00:27 --> Total execution time: 1.2899
DEBUG - 2016-06-25 16:00:31 --> Config Class Initialized
DEBUG - 2016-06-25 16:00:31 --> Hooks Class Initialized
DEBUG - 2016-06-25 16:00:31 --> Utf8 Class Initialized
DEBUG - 2016-06-25 16:00:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 16:00:31 --> URI Class Initialized
DEBUG - 2016-06-25 16:00:31 --> Router Class Initialized
DEBUG - 2016-06-25 16:00:31 --> Output Class Initialized
DEBUG - 2016-06-25 16:00:31 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 16:00:31 --> Security Class Initialized
DEBUG - 2016-06-25 16:00:31 --> Input Class Initialized
DEBUG - 2016-06-25 16:00:31 --> XSS Filtering completed
DEBUG - 2016-06-25 16:00:32 --> XSS Filtering completed
DEBUG - 2016-06-25 16:00:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 16:00:32 --> Language Class Initialized
DEBUG - 2016-06-25 16:00:32 --> Loader Class Initialized
DEBUG - 2016-06-25 16:00:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 16:00:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 16:00:32 --> Helper loaded: url_helper
DEBUG - 2016-06-25 16:00:32 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 16:00:32 --> Helper loaded: file_helper
DEBUG - 2016-06-25 16:00:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 16:00:32 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 16:00:32 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 16:00:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 16:00:32 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 16:00:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 16:00:32 --> Helper loaded: common_helper
DEBUG - 2016-06-25 16:00:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 16:00:32 --> Helper loaded: common_helper
DEBUG - 2016-06-25 16:00:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 16:00:32 --> Helper loaded: form_helper
DEBUG - 2016-06-25 16:00:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 16:00:32 --> Helper loaded: security_helper
DEBUG - 2016-06-25 16:00:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 16:00:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 16:00:32 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 16:00:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 16:00:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 16:00:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 16:00:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 16:00:32 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 16:00:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 16:00:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 16:00:32 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 16:00:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 16:00:32 --> Database Driver Class Initialized
DEBUG - 2016-06-25 16:00:33 --> Session Class Initialized
DEBUG - 2016-06-25 16:00:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 16:00:33 --> Helper loaded: string_helper
DEBUG - 2016-06-25 16:00:33 --> Session routines successfully run
DEBUG - 2016-06-25 16:00:33 --> Native_session Class Initialized
DEBUG - 2016-06-25 16:00:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 16:00:33 --> Form Validation Class Initialized
DEBUG - 2016-06-25 16:00:33 --> Form Validation Class Initialized
DEBUG - 2016-06-25 16:00:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 16:00:33 --> Controller Class Initialized
DEBUG - 2016-06-25 16:00:33 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 16:00:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 16:00:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 16:00:33 --> Carabiner: library configured.
DEBUG - 2016-06-25 16:00:33 --> Carabiner: library configured.
DEBUG - 2016-06-25 16:00:33 --> User Agent Class Initialized
DEBUG - 2016-06-25 16:00:33 --> Model Class Initialized
DEBUG - 2016-06-25 16:00:33 --> Model Class Initialized
DEBUG - 2016-06-25 16:00:33 --> Model Class Initialized
DEBUG - 2016-06-25 16:00:33 --> Model Class Initialized
DEBUG - 2016-06-25 16:00:33 --> Model Class Initialized
ERROR - 2016-06-25 16:00:33 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 16:00:33 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 16:00:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 16:00:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 16:00:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 16:00:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 16:00:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 16:00:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 16:00:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 16:00:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 16:00:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 16:00:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 16:00:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 16:00:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 16:00:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 16:00:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 16:00:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 16:00:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 16:00:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 16:00:34 --> Final output sent to browser
DEBUG - 2016-06-25 16:00:34 --> Total execution time: 2.0368
DEBUG - 2016-06-25 16:15:27 --> Config Class Initialized
DEBUG - 2016-06-25 16:15:27 --> Hooks Class Initialized
DEBUG - 2016-06-25 16:15:27 --> Utf8 Class Initialized
DEBUG - 2016-06-25 16:15:27 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 16:15:27 --> URI Class Initialized
DEBUG - 2016-06-25 16:15:27 --> Router Class Initialized
DEBUG - 2016-06-25 16:15:27 --> Output Class Initialized
DEBUG - 2016-06-25 16:15:27 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 16:15:27 --> Security Class Initialized
DEBUG - 2016-06-25 16:15:27 --> Input Class Initialized
DEBUG - 2016-06-25 16:15:27 --> XSS Filtering completed
DEBUG - 2016-06-25 16:15:27 --> XSS Filtering completed
DEBUG - 2016-06-25 16:15:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 16:15:27 --> Language Class Initialized
DEBUG - 2016-06-25 16:15:27 --> Loader Class Initialized
DEBUG - 2016-06-25 16:15:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 16:15:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 16:15:27 --> Helper loaded: url_helper
DEBUG - 2016-06-25 16:15:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 16:15:27 --> Helper loaded: file_helper
DEBUG - 2016-06-25 16:15:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 16:15:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 16:15:27 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 16:15:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 16:15:27 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 16:15:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 16:15:27 --> Helper loaded: common_helper
DEBUG - 2016-06-25 16:15:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 16:15:27 --> Helper loaded: common_helper
DEBUG - 2016-06-25 16:15:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 16:15:28 --> Helper loaded: form_helper
DEBUG - 2016-06-25 16:15:28 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 16:15:28 --> Helper loaded: security_helper
DEBUG - 2016-06-25 16:15:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 16:15:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 16:15:28 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 16:15:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 16:15:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 16:15:28 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 16:15:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 16:15:28 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 16:15:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 16:15:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 16:15:28 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 16:15:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 16:15:28 --> Database Driver Class Initialized
DEBUG - 2016-06-25 16:15:28 --> Session Class Initialized
DEBUG - 2016-06-25 16:15:28 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 16:15:28 --> Helper loaded: string_helper
DEBUG - 2016-06-25 16:15:28 --> Session routines successfully run
DEBUG - 2016-06-25 16:15:28 --> Native_session Class Initialized
DEBUG - 2016-06-25 16:15:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 16:15:28 --> Form Validation Class Initialized
DEBUG - 2016-06-25 16:15:28 --> Form Validation Class Initialized
DEBUG - 2016-06-25 16:15:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 16:15:28 --> Controller Class Initialized
DEBUG - 2016-06-25 16:15:28 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 16:15:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 16:15:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 16:15:28 --> Carabiner: library configured.
DEBUG - 2016-06-25 16:15:28 --> Carabiner: library configured.
DEBUG - 2016-06-25 16:15:28 --> User Agent Class Initialized
DEBUG - 2016-06-25 16:15:28 --> Model Class Initialized
DEBUG - 2016-06-25 16:15:28 --> Model Class Initialized
DEBUG - 2016-06-25 16:15:28 --> Model Class Initialized
DEBUG - 2016-06-25 16:15:28 --> Model Class Initialized
DEBUG - 2016-06-25 16:15:28 --> Model Class Initialized
DEBUG - 2016-06-25 16:17:38 --> Config Class Initialized
DEBUG - 2016-06-25 16:17:38 --> Hooks Class Initialized
DEBUG - 2016-06-25 16:17:38 --> Utf8 Class Initialized
DEBUG - 2016-06-25 16:17:38 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 16:17:38 --> URI Class Initialized
DEBUG - 2016-06-25 16:17:38 --> Router Class Initialized
DEBUG - 2016-06-25 16:17:38 --> Output Class Initialized
DEBUG - 2016-06-25 16:17:38 --> Security Class Initialized
DEBUG - 2016-06-25 16:17:38 --> Input Class Initialized
DEBUG - 2016-06-25 16:17:38 --> XSS Filtering completed
DEBUG - 2016-06-25 16:17:38 --> XSS Filtering completed
DEBUG - 2016-06-25 16:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 16:17:38 --> Language Class Initialized
DEBUG - 2016-06-25 16:17:38 --> Loader Class Initialized
DEBUG - 2016-06-25 16:17:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 16:17:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 16:17:38 --> Helper loaded: url_helper
DEBUG - 2016-06-25 16:17:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 16:17:38 --> Helper loaded: file_helper
DEBUG - 2016-06-25 16:17:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 16:17:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 16:17:39 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 16:17:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 16:17:39 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 16:17:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 16:17:39 --> Helper loaded: common_helper
DEBUG - 2016-06-25 16:17:39 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 16:17:39 --> Helper loaded: common_helper
DEBUG - 2016-06-25 16:17:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 16:17:39 --> Helper loaded: form_helper
DEBUG - 2016-06-25 16:17:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 16:17:39 --> Helper loaded: security_helper
DEBUG - 2016-06-25 16:17:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 16:17:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 16:17:39 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 16:17:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 16:17:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 16:17:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 16:17:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 16:17:40 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 16:17:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 16:17:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 16:17:40 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 16:17:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 16:17:40 --> Database Driver Class Initialized
DEBUG - 2016-06-25 16:17:40 --> Session Class Initialized
DEBUG - 2016-06-25 16:17:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 16:17:40 --> Helper loaded: string_helper
DEBUG - 2016-06-25 16:17:40 --> Session routines successfully run
DEBUG - 2016-06-25 16:17:40 --> Native_session Class Initialized
DEBUG - 2016-06-25 16:17:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 16:17:40 --> Form Validation Class Initialized
DEBUG - 2016-06-25 16:17:40 --> Form Validation Class Initialized
DEBUG - 2016-06-25 16:17:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 16:17:40 --> Controller Class Initialized
DEBUG - 2016-06-25 16:17:40 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 16:17:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 16:17:41 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 16:17:41 --> Carabiner: library configured.
DEBUG - 2016-06-25 16:17:41 --> Carabiner: library configured.
DEBUG - 2016-06-25 16:17:41 --> User Agent Class Initialized
DEBUG - 2016-06-25 16:17:41 --> Model Class Initialized
DEBUG - 2016-06-25 16:17:41 --> Model Class Initialized
DEBUG - 2016-06-25 16:17:41 --> Model Class Initialized
DEBUG - 2016-06-25 16:17:41 --> Model Class Initialized
DEBUG - 2016-06-25 16:17:41 --> Model Class Initialized
DEBUG - 2016-06-25 16:17:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 16:17:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 16:17:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 16:17:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 16:17:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 16:17:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 16:17:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 16:17:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 16:17:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 16:17:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 16:17:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 16:17:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 16:17:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 16:17:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 16:17:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 16:17:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 16:17:41 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 16:17:41 --> Final output sent to browser
DEBUG - 2016-06-25 16:17:41 --> Total execution time: 3.1315
DEBUG - 2016-06-25 16:17:47 --> Config Class Initialized
DEBUG - 2016-06-25 16:17:55 --> Hooks Class Initialized
DEBUG - 2016-06-25 16:17:55 --> Config Class Initialized
DEBUG - 2016-06-25 16:17:55 --> Hooks Class Initialized
DEBUG - 2016-06-25 16:17:55 --> Utf8 Class Initialized
DEBUG - 2016-06-25 16:17:55 --> Utf8 Class Initialized
DEBUG - 2016-06-25 16:17:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 16:17:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 16:17:55 --> URI Class Initialized
DEBUG - 2016-06-25 16:17:55 --> Router Class Initialized
DEBUG - 2016-06-25 16:17:55 --> URI Class Initialized
DEBUG - 2016-06-25 16:17:55 --> Router Class Initialized
DEBUG - 2016-06-25 16:17:55 --> Output Class Initialized
DEBUG - 2016-06-25 16:17:55 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 16:17:55 --> Security Class Initialized
DEBUG - 2016-06-25 16:17:55 --> Input Class Initialized
DEBUG - 2016-06-25 16:17:55 --> XSS Filtering completed
DEBUG - 2016-06-25 16:17:56 --> XSS Filtering completed
DEBUG - 2016-06-25 16:17:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 16:17:56 --> Language Class Initialized
DEBUG - 2016-06-25 16:17:56 --> Output Class Initialized
DEBUG - 2016-06-25 16:17:56 --> Loader Class Initialized
DEBUG - 2016-06-25 16:17:56 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 16:17:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 16:17:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 16:17:57 --> Helper loaded: url_helper
DEBUG - 2016-06-25 16:17:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 16:17:57 --> Helper loaded: file_helper
DEBUG - 2016-06-25 16:17:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 16:17:57 --> Security Class Initialized
DEBUG - 2016-06-25 16:17:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 16:17:57 --> Input Class Initialized
DEBUG - 2016-06-25 16:17:57 --> XSS Filtering completed
DEBUG - 2016-06-25 16:17:57 --> XSS Filtering completed
DEBUG - 2016-06-25 16:17:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 16:17:57 --> Language Class Initialized
DEBUG - 2016-06-25 16:17:57 --> Loader Class Initialized
DEBUG - 2016-06-25 16:17:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 16:17:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 16:17:57 --> Helper loaded: url_helper
DEBUG - 2016-06-25 16:17:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 16:17:57 --> Helper loaded: file_helper
DEBUG - 2016-06-25 16:17:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 16:17:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 16:17:57 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 16:17:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 16:17:57 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 16:17:57 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 16:17:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 16:17:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 16:17:57 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 16:17:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 16:17:57 --> Helper loaded: common_helper
DEBUG - 2016-06-25 16:17:57 --> Helper loaded: common_helper
DEBUG - 2016-06-25 16:17:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 16:17:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 16:17:57 --> Helper loaded: common_helper
DEBUG - 2016-06-25 16:17:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 16:17:57 --> Helper loaded: common_helper
DEBUG - 2016-06-25 16:17:57 --> Helper loaded: form_helper
DEBUG - 2016-06-25 16:17:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 16:17:57 --> Helper loaded: form_helper
DEBUG - 2016-06-25 16:17:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 16:17:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 16:17:58 --> Helper loaded: security_helper
DEBUG - 2016-06-25 16:17:58 --> Helper loaded: security_helper
DEBUG - 2016-06-25 16:17:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 16:17:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 16:17:58 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 16:17:58 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 16:17:58 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 16:17:58 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 16:17:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 16:17:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 16:17:58 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 16:17:58 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 16:17:58 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 16:17:58 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 16:17:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 16:17:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 16:17:58 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 16:17:58 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 16:17:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 16:17:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 16:17:58 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 16:17:58 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 16:17:58 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 16:17:58 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 16:17:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 16:17:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 16:17:58 --> Database Driver Class Initialized
DEBUG - 2016-06-25 16:17:58 --> Database Driver Class Initialized
DEBUG - 2016-06-25 16:18:02 --> Session Class Initialized
DEBUG - 2016-06-25 16:18:02 --> Session Class Initialized
DEBUG - 2016-06-25 16:18:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 16:18:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 16:18:02 --> Helper loaded: string_helper
DEBUG - 2016-06-25 16:18:02 --> Helper loaded: string_helper
DEBUG - 2016-06-25 16:18:03 --> Session routines successfully run
DEBUG - 2016-06-25 16:18:03 --> Session routines successfully run
DEBUG - 2016-06-25 16:18:03 --> Native_session Class Initialized
DEBUG - 2016-06-25 16:18:03 --> Native_session Class Initialized
DEBUG - 2016-06-25 16:18:03 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 16:18:03 --> Form Validation Class Initialized
DEBUG - 2016-06-25 16:18:03 --> Form Validation Class Initialized
DEBUG - 2016-06-25 16:18:03 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 16:18:03 --> Controller Class Initialized
DEBUG - 2016-06-25 16:18:03 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 16:18:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 16:18:03 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 16:18:03 --> Carabiner: library configured.
DEBUG - 2016-06-25 16:18:03 --> Carabiner: library configured.
DEBUG - 2016-06-25 16:18:03 --> User Agent Class Initialized
DEBUG - 2016-06-25 16:18:03 --> Model Class Initialized
DEBUG - 2016-06-25 16:18:03 --> Model Class Initialized
DEBUG - 2016-06-25 16:18:03 --> Model Class Initialized
DEBUG - 2016-06-25 16:18:03 --> Model Class Initialized
DEBUG - 2016-06-25 16:18:03 --> Model Class Initialized
DEBUG - 2016-06-25 16:18:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 16:18:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 16:18:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 16:18:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 16:18:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 16:18:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 16:18:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 16:18:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 16:18:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 16:18:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 16:18:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 16:18:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 16:18:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 16:18:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 16:18:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 16:18:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 16:18:04 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-25 16:18:04 --> Final output sent to browser
DEBUG - 2016-06-25 16:18:04 --> Total execution time: 14.9447
DEBUG - 2016-06-25 16:18:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 16:18:04 --> Form Validation Class Initialized
DEBUG - 2016-06-25 16:18:04 --> Form Validation Class Initialized
DEBUG - 2016-06-25 16:18:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 16:18:04 --> Controller Class Initialized
DEBUG - 2016-06-25 16:18:04 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 16:18:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 16:18:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 16:18:04 --> Carabiner: library configured.
DEBUG - 2016-06-25 16:18:04 --> Carabiner: library configured.
DEBUG - 2016-06-25 16:18:04 --> User Agent Class Initialized
DEBUG - 2016-06-25 16:18:04 --> Model Class Initialized
DEBUG - 2016-06-25 16:18:04 --> Model Class Initialized
DEBUG - 2016-06-25 16:18:04 --> Model Class Initialized
DEBUG - 2016-06-25 16:18:04 --> Model Class Initialized
DEBUG - 2016-06-25 16:18:04 --> Model Class Initialized
ERROR - 2016-06-25 16:18:05 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 16:18:05 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 16:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 16:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 16:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 16:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 16:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 16:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 16:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 16:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 16:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 16:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 16:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 16:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 16:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 16:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 16:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 16:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 16:18:05 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 16:18:05 --> Final output sent to browser
DEBUG - 2016-06-25 16:18:05 --> Total execution time: 17.7022
DEBUG - 2016-06-25 16:18:10 --> Config Class Initialized
DEBUG - 2016-06-25 16:18:11 --> Hooks Class Initialized
DEBUG - 2016-06-25 16:18:11 --> Utf8 Class Initialized
DEBUG - 2016-06-25 16:18:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-25 16:18:11 --> URI Class Initialized
DEBUG - 2016-06-25 16:18:11 --> Router Class Initialized
DEBUG - 2016-06-25 16:18:11 --> Output Class Initialized
DEBUG - 2016-06-25 16:18:11 --> Cache file has expired. File deleted
DEBUG - 2016-06-25 16:18:11 --> Security Class Initialized
DEBUG - 2016-06-25 16:18:11 --> Input Class Initialized
DEBUG - 2016-06-25 16:18:11 --> XSS Filtering completed
DEBUG - 2016-06-25 16:18:11 --> XSS Filtering completed
DEBUG - 2016-06-25 16:18:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-25 16:18:11 --> Language Class Initialized
DEBUG - 2016-06-25 16:18:11 --> Loader Class Initialized
DEBUG - 2016-06-25 16:18:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-25 16:18:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-25 16:18:11 --> Helper loaded: url_helper
DEBUG - 2016-06-25 16:18:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-25 16:18:11 --> Helper loaded: file_helper
DEBUG - 2016-06-25 16:18:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 16:18:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-25 16:18:11 --> Helper loaded: conf_helper
DEBUG - 2016-06-25 16:18:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-25 16:18:11 --> Check Exists common_helper.php: No
DEBUG - 2016-06-25 16:18:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-25 16:18:11 --> Helper loaded: common_helper
DEBUG - 2016-06-25 16:18:11 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-25 16:18:11 --> Helper loaded: common_helper
DEBUG - 2016-06-25 16:18:11 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-25 16:18:11 --> Helper loaded: form_helper
DEBUG - 2016-06-25 16:18:11 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-25 16:18:11 --> Helper loaded: security_helper
DEBUG - 2016-06-25 16:18:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 16:18:11 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-25 16:18:11 --> Helper loaded: lang_helper
DEBUG - 2016-06-25 16:18:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-25 16:18:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-25 16:18:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-25 16:18:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-25 16:18:12 --> Helper loaded: atlant_helper
DEBUG - 2016-06-25 16:18:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 16:18:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-25 16:18:12 --> Helper loaded: crypto_helper
DEBUG - 2016-06-25 16:18:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-25 16:18:12 --> Database Driver Class Initialized
DEBUG - 2016-06-25 16:18:12 --> Session Class Initialized
DEBUG - 2016-06-25 16:18:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-25 16:18:12 --> Helper loaded: string_helper
DEBUG - 2016-06-25 16:18:12 --> Session routines successfully run
DEBUG - 2016-06-25 16:18:12 --> Native_session Class Initialized
DEBUG - 2016-06-25 16:18:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-25 16:18:12 --> Form Validation Class Initialized
DEBUG - 2016-06-25 16:18:12 --> Form Validation Class Initialized
DEBUG - 2016-06-25 16:18:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-25 16:18:12 --> Controller Class Initialized
DEBUG - 2016-06-25 16:18:12 --> Carabiner: Library initialized.
DEBUG - 2016-06-25 16:18:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-25 16:18:12 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-25 16:18:12 --> Carabiner: library configured.
DEBUG - 2016-06-25 16:18:12 --> Carabiner: library configured.
DEBUG - 2016-06-25 16:18:12 --> User Agent Class Initialized
DEBUG - 2016-06-25 16:18:12 --> Model Class Initialized
DEBUG - 2016-06-25 16:18:12 --> Model Class Initialized
DEBUG - 2016-06-25 16:18:12 --> Model Class Initialized
DEBUG - 2016-06-25 16:18:12 --> Model Class Initialized
DEBUG - 2016-06-25 16:18:12 --> Model Class Initialized
ERROR - 2016-06-25 16:18:12 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-25 16:18:12 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-25 16:18:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-25 16:18:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-25 16:18:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 16:18:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 16:18:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 16:18:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 16:18:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 16:18:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 16:18:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 16:18:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-25 16:18:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-25 16:18:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-25 16:18:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-25 16:18:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-06-25 16:18:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-25 16:18:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-25 16:18:13 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-25 16:18:13 --> Final output sent to browser
DEBUG - 2016-06-25 16:18:13 --> Total execution time: 4.0577
