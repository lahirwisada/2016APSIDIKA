<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-08-30 17:19:11 --> Config Class Initialized
DEBUG - 2016-08-30 17:19:11 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:19:11 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:19:11 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:19:11 --> URI Class Initialized
DEBUG - 2016-08-30 17:19:11 --> Router Class Initialized
DEBUG - 2016-08-30 17:19:11 --> No URI present. Default controller set.
DEBUG - 2016-08-30 17:19:11 --> Output Class Initialized
DEBUG - 2016-08-30 17:19:11 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 17:19:11 --> Security Class Initialized
DEBUG - 2016-08-30 17:19:11 --> Input Class Initialized
DEBUG - 2016-08-30 17:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:19:11 --> Language Class Initialized
DEBUG - 2016-08-30 17:19:11 --> Loader Class Initialized
DEBUG - 2016-08-30 17:19:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:19:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:19:11 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:19:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:19:11 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:19:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:19:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:19:11 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:19:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:19:11 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:19:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:19:11 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:19:11 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:19:11 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:19:11 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:19:11 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:19:11 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:19:11 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:19:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:19:11 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:19:11 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:19:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:19:11 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:19:11 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:19:11 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:19:12 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:19:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:19:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:19:12 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:19:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:19:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:19:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:19:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:19:12 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:19:12 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:19:12 --> Session Class Initialized
DEBUG - 2016-08-30 17:19:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:19:12 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:19:12 --> A session cookie was not found.
DEBUG - 2016-08-30 17:19:12 --> Session routines successfully run
DEBUG - 2016-08-30 17:19:12 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:19:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:19:12 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:19:12 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:19:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:19:12 --> Controller Class Initialized
DEBUG - 2016-08-30 17:19:12 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:19:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:19:12 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:19:12 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:19:12 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:19:13 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:19:13 --> Model Class Initialized
DEBUG - 2016-08-30 17:19:13 --> Model Class Initialized
DEBUG - 2016-08-30 17:19:13 --> Model Class Initialized
DEBUG - 2016-08-30 17:19:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-08-30 17:19:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:19:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:19:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:19:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:19:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:19:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:19:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:19:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:19:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:19:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:19:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:19:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:19:16 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-08-30 17:19:16 --> Final output sent to browser
DEBUG - 2016-08-30 17:19:16 --> Total execution time: 5.3110
DEBUG - 2016-08-30 17:20:37 --> Config Class Initialized
DEBUG - 2016-08-30 17:20:37 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:20:37 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:20:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:20:37 --> URI Class Initialized
DEBUG - 2016-08-30 17:20:37 --> Router Class Initialized
DEBUG - 2016-08-30 17:20:37 --> Output Class Initialized
DEBUG - 2016-08-30 17:20:37 --> Security Class Initialized
DEBUG - 2016-08-30 17:20:37 --> Input Class Initialized
DEBUG - 2016-08-30 17:20:37 --> XSS Filtering completed
DEBUG - 2016-08-30 17:20:37 --> XSS Filtering completed
DEBUG - 2016-08-30 17:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:20:37 --> Language Class Initialized
DEBUG - 2016-08-30 17:20:37 --> Loader Class Initialized
DEBUG - 2016-08-30 17:20:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:20:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:20:37 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:20:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:20:37 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:20:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:20:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:20:37 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:20:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:20:37 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:20:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:20:37 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:20:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:20:37 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:20:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:20:37 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:20:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:20:37 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:20:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:20:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:20:37 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:20:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:20:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:20:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:20:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:20:37 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:20:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:20:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:20:37 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:20:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:20:37 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:20:37 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:20:37 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:20:37 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:20:37 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:20:37 --> Session Class Initialized
DEBUG - 2016-08-30 17:20:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:20:37 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:20:37 --> Session routines successfully run
DEBUG - 2016-08-30 17:20:37 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:20:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:20:37 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:20:37 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:20:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:20:37 --> Controller Class Initialized
DEBUG - 2016-08-30 17:20:37 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:20:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:20:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:20:37 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:20:37 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:20:37 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:20:37 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:37 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:37 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:37 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:37 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:37 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:37 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:37 --> Model Class Initialized
ERROR - 2016-08-30 17:20:38 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-08-30 17:20:38 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-08-30 17:20:38 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-08-30 17:20:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-08-30 17:20:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-08-30 17:20:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-08-30 17:20:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-08-30 17:20:38 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-08-30 17:20:38 --> Final output sent to browser
DEBUG - 2016-08-30 17:20:38 --> Total execution time: 1.2712
DEBUG - 2016-08-30 17:20:39 --> Config Class Initialized
DEBUG - 2016-08-30 17:20:39 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:20:39 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:20:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:20:39 --> URI Class Initialized
DEBUG - 2016-08-30 17:20:39 --> Router Class Initialized
ERROR - 2016-08-30 17:20:39 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-08-30 17:20:44 --> Config Class Initialized
DEBUG - 2016-08-30 17:20:44 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:20:44 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:20:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:20:44 --> URI Class Initialized
DEBUG - 2016-08-30 17:20:44 --> Router Class Initialized
DEBUG - 2016-08-30 17:20:44 --> Output Class Initialized
DEBUG - 2016-08-30 17:20:44 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 17:20:44 --> Security Class Initialized
DEBUG - 2016-08-30 17:20:44 --> Input Class Initialized
DEBUG - 2016-08-30 17:20:44 --> XSS Filtering completed
DEBUG - 2016-08-30 17:20:44 --> XSS Filtering completed
DEBUG - 2016-08-30 17:20:44 --> XSS Filtering completed
DEBUG - 2016-08-30 17:20:44 --> XSS Filtering completed
DEBUG - 2016-08-30 17:20:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:20:44 --> Language Class Initialized
DEBUG - 2016-08-30 17:20:44 --> Loader Class Initialized
DEBUG - 2016-08-30 17:20:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:20:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:20:44 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:20:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:20:44 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:20:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:20:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:20:44 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:20:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:20:44 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:20:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:20:44 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:20:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:20:44 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:20:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:20:44 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:20:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:20:44 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:20:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:20:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:20:44 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:20:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:20:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:20:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:20:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:20:44 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:20:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:20:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:20:44 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:20:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:20:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:20:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:20:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:20:44 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:20:44 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Session Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:20:45 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:20:45 --> Session routines successfully run
DEBUG - 2016-08-30 17:20:45 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:20:45 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:20:45 --> Controller Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:20:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:20:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:20:45 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:20:45 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:20:45 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Model Class Initialized
ERROR - 2016-08-30 17:20:45 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-08-30 17:20:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 17:20:45 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:20:45 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-08-30 17:20:45 --> Config Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:20:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:20:45 --> URI Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Router Class Initialized
DEBUG - 2016-08-30 17:20:45 --> No URI present. Default controller set.
DEBUG - 2016-08-30 17:20:45 --> Output Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 17:20:45 --> Security Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Input Class Initialized
DEBUG - 2016-08-30 17:20:45 --> XSS Filtering completed
DEBUG - 2016-08-30 17:20:45 --> XSS Filtering completed
DEBUG - 2016-08-30 17:20:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:20:45 --> Language Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Loader Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:20:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:20:45 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:20:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:20:45 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:20:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:20:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:20:45 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:20:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:20:45 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:20:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:20:45 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:20:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:20:45 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:20:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:20:45 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:20:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:20:45 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:20:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:20:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:20:45 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:20:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:20:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:20:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:20:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:20:45 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:20:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:20:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:20:45 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:20:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:20:45 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:20:45 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:20:45 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:20:45 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:20:45 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Session Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:20:45 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:20:45 --> Session routines successfully run
DEBUG - 2016-08-30 17:20:45 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:20:45 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:20:45 --> Controller Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:20:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:20:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:20:45 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:20:45 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:20:45 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:45 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-08-30 17:20:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:20:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:20:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:20:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:20:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:20:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:20:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:20:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:20:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:20:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:20:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:20:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:20:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-08-30 17:20:45 --> Final output sent to browser
DEBUG - 2016-08-30 17:20:45 --> Total execution time: 0.2198
DEBUG - 2016-08-30 17:20:47 --> Config Class Initialized
DEBUG - 2016-08-30 17:20:47 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:20:47 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:20:47 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:20:47 --> URI Class Initialized
DEBUG - 2016-08-30 17:20:47 --> Router Class Initialized
DEBUG - 2016-08-30 17:20:47 --> Output Class Initialized
DEBUG - 2016-08-30 17:20:48 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 17:20:48 --> Security Class Initialized
DEBUG - 2016-08-30 17:20:48 --> Input Class Initialized
DEBUG - 2016-08-30 17:20:48 --> XSS Filtering completed
DEBUG - 2016-08-30 17:20:48 --> XSS Filtering completed
DEBUG - 2016-08-30 17:20:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:20:48 --> Language Class Initialized
DEBUG - 2016-08-30 17:20:48 --> Loader Class Initialized
DEBUG - 2016-08-30 17:20:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:20:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:20:48 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:20:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:20:48 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:20:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:20:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:20:48 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:20:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:20:48 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:20:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:20:48 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:20:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:20:48 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:20:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:20:48 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:20:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:20:48 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:20:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:20:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:20:48 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:20:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:20:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:20:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:20:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:20:48 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:20:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:20:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:20:48 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:20:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:20:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:20:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:20:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:20:48 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:20:48 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:20:48 --> Session Class Initialized
DEBUG - 2016-08-30 17:20:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:20:48 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:20:48 --> Session routines successfully run
DEBUG - 2016-08-30 17:20:48 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:20:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:20:48 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:20:48 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:20:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:20:48 --> Controller Class Initialized
DEBUG - 2016-08-30 17:20:48 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:20:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:20:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:20:48 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:20:48 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:20:48 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:20:48 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:48 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:48 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:48 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:48 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:48 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:48 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:48 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:48 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 17:20:49 --> Pagination Class Initialized
DEBUG - 2016-08-30 17:20:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 17:20:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-30 17:20:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:20:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:20:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:20:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:20:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-30 17:20:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:20:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:20:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:20:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:20:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:20:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:20:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-30 17:20:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:20:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:20:50 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-30 17:20:50 --> Final output sent to browser
DEBUG - 2016-08-30 17:20:50 --> Total execution time: 1.8702
DEBUG - 2016-08-30 17:20:50 --> Config Class Initialized
DEBUG - 2016-08-30 17:20:50 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:20:50 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:20:50 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:20:50 --> URI Class Initialized
DEBUG - 2016-08-30 17:20:50 --> Router Class Initialized
ERROR - 2016-08-30 17:20:50 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-08-30 17:20:52 --> Config Class Initialized
DEBUG - 2016-08-30 17:20:52 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:20:52 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:20:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:20:52 --> URI Class Initialized
DEBUG - 2016-08-30 17:20:52 --> Router Class Initialized
DEBUG - 2016-08-30 17:20:52 --> Output Class Initialized
DEBUG - 2016-08-30 17:20:52 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 17:20:52 --> Security Class Initialized
DEBUG - 2016-08-30 17:20:52 --> Input Class Initialized
DEBUG - 2016-08-30 17:20:52 --> XSS Filtering completed
DEBUG - 2016-08-30 17:20:52 --> XSS Filtering completed
DEBUG - 2016-08-30 17:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:20:52 --> Language Class Initialized
DEBUG - 2016-08-30 17:20:52 --> Loader Class Initialized
DEBUG - 2016-08-30 17:20:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:20:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:20:52 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:20:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:20:52 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:20:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:20:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:20:52 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:20:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:20:52 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:20:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:20:52 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:20:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:20:52 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:20:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:20:52 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:20:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:20:52 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:20:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:20:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:20:52 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:20:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:20:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:20:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:20:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:20:52 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:20:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:20:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:20:52 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:20:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:20:53 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:20:53 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:20:53 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:20:53 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:20:53 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:20:53 --> Session Class Initialized
DEBUG - 2016-08-30 17:20:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:20:53 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:20:53 --> Session routines successfully run
DEBUG - 2016-08-30 17:20:53 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:20:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:20:53 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:20:53 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:20:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:20:53 --> Controller Class Initialized
DEBUG - 2016-08-30 17:20:53 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:20:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:20:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:20:53 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:20:53 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:20:53 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:20:53 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:53 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:53 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:53 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:53 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 17:20:53 --> Pagination Class Initialized
DEBUG - 2016-08-30 17:20:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 17:20:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/index.php
DEBUG - 2016-08-30 17:20:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:20:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:20:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:20:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:20:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-08-30 17:20:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:20:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:20:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:20:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:20:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:20:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:20:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-08-30 17:20:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:20:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:20:53 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c2a3e0401bd35d4fcac4bae5f9412231
DEBUG - 2016-08-30 17:20:53 --> Final output sent to browser
DEBUG - 2016-08-30 17:20:53 --> Total execution time: 0.8597
DEBUG - 2016-08-30 17:20:54 --> Config Class Initialized
DEBUG - 2016-08-30 17:20:54 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:20:54 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:20:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:20:54 --> URI Class Initialized
DEBUG - 2016-08-30 17:20:54 --> Router Class Initialized
DEBUG - 2016-08-30 17:20:54 --> Output Class Initialized
DEBUG - 2016-08-30 17:20:54 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 17:20:54 --> Security Class Initialized
DEBUG - 2016-08-30 17:20:54 --> Input Class Initialized
DEBUG - 2016-08-30 17:20:54 --> XSS Filtering completed
DEBUG - 2016-08-30 17:20:54 --> XSS Filtering completed
DEBUG - 2016-08-30 17:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:20:54 --> Language Class Initialized
DEBUG - 2016-08-30 17:20:54 --> Loader Class Initialized
DEBUG - 2016-08-30 17:20:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:20:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:20:54 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:20:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:20:54 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:20:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:20:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:20:55 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:20:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:20:55 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:20:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:20:55 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:20:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:20:55 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:20:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:20:55 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:20:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:20:55 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:20:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:20:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:20:55 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:20:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:20:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:20:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:20:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:20:55 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:20:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:20:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:20:55 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:20:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:20:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:20:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:20:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:20:55 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:20:55 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Session Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:20:55 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:20:55 --> Session routines successfully run
DEBUG - 2016-08-30 17:20:55 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:20:55 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:20:55 --> Controller Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:20:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:20:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:20:55 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:20:55 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:20:55 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 17:20:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:20:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:20:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:20:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:20:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:20:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:20:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:20:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:20:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:20:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:20:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:20:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:20:55 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 17:20:55 --> Final output sent to browser
DEBUG - 2016-08-30 17:20:55 --> Total execution time: 0.3933
DEBUG - 2016-08-30 17:20:55 --> Config Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:20:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:20:55 --> URI Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Router Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Output Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Security Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Input Class Initialized
DEBUG - 2016-08-30 17:20:55 --> XSS Filtering completed
DEBUG - 2016-08-30 17:20:55 --> XSS Filtering completed
DEBUG - 2016-08-30 17:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:20:55 --> Language Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Loader Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:20:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:20:55 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:20:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:20:55 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:20:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:20:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:20:55 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:20:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:20:55 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:20:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:20:55 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:20:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:20:55 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:20:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:20:55 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:20:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:20:55 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:20:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:20:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:20:55 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:20:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:20:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:20:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:20:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:20:55 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:20:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:20:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:20:55 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:20:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:20:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:20:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:20:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:20:55 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:20:55 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Session Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:20:55 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:20:55 --> Session routines successfully run
DEBUG - 2016-08-30 17:20:55 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:20:55 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:20:55 --> Controller Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:20:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:20:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:20:55 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:20:55 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:20:55 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Model Class Initialized
DEBUG - 2016-08-30 17:20:55 --> Model Class Initialized
ERROR - 2016-08-30 17:20:55 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;favicon.ico&quot;
LINE 10: WHERE &quot;sc_sidika&quot;.&quot;ref_pegawai&quot;.&quot;id_pegawai&quot; = 'favicon.ico'...
                                                        ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-08-30 17:20:55 --> DB Transaction Failure
ERROR - 2016-08-30 17:20:55 --> Query error: ERROR:  invalid input syntax for integer: "favicon.ico"
LINE 10: WHERE "sc_sidika"."ref_pegawai"."id_pegawai" = 'favicon.ico'...
                                                        ^
DEBUG - 2016-08-30 17:20:56 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-08-30 17:21:48 --> Config Class Initialized
DEBUG - 2016-08-30 17:21:48 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:21:48 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:21:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:21:48 --> URI Class Initialized
DEBUG - 2016-08-30 17:21:48 --> Router Class Initialized
DEBUG - 2016-08-30 17:21:48 --> Output Class Initialized
DEBUG - 2016-08-30 17:21:48 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 17:21:48 --> Security Class Initialized
DEBUG - 2016-08-30 17:21:48 --> Input Class Initialized
DEBUG - 2016-08-30 17:21:48 --> XSS Filtering completed
DEBUG - 2016-08-30 17:21:48 --> XSS Filtering completed
DEBUG - 2016-08-30 17:21:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:21:48 --> Language Class Initialized
DEBUG - 2016-08-30 17:21:48 --> Loader Class Initialized
DEBUG - 2016-08-30 17:21:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:21:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:21:48 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:21:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:21:48 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:21:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:21:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:21:48 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:21:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:21:48 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:21:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:21:48 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:21:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:21:48 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:21:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:21:48 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:21:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:21:48 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:21:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:21:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:21:48 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:21:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:21:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:21:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:21:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:21:48 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:21:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:21:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:21:48 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:21:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:21:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:21:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:21:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:21:48 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:21:48 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:21:48 --> Session Class Initialized
DEBUG - 2016-08-30 17:21:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:21:48 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:21:48 --> Session routines successfully run
DEBUG - 2016-08-30 17:21:48 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:21:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:21:48 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:21:48 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:21:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:21:48 --> Controller Class Initialized
DEBUG - 2016-08-30 17:21:48 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:21:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:21:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:21:48 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:21:48 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:21:48 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:21:48 --> Model Class Initialized
DEBUG - 2016-08-30 17:21:48 --> Model Class Initialized
DEBUG - 2016-08-30 17:21:48 --> Model Class Initialized
DEBUG - 2016-08-30 17:21:48 --> Model Class Initialized
DEBUG - 2016-08-30 17:21:48 --> Model Class Initialized
DEBUG - 2016-08-30 17:21:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 17:21:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:21:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:21:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:21:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:21:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:21:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:21:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:21:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:21:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:21:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:21:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:21:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:21:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 17:21:48 --> Final output sent to browser
DEBUG - 2016-08-30 17:21:48 --> Total execution time: 0.4081
DEBUG - 2016-08-30 17:21:49 --> Config Class Initialized
DEBUG - 2016-08-30 17:21:49 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:21:49 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:21:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:21:49 --> URI Class Initialized
DEBUG - 2016-08-30 17:21:49 --> Router Class Initialized
DEBUG - 2016-08-30 17:21:49 --> Output Class Initialized
DEBUG - 2016-08-30 17:21:49 --> Security Class Initialized
DEBUG - 2016-08-30 17:21:49 --> Input Class Initialized
DEBUG - 2016-08-30 17:21:49 --> XSS Filtering completed
DEBUG - 2016-08-30 17:21:49 --> XSS Filtering completed
DEBUG - 2016-08-30 17:21:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:21:49 --> Language Class Initialized
DEBUG - 2016-08-30 17:21:49 --> Loader Class Initialized
DEBUG - 2016-08-30 17:21:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:21:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:21:49 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:21:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:21:49 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:21:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:21:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:21:49 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:21:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:21:49 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:21:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:21:49 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:21:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:21:49 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:21:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:21:49 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:21:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:21:49 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:21:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:21:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:21:49 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:21:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:21:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:21:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:21:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:21:49 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:21:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:21:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:21:49 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:21:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:21:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:21:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:21:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:21:49 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:21:49 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:21:49 --> Session Class Initialized
DEBUG - 2016-08-30 17:21:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:21:49 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:21:49 --> Session routines successfully run
DEBUG - 2016-08-30 17:21:49 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:21:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:21:49 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:21:49 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:21:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:21:49 --> Controller Class Initialized
DEBUG - 2016-08-30 17:21:49 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:21:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:21:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:21:49 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:21:49 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:21:49 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:21:49 --> Model Class Initialized
DEBUG - 2016-08-30 17:21:49 --> Model Class Initialized
DEBUG - 2016-08-30 17:21:49 --> Model Class Initialized
DEBUG - 2016-08-30 17:21:49 --> Model Class Initialized
DEBUG - 2016-08-30 17:21:49 --> Model Class Initialized
ERROR - 2016-08-30 17:21:49 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;favicon.ico&quot;
LINE 10: WHERE &quot;sc_sidika&quot;.&quot;ref_pegawai&quot;.&quot;id_pegawai&quot; = 'favicon.ico'...
                                                        ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-08-30 17:21:49 --> DB Transaction Failure
ERROR - 2016-08-30 17:21:49 --> Query error: ERROR:  invalid input syntax for integer: "favicon.ico"
LINE 10: WHERE "sc_sidika"."ref_pegawai"."id_pegawai" = 'favicon.ico'...
                                                        ^
DEBUG - 2016-08-30 17:21:49 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-08-30 17:25:42 --> Config Class Initialized
DEBUG - 2016-08-30 17:25:42 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:25:42 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:25:42 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:25:42 --> URI Class Initialized
DEBUG - 2016-08-30 17:25:42 --> Router Class Initialized
DEBUG - 2016-08-30 17:25:42 --> Output Class Initialized
DEBUG - 2016-08-30 17:25:42 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 17:25:42 --> Security Class Initialized
DEBUG - 2016-08-30 17:25:42 --> Input Class Initialized
DEBUG - 2016-08-30 17:25:42 --> XSS Filtering completed
DEBUG - 2016-08-30 17:25:42 --> XSS Filtering completed
DEBUG - 2016-08-30 17:25:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:25:42 --> Language Class Initialized
DEBUG - 2016-08-30 17:25:42 --> Loader Class Initialized
DEBUG - 2016-08-30 17:25:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:25:42 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:25:42 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:25:42 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:25:42 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:25:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:25:42 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:25:42 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:25:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:25:42 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:25:42 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:25:42 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:25:42 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:25:42 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:25:42 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:25:42 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:25:42 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:25:42 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:25:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:25:42 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:25:42 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:25:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:25:42 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:25:42 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:25:42 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:25:42 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:25:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:25:42 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:25:42 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:25:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:25:42 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:25:42 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:25:42 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:25:42 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:25:42 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:25:42 --> Session Class Initialized
DEBUG - 2016-08-30 17:25:42 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:25:42 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:25:42 --> Session routines successfully run
DEBUG - 2016-08-30 17:25:42 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:25:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:25:42 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:25:42 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:25:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:25:42 --> Controller Class Initialized
DEBUG - 2016-08-30 17:25:42 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:25:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:25:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:25:42 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:25:42 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:25:42 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:25:42 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:42 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:42 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:42 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:42 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 17:25:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 17:25:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 17:25:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:25:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:25:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:25:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:25:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:25:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:25:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:25:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:25:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:25:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:25:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:25:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:25:42 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 17:25:42 --> Final output sent to browser
DEBUG - 2016-08-30 17:25:42 --> Total execution time: 0.4330
DEBUG - 2016-08-30 17:25:43 --> Config Class Initialized
DEBUG - 2016-08-30 17:25:43 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:25:43 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:25:43 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:25:43 --> URI Class Initialized
DEBUG - 2016-08-30 17:25:43 --> Router Class Initialized
DEBUG - 2016-08-30 17:25:43 --> Output Class Initialized
DEBUG - 2016-08-30 17:25:43 --> Security Class Initialized
DEBUG - 2016-08-30 17:25:43 --> Input Class Initialized
DEBUG - 2016-08-30 17:25:43 --> XSS Filtering completed
DEBUG - 2016-08-30 17:25:43 --> XSS Filtering completed
DEBUG - 2016-08-30 17:25:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:25:43 --> Language Class Initialized
DEBUG - 2016-08-30 17:25:43 --> Loader Class Initialized
DEBUG - 2016-08-30 17:25:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:25:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:25:43 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:25:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:25:43 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:25:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:25:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:25:43 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:25:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:25:43 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:25:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:25:43 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:25:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:25:43 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:25:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:25:43 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:25:43 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:25:43 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:25:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:25:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:25:43 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:25:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:25:43 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:25:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:25:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:25:43 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:25:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:25:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:25:43 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:25:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:25:43 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:25:43 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:25:43 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:25:43 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:25:43 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:25:43 --> Session Class Initialized
DEBUG - 2016-08-30 17:25:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:25:43 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:25:43 --> Session routines successfully run
DEBUG - 2016-08-30 17:25:43 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:25:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:25:43 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:25:43 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:25:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:25:43 --> Controller Class Initialized
DEBUG - 2016-08-30 17:25:43 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:25:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:25:43 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:25:43 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:25:43 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:25:43 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:25:43 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:43 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:43 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:43 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:43 --> Model Class Initialized
ERROR - 2016-08-30 17:25:44 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;favicon.ico&quot;
LINE 10: WHERE &quot;sc_sidika&quot;.&quot;ref_pegawai&quot;.&quot;id_pegawai&quot; = 'favicon.ico'...
                                                        ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-08-30 17:25:44 --> DB Transaction Failure
ERROR - 2016-08-30 17:25:44 --> Query error: ERROR:  invalid input syntax for integer: "favicon.ico"
LINE 10: WHERE "sc_sidika"."ref_pegawai"."id_pegawai" = 'favicon.ico'...
                                                        ^
DEBUG - 2016-08-30 17:25:44 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-08-30 17:25:47 --> Config Class Initialized
DEBUG - 2016-08-30 17:25:47 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:25:47 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:25:47 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:25:47 --> URI Class Initialized
DEBUG - 2016-08-30 17:25:47 --> Router Class Initialized
DEBUG - 2016-08-30 17:25:47 --> Output Class Initialized
DEBUG - 2016-08-30 17:25:47 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 17:25:47 --> Security Class Initialized
DEBUG - 2016-08-30 17:25:47 --> Input Class Initialized
DEBUG - 2016-08-30 17:25:47 --> XSS Filtering completed
DEBUG - 2016-08-30 17:25:47 --> XSS Filtering completed
DEBUG - 2016-08-30 17:25:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:25:47 --> Language Class Initialized
DEBUG - 2016-08-30 17:25:47 --> Loader Class Initialized
DEBUG - 2016-08-30 17:25:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:25:47 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:25:47 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:25:47 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:25:47 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:25:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:25:47 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:25:47 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:25:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:25:47 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:25:47 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:25:47 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:25:47 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:25:47 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:25:47 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:25:47 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:25:47 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:25:47 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:25:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:25:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:25:47 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:25:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:25:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:25:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:25:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:25:47 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:25:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:25:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:25:47 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:25:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:25:47 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:25:47 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:25:47 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:25:47 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:25:47 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:25:47 --> Session Class Initialized
DEBUG - 2016-08-30 17:25:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:25:47 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:25:47 --> Session routines successfully run
DEBUG - 2016-08-30 17:25:47 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:25:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:25:47 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:25:47 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:25:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:25:47 --> Controller Class Initialized
DEBUG - 2016-08-30 17:25:47 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:25:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:25:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:25:47 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:25:47 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:25:47 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:25:47 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:47 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:47 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:47 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:47 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:25:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 17:25:47 --> Final output sent to browser
DEBUG - 2016-08-30 17:25:47 --> Total execution time: 0.4612
DEBUG - 2016-08-30 17:25:48 --> Config Class Initialized
DEBUG - 2016-08-30 17:25:48 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:25:48 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:25:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:25:48 --> URI Class Initialized
DEBUG - 2016-08-30 17:25:48 --> Router Class Initialized
DEBUG - 2016-08-30 17:25:48 --> Output Class Initialized
DEBUG - 2016-08-30 17:25:48 --> Security Class Initialized
DEBUG - 2016-08-30 17:25:48 --> Input Class Initialized
DEBUG - 2016-08-30 17:25:48 --> XSS Filtering completed
DEBUG - 2016-08-30 17:25:48 --> XSS Filtering completed
DEBUG - 2016-08-30 17:25:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:25:48 --> Language Class Initialized
DEBUG - 2016-08-30 17:25:48 --> Loader Class Initialized
DEBUG - 2016-08-30 17:25:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:25:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:25:48 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:25:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:25:48 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:25:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:25:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:25:48 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:25:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:25:48 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:25:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:25:48 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:25:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:25:48 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:25:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:25:48 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:25:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:25:48 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:25:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:25:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:25:48 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:25:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:25:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:25:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:25:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:25:48 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:25:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:25:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:25:48 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:25:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:25:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:25:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:25:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:25:48 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:25:48 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:25:48 --> Session Class Initialized
DEBUG - 2016-08-30 17:25:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:25:48 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:25:48 --> Session routines successfully run
DEBUG - 2016-08-30 17:25:48 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:25:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:25:48 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:25:48 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:25:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:25:48 --> Controller Class Initialized
DEBUG - 2016-08-30 17:25:48 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:25:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:25:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:25:48 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:25:48 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:25:48 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:25:48 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:48 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:48 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:48 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:48 --> Model Class Initialized
ERROR - 2016-08-30 17:25:48 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;favicon.ico&quot;
LINE 10: WHERE &quot;sc_sidika&quot;.&quot;ref_pegawai&quot;.&quot;id_pegawai&quot; = 'favicon.ico'...
                                                        ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-08-30 17:25:48 --> DB Transaction Failure
ERROR - 2016-08-30 17:25:48 --> Query error: ERROR:  invalid input syntax for integer: "favicon.ico"
LINE 10: WHERE "sc_sidika"."ref_pegawai"."id_pegawai" = 'favicon.ico'...
                                                        ^
DEBUG - 2016-08-30 17:25:48 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-08-30 17:25:56 --> Config Class Initialized
DEBUG - 2016-08-30 17:25:56 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:25:56 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:25:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:25:56 --> URI Class Initialized
DEBUG - 2016-08-30 17:25:56 --> Router Class Initialized
DEBUG - 2016-08-30 17:25:56 --> Output Class Initialized
DEBUG - 2016-08-30 17:25:56 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 17:25:56 --> Security Class Initialized
DEBUG - 2016-08-30 17:25:56 --> Input Class Initialized
DEBUG - 2016-08-30 17:25:56 --> XSS Filtering completed
DEBUG - 2016-08-30 17:25:56 --> XSS Filtering completed
DEBUG - 2016-08-30 17:25:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:25:56 --> Language Class Initialized
DEBUG - 2016-08-30 17:25:56 --> Loader Class Initialized
DEBUG - 2016-08-30 17:25:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:25:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:25:56 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:25:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:25:56 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:25:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:25:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:25:56 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:25:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:25:56 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:25:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:25:56 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:25:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:25:56 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:25:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:25:56 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:25:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:25:56 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:25:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:25:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:25:56 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:25:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:25:56 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:25:56 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:25:56 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:25:56 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:25:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:25:56 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:25:56 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:25:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:25:56 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:25:56 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:25:56 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:25:56 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:25:56 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:25:56 --> Session Class Initialized
DEBUG - 2016-08-30 17:25:56 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:25:56 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:25:56 --> Session routines successfully run
DEBUG - 2016-08-30 17:25:56 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:25:56 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:25:56 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:25:56 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:25:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:25:56 --> Controller Class Initialized
DEBUG - 2016-08-30 17:25:56 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:25:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:25:56 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:25:56 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:25:56 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:25:56 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:25:56 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:56 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:56 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:56 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:56 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 17:25:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 17:25:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 17:25:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:25:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:25:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:25:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:25:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:25:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:25:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:25:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:25:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:25:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:25:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:25:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:25:56 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 17:25:56 --> Final output sent to browser
DEBUG - 2016-08-30 17:25:56 --> Total execution time: 0.5008
DEBUG - 2016-08-30 17:25:57 --> Config Class Initialized
DEBUG - 2016-08-30 17:25:57 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:25:57 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:25:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:25:57 --> URI Class Initialized
DEBUG - 2016-08-30 17:25:57 --> Router Class Initialized
DEBUG - 2016-08-30 17:25:57 --> Output Class Initialized
DEBUG - 2016-08-30 17:25:57 --> Security Class Initialized
DEBUG - 2016-08-30 17:25:57 --> Input Class Initialized
DEBUG - 2016-08-30 17:25:57 --> XSS Filtering completed
DEBUG - 2016-08-30 17:25:57 --> XSS Filtering completed
DEBUG - 2016-08-30 17:25:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:25:57 --> Language Class Initialized
DEBUG - 2016-08-30 17:25:57 --> Loader Class Initialized
DEBUG - 2016-08-30 17:25:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:25:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:25:57 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:25:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:25:57 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:25:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:25:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:25:57 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:25:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:25:57 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:25:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:25:57 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:25:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:25:57 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:25:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:25:57 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:25:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:25:57 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:25:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:25:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:25:57 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:25:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:25:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:25:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:25:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:25:57 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:25:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:25:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:25:57 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:25:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:25:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:25:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:25:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:25:57 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:25:57 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:25:57 --> Session Class Initialized
DEBUG - 2016-08-30 17:25:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:25:57 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:25:57 --> Session routines successfully run
DEBUG - 2016-08-30 17:25:57 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:25:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:25:57 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:25:57 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:25:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:25:57 --> Controller Class Initialized
DEBUG - 2016-08-30 17:25:57 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:25:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:25:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:25:57 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:25:57 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:25:57 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:25:57 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:57 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:57 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:57 --> Model Class Initialized
DEBUG - 2016-08-30 17:25:57 --> Model Class Initialized
ERROR - 2016-08-30 17:25:57 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;favicon.ico&quot;
LINE 10: WHERE &quot;sc_sidika&quot;.&quot;ref_pegawai&quot;.&quot;id_pegawai&quot; = 'favicon.ico'...
                                                        ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-08-30 17:25:57 --> DB Transaction Failure
ERROR - 2016-08-30 17:25:57 --> Query error: ERROR:  invalid input syntax for integer: "favicon.ico"
LINE 10: WHERE "sc_sidika"."ref_pegawai"."id_pegawai" = 'favicon.ico'...
                                                        ^
DEBUG - 2016-08-30 17:25:57 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-08-30 17:26:07 --> Config Class Initialized
DEBUG - 2016-08-30 17:26:07 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:26:07 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:26:07 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:26:07 --> URI Class Initialized
DEBUG - 2016-08-30 17:26:07 --> Router Class Initialized
DEBUG - 2016-08-30 17:26:07 --> Output Class Initialized
DEBUG - 2016-08-30 17:26:07 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 17:26:07 --> Security Class Initialized
DEBUG - 2016-08-30 17:26:07 --> Input Class Initialized
DEBUG - 2016-08-30 17:26:07 --> XSS Filtering completed
DEBUG - 2016-08-30 17:26:07 --> XSS Filtering completed
DEBUG - 2016-08-30 17:26:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:26:07 --> Language Class Initialized
DEBUG - 2016-08-30 17:26:07 --> Loader Class Initialized
DEBUG - 2016-08-30 17:26:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:26:07 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:26:07 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:26:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:26:07 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:26:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:26:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:26:07 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:26:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:26:07 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:26:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:26:07 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:26:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:26:07 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:26:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:26:07 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:26:07 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:26:07 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:26:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:26:07 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:26:07 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:26:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:26:08 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:26:08 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:26:08 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:26:08 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:26:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:26:08 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:26:08 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:26:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:26:08 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:26:08 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:26:08 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:26:08 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:26:08 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:26:08 --> Session Class Initialized
DEBUG - 2016-08-30 17:26:08 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:26:08 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:26:08 --> Session routines successfully run
DEBUG - 2016-08-30 17:26:08 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:26:08 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:26:08 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:26:08 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:26:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:26:08 --> Controller Class Initialized
DEBUG - 2016-08-30 17:26:08 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:26:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:26:08 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:26:08 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:26:08 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:26:08 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:26:08 --> Model Class Initialized
DEBUG - 2016-08-30 17:26:08 --> Model Class Initialized
DEBUG - 2016-08-30 17:26:08 --> Model Class Initialized
DEBUG - 2016-08-30 17:26:08 --> Model Class Initialized
DEBUG - 2016-08-30 17:26:08 --> Model Class Initialized
DEBUG - 2016-08-30 17:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 17:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 17:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 17:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:26:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:26:08 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 17:26:08 --> Final output sent to browser
DEBUG - 2016-08-30 17:26:08 --> Total execution time: 0.5459
DEBUG - 2016-08-30 17:26:08 --> Config Class Initialized
DEBUG - 2016-08-30 17:26:08 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:26:08 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:26:08 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:26:08 --> URI Class Initialized
DEBUG - 2016-08-30 17:26:08 --> Router Class Initialized
DEBUG - 2016-08-30 17:26:08 --> Output Class Initialized
DEBUG - 2016-08-30 17:26:08 --> Security Class Initialized
DEBUG - 2016-08-30 17:26:08 --> Input Class Initialized
DEBUG - 2016-08-30 17:26:08 --> XSS Filtering completed
DEBUG - 2016-08-30 17:26:08 --> XSS Filtering completed
DEBUG - 2016-08-30 17:26:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:26:09 --> Language Class Initialized
DEBUG - 2016-08-30 17:26:09 --> Loader Class Initialized
DEBUG - 2016-08-30 17:26:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:26:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:26:09 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:26:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:26:09 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:26:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:26:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:26:09 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:26:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:26:09 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:26:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:26:09 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:26:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:26:09 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:26:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:26:09 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:26:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:26:09 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:26:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:26:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:26:09 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:26:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:26:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:26:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:26:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:26:09 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:26:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:26:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:26:09 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:26:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:26:09 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:26:09 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:26:09 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:26:09 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:26:09 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:26:09 --> Session Class Initialized
DEBUG - 2016-08-30 17:26:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:26:09 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:26:09 --> Session routines successfully run
DEBUG - 2016-08-30 17:26:09 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:26:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:26:09 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:26:09 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:26:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:26:09 --> Controller Class Initialized
DEBUG - 2016-08-30 17:26:09 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:26:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:26:09 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:26:09 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:26:09 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:26:09 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:26:09 --> Model Class Initialized
DEBUG - 2016-08-30 17:26:09 --> Model Class Initialized
DEBUG - 2016-08-30 17:26:09 --> Model Class Initialized
DEBUG - 2016-08-30 17:26:09 --> Model Class Initialized
DEBUG - 2016-08-30 17:26:09 --> Model Class Initialized
ERROR - 2016-08-30 17:26:09 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;favicon.ico&quot;
LINE 10: WHERE &quot;sc_sidika&quot;.&quot;ref_pegawai&quot;.&quot;id_pegawai&quot; = 'favicon.ico'...
                                                        ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-08-30 17:26:09 --> DB Transaction Failure
ERROR - 2016-08-30 17:26:09 --> Query error: ERROR:  invalid input syntax for integer: "favicon.ico"
LINE 10: WHERE "sc_sidika"."ref_pegawai"."id_pegawai" = 'favicon.ico'...
                                                        ^
DEBUG - 2016-08-30 17:26:09 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-08-30 17:27:04 --> Config Class Initialized
DEBUG - 2016-08-30 17:27:04 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:27:04 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:27:04 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:27:04 --> URI Class Initialized
DEBUG - 2016-08-30 17:27:04 --> Router Class Initialized
DEBUG - 2016-08-30 17:27:04 --> Output Class Initialized
DEBUG - 2016-08-30 17:27:04 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 17:27:04 --> Security Class Initialized
DEBUG - 2016-08-30 17:27:04 --> Input Class Initialized
DEBUG - 2016-08-30 17:27:04 --> XSS Filtering completed
DEBUG - 2016-08-30 17:27:04 --> XSS Filtering completed
DEBUG - 2016-08-30 17:27:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:27:04 --> Language Class Initialized
DEBUG - 2016-08-30 17:27:04 --> Loader Class Initialized
DEBUG - 2016-08-30 17:27:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:27:04 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:27:04 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:27:04 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:27:04 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:27:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:27:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:27:04 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:27:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:27:04 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:27:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:27:04 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:27:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:27:04 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:27:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:27:04 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:27:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:27:04 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:27:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:27:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:27:04 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:27:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:27:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:27:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:27:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:27:04 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:27:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:27:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:27:04 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:27:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:27:04 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:27:04 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:27:04 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:27:04 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:27:04 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:27:04 --> Session Class Initialized
DEBUG - 2016-08-30 17:27:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:27:04 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:27:04 --> Session routines successfully run
DEBUG - 2016-08-30 17:27:04 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:27:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:27:04 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:27:04 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:27:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:27:04 --> Controller Class Initialized
DEBUG - 2016-08-30 17:27:04 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:27:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:27:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:27:04 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:27:04 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:27:04 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:27:04 --> Model Class Initialized
DEBUG - 2016-08-30 17:27:04 --> Model Class Initialized
DEBUG - 2016-08-30 17:27:04 --> Model Class Initialized
DEBUG - 2016-08-30 17:27:04 --> Model Class Initialized
DEBUG - 2016-08-30 17:27:04 --> Model Class Initialized
DEBUG - 2016-08-30 17:27:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 17:27:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 17:27:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 17:27:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:27:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:27:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:27:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:27:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:27:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:27:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:27:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:27:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:27:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:27:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:27:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:27:04 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 17:27:04 --> Final output sent to browser
DEBUG - 2016-08-30 17:27:04 --> Total execution time: 0.5661
DEBUG - 2016-08-30 17:27:05 --> Config Class Initialized
DEBUG - 2016-08-30 17:27:05 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:27:05 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:27:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:27:05 --> URI Class Initialized
DEBUG - 2016-08-30 17:27:05 --> Router Class Initialized
DEBUG - 2016-08-30 17:27:05 --> Output Class Initialized
DEBUG - 2016-08-30 17:27:05 --> Security Class Initialized
DEBUG - 2016-08-30 17:27:05 --> Input Class Initialized
DEBUG - 2016-08-30 17:27:05 --> XSS Filtering completed
DEBUG - 2016-08-30 17:27:05 --> XSS Filtering completed
DEBUG - 2016-08-30 17:27:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:27:05 --> Language Class Initialized
DEBUG - 2016-08-30 17:27:05 --> Loader Class Initialized
DEBUG - 2016-08-30 17:27:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:27:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:27:05 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:27:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:27:05 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:27:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:27:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:27:05 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:27:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:27:05 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:27:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:27:05 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:27:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:27:05 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:27:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:27:05 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:27:05 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:27:05 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:27:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:27:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:27:05 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:27:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:27:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:27:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:27:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:27:05 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:27:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:27:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:27:05 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:27:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:27:05 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:27:05 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:27:05 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:27:05 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:27:05 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:27:05 --> Session Class Initialized
DEBUG - 2016-08-30 17:27:05 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:27:05 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:27:05 --> Session routines successfully run
DEBUG - 2016-08-30 17:27:05 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:27:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:27:05 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:27:05 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:27:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:27:05 --> Controller Class Initialized
DEBUG - 2016-08-30 17:27:05 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:27:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:27:05 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:27:05 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:27:05 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:27:05 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:27:05 --> Model Class Initialized
DEBUG - 2016-08-30 17:27:05 --> Model Class Initialized
DEBUG - 2016-08-30 17:27:05 --> Model Class Initialized
DEBUG - 2016-08-30 17:27:05 --> Model Class Initialized
DEBUG - 2016-08-30 17:27:05 --> Model Class Initialized
ERROR - 2016-08-30 17:27:06 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;favicon.ico&quot;
LINE 10: WHERE &quot;sc_sidika&quot;.&quot;ref_pegawai&quot;.&quot;id_pegawai&quot; = 'favicon.ico'...
                                                        ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-08-30 17:27:06 --> DB Transaction Failure
ERROR - 2016-08-30 17:27:06 --> Query error: ERROR:  invalid input syntax for integer: "favicon.ico"
LINE 10: WHERE "sc_sidika"."ref_pegawai"."id_pegawai" = 'favicon.ico'...
                                                        ^
DEBUG - 2016-08-30 17:27:06 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-08-30 17:27:24 --> Config Class Initialized
DEBUG - 2016-08-30 17:27:24 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:27:24 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:27:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:27:24 --> URI Class Initialized
DEBUG - 2016-08-30 17:27:24 --> Router Class Initialized
DEBUG - 2016-08-30 17:27:24 --> Output Class Initialized
DEBUG - 2016-08-30 17:27:24 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 17:27:24 --> Security Class Initialized
DEBUG - 2016-08-30 17:27:24 --> Input Class Initialized
DEBUG - 2016-08-30 17:27:24 --> XSS Filtering completed
DEBUG - 2016-08-30 17:27:24 --> XSS Filtering completed
DEBUG - 2016-08-30 17:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:27:24 --> Language Class Initialized
DEBUG - 2016-08-30 17:27:24 --> Loader Class Initialized
DEBUG - 2016-08-30 17:27:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:27:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:27:24 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:27:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:27:24 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:27:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:27:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:27:24 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:27:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:27:24 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:27:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:27:24 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:27:24 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:27:24 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:27:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:27:24 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:27:24 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:27:24 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:27:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:27:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:27:24 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:27:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:27:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:27:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:27:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:27:24 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:27:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:27:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:27:24 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:27:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:27:24 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:27:24 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:27:24 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:27:24 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:27:24 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:27:24 --> Session Class Initialized
DEBUG - 2016-08-30 17:27:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:27:24 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:27:24 --> Session routines successfully run
DEBUG - 2016-08-30 17:27:24 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:27:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:27:24 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:27:24 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:27:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:27:24 --> Controller Class Initialized
DEBUG - 2016-08-30 17:27:24 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:27:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:27:24 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:27:24 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:27:24 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:27:24 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:27:24 --> Model Class Initialized
DEBUG - 2016-08-30 17:27:24 --> Model Class Initialized
DEBUG - 2016-08-30 17:27:24 --> Model Class Initialized
DEBUG - 2016-08-30 17:27:24 --> Model Class Initialized
DEBUG - 2016-08-30 17:27:24 --> Model Class Initialized
DEBUG - 2016-08-30 17:27:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 17:27:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 17:27:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:27:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:27:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:27:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:27:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:27:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:27:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:27:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:27:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:27:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:27:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:27:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:27:25 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 17:27:25 --> Final output sent to browser
DEBUG - 2016-08-30 17:27:25 --> Total execution time: 0.6086
DEBUG - 2016-08-30 17:27:25 --> Config Class Initialized
DEBUG - 2016-08-30 17:27:25 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:27:25 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:27:25 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:27:25 --> URI Class Initialized
DEBUG - 2016-08-30 17:27:25 --> Router Class Initialized
DEBUG - 2016-08-30 17:27:25 --> Output Class Initialized
DEBUG - 2016-08-30 17:27:25 --> Security Class Initialized
DEBUG - 2016-08-30 17:27:25 --> Input Class Initialized
DEBUG - 2016-08-30 17:27:25 --> XSS Filtering completed
DEBUG - 2016-08-30 17:27:25 --> XSS Filtering completed
DEBUG - 2016-08-30 17:27:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:27:25 --> Language Class Initialized
DEBUG - 2016-08-30 17:27:25 --> Loader Class Initialized
DEBUG - 2016-08-30 17:27:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:27:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:27:25 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:27:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:27:25 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:27:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:27:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:27:25 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:27:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:27:25 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:27:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:27:25 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:27:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:27:25 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:27:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:27:25 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:27:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:27:25 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:27:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:27:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:27:25 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:27:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:27:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:27:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:27:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:27:26 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:27:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:27:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:27:26 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:27:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:27:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:27:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:27:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:27:26 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:27:26 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:27:26 --> Session Class Initialized
DEBUG - 2016-08-30 17:27:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:27:26 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:27:26 --> Session routines successfully run
DEBUG - 2016-08-30 17:27:26 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:27:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:27:26 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:27:26 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:27:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:27:26 --> Controller Class Initialized
DEBUG - 2016-08-30 17:27:26 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:27:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:27:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:27:26 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:27:26 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:27:26 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:27:26 --> Model Class Initialized
DEBUG - 2016-08-30 17:27:26 --> Model Class Initialized
DEBUG - 2016-08-30 17:27:26 --> Model Class Initialized
DEBUG - 2016-08-30 17:27:26 --> Model Class Initialized
DEBUG - 2016-08-30 17:27:26 --> Model Class Initialized
ERROR - 2016-08-30 17:27:26 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;favicon.ico&quot;
LINE 10: WHERE &quot;sc_sidika&quot;.&quot;ref_pegawai&quot;.&quot;id_pegawai&quot; = 'favicon.ico'...
                                                        ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-08-30 17:27:26 --> DB Transaction Failure
ERROR - 2016-08-30 17:27:26 --> Query error: ERROR:  invalid input syntax for integer: "favicon.ico"
LINE 10: WHERE "sc_sidika"."ref_pegawai"."id_pegawai" = 'favicon.ico'...
                                                        ^
DEBUG - 2016-08-30 17:27:26 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-08-30 17:28:26 --> Config Class Initialized
DEBUG - 2016-08-30 17:28:26 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:28:26 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:28:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:28:26 --> URI Class Initialized
DEBUG - 2016-08-30 17:28:26 --> Router Class Initialized
DEBUG - 2016-08-30 17:28:26 --> Output Class Initialized
DEBUG - 2016-08-30 17:28:26 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 17:28:26 --> Security Class Initialized
DEBUG - 2016-08-30 17:28:26 --> Input Class Initialized
DEBUG - 2016-08-30 17:28:26 --> XSS Filtering completed
DEBUG - 2016-08-30 17:28:26 --> XSS Filtering completed
DEBUG - 2016-08-30 17:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:28:26 --> Language Class Initialized
DEBUG - 2016-08-30 17:28:26 --> Loader Class Initialized
DEBUG - 2016-08-30 17:28:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:28:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:28:26 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:28:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:28:26 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:28:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:28:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:28:26 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:28:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:28:26 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:28:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:28:26 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:28:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:28:26 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:28:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:28:26 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:28:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:28:26 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:28:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:28:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:28:26 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:28:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:28:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:28:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:28:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:28:26 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:28:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:28:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:28:26 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:28:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:28:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:28:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:28:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:28:26 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:28:26 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:28:26 --> Session Class Initialized
DEBUG - 2016-08-30 17:28:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:28:26 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:28:26 --> Session routines successfully run
DEBUG - 2016-08-30 17:28:26 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:28:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:28:26 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:28:26 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:28:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:28:26 --> Controller Class Initialized
DEBUG - 2016-08-30 17:28:26 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:28:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:28:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:28:26 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:28:26 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:28:26 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:28:26 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:26 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:26 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:26 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:26 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 17:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 17:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:28:26 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 17:28:26 --> Final output sent to browser
DEBUG - 2016-08-30 17:28:26 --> Total execution time: 0.6404
DEBUG - 2016-08-30 17:28:27 --> Config Class Initialized
DEBUG - 2016-08-30 17:28:27 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:28:27 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:28:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:28:27 --> URI Class Initialized
DEBUG - 2016-08-30 17:28:27 --> Router Class Initialized
DEBUG - 2016-08-30 17:28:27 --> Output Class Initialized
DEBUG - 2016-08-30 17:28:27 --> Security Class Initialized
DEBUG - 2016-08-30 17:28:27 --> Input Class Initialized
DEBUG - 2016-08-30 17:28:27 --> XSS Filtering completed
DEBUG - 2016-08-30 17:28:27 --> XSS Filtering completed
DEBUG - 2016-08-30 17:28:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:28:27 --> Language Class Initialized
DEBUG - 2016-08-30 17:28:27 --> Loader Class Initialized
DEBUG - 2016-08-30 17:28:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:28:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:28:27 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:28:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:28:27 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:28:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:28:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:28:27 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:28:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:28:27 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:28:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:28:27 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:28:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:28:27 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:28:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:28:27 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:28:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:28:27 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:28:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:28:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:28:27 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:28:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:28:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:28:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:28:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:28:27 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:28:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:28:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:28:27 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:28:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:28:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:28:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:28:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:28:27 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:28:27 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:28:27 --> Session Class Initialized
DEBUG - 2016-08-30 17:28:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:28:27 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:28:27 --> Session routines successfully run
DEBUG - 2016-08-30 17:28:27 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:28:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:28:27 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:28:27 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:28:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:28:27 --> Controller Class Initialized
DEBUG - 2016-08-30 17:28:27 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:28:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:28:27 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:28:27 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:28:27 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:28:28 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:28:28 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:28 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:28 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:28 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:28 --> Model Class Initialized
ERROR - 2016-08-30 17:28:28 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;favicon.ico&quot;
LINE 10: WHERE &quot;sc_sidika&quot;.&quot;ref_pegawai&quot;.&quot;id_pegawai&quot; = 'favicon.ico'...
                                                        ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-08-30 17:28:28 --> DB Transaction Failure
ERROR - 2016-08-30 17:28:28 --> Query error: ERROR:  invalid input syntax for integer: "favicon.ico"
LINE 10: WHERE "sc_sidika"."ref_pegawai"."id_pegawai" = 'favicon.ico'...
                                                        ^
DEBUG - 2016-08-30 17:28:28 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-08-30 17:28:30 --> Config Class Initialized
DEBUG - 2016-08-30 17:28:30 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:28:30 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:28:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:28:30 --> URI Class Initialized
DEBUG - 2016-08-30 17:28:30 --> Router Class Initialized
DEBUG - 2016-08-30 17:28:30 --> Output Class Initialized
DEBUG - 2016-08-30 17:28:30 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 17:28:30 --> Security Class Initialized
DEBUG - 2016-08-30 17:28:30 --> Input Class Initialized
DEBUG - 2016-08-30 17:28:30 --> XSS Filtering completed
DEBUG - 2016-08-30 17:28:30 --> XSS Filtering completed
DEBUG - 2016-08-30 17:28:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:28:30 --> Language Class Initialized
DEBUG - 2016-08-30 17:28:30 --> Loader Class Initialized
DEBUG - 2016-08-30 17:28:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:28:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:28:30 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:28:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:28:30 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:28:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:28:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:28:30 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:28:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:28:30 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:28:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:28:30 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:28:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:28:30 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:28:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:28:30 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:28:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:28:30 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:28:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:28:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:28:30 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:28:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:28:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:28:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:28:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:28:30 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:28:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:28:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:28:30 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:28:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:28:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:28:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:28:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:28:30 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:28:30 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:28:30 --> Session Class Initialized
DEBUG - 2016-08-30 17:28:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:28:30 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:28:31 --> Session routines successfully run
DEBUG - 2016-08-30 17:28:31 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:28:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:28:31 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:28:31 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:28:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:28:31 --> Controller Class Initialized
DEBUG - 2016-08-30 17:28:31 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:28:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:28:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:28:31 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:28:31 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:28:31 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:28:31 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:31 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:31 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:31 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:31 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:31 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:31 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:31 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:31 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 17:28:31 --> Pagination Class Initialized
DEBUG - 2016-08-30 17:28:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 17:28:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-30 17:28:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:28:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:28:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:28:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:28:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-30 17:28:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:28:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:28:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:28:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:28:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:28:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:28:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-30 17:28:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:28:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:28:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-30 17:28:31 --> Final output sent to browser
DEBUG - 2016-08-30 17:28:31 --> Total execution time: 0.7377
DEBUG - 2016-08-30 17:28:31 --> Config Class Initialized
DEBUG - 2016-08-30 17:28:31 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:28:31 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:28:31 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:28:31 --> URI Class Initialized
DEBUG - 2016-08-30 17:28:31 --> Router Class Initialized
ERROR - 2016-08-30 17:28:31 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-08-30 17:28:32 --> Config Class Initialized
DEBUG - 2016-08-30 17:28:32 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:28:32 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:28:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:28:32 --> URI Class Initialized
DEBUG - 2016-08-30 17:28:32 --> Router Class Initialized
DEBUG - 2016-08-30 17:28:32 --> Output Class Initialized
DEBUG - 2016-08-30 17:28:32 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 17:28:32 --> Security Class Initialized
DEBUG - 2016-08-30 17:28:32 --> Input Class Initialized
DEBUG - 2016-08-30 17:28:32 --> XSS Filtering completed
DEBUG - 2016-08-30 17:28:32 --> XSS Filtering completed
DEBUG - 2016-08-30 17:28:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:28:32 --> Language Class Initialized
DEBUG - 2016-08-30 17:28:32 --> Loader Class Initialized
DEBUG - 2016-08-30 17:28:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:28:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:28:33 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:28:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:28:33 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:28:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:28:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:28:33 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:28:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:28:33 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:28:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:28:33 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:28:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:28:33 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:28:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:28:33 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:28:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:28:33 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:28:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:28:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:28:33 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:28:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:28:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:28:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:28:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:28:33 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:28:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:28:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:28:33 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:28:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:28:33 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:28:33 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:28:33 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:28:33 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:28:33 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:28:33 --> Session Class Initialized
DEBUG - 2016-08-30 17:28:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:28:33 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:28:33 --> Session routines successfully run
DEBUG - 2016-08-30 17:28:33 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:28:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:28:33 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:28:33 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:28:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:28:33 --> Controller Class Initialized
DEBUG - 2016-08-30 17:28:33 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:28:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:28:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:28:33 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:28:33 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:28:33 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:28:33 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:33 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:33 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:33 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:33 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:33 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:33 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:33 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:33 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 17:28:33 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:28:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:28:33 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-08-30 17:28:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 17:28:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-08-30 17:28:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 17:28:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-08-30 17:28:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 17:28:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-08-30 17:28:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 17:28:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-08-30 17:28:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 17:28:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-08-30 17:28:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 17:28:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-08-30 17:28:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 17:28:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-08-30 17:28:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-08-30 17:28:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:28:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:28:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:28:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:28:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-08-30 17:28:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-08-30 17:28:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-08-30 17:28:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-08-30 17:28:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-08-30 17:28:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-08-30 17:28:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:28:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:28:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:28:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:28:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:28:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:28:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-08-30 17:28:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-08-30 17:28:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-08-30 17:28:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-08-30 17:28:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-08-30 17:28:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-08-30 17:28:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:28:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:28:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8f8e2926e3f1cbfc3aa536b43cdd0626
DEBUG - 2016-08-30 17:28:34 --> Final output sent to browser
DEBUG - 2016-08-30 17:28:34 --> Total execution time: 0.8450
DEBUG - 2016-08-30 17:28:34 --> Config Class Initialized
DEBUG - 2016-08-30 17:28:34 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:28:34 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:28:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:28:34 --> URI Class Initialized
DEBUG - 2016-08-30 17:28:34 --> Router Class Initialized
DEBUG - 2016-08-30 17:28:34 --> Output Class Initialized
DEBUG - 2016-08-30 17:28:34 --> Security Class Initialized
DEBUG - 2016-08-30 17:28:34 --> Input Class Initialized
DEBUG - 2016-08-30 17:28:34 --> XSS Filtering completed
DEBUG - 2016-08-30 17:28:34 --> XSS Filtering completed
DEBUG - 2016-08-30 17:28:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:28:34 --> Language Class Initialized
DEBUG - 2016-08-30 17:28:34 --> Loader Class Initialized
DEBUG - 2016-08-30 17:28:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:28:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:28:34 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:28:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:28:34 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:28:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:28:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:28:34 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:28:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:28:34 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:28:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:28:34 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:28:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:28:34 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:28:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:28:34 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:28:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:28:34 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:28:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:28:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:28:34 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:28:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:28:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:28:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:28:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:28:35 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:28:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:28:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:28:35 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:28:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:28:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:28:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:28:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:28:35 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:28:35 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:28:35 --> Session Class Initialized
DEBUG - 2016-08-30 17:28:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:28:35 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:28:35 --> Session routines successfully run
DEBUG - 2016-08-30 17:28:35 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:28:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:28:35 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:28:35 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:28:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:28:35 --> Controller Class Initialized
DEBUG - 2016-08-30 17:28:35 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:28:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:28:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:28:35 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:28:35 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:28:35 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:28:35 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:35 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:35 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:35 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:35 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:35 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:35 --> Model Class Initialized
DEBUG - 2016-08-30 17:28:35 --> Model Class Initialized
ERROR - 2016-08-30 17:28:35 --> 404 Page Not Found --> 
DEBUG - 2016-08-30 17:29:07 --> Config Class Initialized
DEBUG - 2016-08-30 17:29:07 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:29:07 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:29:07 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:29:07 --> URI Class Initialized
DEBUG - 2016-08-30 17:29:07 --> Router Class Initialized
DEBUG - 2016-08-30 17:29:07 --> Output Class Initialized
DEBUG - 2016-08-30 17:29:07 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 17:29:07 --> Security Class Initialized
DEBUG - 2016-08-30 17:29:07 --> Input Class Initialized
DEBUG - 2016-08-30 17:29:07 --> XSS Filtering completed
DEBUG - 2016-08-30 17:29:07 --> XSS Filtering completed
DEBUG - 2016-08-30 17:29:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:29:07 --> Language Class Initialized
DEBUG - 2016-08-30 17:29:07 --> Loader Class Initialized
DEBUG - 2016-08-30 17:29:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:29:07 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:29:07 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:29:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:29:07 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:29:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:29:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:29:07 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:29:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:29:07 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:29:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:29:07 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:29:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:29:07 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:29:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:29:07 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:29:07 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:29:07 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:29:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:29:07 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:29:07 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:29:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:29:07 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:29:07 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:29:07 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:29:07 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:29:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:29:07 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:29:07 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:29:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:29:07 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:29:07 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:29:07 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:29:07 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:29:07 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:29:07 --> Session Class Initialized
DEBUG - 2016-08-30 17:29:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:29:07 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:29:07 --> Session routines successfully run
DEBUG - 2016-08-30 17:29:07 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:29:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:29:07 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:29:07 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:29:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:29:07 --> Controller Class Initialized
DEBUG - 2016-08-30 17:29:07 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:29:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:29:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:29:07 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:29:07 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:29:07 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:29:07 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:07 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:07 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:07 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:07 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:07 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:07 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:07 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:07 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 17:29:07 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:29:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:29:07 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-08-30 17:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 17:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-08-30 17:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 17:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-08-30 17:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 17:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-08-30 17:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 17:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-08-30 17:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 17:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-08-30 17:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 17:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-08-30 17:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 17:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-08-30 17:29:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-08-30 17:29:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:29:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:29:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:29:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:29:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-08-30 17:29:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-08-30 17:29:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-08-30 17:29:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-08-30 17:29:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-08-30 17:29:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-08-30 17:29:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:29:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:29:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:29:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:29:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:29:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:29:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-08-30 17:29:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-08-30 17:29:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-08-30 17:29:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-08-30 17:29:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-08-30 17:29:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-08-30 17:29:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:29:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:29:08 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8f8e2926e3f1cbfc3aa536b43cdd0626
DEBUG - 2016-08-30 17:29:08 --> Final output sent to browser
DEBUG - 2016-08-30 17:29:08 --> Total execution time: 0.8299
DEBUG - 2016-08-30 17:29:51 --> Config Class Initialized
DEBUG - 2016-08-30 17:29:51 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:29:51 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:29:51 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:29:51 --> URI Class Initialized
DEBUG - 2016-08-30 17:29:51 --> Router Class Initialized
DEBUG - 2016-08-30 17:29:51 --> Output Class Initialized
DEBUG - 2016-08-30 17:29:51 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 17:29:51 --> Security Class Initialized
DEBUG - 2016-08-30 17:29:51 --> Input Class Initialized
DEBUG - 2016-08-30 17:29:51 --> XSS Filtering completed
DEBUG - 2016-08-30 17:29:51 --> XSS Filtering completed
DEBUG - 2016-08-30 17:29:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:29:51 --> Language Class Initialized
DEBUG - 2016-08-30 17:29:51 --> Loader Class Initialized
DEBUG - 2016-08-30 17:29:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:29:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:29:51 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:29:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:29:51 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:29:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:29:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:29:51 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:29:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:29:51 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:29:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:29:51 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:29:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:29:51 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:29:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:29:51 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:29:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:29:51 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:29:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:29:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:29:51 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:29:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:29:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:29:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:29:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:29:51 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:29:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:29:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:29:51 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:29:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:29:51 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:29:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:29:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:29:51 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:29:51 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:29:51 --> Session Class Initialized
DEBUG - 2016-08-30 17:29:52 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:29:52 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:29:52 --> Session routines successfully run
DEBUG - 2016-08-30 17:29:52 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:29:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:29:52 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:29:52 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:29:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:29:52 --> Controller Class Initialized
DEBUG - 2016-08-30 17:29:52 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:29:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:29:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:29:52 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:29:52 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:29:52 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:29:52 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:52 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:52 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:52 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:52 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 17:29:52 --> Pagination Class Initialized
DEBUG - 2016-08-30 17:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 17:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/index.php
DEBUG - 2016-08-30 17:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-08-30 17:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-08-30 17:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:29:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:29:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c2a3e0401bd35d4fcac4bae5f9412231
DEBUG - 2016-08-30 17:29:52 --> Final output sent to browser
DEBUG - 2016-08-30 17:29:52 --> Total execution time: 0.7919
DEBUG - 2016-08-30 17:29:53 --> Config Class Initialized
DEBUG - 2016-08-30 17:29:53 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:29:53 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:29:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:29:53 --> URI Class Initialized
DEBUG - 2016-08-30 17:29:53 --> Router Class Initialized
DEBUG - 2016-08-30 17:29:53 --> Output Class Initialized
DEBUG - 2016-08-30 17:29:53 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 17:29:53 --> Security Class Initialized
DEBUG - 2016-08-30 17:29:53 --> Input Class Initialized
DEBUG - 2016-08-30 17:29:53 --> XSS Filtering completed
DEBUG - 2016-08-30 17:29:53 --> XSS Filtering completed
DEBUG - 2016-08-30 17:29:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:29:53 --> Language Class Initialized
DEBUG - 2016-08-30 17:29:53 --> Loader Class Initialized
DEBUG - 2016-08-30 17:29:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:29:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:29:53 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:29:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:29:53 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:29:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:29:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:29:53 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:29:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:29:53 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:29:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:29:53 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:29:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:29:53 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:29:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:29:53 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:29:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:29:53 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:29:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:29:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:29:53 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:29:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:29:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:29:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:29:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:29:54 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:29:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:29:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:29:54 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:29:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:29:54 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:29:54 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:29:54 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:29:54 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:29:54 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:29:54 --> Session Class Initialized
DEBUG - 2016-08-30 17:29:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:29:54 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:29:54 --> Session routines successfully run
DEBUG - 2016-08-30 17:29:54 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:29:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:29:54 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:29:54 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:29:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:29:54 --> Controller Class Initialized
DEBUG - 2016-08-30 17:29:54 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:29:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:29:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:29:54 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:29:54 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:29:54 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:29:54 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:54 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:54 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:54 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:54 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 17:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 17:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:29:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 17:29:54 --> Final output sent to browser
DEBUG - 2016-08-30 17:29:54 --> Total execution time: 0.8086
DEBUG - 2016-08-30 17:29:54 --> Config Class Initialized
DEBUG - 2016-08-30 17:29:54 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:29:54 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:29:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:29:54 --> URI Class Initialized
DEBUG - 2016-08-30 17:29:54 --> Router Class Initialized
DEBUG - 2016-08-30 17:29:54 --> Output Class Initialized
DEBUG - 2016-08-30 17:29:54 --> Security Class Initialized
DEBUG - 2016-08-30 17:29:54 --> Input Class Initialized
DEBUG - 2016-08-30 17:29:54 --> XSS Filtering completed
DEBUG - 2016-08-30 17:29:54 --> XSS Filtering completed
DEBUG - 2016-08-30 17:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:29:54 --> Language Class Initialized
DEBUG - 2016-08-30 17:29:54 --> Loader Class Initialized
DEBUG - 2016-08-30 17:29:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:29:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:29:54 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:29:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:29:54 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:29:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:29:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:29:54 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:29:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:29:55 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:29:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:29:55 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:29:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:29:55 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:29:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:29:55 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:29:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:29:55 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:29:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:29:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:29:55 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:29:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:29:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:29:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:29:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:29:55 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:29:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:29:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:29:55 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:29:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:29:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:29:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:29:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:29:55 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:29:55 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:29:55 --> Session Class Initialized
DEBUG - 2016-08-30 17:29:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:29:55 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:29:55 --> Session routines successfully run
DEBUG - 2016-08-30 17:29:55 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:29:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:29:55 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:29:55 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:29:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:29:55 --> Controller Class Initialized
DEBUG - 2016-08-30 17:29:55 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:29:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:29:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:29:55 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:29:55 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:29:55 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:29:55 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:55 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:55 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:55 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:55 --> Model Class Initialized
ERROR - 2016-08-30 17:29:55 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;favicon.ico&quot;
LINE 10: WHERE &quot;sc_sidika&quot;.&quot;ref_pegawai&quot;.&quot;id_pegawai&quot; = 'favicon.ico'...
                                                        ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-08-30 17:29:55 --> DB Transaction Failure
ERROR - 2016-08-30 17:29:55 --> Query error: ERROR:  invalid input syntax for integer: "favicon.ico"
LINE 10: WHERE "sc_sidika"."ref_pegawai"."id_pegawai" = 'favicon.ico'...
                                                        ^
DEBUG - 2016-08-30 17:29:55 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-08-30 17:29:57 --> Config Class Initialized
DEBUG - 2016-08-30 17:29:57 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:29:57 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:29:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:29:57 --> URI Class Initialized
DEBUG - 2016-08-30 17:29:57 --> Router Class Initialized
DEBUG - 2016-08-30 17:29:57 --> Output Class Initialized
DEBUG - 2016-08-30 17:29:57 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 17:29:57 --> Security Class Initialized
DEBUG - 2016-08-30 17:29:57 --> Input Class Initialized
DEBUG - 2016-08-30 17:29:57 --> XSS Filtering completed
DEBUG - 2016-08-30 17:29:57 --> XSS Filtering completed
DEBUG - 2016-08-30 17:29:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:29:57 --> Language Class Initialized
DEBUG - 2016-08-30 17:29:57 --> Loader Class Initialized
DEBUG - 2016-08-30 17:29:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:29:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:29:57 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:29:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:29:57 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:29:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:29:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:29:57 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:29:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:29:57 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:29:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:29:57 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:29:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:29:57 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:29:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:29:57 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:29:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:29:57 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:29:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:29:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:29:57 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:29:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:29:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:29:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:29:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:29:57 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:29:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:29:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:29:57 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:29:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:29:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:29:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:29:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:29:57 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:29:57 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:29:57 --> Session Class Initialized
DEBUG - 2016-08-30 17:29:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:29:57 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:29:57 --> Session routines successfully run
DEBUG - 2016-08-30 17:29:57 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:29:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:29:57 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:29:57 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:29:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:29:57 --> Controller Class Initialized
DEBUG - 2016-08-30 17:29:57 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:29:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:29:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:29:57 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:29:57 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:29:57 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:29:57 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:57 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:57 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:57 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:57 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 17:29:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 17:29:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:29:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:29:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:29:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:29:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:29:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:29:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:29:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:29:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:29:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:29:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:29:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:29:57 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 17:29:57 --> Final output sent to browser
DEBUG - 2016-08-30 17:29:58 --> Total execution time: 0.8129
DEBUG - 2016-08-30 17:29:58 --> Config Class Initialized
DEBUG - 2016-08-30 17:29:58 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:29:58 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:29:58 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:29:58 --> URI Class Initialized
DEBUG - 2016-08-30 17:29:58 --> Router Class Initialized
DEBUG - 2016-08-30 17:29:58 --> Output Class Initialized
DEBUG - 2016-08-30 17:29:58 --> Security Class Initialized
DEBUG - 2016-08-30 17:29:58 --> Input Class Initialized
DEBUG - 2016-08-30 17:29:58 --> XSS Filtering completed
DEBUG - 2016-08-30 17:29:58 --> XSS Filtering completed
DEBUG - 2016-08-30 17:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:29:58 --> Language Class Initialized
DEBUG - 2016-08-30 17:29:58 --> Loader Class Initialized
DEBUG - 2016-08-30 17:29:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:29:58 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:29:58 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:29:58 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:29:58 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:29:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:29:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:29:58 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:29:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:29:58 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:29:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:29:58 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:29:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:29:58 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:29:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:29:58 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:29:58 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:29:58 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:29:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:29:58 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:29:58 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:29:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:29:58 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:29:58 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:29:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:29:58 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:29:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:29:58 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:29:58 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:29:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:29:58 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:29:58 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:29:58 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:29:58 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:29:58 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:29:59 --> Session Class Initialized
DEBUG - 2016-08-30 17:29:59 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:29:59 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:29:59 --> Session routines successfully run
DEBUG - 2016-08-30 17:29:59 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:29:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:29:59 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:29:59 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:29:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:29:59 --> Controller Class Initialized
DEBUG - 2016-08-30 17:29:59 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:29:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:29:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:29:59 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:29:59 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:29:59 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:29:59 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:59 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:59 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:59 --> Model Class Initialized
DEBUG - 2016-08-30 17:29:59 --> Model Class Initialized
ERROR - 2016-08-30 17:29:59 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;favicon.ico&quot;
LINE 10: WHERE &quot;sc_sidika&quot;.&quot;ref_pegawai&quot;.&quot;id_pegawai&quot; = 'favicon.ico'...
                                                        ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-08-30 17:29:59 --> DB Transaction Failure
ERROR - 2016-08-30 17:29:59 --> Query error: ERROR:  invalid input syntax for integer: "favicon.ico"
LINE 10: WHERE "sc_sidika"."ref_pegawai"."id_pegawai" = 'favicon.ico'...
                                                        ^
DEBUG - 2016-08-30 17:29:59 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-08-30 17:30:30 --> Config Class Initialized
DEBUG - 2016-08-30 17:30:30 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:30:30 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:30:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:30:30 --> URI Class Initialized
DEBUG - 2016-08-30 17:30:30 --> Router Class Initialized
DEBUG - 2016-08-30 17:30:30 --> Output Class Initialized
DEBUG - 2016-08-30 17:30:30 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 17:30:30 --> Security Class Initialized
DEBUG - 2016-08-30 17:30:30 --> Input Class Initialized
DEBUG - 2016-08-30 17:30:30 --> XSS Filtering completed
DEBUG - 2016-08-30 17:30:30 --> XSS Filtering completed
DEBUG - 2016-08-30 17:30:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:30:30 --> Language Class Initialized
DEBUG - 2016-08-30 17:30:30 --> Loader Class Initialized
DEBUG - 2016-08-30 17:30:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:30:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:30:30 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:30:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:30:30 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:30:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:30:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:30:30 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:30:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:30:30 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:30:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:30:30 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:30:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:30:30 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:30:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:30:30 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:30:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:30:30 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:30:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:30:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:30:30 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:30:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:30:31 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:30:31 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:30:31 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:30:31 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:30:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:30:31 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:30:31 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:30:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:30:31 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:30:31 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:30:31 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:30:31 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:30:31 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:30:31 --> Session Class Initialized
DEBUG - 2016-08-30 17:30:31 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:30:31 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:30:31 --> Session routines successfully run
DEBUG - 2016-08-30 17:30:31 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:30:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:30:31 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:30:31 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:30:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:30:31 --> Controller Class Initialized
DEBUG - 2016-08-30 17:30:31 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:30:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:30:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:30:31 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:30:31 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:30:31 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:30:31 --> Model Class Initialized
DEBUG - 2016-08-30 17:30:31 --> Model Class Initialized
DEBUG - 2016-08-30 17:30:31 --> Model Class Initialized
DEBUG - 2016-08-30 17:30:31 --> Model Class Initialized
DEBUG - 2016-08-30 17:30:31 --> Model Class Initialized
DEBUG - 2016-08-30 17:30:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 17:30:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 17:30:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:30:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:30:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:30:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:30:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:30:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:30:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 17:30:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 17:30:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 17:30:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 17:30:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 17:30:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 17:30:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 17:30:31 --> Final output sent to browser
DEBUG - 2016-08-30 17:30:31 --> Total execution time: 0.8712
DEBUG - 2016-08-30 17:30:32 --> Config Class Initialized
DEBUG - 2016-08-30 17:30:32 --> Hooks Class Initialized
DEBUG - 2016-08-30 17:30:32 --> Utf8 Class Initialized
DEBUG - 2016-08-30 17:30:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 17:30:32 --> URI Class Initialized
DEBUG - 2016-08-30 17:30:32 --> Router Class Initialized
DEBUG - 2016-08-30 17:30:32 --> Output Class Initialized
DEBUG - 2016-08-30 17:30:32 --> Security Class Initialized
DEBUG - 2016-08-30 17:30:32 --> Input Class Initialized
DEBUG - 2016-08-30 17:30:32 --> XSS Filtering completed
DEBUG - 2016-08-30 17:30:32 --> XSS Filtering completed
DEBUG - 2016-08-30 17:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 17:30:32 --> Language Class Initialized
DEBUG - 2016-08-30 17:30:32 --> Loader Class Initialized
DEBUG - 2016-08-30 17:30:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 17:30:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 17:30:32 --> Helper loaded: url_helper
DEBUG - 2016-08-30 17:30:32 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 17:30:32 --> Helper loaded: file_helper
DEBUG - 2016-08-30 17:30:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:30:32 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 17:30:32 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 17:30:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 17:30:32 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 17:30:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 17:30:32 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:30:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 17:30:32 --> Helper loaded: common_helper
DEBUG - 2016-08-30 17:30:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 17:30:32 --> Helper loaded: form_helper
DEBUG - 2016-08-30 17:30:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 17:30:32 --> Helper loaded: security_helper
DEBUG - 2016-08-30 17:30:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:30:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 17:30:32 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 17:30:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 17:30:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 17:30:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 17:30:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 17:30:32 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 17:30:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:30:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 17:30:32 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 17:30:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 17:30:32 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 17:30:32 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 17:30:32 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 17:30:32 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 17:30:32 --> Database Driver Class Initialized
DEBUG - 2016-08-30 17:30:32 --> Session Class Initialized
DEBUG - 2016-08-30 17:30:32 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 17:30:32 --> Helper loaded: string_helper
DEBUG - 2016-08-30 17:30:32 --> Session routines successfully run
DEBUG - 2016-08-30 17:30:32 --> Native_session Class Initialized
DEBUG - 2016-08-30 17:30:32 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 17:30:32 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:30:32 --> Form Validation Class Initialized
DEBUG - 2016-08-30 17:30:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 17:30:32 --> Controller Class Initialized
DEBUG - 2016-08-30 17:30:32 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 17:30:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 17:30:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 17:30:32 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:30:32 --> Carabiner: library configured.
DEBUG - 2016-08-30 17:30:32 --> User Agent Class Initialized
DEBUG - 2016-08-30 17:30:32 --> Model Class Initialized
DEBUG - 2016-08-30 17:30:32 --> Model Class Initialized
DEBUG - 2016-08-30 17:30:33 --> Model Class Initialized
DEBUG - 2016-08-30 17:30:33 --> Model Class Initialized
DEBUG - 2016-08-30 17:30:33 --> Model Class Initialized
ERROR - 2016-08-30 17:30:33 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;favicon.ico&quot;
LINE 10: WHERE &quot;sc_sidika&quot;.&quot;ref_pegawai&quot;.&quot;id_pegawai&quot; = 'favicon.ico'...
                                                        ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-08-30 17:30:33 --> DB Transaction Failure
ERROR - 2016-08-30 17:30:33 --> Query error: ERROR:  invalid input syntax for integer: "favicon.ico"
LINE 10: WHERE "sc_sidika"."ref_pegawai"."id_pegawai" = 'favicon.ico'...
                                                        ^
DEBUG - 2016-08-30 17:30:33 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-08-30 18:36:42 --> Config Class Initialized
DEBUG - 2016-08-30 18:36:42 --> Hooks Class Initialized
DEBUG - 2016-08-30 18:36:42 --> Utf8 Class Initialized
DEBUG - 2016-08-30 18:36:42 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 18:36:42 --> URI Class Initialized
DEBUG - 2016-08-30 18:36:42 --> Router Class Initialized
DEBUG - 2016-08-30 18:36:42 --> Output Class Initialized
DEBUG - 2016-08-30 18:36:42 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 18:36:42 --> Security Class Initialized
DEBUG - 2016-08-30 18:36:42 --> Input Class Initialized
DEBUG - 2016-08-30 18:36:42 --> XSS Filtering completed
DEBUG - 2016-08-30 18:36:42 --> XSS Filtering completed
DEBUG - 2016-08-30 18:36:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 18:36:42 --> Language Class Initialized
DEBUG - 2016-08-30 18:36:42 --> Loader Class Initialized
DEBUG - 2016-08-30 18:36:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 18:36:42 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 18:36:42 --> Helper loaded: url_helper
DEBUG - 2016-08-30 18:36:42 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 18:36:42 --> Helper loaded: file_helper
DEBUG - 2016-08-30 18:36:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:36:42 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 18:36:42 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 18:36:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:36:42 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 18:36:42 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 18:36:42 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:36:42 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 18:36:42 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:36:42 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 18:36:42 --> Helper loaded: form_helper
DEBUG - 2016-08-30 18:36:42 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 18:36:42 --> Helper loaded: security_helper
DEBUG - 2016-08-30 18:36:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:36:42 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 18:36:42 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 18:36:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:36:42 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 18:36:42 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 18:36:42 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 18:36:42 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 18:36:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:36:42 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 18:36:42 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 18:36:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:36:42 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 18:36:42 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 18:36:42 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 18:36:42 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 18:36:42 --> Database Driver Class Initialized
DEBUG - 2016-08-30 18:36:43 --> Session Class Initialized
DEBUG - 2016-08-30 18:36:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 18:36:43 --> Helper loaded: string_helper
DEBUG - 2016-08-30 18:36:43 --> Session routines successfully run
DEBUG - 2016-08-30 18:36:43 --> Native_session Class Initialized
DEBUG - 2016-08-30 18:36:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 18:36:43 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:36:43 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:36:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 18:36:43 --> Controller Class Initialized
DEBUG - 2016-08-30 18:36:43 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 18:36:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 18:36:43 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 18:36:43 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:36:43 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:36:43 --> User Agent Class Initialized
DEBUG - 2016-08-30 18:36:43 --> Model Class Initialized
DEBUG - 2016-08-30 18:36:43 --> Model Class Initialized
DEBUG - 2016-08-30 18:36:43 --> Model Class Initialized
DEBUG - 2016-08-30 18:36:43 --> Model Class Initialized
DEBUG - 2016-08-30 18:36:43 --> Model Class Initialized
DEBUG - 2016-08-30 18:36:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 18:36:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 18:36:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 18:36:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 18:36:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 18:36:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 18:36:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 18:36:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 18:36:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 18:36:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 18:36:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 18:36:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 18:36:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 18:36:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 18:36:43 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 18:36:43 --> Final output sent to browser
DEBUG - 2016-08-30 18:36:43 --> Total execution time: 0.8870
DEBUG - 2016-08-30 18:36:44 --> Config Class Initialized
DEBUG - 2016-08-30 18:36:44 --> Hooks Class Initialized
DEBUG - 2016-08-30 18:36:44 --> Utf8 Class Initialized
DEBUG - 2016-08-30 18:36:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 18:36:44 --> URI Class Initialized
DEBUG - 2016-08-30 18:36:44 --> Router Class Initialized
DEBUG - 2016-08-30 18:36:44 --> Output Class Initialized
DEBUG - 2016-08-30 18:36:44 --> Security Class Initialized
DEBUG - 2016-08-30 18:36:44 --> Input Class Initialized
DEBUG - 2016-08-30 18:36:44 --> XSS Filtering completed
DEBUG - 2016-08-30 18:36:44 --> XSS Filtering completed
DEBUG - 2016-08-30 18:36:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 18:36:44 --> Language Class Initialized
DEBUG - 2016-08-30 18:36:44 --> Loader Class Initialized
DEBUG - 2016-08-30 18:36:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 18:36:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 18:36:44 --> Helper loaded: url_helper
DEBUG - 2016-08-30 18:36:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 18:36:44 --> Helper loaded: file_helper
DEBUG - 2016-08-30 18:36:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:36:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 18:36:44 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 18:36:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:36:44 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 18:36:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 18:36:44 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:36:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 18:36:44 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:36:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 18:36:44 --> Helper loaded: form_helper
DEBUG - 2016-08-30 18:36:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 18:36:44 --> Helper loaded: security_helper
DEBUG - 2016-08-30 18:36:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:36:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 18:36:44 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 18:36:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:36:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 18:36:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 18:36:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 18:36:44 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 18:36:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:36:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 18:36:44 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 18:36:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:36:45 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 18:36:45 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 18:36:45 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 18:36:45 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 18:36:45 --> Database Driver Class Initialized
DEBUG - 2016-08-30 18:36:45 --> Session Class Initialized
DEBUG - 2016-08-30 18:36:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 18:36:45 --> Helper loaded: string_helper
DEBUG - 2016-08-30 18:36:45 --> Session routines successfully run
DEBUG - 2016-08-30 18:36:45 --> Native_session Class Initialized
DEBUG - 2016-08-30 18:36:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 18:36:45 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:36:45 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:36:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 18:36:45 --> Controller Class Initialized
DEBUG - 2016-08-30 18:36:45 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 18:36:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 18:36:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 18:36:45 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:36:45 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:36:45 --> User Agent Class Initialized
DEBUG - 2016-08-30 18:36:45 --> Model Class Initialized
DEBUG - 2016-08-30 18:36:45 --> Model Class Initialized
DEBUG - 2016-08-30 18:36:45 --> Model Class Initialized
DEBUG - 2016-08-30 18:36:45 --> Model Class Initialized
DEBUG - 2016-08-30 18:36:45 --> Model Class Initialized
ERROR - 2016-08-30 18:36:45 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;favicon.ico&quot;
LINE 10: WHERE &quot;sc_sidika&quot;.&quot;ref_pegawai&quot;.&quot;id_pegawai&quot; = 'favicon.ico'...
                                                        ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-08-30 18:36:45 --> DB Transaction Failure
ERROR - 2016-08-30 18:36:45 --> Query error: ERROR:  invalid input syntax for integer: "favicon.ico"
LINE 10: WHERE "sc_sidika"."ref_pegawai"."id_pegawai" = 'favicon.ico'...
                                                        ^
DEBUG - 2016-08-30 18:36:45 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-08-30 18:39:15 --> Config Class Initialized
DEBUG - 2016-08-30 18:39:15 --> Hooks Class Initialized
DEBUG - 2016-08-30 18:39:15 --> Utf8 Class Initialized
DEBUG - 2016-08-30 18:39:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 18:39:15 --> URI Class Initialized
DEBUG - 2016-08-30 18:39:15 --> Router Class Initialized
DEBUG - 2016-08-30 18:39:15 --> Output Class Initialized
DEBUG - 2016-08-30 18:39:15 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 18:39:15 --> Security Class Initialized
DEBUG - 2016-08-30 18:39:15 --> Input Class Initialized
DEBUG - 2016-08-30 18:39:15 --> XSS Filtering completed
DEBUG - 2016-08-30 18:39:15 --> XSS Filtering completed
DEBUG - 2016-08-30 18:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 18:39:15 --> Language Class Initialized
DEBUG - 2016-08-30 18:39:15 --> Loader Class Initialized
DEBUG - 2016-08-30 18:39:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 18:39:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 18:39:15 --> Helper loaded: url_helper
DEBUG - 2016-08-30 18:39:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 18:39:15 --> Helper loaded: file_helper
DEBUG - 2016-08-30 18:39:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:39:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 18:39:15 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 18:39:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:39:15 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 18:39:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 18:39:15 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:39:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 18:39:15 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:39:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 18:39:15 --> Helper loaded: form_helper
DEBUG - 2016-08-30 18:39:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 18:39:15 --> Helper loaded: security_helper
DEBUG - 2016-08-30 18:39:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:39:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 18:39:15 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 18:39:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:39:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 18:39:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 18:39:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 18:39:15 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 18:39:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:39:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 18:39:16 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 18:39:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:39:16 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 18:39:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 18:39:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 18:39:16 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 18:39:16 --> Database Driver Class Initialized
DEBUG - 2016-08-30 18:39:16 --> Session Class Initialized
DEBUG - 2016-08-30 18:39:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 18:39:16 --> Helper loaded: string_helper
DEBUG - 2016-08-30 18:39:16 --> Session routines successfully run
DEBUG - 2016-08-30 18:39:16 --> Native_session Class Initialized
DEBUG - 2016-08-30 18:39:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 18:39:16 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:39:16 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:39:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 18:39:16 --> Controller Class Initialized
DEBUG - 2016-08-30 18:39:16 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 18:39:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 18:39:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 18:39:16 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:39:16 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:39:16 --> User Agent Class Initialized
DEBUG - 2016-08-30 18:39:16 --> Model Class Initialized
DEBUG - 2016-08-30 18:39:16 --> Model Class Initialized
DEBUG - 2016-08-30 18:39:16 --> Model Class Initialized
DEBUG - 2016-08-30 18:39:16 --> Model Class Initialized
DEBUG - 2016-08-30 18:39:16 --> Model Class Initialized
DEBUG - 2016-08-30 18:39:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 18:39:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 18:39:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 18:39:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 18:39:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 18:39:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 18:39:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 18:39:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 18:39:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 18:39:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 18:39:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 18:39:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 18:39:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 18:39:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 18:39:16 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 18:39:16 --> Final output sent to browser
DEBUG - 2016-08-30 18:39:16 --> Total execution time: 0.8771
DEBUG - 2016-08-30 18:39:17 --> Config Class Initialized
DEBUG - 2016-08-30 18:39:17 --> Hooks Class Initialized
DEBUG - 2016-08-30 18:39:17 --> Utf8 Class Initialized
DEBUG - 2016-08-30 18:39:17 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 18:39:17 --> URI Class Initialized
DEBUG - 2016-08-30 18:39:17 --> Router Class Initialized
DEBUG - 2016-08-30 18:39:17 --> Output Class Initialized
DEBUG - 2016-08-30 18:39:17 --> Security Class Initialized
DEBUG - 2016-08-30 18:39:17 --> Input Class Initialized
DEBUG - 2016-08-30 18:39:17 --> XSS Filtering completed
DEBUG - 2016-08-30 18:39:17 --> XSS Filtering completed
DEBUG - 2016-08-30 18:39:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 18:39:17 --> Language Class Initialized
DEBUG - 2016-08-30 18:39:17 --> Loader Class Initialized
DEBUG - 2016-08-30 18:39:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 18:39:17 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 18:39:17 --> Helper loaded: url_helper
DEBUG - 2016-08-30 18:39:17 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 18:39:17 --> Helper loaded: file_helper
DEBUG - 2016-08-30 18:39:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:39:17 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 18:39:17 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 18:39:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:39:17 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 18:39:17 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 18:39:17 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:39:17 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 18:39:17 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:39:17 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 18:39:17 --> Helper loaded: form_helper
DEBUG - 2016-08-30 18:39:17 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 18:39:17 --> Helper loaded: security_helper
DEBUG - 2016-08-30 18:39:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:39:17 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 18:39:17 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 18:39:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:39:17 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 18:39:17 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 18:39:17 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 18:39:17 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 18:39:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:39:17 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 18:39:17 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 18:39:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:39:17 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 18:39:17 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 18:39:17 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 18:39:17 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 18:39:17 --> Database Driver Class Initialized
DEBUG - 2016-08-30 18:39:17 --> Session Class Initialized
DEBUG - 2016-08-30 18:39:17 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 18:39:17 --> Helper loaded: string_helper
DEBUG - 2016-08-30 18:39:17 --> Session routines successfully run
DEBUG - 2016-08-30 18:39:17 --> Native_session Class Initialized
DEBUG - 2016-08-30 18:39:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 18:39:17 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:39:17 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:39:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 18:39:17 --> Controller Class Initialized
DEBUG - 2016-08-30 18:39:17 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 18:39:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 18:39:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 18:39:17 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:39:17 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:39:17 --> User Agent Class Initialized
DEBUG - 2016-08-30 18:39:17 --> Model Class Initialized
DEBUG - 2016-08-30 18:39:17 --> Model Class Initialized
DEBUG - 2016-08-30 18:39:18 --> Model Class Initialized
DEBUG - 2016-08-30 18:39:18 --> Model Class Initialized
DEBUG - 2016-08-30 18:39:18 --> Model Class Initialized
ERROR - 2016-08-30 18:39:18 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;favicon.ico&quot;
LINE 10: WHERE &quot;sc_sidika&quot;.&quot;ref_pegawai&quot;.&quot;id_pegawai&quot; = 'favicon.ico'...
                                                        ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-08-30 18:39:18 --> DB Transaction Failure
ERROR - 2016-08-30 18:39:18 --> Query error: ERROR:  invalid input syntax for integer: "favicon.ico"
LINE 10: WHERE "sc_sidika"."ref_pegawai"."id_pegawai" = 'favicon.ico'...
                                                        ^
DEBUG - 2016-08-30 18:39:18 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-08-30 18:39:33 --> Config Class Initialized
DEBUG - 2016-08-30 18:39:33 --> Hooks Class Initialized
DEBUG - 2016-08-30 18:39:33 --> Utf8 Class Initialized
DEBUG - 2016-08-30 18:39:33 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 18:39:33 --> URI Class Initialized
DEBUG - 2016-08-30 18:39:33 --> Router Class Initialized
DEBUG - 2016-08-30 18:39:33 --> Output Class Initialized
DEBUG - 2016-08-30 18:39:33 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 18:39:33 --> Security Class Initialized
DEBUG - 2016-08-30 18:39:33 --> Input Class Initialized
DEBUG - 2016-08-30 18:39:33 --> XSS Filtering completed
DEBUG - 2016-08-30 18:39:33 --> XSS Filtering completed
DEBUG - 2016-08-30 18:39:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 18:39:33 --> Language Class Initialized
DEBUG - 2016-08-30 18:39:33 --> Loader Class Initialized
DEBUG - 2016-08-30 18:39:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 18:39:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 18:39:33 --> Helper loaded: url_helper
DEBUG - 2016-08-30 18:39:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 18:39:33 --> Helper loaded: file_helper
DEBUG - 2016-08-30 18:39:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:39:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 18:39:33 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 18:39:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:39:33 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 18:39:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 18:39:33 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:39:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 18:39:33 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:39:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 18:39:33 --> Helper loaded: form_helper
DEBUG - 2016-08-30 18:39:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 18:39:33 --> Helper loaded: security_helper
DEBUG - 2016-08-30 18:39:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:39:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 18:39:33 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 18:39:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:39:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 18:39:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 18:39:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 18:39:33 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 18:39:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:39:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 18:39:33 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 18:39:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:39:33 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 18:39:33 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 18:39:33 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 18:39:33 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 18:39:33 --> Database Driver Class Initialized
DEBUG - 2016-08-30 18:39:33 --> Session Class Initialized
DEBUG - 2016-08-30 18:39:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 18:39:33 --> Helper loaded: string_helper
DEBUG - 2016-08-30 18:39:33 --> Session routines successfully run
DEBUG - 2016-08-30 18:39:33 --> Native_session Class Initialized
DEBUG - 2016-08-30 18:39:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 18:39:33 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:39:33 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:39:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 18:39:33 --> Controller Class Initialized
DEBUG - 2016-08-30 18:39:33 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 18:39:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 18:39:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 18:39:33 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:39:33 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:39:33 --> User Agent Class Initialized
DEBUG - 2016-08-30 18:39:33 --> Model Class Initialized
DEBUG - 2016-08-30 18:39:33 --> Model Class Initialized
DEBUG - 2016-08-30 18:39:33 --> Model Class Initialized
DEBUG - 2016-08-30 18:39:33 --> Model Class Initialized
DEBUG - 2016-08-30 18:39:33 --> Model Class Initialized
DEBUG - 2016-08-30 18:39:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 18:39:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 18:39:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 18:39:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 18:39:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 18:39:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 18:39:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 18:39:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 18:39:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 18:39:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 18:39:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 18:39:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 18:39:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 18:39:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 18:39:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 18:39:34 --> Final output sent to browser
DEBUG - 2016-08-30 18:39:34 --> Total execution time: 0.9385
DEBUG - 2016-08-30 18:39:34 --> Config Class Initialized
DEBUG - 2016-08-30 18:39:34 --> Hooks Class Initialized
DEBUG - 2016-08-30 18:39:34 --> Utf8 Class Initialized
DEBUG - 2016-08-30 18:39:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 18:39:34 --> URI Class Initialized
DEBUG - 2016-08-30 18:39:34 --> Router Class Initialized
DEBUG - 2016-08-30 18:39:34 --> Output Class Initialized
DEBUG - 2016-08-30 18:39:34 --> Security Class Initialized
DEBUG - 2016-08-30 18:39:34 --> Input Class Initialized
DEBUG - 2016-08-30 18:39:34 --> XSS Filtering completed
DEBUG - 2016-08-30 18:39:34 --> XSS Filtering completed
DEBUG - 2016-08-30 18:39:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 18:39:34 --> Language Class Initialized
DEBUG - 2016-08-30 18:39:34 --> Loader Class Initialized
DEBUG - 2016-08-30 18:39:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 18:39:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 18:39:34 --> Helper loaded: url_helper
DEBUG - 2016-08-30 18:39:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 18:39:34 --> Helper loaded: file_helper
DEBUG - 2016-08-30 18:39:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:39:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 18:39:35 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 18:39:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:39:35 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 18:39:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 18:39:35 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:39:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 18:39:35 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:39:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 18:39:35 --> Helper loaded: form_helper
DEBUG - 2016-08-30 18:39:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 18:39:35 --> Helper loaded: security_helper
DEBUG - 2016-08-30 18:39:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:39:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 18:39:35 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 18:39:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:39:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 18:39:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 18:39:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 18:39:35 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 18:39:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:39:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 18:39:35 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 18:39:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:39:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 18:39:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 18:39:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 18:39:35 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 18:39:35 --> Database Driver Class Initialized
DEBUG - 2016-08-30 18:39:35 --> Session Class Initialized
DEBUG - 2016-08-30 18:39:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 18:39:35 --> Helper loaded: string_helper
DEBUG - 2016-08-30 18:39:35 --> Session routines successfully run
DEBUG - 2016-08-30 18:39:35 --> Native_session Class Initialized
DEBUG - 2016-08-30 18:39:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 18:39:35 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:39:35 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:39:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 18:39:35 --> Controller Class Initialized
DEBUG - 2016-08-30 18:39:35 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 18:39:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 18:39:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 18:39:35 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:39:35 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:39:35 --> User Agent Class Initialized
DEBUG - 2016-08-30 18:39:35 --> Model Class Initialized
DEBUG - 2016-08-30 18:39:35 --> Model Class Initialized
DEBUG - 2016-08-30 18:39:35 --> Model Class Initialized
DEBUG - 2016-08-30 18:39:35 --> Model Class Initialized
DEBUG - 2016-08-30 18:39:35 --> Model Class Initialized
ERROR - 2016-08-30 18:39:35 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;favicon.ico&quot;
LINE 10: WHERE &quot;sc_sidika&quot;.&quot;ref_pegawai&quot;.&quot;id_pegawai&quot; = 'favicon.ico'...
                                                        ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-08-30 18:39:35 --> DB Transaction Failure
ERROR - 2016-08-30 18:39:35 --> Query error: ERROR:  invalid input syntax for integer: "favicon.ico"
LINE 10: WHERE "sc_sidika"."ref_pegawai"."id_pegawai" = 'favicon.ico'...
                                                        ^
DEBUG - 2016-08-30 18:39:35 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-08-30 18:40:06 --> Config Class Initialized
DEBUG - 2016-08-30 18:40:06 --> Hooks Class Initialized
DEBUG - 2016-08-30 18:40:06 --> Utf8 Class Initialized
DEBUG - 2016-08-30 18:40:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 18:40:06 --> URI Class Initialized
DEBUG - 2016-08-30 18:40:06 --> Router Class Initialized
DEBUG - 2016-08-30 18:40:06 --> Output Class Initialized
DEBUG - 2016-08-30 18:40:06 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 18:40:06 --> Security Class Initialized
DEBUG - 2016-08-30 18:40:06 --> Input Class Initialized
DEBUG - 2016-08-30 18:40:06 --> XSS Filtering completed
DEBUG - 2016-08-30 18:40:06 --> XSS Filtering completed
DEBUG - 2016-08-30 18:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 18:40:06 --> Language Class Initialized
DEBUG - 2016-08-30 18:40:06 --> Loader Class Initialized
DEBUG - 2016-08-30 18:40:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 18:40:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 18:40:06 --> Helper loaded: url_helper
DEBUG - 2016-08-30 18:40:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 18:40:06 --> Helper loaded: file_helper
DEBUG - 2016-08-30 18:40:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:40:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 18:40:06 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 18:40:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:40:06 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 18:40:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 18:40:06 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:40:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 18:40:06 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:40:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 18:40:06 --> Helper loaded: form_helper
DEBUG - 2016-08-30 18:40:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 18:40:06 --> Helper loaded: security_helper
DEBUG - 2016-08-30 18:40:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:40:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 18:40:06 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 18:40:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:40:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 18:40:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 18:40:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 18:40:06 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 18:40:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:40:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 18:40:06 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 18:40:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:40:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 18:40:07 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 18:40:07 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 18:40:07 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 18:40:07 --> Database Driver Class Initialized
DEBUG - 2016-08-30 18:40:07 --> Session Class Initialized
DEBUG - 2016-08-30 18:40:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 18:40:07 --> Helper loaded: string_helper
DEBUG - 2016-08-30 18:40:07 --> Session routines successfully run
DEBUG - 2016-08-30 18:40:07 --> Native_session Class Initialized
DEBUG - 2016-08-30 18:40:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 18:40:07 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:40:07 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:40:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 18:40:07 --> Controller Class Initialized
DEBUG - 2016-08-30 18:40:07 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 18:40:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 18:40:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 18:40:07 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:40:07 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:40:07 --> User Agent Class Initialized
DEBUG - 2016-08-30 18:40:07 --> Model Class Initialized
DEBUG - 2016-08-30 18:40:07 --> Model Class Initialized
DEBUG - 2016-08-30 18:40:07 --> Model Class Initialized
DEBUG - 2016-08-30 18:40:07 --> Model Class Initialized
DEBUG - 2016-08-30 18:40:07 --> Model Class Initialized
DEBUG - 2016-08-30 18:40:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 18:40:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 18:40:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 18:40:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 18:40:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 18:40:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 18:40:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 18:40:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 18:40:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 18:40:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 18:40:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 18:40:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 18:40:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 18:40:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 18:40:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 18:40:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 18:40:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 18:40:07 --> Final output sent to browser
DEBUG - 2016-08-30 18:40:07 --> Total execution time: 0.9384
DEBUG - 2016-08-30 18:40:09 --> Config Class Initialized
DEBUG - 2016-08-30 18:40:09 --> Hooks Class Initialized
DEBUG - 2016-08-30 18:40:09 --> Utf8 Class Initialized
DEBUG - 2016-08-30 18:40:09 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 18:40:09 --> URI Class Initialized
DEBUG - 2016-08-30 18:40:09 --> Router Class Initialized
DEBUG - 2016-08-30 18:40:09 --> Output Class Initialized
DEBUG - 2016-08-30 18:40:09 --> Security Class Initialized
DEBUG - 2016-08-30 18:40:09 --> Input Class Initialized
DEBUG - 2016-08-30 18:40:09 --> XSS Filtering completed
DEBUG - 2016-08-30 18:40:09 --> XSS Filtering completed
DEBUG - 2016-08-30 18:40:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 18:40:09 --> Language Class Initialized
DEBUG - 2016-08-30 18:40:09 --> Loader Class Initialized
DEBUG - 2016-08-30 18:40:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 18:40:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 18:40:09 --> Helper loaded: url_helper
DEBUG - 2016-08-30 18:40:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 18:40:09 --> Helper loaded: file_helper
DEBUG - 2016-08-30 18:40:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:40:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 18:40:09 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 18:40:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:40:09 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 18:40:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 18:40:09 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:40:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 18:40:09 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:40:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 18:40:09 --> Helper loaded: form_helper
DEBUG - 2016-08-30 18:40:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 18:40:09 --> Helper loaded: security_helper
DEBUG - 2016-08-30 18:40:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:40:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 18:40:09 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 18:40:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:40:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 18:40:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 18:40:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 18:40:09 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 18:40:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:40:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 18:40:09 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 18:40:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:40:09 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 18:40:09 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 18:40:09 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 18:40:09 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 18:40:10 --> Database Driver Class Initialized
DEBUG - 2016-08-30 18:40:10 --> Session Class Initialized
DEBUG - 2016-08-30 18:40:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 18:40:10 --> Helper loaded: string_helper
DEBUG - 2016-08-30 18:40:10 --> Session routines successfully run
DEBUG - 2016-08-30 18:40:10 --> Native_session Class Initialized
DEBUG - 2016-08-30 18:40:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 18:40:10 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:40:10 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:40:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 18:40:10 --> Controller Class Initialized
DEBUG - 2016-08-30 18:40:10 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 18:40:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 18:40:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 18:40:10 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:40:10 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:40:10 --> User Agent Class Initialized
DEBUG - 2016-08-30 18:40:10 --> Model Class Initialized
DEBUG - 2016-08-30 18:40:10 --> Model Class Initialized
DEBUG - 2016-08-30 18:40:10 --> Model Class Initialized
DEBUG - 2016-08-30 18:40:10 --> Model Class Initialized
DEBUG - 2016-08-30 18:40:10 --> Model Class Initialized
ERROR - 2016-08-30 18:40:10 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;favicon.ico&quot;
LINE 10: WHERE &quot;sc_sidika&quot;.&quot;ref_pegawai&quot;.&quot;id_pegawai&quot; = 'favicon.ico'...
                                                        ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-08-30 18:40:10 --> DB Transaction Failure
ERROR - 2016-08-30 18:40:10 --> Query error: ERROR:  invalid input syntax for integer: "favicon.ico"
LINE 10: WHERE "sc_sidika"."ref_pegawai"."id_pegawai" = 'favicon.ico'...
                                                        ^
DEBUG - 2016-08-30 18:40:10 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-08-30 18:40:18 --> Config Class Initialized
DEBUG - 2016-08-30 18:40:18 --> Hooks Class Initialized
DEBUG - 2016-08-30 18:40:18 --> Utf8 Class Initialized
DEBUG - 2016-08-30 18:40:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 18:40:18 --> URI Class Initialized
DEBUG - 2016-08-30 18:40:18 --> Router Class Initialized
DEBUG - 2016-08-30 18:40:18 --> Output Class Initialized
DEBUG - 2016-08-30 18:40:18 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 18:40:18 --> Security Class Initialized
DEBUG - 2016-08-30 18:40:18 --> Input Class Initialized
DEBUG - 2016-08-30 18:40:18 --> XSS Filtering completed
DEBUG - 2016-08-30 18:40:18 --> XSS Filtering completed
DEBUG - 2016-08-30 18:40:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 18:40:18 --> Language Class Initialized
DEBUG - 2016-08-30 18:40:18 --> Loader Class Initialized
DEBUG - 2016-08-30 18:40:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 18:40:18 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 18:40:18 --> Helper loaded: url_helper
DEBUG - 2016-08-30 18:40:18 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 18:40:18 --> Helper loaded: file_helper
DEBUG - 2016-08-30 18:40:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:40:18 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 18:40:18 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 18:40:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:40:18 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 18:40:18 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 18:40:18 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:40:18 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 18:40:18 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:40:18 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 18:40:18 --> Helper loaded: form_helper
DEBUG - 2016-08-30 18:40:18 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 18:40:18 --> Helper loaded: security_helper
DEBUG - 2016-08-30 18:40:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:40:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 18:40:18 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 18:40:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:40:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 18:40:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 18:40:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 18:40:18 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 18:40:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:40:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 18:40:19 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 18:40:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:40:19 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 18:40:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 18:40:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 18:40:19 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 18:40:19 --> Database Driver Class Initialized
DEBUG - 2016-08-30 18:40:19 --> Session Class Initialized
DEBUG - 2016-08-30 18:40:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 18:40:19 --> Helper loaded: string_helper
DEBUG - 2016-08-30 18:40:19 --> Session routines successfully run
DEBUG - 2016-08-30 18:40:19 --> Native_session Class Initialized
DEBUG - 2016-08-30 18:40:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 18:40:19 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:40:19 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:40:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 18:40:19 --> Controller Class Initialized
DEBUG - 2016-08-30 18:40:19 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 18:40:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 18:40:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 18:40:19 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:40:19 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:40:19 --> User Agent Class Initialized
DEBUG - 2016-08-30 18:40:19 --> Model Class Initialized
DEBUG - 2016-08-30 18:40:19 --> Model Class Initialized
DEBUG - 2016-08-30 18:40:19 --> Model Class Initialized
DEBUG - 2016-08-30 18:40:19 --> Model Class Initialized
DEBUG - 2016-08-30 18:40:19 --> Model Class Initialized
DEBUG - 2016-08-30 18:40:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 18:40:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 18:40:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 18:40:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 18:40:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 18:40:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 18:40:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 18:40:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 18:40:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 18:40:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 18:40:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 18:40:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 18:40:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 18:40:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 18:40:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 18:40:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 18:40:19 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 18:40:19 --> Final output sent to browser
DEBUG - 2016-08-30 18:40:19 --> Total execution time: 0.9750
DEBUG - 2016-08-30 18:40:20 --> Config Class Initialized
DEBUG - 2016-08-30 18:40:20 --> Hooks Class Initialized
DEBUG - 2016-08-30 18:40:20 --> Utf8 Class Initialized
DEBUG - 2016-08-30 18:40:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 18:40:20 --> URI Class Initialized
DEBUG - 2016-08-30 18:40:20 --> Router Class Initialized
DEBUG - 2016-08-30 18:40:20 --> Output Class Initialized
DEBUG - 2016-08-30 18:40:20 --> Security Class Initialized
DEBUG - 2016-08-30 18:40:20 --> Input Class Initialized
DEBUG - 2016-08-30 18:40:20 --> XSS Filtering completed
DEBUG - 2016-08-30 18:40:20 --> XSS Filtering completed
DEBUG - 2016-08-30 18:40:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 18:40:20 --> Language Class Initialized
DEBUG - 2016-08-30 18:40:20 --> Loader Class Initialized
DEBUG - 2016-08-30 18:40:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 18:40:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 18:40:20 --> Helper loaded: url_helper
DEBUG - 2016-08-30 18:40:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 18:40:20 --> Helper loaded: file_helper
DEBUG - 2016-08-30 18:40:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:40:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 18:40:20 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 18:40:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:40:20 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 18:40:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 18:40:20 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:40:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 18:40:20 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:40:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 18:40:20 --> Helper loaded: form_helper
DEBUG - 2016-08-30 18:40:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 18:40:20 --> Helper loaded: security_helper
DEBUG - 2016-08-30 18:40:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:40:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 18:40:20 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 18:40:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:40:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 18:40:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 18:40:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 18:40:20 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 18:40:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:40:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 18:40:20 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 18:40:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:40:20 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 18:40:20 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 18:40:20 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 18:40:20 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 18:40:20 --> Database Driver Class Initialized
DEBUG - 2016-08-30 18:40:20 --> Session Class Initialized
DEBUG - 2016-08-30 18:40:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 18:40:20 --> Helper loaded: string_helper
DEBUG - 2016-08-30 18:40:20 --> Session routines successfully run
DEBUG - 2016-08-30 18:40:20 --> Native_session Class Initialized
DEBUG - 2016-08-30 18:40:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 18:40:20 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:40:20 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:40:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 18:40:20 --> Controller Class Initialized
DEBUG - 2016-08-30 18:40:20 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 18:40:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 18:40:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 18:40:20 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:40:20 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:40:20 --> User Agent Class Initialized
DEBUG - 2016-08-30 18:40:20 --> Model Class Initialized
DEBUG - 2016-08-30 18:40:20 --> Model Class Initialized
DEBUG - 2016-08-30 18:40:20 --> Model Class Initialized
DEBUG - 2016-08-30 18:40:21 --> Model Class Initialized
DEBUG - 2016-08-30 18:40:21 --> Model Class Initialized
ERROR - 2016-08-30 18:40:21 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;favicon.ico&quot;
LINE 10: WHERE &quot;sc_sidika&quot;.&quot;ref_pegawai&quot;.&quot;id_pegawai&quot; = 'favicon.ico'...
                                                        ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-08-30 18:40:21 --> DB Transaction Failure
ERROR - 2016-08-30 18:40:21 --> Query error: ERROR:  invalid input syntax for integer: "favicon.ico"
LINE 10: WHERE "sc_sidika"."ref_pegawai"."id_pegawai" = 'favicon.ico'...
                                                        ^
DEBUG - 2016-08-30 18:40:21 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-08-30 18:42:12 --> Config Class Initialized
DEBUG - 2016-08-30 18:42:12 --> Hooks Class Initialized
DEBUG - 2016-08-30 18:42:12 --> Utf8 Class Initialized
DEBUG - 2016-08-30 18:42:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 18:42:12 --> URI Class Initialized
DEBUG - 2016-08-30 18:42:12 --> Router Class Initialized
DEBUG - 2016-08-30 18:42:13 --> Output Class Initialized
DEBUG - 2016-08-30 18:42:13 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 18:42:13 --> Security Class Initialized
DEBUG - 2016-08-30 18:42:13 --> Input Class Initialized
DEBUG - 2016-08-30 18:42:13 --> XSS Filtering completed
DEBUG - 2016-08-30 18:42:13 --> XSS Filtering completed
DEBUG - 2016-08-30 18:42:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 18:42:13 --> Language Class Initialized
DEBUG - 2016-08-30 18:42:13 --> Loader Class Initialized
DEBUG - 2016-08-30 18:42:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 18:42:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 18:42:13 --> Helper loaded: url_helper
DEBUG - 2016-08-30 18:42:13 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 18:42:13 --> Helper loaded: file_helper
DEBUG - 2016-08-30 18:42:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:42:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 18:42:13 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 18:42:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:42:13 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 18:42:13 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 18:42:13 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:42:13 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 18:42:13 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:42:13 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 18:42:13 --> Helper loaded: form_helper
DEBUG - 2016-08-30 18:42:13 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 18:42:13 --> Helper loaded: security_helper
DEBUG - 2016-08-30 18:42:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:42:13 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 18:42:13 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 18:42:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:42:13 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 18:42:13 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 18:42:13 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 18:42:13 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 18:42:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:42:13 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 18:42:13 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 18:42:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:42:13 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 18:42:13 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 18:42:13 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 18:42:13 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 18:42:13 --> Database Driver Class Initialized
DEBUG - 2016-08-30 18:42:13 --> Session Class Initialized
DEBUG - 2016-08-30 18:42:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 18:42:13 --> Helper loaded: string_helper
DEBUG - 2016-08-30 18:42:13 --> Session routines successfully run
DEBUG - 2016-08-30 18:42:13 --> Native_session Class Initialized
DEBUG - 2016-08-30 18:42:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 18:42:13 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:42:13 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:42:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 18:42:13 --> Controller Class Initialized
DEBUG - 2016-08-30 18:42:13 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 18:42:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 18:42:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 18:42:13 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:42:13 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:42:13 --> User Agent Class Initialized
DEBUG - 2016-08-30 18:42:13 --> Model Class Initialized
DEBUG - 2016-08-30 18:42:13 --> Model Class Initialized
DEBUG - 2016-08-30 18:42:13 --> Model Class Initialized
DEBUG - 2016-08-30 18:42:13 --> Model Class Initialized
DEBUG - 2016-08-30 18:42:13 --> Model Class Initialized
DEBUG - 2016-08-30 18:42:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 18:42:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 18:42:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 18:42:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 18:42:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 18:42:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 18:42:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 18:42:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 18:42:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 18:42:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 18:42:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 18:42:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 18:42:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 18:42:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 18:42:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 18:42:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 18:42:14 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 18:42:14 --> Final output sent to browser
DEBUG - 2016-08-30 18:42:14 --> Total execution time: 1.0171
DEBUG - 2016-08-30 18:42:15 --> Config Class Initialized
DEBUG - 2016-08-30 18:42:15 --> Hooks Class Initialized
DEBUG - 2016-08-30 18:42:15 --> Utf8 Class Initialized
DEBUG - 2016-08-30 18:42:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 18:42:15 --> URI Class Initialized
DEBUG - 2016-08-30 18:42:15 --> Router Class Initialized
DEBUG - 2016-08-30 18:42:15 --> Output Class Initialized
DEBUG - 2016-08-30 18:42:15 --> Security Class Initialized
DEBUG - 2016-08-30 18:42:15 --> Input Class Initialized
DEBUG - 2016-08-30 18:42:15 --> XSS Filtering completed
DEBUG - 2016-08-30 18:42:15 --> XSS Filtering completed
DEBUG - 2016-08-30 18:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 18:42:15 --> Language Class Initialized
DEBUG - 2016-08-30 18:42:15 --> Loader Class Initialized
DEBUG - 2016-08-30 18:42:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 18:42:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 18:42:15 --> Helper loaded: url_helper
DEBUG - 2016-08-30 18:42:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 18:42:15 --> Helper loaded: file_helper
DEBUG - 2016-08-30 18:42:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:42:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 18:42:15 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 18:42:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:42:15 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 18:42:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 18:42:15 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:42:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 18:42:15 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:42:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 18:42:15 --> Helper loaded: form_helper
DEBUG - 2016-08-30 18:42:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 18:42:15 --> Helper loaded: security_helper
DEBUG - 2016-08-30 18:42:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:42:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 18:42:15 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 18:42:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:42:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 18:42:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 18:42:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 18:42:15 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 18:42:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:42:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 18:42:15 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 18:42:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:42:15 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 18:42:15 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 18:42:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 18:42:16 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 18:42:16 --> Database Driver Class Initialized
DEBUG - 2016-08-30 18:42:16 --> Session Class Initialized
DEBUG - 2016-08-30 18:42:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 18:42:16 --> Helper loaded: string_helper
DEBUG - 2016-08-30 18:42:16 --> Session routines successfully run
DEBUG - 2016-08-30 18:42:16 --> Native_session Class Initialized
DEBUG - 2016-08-30 18:42:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 18:42:16 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:42:16 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:42:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 18:42:16 --> Controller Class Initialized
DEBUG - 2016-08-30 18:42:16 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 18:42:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 18:42:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 18:42:16 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:42:16 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:42:16 --> User Agent Class Initialized
DEBUG - 2016-08-30 18:42:16 --> Model Class Initialized
DEBUG - 2016-08-30 18:42:16 --> Model Class Initialized
DEBUG - 2016-08-30 18:42:16 --> Model Class Initialized
DEBUG - 2016-08-30 18:42:16 --> Model Class Initialized
DEBUG - 2016-08-30 18:42:16 --> Model Class Initialized
ERROR - 2016-08-30 18:42:16 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;favicon.ico&quot;
LINE 10: WHERE &quot;sc_sidika&quot;.&quot;ref_pegawai&quot;.&quot;id_pegawai&quot; = 'favicon.ico'...
                                                        ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-08-30 18:42:16 --> DB Transaction Failure
ERROR - 2016-08-30 18:42:16 --> Query error: ERROR:  invalid input syntax for integer: "favicon.ico"
LINE 10: WHERE "sc_sidika"."ref_pegawai"."id_pegawai" = 'favicon.ico'...
                                                        ^
DEBUG - 2016-08-30 18:42:16 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-08-30 18:44:13 --> Config Class Initialized
DEBUG - 2016-08-30 18:44:13 --> Hooks Class Initialized
DEBUG - 2016-08-30 18:44:13 --> Utf8 Class Initialized
DEBUG - 2016-08-30 18:44:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 18:44:13 --> URI Class Initialized
DEBUG - 2016-08-30 18:44:13 --> Router Class Initialized
DEBUG - 2016-08-30 18:44:13 --> Output Class Initialized
DEBUG - 2016-08-30 18:44:13 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 18:44:13 --> Security Class Initialized
DEBUG - 2016-08-30 18:44:13 --> Input Class Initialized
DEBUG - 2016-08-30 18:44:13 --> XSS Filtering completed
DEBUG - 2016-08-30 18:44:13 --> XSS Filtering completed
DEBUG - 2016-08-30 18:44:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 18:44:13 --> Language Class Initialized
DEBUG - 2016-08-30 18:44:13 --> Loader Class Initialized
DEBUG - 2016-08-30 18:44:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 18:44:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 18:44:13 --> Helper loaded: url_helper
DEBUG - 2016-08-30 18:44:13 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 18:44:13 --> Helper loaded: file_helper
DEBUG - 2016-08-30 18:44:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:44:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 18:44:13 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 18:44:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:44:13 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 18:44:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 18:44:14 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:44:14 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 18:44:14 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:44:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 18:44:14 --> Helper loaded: form_helper
DEBUG - 2016-08-30 18:44:14 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 18:44:14 --> Helper loaded: security_helper
DEBUG - 2016-08-30 18:44:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:44:14 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 18:44:14 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 18:44:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:44:14 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 18:44:14 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 18:44:14 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 18:44:14 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 18:44:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:44:14 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 18:44:14 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 18:44:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:44:14 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 18:44:14 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 18:44:14 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 18:44:14 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 18:44:14 --> Database Driver Class Initialized
DEBUG - 2016-08-30 18:44:14 --> Session Class Initialized
DEBUG - 2016-08-30 18:44:14 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 18:44:14 --> Helper loaded: string_helper
DEBUG - 2016-08-30 18:44:14 --> Session routines successfully run
DEBUG - 2016-08-30 18:44:14 --> Native_session Class Initialized
DEBUG - 2016-08-30 18:44:14 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 18:44:14 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:44:14 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:44:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 18:44:14 --> Controller Class Initialized
DEBUG - 2016-08-30 18:44:14 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 18:44:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 18:44:14 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 18:44:14 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:44:14 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:44:14 --> User Agent Class Initialized
DEBUG - 2016-08-30 18:44:14 --> Model Class Initialized
DEBUG - 2016-08-30 18:44:14 --> Model Class Initialized
DEBUG - 2016-08-30 18:44:14 --> Model Class Initialized
DEBUG - 2016-08-30 18:44:14 --> Model Class Initialized
DEBUG - 2016-08-30 18:44:14 --> Model Class Initialized
DEBUG - 2016-08-30 18:44:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 18:44:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 18:44:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 18:44:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 18:44:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 18:44:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 18:44:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 18:44:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 18:44:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 18:44:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 18:44:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 18:44:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 18:44:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 18:44:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 18:44:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 18:44:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 18:44:14 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 18:44:14 --> Final output sent to browser
DEBUG - 2016-08-30 18:44:14 --> Total execution time: 1.0355
DEBUG - 2016-08-30 18:44:15 --> Config Class Initialized
DEBUG - 2016-08-30 18:44:15 --> Hooks Class Initialized
DEBUG - 2016-08-30 18:44:15 --> Utf8 Class Initialized
DEBUG - 2016-08-30 18:44:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 18:44:15 --> URI Class Initialized
DEBUG - 2016-08-30 18:44:15 --> Router Class Initialized
DEBUG - 2016-08-30 18:44:15 --> Output Class Initialized
DEBUG - 2016-08-30 18:44:15 --> Security Class Initialized
DEBUG - 2016-08-30 18:44:15 --> Input Class Initialized
DEBUG - 2016-08-30 18:44:15 --> XSS Filtering completed
DEBUG - 2016-08-30 18:44:15 --> XSS Filtering completed
DEBUG - 2016-08-30 18:44:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 18:44:15 --> Language Class Initialized
DEBUG - 2016-08-30 18:44:15 --> Loader Class Initialized
DEBUG - 2016-08-30 18:44:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 18:44:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 18:44:16 --> Helper loaded: url_helper
DEBUG - 2016-08-30 18:44:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 18:44:16 --> Helper loaded: file_helper
DEBUG - 2016-08-30 18:44:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:44:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 18:44:16 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 18:44:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:44:16 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 18:44:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 18:44:16 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:44:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 18:44:16 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:44:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 18:44:16 --> Helper loaded: form_helper
DEBUG - 2016-08-30 18:44:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 18:44:16 --> Helper loaded: security_helper
DEBUG - 2016-08-30 18:44:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:44:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 18:44:16 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 18:44:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:44:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 18:44:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 18:44:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 18:44:16 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 18:44:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:44:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 18:44:16 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 18:44:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:44:16 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 18:44:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 18:44:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 18:44:16 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 18:44:16 --> Database Driver Class Initialized
DEBUG - 2016-08-30 18:44:16 --> Session Class Initialized
DEBUG - 2016-08-30 18:44:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 18:44:16 --> Helper loaded: string_helper
DEBUG - 2016-08-30 18:44:16 --> Session routines successfully run
DEBUG - 2016-08-30 18:44:16 --> Native_session Class Initialized
DEBUG - 2016-08-30 18:44:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 18:44:16 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:44:16 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:44:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 18:44:16 --> Controller Class Initialized
DEBUG - 2016-08-30 18:44:16 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 18:44:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 18:44:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 18:44:16 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:44:16 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:44:16 --> User Agent Class Initialized
DEBUG - 2016-08-30 18:44:16 --> Model Class Initialized
DEBUG - 2016-08-30 18:44:16 --> Model Class Initialized
DEBUG - 2016-08-30 18:44:16 --> Model Class Initialized
DEBUG - 2016-08-30 18:44:16 --> Model Class Initialized
DEBUG - 2016-08-30 18:44:16 --> Model Class Initialized
ERROR - 2016-08-30 18:44:16 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;favicon.ico&quot;
LINE 10: WHERE &quot;sc_sidika&quot;.&quot;ref_pegawai&quot;.&quot;id_pegawai&quot; = 'favicon.ico'...
                                                        ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-08-30 18:44:16 --> DB Transaction Failure
ERROR - 2016-08-30 18:44:16 --> Query error: ERROR:  invalid input syntax for integer: "favicon.ico"
LINE 10: WHERE "sc_sidika"."ref_pegawai"."id_pegawai" = 'favicon.ico'...
                                                        ^
DEBUG - 2016-08-30 18:44:16 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-08-30 18:46:35 --> Config Class Initialized
DEBUG - 2016-08-30 18:46:35 --> Hooks Class Initialized
DEBUG - 2016-08-30 18:46:35 --> Utf8 Class Initialized
DEBUG - 2016-08-30 18:46:35 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 18:46:35 --> URI Class Initialized
DEBUG - 2016-08-30 18:46:35 --> Router Class Initialized
DEBUG - 2016-08-30 18:46:35 --> Output Class Initialized
DEBUG - 2016-08-30 18:46:35 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 18:46:35 --> Security Class Initialized
DEBUG - 2016-08-30 18:46:35 --> Input Class Initialized
DEBUG - 2016-08-30 18:46:35 --> XSS Filtering completed
DEBUG - 2016-08-30 18:46:35 --> XSS Filtering completed
DEBUG - 2016-08-30 18:46:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 18:46:36 --> Language Class Initialized
DEBUG - 2016-08-30 18:46:36 --> Loader Class Initialized
DEBUG - 2016-08-30 18:46:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 18:46:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 18:46:36 --> Helper loaded: url_helper
DEBUG - 2016-08-30 18:46:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 18:46:36 --> Helper loaded: file_helper
DEBUG - 2016-08-30 18:46:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:46:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 18:46:36 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 18:46:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:46:36 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 18:46:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 18:46:36 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:46:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 18:46:36 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:46:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 18:46:36 --> Helper loaded: form_helper
DEBUG - 2016-08-30 18:46:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 18:46:36 --> Helper loaded: security_helper
DEBUG - 2016-08-30 18:46:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:46:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 18:46:36 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 18:46:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:46:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 18:46:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 18:46:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 18:46:36 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 18:46:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:46:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 18:46:36 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 18:46:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:46:36 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 18:46:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 18:46:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 18:46:36 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 18:46:36 --> Database Driver Class Initialized
DEBUG - 2016-08-30 18:46:36 --> Session Class Initialized
DEBUG - 2016-08-30 18:46:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 18:46:36 --> Helper loaded: string_helper
DEBUG - 2016-08-30 18:46:36 --> Session routines successfully run
DEBUG - 2016-08-30 18:46:36 --> Native_session Class Initialized
DEBUG - 2016-08-30 18:46:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 18:46:36 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:46:36 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:46:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 18:46:36 --> Controller Class Initialized
DEBUG - 2016-08-30 18:46:36 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 18:46:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 18:46:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 18:46:36 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:46:36 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:46:36 --> User Agent Class Initialized
DEBUG - 2016-08-30 18:46:36 --> Model Class Initialized
DEBUG - 2016-08-30 18:46:36 --> Model Class Initialized
DEBUG - 2016-08-30 18:46:36 --> Model Class Initialized
DEBUG - 2016-08-30 18:46:36 --> Model Class Initialized
DEBUG - 2016-08-30 18:46:36 --> Model Class Initialized
DEBUG - 2016-08-30 18:46:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 18:46:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 18:46:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 18:46:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 18:46:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 18:46:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 18:46:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 18:46:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 18:46:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 18:46:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 18:46:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 18:46:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 18:46:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 18:46:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 18:46:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 18:46:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 18:46:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 18:46:37 --> Final output sent to browser
DEBUG - 2016-08-30 18:46:37 --> Total execution time: 1.0687
DEBUG - 2016-08-30 18:46:37 --> Config Class Initialized
DEBUG - 2016-08-30 18:46:37 --> Hooks Class Initialized
DEBUG - 2016-08-30 18:46:37 --> Utf8 Class Initialized
DEBUG - 2016-08-30 18:46:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 18:46:37 --> URI Class Initialized
DEBUG - 2016-08-30 18:46:38 --> Router Class Initialized
DEBUG - 2016-08-30 18:46:38 --> Output Class Initialized
DEBUG - 2016-08-30 18:46:38 --> Security Class Initialized
DEBUG - 2016-08-30 18:46:38 --> Input Class Initialized
DEBUG - 2016-08-30 18:46:38 --> XSS Filtering completed
DEBUG - 2016-08-30 18:46:38 --> XSS Filtering completed
DEBUG - 2016-08-30 18:46:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 18:46:38 --> Language Class Initialized
DEBUG - 2016-08-30 18:46:38 --> Loader Class Initialized
DEBUG - 2016-08-30 18:46:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 18:46:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 18:46:38 --> Helper loaded: url_helper
DEBUG - 2016-08-30 18:46:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 18:46:38 --> Helper loaded: file_helper
DEBUG - 2016-08-30 18:46:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:46:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 18:46:38 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 18:46:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:46:38 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 18:46:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 18:46:38 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:46:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 18:46:38 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:46:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 18:46:38 --> Helper loaded: form_helper
DEBUG - 2016-08-30 18:46:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 18:46:38 --> Helper loaded: security_helper
DEBUG - 2016-08-30 18:46:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:46:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 18:46:38 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 18:46:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:46:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 18:46:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 18:46:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 18:46:38 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 18:46:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:46:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 18:46:38 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 18:46:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:46:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 18:46:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 18:46:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 18:46:38 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 18:46:38 --> Database Driver Class Initialized
DEBUG - 2016-08-30 18:46:38 --> Session Class Initialized
DEBUG - 2016-08-30 18:46:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 18:46:38 --> Helper loaded: string_helper
DEBUG - 2016-08-30 18:46:38 --> Session routines successfully run
DEBUG - 2016-08-30 18:46:38 --> Native_session Class Initialized
DEBUG - 2016-08-30 18:46:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 18:46:38 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:46:38 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:46:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 18:46:38 --> Controller Class Initialized
DEBUG - 2016-08-30 18:46:38 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 18:46:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 18:46:38 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 18:46:38 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:46:38 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:46:38 --> User Agent Class Initialized
DEBUG - 2016-08-30 18:46:38 --> Model Class Initialized
DEBUG - 2016-08-30 18:46:38 --> Model Class Initialized
DEBUG - 2016-08-30 18:46:38 --> Model Class Initialized
DEBUG - 2016-08-30 18:46:38 --> Model Class Initialized
DEBUG - 2016-08-30 18:46:39 --> Model Class Initialized
ERROR - 2016-08-30 18:46:39 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;favicon.ico&quot;
LINE 10: WHERE &quot;sc_sidika&quot;.&quot;ref_pegawai&quot;.&quot;id_pegawai&quot; = 'favicon.ico'...
                                                        ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-08-30 18:46:39 --> DB Transaction Failure
ERROR - 2016-08-30 18:46:39 --> Query error: ERROR:  invalid input syntax for integer: "favicon.ico"
LINE 10: WHERE "sc_sidika"."ref_pegawai"."id_pegawai" = 'favicon.ico'...
                                                        ^
DEBUG - 2016-08-30 18:46:39 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-08-30 18:49:44 --> Config Class Initialized
DEBUG - 2016-08-30 18:49:44 --> Hooks Class Initialized
DEBUG - 2016-08-30 18:49:44 --> Utf8 Class Initialized
DEBUG - 2016-08-30 18:49:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 18:49:44 --> URI Class Initialized
DEBUG - 2016-08-30 18:49:44 --> Router Class Initialized
DEBUG - 2016-08-30 18:49:44 --> Output Class Initialized
DEBUG - 2016-08-30 18:49:44 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 18:49:44 --> Security Class Initialized
DEBUG - 2016-08-30 18:49:44 --> Input Class Initialized
DEBUG - 2016-08-30 18:49:44 --> XSS Filtering completed
DEBUG - 2016-08-30 18:49:44 --> XSS Filtering completed
DEBUG - 2016-08-30 18:49:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 18:49:44 --> Language Class Initialized
DEBUG - 2016-08-30 18:49:44 --> Loader Class Initialized
DEBUG - 2016-08-30 18:49:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 18:49:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 18:49:44 --> Helper loaded: url_helper
DEBUG - 2016-08-30 18:49:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 18:49:44 --> Helper loaded: file_helper
DEBUG - 2016-08-30 18:49:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:49:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 18:49:44 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 18:49:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:49:44 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 18:49:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 18:49:44 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:49:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 18:49:44 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:49:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 18:49:44 --> Helper loaded: form_helper
DEBUG - 2016-08-30 18:49:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 18:49:44 --> Helper loaded: security_helper
DEBUG - 2016-08-30 18:49:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:49:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 18:49:44 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 18:49:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:49:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 18:49:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 18:49:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 18:49:45 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 18:49:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:49:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 18:49:45 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 18:49:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:49:45 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 18:49:45 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 18:49:45 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 18:49:45 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 18:49:45 --> Database Driver Class Initialized
DEBUG - 2016-08-30 18:49:45 --> Session Class Initialized
DEBUG - 2016-08-30 18:49:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 18:49:45 --> Helper loaded: string_helper
DEBUG - 2016-08-30 18:49:45 --> Session routines successfully run
DEBUG - 2016-08-30 18:49:45 --> Native_session Class Initialized
DEBUG - 2016-08-30 18:49:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 18:49:45 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:49:45 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:49:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 18:49:45 --> Controller Class Initialized
DEBUG - 2016-08-30 18:49:45 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 18:49:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 18:49:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 18:49:45 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:49:45 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:49:45 --> User Agent Class Initialized
DEBUG - 2016-08-30 18:49:45 --> Model Class Initialized
DEBUG - 2016-08-30 18:49:45 --> Model Class Initialized
DEBUG - 2016-08-30 18:49:45 --> Model Class Initialized
DEBUG - 2016-08-30 18:49:45 --> Model Class Initialized
DEBUG - 2016-08-30 18:49:45 --> Model Class Initialized
DEBUG - 2016-08-30 18:49:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 18:49:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 18:49:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 18:49:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 18:49:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 18:49:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 18:49:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 18:49:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 18:49:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 18:49:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 18:49:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 18:49:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 18:49:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 18:49:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 18:49:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 18:49:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 18:49:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 18:49:45 --> Final output sent to browser
DEBUG - 2016-08-30 18:49:45 --> Total execution time: 1.0931
DEBUG - 2016-08-30 18:49:54 --> Config Class Initialized
DEBUG - 2016-08-30 18:49:54 --> Hooks Class Initialized
DEBUG - 2016-08-30 18:49:54 --> Utf8 Class Initialized
DEBUG - 2016-08-30 18:49:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 18:49:54 --> URI Class Initialized
DEBUG - 2016-08-30 18:49:55 --> Router Class Initialized
DEBUG - 2016-08-30 18:49:55 --> Output Class Initialized
DEBUG - 2016-08-30 18:49:55 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 18:49:55 --> Security Class Initialized
DEBUG - 2016-08-30 18:49:55 --> Input Class Initialized
DEBUG - 2016-08-30 18:49:55 --> XSS Filtering completed
DEBUG - 2016-08-30 18:49:55 --> XSS Filtering completed
DEBUG - 2016-08-30 18:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 18:49:55 --> Language Class Initialized
DEBUG - 2016-08-30 18:49:55 --> Loader Class Initialized
DEBUG - 2016-08-30 18:49:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 18:49:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 18:49:55 --> Helper loaded: url_helper
DEBUG - 2016-08-30 18:49:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 18:49:55 --> Helper loaded: file_helper
DEBUG - 2016-08-30 18:49:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:49:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 18:49:55 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 18:49:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:49:55 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 18:49:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 18:49:55 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:49:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 18:49:55 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:49:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 18:49:55 --> Helper loaded: form_helper
DEBUG - 2016-08-30 18:49:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 18:49:55 --> Helper loaded: security_helper
DEBUG - 2016-08-30 18:49:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:49:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 18:49:55 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 18:49:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:49:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 18:49:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 18:49:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 18:49:55 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 18:49:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:49:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 18:49:55 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 18:49:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:49:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 18:49:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 18:49:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 18:49:55 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 18:49:55 --> Database Driver Class Initialized
DEBUG - 2016-08-30 18:49:55 --> Session Class Initialized
DEBUG - 2016-08-30 18:49:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 18:49:55 --> Helper loaded: string_helper
DEBUG - 2016-08-30 18:49:55 --> Session routines successfully run
DEBUG - 2016-08-30 18:49:55 --> Native_session Class Initialized
DEBUG - 2016-08-30 18:49:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 18:49:55 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:49:55 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:49:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 18:49:55 --> Controller Class Initialized
DEBUG - 2016-08-30 18:49:55 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 18:49:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 18:49:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 18:49:55 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:49:55 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:49:55 --> User Agent Class Initialized
DEBUG - 2016-08-30 18:49:55 --> Model Class Initialized
DEBUG - 2016-08-30 18:49:56 --> Model Class Initialized
DEBUG - 2016-08-30 18:49:56 --> Model Class Initialized
DEBUG - 2016-08-30 18:49:56 --> Model Class Initialized
DEBUG - 2016-08-30 18:49:56 --> Model Class Initialized
DEBUG - 2016-08-30 18:49:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 18:49:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 18:49:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 18:49:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 18:49:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 18:49:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 18:49:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 18:49:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 18:49:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 18:49:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 18:49:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 18:49:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 18:49:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 18:49:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 18:49:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 18:49:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 18:49:56 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 18:49:56 --> Final output sent to browser
DEBUG - 2016-08-30 18:49:56 --> Total execution time: 1.1913
DEBUG - 2016-08-30 18:50:15 --> Config Class Initialized
DEBUG - 2016-08-30 18:50:15 --> Hooks Class Initialized
DEBUG - 2016-08-30 18:50:15 --> Utf8 Class Initialized
DEBUG - 2016-08-30 18:50:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 18:50:15 --> URI Class Initialized
DEBUG - 2016-08-30 18:50:15 --> Router Class Initialized
DEBUG - 2016-08-30 18:50:15 --> Output Class Initialized
DEBUG - 2016-08-30 18:50:15 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 18:50:15 --> Security Class Initialized
DEBUG - 2016-08-30 18:50:15 --> Input Class Initialized
DEBUG - 2016-08-30 18:50:15 --> XSS Filtering completed
DEBUG - 2016-08-30 18:50:15 --> XSS Filtering completed
DEBUG - 2016-08-30 18:50:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 18:50:15 --> Language Class Initialized
DEBUG - 2016-08-30 18:50:15 --> Loader Class Initialized
DEBUG - 2016-08-30 18:50:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 18:50:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 18:50:15 --> Helper loaded: url_helper
DEBUG - 2016-08-30 18:50:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 18:50:16 --> Helper loaded: file_helper
DEBUG - 2016-08-30 18:50:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:50:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 18:50:16 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 18:50:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:50:16 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 18:50:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 18:50:16 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:50:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 18:50:16 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:50:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 18:50:16 --> Helper loaded: form_helper
DEBUG - 2016-08-30 18:50:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 18:50:16 --> Helper loaded: security_helper
DEBUG - 2016-08-30 18:50:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:50:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 18:50:16 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 18:50:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:50:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 18:50:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 18:50:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 18:50:16 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 18:50:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:50:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 18:50:16 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 18:50:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:50:16 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 18:50:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 18:50:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 18:50:16 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 18:50:16 --> Database Driver Class Initialized
DEBUG - 2016-08-30 18:50:16 --> Session Class Initialized
DEBUG - 2016-08-30 18:50:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 18:50:16 --> Helper loaded: string_helper
DEBUG - 2016-08-30 18:50:16 --> Session routines successfully run
DEBUG - 2016-08-30 18:50:16 --> Native_session Class Initialized
DEBUG - 2016-08-30 18:50:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 18:50:16 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:50:16 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:50:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 18:50:16 --> Controller Class Initialized
DEBUG - 2016-08-30 18:50:16 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 18:50:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 18:50:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 18:50:16 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:50:16 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:50:16 --> User Agent Class Initialized
DEBUG - 2016-08-30 18:50:16 --> Model Class Initialized
DEBUG - 2016-08-30 18:50:16 --> Model Class Initialized
DEBUG - 2016-08-30 18:50:16 --> Model Class Initialized
DEBUG - 2016-08-30 18:50:16 --> Model Class Initialized
DEBUG - 2016-08-30 18:50:16 --> Model Class Initialized
DEBUG - 2016-08-30 18:50:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 18:50:16 --> Pagination Class Initialized
DEBUG - 2016-08-30 18:50:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 18:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_tingkat_pendidikan/index.php
DEBUG - 2016-08-30 18:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 18:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 18:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 18:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 18:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_tingkat_pendidikan/js/index_js.php
DEBUG - 2016-08-30 18:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 18:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 18:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 18:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 18:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 18:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 18:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_tingkat_pendidikan/js/index_js.php
DEBUG - 2016-08-30 18:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 18:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 18:50:17 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c75a32d2afef33dce35572ed7fc68d18
DEBUG - 2016-08-30 18:50:17 --> Final output sent to browser
DEBUG - 2016-08-30 18:50:17 --> Total execution time: 1.3265
DEBUG - 2016-08-30 18:55:05 --> Config Class Initialized
DEBUG - 2016-08-30 18:55:05 --> Hooks Class Initialized
DEBUG - 2016-08-30 18:55:05 --> Utf8 Class Initialized
DEBUG - 2016-08-30 18:55:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 18:55:05 --> URI Class Initialized
DEBUG - 2016-08-30 18:55:05 --> Router Class Initialized
DEBUG - 2016-08-30 18:55:05 --> Output Class Initialized
DEBUG - 2016-08-30 18:55:05 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 18:55:05 --> Security Class Initialized
DEBUG - 2016-08-30 18:55:05 --> Input Class Initialized
DEBUG - 2016-08-30 18:55:05 --> XSS Filtering completed
DEBUG - 2016-08-30 18:55:05 --> XSS Filtering completed
DEBUG - 2016-08-30 18:55:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 18:55:05 --> Language Class Initialized
DEBUG - 2016-08-30 18:55:05 --> Loader Class Initialized
DEBUG - 2016-08-30 18:55:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 18:55:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 18:55:05 --> Helper loaded: url_helper
DEBUG - 2016-08-30 18:55:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 18:55:05 --> Helper loaded: file_helper
DEBUG - 2016-08-30 18:55:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:55:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 18:55:05 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 18:55:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 18:55:05 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 18:55:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 18:55:05 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:55:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 18:55:05 --> Helper loaded: common_helper
DEBUG - 2016-08-30 18:55:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 18:55:05 --> Helper loaded: form_helper
DEBUG - 2016-08-30 18:55:05 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 18:55:06 --> Helper loaded: security_helper
DEBUG - 2016-08-30 18:55:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:55:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 18:55:06 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 18:55:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 18:55:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 18:55:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 18:55:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 18:55:06 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 18:55:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:55:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 18:55:06 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 18:55:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 18:55:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 18:55:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 18:55:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 18:55:06 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 18:55:06 --> Database Driver Class Initialized
DEBUG - 2016-08-30 18:55:06 --> Session Class Initialized
DEBUG - 2016-08-30 18:55:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 18:55:06 --> Helper loaded: string_helper
DEBUG - 2016-08-30 18:55:06 --> Session routines successfully run
DEBUG - 2016-08-30 18:55:06 --> Native_session Class Initialized
DEBUG - 2016-08-30 18:55:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 18:55:06 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:55:06 --> Form Validation Class Initialized
DEBUG - 2016-08-30 18:55:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 18:55:06 --> Controller Class Initialized
DEBUG - 2016-08-30 18:55:06 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 18:55:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 18:55:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 18:55:06 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:55:06 --> Carabiner: library configured.
DEBUG - 2016-08-30 18:55:06 --> User Agent Class Initialized
DEBUG - 2016-08-30 18:55:06 --> Model Class Initialized
DEBUG - 2016-08-30 18:55:06 --> Model Class Initialized
DEBUG - 2016-08-30 18:55:06 --> Model Class Initialized
DEBUG - 2016-08-30 18:55:06 --> Model Class Initialized
DEBUG - 2016-08-30 18:55:06 --> Model Class Initialized
DEBUG - 2016-08-30 18:55:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 18:55:06 --> Pagination Class Initialized
DEBUG - 2016-08-30 18:55:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 18:55:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_tingkat_pendidikan/index.php
DEBUG - 2016-08-30 18:55:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 18:55:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 18:55:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 18:55:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 18:55:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_tingkat_pendidikan/js/index_js.php
DEBUG - 2016-08-30 18:55:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 18:55:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 18:55:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 18:55:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 18:55:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 18:55:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 18:55:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_tingkat_pendidikan/js/index_js.php
DEBUG - 2016-08-30 18:55:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 18:55:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 18:55:06 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c75a32d2afef33dce35572ed7fc68d18
DEBUG - 2016-08-30 18:55:06 --> Final output sent to browser
DEBUG - 2016-08-30 18:55:06 --> Total execution time: 1.1980
DEBUG - 2016-08-30 19:14:53 --> Config Class Initialized
DEBUG - 2016-08-30 19:14:53 --> Hooks Class Initialized
DEBUG - 2016-08-30 19:14:53 --> Utf8 Class Initialized
DEBUG - 2016-08-30 19:14:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 19:14:53 --> URI Class Initialized
DEBUG - 2016-08-30 19:14:53 --> Router Class Initialized
DEBUG - 2016-08-30 19:14:53 --> Output Class Initialized
DEBUG - 2016-08-30 19:14:53 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 19:14:53 --> Security Class Initialized
DEBUG - 2016-08-30 19:14:53 --> Input Class Initialized
DEBUG - 2016-08-30 19:14:54 --> XSS Filtering completed
DEBUG - 2016-08-30 19:14:54 --> XSS Filtering completed
DEBUG - 2016-08-30 19:14:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 19:14:54 --> Language Class Initialized
DEBUG - 2016-08-30 19:14:54 --> Loader Class Initialized
DEBUG - 2016-08-30 19:14:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 19:14:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 19:14:54 --> Helper loaded: url_helper
DEBUG - 2016-08-30 19:14:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 19:14:54 --> Helper loaded: file_helper
DEBUG - 2016-08-30 19:14:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 19:14:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 19:14:54 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 19:14:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 19:14:54 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 19:14:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 19:14:54 --> Helper loaded: common_helper
DEBUG - 2016-08-30 19:14:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 19:14:54 --> Helper loaded: common_helper
DEBUG - 2016-08-30 19:14:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 19:14:54 --> Helper loaded: form_helper
DEBUG - 2016-08-30 19:14:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 19:14:54 --> Helper loaded: security_helper
DEBUG - 2016-08-30 19:14:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 19:14:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 19:14:54 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 19:14:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 19:14:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 19:14:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 19:14:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 19:14:54 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 19:14:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 19:14:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 19:14:54 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 19:14:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 19:14:54 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 19:14:54 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 19:14:54 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 19:14:54 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 19:14:54 --> Database Driver Class Initialized
DEBUG - 2016-08-30 19:14:54 --> Session Class Initialized
DEBUG - 2016-08-30 19:14:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 19:14:54 --> Helper loaded: string_helper
DEBUG - 2016-08-30 19:14:54 --> Session routines successfully run
DEBUG - 2016-08-30 19:14:54 --> Native_session Class Initialized
DEBUG - 2016-08-30 19:14:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 19:14:54 --> Form Validation Class Initialized
DEBUG - 2016-08-30 19:14:54 --> Form Validation Class Initialized
DEBUG - 2016-08-30 19:14:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 19:14:54 --> Controller Class Initialized
DEBUG - 2016-08-30 19:14:54 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 19:14:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 19:14:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 19:14:54 --> Carabiner: library configured.
DEBUG - 2016-08-30 19:14:54 --> Carabiner: library configured.
DEBUG - 2016-08-30 19:14:54 --> User Agent Class Initialized
DEBUG - 2016-08-30 19:14:54 --> Model Class Initialized
DEBUG - 2016-08-30 19:14:54 --> Model Class Initialized
DEBUG - 2016-08-30 19:14:54 --> Model Class Initialized
DEBUG - 2016-08-30 19:14:54 --> Model Class Initialized
DEBUG - 2016-08-30 19:14:54 --> Model Class Initialized
DEBUG - 2016-08-30 19:14:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 19:14:55 --> Pagination Class Initialized
DEBUG - 2016-08-30 19:14:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 19:14:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/index.php
DEBUG - 2016-08-30 19:14:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 19:14:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 19:14:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 19:14:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 19:14:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-08-30 19:14:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 19:14:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 19:14:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 19:14:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 19:14:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 19:14:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 19:14:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-08-30 19:14:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 19:14:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 19:14:55 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c2a3e0401bd35d4fcac4bae5f9412231
DEBUG - 2016-08-30 19:14:55 --> Final output sent to browser
DEBUG - 2016-08-30 19:14:55 --> Total execution time: 1.2067
DEBUG - 2016-08-30 19:14:57 --> Config Class Initialized
DEBUG - 2016-08-30 19:14:57 --> Hooks Class Initialized
DEBUG - 2016-08-30 19:14:57 --> Utf8 Class Initialized
DEBUG - 2016-08-30 19:14:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 19:14:57 --> URI Class Initialized
DEBUG - 2016-08-30 19:14:57 --> Router Class Initialized
DEBUG - 2016-08-30 19:14:57 --> Output Class Initialized
DEBUG - 2016-08-30 19:14:57 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 19:14:57 --> Security Class Initialized
DEBUG - 2016-08-30 19:14:57 --> Input Class Initialized
DEBUG - 2016-08-30 19:14:57 --> XSS Filtering completed
DEBUG - 2016-08-30 19:14:57 --> XSS Filtering completed
DEBUG - 2016-08-30 19:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 19:14:57 --> Language Class Initialized
DEBUG - 2016-08-30 19:14:57 --> Loader Class Initialized
DEBUG - 2016-08-30 19:14:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 19:14:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 19:14:57 --> Helper loaded: url_helper
DEBUG - 2016-08-30 19:14:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 19:14:57 --> Helper loaded: file_helper
DEBUG - 2016-08-30 19:14:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 19:14:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 19:14:57 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 19:14:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 19:14:57 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 19:14:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 19:14:57 --> Helper loaded: common_helper
DEBUG - 2016-08-30 19:14:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 19:14:57 --> Helper loaded: common_helper
DEBUG - 2016-08-30 19:14:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 19:14:57 --> Helper loaded: form_helper
DEBUG - 2016-08-30 19:14:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 19:14:57 --> Helper loaded: security_helper
DEBUG - 2016-08-30 19:14:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 19:14:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 19:14:57 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 19:14:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 19:14:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 19:14:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 19:14:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 19:14:57 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 19:14:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 19:14:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 19:14:57 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 19:14:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 19:14:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 19:14:58 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 19:14:58 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 19:14:58 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 19:14:58 --> Database Driver Class Initialized
DEBUG - 2016-08-30 19:14:58 --> Session Class Initialized
DEBUG - 2016-08-30 19:14:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 19:14:58 --> Helper loaded: string_helper
DEBUG - 2016-08-30 19:14:58 --> Session routines successfully run
DEBUG - 2016-08-30 19:14:58 --> Native_session Class Initialized
DEBUG - 2016-08-30 19:14:58 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 19:14:58 --> Form Validation Class Initialized
DEBUG - 2016-08-30 19:14:58 --> Form Validation Class Initialized
DEBUG - 2016-08-30 19:14:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 19:14:58 --> Controller Class Initialized
DEBUG - 2016-08-30 19:14:58 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 19:14:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 19:14:58 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 19:14:58 --> Carabiner: library configured.
DEBUG - 2016-08-30 19:14:58 --> Carabiner: library configured.
DEBUG - 2016-08-30 19:14:58 --> User Agent Class Initialized
DEBUG - 2016-08-30 19:14:58 --> Model Class Initialized
DEBUG - 2016-08-30 19:14:58 --> Model Class Initialized
DEBUG - 2016-08-30 19:14:58 --> Model Class Initialized
DEBUG - 2016-08-30 19:14:58 --> Model Class Initialized
DEBUG - 2016-08-30 19:14:58 --> Model Class Initialized
DEBUG - 2016-08-30 19:14:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 19:14:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 19:14:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 19:14:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 19:14:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 19:14:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 19:14:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 19:14:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 19:14:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 19:14:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 19:14:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 19:14:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 19:14:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 19:14:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 19:14:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 19:14:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 19:14:58 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 19:14:58 --> Final output sent to browser
DEBUG - 2016-08-30 19:14:58 --> Total execution time: 1.1868
DEBUG - 2016-08-30 21:12:29 --> Config Class Initialized
DEBUG - 2016-08-30 21:12:29 --> Hooks Class Initialized
DEBUG - 2016-08-30 21:12:29 --> Utf8 Class Initialized
DEBUG - 2016-08-30 21:12:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 21:12:29 --> URI Class Initialized
DEBUG - 2016-08-30 21:12:29 --> Router Class Initialized
DEBUG - 2016-08-30 21:12:29 --> Output Class Initialized
DEBUG - 2016-08-30 21:12:29 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 21:12:29 --> Security Class Initialized
DEBUG - 2016-08-30 21:12:29 --> Input Class Initialized
DEBUG - 2016-08-30 21:12:29 --> XSS Filtering completed
DEBUG - 2016-08-30 21:12:29 --> XSS Filtering completed
DEBUG - 2016-08-30 21:12:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 21:12:29 --> Language Class Initialized
DEBUG - 2016-08-30 21:12:29 --> Loader Class Initialized
DEBUG - 2016-08-30 21:12:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 21:12:29 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 21:12:29 --> Helper loaded: url_helper
DEBUG - 2016-08-30 21:12:29 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 21:12:29 --> Helper loaded: file_helper
DEBUG - 2016-08-30 21:12:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 21:12:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 21:12:29 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 21:12:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 21:12:29 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 21:12:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 21:12:29 --> Helper loaded: common_helper
DEBUG - 2016-08-30 21:12:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 21:12:29 --> Helper loaded: common_helper
DEBUG - 2016-08-30 21:12:29 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 21:12:29 --> Helper loaded: form_helper
DEBUG - 2016-08-30 21:12:29 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 21:12:29 --> Helper loaded: security_helper
DEBUG - 2016-08-30 21:12:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 21:12:29 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 21:12:29 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 21:12:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 21:12:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 21:12:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 21:12:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 21:12:30 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 21:12:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 21:12:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 21:12:30 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 21:12:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 21:12:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 21:12:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 21:12:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 21:12:30 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 21:12:30 --> Database Driver Class Initialized
DEBUG - 2016-08-30 21:12:30 --> Session Class Initialized
DEBUG - 2016-08-30 21:12:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 21:12:30 --> Helper loaded: string_helper
DEBUG - 2016-08-30 21:12:30 --> Session routines successfully run
DEBUG - 2016-08-30 21:12:30 --> Native_session Class Initialized
DEBUG - 2016-08-30 21:12:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 21:12:30 --> Form Validation Class Initialized
DEBUG - 2016-08-30 21:12:30 --> Form Validation Class Initialized
DEBUG - 2016-08-30 21:12:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 21:12:30 --> Controller Class Initialized
DEBUG - 2016-08-30 21:12:30 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 21:12:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 21:12:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 21:12:30 --> Carabiner: library configured.
DEBUG - 2016-08-30 21:12:30 --> Carabiner: library configured.
DEBUG - 2016-08-30 21:12:30 --> User Agent Class Initialized
DEBUG - 2016-08-30 21:12:30 --> Model Class Initialized
DEBUG - 2016-08-30 21:12:30 --> Model Class Initialized
DEBUG - 2016-08-30 21:12:30 --> Model Class Initialized
DEBUG - 2016-08-30 21:12:30 --> Model Class Initialized
DEBUG - 2016-08-30 21:12:30 --> Model Class Initialized
DEBUG - 2016-08-30 21:12:30 --> Model Class Initialized
DEBUG - 2016-08-30 21:12:30 --> Model Class Initialized
DEBUG - 2016-08-30 21:12:30 --> Model Class Initialized
DEBUG - 2016-08-30 21:12:30 --> Model Class Initialized
DEBUG - 2016-08-30 21:12:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 21:12:30 --> Pagination Class Initialized
ERROR - 2016-08-30 21:12:30 --> Severity: Notice  --> Undefined variable: model E:\www\GitHub\2016APSIDIKA\application\controllers\back_end\cpustaka_data.php 38
DEBUG - 2016-08-30 21:12:45 --> Config Class Initialized
DEBUG - 2016-08-30 21:12:45 --> Hooks Class Initialized
DEBUG - 2016-08-30 21:12:45 --> Utf8 Class Initialized
DEBUG - 2016-08-30 21:12:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 21:12:45 --> URI Class Initialized
DEBUG - 2016-08-30 21:12:45 --> Router Class Initialized
DEBUG - 2016-08-30 21:12:45 --> Output Class Initialized
DEBUG - 2016-08-30 21:12:45 --> Security Class Initialized
DEBUG - 2016-08-30 21:12:45 --> Input Class Initialized
DEBUG - 2016-08-30 21:12:45 --> XSS Filtering completed
DEBUG - 2016-08-30 21:12:45 --> XSS Filtering completed
DEBUG - 2016-08-30 21:12:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 21:12:45 --> Language Class Initialized
DEBUG - 2016-08-30 21:12:45 --> Loader Class Initialized
DEBUG - 2016-08-30 21:12:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 21:12:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 21:12:45 --> Helper loaded: url_helper
DEBUG - 2016-08-30 21:12:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 21:12:45 --> Helper loaded: file_helper
DEBUG - 2016-08-30 21:12:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 21:12:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 21:12:45 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 21:12:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 21:12:45 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 21:12:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 21:12:45 --> Helper loaded: common_helper
DEBUG - 2016-08-30 21:12:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 21:12:45 --> Helper loaded: common_helper
DEBUG - 2016-08-30 21:12:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 21:12:45 --> Helper loaded: form_helper
DEBUG - 2016-08-30 21:12:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 21:12:45 --> Helper loaded: security_helper
DEBUG - 2016-08-30 21:12:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 21:12:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 21:12:45 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 21:12:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 21:12:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 21:12:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 21:12:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 21:12:46 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 21:12:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 21:12:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 21:12:46 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 21:12:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 21:12:46 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 21:12:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 21:12:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 21:12:46 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 21:12:46 --> Database Driver Class Initialized
DEBUG - 2016-08-30 21:12:46 --> Session Class Initialized
DEBUG - 2016-08-30 21:12:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 21:12:46 --> Helper loaded: string_helper
DEBUG - 2016-08-30 21:12:46 --> Session routines successfully run
DEBUG - 2016-08-30 21:12:46 --> Native_session Class Initialized
DEBUG - 2016-08-30 21:12:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 21:12:46 --> Form Validation Class Initialized
DEBUG - 2016-08-30 21:12:46 --> Form Validation Class Initialized
DEBUG - 2016-08-30 21:12:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 21:12:46 --> Controller Class Initialized
DEBUG - 2016-08-30 21:12:46 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 21:12:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 21:12:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 21:12:46 --> Carabiner: library configured.
DEBUG - 2016-08-30 21:12:46 --> Carabiner: library configured.
DEBUG - 2016-08-30 21:12:46 --> User Agent Class Initialized
DEBUG - 2016-08-30 21:12:46 --> Model Class Initialized
DEBUG - 2016-08-30 21:12:46 --> Model Class Initialized
DEBUG - 2016-08-30 21:12:46 --> Model Class Initialized
DEBUG - 2016-08-30 21:12:46 --> Model Class Initialized
DEBUG - 2016-08-30 21:12:46 --> Model Class Initialized
DEBUG - 2016-08-30 21:12:46 --> Model Class Initialized
DEBUG - 2016-08-30 21:12:46 --> Model Class Initialized
DEBUG - 2016-08-30 21:12:46 --> Model Class Initialized
DEBUG - 2016-08-30 21:12:46 --> Model Class Initialized
DEBUG - 2016-08-30 21:12:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 21:12:46 --> Pagination Class Initialized
DEBUG - 2016-08-30 21:12:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 21:12:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-30 21:12:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 21:12:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 21:12:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 21:12:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 21:12:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-30 21:12:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 21:12:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 21:12:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 21:12:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 21:12:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 21:12:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 21:12:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-30 21:12:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 21:12:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 21:12:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-30 21:12:47 --> Final output sent to browser
DEBUG - 2016-08-30 21:12:47 --> Total execution time: 1.6460
DEBUG - 2016-08-30 21:29:28 --> Config Class Initialized
DEBUG - 2016-08-30 21:29:28 --> Hooks Class Initialized
DEBUG - 2016-08-30 21:29:28 --> Utf8 Class Initialized
DEBUG - 2016-08-30 21:29:28 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 21:29:28 --> URI Class Initialized
DEBUG - 2016-08-30 21:29:28 --> Router Class Initialized
DEBUG - 2016-08-30 21:29:28 --> Output Class Initialized
DEBUG - 2016-08-30 21:29:28 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 21:29:28 --> Security Class Initialized
DEBUG - 2016-08-30 21:29:28 --> Input Class Initialized
DEBUG - 2016-08-30 21:29:28 --> XSS Filtering completed
DEBUG - 2016-08-30 21:29:28 --> XSS Filtering completed
DEBUG - 2016-08-30 21:29:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 21:29:28 --> Language Class Initialized
DEBUG - 2016-08-30 21:29:28 --> Loader Class Initialized
DEBUG - 2016-08-30 21:29:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 21:29:28 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 21:29:28 --> Helper loaded: url_helper
DEBUG - 2016-08-30 21:29:28 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 21:29:28 --> Helper loaded: file_helper
DEBUG - 2016-08-30 21:29:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 21:29:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 21:29:29 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 21:29:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 21:29:29 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 21:29:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 21:29:29 --> Helper loaded: common_helper
DEBUG - 2016-08-30 21:29:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 21:29:29 --> Helper loaded: common_helper
DEBUG - 2016-08-30 21:29:29 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 21:29:29 --> Helper loaded: form_helper
DEBUG - 2016-08-30 21:29:29 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 21:29:29 --> Helper loaded: security_helper
DEBUG - 2016-08-30 21:29:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 21:29:29 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 21:29:29 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 21:29:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 21:29:29 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 21:29:29 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 21:29:29 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 21:29:29 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 21:29:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 21:29:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 21:29:29 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 21:29:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 21:29:29 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 21:29:29 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 21:29:29 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 21:29:29 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 21:29:29 --> Database Driver Class Initialized
DEBUG - 2016-08-30 21:29:29 --> Session Class Initialized
DEBUG - 2016-08-30 21:29:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 21:29:29 --> Helper loaded: string_helper
DEBUG - 2016-08-30 21:29:29 --> Session routines successfully run
DEBUG - 2016-08-30 21:29:29 --> Native_session Class Initialized
DEBUG - 2016-08-30 21:29:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 21:29:29 --> Form Validation Class Initialized
DEBUG - 2016-08-30 21:29:29 --> Form Validation Class Initialized
DEBUG - 2016-08-30 21:29:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 21:29:29 --> Controller Class Initialized
DEBUG - 2016-08-30 21:29:29 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 21:29:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 21:29:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 21:29:29 --> Carabiner: library configured.
DEBUG - 2016-08-30 21:29:29 --> Carabiner: library configured.
DEBUG - 2016-08-30 21:29:29 --> User Agent Class Initialized
DEBUG - 2016-08-30 21:29:29 --> Model Class Initialized
DEBUG - 2016-08-30 21:29:29 --> Model Class Initialized
DEBUG - 2016-08-30 21:29:29 --> Model Class Initialized
DEBUG - 2016-08-30 21:29:45 --> Config Class Initialized
DEBUG - 2016-08-30 21:29:45 --> Hooks Class Initialized
DEBUG - 2016-08-30 21:29:45 --> Utf8 Class Initialized
DEBUG - 2016-08-30 21:29:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 21:29:45 --> URI Class Initialized
DEBUG - 2016-08-30 21:29:45 --> Router Class Initialized
DEBUG - 2016-08-30 21:29:45 --> Output Class Initialized
DEBUG - 2016-08-30 21:29:45 --> Security Class Initialized
DEBUG - 2016-08-30 21:29:45 --> Input Class Initialized
DEBUG - 2016-08-30 21:29:45 --> XSS Filtering completed
DEBUG - 2016-08-30 21:29:45 --> XSS Filtering completed
DEBUG - 2016-08-30 21:29:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 21:29:45 --> Language Class Initialized
DEBUG - 2016-08-30 21:29:45 --> Loader Class Initialized
DEBUG - 2016-08-30 21:29:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 21:29:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 21:29:45 --> Helper loaded: url_helper
DEBUG - 2016-08-30 21:29:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 21:29:45 --> Helper loaded: file_helper
DEBUG - 2016-08-30 21:29:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 21:29:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 21:29:45 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 21:29:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 21:29:45 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 21:29:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 21:29:45 --> Helper loaded: common_helper
DEBUG - 2016-08-30 21:29:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 21:29:45 --> Helper loaded: common_helper
DEBUG - 2016-08-30 21:29:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 21:29:45 --> Helper loaded: form_helper
DEBUG - 2016-08-30 21:29:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 21:29:45 --> Helper loaded: security_helper
DEBUG - 2016-08-30 21:29:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 21:29:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 21:29:45 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 21:29:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 21:29:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 21:29:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 21:29:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 21:29:45 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 21:29:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 21:29:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 21:29:45 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 21:29:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 21:29:45 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 21:29:45 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 21:29:45 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 21:29:45 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 21:29:45 --> Database Driver Class Initialized
DEBUG - 2016-08-30 21:29:45 --> Session Class Initialized
DEBUG - 2016-08-30 21:29:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 21:29:45 --> Helper loaded: string_helper
DEBUG - 2016-08-30 21:29:46 --> Session routines successfully run
DEBUG - 2016-08-30 21:29:46 --> Native_session Class Initialized
DEBUG - 2016-08-30 21:29:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 21:29:46 --> Form Validation Class Initialized
DEBUG - 2016-08-30 21:29:46 --> Form Validation Class Initialized
DEBUG - 2016-08-30 21:29:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 21:29:46 --> Controller Class Initialized
DEBUG - 2016-08-30 21:29:46 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 21:29:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 21:29:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 21:29:46 --> Carabiner: library configured.
DEBUG - 2016-08-30 21:29:46 --> Carabiner: library configured.
DEBUG - 2016-08-30 21:29:46 --> User Agent Class Initialized
DEBUG - 2016-08-30 21:29:46 --> Model Class Initialized
DEBUG - 2016-08-30 21:29:46 --> Model Class Initialized
DEBUG - 2016-08-30 21:29:46 --> Model Class Initialized
DEBUG - 2016-08-30 21:29:53 --> Config Class Initialized
DEBUG - 2016-08-30 21:29:53 --> Hooks Class Initialized
DEBUG - 2016-08-30 21:29:53 --> Utf8 Class Initialized
DEBUG - 2016-08-30 21:29:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 21:29:53 --> URI Class Initialized
DEBUG - 2016-08-30 21:29:53 --> Router Class Initialized
DEBUG - 2016-08-30 21:29:53 --> Output Class Initialized
DEBUG - 2016-08-30 21:29:53 --> Security Class Initialized
DEBUG - 2016-08-30 21:29:53 --> Input Class Initialized
DEBUG - 2016-08-30 21:29:53 --> XSS Filtering completed
DEBUG - 2016-08-30 21:29:53 --> XSS Filtering completed
DEBUG - 2016-08-30 21:29:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 21:29:53 --> Language Class Initialized
DEBUG - 2016-08-30 21:29:53 --> Loader Class Initialized
DEBUG - 2016-08-30 21:29:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 21:29:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 21:29:53 --> Helper loaded: url_helper
DEBUG - 2016-08-30 21:29:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 21:29:53 --> Helper loaded: file_helper
DEBUG - 2016-08-30 21:29:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 21:29:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 21:29:53 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 21:29:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 21:29:53 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 21:29:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 21:29:53 --> Helper loaded: common_helper
DEBUG - 2016-08-30 21:29:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 21:29:53 --> Helper loaded: common_helper
DEBUG - 2016-08-30 21:29:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 21:29:53 --> Helper loaded: form_helper
DEBUG - 2016-08-30 21:29:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 21:29:53 --> Helper loaded: security_helper
DEBUG - 2016-08-30 21:29:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 21:29:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 21:29:53 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 21:29:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 21:29:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 21:29:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 21:29:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 21:29:53 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 21:29:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 21:29:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 21:29:53 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 21:29:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 21:29:53 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 21:29:53 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 21:29:53 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 21:29:53 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 21:29:53 --> Database Driver Class Initialized
DEBUG - 2016-08-30 21:29:54 --> Session Class Initialized
DEBUG - 2016-08-30 21:29:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 21:29:54 --> Helper loaded: string_helper
DEBUG - 2016-08-30 21:29:54 --> Session routines successfully run
DEBUG - 2016-08-30 21:29:54 --> Native_session Class Initialized
DEBUG - 2016-08-30 21:29:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 21:29:54 --> Form Validation Class Initialized
DEBUG - 2016-08-30 21:29:54 --> Form Validation Class Initialized
DEBUG - 2016-08-30 21:29:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 21:29:54 --> Controller Class Initialized
DEBUG - 2016-08-30 21:29:54 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 21:29:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 21:29:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 21:29:54 --> Carabiner: library configured.
DEBUG - 2016-08-30 21:29:54 --> Carabiner: library configured.
DEBUG - 2016-08-30 21:29:54 --> User Agent Class Initialized
DEBUG - 2016-08-30 21:29:54 --> Model Class Initialized
DEBUG - 2016-08-30 21:29:54 --> Model Class Initialized
DEBUG - 2016-08-30 21:29:54 --> Model Class Initialized
DEBUG - 2016-08-30 21:29:54 --> Model Class Initialized
DEBUG - 2016-08-30 21:29:54 --> Model Class Initialized
DEBUG - 2016-08-30 21:29:54 --> Model Class Initialized
DEBUG - 2016-08-30 21:29:54 --> Model Class Initialized
DEBUG - 2016-08-30 21:29:54 --> Model Class Initialized
DEBUG - 2016-08-30 21:29:54 --> Model Class Initialized
DEBUG - 2016-08-30 21:29:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 21:29:54 --> Pagination Class Initialized
DEBUG - 2016-08-30 21:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 21:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-30 21:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 21:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 21:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 21:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 21:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-30 21:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 21:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 21:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 21:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 21:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 21:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 21:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-30 21:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 21:29:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 21:29:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-30 21:29:54 --> Final output sent to browser
DEBUG - 2016-08-30 21:29:54 --> Total execution time: 1.4721
DEBUG - 2016-08-30 21:56:01 --> Config Class Initialized
DEBUG - 2016-08-30 21:56:01 --> Hooks Class Initialized
DEBUG - 2016-08-30 21:56:01 --> Utf8 Class Initialized
DEBUG - 2016-08-30 21:56:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 21:56:01 --> URI Class Initialized
DEBUG - 2016-08-30 21:56:01 --> Router Class Initialized
DEBUG - 2016-08-30 21:56:01 --> Output Class Initialized
DEBUG - 2016-08-30 21:56:01 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 21:56:01 --> Security Class Initialized
DEBUG - 2016-08-30 21:56:01 --> Input Class Initialized
DEBUG - 2016-08-30 21:56:01 --> XSS Filtering completed
DEBUG - 2016-08-30 21:56:01 --> XSS Filtering completed
DEBUG - 2016-08-30 21:56:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 21:56:01 --> Language Class Initialized
DEBUG - 2016-08-30 21:56:01 --> Loader Class Initialized
DEBUG - 2016-08-30 21:56:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 21:56:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 21:56:01 --> Helper loaded: url_helper
DEBUG - 2016-08-30 21:56:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 21:56:01 --> Helper loaded: file_helper
DEBUG - 2016-08-30 21:56:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 21:56:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 21:56:01 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 21:56:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 21:56:02 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 21:56:02 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 21:56:02 --> Helper loaded: common_helper
DEBUG - 2016-08-30 21:56:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 21:56:02 --> Helper loaded: common_helper
DEBUG - 2016-08-30 21:56:02 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 21:56:02 --> Helper loaded: form_helper
DEBUG - 2016-08-30 21:56:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 21:56:02 --> Helper loaded: security_helper
DEBUG - 2016-08-30 21:56:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 21:56:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 21:56:02 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 21:56:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 21:56:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 21:56:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 21:56:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 21:56:02 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 21:56:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 21:56:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 21:56:02 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 21:56:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 21:56:02 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 21:56:02 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 21:56:02 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 21:56:02 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 21:56:02 --> Database Driver Class Initialized
DEBUG - 2016-08-30 21:56:02 --> Session Class Initialized
DEBUG - 2016-08-30 21:56:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 21:56:02 --> Helper loaded: string_helper
DEBUG - 2016-08-30 21:56:02 --> Session routines successfully run
DEBUG - 2016-08-30 21:56:02 --> Native_session Class Initialized
DEBUG - 2016-08-30 21:56:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 21:56:02 --> Form Validation Class Initialized
DEBUG - 2016-08-30 21:56:02 --> Form Validation Class Initialized
DEBUG - 2016-08-30 21:56:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 21:56:02 --> Controller Class Initialized
DEBUG - 2016-08-30 21:56:02 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 21:56:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 21:56:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 21:56:02 --> Carabiner: library configured.
DEBUG - 2016-08-30 21:56:02 --> Carabiner: library configured.
DEBUG - 2016-08-30 21:56:02 --> User Agent Class Initialized
DEBUG - 2016-08-30 21:56:02 --> Model Class Initialized
DEBUG - 2016-08-30 21:56:02 --> Model Class Initialized
DEBUG - 2016-08-30 21:56:02 --> Model Class Initialized
DEBUG - 2016-08-30 21:56:02 --> Model Class Initialized
DEBUG - 2016-08-30 21:56:02 --> Model Class Initialized
DEBUG - 2016-08-30 21:56:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 21:56:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 21:56:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 21:56:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 21:56:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 21:56:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 21:56:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 21:56:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 21:56:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 21:56:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 21:56:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 21:56:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 21:56:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 21:56:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 21:56:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 21:56:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 21:56:03 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 21:56:03 --> Final output sent to browser
DEBUG - 2016-08-30 21:56:03 --> Total execution time: 1.3862
DEBUG - 2016-08-30 22:00:09 --> Config Class Initialized
DEBUG - 2016-08-30 22:00:09 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:00:09 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:00:09 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:00:09 --> URI Class Initialized
DEBUG - 2016-08-30 22:00:09 --> Router Class Initialized
DEBUG - 2016-08-30 22:00:09 --> Output Class Initialized
DEBUG - 2016-08-30 22:00:09 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:00:09 --> Security Class Initialized
DEBUG - 2016-08-30 22:00:09 --> Input Class Initialized
DEBUG - 2016-08-30 22:00:09 --> XSS Filtering completed
DEBUG - 2016-08-30 22:00:09 --> XSS Filtering completed
DEBUG - 2016-08-30 22:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:00:09 --> Language Class Initialized
DEBUG - 2016-08-30 22:00:09 --> Loader Class Initialized
DEBUG - 2016-08-30 22:00:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:00:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:00:09 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:00:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:00:09 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:00:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:00:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:00:09 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:00:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:00:09 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:00:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:00:09 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:00:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:00:09 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:00:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:00:09 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:00:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:00:09 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:00:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:00:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:00:10 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:00:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:00:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:00:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:00:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:00:10 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:00:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:00:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:00:10 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:00:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:00:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:00:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:00:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:00:10 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:00:10 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:00:10 --> Session Class Initialized
DEBUG - 2016-08-30 22:00:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:00:10 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:00:10 --> Session routines successfully run
DEBUG - 2016-08-30 22:00:10 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:00:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:00:10 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:00:10 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:00:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:00:10 --> Controller Class Initialized
DEBUG - 2016-08-30 22:00:10 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:00:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:00:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:00:10 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:00:10 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:00:10 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:00:10 --> Model Class Initialized
DEBUG - 2016-08-30 22:00:10 --> Model Class Initialized
DEBUG - 2016-08-30 22:00:10 --> Model Class Initialized
DEBUG - 2016-08-30 22:00:10 --> Model Class Initialized
DEBUG - 2016-08-30 22:00:10 --> Model Class Initialized
DEBUG - 2016-08-30 22:00:10 --> Model Class Initialized
DEBUG - 2016-08-30 22:00:10 --> Model Class Initialized
DEBUG - 2016-08-30 22:00:10 --> Model Class Initialized
DEBUG - 2016-08-30 22:00:10 --> Model Class Initialized
ERROR - 2016-08-30 22:00:10 --> Severity: Notice  --> Undefined variable: model_name E:\www\GitHub\2016APSIDIKA\application\controllers\back_end\cpustaka_data.php 36
DEBUG - 2016-08-30 22:00:25 --> Config Class Initialized
DEBUG - 2016-08-30 22:00:25 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:00:25 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:00:25 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:00:25 --> URI Class Initialized
DEBUG - 2016-08-30 22:00:25 --> Router Class Initialized
DEBUG - 2016-08-30 22:00:25 --> Output Class Initialized
DEBUG - 2016-08-30 22:00:25 --> Security Class Initialized
DEBUG - 2016-08-30 22:00:25 --> Input Class Initialized
DEBUG - 2016-08-30 22:00:25 --> XSS Filtering completed
DEBUG - 2016-08-30 22:00:25 --> XSS Filtering completed
DEBUG - 2016-08-30 22:00:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:00:25 --> Language Class Initialized
DEBUG - 2016-08-30 22:00:25 --> Loader Class Initialized
DEBUG - 2016-08-30 22:00:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:00:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:00:25 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:00:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:00:25 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:00:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:00:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:00:25 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:00:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:00:25 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:00:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:00:25 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:00:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:00:25 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:00:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:00:25 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:00:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:00:25 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:00:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:00:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:00:25 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:00:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:00:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:00:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:00:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:00:25 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:00:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:00:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:00:25 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:00:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:00:25 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:00:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:00:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:00:25 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:00:26 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:00:26 --> Session Class Initialized
DEBUG - 2016-08-30 22:00:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:00:26 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:00:26 --> Session routines successfully run
DEBUG - 2016-08-30 22:00:26 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:00:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:00:26 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:00:26 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:00:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:00:26 --> Controller Class Initialized
DEBUG - 2016-08-30 22:00:26 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:00:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:00:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:00:26 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:00:26 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:00:26 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:00:26 --> Model Class Initialized
DEBUG - 2016-08-30 22:00:26 --> Model Class Initialized
DEBUG - 2016-08-30 22:00:26 --> Model Class Initialized
DEBUG - 2016-08-30 22:00:26 --> Model Class Initialized
DEBUG - 2016-08-30 22:00:26 --> Model Class Initialized
DEBUG - 2016-08-30 22:00:26 --> Model Class Initialized
DEBUG - 2016-08-30 22:00:26 --> Model Class Initialized
DEBUG - 2016-08-30 22:00:26 --> Model Class Initialized
DEBUG - 2016-08-30 22:00:26 --> Model Class Initialized
DEBUG - 2016-08-30 22:00:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:00:26 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 22:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-30 22:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-30 22:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-30 22:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:00:26 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-30 22:00:26 --> Final output sent to browser
DEBUG - 2016-08-30 22:00:26 --> Total execution time: 1.4621
DEBUG - 2016-08-30 22:14:06 --> Config Class Initialized
DEBUG - 2016-08-30 22:14:07 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:14:07 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:14:07 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:14:07 --> URI Class Initialized
DEBUG - 2016-08-30 22:14:07 --> Router Class Initialized
DEBUG - 2016-08-30 22:14:07 --> Output Class Initialized
DEBUG - 2016-08-30 22:14:07 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:14:07 --> Security Class Initialized
DEBUG - 2016-08-30 22:14:07 --> Input Class Initialized
DEBUG - 2016-08-30 22:14:07 --> XSS Filtering completed
DEBUG - 2016-08-30 22:14:07 --> XSS Filtering completed
DEBUG - 2016-08-30 22:14:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:14:07 --> Language Class Initialized
DEBUG - 2016-08-30 22:14:07 --> Loader Class Initialized
DEBUG - 2016-08-30 22:14:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:14:07 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:14:07 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:14:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:14:07 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:14:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:14:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:14:07 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:14:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:14:07 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:14:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:14:07 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:14:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:14:07 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:14:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:14:07 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:14:07 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:14:07 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:14:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:14:07 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:14:07 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:14:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:14:07 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:14:07 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:14:07 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:14:07 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:14:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:14:07 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:14:07 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:14:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:14:07 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:14:07 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:14:07 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:14:07 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:14:07 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:14:07 --> Session Class Initialized
DEBUG - 2016-08-30 22:14:08 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:14:08 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:14:08 --> Session routines successfully run
DEBUG - 2016-08-30 22:14:08 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:14:08 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:14:08 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:14:08 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:14:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:14:08 --> Controller Class Initialized
DEBUG - 2016-08-30 22:14:08 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:14:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:14:08 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:14:08 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:14:08 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:14:08 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:14:08 --> Model Class Initialized
DEBUG - 2016-08-30 22:14:08 --> Model Class Initialized
DEBUG - 2016-08-30 22:14:08 --> Model Class Initialized
DEBUG - 2016-08-30 22:14:08 --> Model Class Initialized
DEBUG - 2016-08-30 22:14:08 --> Model Class Initialized
DEBUG - 2016-08-30 22:14:08 --> Model Class Initialized
DEBUG - 2016-08-30 22:14:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:14:08 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:14:08 --> Model Class Initialized
ERROR - 2016-08-30 22:14:08 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  column tr_pegawai_skpd_jabatan.id_pegawai does not exist
LINE 8: WHERE &quot;sc_sidika&quot;.&quot;tr_pegawai_skpd_jabatan&quot;.&quot;id_pegawai&quot; = '...
              ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-08-30 22:14:08 --> DB Transaction Failure
ERROR - 2016-08-30 22:14:08 --> Query error: ERROR:  column tr_pegawai_skpd_jabatan.id_pegawai does not exist
LINE 8: WHERE "sc_sidika"."tr_pegawai_skpd_jabatan"."id_pegawai" = '...
              ^
DEBUG - 2016-08-30 22:14:08 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-08-30 22:16:21 --> Config Class Initialized
DEBUG - 2016-08-30 22:16:21 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:16:21 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:16:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:16:21 --> URI Class Initialized
DEBUG - 2016-08-30 22:16:21 --> Router Class Initialized
DEBUG - 2016-08-30 22:16:21 --> Output Class Initialized
DEBUG - 2016-08-30 22:16:21 --> Security Class Initialized
DEBUG - 2016-08-30 22:16:21 --> Input Class Initialized
DEBUG - 2016-08-30 22:16:21 --> XSS Filtering completed
DEBUG - 2016-08-30 22:16:21 --> XSS Filtering completed
DEBUG - 2016-08-30 22:16:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:16:21 --> Language Class Initialized
DEBUG - 2016-08-30 22:16:22 --> Loader Class Initialized
DEBUG - 2016-08-30 22:16:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:16:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:16:22 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:16:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:16:22 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:16:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:16:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:16:22 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:16:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:16:22 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:16:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:16:22 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:16:22 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:16:22 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:16:22 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:16:22 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:16:22 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:16:22 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:16:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:16:22 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:16:22 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:16:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:16:22 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:16:22 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:16:22 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:16:22 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:16:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:16:22 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:16:22 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:16:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:16:22 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:16:22 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:16:22 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:16:22 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:16:22 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:16:22 --> Session Class Initialized
DEBUG - 2016-08-30 22:16:22 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:16:22 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:16:22 --> Session routines successfully run
DEBUG - 2016-08-30 22:16:22 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:16:22 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:16:22 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:16:23 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:16:23 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:16:23 --> Controller Class Initialized
DEBUG - 2016-08-30 22:16:23 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:16:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:16:23 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:16:23 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:16:23 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:16:23 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:16:23 --> Model Class Initialized
DEBUG - 2016-08-30 22:16:23 --> Model Class Initialized
DEBUG - 2016-08-30 22:16:23 --> Model Class Initialized
DEBUG - 2016-08-30 22:16:23 --> Model Class Initialized
DEBUG - 2016-08-30 22:16:23 --> Model Class Initialized
DEBUG - 2016-08-30 22:16:23 --> Model Class Initialized
DEBUG - 2016-08-30 22:16:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:16:23 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:16:23 --> Model Class Initialized
DEBUG - 2016-08-30 22:16:23 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:16:23 --> Model Class Initialized
ERROR - 2016-08-30 22:16:23 --> Severity: Notice  --> Undefined variable: force_limit E:\www\GitHub\2016APSIDIKA\application\models\model_tr_peserta_diklat.php 287
ERROR - 2016-08-30 22:16:23 --> Severity: Notice  --> Undefined variable: force_offset E:\www\GitHub\2016APSIDIKA\application\models\model_tr_peserta_diklat.php 287
DEBUG - 2016-08-30 22:16:23 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:17:40 --> Config Class Initialized
DEBUG - 2016-08-30 22:17:40 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:17:40 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:17:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:17:40 --> URI Class Initialized
DEBUG - 2016-08-30 22:17:40 --> Router Class Initialized
DEBUG - 2016-08-30 22:17:40 --> Output Class Initialized
DEBUG - 2016-08-30 22:17:40 --> Security Class Initialized
DEBUG - 2016-08-30 22:17:40 --> Input Class Initialized
DEBUG - 2016-08-30 22:17:40 --> XSS Filtering completed
DEBUG - 2016-08-30 22:17:40 --> XSS Filtering completed
DEBUG - 2016-08-30 22:17:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:17:41 --> Language Class Initialized
DEBUG - 2016-08-30 22:17:41 --> Loader Class Initialized
DEBUG - 2016-08-30 22:17:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:17:41 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:17:41 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:17:41 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:17:41 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:17:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:17:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:17:41 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:17:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:17:41 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:17:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:17:41 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:17:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:17:41 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:17:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:17:41 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:17:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:17:41 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:17:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:17:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:17:41 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:17:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:17:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:17:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:17:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:17:41 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:17:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:17:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:17:41 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:17:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:17:41 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:17:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:17:41 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:17:41 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:17:41 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:17:41 --> Session Class Initialized
DEBUG - 2016-08-30 22:17:41 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:17:42 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:17:42 --> Session routines successfully run
DEBUG - 2016-08-30 22:17:42 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:17:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:17:42 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:17:42 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:17:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:17:42 --> Controller Class Initialized
DEBUG - 2016-08-30 22:17:42 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:17:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:17:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:17:42 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:17:42 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:17:42 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:17:42 --> Model Class Initialized
DEBUG - 2016-08-30 22:17:42 --> Model Class Initialized
DEBUG - 2016-08-30 22:17:42 --> Model Class Initialized
DEBUG - 2016-08-30 22:17:42 --> Model Class Initialized
DEBUG - 2016-08-30 22:17:42 --> Model Class Initialized
DEBUG - 2016-08-30 22:17:42 --> Model Class Initialized
DEBUG - 2016-08-30 22:17:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:17:42 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:17:42 --> Model Class Initialized
DEBUG - 2016-08-30 22:17:42 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:17:42 --> Model Class Initialized
DEBUG - 2016-08-30 22:17:42 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:17:59 --> Config Class Initialized
DEBUG - 2016-08-30 22:17:59 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:17:59 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:17:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:17:59 --> URI Class Initialized
DEBUG - 2016-08-30 22:17:59 --> Router Class Initialized
DEBUG - 2016-08-30 22:17:59 --> Output Class Initialized
DEBUG - 2016-08-30 22:17:59 --> Security Class Initialized
DEBUG - 2016-08-30 22:17:59 --> Input Class Initialized
DEBUG - 2016-08-30 22:17:59 --> XSS Filtering completed
DEBUG - 2016-08-30 22:17:59 --> XSS Filtering completed
DEBUG - 2016-08-30 22:17:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:17:59 --> Language Class Initialized
DEBUG - 2016-08-30 22:17:59 --> Loader Class Initialized
DEBUG - 2016-08-30 22:17:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:17:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:17:59 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:17:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:17:59 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:17:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:17:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:17:59 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:17:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:18:00 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:18:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:18:00 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:18:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:18:00 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:18:00 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:18:00 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:18:00 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:18:00 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:18:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:18:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:18:00 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:18:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:18:00 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:18:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:18:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:18:00 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:18:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:18:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:18:00 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:18:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:18:00 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:18:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:18:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:18:00 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:18:00 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:18:00 --> Session Class Initialized
DEBUG - 2016-08-30 22:18:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:18:00 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:18:00 --> Session routines successfully run
DEBUG - 2016-08-30 22:18:00 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:18:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:18:00 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:18:00 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:18:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:18:00 --> Controller Class Initialized
DEBUG - 2016-08-30 22:18:01 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:18:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:18:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:18:01 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:18:01 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:18:01 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:18:01 --> Model Class Initialized
DEBUG - 2016-08-30 22:18:01 --> Model Class Initialized
DEBUG - 2016-08-30 22:18:01 --> Model Class Initialized
DEBUG - 2016-08-30 22:18:01 --> Model Class Initialized
DEBUG - 2016-08-30 22:18:01 --> Model Class Initialized
DEBUG - 2016-08-30 22:18:01 --> Model Class Initialized
DEBUG - 2016-08-30 22:18:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:18:01 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:18:01 --> Model Class Initialized
DEBUG - 2016-08-30 22:18:01 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:18:01 --> Model Class Initialized
DEBUG - 2016-08-30 22:18:01 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:18:03 --> Config Class Initialized
DEBUG - 2016-08-30 22:18:03 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:18:03 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:18:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:18:03 --> URI Class Initialized
DEBUG - 2016-08-30 22:18:03 --> Router Class Initialized
DEBUG - 2016-08-30 22:18:03 --> Output Class Initialized
DEBUG - 2016-08-30 22:18:03 --> Security Class Initialized
DEBUG - 2016-08-30 22:18:03 --> Input Class Initialized
DEBUG - 2016-08-30 22:18:03 --> XSS Filtering completed
DEBUG - 2016-08-30 22:18:03 --> XSS Filtering completed
DEBUG - 2016-08-30 22:18:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:18:03 --> Language Class Initialized
DEBUG - 2016-08-30 22:18:03 --> Loader Class Initialized
DEBUG - 2016-08-30 22:18:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:18:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:18:03 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:18:04 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:18:04 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:18:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:18:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:18:04 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:18:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:18:04 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:18:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:18:04 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:18:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:18:04 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:18:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:18:04 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:18:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:18:04 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:18:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:18:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:18:04 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:18:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:18:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:18:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:18:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:18:04 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:18:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:18:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:18:04 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:18:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:18:04 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:18:04 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:18:04 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:18:04 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:18:04 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:18:04 --> Session Class Initialized
DEBUG - 2016-08-30 22:18:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:18:04 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:18:04 --> Session routines successfully run
DEBUG - 2016-08-30 22:18:04 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:18:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:18:04 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:18:05 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:18:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:18:05 --> Controller Class Initialized
DEBUG - 2016-08-30 22:18:05 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:18:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:18:05 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:18:05 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:18:05 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:18:05 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:18:05 --> Model Class Initialized
DEBUG - 2016-08-30 22:18:05 --> Model Class Initialized
DEBUG - 2016-08-30 22:18:05 --> Model Class Initialized
DEBUG - 2016-08-30 22:18:05 --> Model Class Initialized
DEBUG - 2016-08-30 22:18:05 --> Model Class Initialized
DEBUG - 2016-08-30 22:18:05 --> Model Class Initialized
DEBUG - 2016-08-30 22:18:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:18:05 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:18:05 --> Model Class Initialized
DEBUG - 2016-08-30 22:18:05 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:18:05 --> Model Class Initialized
DEBUG - 2016-08-30 22:18:05 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:32:15 --> Config Class Initialized
DEBUG - 2016-08-30 22:32:15 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:32:15 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:32:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:32:15 --> URI Class Initialized
DEBUG - 2016-08-30 22:32:15 --> Router Class Initialized
DEBUG - 2016-08-30 22:32:15 --> Output Class Initialized
DEBUG - 2016-08-30 22:32:15 --> Security Class Initialized
DEBUG - 2016-08-30 22:32:15 --> Input Class Initialized
DEBUG - 2016-08-30 22:32:15 --> XSS Filtering completed
DEBUG - 2016-08-30 22:32:15 --> XSS Filtering completed
DEBUG - 2016-08-30 22:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:32:16 --> Language Class Initialized
DEBUG - 2016-08-30 22:32:16 --> Loader Class Initialized
DEBUG - 2016-08-30 22:32:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:32:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:32:16 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:32:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:32:16 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:32:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:32:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:32:16 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:32:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:32:16 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:32:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:32:16 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:32:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:32:16 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:32:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:32:16 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:32:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:32:16 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:32:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:32:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:32:16 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:32:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:32:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:32:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:32:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:32:16 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:32:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:32:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:32:16 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:32:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:32:16 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:32:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:32:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:32:16 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:32:16 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:32:16 --> Session Class Initialized
DEBUG - 2016-08-30 22:32:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:32:16 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:32:16 --> Session routines successfully run
DEBUG - 2016-08-30 22:32:16 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:32:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:32:16 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:32:16 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:32:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:32:16 --> Controller Class Initialized
DEBUG - 2016-08-30 22:32:16 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:32:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:32:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:32:17 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:32:17 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:32:17 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:32:17 --> Model Class Initialized
DEBUG - 2016-08-30 22:32:17 --> Model Class Initialized
DEBUG - 2016-08-30 22:32:17 --> Model Class Initialized
DEBUG - 2016-08-30 22:32:17 --> Model Class Initialized
DEBUG - 2016-08-30 22:32:17 --> Model Class Initialized
DEBUG - 2016-08-30 22:32:17 --> Model Class Initialized
DEBUG - 2016-08-30 22:32:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:32:17 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:32:17 --> Model Class Initialized
DEBUG - 2016-08-30 22:32:17 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:32:17 --> Model Class Initialized
DEBUG - 2016-08-30 22:32:17 --> Pagination class already loaded. Second attempt ignored.
ERROR - 2016-08-30 22:32:17 --> Severity: Notice  --> Undefined variable: keyword E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 22
DEBUG - 2016-08-30 22:32:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 22:32:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 22:32:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:32:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:32:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:32:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:32:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 22:32:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:32:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:32:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:32:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:32:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:32:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:32:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 22:32:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:32:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:32:17 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 22:32:17 --> Final output sent to browser
DEBUG - 2016-08-30 22:32:17 --> Total execution time: 1.6103
DEBUG - 2016-08-30 22:33:05 --> Config Class Initialized
DEBUG - 2016-08-30 22:33:05 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:33:05 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:33:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:33:05 --> URI Class Initialized
DEBUG - 2016-08-30 22:33:05 --> Router Class Initialized
DEBUG - 2016-08-30 22:33:05 --> Output Class Initialized
DEBUG - 2016-08-30 22:33:05 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:33:05 --> Security Class Initialized
DEBUG - 2016-08-30 22:33:05 --> Input Class Initialized
DEBUG - 2016-08-30 22:33:05 --> XSS Filtering completed
DEBUG - 2016-08-30 22:33:05 --> XSS Filtering completed
DEBUG - 2016-08-30 22:33:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:33:05 --> Language Class Initialized
DEBUG - 2016-08-30 22:33:05 --> Loader Class Initialized
DEBUG - 2016-08-30 22:33:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:33:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:33:05 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:33:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:33:06 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:33:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:33:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:33:06 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:33:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:33:06 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:33:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:33:06 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:33:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:33:06 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:33:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:33:06 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:33:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:33:06 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:33:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:33:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:33:06 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:33:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:33:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:33:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:33:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:33:06 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:33:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:33:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:33:06 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:33:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:33:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:33:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:33:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:33:06 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:33:06 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:33:06 --> Session Class Initialized
DEBUG - 2016-08-30 22:33:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:33:06 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:33:06 --> Session routines successfully run
DEBUG - 2016-08-30 22:33:06 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:33:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:33:06 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:33:06 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:33:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:33:06 --> Controller Class Initialized
DEBUG - 2016-08-30 22:33:06 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:33:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:33:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:33:06 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:33:06 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:33:06 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:33:07 --> Model Class Initialized
DEBUG - 2016-08-30 22:33:07 --> Model Class Initialized
DEBUG - 2016-08-30 22:33:07 --> Model Class Initialized
DEBUG - 2016-08-30 22:33:07 --> Model Class Initialized
DEBUG - 2016-08-30 22:33:07 --> Model Class Initialized
DEBUG - 2016-08-30 22:33:07 --> Model Class Initialized
DEBUG - 2016-08-30 22:33:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:33:07 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:33:07 --> Model Class Initialized
DEBUG - 2016-08-30 22:33:07 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:33:07 --> Model Class Initialized
DEBUG - 2016-08-30 22:33:07 --> Pagination class already loaded. Second attempt ignored.
ERROR - 2016-08-30 22:33:07 --> Severity: Notice  --> Undefined variable: keyword E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 23
DEBUG - 2016-08-30 22:33:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 22:33:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 22:33:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:33:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:33:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:33:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:33:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 22:33:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:33:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:33:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:33:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:33:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:33:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:33:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 22:33:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:33:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:33:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 22:33:07 --> Final output sent to browser
DEBUG - 2016-08-30 22:33:07 --> Total execution time: 1.6996
DEBUG - 2016-08-30 22:33:18 --> Config Class Initialized
DEBUG - 2016-08-30 22:33:18 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:33:18 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:33:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:33:18 --> URI Class Initialized
DEBUG - 2016-08-30 22:33:18 --> Router Class Initialized
DEBUG - 2016-08-30 22:33:18 --> Output Class Initialized
DEBUG - 2016-08-30 22:33:18 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:33:18 --> Security Class Initialized
DEBUG - 2016-08-30 22:33:18 --> Input Class Initialized
DEBUG - 2016-08-30 22:33:18 --> XSS Filtering completed
DEBUG - 2016-08-30 22:33:19 --> XSS Filtering completed
DEBUG - 2016-08-30 22:33:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:33:19 --> Language Class Initialized
DEBUG - 2016-08-30 22:33:19 --> Loader Class Initialized
DEBUG - 2016-08-30 22:33:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:33:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:33:19 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:33:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:33:19 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:33:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:33:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:33:19 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:33:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:33:19 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:33:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:33:19 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:33:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:33:19 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:33:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:33:19 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:33:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:33:19 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:33:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:33:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:33:19 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:33:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:33:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:33:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:33:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:33:19 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:33:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:33:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:33:19 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:33:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:33:19 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:33:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:33:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:33:19 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:33:19 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:33:19 --> Session Class Initialized
DEBUG - 2016-08-30 22:33:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:33:19 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:33:19 --> Session routines successfully run
DEBUG - 2016-08-30 22:33:19 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:33:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:33:19 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:33:20 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:33:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:33:20 --> Controller Class Initialized
DEBUG - 2016-08-30 22:33:20 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:33:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:33:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:33:20 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:33:20 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:33:20 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:33:20 --> Model Class Initialized
DEBUG - 2016-08-30 22:33:20 --> Model Class Initialized
DEBUG - 2016-08-30 22:33:20 --> Model Class Initialized
DEBUG - 2016-08-30 22:33:20 --> Model Class Initialized
DEBUG - 2016-08-30 22:33:20 --> Model Class Initialized
DEBUG - 2016-08-30 22:33:20 --> Model Class Initialized
DEBUG - 2016-08-30 22:33:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:33:20 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:33:20 --> Model Class Initialized
DEBUG - 2016-08-30 22:33:20 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:33:20 --> Model Class Initialized
DEBUG - 2016-08-30 22:33:20 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:33:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 22:33:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 22:33:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:33:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:33:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:33:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:33:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 22:33:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:33:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:33:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:33:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:33:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:33:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:33:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 22:33:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:33:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:33:20 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 22:33:20 --> Final output sent to browser
DEBUG - 2016-08-30 22:33:20 --> Total execution time: 1.7641
DEBUG - 2016-08-30 22:33:53 --> Config Class Initialized
DEBUG - 2016-08-30 22:33:53 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:33:53 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:33:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:33:53 --> URI Class Initialized
DEBUG - 2016-08-30 22:33:53 --> Router Class Initialized
DEBUG - 2016-08-30 22:33:53 --> Output Class Initialized
DEBUG - 2016-08-30 22:33:53 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:33:53 --> Security Class Initialized
DEBUG - 2016-08-30 22:33:53 --> Input Class Initialized
DEBUG - 2016-08-30 22:33:53 --> XSS Filtering completed
DEBUG - 2016-08-30 22:33:53 --> XSS Filtering completed
DEBUG - 2016-08-30 22:33:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:33:53 --> Language Class Initialized
DEBUG - 2016-08-30 22:33:53 --> Loader Class Initialized
DEBUG - 2016-08-30 22:33:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:33:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:33:53 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:33:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:33:53 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:33:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:33:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:33:53 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:33:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:33:53 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:33:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:33:53 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:33:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:33:53 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:33:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:33:54 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:33:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:33:54 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:33:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:33:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:33:54 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:33:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:33:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:33:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:33:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:33:54 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:33:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:33:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:33:54 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:33:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:33:54 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:33:54 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:33:54 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:33:54 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:33:54 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:33:54 --> Session Class Initialized
DEBUG - 2016-08-30 22:33:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:33:54 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:33:54 --> Session routines successfully run
DEBUG - 2016-08-30 22:33:54 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:33:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:33:54 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:33:54 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:33:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:33:54 --> Controller Class Initialized
DEBUG - 2016-08-30 22:33:54 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:33:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:33:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:33:54 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:33:54 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:33:54 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:33:54 --> Model Class Initialized
DEBUG - 2016-08-30 22:33:54 --> Model Class Initialized
DEBUG - 2016-08-30 22:33:54 --> Model Class Initialized
DEBUG - 2016-08-30 22:33:54 --> Model Class Initialized
DEBUG - 2016-08-30 22:33:54 --> Model Class Initialized
DEBUG - 2016-08-30 22:33:54 --> Model Class Initialized
DEBUG - 2016-08-30 22:33:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:33:55 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:33:55 --> Model Class Initialized
DEBUG - 2016-08-30 22:33:55 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:33:55 --> Model Class Initialized
DEBUG - 2016-08-30 22:33:55 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:33:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 22:33:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 22:33:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:33:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:33:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:33:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:33:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 22:33:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:33:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:33:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:33:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:33:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:33:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:33:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 22:33:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:33:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:33:55 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 22:33:55 --> Final output sent to browser
DEBUG - 2016-08-30 22:33:55 --> Total execution time: 1.7546
DEBUG - 2016-08-30 22:34:15 --> Config Class Initialized
DEBUG - 2016-08-30 22:34:15 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:34:15 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:34:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:34:15 --> URI Class Initialized
DEBUG - 2016-08-30 22:34:15 --> Router Class Initialized
DEBUG - 2016-08-30 22:34:15 --> Output Class Initialized
DEBUG - 2016-08-30 22:34:15 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:34:15 --> Security Class Initialized
DEBUG - 2016-08-30 22:34:15 --> Input Class Initialized
DEBUG - 2016-08-30 22:34:15 --> XSS Filtering completed
DEBUG - 2016-08-30 22:34:15 --> XSS Filtering completed
DEBUG - 2016-08-30 22:34:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:34:15 --> Language Class Initialized
DEBUG - 2016-08-30 22:34:15 --> Loader Class Initialized
DEBUG - 2016-08-30 22:34:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:34:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:34:15 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:34:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:34:15 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:34:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:34:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:34:15 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:34:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:34:15 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:34:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:34:15 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:34:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:34:15 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:34:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:34:15 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:34:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:34:15 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:34:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:34:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:34:15 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:34:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:34:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:34:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:34:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:34:16 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:34:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:34:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:34:16 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:34:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:34:16 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:34:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:34:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:34:16 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:34:16 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:34:16 --> Session Class Initialized
DEBUG - 2016-08-30 22:34:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:34:16 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:34:16 --> Session routines successfully run
DEBUG - 2016-08-30 22:34:16 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:34:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:34:16 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:34:16 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:34:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:34:16 --> Controller Class Initialized
DEBUG - 2016-08-30 22:34:16 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:34:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:34:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:34:16 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:34:16 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:34:16 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:34:16 --> Model Class Initialized
DEBUG - 2016-08-30 22:34:16 --> Model Class Initialized
DEBUG - 2016-08-30 22:34:16 --> Model Class Initialized
DEBUG - 2016-08-30 22:34:16 --> Model Class Initialized
DEBUG - 2016-08-30 22:34:16 --> Model Class Initialized
DEBUG - 2016-08-30 22:34:16 --> Model Class Initialized
DEBUG - 2016-08-30 22:34:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:34:16 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:34:16 --> Model Class Initialized
DEBUG - 2016-08-30 22:34:16 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:34:16 --> Model Class Initialized
DEBUG - 2016-08-30 22:34:16 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:34:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 22:34:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 22:34:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:34:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:34:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:34:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:34:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 22:34:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:34:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:34:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:34:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:34:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:34:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:34:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 22:34:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:34:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:34:17 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 22:34:17 --> Final output sent to browser
DEBUG - 2016-08-30 22:34:17 --> Total execution time: 1.7673
DEBUG - 2016-08-30 22:34:52 --> Config Class Initialized
DEBUG - 2016-08-30 22:34:52 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:34:52 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:34:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:34:52 --> URI Class Initialized
DEBUG - 2016-08-30 22:34:52 --> Router Class Initialized
DEBUG - 2016-08-30 22:34:52 --> Output Class Initialized
DEBUG - 2016-08-30 22:34:52 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:34:52 --> Security Class Initialized
DEBUG - 2016-08-30 22:34:52 --> Input Class Initialized
DEBUG - 2016-08-30 22:34:52 --> XSS Filtering completed
DEBUG - 2016-08-30 22:34:52 --> XSS Filtering completed
DEBUG - 2016-08-30 22:34:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:34:52 --> Language Class Initialized
DEBUG - 2016-08-30 22:34:52 --> Loader Class Initialized
DEBUG - 2016-08-30 22:34:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:34:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:34:52 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:34:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:34:52 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:34:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:34:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:34:52 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:34:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:34:52 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:34:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:34:52 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:34:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:34:52 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:34:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:34:52 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:34:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:34:52 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:34:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:34:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:34:52 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:34:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:34:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:34:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:34:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:34:52 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:34:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:34:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:34:52 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:34:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:34:52 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:34:53 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:34:53 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:34:53 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:34:53 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:34:53 --> Session Class Initialized
DEBUG - 2016-08-30 22:34:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:34:53 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:34:53 --> Session routines successfully run
DEBUG - 2016-08-30 22:34:53 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:34:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:34:53 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:34:53 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:34:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:34:53 --> Controller Class Initialized
DEBUG - 2016-08-30 22:34:53 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:34:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:34:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:34:53 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:34:53 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:34:53 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:34:53 --> Model Class Initialized
DEBUG - 2016-08-30 22:34:53 --> Model Class Initialized
DEBUG - 2016-08-30 22:34:53 --> Model Class Initialized
DEBUG - 2016-08-30 22:34:53 --> Model Class Initialized
DEBUG - 2016-08-30 22:34:53 --> Model Class Initialized
DEBUG - 2016-08-30 22:34:53 --> Model Class Initialized
DEBUG - 2016-08-30 22:34:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:34:53 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:34:53 --> Model Class Initialized
DEBUG - 2016-08-30 22:34:53 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:34:53 --> Model Class Initialized
DEBUG - 2016-08-30 22:34:53 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:34:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 22:34:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 22:34:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:34:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:34:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:34:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:34:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 22:34:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:34:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:34:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:34:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:34:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:34:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:34:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 22:34:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:34:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:34:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 22:34:54 --> Final output sent to browser
DEBUG - 2016-08-30 22:34:54 --> Total execution time: 1.7621
DEBUG - 2016-08-30 22:40:27 --> Config Class Initialized
DEBUG - 2016-08-30 22:40:27 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:40:27 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:40:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:40:27 --> URI Class Initialized
DEBUG - 2016-08-30 22:40:28 --> Router Class Initialized
DEBUG - 2016-08-30 22:40:28 --> Output Class Initialized
DEBUG - 2016-08-30 22:40:28 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:40:28 --> Security Class Initialized
DEBUG - 2016-08-30 22:40:28 --> Input Class Initialized
DEBUG - 2016-08-30 22:40:28 --> XSS Filtering completed
DEBUG - 2016-08-30 22:40:28 --> XSS Filtering completed
DEBUG - 2016-08-30 22:40:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:40:28 --> Language Class Initialized
DEBUG - 2016-08-30 22:40:28 --> Loader Class Initialized
DEBUG - 2016-08-30 22:40:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:40:28 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:40:28 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:40:28 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:40:28 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:40:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:40:28 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:40:28 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:40:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:40:28 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:40:28 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:40:28 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:40:28 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:40:28 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:40:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:40:28 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:40:28 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:40:28 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:40:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:40:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:40:28 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:40:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:40:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:40:28 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:40:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:40:28 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:40:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:40:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:40:28 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:40:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:40:28 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:40:28 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:40:28 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:40:28 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:40:28 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:40:29 --> Session Class Initialized
DEBUG - 2016-08-30 22:40:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:40:29 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:40:29 --> Session routines successfully run
DEBUG - 2016-08-30 22:40:29 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:40:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:40:29 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:40:29 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:40:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:40:29 --> Controller Class Initialized
DEBUG - 2016-08-30 22:40:29 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:40:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:40:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:40:29 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:40:29 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:40:29 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:40:29 --> Model Class Initialized
DEBUG - 2016-08-30 22:40:29 --> Model Class Initialized
DEBUG - 2016-08-30 22:40:29 --> Model Class Initialized
DEBUG - 2016-08-30 22:40:29 --> Model Class Initialized
DEBUG - 2016-08-30 22:40:29 --> Model Class Initialized
DEBUG - 2016-08-30 22:40:29 --> Model Class Initialized
DEBUG - 2016-08-30 22:40:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:40:29 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:40:29 --> Model Class Initialized
DEBUG - 2016-08-30 22:40:29 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:40:29 --> Model Class Initialized
DEBUG - 2016-08-30 22:40:29 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:40:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 22:40:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 22:40:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:40:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:40:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:40:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:40:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 22:40:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:40:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:40:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:40:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:40:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:40:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:40:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 22:40:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:40:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:40:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 22:40:30 --> Final output sent to browser
DEBUG - 2016-08-30 22:40:30 --> Total execution time: 1.7984
DEBUG - 2016-08-30 22:41:05 --> Config Class Initialized
DEBUG - 2016-08-30 22:41:05 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:41:05 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:41:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:41:05 --> URI Class Initialized
DEBUG - 2016-08-30 22:41:05 --> Router Class Initialized
DEBUG - 2016-08-30 22:41:05 --> Output Class Initialized
DEBUG - 2016-08-30 22:41:05 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:41:05 --> Security Class Initialized
DEBUG - 2016-08-30 22:41:05 --> Input Class Initialized
DEBUG - 2016-08-30 22:41:05 --> XSS Filtering completed
DEBUG - 2016-08-30 22:41:05 --> XSS Filtering completed
DEBUG - 2016-08-30 22:41:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:41:05 --> Language Class Initialized
DEBUG - 2016-08-30 22:41:05 --> Loader Class Initialized
DEBUG - 2016-08-30 22:41:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:41:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:41:05 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:41:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:41:05 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:41:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:41:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:41:05 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:41:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:41:05 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:41:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:41:05 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:41:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:41:05 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:41:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:41:05 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:41:05 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:41:05 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:41:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:41:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:41:05 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:41:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:41:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:41:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:41:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:41:05 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:41:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:41:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:41:05 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:41:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:41:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:41:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:41:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:41:06 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:41:06 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:41:06 --> Session Class Initialized
DEBUG - 2016-08-30 22:41:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:41:06 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:41:06 --> Session routines successfully run
DEBUG - 2016-08-30 22:41:06 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:41:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:41:06 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:41:06 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:41:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:41:06 --> Controller Class Initialized
DEBUG - 2016-08-30 22:41:06 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:41:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:41:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:41:06 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:41:06 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:41:06 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:41:06 --> Model Class Initialized
DEBUG - 2016-08-30 22:41:06 --> Model Class Initialized
DEBUG - 2016-08-30 22:41:06 --> Model Class Initialized
DEBUG - 2016-08-30 22:41:06 --> Model Class Initialized
DEBUG - 2016-08-30 22:41:06 --> Model Class Initialized
DEBUG - 2016-08-30 22:41:06 --> Model Class Initialized
DEBUG - 2016-08-30 22:41:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:41:06 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:41:06 --> Model Class Initialized
DEBUG - 2016-08-30 22:41:06 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:41:06 --> Model Class Initialized
DEBUG - 2016-08-30 22:41:06 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:41:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 22:41:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 22:41:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 22:41:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 22:41:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:41:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:41:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:41:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:41:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 22:41:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:41:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:41:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:41:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:41:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:41:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:41:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 22:41:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:41:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:41:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 22:41:07 --> Final output sent to browser
DEBUG - 2016-08-30 22:41:07 --> Total execution time: 1.8127
DEBUG - 2016-08-30 22:42:47 --> Config Class Initialized
DEBUG - 2016-08-30 22:42:47 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:42:47 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:42:47 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:42:47 --> URI Class Initialized
DEBUG - 2016-08-30 22:42:47 --> Router Class Initialized
DEBUG - 2016-08-30 22:42:47 --> Output Class Initialized
DEBUG - 2016-08-30 22:42:47 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:42:47 --> Security Class Initialized
DEBUG - 2016-08-30 22:42:47 --> Input Class Initialized
DEBUG - 2016-08-30 22:42:47 --> XSS Filtering completed
DEBUG - 2016-08-30 22:42:47 --> XSS Filtering completed
DEBUG - 2016-08-30 22:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:42:47 --> Language Class Initialized
DEBUG - 2016-08-30 22:42:47 --> Loader Class Initialized
DEBUG - 2016-08-30 22:42:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:42:47 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:42:47 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:42:47 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:42:47 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:42:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:42:47 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:42:47 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:42:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:42:48 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:42:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:42:48 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:42:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:42:48 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:42:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:42:48 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:42:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:42:48 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:42:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:42:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:42:48 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:42:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:42:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:42:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:42:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:42:48 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:42:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:42:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:42:48 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:42:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:42:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:42:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:42:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:42:48 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:42:48 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:42:48 --> Session Class Initialized
DEBUG - 2016-08-30 22:42:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:42:48 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:42:48 --> Session routines successfully run
DEBUG - 2016-08-30 22:42:48 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:42:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:42:48 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:42:48 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:42:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:42:48 --> Controller Class Initialized
DEBUG - 2016-08-30 22:42:48 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:42:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:42:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:42:48 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:42:48 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:42:48 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:42:48 --> Model Class Initialized
DEBUG - 2016-08-30 22:42:49 --> Model Class Initialized
DEBUG - 2016-08-30 22:42:49 --> Model Class Initialized
DEBUG - 2016-08-30 22:42:49 --> Model Class Initialized
DEBUG - 2016-08-30 22:42:49 --> Model Class Initialized
DEBUG - 2016-08-30 22:42:49 --> Model Class Initialized
DEBUG - 2016-08-30 22:42:49 --> Model Class Initialized
DEBUG - 2016-08-30 22:42:49 --> Model Class Initialized
DEBUG - 2016-08-30 22:42:49 --> Model Class Initialized
DEBUG - 2016-08-30 22:42:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:42:49 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:42:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 22:42:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-30 22:42:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:42:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:42:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:42:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:42:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-30 22:42:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:42:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:42:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:42:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:42:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:42:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:42:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-30 22:42:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:42:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:42:49 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-30 22:42:49 --> Final output sent to browser
DEBUG - 2016-08-30 22:42:49 --> Total execution time: 1.8426
DEBUG - 2016-08-30 22:42:51 --> Config Class Initialized
DEBUG - 2016-08-30 22:42:51 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:42:51 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:42:51 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:42:51 --> URI Class Initialized
DEBUG - 2016-08-30 22:42:51 --> Router Class Initialized
DEBUG - 2016-08-30 22:42:52 --> Output Class Initialized
DEBUG - 2016-08-30 22:42:52 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:42:52 --> Security Class Initialized
DEBUG - 2016-08-30 22:42:52 --> Input Class Initialized
DEBUG - 2016-08-30 22:42:52 --> XSS Filtering completed
DEBUG - 2016-08-30 22:42:52 --> XSS Filtering completed
DEBUG - 2016-08-30 22:42:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:42:52 --> Language Class Initialized
DEBUG - 2016-08-30 22:42:52 --> Loader Class Initialized
DEBUG - 2016-08-30 22:42:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:42:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:42:52 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:42:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:42:52 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:42:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:42:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:42:52 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:42:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:42:52 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:42:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:42:52 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:42:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:42:52 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:42:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:42:52 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:42:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:42:52 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:42:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:42:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:42:52 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:42:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:42:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:42:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:42:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:42:52 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:42:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:42:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:42:52 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:42:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:42:52 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:42:52 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:42:53 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:42:53 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:42:53 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:42:53 --> Session Class Initialized
DEBUG - 2016-08-30 22:42:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:42:53 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:42:53 --> Session routines successfully run
DEBUG - 2016-08-30 22:42:53 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:42:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:42:53 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:42:53 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:42:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:42:53 --> Controller Class Initialized
DEBUG - 2016-08-30 22:42:53 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:42:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:42:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:42:53 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:42:53 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:42:53 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:42:53 --> Model Class Initialized
DEBUG - 2016-08-30 22:42:53 --> Model Class Initialized
DEBUG - 2016-08-30 22:42:53 --> Model Class Initialized
DEBUG - 2016-08-30 22:42:53 --> Model Class Initialized
DEBUG - 2016-08-30 22:42:53 --> Model Class Initialized
DEBUG - 2016-08-30 22:42:53 --> Model Class Initialized
DEBUG - 2016-08-30 22:42:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:42:53 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:42:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 22:42:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-30 22:42:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:42:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:42:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:42:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:42:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-30 22:42:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:42:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:42:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:42:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:42:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:42:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:42:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-30 22:42:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:42:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:42:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6ab6771ae9d42e25effdc2b45133f90d
DEBUG - 2016-08-30 22:42:54 --> Final output sent to browser
DEBUG - 2016-08-30 22:42:54 --> Total execution time: 1.8358
DEBUG - 2016-08-30 22:42:56 --> Config Class Initialized
DEBUG - 2016-08-30 22:42:56 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:42:56 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:42:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:42:56 --> URI Class Initialized
DEBUG - 2016-08-30 22:42:56 --> Router Class Initialized
DEBUG - 2016-08-30 22:42:56 --> Output Class Initialized
DEBUG - 2016-08-30 22:42:56 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:42:56 --> Security Class Initialized
DEBUG - 2016-08-30 22:42:56 --> Input Class Initialized
DEBUG - 2016-08-30 22:42:56 --> XSS Filtering completed
DEBUG - 2016-08-30 22:42:56 --> XSS Filtering completed
DEBUG - 2016-08-30 22:42:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:42:56 --> Language Class Initialized
DEBUG - 2016-08-30 22:42:56 --> Loader Class Initialized
DEBUG - 2016-08-30 22:42:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:42:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:42:56 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:42:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:42:56 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:42:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:42:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:42:56 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:42:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:42:56 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:42:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:42:56 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:42:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:42:56 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:42:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:42:56 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:42:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:42:56 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:42:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:42:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:42:56 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:42:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:42:56 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:42:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:42:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:42:57 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:42:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:42:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:42:57 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:42:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:42:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:42:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:42:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:42:57 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:42:57 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:42:57 --> Session Class Initialized
DEBUG - 2016-08-30 22:42:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:42:57 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:42:57 --> Session routines successfully run
DEBUG - 2016-08-30 22:42:57 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:42:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:42:57 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:42:57 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:42:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:42:57 --> Controller Class Initialized
DEBUG - 2016-08-30 22:42:57 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:42:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:42:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:42:57 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:42:57 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:42:57 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:42:57 --> Model Class Initialized
DEBUG - 2016-08-30 22:42:57 --> Model Class Initialized
DEBUG - 2016-08-30 22:42:57 --> Model Class Initialized
DEBUG - 2016-08-30 22:42:57 --> Model Class Initialized
DEBUG - 2016-08-30 22:42:57 --> Model Class Initialized
DEBUG - 2016-08-30 22:42:57 --> Model Class Initialized
DEBUG - 2016-08-30 22:42:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 22:42:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/detail.php
DEBUG - 2016-08-30 22:42:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:42:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:42:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:42:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:42:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_js.php
DEBUG - 2016-08-30 22:42:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_isian_js.php
DEBUG - 2016-08-30 22:42:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:42:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:42:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:42:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:42:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:42:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:42:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_js.php
DEBUG - 2016-08-30 22:42:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_isian_js.php
DEBUG - 2016-08-30 22:42:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:42:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:42:58 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/a181d4a679e6905a87ac04b152de0aae
DEBUG - 2016-08-30 22:42:58 --> Final output sent to browser
DEBUG - 2016-08-30 22:42:58 --> Total execution time: 1.8675
DEBUG - 2016-08-30 22:43:53 --> Config Class Initialized
DEBUG - 2016-08-30 22:43:53 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:43:53 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:43:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:43:53 --> URI Class Initialized
DEBUG - 2016-08-30 22:43:53 --> Router Class Initialized
DEBUG - 2016-08-30 22:43:53 --> Output Class Initialized
DEBUG - 2016-08-30 22:43:53 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:43:53 --> Security Class Initialized
DEBUG - 2016-08-30 22:43:54 --> Input Class Initialized
DEBUG - 2016-08-30 22:43:54 --> XSS Filtering completed
DEBUG - 2016-08-30 22:43:54 --> XSS Filtering completed
DEBUG - 2016-08-30 22:43:54 --> XSS Filtering completed
DEBUG - 2016-08-30 22:43:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:43:54 --> Language Class Initialized
DEBUG - 2016-08-30 22:43:54 --> Loader Class Initialized
DEBUG - 2016-08-30 22:43:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:43:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:43:54 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:43:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:43:54 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:43:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:43:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:43:54 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:43:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:43:54 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:43:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:43:54 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:43:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:43:54 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:43:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:43:54 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:43:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:43:54 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:43:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:43:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:43:54 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:43:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:43:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:43:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:43:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:43:54 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:43:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:43:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:43:54 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:43:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:43:54 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:43:54 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:43:54 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:43:54 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:43:54 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:43:55 --> Session Class Initialized
DEBUG - 2016-08-30 22:43:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:43:55 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:43:55 --> Session routines successfully run
DEBUG - 2016-08-30 22:43:55 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:43:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:43:55 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:43:55 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:43:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:43:55 --> Controller Class Initialized
DEBUG - 2016-08-30 22:43:55 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:43:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:43:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:43:55 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:43:55 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:43:55 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:43:55 --> Model Class Initialized
DEBUG - 2016-08-30 22:43:55 --> Model Class Initialized
DEBUG - 2016-08-30 22:43:55 --> Model Class Initialized
DEBUG - 2016-08-30 22:43:55 --> Model Class Initialized
DEBUG - 2016-08-30 22:43:55 --> Model Class Initialized
DEBUG - 2016-08-30 22:43:55 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b5e3eebbe550cd93afc20ddd83908c3b
DEBUG - 2016-08-30 22:43:55 --> Final output sent to browser
DEBUG - 2016-08-30 22:43:55 --> Total execution time: 1.8705
DEBUG - 2016-08-30 22:43:56 --> Config Class Initialized
DEBUG - 2016-08-30 22:43:56 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:43:56 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:43:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:43:56 --> URI Class Initialized
DEBUG - 2016-08-30 22:43:56 --> Router Class Initialized
DEBUG - 2016-08-30 22:43:56 --> Output Class Initialized
DEBUG - 2016-08-30 22:43:56 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:43:56 --> Security Class Initialized
DEBUG - 2016-08-30 22:43:56 --> Input Class Initialized
DEBUG - 2016-08-30 22:43:56 --> XSS Filtering completed
DEBUG - 2016-08-30 22:43:56 --> XSS Filtering completed
DEBUG - 2016-08-30 22:43:56 --> XSS Filtering completed
DEBUG - 2016-08-30 22:43:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:43:56 --> Language Class Initialized
DEBUG - 2016-08-30 22:43:56 --> Loader Class Initialized
DEBUG - 2016-08-30 22:43:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:43:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:43:56 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:43:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:43:56 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:43:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:43:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:43:56 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:43:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:43:56 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:43:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:43:56 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:43:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:43:56 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:43:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:43:56 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:43:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:43:56 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:43:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:43:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:43:57 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:43:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:43:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:43:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:43:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:43:57 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:43:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:43:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:43:57 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:43:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:43:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:43:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:43:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:43:57 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:43:57 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:43:57 --> Session Class Initialized
DEBUG - 2016-08-30 22:43:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:43:57 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:43:57 --> Session routines successfully run
DEBUG - 2016-08-30 22:43:57 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:43:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:43:57 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:43:57 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:43:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:43:57 --> Controller Class Initialized
DEBUG - 2016-08-30 22:43:57 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:43:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:43:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:43:57 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:43:57 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:43:57 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:43:57 --> Model Class Initialized
DEBUG - 2016-08-30 22:43:57 --> Model Class Initialized
DEBUG - 2016-08-30 22:43:57 --> Model Class Initialized
DEBUG - 2016-08-30 22:43:57 --> Model Class Initialized
DEBUG - 2016-08-30 22:43:57 --> Model Class Initialized
DEBUG - 2016-08-30 22:43:58 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b5e3eebbe550cd93afc20ddd83908c3b
DEBUG - 2016-08-30 22:43:58 --> Final output sent to browser
DEBUG - 2016-08-30 22:43:58 --> Total execution time: 1.8495
DEBUG - 2016-08-30 22:43:59 --> Config Class Initialized
DEBUG - 2016-08-30 22:43:59 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:43:59 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:43:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:43:59 --> URI Class Initialized
DEBUG - 2016-08-30 22:43:59 --> Router Class Initialized
DEBUG - 2016-08-30 22:43:59 --> Output Class Initialized
DEBUG - 2016-08-30 22:43:59 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:43:59 --> Security Class Initialized
DEBUG - 2016-08-30 22:43:59 --> Input Class Initialized
DEBUG - 2016-08-30 22:43:59 --> XSS Filtering completed
DEBUG - 2016-08-30 22:43:59 --> XSS Filtering completed
DEBUG - 2016-08-30 22:43:59 --> XSS Filtering completed
DEBUG - 2016-08-30 22:43:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:43:59 --> Language Class Initialized
DEBUG - 2016-08-30 22:43:59 --> Loader Class Initialized
DEBUG - 2016-08-30 22:43:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:43:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:43:59 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:43:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:43:59 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:43:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:43:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:43:59 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:43:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:44:00 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:44:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:44:00 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:44:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:44:00 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:44:00 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:44:00 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:44:00 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:44:00 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:44:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:44:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:44:00 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:44:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:44:00 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:44:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:44:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:44:00 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:44:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:44:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:44:00 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:44:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:44:00 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:44:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:44:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:44:00 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:44:00 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:44:00 --> Session Class Initialized
DEBUG - 2016-08-30 22:44:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:44:00 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:44:00 --> Session routines successfully run
DEBUG - 2016-08-30 22:44:00 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:44:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:44:00 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:44:00 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:44:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:44:00 --> Controller Class Initialized
DEBUG - 2016-08-30 22:44:00 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:44:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:44:00 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:44:00 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:44:01 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:44:01 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:44:01 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:01 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:01 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:01 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:01 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:01 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1ae1cad65d2be9e2d395bd427adbef6f
DEBUG - 2016-08-30 22:44:01 --> Final output sent to browser
DEBUG - 2016-08-30 22:44:01 --> Total execution time: 1.9210
DEBUG - 2016-08-30 22:44:05 --> Config Class Initialized
DEBUG - 2016-08-30 22:44:05 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:44:05 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:44:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:44:05 --> URI Class Initialized
DEBUG - 2016-08-30 22:44:05 --> Router Class Initialized
DEBUG - 2016-08-30 22:44:05 --> Output Class Initialized
DEBUG - 2016-08-30 22:44:05 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:44:05 --> Security Class Initialized
DEBUG - 2016-08-30 22:44:05 --> Input Class Initialized
DEBUG - 2016-08-30 22:44:05 --> XSS Filtering completed
DEBUG - 2016-08-30 22:44:06 --> XSS Filtering completed
DEBUG - 2016-08-30 22:44:06 --> XSS Filtering completed
DEBUG - 2016-08-30 22:44:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:44:06 --> Language Class Initialized
DEBUG - 2016-08-30 22:44:06 --> Loader Class Initialized
DEBUG - 2016-08-30 22:44:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:44:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:44:06 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:44:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:44:06 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:44:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:44:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:44:06 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:44:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:44:06 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:44:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:44:06 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:44:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:44:06 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:44:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:44:06 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:44:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:44:06 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:44:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:44:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:44:06 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:44:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:44:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:44:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:44:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:44:06 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:44:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:44:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:44:06 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:44:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:44:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:44:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:44:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:44:06 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:44:06 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:44:07 --> Session Class Initialized
DEBUG - 2016-08-30 22:44:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:44:07 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:44:07 --> Session routines successfully run
DEBUG - 2016-08-30 22:44:07 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:44:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:44:07 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:44:07 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:44:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:44:07 --> Controller Class Initialized
DEBUG - 2016-08-30 22:44:07 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:44:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:44:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:44:07 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:44:07 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:44:07 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:44:07 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:07 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:07 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:07 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:07 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1ae1cad65d2be9e2d395bd427adbef6f
DEBUG - 2016-08-30 22:44:07 --> Final output sent to browser
DEBUG - 2016-08-30 22:44:07 --> Total execution time: 1.8182
DEBUG - 2016-08-30 22:44:11 --> Config Class Initialized
DEBUG - 2016-08-30 22:44:11 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:44:11 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:44:11 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:44:11 --> URI Class Initialized
DEBUG - 2016-08-30 22:44:11 --> Router Class Initialized
DEBUG - 2016-08-30 22:44:11 --> Output Class Initialized
DEBUG - 2016-08-30 22:44:11 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:44:11 --> Security Class Initialized
DEBUG - 2016-08-30 22:44:11 --> Input Class Initialized
DEBUG - 2016-08-30 22:44:11 --> XSS Filtering completed
DEBUG - 2016-08-30 22:44:11 --> XSS Filtering completed
DEBUG - 2016-08-30 22:44:11 --> XSS Filtering completed
DEBUG - 2016-08-30 22:44:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:44:12 --> Language Class Initialized
DEBUG - 2016-08-30 22:44:12 --> Loader Class Initialized
DEBUG - 2016-08-30 22:44:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:44:12 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:44:12 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:44:12 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:44:12 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:44:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:44:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:44:12 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:44:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:44:12 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:44:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:44:12 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:44:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:44:12 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:44:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:44:12 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:44:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:44:12 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:44:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:44:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:44:12 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:44:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:44:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:44:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:44:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:44:12 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:44:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:44:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:44:12 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:44:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:44:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:44:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:44:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:44:12 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:44:12 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:44:12 --> Session Class Initialized
DEBUG - 2016-08-30 22:44:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:44:13 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:44:13 --> Session routines successfully run
DEBUG - 2016-08-30 22:44:13 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:44:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:44:13 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:44:13 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:44:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:44:13 --> Controller Class Initialized
DEBUG - 2016-08-30 22:44:13 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:44:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:44:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:44:13 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:44:13 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:44:13 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:44:13 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:13 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:13 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:13 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:13 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:13 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/3986b17e67923511ff75332baca04769
DEBUG - 2016-08-30 22:44:13 --> Final output sent to browser
DEBUG - 2016-08-30 22:44:13 --> Total execution time: 1.8763
DEBUG - 2016-08-30 22:44:23 --> Config Class Initialized
DEBUG - 2016-08-30 22:44:23 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:44:23 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:44:23 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:44:23 --> URI Class Initialized
DEBUG - 2016-08-30 22:44:23 --> Router Class Initialized
DEBUG - 2016-08-30 22:44:23 --> Output Class Initialized
DEBUG - 2016-08-30 22:44:23 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:44:23 --> Security Class Initialized
DEBUG - 2016-08-30 22:44:23 --> Input Class Initialized
DEBUG - 2016-08-30 22:44:23 --> XSS Filtering completed
DEBUG - 2016-08-30 22:44:23 --> XSS Filtering completed
DEBUG - 2016-08-30 22:44:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:44:23 --> Language Class Initialized
DEBUG - 2016-08-30 22:44:23 --> Loader Class Initialized
DEBUG - 2016-08-30 22:44:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:44:23 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:44:23 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:44:23 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:44:23 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:44:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:44:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:44:24 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:44:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:44:24 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:44:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:44:24 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:44:24 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:44:24 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:44:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:44:24 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:44:24 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:44:24 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:44:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:44:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:44:24 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:44:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:44:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:44:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:44:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:44:24 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:44:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:44:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:44:24 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:44:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:44:24 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:44:24 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:44:24 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:44:24 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:44:24 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:44:24 --> Session Class Initialized
DEBUG - 2016-08-30 22:44:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:44:24 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:44:24 --> Session routines successfully run
DEBUG - 2016-08-30 22:44:24 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:44:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:44:24 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:44:24 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:44:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:44:25 --> Controller Class Initialized
DEBUG - 2016-08-30 22:44:25 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:44:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:44:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:44:25 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:44:25 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:44:25 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:44:25 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:25 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:25 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:25 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:25 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:25 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:25 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:25 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:25 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:44:25 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:44:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 22:44:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-30 22:44:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:44:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:44:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:44:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:44:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-30 22:44:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:44:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:44:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:44:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:44:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:44:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:44:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-30 22:44:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:44:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:44:25 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-30 22:44:25 --> Final output sent to browser
DEBUG - 2016-08-30 22:44:26 --> Total execution time: 2.0935
DEBUG - 2016-08-30 22:44:28 --> Config Class Initialized
DEBUG - 2016-08-30 22:44:28 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:44:28 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:44:28 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:44:28 --> URI Class Initialized
DEBUG - 2016-08-30 22:44:28 --> Router Class Initialized
DEBUG - 2016-08-30 22:44:28 --> Output Class Initialized
DEBUG - 2016-08-30 22:44:28 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:44:28 --> Security Class Initialized
DEBUG - 2016-08-30 22:44:28 --> Input Class Initialized
DEBUG - 2016-08-30 22:44:28 --> XSS Filtering completed
DEBUG - 2016-08-30 22:44:28 --> XSS Filtering completed
DEBUG - 2016-08-30 22:44:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:44:29 --> Language Class Initialized
DEBUG - 2016-08-30 22:44:29 --> Loader Class Initialized
DEBUG - 2016-08-30 22:44:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:44:29 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:44:29 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:44:29 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:44:29 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:44:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:44:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:44:29 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:44:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:44:29 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:44:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:44:29 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:44:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:44:29 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:44:29 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:44:29 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:44:29 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:44:29 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:44:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:44:29 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:44:29 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:44:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:44:29 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:44:29 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:44:29 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:44:29 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:44:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:44:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:44:29 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:44:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:44:29 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:44:29 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:44:29 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:44:29 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:44:29 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:44:29 --> Session Class Initialized
DEBUG - 2016-08-30 22:44:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:44:30 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:44:30 --> Session routines successfully run
DEBUG - 2016-08-30 22:44:30 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:44:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:44:30 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:44:30 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:44:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:44:30 --> Controller Class Initialized
DEBUG - 2016-08-30 22:44:30 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:44:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:44:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:44:30 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:44:30 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:44:30 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:44:30 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:30 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:30 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:30 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:30 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:30 --> Model Class Initialized
DEBUG - 2016-08-30 22:44:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:44:30 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:44:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 22:44:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-30 22:44:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:44:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:44:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:44:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:44:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-30 22:44:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:44:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:44:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:44:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:44:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:44:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:44:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-30 22:44:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:44:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:44:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6ab6771ae9d42e25effdc2b45133f90d
DEBUG - 2016-08-30 22:44:31 --> Final output sent to browser
DEBUG - 2016-08-30 22:44:31 --> Total execution time: 2.0125
DEBUG - 2016-08-30 22:45:20 --> Config Class Initialized
DEBUG - 2016-08-30 22:45:20 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:45:20 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:45:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:45:20 --> URI Class Initialized
DEBUG - 2016-08-30 22:45:20 --> Router Class Initialized
DEBUG - 2016-08-30 22:45:20 --> Output Class Initialized
DEBUG - 2016-08-30 22:45:20 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:45:20 --> Security Class Initialized
DEBUG - 2016-08-30 22:45:20 --> Input Class Initialized
DEBUG - 2016-08-30 22:45:20 --> XSS Filtering completed
DEBUG - 2016-08-30 22:45:20 --> XSS Filtering completed
DEBUG - 2016-08-30 22:45:20 --> XSS Filtering completed
DEBUG - 2016-08-30 22:45:20 --> XSS Filtering completed
DEBUG - 2016-08-30 22:45:20 --> XSS Filtering completed
DEBUG - 2016-08-30 22:45:20 --> XSS Filtering completed
DEBUG - 2016-08-30 22:45:20 --> XSS Filtering completed
DEBUG - 2016-08-30 22:45:20 --> XSS Filtering completed
DEBUG - 2016-08-30 22:45:20 --> XSS Filtering completed
DEBUG - 2016-08-30 22:45:20 --> XSS Filtering completed
DEBUG - 2016-08-30 22:45:20 --> XSS Filtering completed
DEBUG - 2016-08-30 22:45:20 --> XSS Filtering completed
DEBUG - 2016-08-30 22:45:20 --> XSS Filtering completed
DEBUG - 2016-08-30 22:45:20 --> XSS Filtering completed
DEBUG - 2016-08-30 22:45:20 --> XSS Filtering completed
DEBUG - 2016-08-30 22:45:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:45:20 --> Language Class Initialized
DEBUG - 2016-08-30 22:45:20 --> Loader Class Initialized
DEBUG - 2016-08-30 22:45:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:45:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:45:20 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:45:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:45:20 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:45:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:45:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:45:20 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:45:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:45:20 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:45:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:45:21 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:45:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:45:21 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:45:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:45:21 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:45:21 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:45:21 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:45:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:45:21 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:45:21 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:45:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:45:21 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:45:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:45:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:45:21 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:45:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:45:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:45:21 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:45:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:45:21 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:45:21 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:45:21 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:45:21 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:45:21 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:45:21 --> Session Class Initialized
DEBUG - 2016-08-30 22:45:21 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:45:21 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:45:21 --> Session routines successfully run
DEBUG - 2016-08-30 22:45:21 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:45:21 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:45:21 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:45:21 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:45:21 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:45:21 --> Controller Class Initialized
DEBUG - 2016-08-30 22:45:21 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:45:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:45:21 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:45:21 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:45:22 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:45:22 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:45:22 --> Model Class Initialized
DEBUG - 2016-08-30 22:45:22 --> Model Class Initialized
DEBUG - 2016-08-30 22:45:22 --> Model Class Initialized
DEBUG - 2016-08-30 22:45:22 --> Model Class Initialized
DEBUG - 2016-08-30 22:45:22 --> Model Class Initialized
DEBUG - 2016-08-30 22:45:22 --> Model Class Initialized
DEBUG - 2016-08-30 22:45:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:45:22 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:45:22 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:45:22 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-08-30 22:45:22 --> Config Class Initialized
DEBUG - 2016-08-30 22:45:22 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:45:22 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:45:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:45:22 --> URI Class Initialized
DEBUG - 2016-08-30 22:45:22 --> Router Class Initialized
DEBUG - 2016-08-30 22:45:22 --> Output Class Initialized
DEBUG - 2016-08-30 22:45:22 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:45:22 --> Security Class Initialized
DEBUG - 2016-08-30 22:45:22 --> Input Class Initialized
DEBUG - 2016-08-30 22:45:22 --> XSS Filtering completed
DEBUG - 2016-08-30 22:45:22 --> XSS Filtering completed
DEBUG - 2016-08-30 22:45:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:45:22 --> Language Class Initialized
DEBUG - 2016-08-30 22:45:22 --> Loader Class Initialized
DEBUG - 2016-08-30 22:45:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:45:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:45:22 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:45:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:45:22 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:45:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:45:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:45:22 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:45:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:45:23 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:45:23 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:45:23 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:45:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:45:23 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:45:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:45:23 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:45:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:45:23 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:45:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:45:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:45:23 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:45:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:45:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:45:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:45:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:45:23 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:45:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:45:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:45:23 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:45:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:45:23 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:45:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:45:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:45:23 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:45:23 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:45:23 --> Session Class Initialized
DEBUG - 2016-08-30 22:45:23 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:45:23 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:45:23 --> Session routines successfully run
DEBUG - 2016-08-30 22:45:23 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:45:23 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:45:23 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:45:23 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:45:23 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:45:24 --> Controller Class Initialized
DEBUG - 2016-08-30 22:45:24 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:45:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:45:24 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:45:24 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:45:24 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:45:24 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:45:24 --> Model Class Initialized
DEBUG - 2016-08-30 22:45:24 --> Model Class Initialized
DEBUG - 2016-08-30 22:45:24 --> Model Class Initialized
DEBUG - 2016-08-30 22:45:24 --> Model Class Initialized
DEBUG - 2016-08-30 22:45:24 --> Model Class Initialized
DEBUG - 2016-08-30 22:45:24 --> Model Class Initialized
DEBUG - 2016-08-30 22:45:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:45:24 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 22:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-30 22:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-30 22:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-30 22:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:45:24 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6ab6771ae9d42e25effdc2b45133f90d
DEBUG - 2016-08-30 22:45:24 --> Final output sent to browser
DEBUG - 2016-08-30 22:45:24 --> Total execution time: 2.0842
DEBUG - 2016-08-30 22:45:30 --> Config Class Initialized
DEBUG - 2016-08-30 22:45:30 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:45:30 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:45:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:45:30 --> URI Class Initialized
DEBUG - 2016-08-30 22:45:30 --> Router Class Initialized
DEBUG - 2016-08-30 22:45:30 --> Output Class Initialized
DEBUG - 2016-08-30 22:45:30 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:45:30 --> Security Class Initialized
DEBUG - 2016-08-30 22:45:30 --> Input Class Initialized
DEBUG - 2016-08-30 22:45:30 --> XSS Filtering completed
DEBUG - 2016-08-30 22:45:30 --> XSS Filtering completed
DEBUG - 2016-08-30 22:45:30 --> XSS Filtering completed
DEBUG - 2016-08-30 22:45:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:45:30 --> Language Class Initialized
DEBUG - 2016-08-30 22:45:30 --> Loader Class Initialized
DEBUG - 2016-08-30 22:45:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:45:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:45:30 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:45:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:45:30 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:45:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:45:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:45:30 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:45:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:45:31 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:45:31 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:45:31 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:45:31 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:45:31 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:45:31 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:45:31 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:45:31 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:45:31 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:45:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:45:31 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:45:31 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:45:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:45:31 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:45:31 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:45:31 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:45:31 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:45:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:45:31 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:45:31 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:45:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:45:31 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:45:31 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:45:31 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:45:31 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:45:31 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:45:31 --> Session Class Initialized
DEBUG - 2016-08-30 22:45:31 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:45:31 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:45:31 --> Session routines successfully run
DEBUG - 2016-08-30 22:45:31 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:45:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:45:31 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:45:31 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:45:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:45:31 --> Controller Class Initialized
DEBUG - 2016-08-30 22:45:32 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:45:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:45:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:45:32 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:45:32 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:45:32 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:45:32 --> Model Class Initialized
DEBUG - 2016-08-30 22:45:32 --> Model Class Initialized
DEBUG - 2016-08-30 22:45:32 --> Model Class Initialized
DEBUG - 2016-08-30 22:45:32 --> Model Class Initialized
DEBUG - 2016-08-30 22:45:32 --> Model Class Initialized
DEBUG - 2016-08-30 22:45:32 --> Model Class Initialized
DEBUG - 2016-08-30 22:45:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:45:32 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:45:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 22:45:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-30 22:45:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:45:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:45:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:45:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:45:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-30 22:45:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:45:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:45:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:45:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:45:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:45:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:45:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-30 22:45:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:45:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:45:32 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6ab6771ae9d42e25effdc2b45133f90d
DEBUG - 2016-08-30 22:45:32 --> Final output sent to browser
DEBUG - 2016-08-30 22:45:32 --> Total execution time: 2.0808
DEBUG - 2016-08-30 22:45:48 --> Config Class Initialized
DEBUG - 2016-08-30 22:45:48 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:45:48 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:45:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:45:48 --> URI Class Initialized
DEBUG - 2016-08-30 22:45:48 --> Router Class Initialized
DEBUG - 2016-08-30 22:45:48 --> Output Class Initialized
DEBUG - 2016-08-30 22:45:48 --> Security Class Initialized
DEBUG - 2016-08-30 22:45:48 --> Input Class Initialized
DEBUG - 2016-08-30 22:45:48 --> XSS Filtering completed
DEBUG - 2016-08-30 22:45:48 --> XSS Filtering completed
DEBUG - 2016-08-30 22:45:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:45:48 --> Language Class Initialized
DEBUG - 2016-08-30 22:45:48 --> Loader Class Initialized
DEBUG - 2016-08-30 22:45:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:45:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:45:49 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:45:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:45:49 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:45:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:45:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:45:49 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:45:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:45:49 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:45:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:45:49 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:45:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:45:49 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:45:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:45:49 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:45:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:45:49 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:45:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:45:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:45:49 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:45:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:45:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:45:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:45:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:45:49 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:45:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:45:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:45:49 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:45:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:45:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:45:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:45:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:45:49 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:45:49 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:45:49 --> Session Class Initialized
DEBUG - 2016-08-30 22:45:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:45:50 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:45:50 --> Session routines successfully run
DEBUG - 2016-08-30 22:45:50 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:45:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:45:50 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:45:50 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:45:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:45:50 --> Controller Class Initialized
DEBUG - 2016-08-30 22:45:50 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:45:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:45:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:45:50 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:45:50 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:45:50 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:45:50 --> Model Class Initialized
DEBUG - 2016-08-30 22:45:50 --> Model Class Initialized
DEBUG - 2016-08-30 22:45:50 --> Model Class Initialized
DEBUG - 2016-08-30 22:45:50 --> Model Class Initialized
DEBUG - 2016-08-30 22:45:50 --> Model Class Initialized
DEBUG - 2016-08-30 22:45:50 --> Model Class Initialized
DEBUG - 2016-08-30 22:45:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 22:45:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/detail.php
DEBUG - 2016-08-30 22:45:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:45:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:45:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:45:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:45:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_js.php
DEBUG - 2016-08-30 22:45:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_isian_js.php
DEBUG - 2016-08-30 22:45:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:45:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:45:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:45:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:45:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:45:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:45:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_js.php
DEBUG - 2016-08-30 22:45:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_isian_js.php
DEBUG - 2016-08-30 22:45:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:45:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:45:51 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/a181d4a679e6905a87ac04b152de0aae
DEBUG - 2016-08-30 22:45:51 --> Final output sent to browser
DEBUG - 2016-08-30 22:45:51 --> Total execution time: 2.0190
DEBUG - 2016-08-30 22:46:26 --> Config Class Initialized
DEBUG - 2016-08-30 22:46:26 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:46:26 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:46:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:46:26 --> URI Class Initialized
DEBUG - 2016-08-30 22:46:26 --> Router Class Initialized
DEBUG - 2016-08-30 22:46:26 --> Output Class Initialized
DEBUG - 2016-08-30 22:46:26 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:46:26 --> Security Class Initialized
DEBUG - 2016-08-30 22:46:26 --> Input Class Initialized
DEBUG - 2016-08-30 22:46:26 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:26 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:26 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:46:26 --> Language Class Initialized
DEBUG - 2016-08-30 22:46:26 --> Loader Class Initialized
DEBUG - 2016-08-30 22:46:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:46:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:46:26 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:46:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:46:26 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:46:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:46:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:46:26 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:46:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:46:27 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:46:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:46:27 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:46:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:46:27 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:46:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:46:27 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:46:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:46:27 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:46:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:46:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:46:27 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:46:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:46:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:46:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:46:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:46:27 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:46:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:46:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:46:27 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:46:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:46:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:46:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:46:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:46:27 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:46:27 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:46:27 --> Session Class Initialized
DEBUG - 2016-08-30 22:46:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:46:27 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:46:27 --> Session routines successfully run
DEBUG - 2016-08-30 22:46:27 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:46:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:46:27 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:46:27 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:46:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:46:27 --> Controller Class Initialized
DEBUG - 2016-08-30 22:46:27 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:46:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:46:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:46:28 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:46:28 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:46:28 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:46:28 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:28 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:28 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:28 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:28 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:28 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b5e3eebbe550cd93afc20ddd83908c3b
DEBUG - 2016-08-30 22:46:28 --> Final output sent to browser
DEBUG - 2016-08-30 22:46:28 --> Total execution time: 1.9648
DEBUG - 2016-08-30 22:46:31 --> Config Class Initialized
DEBUG - 2016-08-30 22:46:31 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:46:31 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:46:31 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:46:31 --> URI Class Initialized
DEBUG - 2016-08-30 22:46:31 --> Router Class Initialized
DEBUG - 2016-08-30 22:46:31 --> Output Class Initialized
DEBUG - 2016-08-30 22:46:31 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:46:31 --> Security Class Initialized
DEBUG - 2016-08-30 22:46:31 --> Input Class Initialized
DEBUG - 2016-08-30 22:46:31 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:31 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:31 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:46:31 --> Language Class Initialized
DEBUG - 2016-08-30 22:46:31 --> Loader Class Initialized
DEBUG - 2016-08-30 22:46:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:46:31 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:46:31 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:46:32 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:46:32 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:46:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:46:32 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:46:32 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:46:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:46:32 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:46:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:46:32 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:46:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:46:32 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:46:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:46:32 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:46:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:46:32 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:46:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:46:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:46:32 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:46:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:46:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:46:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:46:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:46:32 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:46:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:46:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:46:32 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:46:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:46:32 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:46:32 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:46:32 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:46:32 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:46:32 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:46:32 --> Session Class Initialized
DEBUG - 2016-08-30 22:46:32 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:46:32 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:46:32 --> Session routines successfully run
DEBUG - 2016-08-30 22:46:33 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:46:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:46:33 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:46:33 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:46:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:46:33 --> Controller Class Initialized
DEBUG - 2016-08-30 22:46:33 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:46:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:46:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:46:33 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:46:33 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:46:33 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:46:33 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:33 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:33 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:33 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:33 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1ae1cad65d2be9e2d395bd427adbef6f
DEBUG - 2016-08-30 22:46:33 --> Final output sent to browser
DEBUG - 2016-08-30 22:46:33 --> Total execution time: 1.9791
DEBUG - 2016-08-30 22:46:36 --> Config Class Initialized
DEBUG - 2016-08-30 22:46:36 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:46:36 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:46:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:46:36 --> URI Class Initialized
DEBUG - 2016-08-30 22:46:36 --> Router Class Initialized
DEBUG - 2016-08-30 22:46:36 --> Output Class Initialized
DEBUG - 2016-08-30 22:46:36 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:46:36 --> Security Class Initialized
DEBUG - 2016-08-30 22:46:37 --> Input Class Initialized
DEBUG - 2016-08-30 22:46:37 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:37 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:37 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:46:37 --> Language Class Initialized
DEBUG - 2016-08-30 22:46:37 --> Loader Class Initialized
DEBUG - 2016-08-30 22:46:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:46:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:46:37 --> Config Class Initialized
DEBUG - 2016-08-30 22:46:37 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:46:37 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:46:37 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:46:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:46:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:46:37 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:46:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:46:37 --> URI Class Initialized
DEBUG - 2016-08-30 22:46:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:46:37 --> Router Class Initialized
DEBUG - 2016-08-30 22:46:37 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:46:37 --> Output Class Initialized
DEBUG - 2016-08-30 22:46:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:46:37 --> Security Class Initialized
DEBUG - 2016-08-30 22:46:37 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:46:37 --> Input Class Initialized
DEBUG - 2016-08-30 22:46:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:46:37 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:37 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:37 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:46:37 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:46:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:46:37 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:46:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:46:37 --> Language Class Initialized
DEBUG - 2016-08-30 22:46:37 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:46:37 --> Loader Class Initialized
DEBUG - 2016-08-30 22:46:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:46:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:46:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:46:37 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:46:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:46:37 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:46:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:46:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:46:37 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:46:37 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:46:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:46:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:46:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:46:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:46:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:46:37 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:46:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:46:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:46:37 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:46:37 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:46:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:46:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:46:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:46:37 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:46:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:46:37 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:46:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:46:37 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:46:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:46:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:46:38 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:46:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:46:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:46:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:46:38 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:46:38 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:46:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:46:38 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:46:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:46:38 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:46:38 --> Session Class Initialized
DEBUG - 2016-08-30 22:46:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:46:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:46:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:46:38 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:46:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:46:38 --> Session routines successfully run
DEBUG - 2016-08-30 22:46:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:46:38 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:46:38 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:46:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:46:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:46:38 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:46:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:46:38 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:46:38 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:46:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:46:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:46:38 --> Controller Class Initialized
DEBUG - 2016-08-30 22:46:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:46:38 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:46:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:46:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:46:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:46:38 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:46:38 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:46:38 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:46:38 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:46:38 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:46:38 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:46:38 --> Session Class Initialized
DEBUG - 2016-08-30 22:46:38 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:46:38 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:38 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:46:38 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:38 --> Session routines successfully run
DEBUG - 2016-08-30 22:46:38 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:38 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:46:38 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:38 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1ae1cad65d2be9e2d395bd427adbef6f
DEBUG - 2016-08-30 22:46:38 --> Final output sent to browser
DEBUG - 2016-08-30 22:46:38 --> Total execution time: 2.0434
DEBUG - 2016-08-30 22:46:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:46:38 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:46:38 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:46:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:46:39 --> Controller Class Initialized
DEBUG - 2016-08-30 22:46:39 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:46:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:46:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:46:39 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:46:39 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:46:39 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:46:39 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:39 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:39 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:39 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:39 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:39 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1ae1cad65d2be9e2d395bd427adbef6f
DEBUG - 2016-08-30 22:46:39 --> Final output sent to browser
DEBUG - 2016-08-30 22:46:39 --> Total execution time: 2.1591
DEBUG - 2016-08-30 22:46:39 --> Config Class Initialized
DEBUG - 2016-08-30 22:46:39 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:46:39 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:46:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:46:39 --> URI Class Initialized
DEBUG - 2016-08-30 22:46:39 --> Router Class Initialized
DEBUG - 2016-08-30 22:46:40 --> Output Class Initialized
DEBUG - 2016-08-30 22:46:40 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:46:40 --> Security Class Initialized
DEBUG - 2016-08-30 22:46:40 --> Input Class Initialized
DEBUG - 2016-08-30 22:46:40 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:40 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:40 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:46:40 --> Language Class Initialized
DEBUG - 2016-08-30 22:46:40 --> Loader Class Initialized
DEBUG - 2016-08-30 22:46:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:46:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:46:40 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:46:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:46:40 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:46:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:46:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:46:40 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:46:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:46:40 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:46:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:46:40 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:46:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:46:40 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:46:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:46:40 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:46:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:46:40 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:46:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:46:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:46:40 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:46:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:46:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:46:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:46:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:46:40 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:46:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:46:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:46:41 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:46:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:46:41 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:46:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:46:41 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:46:41 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:46:41 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:46:41 --> Session Class Initialized
DEBUG - 2016-08-30 22:46:41 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:46:41 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:46:41 --> Session routines successfully run
DEBUG - 2016-08-30 22:46:41 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:46:41 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:46:41 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:46:41 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:46:41 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:46:41 --> Controller Class Initialized
DEBUG - 2016-08-30 22:46:41 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:46:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:46:41 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:46:41 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:46:41 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:46:41 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:46:41 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:41 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:41 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:41 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:41 --> Config Class Initialized
DEBUG - 2016-08-30 22:46:41 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:46:41 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:41 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:46:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:46:41 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1ae1cad65d2be9e2d395bd427adbef6f
DEBUG - 2016-08-30 22:46:41 --> Final output sent to browser
DEBUG - 2016-08-30 22:46:41 --> URI Class Initialized
DEBUG - 2016-08-30 22:46:41 --> Total execution time: 2.0889
DEBUG - 2016-08-30 22:46:41 --> Router Class Initialized
DEBUG - 2016-08-30 22:46:42 --> Output Class Initialized
DEBUG - 2016-08-30 22:46:42 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:46:42 --> Security Class Initialized
DEBUG - 2016-08-30 22:46:42 --> Input Class Initialized
DEBUG - 2016-08-30 22:46:42 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:42 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:42 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:46:42 --> Language Class Initialized
DEBUG - 2016-08-30 22:46:42 --> Loader Class Initialized
DEBUG - 2016-08-30 22:46:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:46:42 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:46:42 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:46:42 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:46:42 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:46:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:46:42 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:46:42 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:46:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:46:42 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:46:42 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:46:42 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:46:42 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:46:42 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:46:42 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:46:42 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:46:42 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:46:42 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:46:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:46:42 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:46:42 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:46:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:46:42 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:46:42 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:46:42 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:46:42 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:46:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:46:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:46:43 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:46:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:46:43 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:46:43 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:46:43 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:46:43 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:46:43 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:46:43 --> Session Class Initialized
DEBUG - 2016-08-30 22:46:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:46:43 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:46:43 --> Session routines successfully run
DEBUG - 2016-08-30 22:46:43 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:46:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:46:43 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:46:43 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:46:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:46:43 --> Controller Class Initialized
DEBUG - 2016-08-30 22:46:43 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:46:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:46:43 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:46:43 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:46:43 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:46:43 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:46:43 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:43 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:43 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:43 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:43 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:43 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1ae1cad65d2be9e2d395bd427adbef6f
DEBUG - 2016-08-30 22:46:43 --> Final output sent to browser
DEBUG - 2016-08-30 22:46:43 --> Total execution time: 2.1002
DEBUG - 2016-08-30 22:46:44 --> Config Class Initialized
DEBUG - 2016-08-30 22:46:44 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:46:44 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:46:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:46:44 --> URI Class Initialized
DEBUG - 2016-08-30 22:46:44 --> Router Class Initialized
DEBUG - 2016-08-30 22:46:44 --> Output Class Initialized
DEBUG - 2016-08-30 22:46:44 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:46:44 --> Security Class Initialized
DEBUG - 2016-08-30 22:46:44 --> Input Class Initialized
DEBUG - 2016-08-30 22:46:44 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:44 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:44 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:46:44 --> Language Class Initialized
DEBUG - 2016-08-30 22:46:44 --> Loader Class Initialized
DEBUG - 2016-08-30 22:46:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:46:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:46:44 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:46:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:46:44 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:46:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:46:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:46:44 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:46:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:46:44 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:46:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:46:44 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:46:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:46:44 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:46:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:46:45 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:46:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:46:45 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:46:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:46:45 --> Config Class Initialized
DEBUG - 2016-08-30 22:46:45 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:46:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:46:45 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:46:45 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:46:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:46:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:46:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:46:45 --> URI Class Initialized
DEBUG - 2016-08-30 22:46:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:46:45 --> Router Class Initialized
DEBUG - 2016-08-30 22:46:45 --> Output Class Initialized
DEBUG - 2016-08-30 22:46:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:46:45 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:46:45 --> Security Class Initialized
DEBUG - 2016-08-30 22:46:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:46:45 --> Input Class Initialized
DEBUG - 2016-08-30 22:46:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:46:45 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:45 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:46:45 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:46:45 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:46:45 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:46:45 --> Language Class Initialized
DEBUG - 2016-08-30 22:46:45 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:46:45 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:46:45 --> Loader Class Initialized
DEBUG - 2016-08-30 22:46:45 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:46:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:46:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:46:45 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:46:45 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:46:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:46:45 --> Session Class Initialized
DEBUG - 2016-08-30 22:46:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:46:45 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:46:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:46:45 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:46:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:46:45 --> Session routines successfully run
DEBUG - 2016-08-30 22:46:45 --> Config Class Initialized
DEBUG - 2016-08-30 22:46:45 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:46:45 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:46:45 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:46:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:46:45 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:46:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:46:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:46:45 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:46:45 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:46:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:46:45 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:46:45 --> URI Class Initialized
DEBUG - 2016-08-30 22:46:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:46:45 --> Router Class Initialized
DEBUG - 2016-08-30 22:46:45 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:46:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:46:45 --> Output Class Initialized
DEBUG - 2016-08-30 22:46:45 --> Controller Class Initialized
DEBUG - 2016-08-30 22:46:45 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:46:45 --> Security Class Initialized
DEBUG - 2016-08-30 22:46:45 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:46:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:46:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:46:45 --> Input Class Initialized
DEBUG - 2016-08-30 22:46:45 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:46:45 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:46:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:46:45 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:45 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:46:46 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:46:46 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:46 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:46:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:46:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:46:46 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:46:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:46:46 --> Language Class Initialized
DEBUG - 2016-08-30 22:46:46 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:46 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:46:46 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:46 --> Loader Class Initialized
DEBUG - 2016-08-30 22:46:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:46:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:46:46 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:46:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:46:46 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:46 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:46 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:46:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:46:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:46:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:46:46 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:46:46 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:46:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1ae1cad65d2be9e2d395bd427adbef6f
DEBUG - 2016-08-30 22:46:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:46:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:46:46 --> Final output sent to browser
DEBUG - 2016-08-30 22:46:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:46:46 --> Total execution time: 2.1484
DEBUG - 2016-08-30 22:46:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:46:46 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:46:46 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:46:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:46:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:46:46 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:46:46 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:46:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:46:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:46:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:46:46 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:46:46 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:46:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:46:46 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:46:46 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:46:46 --> Session Class Initialized
DEBUG - 2016-08-30 22:46:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:46:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:46:46 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:46:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:46:46 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:46:46 --> Session routines successfully run
DEBUG - 2016-08-30 22:46:46 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:46:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:46:46 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:46:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:46:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:46:46 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:46:46 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:46:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:46:46 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:46:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:46:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:46:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:46:46 --> Controller Class Initialized
DEBUG - 2016-08-30 22:46:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:46:46 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:46:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:46:46 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:46:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:46:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:46:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:46:46 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:46:46 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:46:46 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:46:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:46:46 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:46:46 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:46:46 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:47 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:46:47 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:47 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:46:47 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:47 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:46:47 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:47 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:47 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:46:47 --> Session Class Initialized
DEBUG - 2016-08-30 22:46:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1ae1cad65d2be9e2d395bd427adbef6f
DEBUG - 2016-08-30 22:46:47 --> Final output sent to browser
DEBUG - 2016-08-30 22:46:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:46:47 --> Total execution time: 2.0529
DEBUG - 2016-08-30 22:46:47 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:46:47 --> Session routines successfully run
DEBUG - 2016-08-30 22:46:47 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:46:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:46:47 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:46:47 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:46:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:46:47 --> Controller Class Initialized
DEBUG - 2016-08-30 22:46:47 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:46:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:46:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:46:47 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:46:47 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:46:47 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:46:47 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:47 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:47 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:47 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:47 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1ae1cad65d2be9e2d395bd427adbef6f
DEBUG - 2016-08-30 22:46:47 --> Final output sent to browser
DEBUG - 2016-08-30 22:46:47 --> Total execution time: 2.1375
DEBUG - 2016-08-30 22:46:53 --> Config Class Initialized
DEBUG - 2016-08-30 22:46:53 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:46:53 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:46:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:46:53 --> URI Class Initialized
DEBUG - 2016-08-30 22:46:53 --> Router Class Initialized
DEBUG - 2016-08-30 22:46:53 --> Output Class Initialized
DEBUG - 2016-08-30 22:46:53 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:46:53 --> Security Class Initialized
DEBUG - 2016-08-30 22:46:53 --> Input Class Initialized
DEBUG - 2016-08-30 22:46:53 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:53 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:53 --> XSS Filtering completed
DEBUG - 2016-08-30 22:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:46:53 --> Language Class Initialized
DEBUG - 2016-08-30 22:46:53 --> Loader Class Initialized
DEBUG - 2016-08-30 22:46:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:46:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:46:53 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:46:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:46:53 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:46:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:46:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:46:54 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:46:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:46:54 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:46:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:46:54 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:46:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:46:54 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:46:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:46:54 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:46:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:46:54 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:46:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:46:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:46:54 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:46:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:46:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:46:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:46:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:46:54 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:46:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:46:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:46:54 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:46:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:46:54 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:46:54 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:46:54 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:46:54 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:46:54 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:46:54 --> Session Class Initialized
DEBUG - 2016-08-30 22:46:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:46:54 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:46:54 --> Session routines successfully run
DEBUG - 2016-08-30 22:46:54 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:46:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:46:55 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:46:55 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:46:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:46:55 --> Controller Class Initialized
DEBUG - 2016-08-30 22:46:55 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:46:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:46:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:46:55 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:46:55 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:46:55 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:46:55 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:55 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:55 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:55 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:55 --> Model Class Initialized
DEBUG - 2016-08-30 22:46:55 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/3986b17e67923511ff75332baca04769
DEBUG - 2016-08-30 22:46:55 --> Final output sent to browser
DEBUG - 2016-08-30 22:46:55 --> Total execution time: 2.0945
DEBUG - 2016-08-30 22:47:00 --> Config Class Initialized
DEBUG - 2016-08-30 22:47:00 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:47:00 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:47:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:47:00 --> URI Class Initialized
DEBUG - 2016-08-30 22:47:00 --> Router Class Initialized
DEBUG - 2016-08-30 22:47:00 --> Output Class Initialized
DEBUG - 2016-08-30 22:47:00 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:47:00 --> Security Class Initialized
DEBUG - 2016-08-30 22:47:00 --> Input Class Initialized
DEBUG - 2016-08-30 22:47:00 --> XSS Filtering completed
DEBUG - 2016-08-30 22:47:00 --> XSS Filtering completed
DEBUG - 2016-08-30 22:47:00 --> XSS Filtering completed
DEBUG - 2016-08-30 22:47:00 --> XSS Filtering completed
DEBUG - 2016-08-30 22:47:00 --> XSS Filtering completed
DEBUG - 2016-08-30 22:47:00 --> XSS Filtering completed
DEBUG - 2016-08-30 22:47:00 --> XSS Filtering completed
DEBUG - 2016-08-30 22:47:00 --> XSS Filtering completed
DEBUG - 2016-08-30 22:47:00 --> XSS Filtering completed
DEBUG - 2016-08-30 22:47:00 --> XSS Filtering completed
DEBUG - 2016-08-30 22:47:00 --> XSS Filtering completed
DEBUG - 2016-08-30 22:47:00 --> XSS Filtering completed
DEBUG - 2016-08-30 22:47:00 --> XSS Filtering completed
DEBUG - 2016-08-30 22:47:00 --> XSS Filtering completed
DEBUG - 2016-08-30 22:47:00 --> XSS Filtering completed
DEBUG - 2016-08-30 22:47:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:47:01 --> Language Class Initialized
DEBUG - 2016-08-30 22:47:01 --> Loader Class Initialized
DEBUG - 2016-08-30 22:47:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:47:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:47:01 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:47:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:47:01 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:47:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:47:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:47:01 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:47:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:47:01 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:47:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:47:01 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:47:01 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:47:01 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:47:01 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:47:01 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:47:01 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:47:01 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:47:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:47:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:47:01 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:47:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:47:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:47:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:47:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:47:01 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:47:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:47:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:47:01 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:47:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:47:01 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:47:01 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:47:02 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:47:02 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:47:02 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:47:02 --> Session Class Initialized
DEBUG - 2016-08-30 22:47:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:47:02 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:47:02 --> Session routines successfully run
DEBUG - 2016-08-30 22:47:02 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:47:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:47:02 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:47:02 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:47:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:47:02 --> Controller Class Initialized
DEBUG - 2016-08-30 22:47:02 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:47:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:47:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:47:02 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:47:02 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:47:02 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:47:02 --> Model Class Initialized
DEBUG - 2016-08-30 22:47:02 --> Model Class Initialized
DEBUG - 2016-08-30 22:47:02 --> Model Class Initialized
DEBUG - 2016-08-30 22:47:02 --> Model Class Initialized
DEBUG - 2016-08-30 22:47:02 --> Model Class Initialized
DEBUG - 2016-08-30 22:47:02 --> Model Class Initialized
DEBUG - 2016-08-30 22:47:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:47:02 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:47:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:47:02 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-08-30 22:49:38 --> Config Class Initialized
DEBUG - 2016-08-30 22:49:38 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:49:38 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:49:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:49:38 --> URI Class Initialized
DEBUG - 2016-08-30 22:49:38 --> Router Class Initialized
DEBUG - 2016-08-30 22:49:38 --> Output Class Initialized
DEBUG - 2016-08-30 22:49:38 --> Security Class Initialized
DEBUG - 2016-08-30 22:49:38 --> Input Class Initialized
DEBUG - 2016-08-30 22:49:38 --> XSS Filtering completed
DEBUG - 2016-08-30 22:49:38 --> XSS Filtering completed
DEBUG - 2016-08-30 22:49:38 --> XSS Filtering completed
DEBUG - 2016-08-30 22:49:38 --> XSS Filtering completed
DEBUG - 2016-08-30 22:49:38 --> XSS Filtering completed
DEBUG - 2016-08-30 22:49:38 --> XSS Filtering completed
DEBUG - 2016-08-30 22:49:38 --> XSS Filtering completed
DEBUG - 2016-08-30 22:49:38 --> XSS Filtering completed
DEBUG - 2016-08-30 22:49:38 --> XSS Filtering completed
DEBUG - 2016-08-30 22:49:38 --> XSS Filtering completed
DEBUG - 2016-08-30 22:49:38 --> XSS Filtering completed
DEBUG - 2016-08-30 22:49:38 --> XSS Filtering completed
DEBUG - 2016-08-30 22:49:38 --> XSS Filtering completed
DEBUG - 2016-08-30 22:49:38 --> XSS Filtering completed
DEBUG - 2016-08-30 22:49:39 --> XSS Filtering completed
DEBUG - 2016-08-30 22:49:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:49:39 --> Language Class Initialized
DEBUG - 2016-08-30 22:49:39 --> Loader Class Initialized
DEBUG - 2016-08-30 22:49:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:49:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:49:39 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:49:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:49:39 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:49:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:49:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:49:39 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:49:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:49:39 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:49:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:49:39 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:49:39 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:49:39 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:49:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:49:39 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:49:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:49:39 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:49:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:49:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:49:39 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:49:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:49:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:49:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:49:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:49:39 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:49:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:49:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:49:39 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:49:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:49:39 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:49:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:49:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:49:40 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:49:40 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:49:40 --> Session Class Initialized
DEBUG - 2016-08-30 22:49:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:49:40 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:49:40 --> Session routines successfully run
DEBUG - 2016-08-30 22:49:40 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:49:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:49:40 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:49:40 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:49:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:49:40 --> Controller Class Initialized
DEBUG - 2016-08-30 22:49:40 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:49:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:49:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:49:40 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:49:40 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:49:40 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:49:40 --> Model Class Initialized
DEBUG - 2016-08-30 22:49:40 --> Model Class Initialized
DEBUG - 2016-08-30 22:49:40 --> Model Class Initialized
DEBUG - 2016-08-30 22:49:40 --> Model Class Initialized
DEBUG - 2016-08-30 22:49:40 --> Model Class Initialized
DEBUG - 2016-08-30 22:49:40 --> Model Class Initialized
DEBUG - 2016-08-30 22:49:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:49:40 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:49:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:49:40 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-08-30 22:49:40 --> Model Class Initialized
DEBUG - 2016-08-30 22:50:01 --> Config Class Initialized
DEBUG - 2016-08-30 22:50:01 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:50:01 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:50:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:50:01 --> URI Class Initialized
DEBUG - 2016-08-30 22:50:01 --> Router Class Initialized
DEBUG - 2016-08-30 22:50:01 --> Output Class Initialized
DEBUG - 2016-08-30 22:50:01 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:50:02 --> Security Class Initialized
DEBUG - 2016-08-30 22:50:02 --> Input Class Initialized
DEBUG - 2016-08-30 22:50:02 --> XSS Filtering completed
DEBUG - 2016-08-30 22:50:02 --> XSS Filtering completed
DEBUG - 2016-08-30 22:50:02 --> XSS Filtering completed
DEBUG - 2016-08-30 22:50:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:50:02 --> Language Class Initialized
DEBUG - 2016-08-30 22:50:02 --> Loader Class Initialized
DEBUG - 2016-08-30 22:50:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:50:02 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:50:02 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:50:02 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:50:02 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:50:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:50:02 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:50:02 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:50:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:50:02 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:50:02 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:50:02 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:50:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:50:02 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:50:02 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:50:02 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:50:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:50:02 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:50:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:50:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:50:02 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:50:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:50:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:50:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:50:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:50:02 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:50:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:50:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:50:03 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:50:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:50:03 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:50:03 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:50:03 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:50:03 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:50:03 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:50:03 --> Session Class Initialized
DEBUG - 2016-08-30 22:50:03 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:50:03 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:50:03 --> Session routines successfully run
DEBUG - 2016-08-30 22:50:03 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:50:03 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:50:03 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:50:03 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:50:03 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:50:03 --> Controller Class Initialized
DEBUG - 2016-08-30 22:50:03 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:50:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:50:03 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:50:03 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:50:03 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:50:03 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:50:03 --> Model Class Initialized
DEBUG - 2016-08-30 22:50:03 --> Model Class Initialized
DEBUG - 2016-08-30 22:50:03 --> Model Class Initialized
DEBUG - 2016-08-30 22:50:03 --> Model Class Initialized
DEBUG - 2016-08-30 22:50:03 --> Model Class Initialized
DEBUG - 2016-08-30 22:50:03 --> Model Class Initialized
DEBUG - 2016-08-30 22:50:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:50:04 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:50:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 22:50:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-30 22:50:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:50:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:50:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:50:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:50:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-30 22:50:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:50:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:50:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:50:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:50:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:50:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:50:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-30 22:50:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:50:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:50:04 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6ab6771ae9d42e25effdc2b45133f90d
DEBUG - 2016-08-30 22:50:04 --> Final output sent to browser
DEBUG - 2016-08-30 22:50:04 --> Total execution time: 2.2367
DEBUG - 2016-08-30 22:50:48 --> Config Class Initialized
DEBUG - 2016-08-30 22:50:48 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:50:48 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:50:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:50:48 --> URI Class Initialized
DEBUG - 2016-08-30 22:50:48 --> Router Class Initialized
DEBUG - 2016-08-30 22:50:48 --> Output Class Initialized
DEBUG - 2016-08-30 22:50:48 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:50:48 --> Security Class Initialized
DEBUG - 2016-08-30 22:50:48 --> Input Class Initialized
DEBUG - 2016-08-30 22:50:49 --> XSS Filtering completed
DEBUG - 2016-08-30 22:50:49 --> XSS Filtering completed
DEBUG - 2016-08-30 22:50:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:50:49 --> Language Class Initialized
DEBUG - 2016-08-30 22:50:49 --> Loader Class Initialized
DEBUG - 2016-08-30 22:50:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:50:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:50:49 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:50:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:50:49 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:50:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:50:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:50:49 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:50:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:50:49 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:50:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:50:49 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:50:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:50:49 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:50:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:50:49 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:50:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:50:49 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:50:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:50:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:50:49 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:50:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:50:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:50:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:50:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:50:49 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:50:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:50:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:50:49 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:50:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:50:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:50:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:50:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:50:50 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:50:50 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:50:50 --> Session Class Initialized
DEBUG - 2016-08-30 22:50:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:50:50 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:50:50 --> Session routines successfully run
DEBUG - 2016-08-30 22:50:50 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:50:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:50:50 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:50:50 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:50:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:50:50 --> Controller Class Initialized
DEBUG - 2016-08-30 22:50:50 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:50:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:50:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:50:50 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:50:50 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:50:50 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:50:50 --> Model Class Initialized
DEBUG - 2016-08-30 22:50:50 --> Model Class Initialized
DEBUG - 2016-08-30 22:50:50 --> Model Class Initialized
DEBUG - 2016-08-30 22:50:50 --> Model Class Initialized
DEBUG - 2016-08-30 22:50:50 --> Model Class Initialized
DEBUG - 2016-08-30 22:50:50 --> Model Class Initialized
DEBUG - 2016-08-30 22:50:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:50:51 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:50:51 --> Model Class Initialized
DEBUG - 2016-08-30 22:50:51 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:50:51 --> Model Class Initialized
DEBUG - 2016-08-30 22:50:51 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:50:53 --> Config Class Initialized
DEBUG - 2016-08-30 22:50:53 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:50:54 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:50:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:50:54 --> URI Class Initialized
DEBUG - 2016-08-30 22:50:54 --> Router Class Initialized
DEBUG - 2016-08-30 22:50:54 --> Output Class Initialized
DEBUG - 2016-08-30 22:50:54 --> Security Class Initialized
DEBUG - 2016-08-30 22:50:54 --> Input Class Initialized
DEBUG - 2016-08-30 22:50:54 --> XSS Filtering completed
DEBUG - 2016-08-30 22:50:54 --> XSS Filtering completed
DEBUG - 2016-08-30 22:50:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:50:54 --> Language Class Initialized
DEBUG - 2016-08-30 22:50:54 --> Loader Class Initialized
DEBUG - 2016-08-30 22:50:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:50:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:50:54 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:50:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:50:54 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:50:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:50:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:50:54 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:50:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:50:54 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:50:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:50:54 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:50:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:50:54 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:50:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:50:54 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:50:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:50:54 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:50:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:50:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:50:54 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:50:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:50:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:50:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:50:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:50:55 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:50:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:50:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:50:55 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:50:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:50:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:50:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:50:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:50:55 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:50:55 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:50:55 --> Session Class Initialized
DEBUG - 2016-08-30 22:50:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:50:55 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:50:55 --> Session routines successfully run
DEBUG - 2016-08-30 22:50:55 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:50:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:50:55 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:50:55 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:50:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:50:55 --> Controller Class Initialized
DEBUG - 2016-08-30 22:50:55 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:50:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:50:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:50:55 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:50:55 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:50:55 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:50:55 --> Model Class Initialized
DEBUG - 2016-08-30 22:50:56 --> Model Class Initialized
DEBUG - 2016-08-30 22:50:56 --> Model Class Initialized
DEBUG - 2016-08-30 22:50:56 --> Model Class Initialized
DEBUG - 2016-08-30 22:50:56 --> Model Class Initialized
DEBUG - 2016-08-30 22:50:56 --> Model Class Initialized
DEBUG - 2016-08-30 22:50:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:50:56 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:50:56 --> Model Class Initialized
DEBUG - 2016-08-30 22:50:56 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:50:56 --> Model Class Initialized
DEBUG - 2016-08-30 22:50:56 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:55:08 --> Config Class Initialized
DEBUG - 2016-08-30 22:55:08 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:55:08 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:55:08 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:55:08 --> URI Class Initialized
DEBUG - 2016-08-30 22:55:08 --> Router Class Initialized
DEBUG - 2016-08-30 22:55:08 --> Output Class Initialized
DEBUG - 2016-08-30 22:55:08 --> Security Class Initialized
DEBUG - 2016-08-30 22:55:08 --> Input Class Initialized
DEBUG - 2016-08-30 22:55:08 --> XSS Filtering completed
DEBUG - 2016-08-30 22:55:08 --> XSS Filtering completed
DEBUG - 2016-08-30 22:55:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:55:08 --> Language Class Initialized
DEBUG - 2016-08-30 22:55:08 --> Loader Class Initialized
DEBUG - 2016-08-30 22:55:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:55:08 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:55:08 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:55:08 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:55:08 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:55:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:55:08 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:55:08 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:55:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:55:09 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:55:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:55:09 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:55:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:55:09 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:55:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:55:09 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:55:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:55:09 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:55:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:55:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:55:09 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:55:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:55:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:55:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:55:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:55:09 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:55:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:55:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:55:09 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:55:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:55:09 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:55:09 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:55:09 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:55:09 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:55:09 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:55:09 --> Session Class Initialized
DEBUG - 2016-08-30 22:55:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:55:09 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:55:09 --> Session routines successfully run
DEBUG - 2016-08-30 22:55:09 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:55:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:55:09 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:55:10 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:55:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:55:10 --> Controller Class Initialized
DEBUG - 2016-08-30 22:55:10 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:55:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:55:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:55:10 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:55:10 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:55:10 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:55:10 --> Model Class Initialized
DEBUG - 2016-08-30 22:55:10 --> Model Class Initialized
DEBUG - 2016-08-30 22:55:10 --> Model Class Initialized
DEBUG - 2016-08-30 22:55:10 --> Model Class Initialized
DEBUG - 2016-08-30 22:55:10 --> Model Class Initialized
DEBUG - 2016-08-30 22:55:10 --> Model Class Initialized
DEBUG - 2016-08-30 22:55:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:55:10 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:55:10 --> Model Class Initialized
DEBUG - 2016-08-30 22:55:10 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:55:10 --> Model Class Initialized
DEBUG - 2016-08-30 22:55:10 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:55:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 22:55:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
ERROR - 2016-08-30 22:55:10 --> Severity: Notice  --> Undefined property: stdClass::$tgl_ditetapkan E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 72
DEBUG - 2016-08-30 22:55:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 22:55:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 22:55:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:55:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:55:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:55:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:55:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 22:55:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:55:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:55:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:55:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:55:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:55:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:55:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 22:55:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:55:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:55:11 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 22:55:11 --> Final output sent to browser
DEBUG - 2016-08-30 22:55:11 --> Total execution time: 2.3577
DEBUG - 2016-08-30 22:55:27 --> Config Class Initialized
DEBUG - 2016-08-30 22:55:27 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:55:27 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:55:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:55:27 --> URI Class Initialized
DEBUG - 2016-08-30 22:55:27 --> Router Class Initialized
DEBUG - 2016-08-30 22:55:27 --> Output Class Initialized
DEBUG - 2016-08-30 22:55:27 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:55:27 --> Security Class Initialized
DEBUG - 2016-08-30 22:55:27 --> Input Class Initialized
DEBUG - 2016-08-30 22:55:27 --> XSS Filtering completed
DEBUG - 2016-08-30 22:55:27 --> XSS Filtering completed
DEBUG - 2016-08-30 22:55:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:55:27 --> Language Class Initialized
DEBUG - 2016-08-30 22:55:27 --> Loader Class Initialized
DEBUG - 2016-08-30 22:55:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:55:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:55:27 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:55:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:55:28 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:55:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:55:28 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:55:28 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:55:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:55:28 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:55:28 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:55:28 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:55:28 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:55:28 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:55:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:55:28 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:55:28 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:55:28 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:55:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:55:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:55:28 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:55:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:55:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:55:28 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:55:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:55:28 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:55:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:55:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:55:28 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:55:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:55:28 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:55:28 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:55:28 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:55:28 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:55:28 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:55:28 --> Session Class Initialized
DEBUG - 2016-08-30 22:55:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:55:29 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:55:29 --> Session routines successfully run
DEBUG - 2016-08-30 22:55:29 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:55:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:55:29 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:55:29 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:55:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:55:29 --> Controller Class Initialized
DEBUG - 2016-08-30 22:55:29 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:55:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:55:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:55:29 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:55:29 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:55:29 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:55:29 --> Model Class Initialized
DEBUG - 2016-08-30 22:55:29 --> Model Class Initialized
DEBUG - 2016-08-30 22:55:29 --> Model Class Initialized
DEBUG - 2016-08-30 22:55:29 --> Model Class Initialized
DEBUG - 2016-08-30 22:55:29 --> Model Class Initialized
DEBUG - 2016-08-30 22:55:29 --> Model Class Initialized
DEBUG - 2016-08-30 22:55:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:55:29 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:55:29 --> Model Class Initialized
DEBUG - 2016-08-30 22:55:29 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:55:29 --> Model Class Initialized
DEBUG - 2016-08-30 22:55:29 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:55:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 22:55:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 22:55:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 22:55:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 22:55:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:55:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:55:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:55:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:55:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 22:55:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:55:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:55:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:55:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:55:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:55:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:55:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 22:55:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:55:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:55:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 22:55:30 --> Final output sent to browser
DEBUG - 2016-08-30 22:55:30 --> Total execution time: 2.5089
DEBUG - 2016-08-30 22:56:02 --> Config Class Initialized
DEBUG - 2016-08-30 22:56:03 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:56:03 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:56:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:56:03 --> URI Class Initialized
DEBUG - 2016-08-30 22:56:03 --> Router Class Initialized
DEBUG - 2016-08-30 22:56:03 --> Output Class Initialized
DEBUG - 2016-08-30 22:56:03 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:56:03 --> Security Class Initialized
DEBUG - 2016-08-30 22:56:03 --> Input Class Initialized
DEBUG - 2016-08-30 22:56:03 --> XSS Filtering completed
DEBUG - 2016-08-30 22:56:03 --> XSS Filtering completed
DEBUG - 2016-08-30 22:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:56:03 --> Language Class Initialized
DEBUG - 2016-08-30 22:56:03 --> Loader Class Initialized
DEBUG - 2016-08-30 22:56:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:56:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:56:03 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:56:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:56:03 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:56:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:56:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:56:03 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:56:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:56:03 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:56:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:56:03 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:56:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:56:03 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:56:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:56:03 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:56:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:56:03 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:56:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:56:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:56:04 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:56:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:56:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:56:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:56:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:56:04 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:56:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:56:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:56:04 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:56:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:56:04 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:56:04 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:56:04 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:56:04 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:56:04 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:56:04 --> Session Class Initialized
DEBUG - 2016-08-30 22:56:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:56:04 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:56:04 --> Session routines successfully run
DEBUG - 2016-08-30 22:56:04 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:56:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:56:04 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:56:04 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:56:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:56:04 --> Controller Class Initialized
DEBUG - 2016-08-30 22:56:04 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:56:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:56:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:56:04 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:56:04 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:56:05 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:56:05 --> Model Class Initialized
DEBUG - 2016-08-30 22:56:05 --> Model Class Initialized
DEBUG - 2016-08-30 22:56:05 --> Model Class Initialized
DEBUG - 2016-08-30 22:56:05 --> Model Class Initialized
DEBUG - 2016-08-30 22:56:05 --> Model Class Initialized
DEBUG - 2016-08-30 22:56:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:56:05 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:56:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 22:56:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/index.php
DEBUG - 2016-08-30 22:56:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:56:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:56:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:56:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:56:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-08-30 22:56:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:56:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:56:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:56:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:56:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:56:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:56:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-08-30 22:56:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:56:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:56:05 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c2a3e0401bd35d4fcac4bae5f9412231
DEBUG - 2016-08-30 22:56:05 --> Final output sent to browser
DEBUG - 2016-08-30 22:56:05 --> Total execution time: 2.3329
DEBUG - 2016-08-30 22:56:08 --> Config Class Initialized
DEBUG - 2016-08-30 22:56:08 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:56:08 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:56:08 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:56:08 --> URI Class Initialized
DEBUG - 2016-08-30 22:56:08 --> Router Class Initialized
DEBUG - 2016-08-30 22:56:08 --> Output Class Initialized
DEBUG - 2016-08-30 22:56:08 --> Security Class Initialized
DEBUG - 2016-08-30 22:56:08 --> Input Class Initialized
DEBUG - 2016-08-30 22:56:08 --> XSS Filtering completed
DEBUG - 2016-08-30 22:56:08 --> XSS Filtering completed
DEBUG - 2016-08-30 22:56:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:56:08 --> Language Class Initialized
DEBUG - 2016-08-30 22:56:08 --> Loader Class Initialized
DEBUG - 2016-08-30 22:56:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:56:08 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:56:08 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:56:08 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:56:08 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:56:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:56:08 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:56:08 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:56:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:56:08 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:56:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:56:09 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:56:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:56:09 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:56:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:56:09 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:56:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:56:09 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:56:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:56:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:56:09 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:56:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:56:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:56:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:56:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:56:09 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:56:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:56:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:56:09 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:56:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:56:09 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:56:09 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:56:09 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:56:09 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:56:09 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:56:09 --> Session Class Initialized
DEBUG - 2016-08-30 22:56:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:56:09 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:56:09 --> Session routines successfully run
DEBUG - 2016-08-30 22:56:09 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:56:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:56:10 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:56:10 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:56:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:56:10 --> Controller Class Initialized
DEBUG - 2016-08-30 22:56:10 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:56:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:56:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:56:10 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:56:10 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:56:10 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:56:10 --> Model Class Initialized
DEBUG - 2016-08-30 22:56:10 --> Model Class Initialized
DEBUG - 2016-08-30 22:56:10 --> Model Class Initialized
DEBUG - 2016-08-30 22:56:10 --> Model Class Initialized
DEBUG - 2016-08-30 22:56:10 --> Model Class Initialized
DEBUG - 2016-08-30 22:56:10 --> Model Class Initialized
DEBUG - 2016-08-30 22:56:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:56:10 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:56:10 --> Model Class Initialized
DEBUG - 2016-08-30 22:56:10 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:56:10 --> Model Class Initialized
DEBUG - 2016-08-30 22:56:10 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:56:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 22:56:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 22:56:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 22:56:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 22:56:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:56:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:56:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:56:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:56:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 22:56:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:56:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:56:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:56:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:56:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:56:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:56:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 22:56:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:56:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:56:11 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b6bd8c4f0f9a3c083ce1836ed8f53795
DEBUG - 2016-08-30 22:56:11 --> Final output sent to browser
DEBUG - 2016-08-30 22:56:11 --> Total execution time: 2.4567
DEBUG - 2016-08-30 22:58:46 --> Config Class Initialized
DEBUG - 2016-08-30 22:58:46 --> Hooks Class Initialized
DEBUG - 2016-08-30 22:58:46 --> Utf8 Class Initialized
DEBUG - 2016-08-30 22:58:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 22:58:46 --> URI Class Initialized
DEBUG - 2016-08-30 22:58:46 --> Router Class Initialized
DEBUG - 2016-08-30 22:58:46 --> Output Class Initialized
DEBUG - 2016-08-30 22:58:46 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 22:58:46 --> Security Class Initialized
DEBUG - 2016-08-30 22:58:46 --> Input Class Initialized
DEBUG - 2016-08-30 22:58:46 --> XSS Filtering completed
DEBUG - 2016-08-30 22:58:46 --> XSS Filtering completed
DEBUG - 2016-08-30 22:58:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 22:58:46 --> Language Class Initialized
DEBUG - 2016-08-30 22:58:46 --> Loader Class Initialized
DEBUG - 2016-08-30 22:58:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 22:58:47 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 22:58:47 --> Helper loaded: url_helper
DEBUG - 2016-08-30 22:58:47 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 22:58:47 --> Helper loaded: file_helper
DEBUG - 2016-08-30 22:58:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:58:47 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 22:58:47 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 22:58:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 22:58:47 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 22:58:47 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 22:58:47 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:58:47 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 22:58:47 --> Helper loaded: common_helper
DEBUG - 2016-08-30 22:58:47 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 22:58:47 --> Helper loaded: form_helper
DEBUG - 2016-08-30 22:58:47 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 22:58:47 --> Helper loaded: security_helper
DEBUG - 2016-08-30 22:58:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:58:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 22:58:47 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 22:58:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 22:58:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 22:58:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 22:58:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 22:58:47 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 22:58:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:58:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 22:58:47 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 22:58:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 22:58:47 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 22:58:47 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 22:58:47 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 22:58:47 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 22:58:47 --> Database Driver Class Initialized
DEBUG - 2016-08-30 22:58:48 --> Session Class Initialized
DEBUG - 2016-08-30 22:58:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 22:58:48 --> Helper loaded: string_helper
DEBUG - 2016-08-30 22:58:48 --> Session routines successfully run
DEBUG - 2016-08-30 22:58:48 --> Native_session Class Initialized
DEBUG - 2016-08-30 22:58:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 22:58:48 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:58:48 --> Form Validation Class Initialized
DEBUG - 2016-08-30 22:58:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 22:58:48 --> Controller Class Initialized
DEBUG - 2016-08-30 22:58:48 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 22:58:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 22:58:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 22:58:48 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:58:48 --> Carabiner: library configured.
DEBUG - 2016-08-30 22:58:48 --> User Agent Class Initialized
DEBUG - 2016-08-30 22:58:48 --> Model Class Initialized
DEBUG - 2016-08-30 22:58:48 --> Model Class Initialized
DEBUG - 2016-08-30 22:58:48 --> Model Class Initialized
DEBUG - 2016-08-30 22:58:48 --> Model Class Initialized
DEBUG - 2016-08-30 22:58:48 --> Model Class Initialized
DEBUG - 2016-08-30 22:58:48 --> Model Class Initialized
DEBUG - 2016-08-30 22:58:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 22:58:48 --> Pagination Class Initialized
DEBUG - 2016-08-30 22:58:48 --> Model Class Initialized
DEBUG - 2016-08-30 22:58:48 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:58:48 --> Model Class Initialized
DEBUG - 2016-08-30 22:58:48 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 22:58:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 22:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 22:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 22:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 22:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 22:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 22:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 22:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 22:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 22:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 22:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 22:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 22:58:49 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b6bd8c4f0f9a3c083ce1836ed8f53795
DEBUG - 2016-08-30 22:58:49 --> Final output sent to browser
DEBUG - 2016-08-30 22:58:49 --> Total execution time: 2.4610
DEBUG - 2016-08-30 23:06:06 --> Config Class Initialized
DEBUG - 2016-08-30 23:06:06 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:06:06 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:06:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:06:06 --> URI Class Initialized
DEBUG - 2016-08-30 23:06:06 --> Router Class Initialized
DEBUG - 2016-08-30 23:06:06 --> Output Class Initialized
DEBUG - 2016-08-30 23:06:06 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:06:06 --> Security Class Initialized
DEBUG - 2016-08-30 23:06:06 --> Input Class Initialized
DEBUG - 2016-08-30 23:06:06 --> XSS Filtering completed
DEBUG - 2016-08-30 23:06:06 --> XSS Filtering completed
DEBUG - 2016-08-30 23:06:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:06:06 --> Language Class Initialized
DEBUG - 2016-08-30 23:06:06 --> Loader Class Initialized
DEBUG - 2016-08-30 23:06:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:06:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:06:06 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:06:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:06:06 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:06:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:06:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:06:06 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:06:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:06:06 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:06:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:06:07 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:06:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:06:07 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:06:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:06:07 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:06:07 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:06:07 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:06:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:06:07 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:06:07 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:06:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:06:07 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:06:07 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:06:07 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:06:07 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:06:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:06:07 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:06:07 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:06:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:06:07 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:06:07 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:06:07 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:06:07 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:06:07 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:06:07 --> Session Class Initialized
DEBUG - 2016-08-30 23:06:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:06:07 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:06:07 --> Session routines successfully run
DEBUG - 2016-08-30 23:06:07 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:06:08 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:06:08 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:06:08 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:06:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:06:08 --> Controller Class Initialized
DEBUG - 2016-08-30 23:06:08 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:06:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:06:08 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:06:08 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:06:08 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:06:08 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:06:08 --> Model Class Initialized
DEBUG - 2016-08-30 23:06:08 --> Model Class Initialized
DEBUG - 2016-08-30 23:06:08 --> Model Class Initialized
DEBUG - 2016-08-30 23:06:08 --> Model Class Initialized
DEBUG - 2016-08-30 23:06:08 --> Model Class Initialized
DEBUG - 2016-08-30 23:06:08 --> Model Class Initialized
DEBUG - 2016-08-30 23:06:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:06:08 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:06:08 --> Model Class Initialized
DEBUG - 2016-08-30 23:06:08 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:06:08 --> Model Class Initialized
DEBUG - 2016-08-30 23:06:08 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:06:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 23:06:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 23:06:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 23:06:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 23:06:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:06:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:06:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:06:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:06:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:06:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:06:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:06:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:06:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:06:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:06:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:06:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:06:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:06:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:06:09 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 23:06:09 --> Final output sent to browser
DEBUG - 2016-08-30 23:06:09 --> Total execution time: 2.6257
DEBUG - 2016-08-30 23:06:24 --> Config Class Initialized
DEBUG - 2016-08-30 23:06:24 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:06:24 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:06:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:06:24 --> URI Class Initialized
DEBUG - 2016-08-30 23:06:24 --> Router Class Initialized
DEBUG - 2016-08-30 23:06:24 --> Output Class Initialized
DEBUG - 2016-08-30 23:06:24 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:06:24 --> Security Class Initialized
DEBUG - 2016-08-30 23:06:24 --> Input Class Initialized
DEBUG - 2016-08-30 23:06:24 --> XSS Filtering completed
DEBUG - 2016-08-30 23:06:24 --> XSS Filtering completed
DEBUG - 2016-08-30 23:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:06:25 --> Language Class Initialized
DEBUG - 2016-08-30 23:06:25 --> Loader Class Initialized
DEBUG - 2016-08-30 23:06:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:06:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:06:25 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:06:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:06:25 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:06:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:06:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:06:25 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:06:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:06:25 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:06:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:06:25 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:06:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:06:25 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:06:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:06:25 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:06:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:06:25 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:06:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:06:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:06:25 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:06:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:06:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:06:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:06:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:06:25 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:06:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:06:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:06:25 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:06:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:06:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:06:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:06:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:06:26 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:06:26 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:06:26 --> Session Class Initialized
DEBUG - 2016-08-30 23:06:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:06:26 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:06:26 --> Session routines successfully run
DEBUG - 2016-08-30 23:06:26 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:06:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:06:26 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:06:26 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:06:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:06:26 --> Controller Class Initialized
DEBUG - 2016-08-30 23:06:26 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:06:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:06:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:06:26 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:06:26 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:06:26 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:06:26 --> Model Class Initialized
DEBUG - 2016-08-30 23:06:26 --> Model Class Initialized
DEBUG - 2016-08-30 23:06:26 --> Model Class Initialized
DEBUG - 2016-08-30 23:06:26 --> Model Class Initialized
DEBUG - 2016-08-30 23:06:26 --> Model Class Initialized
DEBUG - 2016-08-30 23:06:27 --> Model Class Initialized
DEBUG - 2016-08-30 23:06:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:06:27 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:06:27 --> Model Class Initialized
DEBUG - 2016-08-30 23:06:27 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:06:27 --> Model Class Initialized
DEBUG - 2016-08-30 23:06:27 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 23:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 23:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 23:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 23:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:06:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:06:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 23:06:27 --> Final output sent to browser
DEBUG - 2016-08-30 23:06:27 --> Total execution time: 2.6514
DEBUG - 2016-08-30 23:06:33 --> Config Class Initialized
DEBUG - 2016-08-30 23:06:34 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:06:34 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:06:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:06:34 --> URI Class Initialized
DEBUG - 2016-08-30 23:06:34 --> Router Class Initialized
DEBUG - 2016-08-30 23:06:34 --> Output Class Initialized
DEBUG - 2016-08-30 23:06:34 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:06:34 --> Security Class Initialized
DEBUG - 2016-08-30 23:06:34 --> Input Class Initialized
DEBUG - 2016-08-30 23:06:34 --> XSS Filtering completed
DEBUG - 2016-08-30 23:06:34 --> XSS Filtering completed
DEBUG - 2016-08-30 23:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:06:34 --> Language Class Initialized
DEBUG - 2016-08-30 23:06:34 --> Loader Class Initialized
DEBUG - 2016-08-30 23:06:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:06:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:06:34 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:06:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:06:34 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:06:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:06:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:06:34 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:06:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:06:34 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:06:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:06:34 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:06:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:06:34 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:06:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:06:34 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:06:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:06:35 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:06:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:06:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:06:35 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:06:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:06:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:06:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:06:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:06:35 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:06:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:06:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:06:35 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:06:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:06:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:06:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:06:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:06:35 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:06:35 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:06:35 --> Session Class Initialized
DEBUG - 2016-08-30 23:06:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:06:35 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:06:35 --> Session routines successfully run
DEBUG - 2016-08-30 23:06:35 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:06:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:06:35 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:06:35 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:06:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:06:35 --> Controller Class Initialized
DEBUG - 2016-08-30 23:06:36 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:06:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:06:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:06:36 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:06:36 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:06:36 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:06:36 --> Model Class Initialized
DEBUG - 2016-08-30 23:06:36 --> Model Class Initialized
DEBUG - 2016-08-30 23:06:36 --> Model Class Initialized
DEBUG - 2016-08-30 23:06:36 --> Model Class Initialized
DEBUG - 2016-08-30 23:06:36 --> Model Class Initialized
DEBUG - 2016-08-30 23:06:36 --> Model Class Initialized
DEBUG - 2016-08-30 23:06:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:06:36 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:06:36 --> Model Class Initialized
DEBUG - 2016-08-30 23:06:36 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:06:36 --> Model Class Initialized
DEBUG - 2016-08-30 23:06:36 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:06:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 23:06:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 23:06:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 23:06:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 23:06:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:06:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:06:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:06:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:06:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:06:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:06:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:06:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:06:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:06:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:06:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:06:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:06:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:06:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:06:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 23:06:37 --> Final output sent to browser
DEBUG - 2016-08-30 23:06:37 --> Total execution time: 2.6687
DEBUG - 2016-08-30 23:07:57 --> Config Class Initialized
DEBUG - 2016-08-30 23:07:57 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:07:57 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:07:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:07:57 --> URI Class Initialized
DEBUG - 2016-08-30 23:07:57 --> Router Class Initialized
DEBUG - 2016-08-30 23:07:57 --> Output Class Initialized
DEBUG - 2016-08-30 23:07:57 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:07:57 --> Security Class Initialized
DEBUG - 2016-08-30 23:07:57 --> Input Class Initialized
DEBUG - 2016-08-30 23:07:58 --> XSS Filtering completed
DEBUG - 2016-08-30 23:07:58 --> XSS Filtering completed
DEBUG - 2016-08-30 23:07:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:07:58 --> Language Class Initialized
DEBUG - 2016-08-30 23:07:58 --> Loader Class Initialized
DEBUG - 2016-08-30 23:07:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:07:58 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:07:58 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:07:58 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:07:58 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:07:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:07:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:07:58 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:07:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:07:58 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:07:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:07:58 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:07:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:07:58 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:07:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:07:58 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:07:58 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:07:58 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:07:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:07:58 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:07:58 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:07:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:07:58 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:07:58 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:07:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:07:58 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:07:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:07:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:07:59 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:07:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:07:59 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:07:59 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:07:59 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:07:59 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:07:59 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:07:59 --> Session Class Initialized
DEBUG - 2016-08-30 23:07:59 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:07:59 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:07:59 --> Session routines successfully run
DEBUG - 2016-08-30 23:07:59 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:07:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:07:59 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:07:59 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:07:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:07:59 --> Controller Class Initialized
DEBUG - 2016-08-30 23:07:59 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:07:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:07:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:07:59 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:07:59 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:07:59 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:07:59 --> Model Class Initialized
DEBUG - 2016-08-30 23:07:59 --> Model Class Initialized
DEBUG - 2016-08-30 23:07:59 --> Model Class Initialized
DEBUG - 2016-08-30 23:07:59 --> Model Class Initialized
DEBUG - 2016-08-30 23:07:59 --> Model Class Initialized
DEBUG - 2016-08-30 23:08:00 --> Model Class Initialized
DEBUG - 2016-08-30 23:08:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:08:00 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:08:00 --> Model Class Initialized
DEBUG - 2016-08-30 23:08:00 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:08:00 --> Model Class Initialized
DEBUG - 2016-08-30 23:08:00 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 23:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 23:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 23:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 23:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:08:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:08:00 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 23:08:00 --> Final output sent to browser
DEBUG - 2016-08-30 23:08:00 --> Total execution time: 2.5817
DEBUG - 2016-08-30 23:09:51 --> Config Class Initialized
DEBUG - 2016-08-30 23:09:51 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:09:51 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:09:51 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:09:51 --> URI Class Initialized
DEBUG - 2016-08-30 23:09:51 --> Router Class Initialized
DEBUG - 2016-08-30 23:09:51 --> Output Class Initialized
DEBUG - 2016-08-30 23:09:51 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:09:51 --> Security Class Initialized
DEBUG - 2016-08-30 23:09:51 --> Input Class Initialized
DEBUG - 2016-08-30 23:09:51 --> XSS Filtering completed
DEBUG - 2016-08-30 23:09:51 --> XSS Filtering completed
DEBUG - 2016-08-30 23:09:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:09:51 --> Language Class Initialized
DEBUG - 2016-08-30 23:09:51 --> Loader Class Initialized
DEBUG - 2016-08-30 23:09:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:09:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:09:51 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:09:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:09:51 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:09:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:09:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:09:51 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:09:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:09:51 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:09:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:09:51 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:09:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:09:51 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:09:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:09:52 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:09:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:09:52 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:09:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:09:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:09:52 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:09:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:09:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:09:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:09:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:09:52 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:09:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:09:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:09:52 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:09:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:09:52 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:09:52 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:09:52 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:09:52 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:09:52 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:09:52 --> Session Class Initialized
DEBUG - 2016-08-30 23:09:52 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:09:52 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:09:52 --> Session routines successfully run
DEBUG - 2016-08-30 23:09:52 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:09:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:09:52 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:09:52 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:09:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:09:52 --> Controller Class Initialized
DEBUG - 2016-08-30 23:09:53 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:09:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:09:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:09:53 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:09:53 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:09:53 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:09:53 --> Model Class Initialized
DEBUG - 2016-08-30 23:09:53 --> Model Class Initialized
DEBUG - 2016-08-30 23:09:53 --> Model Class Initialized
DEBUG - 2016-08-30 23:09:53 --> Model Class Initialized
DEBUG - 2016-08-30 23:09:53 --> Model Class Initialized
DEBUG - 2016-08-30 23:09:53 --> Model Class Initialized
DEBUG - 2016-08-30 23:09:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:09:53 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:09:53 --> Model Class Initialized
DEBUG - 2016-08-30 23:09:53 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:09:53 --> Model Class Initialized
DEBUG - 2016-08-30 23:09:53 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:09:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 23:09:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 23:09:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 23:09:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 23:09:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:09:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:09:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:09:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:09:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:09:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:09:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:09:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:09:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:09:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:09:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:09:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:09:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:09:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:09:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 23:09:54 --> Final output sent to browser
DEBUG - 2016-08-30 23:09:54 --> Total execution time: 2.7551
DEBUG - 2016-08-30 23:10:18 --> Config Class Initialized
DEBUG - 2016-08-30 23:10:18 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:10:18 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:10:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:10:18 --> URI Class Initialized
DEBUG - 2016-08-30 23:10:18 --> Router Class Initialized
DEBUG - 2016-08-30 23:10:18 --> Output Class Initialized
DEBUG - 2016-08-30 23:10:18 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:10:18 --> Security Class Initialized
DEBUG - 2016-08-30 23:10:18 --> Input Class Initialized
DEBUG - 2016-08-30 23:10:18 --> XSS Filtering completed
DEBUG - 2016-08-30 23:10:18 --> XSS Filtering completed
DEBUG - 2016-08-30 23:10:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:10:18 --> Language Class Initialized
DEBUG - 2016-08-30 23:10:18 --> Loader Class Initialized
DEBUG - 2016-08-30 23:10:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:10:18 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:10:18 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:10:18 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:10:18 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:10:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:10:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:10:19 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:10:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:10:19 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:10:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:10:19 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:10:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:10:19 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:10:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:10:19 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:10:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:10:19 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:10:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:10:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:10:19 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:10:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:10:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:10:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:10:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:10:19 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:10:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:10:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:10:19 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:10:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:10:19 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:10:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:10:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:10:19 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:10:19 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:10:20 --> Session Class Initialized
DEBUG - 2016-08-30 23:10:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:10:20 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:10:20 --> Session routines successfully run
DEBUG - 2016-08-30 23:10:20 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:10:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:10:20 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:10:20 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:10:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:10:20 --> Controller Class Initialized
DEBUG - 2016-08-30 23:10:20 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:10:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:10:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:10:20 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:10:20 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:10:20 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:10:20 --> Model Class Initialized
DEBUG - 2016-08-30 23:10:20 --> Model Class Initialized
DEBUG - 2016-08-30 23:10:20 --> Model Class Initialized
DEBUG - 2016-08-30 23:10:20 --> Model Class Initialized
DEBUG - 2016-08-30 23:10:20 --> Model Class Initialized
DEBUG - 2016-08-30 23:10:20 --> Model Class Initialized
DEBUG - 2016-08-30 23:10:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:10:20 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:10:20 --> Model Class Initialized
DEBUG - 2016-08-30 23:10:20 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:10:20 --> Model Class Initialized
DEBUG - 2016-08-30 23:10:21 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:10:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 23:10:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 23:10:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 23:10:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 23:10:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:10:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:10:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:10:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:10:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:10:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:10:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:10:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:10:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:10:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:10:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:10:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:10:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:10:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:10:21 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 23:10:21 --> Final output sent to browser
DEBUG - 2016-08-30 23:10:21 --> Total execution time: 2.6498
DEBUG - 2016-08-30 23:11:34 --> Config Class Initialized
DEBUG - 2016-08-30 23:11:34 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:11:34 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:11:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:11:34 --> URI Class Initialized
DEBUG - 2016-08-30 23:11:34 --> Router Class Initialized
DEBUG - 2016-08-30 23:11:35 --> Output Class Initialized
DEBUG - 2016-08-30 23:11:35 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:11:35 --> Security Class Initialized
DEBUG - 2016-08-30 23:11:35 --> Input Class Initialized
DEBUG - 2016-08-30 23:11:35 --> XSS Filtering completed
DEBUG - 2016-08-30 23:11:35 --> XSS Filtering completed
DEBUG - 2016-08-30 23:11:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:11:35 --> Language Class Initialized
DEBUG - 2016-08-30 23:11:35 --> Loader Class Initialized
DEBUG - 2016-08-30 23:11:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:11:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:11:35 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:11:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:11:35 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:11:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:11:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:11:35 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:11:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:11:35 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:11:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:11:35 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:11:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:11:35 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:11:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:11:35 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:11:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:11:35 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:11:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:11:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:11:35 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:11:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:11:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:11:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:11:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:11:36 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:11:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:11:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:11:36 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:11:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:11:36 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:11:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:11:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:11:36 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:11:36 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:11:36 --> Session Class Initialized
DEBUG - 2016-08-30 23:11:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:11:36 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:11:36 --> Session routines successfully run
DEBUG - 2016-08-30 23:11:36 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:11:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:11:36 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:11:36 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:11:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:11:36 --> Controller Class Initialized
DEBUG - 2016-08-30 23:11:36 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:11:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:11:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:11:36 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:11:36 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:11:36 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:11:36 --> Model Class Initialized
DEBUG - 2016-08-30 23:11:37 --> Model Class Initialized
DEBUG - 2016-08-30 23:11:37 --> Model Class Initialized
DEBUG - 2016-08-30 23:11:37 --> Model Class Initialized
DEBUG - 2016-08-30 23:11:37 --> Model Class Initialized
DEBUG - 2016-08-30 23:11:37 --> Model Class Initialized
DEBUG - 2016-08-30 23:11:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:11:37 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:11:37 --> Model Class Initialized
DEBUG - 2016-08-30 23:11:37 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:11:37 --> Model Class Initialized
DEBUG - 2016-08-30 23:11:37 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:11:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 23:11:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 23:11:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 23:11:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 23:11:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:11:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:11:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:11:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:11:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:11:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:11:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:11:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:11:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:11:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:11:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:11:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:11:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:11:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:11:38 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 23:11:38 --> Final output sent to browser
DEBUG - 2016-08-30 23:11:38 --> Total execution time: 2.6292
DEBUG - 2016-08-30 23:13:10 --> Config Class Initialized
DEBUG - 2016-08-30 23:13:10 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:13:10 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:13:11 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:13:11 --> URI Class Initialized
DEBUG - 2016-08-30 23:13:11 --> Router Class Initialized
DEBUG - 2016-08-30 23:13:11 --> Output Class Initialized
DEBUG - 2016-08-30 23:13:11 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:13:11 --> Security Class Initialized
DEBUG - 2016-08-30 23:13:11 --> Input Class Initialized
DEBUG - 2016-08-30 23:13:11 --> XSS Filtering completed
DEBUG - 2016-08-30 23:13:11 --> XSS Filtering completed
DEBUG - 2016-08-30 23:13:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:13:11 --> Language Class Initialized
DEBUG - 2016-08-30 23:13:11 --> Loader Class Initialized
DEBUG - 2016-08-30 23:13:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:13:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:13:11 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:13:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:13:11 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:13:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:13:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:13:11 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:13:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:13:11 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:13:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:13:11 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:13:11 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:13:11 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:13:11 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:13:11 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:13:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:13:12 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:13:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:13:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:13:12 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:13:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:13:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:13:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:13:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:13:12 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:13:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:13:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:13:12 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:13:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:13:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:13:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:13:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:13:12 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:13:12 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:13:12 --> Session Class Initialized
DEBUG - 2016-08-30 23:13:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:13:12 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:13:12 --> Session routines successfully run
DEBUG - 2016-08-30 23:13:12 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:13:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:13:12 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:13:12 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:13:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:13:13 --> Controller Class Initialized
DEBUG - 2016-08-30 23:13:13 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:13:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:13:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:13:13 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:13:13 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:13:13 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:13:13 --> Model Class Initialized
DEBUG - 2016-08-30 23:13:13 --> Model Class Initialized
DEBUG - 2016-08-30 23:13:13 --> Model Class Initialized
DEBUG - 2016-08-30 23:13:13 --> Model Class Initialized
DEBUG - 2016-08-30 23:13:13 --> Model Class Initialized
DEBUG - 2016-08-30 23:13:13 --> Model Class Initialized
DEBUG - 2016-08-30 23:13:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:13:13 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:13:13 --> Model Class Initialized
DEBUG - 2016-08-30 23:13:13 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:13:13 --> Model Class Initialized
DEBUG - 2016-08-30 23:13:13 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:13:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 23:13:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 23:13:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 23:13:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 23:13:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:13:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:13:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:13:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:13:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:13:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:13:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:13:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:13:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:13:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:13:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:13:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:13:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:13:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:13:14 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b6bd8c4f0f9a3c083ce1836ed8f53795
DEBUG - 2016-08-30 23:13:14 --> Final output sent to browser
DEBUG - 2016-08-30 23:13:14 --> Total execution time: 2.8271
DEBUG - 2016-08-30 23:14:58 --> Config Class Initialized
DEBUG - 2016-08-30 23:14:58 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:14:58 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:14:58 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:14:58 --> URI Class Initialized
DEBUG - 2016-08-30 23:14:58 --> Router Class Initialized
DEBUG - 2016-08-30 23:14:58 --> Output Class Initialized
DEBUG - 2016-08-30 23:14:58 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:14:58 --> Security Class Initialized
DEBUG - 2016-08-30 23:14:58 --> Input Class Initialized
DEBUG - 2016-08-30 23:14:58 --> XSS Filtering completed
DEBUG - 2016-08-30 23:14:58 --> XSS Filtering completed
DEBUG - 2016-08-30 23:14:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:14:58 --> Language Class Initialized
DEBUG - 2016-08-30 23:14:58 --> Loader Class Initialized
DEBUG - 2016-08-30 23:14:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:14:58 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:14:58 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:14:58 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:14:58 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:14:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:14:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:14:58 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:14:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:14:58 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:14:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:14:58 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:14:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:14:59 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:14:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:14:59 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:14:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:14:59 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:14:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:14:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:14:59 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:14:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:14:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:14:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:14:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:14:59 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:14:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:14:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:14:59 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:14:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:14:59 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:14:59 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:14:59 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:14:59 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:14:59 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:14:59 --> Session Class Initialized
DEBUG - 2016-08-30 23:14:59 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:14:59 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:14:59 --> Session routines successfully run
DEBUG - 2016-08-30 23:14:59 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:14:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:15:00 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:15:00 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:15:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:15:00 --> Controller Class Initialized
DEBUG - 2016-08-30 23:15:00 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:15:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:15:00 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:15:00 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:15:00 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:15:00 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:15:00 --> Model Class Initialized
DEBUG - 2016-08-30 23:15:00 --> Model Class Initialized
DEBUG - 2016-08-30 23:15:00 --> Model Class Initialized
DEBUG - 2016-08-30 23:15:00 --> Model Class Initialized
DEBUG - 2016-08-30 23:15:00 --> Model Class Initialized
DEBUG - 2016-08-30 23:15:00 --> Model Class Initialized
DEBUG - 2016-08-30 23:15:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:15:00 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:15:00 --> Model Class Initialized
DEBUG - 2016-08-30 23:15:00 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:15:00 --> Model Class Initialized
DEBUG - 2016-08-30 23:15:00 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:15:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 23:15:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 23:15:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 23:15:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 23:15:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:15:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:15:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:15:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:15:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:15:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:15:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:15:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:15:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:15:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:15:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:15:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:15:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:15:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:15:01 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b6bd8c4f0f9a3c083ce1836ed8f53795
DEBUG - 2016-08-30 23:15:01 --> Final output sent to browser
DEBUG - 2016-08-30 23:15:01 --> Total execution time: 2.7225
DEBUG - 2016-08-30 23:22:55 --> Config Class Initialized
DEBUG - 2016-08-30 23:22:55 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:22:55 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:22:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:22:55 --> URI Class Initialized
DEBUG - 2016-08-30 23:22:55 --> Router Class Initialized
DEBUG - 2016-08-30 23:22:56 --> Output Class Initialized
DEBUG - 2016-08-30 23:22:56 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:22:56 --> Security Class Initialized
DEBUG - 2016-08-30 23:22:56 --> Input Class Initialized
DEBUG - 2016-08-30 23:22:56 --> XSS Filtering completed
DEBUG - 2016-08-30 23:22:56 --> XSS Filtering completed
DEBUG - 2016-08-30 23:22:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:22:56 --> Language Class Initialized
DEBUG - 2016-08-30 23:22:56 --> Loader Class Initialized
DEBUG - 2016-08-30 23:22:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:22:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:22:56 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:22:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:22:56 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:22:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:22:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:22:56 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:22:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:22:56 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:22:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:22:56 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:22:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:22:56 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:22:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:22:56 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:22:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:22:56 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:22:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:22:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:22:57 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:22:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:22:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:22:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:22:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:22:57 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:22:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:22:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:22:57 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:22:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:22:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:22:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:22:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:22:57 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:22:57 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:22:57 --> Session Class Initialized
DEBUG - 2016-08-30 23:22:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:22:57 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:22:57 --> Session routines successfully run
DEBUG - 2016-08-30 23:22:57 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:22:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:22:57 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:22:57 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:22:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:22:57 --> Controller Class Initialized
DEBUG - 2016-08-30 23:22:57 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:22:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:22:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:22:57 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:22:58 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:22:58 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:22:58 --> Model Class Initialized
DEBUG - 2016-08-30 23:22:58 --> Model Class Initialized
DEBUG - 2016-08-30 23:22:58 --> Model Class Initialized
DEBUG - 2016-08-30 23:22:58 --> Model Class Initialized
DEBUG - 2016-08-30 23:22:58 --> Model Class Initialized
DEBUG - 2016-08-30 23:22:58 --> Model Class Initialized
DEBUG - 2016-08-30 23:22:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:22:58 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:22:58 --> Model Class Initialized
DEBUG - 2016-08-30 23:22:58 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:22:58 --> Model Class Initialized
DEBUG - 2016-08-30 23:22:58 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:22:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 23:22:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 23:22:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 23:22:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 23:22:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:22:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:22:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:22:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:22:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:22:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:22:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:22:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:22:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:22:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:22:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:22:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:22:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:22:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:22:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b6bd8c4f0f9a3c083ce1836ed8f53795
DEBUG - 2016-08-30 23:22:59 --> Final output sent to browser
DEBUG - 2016-08-30 23:22:59 --> Total execution time: 2.7340
DEBUG - 2016-08-30 23:23:16 --> Config Class Initialized
DEBUG - 2016-08-30 23:23:16 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:23:16 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:23:17 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:23:17 --> URI Class Initialized
DEBUG - 2016-08-30 23:23:17 --> Router Class Initialized
DEBUG - 2016-08-30 23:23:17 --> Output Class Initialized
DEBUG - 2016-08-30 23:23:17 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:23:17 --> Security Class Initialized
DEBUG - 2016-08-30 23:23:17 --> Input Class Initialized
DEBUG - 2016-08-30 23:23:17 --> XSS Filtering completed
DEBUG - 2016-08-30 23:23:17 --> XSS Filtering completed
DEBUG - 2016-08-30 23:23:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:23:17 --> Language Class Initialized
DEBUG - 2016-08-30 23:23:17 --> Loader Class Initialized
DEBUG - 2016-08-30 23:23:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:23:17 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:23:17 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:23:17 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:23:17 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:23:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:23:17 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:23:17 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:23:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:23:17 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:23:17 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:23:17 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:23:17 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:23:17 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:23:17 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:23:17 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:23:18 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:23:18 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:23:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:23:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:23:18 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:23:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:23:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:23:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:23:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:23:18 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:23:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:23:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:23:18 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:23:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:23:18 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:23:18 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:23:18 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:23:18 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:23:18 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:23:18 --> Session Class Initialized
DEBUG - 2016-08-30 23:23:18 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:23:18 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:23:18 --> Session routines successfully run
DEBUG - 2016-08-30 23:23:18 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:23:18 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:23:18 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:23:18 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:23:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:23:19 --> Controller Class Initialized
DEBUG - 2016-08-30 23:23:19 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:23:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:23:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:23:19 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:23:19 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:23:19 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:23:19 --> Model Class Initialized
DEBUG - 2016-08-30 23:23:19 --> Model Class Initialized
DEBUG - 2016-08-30 23:23:19 --> Model Class Initialized
DEBUG - 2016-08-30 23:23:19 --> Model Class Initialized
DEBUG - 2016-08-30 23:23:19 --> Model Class Initialized
DEBUG - 2016-08-30 23:23:19 --> Model Class Initialized
DEBUG - 2016-08-30 23:23:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:23:19 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:23:19 --> Model Class Initialized
DEBUG - 2016-08-30 23:23:19 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:23:19 --> Model Class Initialized
DEBUG - 2016-08-30 23:23:19 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:23:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 23:23:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 23:23:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 23:23:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 23:23:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:23:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:23:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:23:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:23:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:23:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:23:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:23:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:23:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:23:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:23:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:23:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:23:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:23:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:23:20 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b6bd8c4f0f9a3c083ce1836ed8f53795
DEBUG - 2016-08-30 23:23:20 --> Final output sent to browser
DEBUG - 2016-08-30 23:23:20 --> Total execution time: 2.8081
DEBUG - 2016-08-30 23:23:34 --> Config Class Initialized
DEBUG - 2016-08-30 23:23:34 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:23:34 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:23:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:23:34 --> URI Class Initialized
DEBUG - 2016-08-30 23:23:34 --> Router Class Initialized
DEBUG - 2016-08-30 23:23:34 --> Output Class Initialized
DEBUG - 2016-08-30 23:23:34 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:23:34 --> Security Class Initialized
DEBUG - 2016-08-30 23:23:34 --> Input Class Initialized
DEBUG - 2016-08-30 23:23:34 --> XSS Filtering completed
DEBUG - 2016-08-30 23:23:34 --> XSS Filtering completed
DEBUG - 2016-08-30 23:23:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:23:34 --> Language Class Initialized
DEBUG - 2016-08-30 23:23:34 --> Loader Class Initialized
DEBUG - 2016-08-30 23:23:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:23:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:23:34 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:23:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:23:34 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:23:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:23:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:23:35 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:23:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:23:35 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:23:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:23:35 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:23:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:23:35 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:23:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:23:35 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:23:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:23:35 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:23:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:23:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:23:35 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:23:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:23:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:23:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:23:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:23:35 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:23:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:23:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:23:35 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:23:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:23:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:23:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:23:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:23:36 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:23:36 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:23:36 --> Session Class Initialized
DEBUG - 2016-08-30 23:23:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:23:36 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:23:36 --> Session routines successfully run
DEBUG - 2016-08-30 23:23:36 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:23:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:23:36 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:23:36 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:23:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:23:36 --> Controller Class Initialized
DEBUG - 2016-08-30 23:23:36 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:23:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:23:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:23:36 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:23:36 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:23:36 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:23:36 --> Model Class Initialized
DEBUG - 2016-08-30 23:23:36 --> Model Class Initialized
DEBUG - 2016-08-30 23:23:36 --> Model Class Initialized
DEBUG - 2016-08-30 23:23:36 --> Model Class Initialized
DEBUG - 2016-08-30 23:23:36 --> Model Class Initialized
DEBUG - 2016-08-30 23:23:36 --> Model Class Initialized
DEBUG - 2016-08-30 23:23:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:23:37 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:23:37 --> Model Class Initialized
DEBUG - 2016-08-30 23:23:37 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:23:37 --> Model Class Initialized
DEBUG - 2016-08-30 23:23:37 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:23:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 23:23:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 23:23:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 23:23:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 23:23:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:23:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:23:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:23:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:23:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:23:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:23:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:23:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:23:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:23:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:23:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:23:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:23:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:23:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:23:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b6bd8c4f0f9a3c083ce1836ed8f53795
DEBUG - 2016-08-30 23:23:37 --> Final output sent to browser
DEBUG - 2016-08-30 23:23:37 --> Total execution time: 2.9159
DEBUG - 2016-08-30 23:23:45 --> Config Class Initialized
DEBUG - 2016-08-30 23:23:45 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:23:45 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:23:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:23:45 --> URI Class Initialized
DEBUG - 2016-08-30 23:23:45 --> Router Class Initialized
DEBUG - 2016-08-30 23:23:45 --> Output Class Initialized
DEBUG - 2016-08-30 23:23:45 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:23:45 --> Security Class Initialized
DEBUG - 2016-08-30 23:23:45 --> Input Class Initialized
DEBUG - 2016-08-30 23:23:45 --> XSS Filtering completed
DEBUG - 2016-08-30 23:23:45 --> XSS Filtering completed
DEBUG - 2016-08-30 23:23:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:23:45 --> Language Class Initialized
DEBUG - 2016-08-30 23:23:45 --> Loader Class Initialized
DEBUG - 2016-08-30 23:23:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:23:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:23:45 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:23:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:23:46 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:23:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:23:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:23:46 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:23:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:23:46 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:23:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:23:46 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:23:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:23:46 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:23:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:23:46 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:23:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:23:46 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:23:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:23:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:23:46 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:23:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:23:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:23:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:23:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:23:46 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:23:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:23:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:23:46 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:23:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:23:46 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:23:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:23:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:23:47 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:23:47 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:23:47 --> Session Class Initialized
DEBUG - 2016-08-30 23:23:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:23:47 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:23:47 --> Session routines successfully run
DEBUG - 2016-08-30 23:23:47 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:23:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:23:47 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:23:47 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:23:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:23:47 --> Controller Class Initialized
DEBUG - 2016-08-30 23:23:47 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:23:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:23:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:23:47 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:23:47 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:23:47 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:23:47 --> Model Class Initialized
DEBUG - 2016-08-30 23:23:47 --> Model Class Initialized
DEBUG - 2016-08-30 23:23:47 --> Model Class Initialized
DEBUG - 2016-08-30 23:23:47 --> Model Class Initialized
DEBUG - 2016-08-30 23:23:47 --> Model Class Initialized
DEBUG - 2016-08-30 23:23:47 --> Model Class Initialized
DEBUG - 2016-08-30 23:23:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:23:48 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:23:48 --> Model Class Initialized
DEBUG - 2016-08-30 23:23:48 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:23:48 --> Model Class Initialized
DEBUG - 2016-08-30 23:23:48 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:23:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 23:23:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 23:23:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 23:23:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 23:23:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:23:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:23:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:23:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:23:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:23:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:23:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:23:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:23:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:23:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:23:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:23:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:23:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:23:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:23:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b6bd8c4f0f9a3c083ce1836ed8f53795
DEBUG - 2016-08-30 23:23:48 --> Final output sent to browser
DEBUG - 2016-08-30 23:23:49 --> Total execution time: 2.8781
DEBUG - 2016-08-30 23:24:35 --> Config Class Initialized
DEBUG - 2016-08-30 23:24:35 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:24:35 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:24:35 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:24:35 --> URI Class Initialized
DEBUG - 2016-08-30 23:24:35 --> Router Class Initialized
DEBUG - 2016-08-30 23:24:35 --> Output Class Initialized
DEBUG - 2016-08-30 23:24:35 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:24:35 --> Security Class Initialized
DEBUG - 2016-08-30 23:24:35 --> Input Class Initialized
DEBUG - 2016-08-30 23:24:35 --> XSS Filtering completed
DEBUG - 2016-08-30 23:24:35 --> XSS Filtering completed
DEBUG - 2016-08-30 23:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:24:35 --> Language Class Initialized
DEBUG - 2016-08-30 23:24:35 --> Loader Class Initialized
DEBUG - 2016-08-30 23:24:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:24:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:24:35 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:24:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:24:36 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:24:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:24:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:24:36 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:24:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:24:36 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:24:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:24:36 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:24:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:24:36 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:24:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:24:36 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:24:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:24:36 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:24:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:24:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:24:36 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:24:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:24:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:24:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:24:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:24:36 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:24:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:24:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:24:36 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:24:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:24:36 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:24:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:24:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:24:37 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:24:37 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:24:37 --> Session Class Initialized
DEBUG - 2016-08-30 23:24:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:24:37 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:24:37 --> Session routines successfully run
DEBUG - 2016-08-30 23:24:37 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:24:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:24:37 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:24:37 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:24:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:24:37 --> Controller Class Initialized
DEBUG - 2016-08-30 23:24:37 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:24:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:24:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:24:37 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:24:37 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:24:37 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:24:37 --> Model Class Initialized
DEBUG - 2016-08-30 23:24:37 --> Model Class Initialized
DEBUG - 2016-08-30 23:24:37 --> Model Class Initialized
DEBUG - 2016-08-30 23:24:37 --> Model Class Initialized
DEBUG - 2016-08-30 23:24:37 --> Model Class Initialized
DEBUG - 2016-08-30 23:24:37 --> Model Class Initialized
DEBUG - 2016-08-30 23:24:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:24:38 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:24:38 --> Model Class Initialized
DEBUG - 2016-08-30 23:24:38 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:24:38 --> Model Class Initialized
DEBUG - 2016-08-30 23:24:38 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:24:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 23:24:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 23:24:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 23:24:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 23:24:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:24:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:24:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:24:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:24:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:24:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:24:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:24:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:24:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:24:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:24:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:24:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:24:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:24:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:24:38 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b6bd8c4f0f9a3c083ce1836ed8f53795
DEBUG - 2016-08-30 23:24:38 --> Final output sent to browser
DEBUG - 2016-08-30 23:24:38 --> Total execution time: 2.8688
DEBUG - 2016-08-30 23:27:45 --> Config Class Initialized
DEBUG - 2016-08-30 23:27:45 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:27:45 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:27:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:27:45 --> URI Class Initialized
DEBUG - 2016-08-30 23:27:45 --> Router Class Initialized
DEBUG - 2016-08-30 23:27:45 --> Output Class Initialized
DEBUG - 2016-08-30 23:27:45 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:27:45 --> Security Class Initialized
DEBUG - 2016-08-30 23:27:45 --> Input Class Initialized
DEBUG - 2016-08-30 23:27:46 --> XSS Filtering completed
DEBUG - 2016-08-30 23:27:46 --> XSS Filtering completed
DEBUG - 2016-08-30 23:27:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:27:46 --> Language Class Initialized
DEBUG - 2016-08-30 23:27:46 --> Loader Class Initialized
DEBUG - 2016-08-30 23:27:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:27:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:27:46 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:27:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:27:46 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:27:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:27:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:27:46 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:27:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:27:46 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:27:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:27:46 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:27:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:27:46 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:27:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:27:46 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:27:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:27:46 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:27:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:27:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:27:46 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:27:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:27:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:27:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:27:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:27:47 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:27:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:27:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:27:47 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:27:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:27:47 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:27:47 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:27:47 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:27:47 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:27:47 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:27:47 --> Session Class Initialized
DEBUG - 2016-08-30 23:27:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:27:47 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:27:47 --> Session routines successfully run
DEBUG - 2016-08-30 23:27:47 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:27:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:27:47 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:27:47 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:27:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:27:47 --> Controller Class Initialized
DEBUG - 2016-08-30 23:27:47 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:27:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:27:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:27:48 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:27:48 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:27:48 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:27:48 --> Model Class Initialized
DEBUG - 2016-08-30 23:27:48 --> Model Class Initialized
DEBUG - 2016-08-30 23:27:48 --> Model Class Initialized
DEBUG - 2016-08-30 23:27:48 --> Model Class Initialized
DEBUG - 2016-08-30 23:27:48 --> Model Class Initialized
DEBUG - 2016-08-30 23:27:48 --> Model Class Initialized
DEBUG - 2016-08-30 23:27:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:27:48 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:27:48 --> Model Class Initialized
DEBUG - 2016-08-30 23:27:48 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:27:48 --> Model Class Initialized
DEBUG - 2016-08-30 23:27:48 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:27:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 23:27:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 23:27:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 23:27:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 23:27:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:27:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:27:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:27:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:27:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:27:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:27:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:27:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:27:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:27:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:27:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:27:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:27:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:27:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:27:49 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 23:27:49 --> Final output sent to browser
DEBUG - 2016-08-30 23:27:49 --> Total execution time: 2.9411
DEBUG - 2016-08-30 23:30:32 --> Config Class Initialized
DEBUG - 2016-08-30 23:30:32 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:30:32 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:30:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:30:32 --> URI Class Initialized
DEBUG - 2016-08-30 23:30:32 --> Router Class Initialized
DEBUG - 2016-08-30 23:30:32 --> Output Class Initialized
DEBUG - 2016-08-30 23:30:32 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:30:32 --> Security Class Initialized
DEBUG - 2016-08-30 23:30:32 --> Input Class Initialized
DEBUG - 2016-08-30 23:30:32 --> XSS Filtering completed
DEBUG - 2016-08-30 23:30:32 --> XSS Filtering completed
DEBUG - 2016-08-30 23:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:30:32 --> Language Class Initialized
DEBUG - 2016-08-30 23:30:32 --> Loader Class Initialized
DEBUG - 2016-08-30 23:30:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:30:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:30:33 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:30:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:30:33 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:30:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:30:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:30:33 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:30:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:30:33 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:30:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:30:33 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:30:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:30:33 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:30:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:30:33 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:30:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:30:33 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:30:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:30:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:30:33 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:30:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:30:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:30:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:30:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:30:33 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:30:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:30:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:30:33 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:30:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:30:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:30:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:30:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:30:34 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:30:34 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:30:34 --> Session Class Initialized
DEBUG - 2016-08-30 23:30:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:30:34 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:30:34 --> Session routines successfully run
DEBUG - 2016-08-30 23:30:34 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:30:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:30:34 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:30:34 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:30:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:30:34 --> Controller Class Initialized
DEBUG - 2016-08-30 23:30:34 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:30:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:30:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:30:34 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:30:34 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:30:34 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:30:34 --> Model Class Initialized
DEBUG - 2016-08-30 23:30:34 --> Model Class Initialized
DEBUG - 2016-08-30 23:30:34 --> Model Class Initialized
DEBUG - 2016-08-30 23:30:34 --> Model Class Initialized
DEBUG - 2016-08-30 23:30:34 --> Model Class Initialized
DEBUG - 2016-08-30 23:30:35 --> Model Class Initialized
DEBUG - 2016-08-30 23:30:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:30:35 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:30:35 --> Model Class Initialized
DEBUG - 2016-08-30 23:30:35 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:30:35 --> Model Class Initialized
DEBUG - 2016-08-30 23:30:35 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:30:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 23:30:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 23:30:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 23:30:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 23:30:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:30:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:30:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:30:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:30:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:30:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:30:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:30:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:30:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:30:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:30:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:30:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:30:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:30:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:30:35 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b6bd8c4f0f9a3c083ce1836ed8f53795
DEBUG - 2016-08-30 23:30:36 --> Final output sent to browser
DEBUG - 2016-08-30 23:30:36 --> Total execution time: 2.8942
DEBUG - 2016-08-30 23:32:47 --> Config Class Initialized
DEBUG - 2016-08-30 23:32:47 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:32:47 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:32:47 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:32:47 --> URI Class Initialized
DEBUG - 2016-08-30 23:32:47 --> Router Class Initialized
DEBUG - 2016-08-30 23:32:47 --> Output Class Initialized
DEBUG - 2016-08-30 23:32:47 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:32:47 --> Security Class Initialized
DEBUG - 2016-08-30 23:32:47 --> Input Class Initialized
DEBUG - 2016-08-30 23:32:47 --> XSS Filtering completed
DEBUG - 2016-08-30 23:32:47 --> XSS Filtering completed
DEBUG - 2016-08-30 23:32:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:32:48 --> Language Class Initialized
DEBUG - 2016-08-30 23:32:48 --> Loader Class Initialized
DEBUG - 2016-08-30 23:32:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:32:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:32:48 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:32:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:32:48 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:32:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:32:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:32:48 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:32:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:32:48 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:32:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:32:48 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:32:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:32:48 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:32:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:32:48 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:32:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:32:48 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:32:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:32:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:32:48 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:32:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:32:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:32:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:32:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:32:48 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:32:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:32:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:32:49 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:32:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:32:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:32:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:32:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:32:49 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:32:49 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:32:49 --> Session Class Initialized
DEBUG - 2016-08-30 23:32:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:32:49 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:32:49 --> Session routines successfully run
DEBUG - 2016-08-30 23:32:49 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:32:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:32:49 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:32:49 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:32:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:32:49 --> Controller Class Initialized
DEBUG - 2016-08-30 23:32:49 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:32:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:32:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:32:49 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:32:49 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:32:49 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:32:49 --> Model Class Initialized
DEBUG - 2016-08-30 23:32:49 --> Model Class Initialized
DEBUG - 2016-08-30 23:32:49 --> Model Class Initialized
DEBUG - 2016-08-30 23:32:50 --> Model Class Initialized
DEBUG - 2016-08-30 23:32:50 --> Model Class Initialized
DEBUG - 2016-08-30 23:32:50 --> Model Class Initialized
DEBUG - 2016-08-30 23:32:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:32:50 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:32:50 --> Model Class Initialized
DEBUG - 2016-08-30 23:32:50 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:32:50 --> Model Class Initialized
DEBUG - 2016-08-30 23:32:50 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 23:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 23:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 23:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 23:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:32:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:32:51 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 23:32:51 --> Final output sent to browser
DEBUG - 2016-08-30 23:32:51 --> Total execution time: 2.8373
DEBUG - 2016-08-30 23:33:29 --> Config Class Initialized
DEBUG - 2016-08-30 23:33:29 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:33:29 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:33:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:33:29 --> URI Class Initialized
DEBUG - 2016-08-30 23:33:29 --> Router Class Initialized
DEBUG - 2016-08-30 23:33:29 --> Output Class Initialized
DEBUG - 2016-08-30 23:33:29 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:33:29 --> Security Class Initialized
DEBUG - 2016-08-30 23:33:29 --> Input Class Initialized
DEBUG - 2016-08-30 23:33:29 --> XSS Filtering completed
DEBUG - 2016-08-30 23:33:29 --> XSS Filtering completed
DEBUG - 2016-08-30 23:33:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:33:29 --> Language Class Initialized
DEBUG - 2016-08-30 23:33:29 --> Loader Class Initialized
DEBUG - 2016-08-30 23:33:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:33:29 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:33:29 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:33:29 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:33:29 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:33:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:33:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:33:29 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:33:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:33:29 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:33:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:33:30 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:33:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:33:30 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:33:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:33:30 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:33:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:33:30 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:33:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:33:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:33:30 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:33:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:33:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:33:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:33:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:33:30 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:33:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:33:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:33:30 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:33:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:33:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:33:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:33:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:33:30 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:33:30 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:33:30 --> Session Class Initialized
DEBUG - 2016-08-30 23:33:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:33:30 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:33:31 --> Session routines successfully run
DEBUG - 2016-08-30 23:33:31 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:33:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:33:31 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:33:31 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:33:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:33:31 --> Controller Class Initialized
DEBUG - 2016-08-30 23:33:31 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:33:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:33:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:33:31 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:33:31 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:33:31 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:33:31 --> Model Class Initialized
DEBUG - 2016-08-30 23:33:31 --> Model Class Initialized
DEBUG - 2016-08-30 23:33:31 --> Model Class Initialized
DEBUG - 2016-08-30 23:33:31 --> Model Class Initialized
DEBUG - 2016-08-30 23:33:31 --> Model Class Initialized
DEBUG - 2016-08-30 23:33:31 --> Model Class Initialized
DEBUG - 2016-08-30 23:33:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:33:31 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:33:31 --> Model Class Initialized
DEBUG - 2016-08-30 23:33:31 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:33:31 --> Model Class Initialized
DEBUG - 2016-08-30 23:33:31 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 23:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 23:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 23:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 23:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:33:32 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 23:33:32 --> Final output sent to browser
DEBUG - 2016-08-30 23:33:32 --> Total execution time: 2.9615
DEBUG - 2016-08-30 23:33:42 --> Config Class Initialized
DEBUG - 2016-08-30 23:33:42 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:33:42 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:33:43 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:33:43 --> URI Class Initialized
DEBUG - 2016-08-30 23:33:43 --> Router Class Initialized
DEBUG - 2016-08-30 23:33:43 --> Output Class Initialized
DEBUG - 2016-08-30 23:33:43 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:33:43 --> Security Class Initialized
DEBUG - 2016-08-30 23:33:43 --> Input Class Initialized
DEBUG - 2016-08-30 23:33:43 --> XSS Filtering completed
DEBUG - 2016-08-30 23:33:43 --> XSS Filtering completed
DEBUG - 2016-08-30 23:33:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:33:43 --> Language Class Initialized
DEBUG - 2016-08-30 23:33:43 --> Loader Class Initialized
DEBUG - 2016-08-30 23:33:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:33:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:33:43 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:33:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:33:43 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:33:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:33:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:33:43 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:33:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:33:43 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:33:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:33:43 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:33:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:33:43 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:33:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:33:44 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:33:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:33:44 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:33:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:33:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:33:44 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:33:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:33:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:33:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:33:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:33:44 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:33:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:33:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:33:44 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:33:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:33:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:33:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:33:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:33:44 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:33:44 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:33:44 --> Session Class Initialized
DEBUG - 2016-08-30 23:33:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:33:44 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:33:44 --> Session routines successfully run
DEBUG - 2016-08-30 23:33:44 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:33:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:33:45 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:33:45 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:33:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:33:45 --> Controller Class Initialized
DEBUG - 2016-08-30 23:33:45 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:33:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:33:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:33:45 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:33:45 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:33:45 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:33:45 --> Model Class Initialized
DEBUG - 2016-08-30 23:33:45 --> Model Class Initialized
DEBUG - 2016-08-30 23:33:45 --> Model Class Initialized
DEBUG - 2016-08-30 23:33:45 --> Model Class Initialized
DEBUG - 2016-08-30 23:33:45 --> Model Class Initialized
DEBUG - 2016-08-30 23:33:45 --> Model Class Initialized
DEBUG - 2016-08-30 23:33:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:33:45 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:33:45 --> Model Class Initialized
DEBUG - 2016-08-30 23:33:45 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:33:45 --> Model Class Initialized
DEBUG - 2016-08-30 23:33:45 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:33:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 23:33:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 23:33:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 23:33:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 23:33:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:33:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:33:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:33:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:33:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:33:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:33:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:33:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:33:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:33:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:33:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:33:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:33:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:33:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:33:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 23:33:46 --> Final output sent to browser
DEBUG - 2016-08-30 23:33:46 --> Total execution time: 2.9729
DEBUG - 2016-08-30 23:34:19 --> Config Class Initialized
DEBUG - 2016-08-30 23:34:19 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:34:19 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:34:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:34:19 --> URI Class Initialized
DEBUG - 2016-08-30 23:34:19 --> Router Class Initialized
DEBUG - 2016-08-30 23:34:19 --> Output Class Initialized
DEBUG - 2016-08-30 23:34:19 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:34:19 --> Security Class Initialized
DEBUG - 2016-08-30 23:34:19 --> Input Class Initialized
DEBUG - 2016-08-30 23:34:20 --> XSS Filtering completed
DEBUG - 2016-08-30 23:34:20 --> XSS Filtering completed
DEBUG - 2016-08-30 23:34:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:34:20 --> Language Class Initialized
DEBUG - 2016-08-30 23:34:20 --> Loader Class Initialized
DEBUG - 2016-08-30 23:34:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:34:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:34:20 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:34:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:34:20 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:34:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:34:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:34:20 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:34:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:34:20 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:34:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:34:20 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:34:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:34:20 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:34:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:34:20 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:34:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:34:20 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:34:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:34:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:34:20 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:34:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:34:21 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:34:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:34:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:34:21 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:34:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:34:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:34:21 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:34:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:34:21 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:34:21 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:34:21 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:34:21 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:34:21 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:34:21 --> Session Class Initialized
DEBUG - 2016-08-30 23:34:21 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:34:21 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:34:21 --> Session routines successfully run
DEBUG - 2016-08-30 23:34:21 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:34:21 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:34:21 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:34:21 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:34:21 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:34:21 --> Controller Class Initialized
DEBUG - 2016-08-30 23:34:21 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:34:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:34:22 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:34:22 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:34:22 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:34:22 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:34:22 --> Model Class Initialized
DEBUG - 2016-08-30 23:34:22 --> Model Class Initialized
DEBUG - 2016-08-30 23:34:22 --> Model Class Initialized
DEBUG - 2016-08-30 23:34:22 --> Model Class Initialized
DEBUG - 2016-08-30 23:34:22 --> Model Class Initialized
DEBUG - 2016-08-30 23:34:22 --> Model Class Initialized
DEBUG - 2016-08-30 23:34:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:34:22 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:34:22 --> Model Class Initialized
DEBUG - 2016-08-30 23:34:22 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:34:22 --> Model Class Initialized
DEBUG - 2016-08-30 23:34:22 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:34:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 23:34:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 23:34:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 23:34:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 23:34:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:34:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:34:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:34:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:34:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:34:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:34:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:34:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:34:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:34:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:34:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:34:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:34:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:34:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:34:23 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 23:34:23 --> Final output sent to browser
DEBUG - 2016-08-30 23:34:23 --> Total execution time: 2.9890
DEBUG - 2016-08-30 23:34:37 --> Config Class Initialized
DEBUG - 2016-08-30 23:34:37 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:34:37 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:34:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:34:37 --> URI Class Initialized
DEBUG - 2016-08-30 23:34:37 --> Router Class Initialized
DEBUG - 2016-08-30 23:34:37 --> Output Class Initialized
DEBUG - 2016-08-30 23:34:37 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:34:37 --> Security Class Initialized
DEBUG - 2016-08-30 23:34:37 --> Input Class Initialized
DEBUG - 2016-08-30 23:34:37 --> XSS Filtering completed
DEBUG - 2016-08-30 23:34:37 --> XSS Filtering completed
DEBUG - 2016-08-30 23:34:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:34:37 --> Language Class Initialized
DEBUG - 2016-08-30 23:34:37 --> Loader Class Initialized
DEBUG - 2016-08-30 23:34:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:34:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:34:37 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:34:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:34:37 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:34:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:34:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:34:37 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:34:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:34:37 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:34:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:34:38 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:34:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:34:38 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:34:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:34:38 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:34:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:34:38 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:34:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:34:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:34:38 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:34:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:34:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:34:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:34:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:34:38 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:34:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:34:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:34:38 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:34:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:34:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:34:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:34:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:34:38 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:34:38 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:34:39 --> Session Class Initialized
DEBUG - 2016-08-30 23:34:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:34:39 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:34:39 --> Session routines successfully run
DEBUG - 2016-08-30 23:34:39 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:34:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:34:39 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:34:39 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:34:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:34:39 --> Controller Class Initialized
DEBUG - 2016-08-30 23:34:39 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:34:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:34:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:34:39 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:34:39 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:34:39 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:34:39 --> Model Class Initialized
DEBUG - 2016-08-30 23:34:39 --> Model Class Initialized
DEBUG - 2016-08-30 23:34:39 --> Model Class Initialized
DEBUG - 2016-08-30 23:34:39 --> Model Class Initialized
DEBUG - 2016-08-30 23:34:39 --> Model Class Initialized
DEBUG - 2016-08-30 23:34:39 --> Model Class Initialized
DEBUG - 2016-08-30 23:34:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:34:39 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:34:39 --> Model Class Initialized
DEBUG - 2016-08-30 23:34:40 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:34:40 --> Model Class Initialized
DEBUG - 2016-08-30 23:34:40 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 23:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 23:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 23:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 23:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:34:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 23:34:40 --> Final output sent to browser
DEBUG - 2016-08-30 23:34:40 --> Total execution time: 3.0662
DEBUG - 2016-08-30 23:36:44 --> Config Class Initialized
DEBUG - 2016-08-30 23:36:44 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:36:44 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:36:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:36:44 --> URI Class Initialized
DEBUG - 2016-08-30 23:36:44 --> Router Class Initialized
DEBUG - 2016-08-30 23:36:44 --> Output Class Initialized
DEBUG - 2016-08-30 23:36:44 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:36:44 --> Security Class Initialized
DEBUG - 2016-08-30 23:36:44 --> Input Class Initialized
DEBUG - 2016-08-30 23:36:44 --> XSS Filtering completed
DEBUG - 2016-08-30 23:36:44 --> XSS Filtering completed
DEBUG - 2016-08-30 23:36:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:36:44 --> Language Class Initialized
DEBUG - 2016-08-30 23:36:44 --> Loader Class Initialized
DEBUG - 2016-08-30 23:36:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:36:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:36:44 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:36:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:36:44 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:36:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:36:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:36:45 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:36:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:36:45 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:36:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:36:45 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:36:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:36:45 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:36:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:36:45 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:36:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:36:45 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:36:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:36:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:36:45 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:36:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:36:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:36:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:36:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:36:45 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:36:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:36:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:36:45 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:36:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:36:45 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:36:45 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:36:45 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:36:45 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:36:46 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:36:46 --> Session Class Initialized
DEBUG - 2016-08-30 23:36:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:36:46 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:36:46 --> Session routines successfully run
DEBUG - 2016-08-30 23:36:46 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:36:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:36:46 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:36:46 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:36:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:36:46 --> Controller Class Initialized
DEBUG - 2016-08-30 23:36:46 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:36:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:36:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:36:46 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:36:46 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:36:46 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:36:46 --> Model Class Initialized
DEBUG - 2016-08-30 23:36:46 --> Model Class Initialized
DEBUG - 2016-08-30 23:36:46 --> Model Class Initialized
DEBUG - 2016-08-30 23:36:46 --> Model Class Initialized
DEBUG - 2016-08-30 23:36:46 --> Model Class Initialized
DEBUG - 2016-08-30 23:36:46 --> Model Class Initialized
DEBUG - 2016-08-30 23:36:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:36:46 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:36:47 --> Model Class Initialized
DEBUG - 2016-08-30 23:36:47 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:36:47 --> Model Class Initialized
DEBUG - 2016-08-30 23:36:47 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:36:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 23:36:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 23:36:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 23:36:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 23:36:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:36:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:36:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:36:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:36:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:36:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:36:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:36:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:36:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:36:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:36:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:36:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:36:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:36:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:36:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 23:36:47 --> Final output sent to browser
DEBUG - 2016-08-30 23:36:48 --> Total execution time: 2.9946
DEBUG - 2016-08-30 23:37:16 --> Config Class Initialized
DEBUG - 2016-08-30 23:37:16 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:37:16 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:37:16 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:37:16 --> URI Class Initialized
DEBUG - 2016-08-30 23:37:16 --> Router Class Initialized
DEBUG - 2016-08-30 23:37:16 --> Output Class Initialized
DEBUG - 2016-08-30 23:37:16 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:37:16 --> Security Class Initialized
DEBUG - 2016-08-30 23:37:17 --> Input Class Initialized
DEBUG - 2016-08-30 23:37:17 --> XSS Filtering completed
DEBUG - 2016-08-30 23:37:17 --> XSS Filtering completed
DEBUG - 2016-08-30 23:37:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:37:17 --> Language Class Initialized
DEBUG - 2016-08-30 23:37:17 --> Loader Class Initialized
DEBUG - 2016-08-30 23:37:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:37:17 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:37:17 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:37:17 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:37:17 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:37:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:37:17 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:37:17 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:37:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:37:17 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:37:17 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:37:17 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:37:17 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:37:17 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:37:17 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:37:17 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:37:17 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:37:17 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:37:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:37:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:37:18 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:37:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:37:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:37:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:37:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:37:18 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:37:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:37:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:37:18 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:37:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:37:18 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:37:18 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:37:18 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:37:18 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:37:18 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:37:18 --> Session Class Initialized
DEBUG - 2016-08-30 23:37:18 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:37:18 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:37:18 --> Session routines successfully run
DEBUG - 2016-08-30 23:37:18 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:37:18 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:37:18 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:37:18 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:37:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:37:19 --> Controller Class Initialized
DEBUG - 2016-08-30 23:37:19 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:37:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:37:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:37:19 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:37:19 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:37:19 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:37:19 --> Model Class Initialized
DEBUG - 2016-08-30 23:37:19 --> Model Class Initialized
DEBUG - 2016-08-30 23:37:19 --> Model Class Initialized
DEBUG - 2016-08-30 23:37:19 --> Model Class Initialized
DEBUG - 2016-08-30 23:37:19 --> Model Class Initialized
DEBUG - 2016-08-30 23:37:19 --> Model Class Initialized
DEBUG - 2016-08-30 23:37:19 --> Model Class Initialized
DEBUG - 2016-08-30 23:37:19 --> Model Class Initialized
DEBUG - 2016-08-30 23:37:19 --> Model Class Initialized
DEBUG - 2016-08-30 23:37:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:37:19 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:37:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 23:37:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-30 23:37:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:37:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:37:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:37:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:37:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-30 23:37:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:37:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:37:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:37:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:37:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:37:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:37:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-30 23:37:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:37:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:37:20 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-30 23:37:20 --> Final output sent to browser
DEBUG - 2016-08-30 23:37:20 --> Total execution time: 3.0942
DEBUG - 2016-08-30 23:37:23 --> Config Class Initialized
DEBUG - 2016-08-30 23:37:23 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:37:23 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:37:23 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:37:23 --> URI Class Initialized
DEBUG - 2016-08-30 23:37:23 --> Router Class Initialized
DEBUG - 2016-08-30 23:37:23 --> Output Class Initialized
DEBUG - 2016-08-30 23:37:23 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:37:23 --> Security Class Initialized
DEBUG - 2016-08-30 23:37:23 --> Input Class Initialized
DEBUG - 2016-08-30 23:37:23 --> XSS Filtering completed
DEBUG - 2016-08-30 23:37:23 --> XSS Filtering completed
DEBUG - 2016-08-30 23:37:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:37:23 --> Language Class Initialized
DEBUG - 2016-08-30 23:37:23 --> Loader Class Initialized
DEBUG - 2016-08-30 23:37:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:37:23 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:37:23 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:37:23 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:37:23 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:37:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:37:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:37:24 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:37:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:37:24 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:37:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:37:24 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:37:24 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:37:24 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:37:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:37:24 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:37:24 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:37:24 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:37:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:37:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:37:24 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:37:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:37:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:37:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:37:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:37:24 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:37:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:37:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:37:24 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:37:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:37:25 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:37:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:37:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:37:25 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:37:25 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:37:25 --> Session Class Initialized
DEBUG - 2016-08-30 23:37:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:37:25 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:37:25 --> Session routines successfully run
DEBUG - 2016-08-30 23:37:25 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:37:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:37:25 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:37:25 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:37:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:37:25 --> Controller Class Initialized
DEBUG - 2016-08-30 23:37:25 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:37:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:37:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:37:25 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:37:25 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:37:25 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:37:25 --> Model Class Initialized
DEBUG - 2016-08-30 23:37:25 --> Model Class Initialized
DEBUG - 2016-08-30 23:37:26 --> Model Class Initialized
DEBUG - 2016-08-30 23:37:26 --> Model Class Initialized
DEBUG - 2016-08-30 23:37:26 --> Model Class Initialized
DEBUG - 2016-08-30 23:37:26 --> Model Class Initialized
DEBUG - 2016-08-30 23:37:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:37:26 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:37:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 23:37:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-30 23:37:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:37:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:37:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:37:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:37:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-30 23:37:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:37:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:37:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:37:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:37:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:37:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:37:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-30 23:37:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:37:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:37:26 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6ab6771ae9d42e25effdc2b45133f90d
DEBUG - 2016-08-30 23:37:26 --> Final output sent to browser
DEBUG - 2016-08-30 23:37:27 --> Total execution time: 3.0521
DEBUG - 2016-08-30 23:39:43 --> Config Class Initialized
DEBUG - 2016-08-30 23:39:43 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:39:43 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:39:43 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:39:43 --> URI Class Initialized
DEBUG - 2016-08-30 23:39:43 --> Router Class Initialized
DEBUG - 2016-08-30 23:39:43 --> Output Class Initialized
DEBUG - 2016-08-30 23:39:43 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:39:43 --> Security Class Initialized
DEBUG - 2016-08-30 23:39:43 --> Input Class Initialized
DEBUG - 2016-08-30 23:39:43 --> XSS Filtering completed
DEBUG - 2016-08-30 23:39:43 --> XSS Filtering completed
DEBUG - 2016-08-30 23:39:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:39:43 --> Language Class Initialized
DEBUG - 2016-08-30 23:39:43 --> Loader Class Initialized
DEBUG - 2016-08-30 23:39:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:39:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:39:43 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:39:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:39:43 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:39:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:39:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:39:44 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:39:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:39:44 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:39:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:39:44 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:39:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:39:44 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:39:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:39:44 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:39:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:39:44 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:39:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:39:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:39:44 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:39:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:39:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:39:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:39:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:39:44 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:39:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:39:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:39:44 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:39:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:39:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:39:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:39:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:39:45 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:39:45 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:39:45 --> Session Class Initialized
DEBUG - 2016-08-30 23:39:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:39:45 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:39:45 --> Session routines successfully run
DEBUG - 2016-08-30 23:39:45 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:39:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:39:45 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:39:45 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:39:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:39:45 --> Controller Class Initialized
DEBUG - 2016-08-30 23:39:45 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:39:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:39:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:39:45 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:39:45 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:39:45 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:39:45 --> Model Class Initialized
DEBUG - 2016-08-30 23:39:45 --> Model Class Initialized
DEBUG - 2016-08-30 23:39:45 --> Model Class Initialized
DEBUG - 2016-08-30 23:39:45 --> Model Class Initialized
DEBUG - 2016-08-30 23:39:45 --> Model Class Initialized
DEBUG - 2016-08-30 23:39:45 --> Model Class Initialized
DEBUG - 2016-08-30 23:39:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:39:46 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:39:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 23:39:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-30 23:39:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:39:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:39:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:39:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:39:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-30 23:39:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:39:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:39:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:39:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:39:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:39:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:39:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-30 23:39:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:39:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:39:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6ab6771ae9d42e25effdc2b45133f90d
DEBUG - 2016-08-30 23:39:46 --> Final output sent to browser
DEBUG - 2016-08-30 23:39:46 --> Total execution time: 2.9135
DEBUG - 2016-08-30 23:39:59 --> Config Class Initialized
DEBUG - 2016-08-30 23:39:59 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:39:59 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:39:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:39:59 --> URI Class Initialized
DEBUG - 2016-08-30 23:39:59 --> Router Class Initialized
DEBUG - 2016-08-30 23:39:59 --> Output Class Initialized
DEBUG - 2016-08-30 23:39:59 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:39:59 --> Security Class Initialized
DEBUG - 2016-08-30 23:39:59 --> Input Class Initialized
DEBUG - 2016-08-30 23:39:59 --> XSS Filtering completed
DEBUG - 2016-08-30 23:39:59 --> XSS Filtering completed
DEBUG - 2016-08-30 23:39:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:39:59 --> Language Class Initialized
DEBUG - 2016-08-30 23:39:59 --> Loader Class Initialized
DEBUG - 2016-08-30 23:39:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:39:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:39:59 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:39:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:39:59 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:39:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:40:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:40:00 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:40:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:40:00 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:40:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:40:00 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:40:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:40:00 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:40:00 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:40:00 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:40:00 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:40:00 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:40:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:40:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:40:00 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:40:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:40:00 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:40:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:40:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:40:00 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:40:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:40:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:40:00 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:40:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:40:00 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:40:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:40:01 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:40:01 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:40:01 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:40:01 --> Session Class Initialized
DEBUG - 2016-08-30 23:40:01 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:40:01 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:40:01 --> Session routines successfully run
DEBUG - 2016-08-30 23:40:01 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:40:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:40:01 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:40:01 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:40:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:40:01 --> Controller Class Initialized
DEBUG - 2016-08-30 23:40:01 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:40:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:40:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:40:01 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:40:01 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:40:01 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:40:01 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:01 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:01 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:01 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:01 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:02 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:40:02 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:40:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 23:40:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-30 23:40:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:40:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:40:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:40:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:40:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-30 23:40:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:40:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:40:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:40:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:40:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:40:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:40:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-30 23:40:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:40:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:40:02 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6ab6771ae9d42e25effdc2b45133f90d
DEBUG - 2016-08-30 23:40:02 --> Final output sent to browser
DEBUG - 2016-08-30 23:40:02 --> Total execution time: 2.9872
DEBUG - 2016-08-30 23:40:07 --> Config Class Initialized
DEBUG - 2016-08-30 23:40:07 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:40:07 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:40:07 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:40:07 --> URI Class Initialized
DEBUG - 2016-08-30 23:40:07 --> Router Class Initialized
DEBUG - 2016-08-30 23:40:07 --> Output Class Initialized
DEBUG - 2016-08-30 23:40:07 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:40:07 --> Security Class Initialized
DEBUG - 2016-08-30 23:40:07 --> Input Class Initialized
DEBUG - 2016-08-30 23:40:07 --> XSS Filtering completed
DEBUG - 2016-08-30 23:40:07 --> XSS Filtering completed
DEBUG - 2016-08-30 23:40:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:40:07 --> Language Class Initialized
DEBUG - 2016-08-30 23:40:07 --> Loader Class Initialized
DEBUG - 2016-08-30 23:40:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:40:07 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:40:07 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:40:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:40:07 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:40:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:40:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:40:07 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:40:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:40:08 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:40:08 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:40:08 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:40:08 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:40:08 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:40:08 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:40:08 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:40:08 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:40:08 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:40:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:40:08 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:40:08 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:40:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:40:08 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:40:08 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:40:08 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:40:08 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:40:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:40:08 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:40:08 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:40:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:40:08 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:40:08 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:40:09 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:40:09 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:40:09 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:40:09 --> Session Class Initialized
DEBUG - 2016-08-30 23:40:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:40:09 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:40:09 --> Session routines successfully run
DEBUG - 2016-08-30 23:40:09 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:40:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:40:09 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:40:09 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:40:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:40:09 --> Controller Class Initialized
DEBUG - 2016-08-30 23:40:09 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:40:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:40:09 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:40:09 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:40:09 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:40:09 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:40:09 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:09 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:09 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:09 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:10 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:10 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:40:10 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:40:10 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:10 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:40:10 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:10 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:40:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 23:40:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 23:40:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 23:40:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 23:40:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:40:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:40:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:40:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:40:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:40:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:40:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:40:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:40:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:40:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:40:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:40:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:40:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:40:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:40:11 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 23:40:11 --> Final output sent to browser
DEBUG - 2016-08-30 23:40:11 --> Total execution time: 3.2709
DEBUG - 2016-08-30 23:40:30 --> Config Class Initialized
DEBUG - 2016-08-30 23:40:30 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:40:30 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:40:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:40:30 --> URI Class Initialized
DEBUG - 2016-08-30 23:40:30 --> Router Class Initialized
DEBUG - 2016-08-30 23:40:30 --> Output Class Initialized
DEBUG - 2016-08-30 23:40:30 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:40:30 --> Security Class Initialized
DEBUG - 2016-08-30 23:40:30 --> Input Class Initialized
DEBUG - 2016-08-30 23:40:30 --> XSS Filtering completed
DEBUG - 2016-08-30 23:40:30 --> XSS Filtering completed
DEBUG - 2016-08-30 23:40:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:40:30 --> Language Class Initialized
DEBUG - 2016-08-30 23:40:30 --> Loader Class Initialized
DEBUG - 2016-08-30 23:40:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:40:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:40:30 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:40:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:40:30 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:40:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:40:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:40:31 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:40:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:40:31 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:40:31 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:40:31 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:40:31 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:40:31 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:40:31 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:40:31 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:40:31 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:40:31 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:40:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:40:31 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:40:31 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:40:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:40:31 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:40:31 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:40:31 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:40:31 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:40:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:40:31 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:40:31 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:40:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:40:31 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:40:31 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:40:32 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:40:32 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:40:32 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:40:32 --> Session Class Initialized
DEBUG - 2016-08-30 23:40:32 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:40:32 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:40:32 --> Session routines successfully run
DEBUG - 2016-08-30 23:40:32 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:40:32 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:40:32 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:40:32 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:40:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:40:32 --> Controller Class Initialized
DEBUG - 2016-08-30 23:40:32 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:40:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:40:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:40:32 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:40:32 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:40:32 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:40:32 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:32 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:32 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:32 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:32 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:33 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:40:33 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:40:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 23:40:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-30 23:40:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:40:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:40:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:40:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:40:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-30 23:40:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:40:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:40:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:40:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:40:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:40:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:40:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-30 23:40:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:40:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:40:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6ab6771ae9d42e25effdc2b45133f90d
DEBUG - 2016-08-30 23:40:33 --> Final output sent to browser
DEBUG - 2016-08-30 23:40:34 --> Total execution time: 3.0634
DEBUG - 2016-08-30 23:40:37 --> Config Class Initialized
DEBUG - 2016-08-30 23:40:37 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:40:37 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:40:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:40:37 --> URI Class Initialized
DEBUG - 2016-08-30 23:40:37 --> Router Class Initialized
DEBUG - 2016-08-30 23:40:37 --> Output Class Initialized
DEBUG - 2016-08-30 23:40:37 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:40:38 --> Security Class Initialized
DEBUG - 2016-08-30 23:40:38 --> Input Class Initialized
DEBUG - 2016-08-30 23:40:38 --> XSS Filtering completed
DEBUG - 2016-08-30 23:40:38 --> XSS Filtering completed
DEBUG - 2016-08-30 23:40:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:40:38 --> Language Class Initialized
DEBUG - 2016-08-30 23:40:38 --> Loader Class Initialized
DEBUG - 2016-08-30 23:40:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:40:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:40:38 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:40:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:40:38 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:40:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:40:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:40:38 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:40:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:40:38 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:40:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:40:38 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:40:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:40:38 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:40:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:40:38 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:40:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:40:39 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:40:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:40:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:40:39 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:40:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:40:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:40:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:40:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:40:39 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:40:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:40:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:40:39 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:40:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:40:39 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:40:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:40:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:40:39 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:40:39 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:40:39 --> Session Class Initialized
DEBUG - 2016-08-30 23:40:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:40:39 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:40:39 --> Session routines successfully run
DEBUG - 2016-08-30 23:40:39 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:40:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:40:40 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:40:40 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:40:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:40:40 --> Controller Class Initialized
DEBUG - 2016-08-30 23:40:40 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:40:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:40:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:40:40 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:40:40 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:40:40 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:40:40 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:40 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:40 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:40 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:40 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:40 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:40:40 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:40:40 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:40 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:40:40 --> Model Class Initialized
DEBUG - 2016-08-30 23:40:40 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 23:40:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-30 23:40:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-30 23:40:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-30 23:40:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-30 23:40:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:40:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:40:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:40:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:40:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:40:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:40:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:40:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:40:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:40:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:40:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:40:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-30 23:40:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:40:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:40:41 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-30 23:40:41 --> Final output sent to browser
DEBUG - 2016-08-30 23:40:41 --> Total execution time: 3.3017
DEBUG - 2016-08-30 23:56:53 --> Config Class Initialized
DEBUG - 2016-08-30 23:56:53 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:56:53 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:56:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:56:53 --> URI Class Initialized
DEBUG - 2016-08-30 23:56:53 --> Router Class Initialized
DEBUG - 2016-08-30 23:56:53 --> Output Class Initialized
DEBUG - 2016-08-30 23:56:53 --> Cache file has expired. File deleted
DEBUG - 2016-08-30 23:56:53 --> Security Class Initialized
DEBUG - 2016-08-30 23:56:53 --> Input Class Initialized
DEBUG - 2016-08-30 23:56:53 --> XSS Filtering completed
DEBUG - 2016-08-30 23:56:53 --> XSS Filtering completed
DEBUG - 2016-08-30 23:56:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:56:53 --> Language Class Initialized
DEBUG - 2016-08-30 23:56:53 --> Loader Class Initialized
DEBUG - 2016-08-30 23:56:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:56:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:56:54 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:56:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:56:54 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:56:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:56:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:56:54 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:56:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:56:54 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:56:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:56:54 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:56:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:56:54 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:56:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:56:54 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:56:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:56:54 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:56:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:56:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:56:54 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:56:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:56:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:56:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:56:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:56:55 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:56:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:56:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:56:55 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:56:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:56:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:56:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:56:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:56:55 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:56:55 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:56:55 --> Session Class Initialized
DEBUG - 2016-08-30 23:56:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:56:55 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:56:55 --> Session routines successfully run
DEBUG - 2016-08-30 23:56:55 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:56:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:56:55 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:56:55 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:56:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:56:55 --> Controller Class Initialized
DEBUG - 2016-08-30 23:56:55 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:56:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:56:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:56:55 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:56:56 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:56:56 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:56:56 --> Model Class Initialized
DEBUG - 2016-08-30 23:56:56 --> Model Class Initialized
DEBUG - 2016-08-30 23:56:56 --> Model Class Initialized
DEBUG - 2016-08-30 23:56:56 --> Model Class Initialized
DEBUG - 2016-08-30 23:56:56 --> Model Class Initialized
DEBUG - 2016-08-30 23:56:56 --> Model Class Initialized
DEBUG - 2016-08-30 23:56:56 --> Model Class Initialized
DEBUG - 2016-08-30 23:56:56 --> Model Class Initialized
DEBUG - 2016-08-30 23:56:56 --> Model Class Initialized
DEBUG - 2016-08-30 23:56:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-30 23:56:56 --> Pagination Class Initialized
DEBUG - 2016-08-30 23:56:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-30 23:56:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-30 23:56:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:56:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:56:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:56:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:56:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-30 23:56:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:56:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:56:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-30 23:56:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-30 23:56:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-30 23:56:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-30 23:56:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-30 23:56:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-30 23:56:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-30 23:56:57 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-30 23:56:57 --> Final output sent to browser
DEBUG - 2016-08-30 23:56:57 --> Total execution time: 3.2370
DEBUG - 2016-08-30 23:57:02 --> Config Class Initialized
DEBUG - 2016-08-30 23:57:02 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:57:02 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:57:02 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:57:02 --> URI Class Initialized
DEBUG - 2016-08-30 23:57:02 --> Router Class Initialized
DEBUG - 2016-08-30 23:57:02 --> Output Class Initialized
DEBUG - 2016-08-30 23:57:02 --> Security Class Initialized
DEBUG - 2016-08-30 23:57:02 --> Input Class Initialized
DEBUG - 2016-08-30 23:57:02 --> XSS Filtering completed
DEBUG - 2016-08-30 23:57:02 --> XSS Filtering completed
DEBUG - 2016-08-30 23:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:57:03 --> Language Class Initialized
DEBUG - 2016-08-30 23:57:03 --> Loader Class Initialized
DEBUG - 2016-08-30 23:57:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:57:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:57:03 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:57:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:57:03 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:57:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:57:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:57:03 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:57:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:57:03 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:57:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:57:03 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:57:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:57:03 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:57:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:57:03 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:57:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:57:03 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:57:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:57:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:57:03 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:57:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:57:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:57:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:57:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:57:04 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:57:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:57:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:57:04 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:57:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:57:04 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:57:04 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:57:04 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:57:04 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:57:04 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:57:04 --> Session Class Initialized
DEBUG - 2016-08-30 23:57:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:57:04 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:57:04 --> Session routines successfully run
DEBUG - 2016-08-30 23:57:04 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:57:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:57:04 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:57:04 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:57:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:57:04 --> Controller Class Initialized
DEBUG - 2016-08-30 23:57:04 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:57:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:57:05 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:57:05 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:57:05 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:57:05 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:57:05 --> Model Class Initialized
DEBUG - 2016-08-30 23:57:05 --> Model Class Initialized
DEBUG - 2016-08-30 23:57:05 --> Model Class Initialized
DEBUG - 2016-08-30 23:57:05 --> Model Class Initialized
DEBUG - 2016-08-30 23:57:05 --> Model Class Initialized
DEBUG - 2016-08-30 23:57:05 --> Model Class Initialized
DEBUG - 2016-08-30 23:57:05 --> Model Class Initialized
DEBUG - 2016-08-30 23:57:05 --> Model Class Initialized
DEBUG - 2016-08-30 23:57:05 --> Model Class Initialized
DEBUG - 2016-08-30 23:57:05 --> Model Class Initialized
DEBUG - 2016-08-30 23:57:08 --> Config Class Initialized
DEBUG - 2016-08-30 23:57:08 --> Hooks Class Initialized
DEBUG - 2016-08-30 23:57:08 --> Utf8 Class Initialized
DEBUG - 2016-08-30 23:57:08 --> UTF-8 Support Enabled
DEBUG - 2016-08-30 23:57:08 --> URI Class Initialized
DEBUG - 2016-08-30 23:57:08 --> Router Class Initialized
DEBUG - 2016-08-30 23:57:08 --> Output Class Initialized
DEBUG - 2016-08-30 23:57:09 --> Security Class Initialized
DEBUG - 2016-08-30 23:57:09 --> Input Class Initialized
DEBUG - 2016-08-30 23:57:09 --> XSS Filtering completed
DEBUG - 2016-08-30 23:57:09 --> XSS Filtering completed
DEBUG - 2016-08-30 23:57:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-30 23:57:09 --> Language Class Initialized
DEBUG - 2016-08-30 23:57:09 --> Loader Class Initialized
DEBUG - 2016-08-30 23:57:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-30 23:57:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-30 23:57:09 --> Helper loaded: url_helper
DEBUG - 2016-08-30 23:57:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-30 23:57:09 --> Helper loaded: file_helper
DEBUG - 2016-08-30 23:57:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:57:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-30 23:57:09 --> Helper loaded: conf_helper
DEBUG - 2016-08-30 23:57:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-30 23:57:09 --> Check Exists common_helper.php: No
DEBUG - 2016-08-30 23:57:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-30 23:57:09 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:57:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-30 23:57:09 --> Helper loaded: common_helper
DEBUG - 2016-08-30 23:57:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-30 23:57:09 --> Helper loaded: form_helper
DEBUG - 2016-08-30 23:57:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-30 23:57:10 --> Helper loaded: security_helper
DEBUG - 2016-08-30 23:57:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:57:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-30 23:57:10 --> Helper loaded: lang_helper
DEBUG - 2016-08-30 23:57:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-30 23:57:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-30 23:57:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-30 23:57:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-30 23:57:10 --> Helper loaded: atlant_helper
DEBUG - 2016-08-30 23:57:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:57:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-30 23:57:10 --> Helper loaded: crypto_helper
DEBUG - 2016-08-30 23:57:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-30 23:57:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-30 23:57:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-30 23:57:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-30 23:57:10 --> Helper loaded: sidika_helper
DEBUG - 2016-08-30 23:57:10 --> Database Driver Class Initialized
DEBUG - 2016-08-30 23:57:10 --> Session Class Initialized
DEBUG - 2016-08-30 23:57:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-30 23:57:10 --> Helper loaded: string_helper
DEBUG - 2016-08-30 23:57:10 --> Session routines successfully run
DEBUG - 2016-08-30 23:57:10 --> Native_session Class Initialized
DEBUG - 2016-08-30 23:57:11 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-30 23:57:11 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:57:11 --> Form Validation Class Initialized
DEBUG - 2016-08-30 23:57:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-30 23:57:11 --> Controller Class Initialized
DEBUG - 2016-08-30 23:57:11 --> Carabiner: Library initialized.
DEBUG - 2016-08-30 23:57:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-30 23:57:11 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-30 23:57:11 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:57:11 --> Carabiner: library configured.
DEBUG - 2016-08-30 23:57:11 --> User Agent Class Initialized
DEBUG - 2016-08-30 23:57:11 --> Model Class Initialized
DEBUG - 2016-08-30 23:57:11 --> Model Class Initialized
DEBUG - 2016-08-30 23:57:11 --> Model Class Initialized
DEBUG - 2016-08-30 23:57:11 --> Model Class Initialized
DEBUG - 2016-08-30 23:57:11 --> Model Class Initialized
DEBUG - 2016-08-30 23:57:11 --> Model Class Initialized
DEBUG - 2016-08-30 23:57:11 --> Model Class Initialized
DEBUG - 2016-08-30 23:57:11 --> Model Class Initialized
DEBUG - 2016-08-30 23:57:11 --> Model Class Initialized
DEBUG - 2016-08-30 23:57:11 --> Model Class Initialized
