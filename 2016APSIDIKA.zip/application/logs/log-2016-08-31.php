<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-08-31 00:00:40 --> Config Class Initialized
DEBUG - 2016-08-31 00:00:40 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:00:40 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:00:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:00:40 --> URI Class Initialized
DEBUG - 2016-08-31 00:00:40 --> Router Class Initialized
DEBUG - 2016-08-31 00:00:40 --> Output Class Initialized
DEBUG - 2016-08-31 00:00:40 --> Security Class Initialized
DEBUG - 2016-08-31 00:00:40 --> Input Class Initialized
DEBUG - 2016-08-31 00:00:40 --> XSS Filtering completed
DEBUG - 2016-08-31 00:00:40 --> XSS Filtering completed
DEBUG - 2016-08-31 00:00:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:00:40 --> Language Class Initialized
DEBUG - 2016-08-31 00:00:40 --> Loader Class Initialized
DEBUG - 2016-08-31 00:00:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:00:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:00:40 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:00:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:00:40 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:00:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:00:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:00:40 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:00:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:00:40 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:00:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:00:40 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:00:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:00:40 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:00:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:00:40 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:00:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:00:40 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:00:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:00:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:00:40 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:00:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:00:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:00:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:00:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:00:40 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:00:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:00:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:00:40 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:00:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:00:40 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:00:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:00:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:00:40 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:00:40 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:00:40 --> Session Class Initialized
DEBUG - 2016-08-31 00:00:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:00:40 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:00:40 --> Session routines successfully run
DEBUG - 2016-08-31 00:00:40 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:00:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:00:40 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:00:40 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:00:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:00:40 --> Controller Class Initialized
DEBUG - 2016-08-31 00:00:40 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:00:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:00:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:00:40 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:00:40 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:00:40 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:00:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:00:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:00:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:00:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:00:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:00:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:00:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:00:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:00:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:00:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:41 --> Config Class Initialized
DEBUG - 2016-08-31 00:01:41 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:01:41 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:01:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:01:41 --> URI Class Initialized
DEBUG - 2016-08-31 00:01:41 --> Router Class Initialized
DEBUG - 2016-08-31 00:01:41 --> Output Class Initialized
DEBUG - 2016-08-31 00:01:41 --> Security Class Initialized
DEBUG - 2016-08-31 00:01:41 --> Input Class Initialized
DEBUG - 2016-08-31 00:01:41 --> XSS Filtering completed
DEBUG - 2016-08-31 00:01:41 --> XSS Filtering completed
DEBUG - 2016-08-31 00:01:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:01:41 --> Language Class Initialized
DEBUG - 2016-08-31 00:01:41 --> Loader Class Initialized
DEBUG - 2016-08-31 00:01:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:01:41 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:01:41 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:01:41 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:01:41 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:01:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:01:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:01:41 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:01:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:01:41 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:01:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:01:41 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:01:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:01:41 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:01:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:01:41 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:01:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:01:41 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:01:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:01:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:01:41 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:01:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:01:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:01:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:01:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:01:41 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:01:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:01:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:01:41 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:01:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:01:41 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:01:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:01:41 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:01:41 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:01:41 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:01:41 --> Session Class Initialized
DEBUG - 2016-08-31 00:01:41 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:01:41 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:01:41 --> Session routines successfully run
DEBUG - 2016-08-31 00:01:41 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:01:41 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:01:41 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:01:41 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:01:41 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:01:41 --> Controller Class Initialized
DEBUG - 2016-08-31 00:01:41 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:01:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:01:41 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:01:41 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:01:41 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:01:41 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:01:41 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:41 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:41 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:41 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:41 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:41 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:41 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:41 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:41 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:41 --> Model Class Initialized
ERROR - 2016-08-31 00:01:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 158
ERROR - 2016-08-31 00:01:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 164
ERROR - 2016-08-31 00:01:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 166
ERROR - 2016-08-31 00:01:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 167
ERROR - 2016-08-31 00:01:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 168
ERROR - 2016-08-31 00:01:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 169
ERROR - 2016-08-31 00:01:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 170
ERROR - 2016-08-31 00:01:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 171
ERROR - 2016-08-31 00:01:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-08-31 00:01:47 --> Config Class Initialized
DEBUG - 2016-08-31 00:01:47 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:01:47 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:01:47 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:01:47 --> URI Class Initialized
DEBUG - 2016-08-31 00:01:47 --> Router Class Initialized
DEBUG - 2016-08-31 00:01:47 --> Output Class Initialized
DEBUG - 2016-08-31 00:01:47 --> Security Class Initialized
DEBUG - 2016-08-31 00:01:47 --> Input Class Initialized
DEBUG - 2016-08-31 00:01:47 --> XSS Filtering completed
DEBUG - 2016-08-31 00:01:47 --> XSS Filtering completed
DEBUG - 2016-08-31 00:01:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:01:47 --> Language Class Initialized
DEBUG - 2016-08-31 00:01:47 --> Loader Class Initialized
DEBUG - 2016-08-31 00:01:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:01:47 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:01:47 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:01:47 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:01:47 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:01:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:01:47 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:01:47 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:01:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:01:47 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:01:47 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:01:47 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:01:47 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:01:47 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:01:47 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:01:47 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:01:47 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:01:47 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:01:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:01:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:01:47 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:01:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:01:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:01:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:01:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:01:47 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:01:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:01:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:01:47 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:01:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:01:47 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:01:47 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:01:47 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:01:47 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:01:47 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:01:47 --> Session Class Initialized
DEBUG - 2016-08-31 00:01:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:01:47 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:01:47 --> Session routines successfully run
DEBUG - 2016-08-31 00:01:47 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:01:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:01:47 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:01:47 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:01:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:01:47 --> Controller Class Initialized
DEBUG - 2016-08-31 00:01:47 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:01:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:01:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:01:47 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:01:47 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:01:47 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:01:47 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:47 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:47 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:47 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:47 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:47 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:47 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:47 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:47 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:47 --> Model Class Initialized
ERROR - 2016-08-31 00:01:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 158
ERROR - 2016-08-31 00:01:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 164
ERROR - 2016-08-31 00:01:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 166
ERROR - 2016-08-31 00:01:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 167
ERROR - 2016-08-31 00:01:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 168
ERROR - 2016-08-31 00:01:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 169
ERROR - 2016-08-31 00:01:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 170
ERROR - 2016-08-31 00:01:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 171
ERROR - 2016-08-31 00:01:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-08-31 00:01:50 --> Config Class Initialized
DEBUG - 2016-08-31 00:01:50 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:01:50 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:01:50 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:01:50 --> URI Class Initialized
DEBUG - 2016-08-31 00:01:50 --> Router Class Initialized
DEBUG - 2016-08-31 00:01:50 --> Output Class Initialized
DEBUG - 2016-08-31 00:01:50 --> Security Class Initialized
DEBUG - 2016-08-31 00:01:50 --> Input Class Initialized
DEBUG - 2016-08-31 00:01:50 --> XSS Filtering completed
DEBUG - 2016-08-31 00:01:50 --> XSS Filtering completed
DEBUG - 2016-08-31 00:01:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:01:50 --> Language Class Initialized
DEBUG - 2016-08-31 00:01:50 --> Loader Class Initialized
DEBUG - 2016-08-31 00:01:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:01:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:01:50 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:01:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:01:50 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:01:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:01:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:01:50 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:01:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:01:50 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:01:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:01:50 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:01:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:01:50 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:01:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:01:50 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:01:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:01:50 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:01:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:01:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:01:50 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:01:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:01:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:01:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:01:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:01:50 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:01:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:01:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:01:50 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:01:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:01:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:01:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:01:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:01:50 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:01:50 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:01:50 --> Session Class Initialized
DEBUG - 2016-08-31 00:01:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:01:50 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:01:50 --> Session routines successfully run
DEBUG - 2016-08-31 00:01:50 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:01:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:01:50 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:01:50 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:01:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:01:50 --> Controller Class Initialized
DEBUG - 2016-08-31 00:01:50 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:01:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:01:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:01:50 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:01:50 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:01:50 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:01:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:01:50 --> Model Class Initialized
ERROR - 2016-08-31 00:01:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 158
ERROR - 2016-08-31 00:01:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 164
ERROR - 2016-08-31 00:01:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 166
ERROR - 2016-08-31 00:01:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 167
ERROR - 2016-08-31 00:01:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 168
ERROR - 2016-08-31 00:01:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 169
ERROR - 2016-08-31 00:01:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 170
ERROR - 2016-08-31 00:01:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 171
ERROR - 2016-08-31 00:01:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-08-31 00:02:19 --> Config Class Initialized
DEBUG - 2016-08-31 00:02:19 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:02:19 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:02:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:02:19 --> URI Class Initialized
DEBUG - 2016-08-31 00:02:19 --> Router Class Initialized
DEBUG - 2016-08-31 00:02:19 --> Output Class Initialized
DEBUG - 2016-08-31 00:02:19 --> Security Class Initialized
DEBUG - 2016-08-31 00:02:19 --> Input Class Initialized
DEBUG - 2016-08-31 00:02:19 --> XSS Filtering completed
DEBUG - 2016-08-31 00:02:19 --> XSS Filtering completed
DEBUG - 2016-08-31 00:02:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:02:19 --> Language Class Initialized
DEBUG - 2016-08-31 00:02:19 --> Loader Class Initialized
DEBUG - 2016-08-31 00:02:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:02:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:02:19 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:02:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:02:19 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:02:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:02:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:02:19 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:02:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:02:19 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:02:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:02:19 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:02:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:02:19 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:02:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:02:19 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:02:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:02:19 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:02:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:02:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:02:19 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:02:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:02:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:02:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:02:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:02:19 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:02:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:02:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:02:19 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:02:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:02:19 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:02:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:02:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:02:19 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:02:19 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:02:19 --> Session Class Initialized
DEBUG - 2016-08-31 00:02:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:02:19 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:02:19 --> Session routines successfully run
DEBUG - 2016-08-31 00:02:19 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:02:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:02:19 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:02:19 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:02:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:02:19 --> Controller Class Initialized
DEBUG - 2016-08-31 00:02:19 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:02:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:02:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:02:19 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:02:19 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:02:19 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:02:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:02:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:02:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:02:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:02:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:02:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:02:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:02:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:02:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:02:19 --> Model Class Initialized
ERROR - 2016-08-31 00:02:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 158
ERROR - 2016-08-31 00:02:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 164
ERROR - 2016-08-31 00:02:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 166
ERROR - 2016-08-31 00:02:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 167
ERROR - 2016-08-31 00:02:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 168
ERROR - 2016-08-31 00:02:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 169
ERROR - 2016-08-31 00:02:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 170
ERROR - 2016-08-31 00:02:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php 171
ERROR - 2016-08-31 00:02:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php:79) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-08-31 00:03:42 --> Config Class Initialized
DEBUG - 2016-08-31 00:03:42 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:03:42 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:03:42 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:03:42 --> URI Class Initialized
DEBUG - 2016-08-31 00:03:42 --> Router Class Initialized
DEBUG - 2016-08-31 00:03:42 --> Output Class Initialized
DEBUG - 2016-08-31 00:03:42 --> Security Class Initialized
DEBUG - 2016-08-31 00:03:42 --> Input Class Initialized
DEBUG - 2016-08-31 00:03:42 --> XSS Filtering completed
DEBUG - 2016-08-31 00:03:42 --> XSS Filtering completed
DEBUG - 2016-08-31 00:03:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:03:42 --> Language Class Initialized
DEBUG - 2016-08-31 00:03:42 --> Loader Class Initialized
DEBUG - 2016-08-31 00:03:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:03:42 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:03:42 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:03:42 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:03:42 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:03:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:03:42 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:03:42 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:03:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:03:42 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:03:42 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:03:42 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:03:42 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:03:42 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:03:42 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:03:42 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:03:42 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:03:42 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:03:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:03:42 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:03:42 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:03:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:03:42 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:03:42 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:03:42 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:03:42 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:03:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:03:42 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:03:42 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:03:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:03:42 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:03:42 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:03:42 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:03:42 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:03:42 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:03:42 --> Session Class Initialized
DEBUG - 2016-08-31 00:03:42 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:03:42 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:03:42 --> Session routines successfully run
DEBUG - 2016-08-31 00:03:42 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:03:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:03:42 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:03:42 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:03:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:03:42 --> Controller Class Initialized
DEBUG - 2016-08-31 00:03:42 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:03:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:03:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:03:42 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:03:42 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:03:42 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:03:42 --> Model Class Initialized
DEBUG - 2016-08-31 00:03:42 --> Model Class Initialized
DEBUG - 2016-08-31 00:03:42 --> Model Class Initialized
DEBUG - 2016-08-31 00:03:42 --> Model Class Initialized
DEBUG - 2016-08-31 00:03:42 --> Model Class Initialized
DEBUG - 2016-08-31 00:03:42 --> Model Class Initialized
DEBUG - 2016-08-31 00:03:42 --> Model Class Initialized
DEBUG - 2016-08-31 00:03:42 --> Model Class Initialized
DEBUG - 2016-08-31 00:03:42 --> Model Class Initialized
DEBUG - 2016-08-31 00:03:43 --> Model Class Initialized
ERROR - 2016-08-31 00:03:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:172) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-08-31 00:03:53 --> Config Class Initialized
DEBUG - 2016-08-31 00:03:53 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:03:53 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:03:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:03:53 --> URI Class Initialized
DEBUG - 2016-08-31 00:03:54 --> Router Class Initialized
DEBUG - 2016-08-31 00:03:54 --> Output Class Initialized
DEBUG - 2016-08-31 00:03:54 --> Security Class Initialized
DEBUG - 2016-08-31 00:03:54 --> Input Class Initialized
DEBUG - 2016-08-31 00:03:54 --> XSS Filtering completed
DEBUG - 2016-08-31 00:03:54 --> XSS Filtering completed
DEBUG - 2016-08-31 00:03:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:03:54 --> Language Class Initialized
DEBUG - 2016-08-31 00:03:54 --> Loader Class Initialized
DEBUG - 2016-08-31 00:03:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:03:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:03:54 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:03:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:03:54 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:03:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:03:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:03:54 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:03:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:03:54 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:03:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:03:54 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:03:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:03:54 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:03:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:03:54 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:03:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:03:54 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:03:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:03:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:03:54 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:03:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:03:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:03:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:03:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:03:54 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:03:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:03:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:03:54 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:03:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:03:54 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:03:54 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:03:54 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:03:54 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:03:54 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:03:54 --> Session Class Initialized
DEBUG - 2016-08-31 00:03:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:03:54 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:03:54 --> Session routines successfully run
DEBUG - 2016-08-31 00:03:54 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:03:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:03:54 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:03:54 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:03:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:03:54 --> Controller Class Initialized
DEBUG - 2016-08-31 00:03:54 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:03:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:03:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:03:54 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:03:54 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:03:54 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:03:54 --> Model Class Initialized
DEBUG - 2016-08-31 00:03:54 --> Model Class Initialized
DEBUG - 2016-08-31 00:03:54 --> Model Class Initialized
DEBUG - 2016-08-31 00:03:54 --> Model Class Initialized
DEBUG - 2016-08-31 00:03:54 --> Model Class Initialized
DEBUG - 2016-08-31 00:03:54 --> Model Class Initialized
DEBUG - 2016-08-31 00:03:54 --> Model Class Initialized
DEBUG - 2016-08-31 00:03:54 --> Model Class Initialized
DEBUG - 2016-08-31 00:03:54 --> Model Class Initialized
DEBUG - 2016-08-31 00:03:54 --> Model Class Initialized
ERROR - 2016-08-31 00:03:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:172) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-08-31 00:04:56 --> Config Class Initialized
DEBUG - 2016-08-31 00:04:56 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:04:56 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:04:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:04:56 --> URI Class Initialized
DEBUG - 2016-08-31 00:04:56 --> Router Class Initialized
DEBUG - 2016-08-31 00:04:56 --> Output Class Initialized
DEBUG - 2016-08-31 00:04:56 --> Security Class Initialized
DEBUG - 2016-08-31 00:04:56 --> Input Class Initialized
DEBUG - 2016-08-31 00:04:56 --> XSS Filtering completed
DEBUG - 2016-08-31 00:04:56 --> XSS Filtering completed
DEBUG - 2016-08-31 00:04:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:04:56 --> Language Class Initialized
DEBUG - 2016-08-31 00:04:56 --> Loader Class Initialized
DEBUG - 2016-08-31 00:04:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:04:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:04:56 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:04:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:04:56 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:04:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:04:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:04:56 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:04:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:04:56 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:04:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:04:56 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:04:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:04:56 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:04:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:04:56 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:04:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:04:56 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:04:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:04:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:04:56 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:04:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:04:56 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:04:56 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:04:56 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:04:56 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:04:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:04:56 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:04:57 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:04:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:04:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:04:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:04:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:04:57 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:04:57 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:04:57 --> Session Class Initialized
DEBUG - 2016-08-31 00:04:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:04:57 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:04:57 --> Session routines successfully run
DEBUG - 2016-08-31 00:04:57 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:04:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:04:57 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:04:57 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:04:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:04:57 --> Controller Class Initialized
DEBUG - 2016-08-31 00:04:57 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:04:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:04:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:04:57 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:04:57 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:04:57 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:04:57 --> Model Class Initialized
DEBUG - 2016-08-31 00:04:57 --> Model Class Initialized
DEBUG - 2016-08-31 00:04:57 --> Model Class Initialized
DEBUG - 2016-08-31 00:04:57 --> Model Class Initialized
DEBUG - 2016-08-31 00:04:57 --> Model Class Initialized
DEBUG - 2016-08-31 00:04:57 --> Model Class Initialized
DEBUG - 2016-08-31 00:04:57 --> Model Class Initialized
DEBUG - 2016-08-31 00:04:57 --> Model Class Initialized
DEBUG - 2016-08-31 00:04:57 --> Model Class Initialized
DEBUG - 2016-08-31 00:04:57 --> Model Class Initialized
DEBUG - 2016-08-31 00:05:43 --> Config Class Initialized
DEBUG - 2016-08-31 00:05:43 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:05:43 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:05:43 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:05:43 --> URI Class Initialized
DEBUG - 2016-08-31 00:05:43 --> Router Class Initialized
DEBUG - 2016-08-31 00:05:43 --> Output Class Initialized
DEBUG - 2016-08-31 00:05:43 --> Security Class Initialized
DEBUG - 2016-08-31 00:05:43 --> Input Class Initialized
DEBUG - 2016-08-31 00:05:43 --> XSS Filtering completed
DEBUG - 2016-08-31 00:05:43 --> XSS Filtering completed
DEBUG - 2016-08-31 00:05:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:05:43 --> Language Class Initialized
DEBUG - 2016-08-31 00:05:43 --> Loader Class Initialized
DEBUG - 2016-08-31 00:05:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:05:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:05:43 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:05:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:05:43 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:05:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:05:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:05:43 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:05:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:05:43 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:05:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:05:43 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:05:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:05:43 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:05:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:05:43 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:05:43 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:05:43 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:05:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:05:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:05:43 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:05:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:05:43 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:05:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:05:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:05:43 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:05:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:05:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:05:43 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:05:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:05:43 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:05:43 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:05:43 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:05:43 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:05:43 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:05:44 --> Session Class Initialized
DEBUG - 2016-08-31 00:05:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:05:44 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:05:44 --> Session routines successfully run
DEBUG - 2016-08-31 00:05:44 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:05:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:05:44 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:05:44 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:05:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:05:44 --> Controller Class Initialized
DEBUG - 2016-08-31 00:05:44 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:05:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:05:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:05:44 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:05:44 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:05:44 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:05:44 --> Model Class Initialized
DEBUG - 2016-08-31 00:05:44 --> Model Class Initialized
DEBUG - 2016-08-31 00:05:44 --> Model Class Initialized
DEBUG - 2016-08-31 00:05:44 --> Model Class Initialized
DEBUG - 2016-08-31 00:05:44 --> Model Class Initialized
DEBUG - 2016-08-31 00:05:44 --> Model Class Initialized
DEBUG - 2016-08-31 00:05:44 --> Model Class Initialized
DEBUG - 2016-08-31 00:05:44 --> Model Class Initialized
DEBUG - 2016-08-31 00:05:44 --> Model Class Initialized
DEBUG - 2016-08-31 00:05:44 --> Model Class Initialized
ERROR - 2016-08-31 00:05:44 --> Severity: Notice  --> Undefined variable: 1 E:\www\GitHub\2016APSIDIKA\application\libraries\lws_qr.php 85
DEBUG - 2016-08-31 00:06:08 --> Config Class Initialized
DEBUG - 2016-08-31 00:06:08 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:06:08 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:06:08 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:06:08 --> URI Class Initialized
DEBUG - 2016-08-31 00:06:08 --> Router Class Initialized
DEBUG - 2016-08-31 00:06:08 --> Output Class Initialized
DEBUG - 2016-08-31 00:06:08 --> Security Class Initialized
DEBUG - 2016-08-31 00:06:08 --> Input Class Initialized
DEBUG - 2016-08-31 00:06:08 --> XSS Filtering completed
DEBUG - 2016-08-31 00:06:08 --> XSS Filtering completed
DEBUG - 2016-08-31 00:06:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:06:08 --> Language Class Initialized
DEBUG - 2016-08-31 00:06:08 --> Loader Class Initialized
DEBUG - 2016-08-31 00:06:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:06:08 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:06:08 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:06:08 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:06:08 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:06:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:06:08 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:06:08 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:06:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:06:08 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:06:08 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:06:08 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:06:08 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:06:08 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:06:08 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:06:08 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:06:08 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:06:08 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:06:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:06:08 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:06:08 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:06:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:06:08 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:06:08 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:06:08 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:06:08 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:06:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:06:08 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:06:08 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:06:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:06:08 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:06:08 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:06:08 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:06:08 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:06:08 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:06:08 --> Session Class Initialized
DEBUG - 2016-08-31 00:06:08 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:06:08 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:06:08 --> Session routines successfully run
DEBUG - 2016-08-31 00:06:08 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:06:08 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:06:08 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:06:08 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:06:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:06:08 --> Controller Class Initialized
DEBUG - 2016-08-31 00:06:08 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:06:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:06:08 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:06:08 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:06:08 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:06:08 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:06:08 --> Model Class Initialized
DEBUG - 2016-08-31 00:06:08 --> Model Class Initialized
DEBUG - 2016-08-31 00:06:08 --> Model Class Initialized
DEBUG - 2016-08-31 00:06:08 --> Model Class Initialized
DEBUG - 2016-08-31 00:06:08 --> Model Class Initialized
DEBUG - 2016-08-31 00:06:08 --> Model Class Initialized
DEBUG - 2016-08-31 00:06:08 --> Model Class Initialized
DEBUG - 2016-08-31 00:06:08 --> Model Class Initialized
DEBUG - 2016-08-31 00:06:08 --> Model Class Initialized
DEBUG - 2016-08-31 00:06:08 --> Model Class Initialized
DEBUG - 2016-08-31 00:10:50 --> Config Class Initialized
DEBUG - 2016-08-31 00:10:50 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:10:50 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:10:50 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:10:50 --> URI Class Initialized
DEBUG - 2016-08-31 00:10:50 --> Router Class Initialized
DEBUG - 2016-08-31 00:10:50 --> Output Class Initialized
DEBUG - 2016-08-31 00:10:50 --> Security Class Initialized
DEBUG - 2016-08-31 00:10:50 --> Input Class Initialized
DEBUG - 2016-08-31 00:10:50 --> XSS Filtering completed
DEBUG - 2016-08-31 00:10:50 --> XSS Filtering completed
DEBUG - 2016-08-31 00:10:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:10:50 --> Language Class Initialized
DEBUG - 2016-08-31 00:10:50 --> Loader Class Initialized
DEBUG - 2016-08-31 00:10:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:10:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:10:50 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:10:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:10:50 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:10:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:10:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:10:50 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:10:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:10:50 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:10:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:10:50 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:10:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:10:50 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:10:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:10:50 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:10:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:10:50 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:10:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:10:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:10:50 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:10:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:10:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:10:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:10:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:10:50 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:10:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:10:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:10:50 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:10:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:10:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:10:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:10:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:10:50 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:10:50 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:10:50 --> Session Class Initialized
DEBUG - 2016-08-31 00:10:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:10:50 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:10:50 --> Session routines successfully run
DEBUG - 2016-08-31 00:10:50 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:10:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:10:50 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:10:50 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:10:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:10:50 --> Controller Class Initialized
DEBUG - 2016-08-31 00:10:50 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:10:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:10:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:10:50 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:10:50 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:10:50 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:10:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:10:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:10:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:10:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:10:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:10:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:10:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:10:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:10:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:10:50 --> Model Class Initialized
ERROR - 2016-08-31 00:10:50 --> Severity: Warning  --> ZipArchive::deleteName(): Invalid or uninitialized Zip object E:\www\lwscodeigniterwrapper\libraries\lwphpword\PhpWord\Shared\ZipArchive.php 115
ERROR - 2016-08-31 00:10:50 --> Severity: Warning  --> ZipArchive::addFile(): Invalid or uninitialized Zip object E:\www\lwscodeigniterwrapper\libraries\lwphpword\PhpWord\Shared\ZipArchive.php 115
ERROR - 2016-08-31 00:10:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:177) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-08-31 00:13:55 --> Config Class Initialized
DEBUG - 2016-08-31 00:13:55 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:13:55 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:13:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:13:55 --> URI Class Initialized
DEBUG - 2016-08-31 00:13:55 --> Router Class Initialized
DEBUG - 2016-08-31 00:13:55 --> Output Class Initialized
DEBUG - 2016-08-31 00:13:55 --> Security Class Initialized
DEBUG - 2016-08-31 00:13:55 --> Input Class Initialized
DEBUG - 2016-08-31 00:13:55 --> XSS Filtering completed
DEBUG - 2016-08-31 00:13:55 --> XSS Filtering completed
DEBUG - 2016-08-31 00:13:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:13:55 --> Language Class Initialized
DEBUG - 2016-08-31 00:13:55 --> Loader Class Initialized
DEBUG - 2016-08-31 00:13:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:13:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:13:55 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:13:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:13:55 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:13:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:13:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:13:55 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:13:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:13:55 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:13:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:13:55 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:13:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:13:55 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:13:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:13:55 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:13:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:13:55 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:13:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:13:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:13:55 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:13:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:13:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:13:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:13:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:13:55 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:13:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:13:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:13:55 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:13:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:13:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:13:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:13:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:13:55 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:13:55 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:13:55 --> Session Class Initialized
DEBUG - 2016-08-31 00:13:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:13:55 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:13:55 --> Session routines successfully run
DEBUG - 2016-08-31 00:13:55 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:13:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:13:55 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:13:55 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:13:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:13:55 --> Controller Class Initialized
DEBUG - 2016-08-31 00:13:55 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:13:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:13:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:13:55 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:13:55 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:13:55 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:13:55 --> Model Class Initialized
DEBUG - 2016-08-31 00:13:55 --> Model Class Initialized
DEBUG - 2016-08-31 00:13:55 --> Model Class Initialized
DEBUG - 2016-08-31 00:13:55 --> Model Class Initialized
DEBUG - 2016-08-31 00:13:55 --> Model Class Initialized
DEBUG - 2016-08-31 00:13:55 --> Model Class Initialized
DEBUG - 2016-08-31 00:13:55 --> Model Class Initialized
DEBUG - 2016-08-31 00:13:55 --> Model Class Initialized
DEBUG - 2016-08-31 00:13:55 --> Model Class Initialized
DEBUG - 2016-08-31 00:13:55 --> Model Class Initialized
DEBUG - 2016-08-31 00:14:19 --> Config Class Initialized
DEBUG - 2016-08-31 00:14:19 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:14:19 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:14:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:14:19 --> URI Class Initialized
DEBUG - 2016-08-31 00:14:19 --> Router Class Initialized
DEBUG - 2016-08-31 00:14:19 --> Output Class Initialized
DEBUG - 2016-08-31 00:14:19 --> Security Class Initialized
DEBUG - 2016-08-31 00:14:19 --> Input Class Initialized
DEBUG - 2016-08-31 00:14:19 --> XSS Filtering completed
DEBUG - 2016-08-31 00:14:19 --> XSS Filtering completed
DEBUG - 2016-08-31 00:14:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:14:19 --> Language Class Initialized
DEBUG - 2016-08-31 00:14:19 --> Loader Class Initialized
DEBUG - 2016-08-31 00:14:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:14:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:14:19 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:14:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:14:19 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:14:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:14:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:14:19 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:14:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:14:19 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:14:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:14:19 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:14:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:14:19 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:14:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:14:19 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:14:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:14:19 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:14:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:14:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:14:19 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:14:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:14:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:14:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:14:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:14:19 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:14:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:14:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:14:19 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:14:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:14:19 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:14:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:14:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:14:19 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:14:19 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:14:19 --> Session Class Initialized
DEBUG - 2016-08-31 00:14:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:14:19 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:14:19 --> Session routines successfully run
DEBUG - 2016-08-31 00:14:19 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:14:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:14:19 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:14:19 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:14:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:14:19 --> Controller Class Initialized
DEBUG - 2016-08-31 00:14:19 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:14:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:14:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:14:19 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:14:19 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:14:19 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:14:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:14:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:14:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:14:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:14:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:14:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:14:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:14:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:14:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:14:20 --> Model Class Initialized
ERROR - 2016-08-31 00:14:20 --> Severity: Warning  --> ZipArchive::deleteName(): Invalid or uninitialized Zip object E:\www\lwscodeigniterwrapper\libraries\lwphpword\PhpWord\Shared\ZipArchive.php 115
ERROR - 2016-08-31 00:14:20 --> Severity: Warning  --> ZipArchive::addFile(): Invalid or uninitialized Zip object E:\www\lwscodeigniterwrapper\libraries\lwphpword\PhpWord\Shared\ZipArchive.php 115
ERROR - 2016-08-31 00:14:20 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:177) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-08-31 00:15:40 --> Config Class Initialized
DEBUG - 2016-08-31 00:15:40 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:15:40 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:15:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:15:40 --> URI Class Initialized
DEBUG - 2016-08-31 00:15:40 --> Router Class Initialized
DEBUG - 2016-08-31 00:15:40 --> Output Class Initialized
DEBUG - 2016-08-31 00:15:40 --> Security Class Initialized
DEBUG - 2016-08-31 00:15:40 --> Input Class Initialized
DEBUG - 2016-08-31 00:15:40 --> XSS Filtering completed
DEBUG - 2016-08-31 00:15:40 --> XSS Filtering completed
DEBUG - 2016-08-31 00:15:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:15:40 --> Language Class Initialized
DEBUG - 2016-08-31 00:15:40 --> Loader Class Initialized
DEBUG - 2016-08-31 00:15:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:15:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:15:40 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:15:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:15:40 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:15:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:15:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:15:40 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:15:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:15:40 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:15:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:15:40 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:15:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:15:40 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:15:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:15:40 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:15:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:15:40 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:15:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:15:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:15:40 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:15:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:15:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:15:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:15:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:15:40 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:15:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:15:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:15:40 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:15:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:15:40 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:15:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:15:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:15:40 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:15:40 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:15:40 --> Session Class Initialized
DEBUG - 2016-08-31 00:15:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:15:40 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:15:40 --> Session routines successfully run
DEBUG - 2016-08-31 00:15:40 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:15:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:15:40 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:15:40 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:15:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:15:40 --> Controller Class Initialized
DEBUG - 2016-08-31 00:15:40 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:15:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:15:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:15:40 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:15:40 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:15:40 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:15:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:15:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:15:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:15:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:15:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:15:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:15:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:15:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:15:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:15:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:16:44 --> Config Class Initialized
DEBUG - 2016-08-31 00:16:44 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:16:44 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:16:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:16:44 --> URI Class Initialized
DEBUG - 2016-08-31 00:16:44 --> Router Class Initialized
DEBUG - 2016-08-31 00:16:44 --> Output Class Initialized
DEBUG - 2016-08-31 00:16:44 --> Security Class Initialized
DEBUG - 2016-08-31 00:16:44 --> Input Class Initialized
DEBUG - 2016-08-31 00:16:44 --> XSS Filtering completed
DEBUG - 2016-08-31 00:16:44 --> XSS Filtering completed
DEBUG - 2016-08-31 00:16:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:16:44 --> Language Class Initialized
DEBUG - 2016-08-31 00:16:44 --> Loader Class Initialized
DEBUG - 2016-08-31 00:16:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:16:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:16:44 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:16:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:16:44 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:16:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:16:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:16:44 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:16:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:16:44 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:16:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:16:44 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:16:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:16:44 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:16:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:16:44 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:16:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:16:44 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:16:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:16:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:16:44 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:16:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:16:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:16:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:16:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:16:44 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:16:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:16:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:16:44 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:16:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:16:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:16:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:16:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:16:44 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:16:44 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:16:44 --> Session Class Initialized
DEBUG - 2016-08-31 00:16:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:16:44 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:16:44 --> Session routines successfully run
DEBUG - 2016-08-31 00:16:44 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:16:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:16:44 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:16:44 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:16:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:16:44 --> Controller Class Initialized
DEBUG - 2016-08-31 00:16:44 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:16:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:16:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:16:44 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:16:44 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:16:44 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:16:44 --> Model Class Initialized
DEBUG - 2016-08-31 00:16:44 --> Model Class Initialized
DEBUG - 2016-08-31 00:16:44 --> Model Class Initialized
DEBUG - 2016-08-31 00:16:44 --> Model Class Initialized
DEBUG - 2016-08-31 00:16:44 --> Model Class Initialized
DEBUG - 2016-08-31 00:16:44 --> Model Class Initialized
DEBUG - 2016-08-31 00:16:44 --> Model Class Initialized
DEBUG - 2016-08-31 00:16:44 --> Model Class Initialized
DEBUG - 2016-08-31 00:16:44 --> Model Class Initialized
DEBUG - 2016-08-31 00:16:44 --> Model Class Initialized
ERROR - 2016-08-31 00:16:44 --> Severity: Warning  --> ZipArchive::deleteName(): Invalid or uninitialized Zip object E:\www\lwscodeigniterwrapper\libraries\lwphpword\PhpWord\Shared\ZipArchive.php 115
DEBUG - 2016-08-31 00:20:19 --> Config Class Initialized
DEBUG - 2016-08-31 00:20:19 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:20:19 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:20:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:20:19 --> URI Class Initialized
DEBUG - 2016-08-31 00:20:19 --> Router Class Initialized
DEBUG - 2016-08-31 00:20:19 --> Output Class Initialized
DEBUG - 2016-08-31 00:20:19 --> Security Class Initialized
DEBUG - 2016-08-31 00:20:19 --> Input Class Initialized
DEBUG - 2016-08-31 00:20:19 --> XSS Filtering completed
DEBUG - 2016-08-31 00:20:19 --> XSS Filtering completed
DEBUG - 2016-08-31 00:20:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:20:19 --> Language Class Initialized
DEBUG - 2016-08-31 00:20:19 --> Loader Class Initialized
DEBUG - 2016-08-31 00:20:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:20:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:20:19 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:20:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:20:19 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:20:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:20:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:20:19 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:20:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:20:20 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:20:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:20:20 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:20:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:20:20 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:20:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:20:20 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:20:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:20:20 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:20:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:20:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:20:20 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:20:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:20:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:20:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:20:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:20:20 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:20:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:20:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:20:20 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:20:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:20:20 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:20:20 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:20:20 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:20:20 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:20:20 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:20:20 --> Session Class Initialized
DEBUG - 2016-08-31 00:20:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:20:20 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:20:20 --> Session routines successfully run
DEBUG - 2016-08-31 00:20:20 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:20:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:20:20 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:20:20 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:20:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:20:20 --> Controller Class Initialized
DEBUG - 2016-08-31 00:20:20 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:20:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:20:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:20:20 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:20:20 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:20:20 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:20:20 --> Model Class Initialized
DEBUG - 2016-08-31 00:20:20 --> Model Class Initialized
DEBUG - 2016-08-31 00:20:20 --> Model Class Initialized
DEBUG - 2016-08-31 00:20:20 --> Model Class Initialized
DEBUG - 2016-08-31 00:20:20 --> Model Class Initialized
DEBUG - 2016-08-31 00:20:20 --> Model Class Initialized
DEBUG - 2016-08-31 00:20:20 --> Model Class Initialized
DEBUG - 2016-08-31 00:20:20 --> Model Class Initialized
DEBUG - 2016-08-31 00:20:20 --> Model Class Initialized
DEBUG - 2016-08-31 00:20:20 --> Model Class Initialized
DEBUG - 2016-08-31 00:20:22 --> Config Class Initialized
DEBUG - 2016-08-31 00:20:22 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:20:22 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:20:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:20:22 --> URI Class Initialized
DEBUG - 2016-08-31 00:20:22 --> Router Class Initialized
DEBUG - 2016-08-31 00:20:22 --> Output Class Initialized
DEBUG - 2016-08-31 00:20:22 --> Security Class Initialized
DEBUG - 2016-08-31 00:20:22 --> Input Class Initialized
DEBUG - 2016-08-31 00:20:22 --> XSS Filtering completed
DEBUG - 2016-08-31 00:20:22 --> XSS Filtering completed
DEBUG - 2016-08-31 00:20:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:20:22 --> Language Class Initialized
DEBUG - 2016-08-31 00:20:22 --> Loader Class Initialized
DEBUG - 2016-08-31 00:20:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:20:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:20:22 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:20:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:20:22 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:20:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:20:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:20:22 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:20:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:20:22 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:20:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:20:22 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:20:22 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:20:22 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:20:22 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:20:22 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:20:22 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:20:22 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:20:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:20:22 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:20:22 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:20:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:20:22 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:20:22 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:20:22 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:20:22 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:20:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:20:22 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:20:22 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:20:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:20:22 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:20:22 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:20:22 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:20:22 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:20:22 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:20:22 --> Session Class Initialized
DEBUG - 2016-08-31 00:20:22 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:20:22 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:20:22 --> Session routines successfully run
DEBUG - 2016-08-31 00:20:22 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:20:22 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:20:22 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:20:22 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:20:22 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:20:22 --> Controller Class Initialized
DEBUG - 2016-08-31 00:20:22 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:20:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:20:22 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:20:22 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:20:22 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:20:22 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:20:22 --> Model Class Initialized
DEBUG - 2016-08-31 00:20:22 --> Model Class Initialized
DEBUG - 2016-08-31 00:20:22 --> Model Class Initialized
DEBUG - 2016-08-31 00:20:22 --> Model Class Initialized
DEBUG - 2016-08-31 00:20:22 --> Model Class Initialized
DEBUG - 2016-08-31 00:20:22 --> Model Class Initialized
DEBUG - 2016-08-31 00:20:22 --> Model Class Initialized
DEBUG - 2016-08-31 00:20:22 --> Model Class Initialized
DEBUG - 2016-08-31 00:20:22 --> Model Class Initialized
DEBUG - 2016-08-31 00:20:22 --> Model Class Initialized
DEBUG - 2016-08-31 00:23:30 --> Config Class Initialized
DEBUG - 2016-08-31 00:23:30 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:23:30 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:23:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:23:30 --> URI Class Initialized
DEBUG - 2016-08-31 00:23:30 --> Router Class Initialized
DEBUG - 2016-08-31 00:23:30 --> Output Class Initialized
DEBUG - 2016-08-31 00:23:30 --> Security Class Initialized
DEBUG - 2016-08-31 00:23:30 --> Input Class Initialized
DEBUG - 2016-08-31 00:23:30 --> XSS Filtering completed
DEBUG - 2016-08-31 00:23:30 --> XSS Filtering completed
DEBUG - 2016-08-31 00:23:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:23:30 --> Language Class Initialized
DEBUG - 2016-08-31 00:23:30 --> Loader Class Initialized
DEBUG - 2016-08-31 00:23:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:23:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:23:30 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:23:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:23:30 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:23:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:23:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:23:30 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:23:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:23:30 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:23:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:23:30 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:23:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:23:30 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:23:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:23:30 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:23:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:23:30 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:23:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:23:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:23:30 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:23:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:23:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:23:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:23:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:23:30 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:23:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:23:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:23:30 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:23:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:23:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:23:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:23:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:23:30 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:23:30 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:23:30 --> Session Class Initialized
DEBUG - 2016-08-31 00:23:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:23:30 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:23:30 --> Session routines successfully run
DEBUG - 2016-08-31 00:23:30 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:23:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:23:30 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:23:30 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:23:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:23:30 --> Controller Class Initialized
DEBUG - 2016-08-31 00:23:30 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:23:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:23:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:23:30 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:23:30 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:23:30 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:23:30 --> Model Class Initialized
DEBUG - 2016-08-31 00:23:31 --> Model Class Initialized
DEBUG - 2016-08-31 00:23:31 --> Model Class Initialized
DEBUG - 2016-08-31 00:23:31 --> Model Class Initialized
DEBUG - 2016-08-31 00:23:31 --> Model Class Initialized
DEBUG - 2016-08-31 00:23:31 --> Model Class Initialized
DEBUG - 2016-08-31 00:23:31 --> Model Class Initialized
DEBUG - 2016-08-31 00:23:31 --> Model Class Initialized
DEBUG - 2016-08-31 00:23:31 --> Model Class Initialized
DEBUG - 2016-08-31 00:23:31 --> Model Class Initialized
ERROR - 2016-08-31 00:23:31 --> Severity: Warning  --> ZipArchive::deleteName(): Invalid or uninitialized Zip object E:\www\lwscodeigniterwrapper\libraries\lwphpword\PhpWord\Shared\ZipArchive.php 115
ERROR - 2016-08-31 00:23:31 --> Severity: Warning  --> ZipArchive::addFile(): Invalid or uninitialized Zip object E:\www\lwscodeigniterwrapper\libraries\lwphpword\PhpWord\Shared\ZipArchive.php 115
ERROR - 2016-08-31 00:23:31 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:177) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-08-31 00:23:37 --> Config Class Initialized
DEBUG - 2016-08-31 00:23:37 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:23:37 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:23:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:23:37 --> URI Class Initialized
DEBUG - 2016-08-31 00:23:37 --> Router Class Initialized
DEBUG - 2016-08-31 00:23:37 --> Output Class Initialized
DEBUG - 2016-08-31 00:23:37 --> Security Class Initialized
DEBUG - 2016-08-31 00:23:37 --> Input Class Initialized
DEBUG - 2016-08-31 00:23:37 --> XSS Filtering completed
DEBUG - 2016-08-31 00:23:37 --> XSS Filtering completed
DEBUG - 2016-08-31 00:23:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:23:37 --> Language Class Initialized
DEBUG - 2016-08-31 00:23:37 --> Loader Class Initialized
DEBUG - 2016-08-31 00:23:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:23:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:23:37 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:23:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:23:37 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:23:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:23:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:23:37 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:23:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:23:37 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:23:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:23:37 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:23:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:23:37 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:23:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:23:37 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:23:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:23:37 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:23:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:23:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:23:37 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:23:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:23:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:23:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:23:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:23:37 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:23:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:23:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:23:37 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:23:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:23:37 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:23:37 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:23:37 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:23:37 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:23:37 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:23:37 --> Session Class Initialized
DEBUG - 2016-08-31 00:23:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:23:37 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:23:37 --> Session routines successfully run
DEBUG - 2016-08-31 00:23:37 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:23:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:23:37 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:23:37 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:23:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:23:37 --> Controller Class Initialized
DEBUG - 2016-08-31 00:23:37 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:23:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:23:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:23:37 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:23:37 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:23:37 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:23:37 --> Model Class Initialized
DEBUG - 2016-08-31 00:23:37 --> Model Class Initialized
DEBUG - 2016-08-31 00:23:37 --> Model Class Initialized
DEBUG - 2016-08-31 00:23:37 --> Model Class Initialized
DEBUG - 2016-08-31 00:23:37 --> Model Class Initialized
DEBUG - 2016-08-31 00:23:37 --> Model Class Initialized
DEBUG - 2016-08-31 00:23:37 --> Model Class Initialized
DEBUG - 2016-08-31 00:23:37 --> Model Class Initialized
DEBUG - 2016-08-31 00:23:37 --> Model Class Initialized
DEBUG - 2016-08-31 00:23:37 --> Model Class Initialized
ERROR - 2016-08-31 00:23:37 --> Severity: Warning  --> ZipArchive::deleteName(): Invalid or uninitialized Zip object E:\www\lwscodeigniterwrapper\libraries\lwphpword\PhpWord\Shared\ZipArchive.php 115
ERROR - 2016-08-31 00:23:37 --> Severity: Warning  --> ZipArchive::addFile(): Invalid or uninitialized Zip object E:\www\lwscodeigniterwrapper\libraries\lwphpword\PhpWord\Shared\ZipArchive.php 115
ERROR - 2016-08-31 00:23:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:177) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-08-31 00:30:18 --> Config Class Initialized
DEBUG - 2016-08-31 00:30:18 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:30:18 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:30:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:30:18 --> URI Class Initialized
DEBUG - 2016-08-31 00:30:18 --> Router Class Initialized
DEBUG - 2016-08-31 00:30:18 --> Output Class Initialized
DEBUG - 2016-08-31 00:30:18 --> Security Class Initialized
DEBUG - 2016-08-31 00:30:18 --> Input Class Initialized
DEBUG - 2016-08-31 00:30:18 --> XSS Filtering completed
DEBUG - 2016-08-31 00:30:18 --> XSS Filtering completed
DEBUG - 2016-08-31 00:30:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:30:18 --> Language Class Initialized
DEBUG - 2016-08-31 00:30:18 --> Loader Class Initialized
DEBUG - 2016-08-31 00:30:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:30:18 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:30:18 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:30:18 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:30:18 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:30:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:30:18 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:30:18 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:30:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:30:18 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:30:18 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:30:18 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:30:18 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:30:18 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:30:18 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:30:18 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:30:18 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:30:18 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:30:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:30:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:30:18 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:30:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:30:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:30:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:30:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:30:18 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:30:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:30:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:30:18 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:30:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:30:18 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:30:18 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:30:18 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:30:18 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:30:18 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:30:18 --> Session Class Initialized
DEBUG - 2016-08-31 00:30:18 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:30:18 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:30:18 --> Session routines successfully run
DEBUG - 2016-08-31 00:30:18 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:30:18 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:30:18 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:30:18 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:30:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:30:18 --> Controller Class Initialized
DEBUG - 2016-08-31 00:30:18 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:30:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:30:18 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:30:18 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:30:18 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:30:18 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:30:18 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:18 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:18 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:18 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:18 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:18 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:18 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:18 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:18 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:18 --> Model Class Initialized
ERROR - 2016-08-31 00:30:19 --> Severity: Warning  --> ZipArchive::deleteName(): Invalid or uninitialized Zip object E:\www\lwscodeigniterwrapper\libraries\lwphpword\PhpWord\Shared\ZipArchive.php 115
ERROR - 2016-08-31 00:30:19 --> Severity: Warning  --> ZipArchive::locateName(): Invalid or uninitialized Zip object E:\www\lwscodeigniterwrapper\libraries\lwphpword\PhpWord\Shared\ZipArchive.php 115
DEBUG - 2016-08-31 00:30:24 --> Config Class Initialized
DEBUG - 2016-08-31 00:30:24 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:30:24 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:30:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:30:24 --> URI Class Initialized
DEBUG - 2016-08-31 00:30:24 --> Router Class Initialized
DEBUG - 2016-08-31 00:30:24 --> Output Class Initialized
DEBUG - 2016-08-31 00:30:24 --> Security Class Initialized
DEBUG - 2016-08-31 00:30:24 --> Input Class Initialized
DEBUG - 2016-08-31 00:30:24 --> XSS Filtering completed
DEBUG - 2016-08-31 00:30:25 --> XSS Filtering completed
DEBUG - 2016-08-31 00:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:30:25 --> Language Class Initialized
DEBUG - 2016-08-31 00:30:25 --> Loader Class Initialized
DEBUG - 2016-08-31 00:30:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:30:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:30:25 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:30:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:30:25 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:30:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:30:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:30:25 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:30:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:30:25 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:30:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:30:25 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:30:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:30:25 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:30:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:30:25 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:30:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:30:25 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:30:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:30:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:30:25 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:30:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:30:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:30:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:30:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:30:25 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:30:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:30:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:30:25 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:30:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:30:25 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:30:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:30:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:30:25 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:30:25 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:30:25 --> Session Class Initialized
DEBUG - 2016-08-31 00:30:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:30:25 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:30:25 --> Session routines successfully run
DEBUG - 2016-08-31 00:30:25 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:30:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:30:25 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:30:25 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:30:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:30:25 --> Controller Class Initialized
DEBUG - 2016-08-31 00:30:25 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:30:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:30:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:30:25 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:30:25 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:30:25 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:30:25 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:25 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:25 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:25 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:25 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:25 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:25 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:25 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:25 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:25 --> Model Class Initialized
ERROR - 2016-08-31 00:30:25 --> Severity: Warning  --> ZipArchive::deleteName(): Invalid or uninitialized Zip object E:\www\lwscodeigniterwrapper\libraries\lwphpword\PhpWord\Shared\ZipArchive.php 115
ERROR - 2016-08-31 00:30:25 --> Severity: Warning  --> ZipArchive::addFile(): Invalid or uninitialized Zip object E:\www\lwscodeigniterwrapper\libraries\lwphpword\PhpWord\Shared\ZipArchive.php 115
ERROR - 2016-08-31 00:30:25 --> Severity: Warning  --> ZipArchive::locateName(): Invalid or uninitialized Zip object E:\www\lwscodeigniterwrapper\libraries\lwphpword\PhpWord\Shared\ZipArchive.php 115
DEBUG - 2016-08-31 00:30:31 --> Config Class Initialized
DEBUG - 2016-08-31 00:30:31 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:30:31 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:30:31 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:30:31 --> URI Class Initialized
DEBUG - 2016-08-31 00:30:31 --> Router Class Initialized
DEBUG - 2016-08-31 00:30:31 --> Output Class Initialized
DEBUG - 2016-08-31 00:30:31 --> Security Class Initialized
DEBUG - 2016-08-31 00:30:31 --> Input Class Initialized
DEBUG - 2016-08-31 00:30:31 --> XSS Filtering completed
DEBUG - 2016-08-31 00:30:32 --> XSS Filtering completed
DEBUG - 2016-08-31 00:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:30:32 --> Language Class Initialized
DEBUG - 2016-08-31 00:30:32 --> Loader Class Initialized
DEBUG - 2016-08-31 00:30:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:30:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:30:32 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:30:32 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:30:32 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:30:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:30:32 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:30:32 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:30:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:30:32 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:30:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:30:32 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:30:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:30:32 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:30:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:30:32 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:30:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:30:32 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:30:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:30:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:30:32 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:30:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:30:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:30:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:30:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:30:32 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:30:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:30:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:30:32 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:30:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:30:32 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:30:32 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:30:32 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:30:32 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:30:32 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:30:32 --> Session Class Initialized
DEBUG - 2016-08-31 00:30:32 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:30:32 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:30:32 --> Session routines successfully run
DEBUG - 2016-08-31 00:30:32 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:30:32 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:30:32 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:30:32 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:30:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:30:32 --> Controller Class Initialized
DEBUG - 2016-08-31 00:30:32 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:30:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:30:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:30:32 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:30:32 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:30:32 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:30:32 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:32 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:32 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:32 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:32 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:32 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:32 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:32 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:32 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:32 --> Model Class Initialized
ERROR - 2016-08-31 00:30:32 --> Severity: Warning  --> ZipArchive::deleteName(): Invalid or uninitialized Zip object E:\www\lwscodeigniterwrapper\libraries\lwphpword\PhpWord\Shared\ZipArchive.php 115
ERROR - 2016-08-31 00:30:32 --> Severity: Warning  --> ZipArchive::addFile(): Invalid or uninitialized Zip object E:\www\lwscodeigniterwrapper\libraries\lwphpword\PhpWord\Shared\ZipArchive.php 115
ERROR - 2016-08-31 00:30:32 --> Severity: Warning  --> ZipArchive::locateName(): Invalid or uninitialized Zip object E:\www\lwscodeigniterwrapper\libraries\lwphpword\PhpWord\Shared\ZipArchive.php 115
DEBUG - 2016-08-31 00:30:49 --> Config Class Initialized
DEBUG - 2016-08-31 00:30:49 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:30:49 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:30:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:30:49 --> URI Class Initialized
DEBUG - 2016-08-31 00:30:49 --> Router Class Initialized
DEBUG - 2016-08-31 00:30:49 --> Output Class Initialized
DEBUG - 2016-08-31 00:30:49 --> Security Class Initialized
DEBUG - 2016-08-31 00:30:49 --> Input Class Initialized
DEBUG - 2016-08-31 00:30:49 --> XSS Filtering completed
DEBUG - 2016-08-31 00:30:49 --> XSS Filtering completed
DEBUG - 2016-08-31 00:30:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:30:49 --> Language Class Initialized
DEBUG - 2016-08-31 00:30:49 --> Loader Class Initialized
DEBUG - 2016-08-31 00:30:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:30:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:30:49 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:30:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:30:49 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:30:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:30:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:30:49 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:30:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:30:49 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:30:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:30:49 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:30:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:30:49 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:30:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:30:49 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:30:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:30:49 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:30:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:30:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:30:49 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:30:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:30:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:30:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:30:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:30:49 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:30:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:30:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:30:49 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:30:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:30:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:30:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:30:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:30:49 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:30:49 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:30:49 --> Session Class Initialized
DEBUG - 2016-08-31 00:30:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:30:49 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:30:49 --> Session routines successfully run
DEBUG - 2016-08-31 00:30:49 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:30:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:30:49 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:30:49 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:30:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:30:49 --> Controller Class Initialized
DEBUG - 2016-08-31 00:30:50 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:30:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:30:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:30:50 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:30:50 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:30:50 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:30:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:50 --> Model Class Initialized
DEBUG - 2016-08-31 00:30:50 --> Model Class Initialized
ERROR - 2016-08-31 00:30:50 --> Severity: Warning  --> ZipArchive::locateName(): Invalid or uninitialized Zip object E:\www\lwscodeigniterwrapper\libraries\lwphpword\PhpWord\Shared\ZipArchive.php 115
DEBUG - 2016-08-31 00:31:39 --> Config Class Initialized
DEBUG - 2016-08-31 00:31:39 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:31:39 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:31:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:31:39 --> URI Class Initialized
DEBUG - 2016-08-31 00:31:39 --> Router Class Initialized
DEBUG - 2016-08-31 00:31:39 --> Output Class Initialized
DEBUG - 2016-08-31 00:31:39 --> Security Class Initialized
DEBUG - 2016-08-31 00:31:39 --> Input Class Initialized
DEBUG - 2016-08-31 00:31:39 --> XSS Filtering completed
DEBUG - 2016-08-31 00:31:39 --> XSS Filtering completed
DEBUG - 2016-08-31 00:31:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:31:39 --> Language Class Initialized
DEBUG - 2016-08-31 00:31:39 --> Loader Class Initialized
DEBUG - 2016-08-31 00:31:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:31:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:31:39 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:31:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:31:39 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:31:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:31:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:31:39 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:31:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:31:39 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:31:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:31:39 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:31:39 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:31:39 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:31:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:31:39 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:31:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:31:39 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:31:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:31:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:31:40 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:31:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:31:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:31:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:31:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:31:40 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:31:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:31:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:31:40 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:31:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:31:40 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:31:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:31:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:31:40 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:31:40 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:31:40 --> Session Class Initialized
DEBUG - 2016-08-31 00:31:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:31:40 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:31:40 --> Session routines successfully run
DEBUG - 2016-08-31 00:31:40 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:31:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:31:40 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:31:40 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:31:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:31:40 --> Controller Class Initialized
DEBUG - 2016-08-31 00:31:40 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:31:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:31:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:31:40 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:31:40 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:31:40 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:31:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:31:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:31:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:31:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:31:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:31:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:31:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:31:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:31:40 --> Model Class Initialized
DEBUG - 2016-08-31 00:31:40 --> Model Class Initialized
ERROR - 2016-08-31 00:31:40 --> Severity: Warning  --> ZipArchive::locateName(): Invalid or uninitialized Zip object E:\www\lwscodeigniterwrapper\libraries\lwphpword\PhpWord\Shared\ZipArchive.php 115
DEBUG - 2016-08-31 00:35:15 --> Config Class Initialized
DEBUG - 2016-08-31 00:35:15 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:35:16 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:35:16 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:35:16 --> URI Class Initialized
DEBUG - 2016-08-31 00:35:16 --> Router Class Initialized
DEBUG - 2016-08-31 00:35:16 --> Output Class Initialized
DEBUG - 2016-08-31 00:35:16 --> Security Class Initialized
DEBUG - 2016-08-31 00:35:16 --> Input Class Initialized
DEBUG - 2016-08-31 00:35:16 --> XSS Filtering completed
DEBUG - 2016-08-31 00:35:16 --> XSS Filtering completed
DEBUG - 2016-08-31 00:35:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:35:16 --> Language Class Initialized
DEBUG - 2016-08-31 00:35:16 --> Loader Class Initialized
DEBUG - 2016-08-31 00:35:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:35:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:35:16 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:35:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:35:16 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:35:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:35:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:35:16 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:35:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:35:16 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:35:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:35:16 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:35:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:35:16 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:35:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:35:16 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:35:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:35:16 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:35:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:35:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:35:16 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:35:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:35:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:35:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:35:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:35:16 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:35:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:35:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:35:16 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:35:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:35:16 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:35:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:35:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:35:16 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:35:16 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:35:16 --> Session Class Initialized
DEBUG - 2016-08-31 00:35:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:35:16 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:35:16 --> Session routines successfully run
DEBUG - 2016-08-31 00:35:16 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:35:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:35:16 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:35:16 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:35:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:35:16 --> Controller Class Initialized
DEBUG - 2016-08-31 00:35:16 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:35:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:35:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:35:16 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:35:16 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:35:16 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:35:16 --> Model Class Initialized
DEBUG - 2016-08-31 00:35:16 --> Model Class Initialized
DEBUG - 2016-08-31 00:35:16 --> Model Class Initialized
DEBUG - 2016-08-31 00:35:16 --> Model Class Initialized
DEBUG - 2016-08-31 00:35:16 --> Model Class Initialized
DEBUG - 2016-08-31 00:35:16 --> Model Class Initialized
DEBUG - 2016-08-31 00:35:16 --> Model Class Initialized
DEBUG - 2016-08-31 00:35:16 --> Model Class Initialized
DEBUG - 2016-08-31 00:35:16 --> Model Class Initialized
DEBUG - 2016-08-31 00:35:16 --> Model Class Initialized
DEBUG - 2016-08-31 00:42:09 --> Config Class Initialized
DEBUG - 2016-08-31 00:42:09 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:42:09 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:42:09 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:42:09 --> URI Class Initialized
DEBUG - 2016-08-31 00:42:09 --> Router Class Initialized
DEBUG - 2016-08-31 00:42:09 --> Output Class Initialized
DEBUG - 2016-08-31 00:42:09 --> Security Class Initialized
DEBUG - 2016-08-31 00:42:09 --> Input Class Initialized
DEBUG - 2016-08-31 00:42:09 --> XSS Filtering completed
DEBUG - 2016-08-31 00:42:09 --> XSS Filtering completed
DEBUG - 2016-08-31 00:42:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:42:09 --> Language Class Initialized
DEBUG - 2016-08-31 00:42:09 --> Loader Class Initialized
DEBUG - 2016-08-31 00:42:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:42:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:42:09 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:42:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:42:09 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:42:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:42:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:42:10 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:42:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:42:10 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:42:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:42:10 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:42:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:42:10 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:42:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:42:10 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:42:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:42:10 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:42:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:42:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:42:10 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:42:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:42:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:42:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:42:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:42:10 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:42:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:42:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:42:10 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:42:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:42:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:42:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:42:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:42:10 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:42:10 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:42:10 --> Session Class Initialized
DEBUG - 2016-08-31 00:42:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:42:10 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:42:10 --> Session routines successfully run
DEBUG - 2016-08-31 00:42:10 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:42:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:42:10 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:42:10 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:42:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:42:10 --> Controller Class Initialized
DEBUG - 2016-08-31 00:42:10 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:42:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:42:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:42:10 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:42:10 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:42:10 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:42:10 --> Model Class Initialized
DEBUG - 2016-08-31 00:42:10 --> Model Class Initialized
DEBUG - 2016-08-31 00:42:10 --> Model Class Initialized
DEBUG - 2016-08-31 00:42:10 --> Model Class Initialized
DEBUG - 2016-08-31 00:42:10 --> Model Class Initialized
DEBUG - 2016-08-31 00:42:10 --> Model Class Initialized
DEBUG - 2016-08-31 00:42:10 --> Model Class Initialized
DEBUG - 2016-08-31 00:42:10 --> Model Class Initialized
DEBUG - 2016-08-31 00:42:10 --> Model Class Initialized
DEBUG - 2016-08-31 00:42:10 --> Model Class Initialized
DEBUG - 2016-08-31 00:42:33 --> Config Class Initialized
DEBUG - 2016-08-31 00:42:33 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:42:33 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:42:33 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:42:33 --> URI Class Initialized
DEBUG - 2016-08-31 00:42:33 --> Router Class Initialized
DEBUG - 2016-08-31 00:42:33 --> Output Class Initialized
DEBUG - 2016-08-31 00:42:33 --> Security Class Initialized
DEBUG - 2016-08-31 00:42:33 --> Input Class Initialized
DEBUG - 2016-08-31 00:42:33 --> XSS Filtering completed
DEBUG - 2016-08-31 00:42:33 --> XSS Filtering completed
DEBUG - 2016-08-31 00:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:42:33 --> Language Class Initialized
DEBUG - 2016-08-31 00:42:33 --> Loader Class Initialized
DEBUG - 2016-08-31 00:42:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:42:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:42:33 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:42:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:42:33 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:42:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:42:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:42:33 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:42:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:42:33 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:42:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:42:33 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:42:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:42:33 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:42:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:42:33 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:42:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:42:33 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:42:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:42:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:42:33 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:42:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:42:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:42:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:42:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:42:33 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:42:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:42:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:42:33 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:42:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:42:33 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:42:33 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:42:33 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:42:33 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:42:33 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:42:33 --> Session Class Initialized
DEBUG - 2016-08-31 00:42:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:42:33 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:42:33 --> Session routines successfully run
DEBUG - 2016-08-31 00:42:33 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:42:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:42:33 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:42:33 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:42:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:42:33 --> Controller Class Initialized
DEBUG - 2016-08-31 00:42:33 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:42:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:42:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:42:33 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:42:33 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:42:33 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:42:34 --> Model Class Initialized
DEBUG - 2016-08-31 00:42:34 --> Model Class Initialized
DEBUG - 2016-08-31 00:42:34 --> Model Class Initialized
DEBUG - 2016-08-31 00:42:34 --> Model Class Initialized
DEBUG - 2016-08-31 00:42:34 --> Model Class Initialized
DEBUG - 2016-08-31 00:42:34 --> Model Class Initialized
DEBUG - 2016-08-31 00:42:34 --> Model Class Initialized
DEBUG - 2016-08-31 00:42:34 --> Model Class Initialized
DEBUG - 2016-08-31 00:42:34 --> Model Class Initialized
DEBUG - 2016-08-31 00:42:34 --> Model Class Initialized
DEBUG - 2016-08-31 00:43:11 --> Config Class Initialized
DEBUG - 2016-08-31 00:43:11 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:43:11 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:43:11 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:43:11 --> URI Class Initialized
DEBUG - 2016-08-31 00:43:11 --> Router Class Initialized
DEBUG - 2016-08-31 00:43:11 --> Output Class Initialized
DEBUG - 2016-08-31 00:43:11 --> Security Class Initialized
DEBUG - 2016-08-31 00:43:11 --> Input Class Initialized
DEBUG - 2016-08-31 00:43:11 --> XSS Filtering completed
DEBUG - 2016-08-31 00:43:11 --> XSS Filtering completed
DEBUG - 2016-08-31 00:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:43:11 --> Language Class Initialized
DEBUG - 2016-08-31 00:43:11 --> Loader Class Initialized
DEBUG - 2016-08-31 00:43:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:43:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:43:11 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:43:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:43:11 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:43:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:43:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:43:11 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:43:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:43:11 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:43:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:43:11 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:43:11 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:43:11 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:43:11 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:43:11 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:43:11 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:43:11 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:43:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:43:11 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:43:11 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:43:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:43:11 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:43:11 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:43:11 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:43:11 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:43:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:43:11 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:43:11 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:43:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:43:11 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:43:11 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:43:11 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:43:11 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:43:11 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:43:11 --> Session Class Initialized
DEBUG - 2016-08-31 00:43:11 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:43:11 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:43:11 --> Session routines successfully run
DEBUG - 2016-08-31 00:43:11 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:43:11 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:43:11 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:43:11 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:43:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:43:12 --> Controller Class Initialized
DEBUG - 2016-08-31 00:43:12 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:43:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:43:12 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:43:12 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:43:12 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:43:12 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:43:12 --> Model Class Initialized
DEBUG - 2016-08-31 00:43:12 --> Model Class Initialized
DEBUG - 2016-08-31 00:43:12 --> Model Class Initialized
DEBUG - 2016-08-31 00:43:12 --> Model Class Initialized
DEBUG - 2016-08-31 00:43:12 --> Model Class Initialized
DEBUG - 2016-08-31 00:43:12 --> Model Class Initialized
DEBUG - 2016-08-31 00:43:12 --> Model Class Initialized
DEBUG - 2016-08-31 00:43:12 --> Model Class Initialized
DEBUG - 2016-08-31 00:43:12 --> Model Class Initialized
DEBUG - 2016-08-31 00:43:12 --> Model Class Initialized
ERROR - 2016-08-31 00:43:12 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:177) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-08-31 00:43:14 --> Config Class Initialized
DEBUG - 2016-08-31 00:43:14 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:43:14 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:43:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:43:14 --> URI Class Initialized
DEBUG - 2016-08-31 00:43:14 --> Router Class Initialized
DEBUG - 2016-08-31 00:43:14 --> Output Class Initialized
DEBUG - 2016-08-31 00:43:14 --> Security Class Initialized
DEBUG - 2016-08-31 00:43:14 --> Input Class Initialized
DEBUG - 2016-08-31 00:43:14 --> XSS Filtering completed
DEBUG - 2016-08-31 00:43:14 --> XSS Filtering completed
DEBUG - 2016-08-31 00:43:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:43:14 --> Language Class Initialized
DEBUG - 2016-08-31 00:43:14 --> Loader Class Initialized
DEBUG - 2016-08-31 00:43:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:43:14 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:43:14 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:43:14 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:43:14 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:43:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:43:14 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:43:14 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:43:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:43:14 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:43:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:43:14 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:43:14 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:43:14 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:43:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:43:14 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:43:14 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:43:14 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:43:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:43:14 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:43:14 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:43:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:43:14 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:43:14 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:43:14 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:43:14 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:43:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:43:14 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:43:14 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:43:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:43:14 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:43:14 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:43:14 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:43:14 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:43:14 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:43:14 --> Session Class Initialized
DEBUG - 2016-08-31 00:43:14 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:43:14 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:43:14 --> Session routines successfully run
DEBUG - 2016-08-31 00:43:14 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:43:14 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:43:14 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:43:14 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:43:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:43:14 --> Controller Class Initialized
DEBUG - 2016-08-31 00:43:14 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:43:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:43:14 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:43:14 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:43:14 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:43:14 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:43:14 --> Model Class Initialized
DEBUG - 2016-08-31 00:43:14 --> Model Class Initialized
DEBUG - 2016-08-31 00:43:14 --> Model Class Initialized
DEBUG - 2016-08-31 00:43:14 --> Model Class Initialized
DEBUG - 2016-08-31 00:43:14 --> Model Class Initialized
DEBUG - 2016-08-31 00:43:14 --> Model Class Initialized
DEBUG - 2016-08-31 00:43:14 --> Model Class Initialized
DEBUG - 2016-08-31 00:43:14 --> Model Class Initialized
DEBUG - 2016-08-31 00:43:14 --> Model Class Initialized
DEBUG - 2016-08-31 00:43:14 --> Model Class Initialized
ERROR - 2016-08-31 00:43:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:177) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-08-31 00:50:12 --> Config Class Initialized
DEBUG - 2016-08-31 00:50:12 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:50:12 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:50:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:50:12 --> URI Class Initialized
DEBUG - 2016-08-31 00:50:12 --> Router Class Initialized
DEBUG - 2016-08-31 00:50:12 --> No URI present. Default controller set.
DEBUG - 2016-08-31 00:50:12 --> Output Class Initialized
DEBUG - 2016-08-31 00:50:12 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 00:50:12 --> Security Class Initialized
DEBUG - 2016-08-31 00:50:12 --> Input Class Initialized
DEBUG - 2016-08-31 00:50:12 --> XSS Filtering completed
DEBUG - 2016-08-31 00:50:12 --> XSS Filtering completed
DEBUG - 2016-08-31 00:50:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:50:12 --> Language Class Initialized
DEBUG - 2016-08-31 00:50:12 --> Loader Class Initialized
DEBUG - 2016-08-31 00:50:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:50:12 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:50:12 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:50:12 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:50:12 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:50:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:50:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:50:12 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:50:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:50:12 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:50:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:50:12 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:50:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:50:12 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:50:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:50:12 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:50:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:50:12 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:50:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:50:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:50:12 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:50:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:50:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:50:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:50:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:50:12 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:50:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:50:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:50:12 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:50:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:50:13 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:50:13 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:50:13 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:50:13 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:50:13 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:50:13 --> Session Class Initialized
DEBUG - 2016-08-31 00:50:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:50:13 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:50:13 --> Session routines successfully run
DEBUG - 2016-08-31 00:50:13 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:50:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:50:13 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:50:13 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:50:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:50:13 --> Controller Class Initialized
DEBUG - 2016-08-31 00:50:13 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:50:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:50:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:50:13 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:50:13 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:50:13 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:50:13 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:13 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:13 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-08-31 00:50:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 00:50:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 00:50:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 00:50:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 00:50:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 00:50:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 00:50:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 00:50:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 00:50:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 00:50:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 00:50:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 00:50:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 00:50:13 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-08-31 00:50:13 --> Final output sent to browser
DEBUG - 2016-08-31 00:50:13 --> Total execution time: 0.7007
DEBUG - 2016-08-31 00:50:16 --> Config Class Initialized
DEBUG - 2016-08-31 00:50:16 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:50:16 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:50:16 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:50:16 --> URI Class Initialized
DEBUG - 2016-08-31 00:50:16 --> Router Class Initialized
DEBUG - 2016-08-31 00:50:16 --> Output Class Initialized
DEBUG - 2016-08-31 00:50:16 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 00:50:16 --> Security Class Initialized
DEBUG - 2016-08-31 00:50:16 --> Input Class Initialized
DEBUG - 2016-08-31 00:50:16 --> XSS Filtering completed
DEBUG - 2016-08-31 00:50:16 --> XSS Filtering completed
DEBUG - 2016-08-31 00:50:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:50:16 --> Language Class Initialized
DEBUG - 2016-08-31 00:50:16 --> Loader Class Initialized
DEBUG - 2016-08-31 00:50:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:50:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:50:16 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:50:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:50:16 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:50:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:50:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:50:16 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:50:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:50:16 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:50:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:50:16 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:50:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:50:16 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:50:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:50:16 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:50:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:50:16 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:50:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:50:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:50:16 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:50:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:50:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:50:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:50:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:50:16 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:50:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:50:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:50:16 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:50:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:50:16 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:50:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:50:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:50:16 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:50:16 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:50:16 --> Session Class Initialized
DEBUG - 2016-08-31 00:50:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:50:16 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:50:16 --> Session routines successfully run
DEBUG - 2016-08-31 00:50:16 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:50:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:50:16 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:50:16 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:50:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:50:16 --> Controller Class Initialized
DEBUG - 2016-08-31 00:50:16 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:50:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:50:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:50:16 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:50:16 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:50:16 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:50:16 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:16 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:16 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:16 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:16 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:16 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:16 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:16 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:17 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 00:50:17 --> Pagination Class Initialized
DEBUG - 2016-08-31 00:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 00:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-31 00:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 00:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 00:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 00:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 00:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 00:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 00:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 00:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 00:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 00:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 00:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 00:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 00:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 00:50:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 00:50:17 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-31 00:50:17 --> Final output sent to browser
DEBUG - 2016-08-31 00:50:17 --> Total execution time: 0.7900
DEBUG - 2016-08-31 00:50:21 --> Config Class Initialized
DEBUG - 2016-08-31 00:50:21 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:50:21 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:50:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:50:21 --> URI Class Initialized
DEBUG - 2016-08-31 00:50:21 --> Router Class Initialized
DEBUG - 2016-08-31 00:50:21 --> Output Class Initialized
DEBUG - 2016-08-31 00:50:21 --> Security Class Initialized
DEBUG - 2016-08-31 00:50:21 --> Input Class Initialized
DEBUG - 2016-08-31 00:50:21 --> XSS Filtering completed
DEBUG - 2016-08-31 00:50:21 --> XSS Filtering completed
DEBUG - 2016-08-31 00:50:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:50:21 --> Language Class Initialized
DEBUG - 2016-08-31 00:50:21 --> Loader Class Initialized
DEBUG - 2016-08-31 00:50:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:50:21 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:50:21 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:50:21 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:50:21 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:50:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:50:21 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:50:21 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:50:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:50:21 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:50:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:50:21 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:50:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:50:21 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:50:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:50:21 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:50:21 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:50:21 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:50:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:50:21 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:50:21 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:50:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:50:21 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:50:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:50:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:50:21 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:50:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:50:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:50:21 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:50:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:50:21 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:50:21 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:50:21 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:50:21 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:50:21 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:50:21 --> Session Class Initialized
DEBUG - 2016-08-31 00:50:21 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:50:21 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:50:21 --> Session routines successfully run
DEBUG - 2016-08-31 00:50:21 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:50:21 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:50:21 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:50:21 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:50:21 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:50:21 --> Controller Class Initialized
DEBUG - 2016-08-31 00:50:21 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:50:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:50:21 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:50:21 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:50:21 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:50:21 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:50:21 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:21 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:21 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:21 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:21 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:21 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:21 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:21 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:21 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:21 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:23 --> Config Class Initialized
DEBUG - 2016-08-31 00:50:23 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:50:23 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:50:23 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:50:23 --> URI Class Initialized
DEBUG - 2016-08-31 00:50:23 --> Router Class Initialized
DEBUG - 2016-08-31 00:50:23 --> Output Class Initialized
DEBUG - 2016-08-31 00:50:23 --> Security Class Initialized
DEBUG - 2016-08-31 00:50:23 --> Input Class Initialized
DEBUG - 2016-08-31 00:50:23 --> XSS Filtering completed
DEBUG - 2016-08-31 00:50:23 --> XSS Filtering completed
DEBUG - 2016-08-31 00:50:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:50:23 --> Language Class Initialized
DEBUG - 2016-08-31 00:50:23 --> Loader Class Initialized
DEBUG - 2016-08-31 00:50:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:50:23 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:50:23 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:50:23 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:50:23 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:50:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:50:23 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:50:23 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:50:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:50:23 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:50:23 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:50:23 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:50:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:50:23 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:50:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:50:23 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:50:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:50:23 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:50:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:50:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:50:24 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:50:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:50:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:50:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:50:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:50:24 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:50:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:50:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:50:24 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:50:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:50:24 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:50:24 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:50:24 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:50:24 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:50:24 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:50:24 --> Session Class Initialized
DEBUG - 2016-08-31 00:50:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:50:24 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:50:24 --> Session routines successfully run
DEBUG - 2016-08-31 00:50:24 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:50:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:50:24 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:50:24 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:50:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:50:24 --> Controller Class Initialized
DEBUG - 2016-08-31 00:50:24 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:50:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:50:24 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:50:24 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:50:24 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:50:24 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:50:24 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:24 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:24 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:24 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:24 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:24 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:24 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:24 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:24 --> Model Class Initialized
DEBUG - 2016-08-31 00:50:24 --> Model Class Initialized
DEBUG - 2016-08-31 00:59:18 --> Config Class Initialized
DEBUG - 2016-08-31 00:59:18 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:59:18 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:59:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:59:18 --> URI Class Initialized
DEBUG - 2016-08-31 00:59:18 --> Router Class Initialized
DEBUG - 2016-08-31 00:59:18 --> Output Class Initialized
DEBUG - 2016-08-31 00:59:18 --> Security Class Initialized
DEBUG - 2016-08-31 00:59:18 --> Input Class Initialized
DEBUG - 2016-08-31 00:59:18 --> XSS Filtering completed
DEBUG - 2016-08-31 00:59:18 --> XSS Filtering completed
DEBUG - 2016-08-31 00:59:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:59:18 --> Language Class Initialized
DEBUG - 2016-08-31 00:59:18 --> Loader Class Initialized
DEBUG - 2016-08-31 00:59:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:59:18 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:59:18 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:59:18 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:59:18 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:59:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:59:18 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:59:18 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:59:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:59:18 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:59:18 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:59:18 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:59:18 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:59:18 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:59:18 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:59:18 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:59:18 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:59:18 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:59:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:59:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:59:18 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:59:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:59:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:59:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:59:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:59:18 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:59:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:59:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:59:18 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:59:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:59:18 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:59:18 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:59:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:59:19 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:59:19 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:59:19 --> Session Class Initialized
DEBUG - 2016-08-31 00:59:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:59:19 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:59:19 --> Session routines successfully run
DEBUG - 2016-08-31 00:59:19 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:59:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:59:19 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:59:19 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:59:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:59:19 --> Controller Class Initialized
DEBUG - 2016-08-31 00:59:19 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:59:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:59:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:59:19 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:59:19 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:59:19 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:59:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:59:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:59:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:59:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:59:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:59:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:59:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:59:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:59:19 --> Model Class Initialized
DEBUG - 2016-08-31 00:59:19 --> Model Class Initialized
ERROR - 2016-08-31 00:59:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:177) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-08-31 00:59:21 --> Config Class Initialized
DEBUG - 2016-08-31 00:59:21 --> Hooks Class Initialized
DEBUG - 2016-08-31 00:59:21 --> Utf8 Class Initialized
DEBUG - 2016-08-31 00:59:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 00:59:21 --> URI Class Initialized
DEBUG - 2016-08-31 00:59:21 --> Router Class Initialized
DEBUG - 2016-08-31 00:59:21 --> Output Class Initialized
DEBUG - 2016-08-31 00:59:21 --> Security Class Initialized
DEBUG - 2016-08-31 00:59:21 --> Input Class Initialized
DEBUG - 2016-08-31 00:59:21 --> XSS Filtering completed
DEBUG - 2016-08-31 00:59:21 --> XSS Filtering completed
DEBUG - 2016-08-31 00:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 00:59:21 --> Language Class Initialized
DEBUG - 2016-08-31 00:59:21 --> Loader Class Initialized
DEBUG - 2016-08-31 00:59:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 00:59:21 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 00:59:21 --> Helper loaded: url_helper
DEBUG - 2016-08-31 00:59:21 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 00:59:21 --> Helper loaded: file_helper
DEBUG - 2016-08-31 00:59:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:59:21 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 00:59:21 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 00:59:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 00:59:21 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 00:59:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 00:59:21 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:59:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 00:59:21 --> Helper loaded: common_helper
DEBUG - 2016-08-31 00:59:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 00:59:21 --> Helper loaded: form_helper
DEBUG - 2016-08-31 00:59:21 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 00:59:21 --> Helper loaded: security_helper
DEBUG - 2016-08-31 00:59:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:59:21 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 00:59:21 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 00:59:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 00:59:21 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 00:59:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 00:59:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 00:59:21 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 00:59:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:59:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 00:59:21 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 00:59:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 00:59:21 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 00:59:21 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 00:59:21 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 00:59:21 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 00:59:21 --> Database Driver Class Initialized
DEBUG - 2016-08-31 00:59:21 --> Session Class Initialized
DEBUG - 2016-08-31 00:59:22 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 00:59:22 --> Helper loaded: string_helper
DEBUG - 2016-08-31 00:59:22 --> Session routines successfully run
DEBUG - 2016-08-31 00:59:22 --> Native_session Class Initialized
DEBUG - 2016-08-31 00:59:22 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 00:59:22 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:59:22 --> Form Validation Class Initialized
DEBUG - 2016-08-31 00:59:22 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 00:59:22 --> Controller Class Initialized
DEBUG - 2016-08-31 00:59:22 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 00:59:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 00:59:22 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 00:59:22 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:59:22 --> Carabiner: library configured.
DEBUG - 2016-08-31 00:59:22 --> User Agent Class Initialized
DEBUG - 2016-08-31 00:59:22 --> Model Class Initialized
DEBUG - 2016-08-31 00:59:22 --> Model Class Initialized
DEBUG - 2016-08-31 00:59:22 --> Model Class Initialized
DEBUG - 2016-08-31 00:59:22 --> Model Class Initialized
DEBUG - 2016-08-31 00:59:22 --> Model Class Initialized
DEBUG - 2016-08-31 00:59:22 --> Model Class Initialized
DEBUG - 2016-08-31 00:59:22 --> Model Class Initialized
DEBUG - 2016-08-31 00:59:22 --> Model Class Initialized
DEBUG - 2016-08-31 00:59:22 --> Model Class Initialized
DEBUG - 2016-08-31 00:59:22 --> Model Class Initialized
ERROR - 2016-08-31 00:59:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:177) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-08-31 01:02:00 --> Config Class Initialized
DEBUG - 2016-08-31 01:02:00 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:02:00 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:02:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:02:00 --> URI Class Initialized
DEBUG - 2016-08-31 01:02:00 --> Router Class Initialized
DEBUG - 2016-08-31 01:02:00 --> Output Class Initialized
DEBUG - 2016-08-31 01:02:00 --> Security Class Initialized
DEBUG - 2016-08-31 01:02:00 --> Input Class Initialized
DEBUG - 2016-08-31 01:02:00 --> XSS Filtering completed
DEBUG - 2016-08-31 01:02:00 --> XSS Filtering completed
DEBUG - 2016-08-31 01:02:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:02:00 --> Language Class Initialized
DEBUG - 2016-08-31 01:02:00 --> Loader Class Initialized
DEBUG - 2016-08-31 01:02:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:02:00 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:02:00 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:02:00 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:02:00 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:02:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:02:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:02:00 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:02:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:02:00 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:02:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:02:01 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:02:01 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:02:01 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:02:01 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:02:01 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:02:01 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:02:01 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:02:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:02:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:02:01 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:02:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:02:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:02:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:02:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:02:01 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:02:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:02:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:02:01 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:02:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:02:01 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:02:01 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:02:01 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:02:01 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:02:01 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:02:01 --> Session Class Initialized
DEBUG - 2016-08-31 01:02:01 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:02:01 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:02:01 --> Session routines successfully run
DEBUG - 2016-08-31 01:02:01 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:02:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:02:01 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:02:01 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:02:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:02:01 --> Controller Class Initialized
DEBUG - 2016-08-31 01:02:01 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:02:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:02:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:02:01 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:02:01 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:02:01 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:02:01 --> Model Class Initialized
DEBUG - 2016-08-31 01:02:01 --> Model Class Initialized
DEBUG - 2016-08-31 01:02:01 --> Model Class Initialized
DEBUG - 2016-08-31 01:02:01 --> Model Class Initialized
DEBUG - 2016-08-31 01:02:01 --> Model Class Initialized
DEBUG - 2016-08-31 01:02:01 --> Model Class Initialized
DEBUG - 2016-08-31 01:02:01 --> Model Class Initialized
DEBUG - 2016-08-31 01:02:01 --> Model Class Initialized
DEBUG - 2016-08-31 01:02:01 --> Model Class Initialized
DEBUG - 2016-08-31 01:02:01 --> Model Class Initialized
ERROR - 2016-08-31 01:02:01 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:177) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-08-31 01:02:35 --> Config Class Initialized
DEBUG - 2016-08-31 01:02:35 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:02:35 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:02:35 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:02:35 --> URI Class Initialized
DEBUG - 2016-08-31 01:02:35 --> Router Class Initialized
DEBUG - 2016-08-31 01:02:35 --> Output Class Initialized
DEBUG - 2016-08-31 01:02:35 --> Security Class Initialized
DEBUG - 2016-08-31 01:02:35 --> Input Class Initialized
DEBUG - 2016-08-31 01:02:35 --> XSS Filtering completed
DEBUG - 2016-08-31 01:02:35 --> XSS Filtering completed
DEBUG - 2016-08-31 01:02:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:02:36 --> Language Class Initialized
DEBUG - 2016-08-31 01:02:36 --> Loader Class Initialized
DEBUG - 2016-08-31 01:02:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:02:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:02:36 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:02:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:02:36 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:02:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:02:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:02:36 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:02:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:02:36 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:02:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:02:36 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:02:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:02:36 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:02:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:02:36 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:02:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:02:36 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:02:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:02:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:02:36 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:02:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:02:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:02:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:02:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:02:36 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:02:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:02:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:02:36 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:02:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:02:36 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:02:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:02:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:02:36 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:02:36 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:02:36 --> Session Class Initialized
DEBUG - 2016-08-31 01:02:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:02:36 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:02:36 --> Session routines successfully run
DEBUG - 2016-08-31 01:02:36 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:02:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:02:36 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:02:36 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:02:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:02:36 --> Controller Class Initialized
DEBUG - 2016-08-31 01:02:36 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:02:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:02:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:02:36 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:02:36 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:02:36 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:02:36 --> Model Class Initialized
DEBUG - 2016-08-31 01:02:36 --> Model Class Initialized
DEBUG - 2016-08-31 01:02:36 --> Model Class Initialized
DEBUG - 2016-08-31 01:02:36 --> Model Class Initialized
DEBUG - 2016-08-31 01:02:36 --> Model Class Initialized
DEBUG - 2016-08-31 01:02:36 --> Model Class Initialized
DEBUG - 2016-08-31 01:02:36 --> Model Class Initialized
DEBUG - 2016-08-31 01:02:36 --> Model Class Initialized
DEBUG - 2016-08-31 01:02:36 --> Model Class Initialized
DEBUG - 2016-08-31 01:02:36 --> Model Class Initialized
ERROR - 2016-08-31 01:02:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:177) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-08-31 01:05:28 --> Config Class Initialized
DEBUG - 2016-08-31 01:05:28 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:05:28 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:05:28 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:05:28 --> URI Class Initialized
DEBUG - 2016-08-31 01:05:28 --> Router Class Initialized
DEBUG - 2016-08-31 01:05:28 --> Output Class Initialized
DEBUG - 2016-08-31 01:05:28 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 01:05:28 --> Security Class Initialized
DEBUG - 2016-08-31 01:05:28 --> Input Class Initialized
DEBUG - 2016-08-31 01:05:28 --> XSS Filtering completed
DEBUG - 2016-08-31 01:05:28 --> XSS Filtering completed
DEBUG - 2016-08-31 01:05:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:05:28 --> Language Class Initialized
DEBUG - 2016-08-31 01:05:28 --> Loader Class Initialized
DEBUG - 2016-08-31 01:05:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:05:28 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:05:28 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:05:28 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:05:28 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:05:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:05:28 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:05:28 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:05:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:05:28 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:05:28 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:05:28 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:05:28 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:05:28 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:05:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:05:28 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:05:28 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:05:28 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:05:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:05:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:05:28 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:05:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:05:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:05:28 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:05:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:05:28 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:05:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:05:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:05:28 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:05:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:05:28 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:05:28 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:05:28 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:05:28 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:05:28 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:05:28 --> Session Class Initialized
DEBUG - 2016-08-31 01:05:28 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:05:28 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:05:28 --> Session routines successfully run
DEBUG - 2016-08-31 01:05:28 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:05:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:05:28 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:05:28 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:05:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:05:28 --> Controller Class Initialized
DEBUG - 2016-08-31 01:05:28 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:05:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:05:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:05:28 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:05:28 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:05:28 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:05:28 --> Model Class Initialized
DEBUG - 2016-08-31 01:05:28 --> Model Class Initialized
DEBUG - 2016-08-31 01:05:28 --> Model Class Initialized
DEBUG - 2016-08-31 01:05:28 --> Model Class Initialized
DEBUG - 2016-08-31 01:05:28 --> Model Class Initialized
DEBUG - 2016-08-31 01:05:28 --> Model Class Initialized
DEBUG - 2016-08-31 01:05:28 --> Model Class Initialized
DEBUG - 2016-08-31 01:05:28 --> Model Class Initialized
DEBUG - 2016-08-31 01:05:28 --> Model Class Initialized
DEBUG - 2016-08-31 01:05:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 01:05:28 --> Pagination Class Initialized
DEBUG - 2016-08-31 01:05:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:05:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-31 01:05:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:05:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:05:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:05:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:05:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 01:05:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:05:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:05:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:05:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:05:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:05:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:05:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 01:05:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:05:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:05:29 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-31 01:05:29 --> Final output sent to browser
DEBUG - 2016-08-31 01:05:29 --> Total execution time: 0.9396
DEBUG - 2016-08-31 01:05:32 --> Config Class Initialized
DEBUG - 2016-08-31 01:05:32 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:05:32 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:05:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:05:32 --> URI Class Initialized
DEBUG - 2016-08-31 01:05:32 --> Router Class Initialized
DEBUG - 2016-08-31 01:05:32 --> Output Class Initialized
DEBUG - 2016-08-31 01:05:32 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 01:05:32 --> Security Class Initialized
DEBUG - 2016-08-31 01:05:32 --> Input Class Initialized
DEBUG - 2016-08-31 01:05:32 --> XSS Filtering completed
DEBUG - 2016-08-31 01:05:32 --> XSS Filtering completed
DEBUG - 2016-08-31 01:05:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:05:32 --> Language Class Initialized
DEBUG - 2016-08-31 01:05:32 --> Loader Class Initialized
DEBUG - 2016-08-31 01:05:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:05:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:05:32 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:05:32 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:05:32 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:05:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:05:32 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:05:32 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:05:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:05:32 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:05:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:05:32 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:05:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:05:32 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:05:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:05:32 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:05:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:05:32 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:05:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:05:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:05:32 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:05:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:05:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:05:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:05:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:05:32 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:05:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:05:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:05:32 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:05:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:05:32 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:05:32 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:05:32 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:05:32 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:05:33 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:05:33 --> Session Class Initialized
DEBUG - 2016-08-31 01:05:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:05:33 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:05:33 --> Session routines successfully run
DEBUG - 2016-08-31 01:05:33 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:05:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:05:33 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:05:33 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:05:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:05:33 --> Controller Class Initialized
DEBUG - 2016-08-31 01:05:33 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:05:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:05:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:05:33 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:05:33 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:05:33 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:05:33 --> Model Class Initialized
DEBUG - 2016-08-31 01:05:33 --> Model Class Initialized
DEBUG - 2016-08-31 01:05:33 --> Model Class Initialized
DEBUG - 2016-08-31 01:05:33 --> Model Class Initialized
DEBUG - 2016-08-31 01:05:33 --> Model Class Initialized
DEBUG - 2016-08-31 01:05:33 --> Model Class Initialized
DEBUG - 2016-08-31 01:05:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 01:05:33 --> Pagination Class Initialized
DEBUG - 2016-08-31 01:05:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:05:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-31 01:05:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:05:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:05:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:05:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:05:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 01:05:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:05:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:05:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:05:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:05:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:05:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:05:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 01:05:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:05:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:05:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6ab6771ae9d42e25effdc2b45133f90d
DEBUG - 2016-08-31 01:05:33 --> Final output sent to browser
DEBUG - 2016-08-31 01:05:33 --> Total execution time: 0.8744
DEBUG - 2016-08-31 01:06:55 --> Config Class Initialized
DEBUG - 2016-08-31 01:06:55 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:06:55 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:06:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:06:55 --> URI Class Initialized
DEBUG - 2016-08-31 01:06:55 --> Router Class Initialized
DEBUG - 2016-08-31 01:06:55 --> Output Class Initialized
DEBUG - 2016-08-31 01:06:55 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 01:06:55 --> Security Class Initialized
DEBUG - 2016-08-31 01:06:55 --> Input Class Initialized
DEBUG - 2016-08-31 01:06:55 --> XSS Filtering completed
DEBUG - 2016-08-31 01:06:55 --> XSS Filtering completed
DEBUG - 2016-08-31 01:06:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:06:55 --> Language Class Initialized
DEBUG - 2016-08-31 01:06:55 --> Loader Class Initialized
DEBUG - 2016-08-31 01:06:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:06:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:06:55 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:06:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:06:55 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:06:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:06:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:06:55 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:06:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:06:55 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:06:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:06:55 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:06:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:06:55 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:06:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:06:55 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:06:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:06:55 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:06:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:06:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:06:55 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:06:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:06:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:06:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:06:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:06:55 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:06:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:06:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:06:55 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:06:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:06:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:06:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:06:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:06:55 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:06:55 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:06:56 --> Session Class Initialized
DEBUG - 2016-08-31 01:06:56 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:06:56 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:06:56 --> Session routines successfully run
DEBUG - 2016-08-31 01:06:56 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:06:56 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:06:56 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:06:56 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:06:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:06:56 --> Controller Class Initialized
DEBUG - 2016-08-31 01:06:56 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:06:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:06:56 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:06:56 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:06:56 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:06:56 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:06:56 --> Model Class Initialized
DEBUG - 2016-08-31 01:06:56 --> Model Class Initialized
DEBUG - 2016-08-31 01:06:56 --> Model Class Initialized
DEBUG - 2016-08-31 01:06:56 --> Model Class Initialized
DEBUG - 2016-08-31 01:06:56 --> Model Class Initialized
DEBUG - 2016-08-31 01:06:56 --> Model Class Initialized
DEBUG - 2016-08-31 01:06:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 01:06:56 --> Pagination Class Initialized
DEBUG - 2016-08-31 01:06:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:06:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-31 01:06:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:06:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:06:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:06:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:06:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 01:06:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:06:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:06:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:06:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:06:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:06:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:06:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 01:06:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:06:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:06:56 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6ab6771ae9d42e25effdc2b45133f90d
DEBUG - 2016-08-31 01:06:56 --> Final output sent to browser
DEBUG - 2016-08-31 01:06:56 --> Total execution time: 0.8942
DEBUG - 2016-08-31 01:07:07 --> Config Class Initialized
DEBUG - 2016-08-31 01:07:07 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:07:07 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:07:08 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:07:08 --> URI Class Initialized
DEBUG - 2016-08-31 01:07:08 --> Router Class Initialized
DEBUG - 2016-08-31 01:07:08 --> Output Class Initialized
DEBUG - 2016-08-31 01:07:08 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 01:07:08 --> Security Class Initialized
DEBUG - 2016-08-31 01:07:08 --> Input Class Initialized
DEBUG - 2016-08-31 01:07:08 --> XSS Filtering completed
DEBUG - 2016-08-31 01:07:08 --> XSS Filtering completed
DEBUG - 2016-08-31 01:07:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:07:08 --> Language Class Initialized
DEBUG - 2016-08-31 01:07:08 --> Loader Class Initialized
DEBUG - 2016-08-31 01:07:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:07:08 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:07:08 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:07:08 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:07:08 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:07:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:07:08 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:07:08 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:07:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:07:08 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:07:08 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:07:08 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:07:08 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:07:08 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:07:08 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:07:08 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:07:08 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:07:08 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:07:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:07:08 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:07:08 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:07:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:07:08 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:07:08 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:07:08 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:07:08 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:07:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:07:08 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:07:08 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:07:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:07:08 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:07:08 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:07:08 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:07:08 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:07:08 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:07:08 --> Session Class Initialized
DEBUG - 2016-08-31 01:07:08 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:07:08 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:07:08 --> Session routines successfully run
DEBUG - 2016-08-31 01:07:08 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:07:08 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:07:08 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:07:08 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:07:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:07:08 --> Controller Class Initialized
DEBUG - 2016-08-31 01:07:08 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:07:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:07:08 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:07:08 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:07:08 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:07:08 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:07:08 --> Model Class Initialized
DEBUG - 2016-08-31 01:07:08 --> Model Class Initialized
DEBUG - 2016-08-31 01:07:08 --> Model Class Initialized
DEBUG - 2016-08-31 01:07:08 --> Model Class Initialized
DEBUG - 2016-08-31 01:07:08 --> Model Class Initialized
DEBUG - 2016-08-31 01:07:08 --> Model Class Initialized
DEBUG - 2016-08-31 01:07:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 01:07:08 --> Pagination Class Initialized
DEBUG - 2016-08-31 01:07:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:07:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-31 01:07:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:07:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:07:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:07:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:07:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 01:07:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:07:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:07:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:07:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:07:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:07:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:07:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 01:07:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:07:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:07:09 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6ab6771ae9d42e25effdc2b45133f90d
DEBUG - 2016-08-31 01:07:09 --> Final output sent to browser
DEBUG - 2016-08-31 01:07:09 --> Total execution time: 0.9298
DEBUG - 2016-08-31 01:08:10 --> Config Class Initialized
DEBUG - 2016-08-31 01:08:10 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:08:10 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:08:10 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:08:10 --> URI Class Initialized
DEBUG - 2016-08-31 01:08:10 --> Router Class Initialized
DEBUG - 2016-08-31 01:08:10 --> Output Class Initialized
DEBUG - 2016-08-31 01:08:10 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 01:08:10 --> Security Class Initialized
DEBUG - 2016-08-31 01:08:10 --> Input Class Initialized
DEBUG - 2016-08-31 01:08:10 --> XSS Filtering completed
DEBUG - 2016-08-31 01:08:10 --> XSS Filtering completed
DEBUG - 2016-08-31 01:08:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:08:10 --> Language Class Initialized
DEBUG - 2016-08-31 01:08:10 --> Loader Class Initialized
DEBUG - 2016-08-31 01:08:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:08:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:08:10 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:08:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:08:10 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:08:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:08:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:08:10 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:08:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:08:10 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:08:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:08:10 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:08:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:08:10 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:08:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:08:10 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:08:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:08:10 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:08:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:08:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:08:10 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:08:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:08:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:08:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:08:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:08:10 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:08:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:08:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:08:10 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:08:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:08:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:08:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:08:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:08:10 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:08:10 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:08:10 --> Session Class Initialized
DEBUG - 2016-08-31 01:08:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:08:10 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:08:10 --> Session routines successfully run
DEBUG - 2016-08-31 01:08:10 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:08:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:08:10 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:08:10 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:08:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:08:10 --> Controller Class Initialized
DEBUG - 2016-08-31 01:08:10 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:08:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:08:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:08:10 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:08:10 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:08:10 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:08:10 --> Model Class Initialized
DEBUG - 2016-08-31 01:08:10 --> Model Class Initialized
DEBUG - 2016-08-31 01:08:11 --> Model Class Initialized
DEBUG - 2016-08-31 01:08:11 --> Model Class Initialized
DEBUG - 2016-08-31 01:08:11 --> Model Class Initialized
DEBUG - 2016-08-31 01:08:11 --> Model Class Initialized
DEBUG - 2016-08-31 01:08:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 01:08:11 --> Pagination Class Initialized
DEBUG - 2016-08-31 01:08:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:08:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-31 01:08:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:08:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:08:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:08:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:08:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 01:08:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:08:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:08:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:08:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:08:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:08:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:08:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 01:08:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:08:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:08:11 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6ab6771ae9d42e25effdc2b45133f90d
DEBUG - 2016-08-31 01:08:11 --> Final output sent to browser
DEBUG - 2016-08-31 01:08:11 --> Total execution time: 0.9483
DEBUG - 2016-08-31 01:08:13 --> Config Class Initialized
DEBUG - 2016-08-31 01:08:13 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:08:13 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:08:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:08:13 --> URI Class Initialized
DEBUG - 2016-08-31 01:08:13 --> Router Class Initialized
ERROR - 2016-08-31 01:08:13 --> 404 Page Not Found --> back_end/cref_daftar_diklat
DEBUG - 2016-08-31 01:08:13 --> Config Class Initialized
DEBUG - 2016-08-31 01:08:13 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:08:13 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:08:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:08:13 --> URI Class Initialized
DEBUG - 2016-08-31 01:08:13 --> Router Class Initialized
ERROR - 2016-08-31 01:08:13 --> 404 Page Not Found --> back_end/cref_daftar_diklat
DEBUG - 2016-08-31 01:08:13 --> Config Class Initialized
DEBUG - 2016-08-31 01:08:13 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:08:13 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:08:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:08:13 --> URI Class Initialized
DEBUG - 2016-08-31 01:08:13 --> Router Class Initialized
ERROR - 2016-08-31 01:08:13 --> 404 Page Not Found --> back_end/cref_daftar_diklat
DEBUG - 2016-08-31 01:08:16 --> Config Class Initialized
DEBUG - 2016-08-31 01:08:16 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:08:16 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:08:16 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:08:16 --> URI Class Initialized
DEBUG - 2016-08-31 01:08:16 --> Router Class Initialized
DEBUG - 2016-08-31 01:08:16 --> Output Class Initialized
DEBUG - 2016-08-31 01:08:16 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 01:08:16 --> Security Class Initialized
DEBUG - 2016-08-31 01:08:16 --> Input Class Initialized
DEBUG - 2016-08-31 01:08:16 --> XSS Filtering completed
DEBUG - 2016-08-31 01:08:16 --> XSS Filtering completed
DEBUG - 2016-08-31 01:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:08:16 --> Language Class Initialized
DEBUG - 2016-08-31 01:08:16 --> Loader Class Initialized
DEBUG - 2016-08-31 01:08:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:08:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:08:16 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:08:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:08:16 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:08:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:08:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:08:16 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:08:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:08:16 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:08:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:08:16 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:08:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:08:16 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:08:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:08:16 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:08:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:08:16 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:08:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:08:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:08:16 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:08:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:08:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:08:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:08:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:08:16 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:08:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:08:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:08:16 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:08:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:08:16 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:08:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:08:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:08:16 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:08:16 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:08:16 --> Session Class Initialized
DEBUG - 2016-08-31 01:08:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:08:16 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:08:16 --> Session routines successfully run
DEBUG - 2016-08-31 01:08:16 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:08:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:08:16 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:08:16 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:08:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:08:16 --> Controller Class Initialized
DEBUG - 2016-08-31 01:08:16 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:08:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:08:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:08:16 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:08:16 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:08:16 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:08:16 --> Model Class Initialized
DEBUG - 2016-08-31 01:08:16 --> Model Class Initialized
DEBUG - 2016-08-31 01:08:16 --> Model Class Initialized
DEBUG - 2016-08-31 01:08:16 --> Model Class Initialized
DEBUG - 2016-08-31 01:08:17 --> Model Class Initialized
DEBUG - 2016-08-31 01:08:17 --> Model Class Initialized
DEBUG - 2016-08-31 01:08:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 01:08:17 --> Pagination Class Initialized
DEBUG - 2016-08-31 01:08:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:08:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-31 01:08:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:08:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:08:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:08:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:08:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 01:08:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:08:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:08:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:08:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:08:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:08:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:08:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 01:08:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:08:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:08:17 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6ab6771ae9d42e25effdc2b45133f90d
DEBUG - 2016-08-31 01:08:17 --> Final output sent to browser
DEBUG - 2016-08-31 01:08:17 --> Total execution time: 0.9601
DEBUG - 2016-08-31 01:08:53 --> Config Class Initialized
DEBUG - 2016-08-31 01:08:53 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:08:53 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:08:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:08:53 --> URI Class Initialized
DEBUG - 2016-08-31 01:08:53 --> Router Class Initialized
DEBUG - 2016-08-31 01:08:53 --> Output Class Initialized
DEBUG - 2016-08-31 01:08:53 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 01:08:53 --> Security Class Initialized
DEBUG - 2016-08-31 01:08:53 --> Input Class Initialized
DEBUG - 2016-08-31 01:08:53 --> XSS Filtering completed
DEBUG - 2016-08-31 01:08:53 --> XSS Filtering completed
DEBUG - 2016-08-31 01:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:08:53 --> Language Class Initialized
DEBUG - 2016-08-31 01:08:53 --> Loader Class Initialized
DEBUG - 2016-08-31 01:08:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:08:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:08:53 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:08:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:08:53 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:08:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:08:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:08:53 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:08:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:08:53 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:08:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:08:53 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:08:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:08:53 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:08:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:08:53 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:08:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:08:53 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:08:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:08:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:08:53 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:08:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:08:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:08:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:08:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:08:53 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:08:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:08:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:08:53 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:08:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:08:53 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:08:53 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:08:53 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:08:53 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:08:53 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:08:53 --> Session Class Initialized
DEBUG - 2016-08-31 01:08:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:08:53 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:08:53 --> Session routines successfully run
DEBUG - 2016-08-31 01:08:53 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:08:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:08:53 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:08:53 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:08:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:08:53 --> Controller Class Initialized
DEBUG - 2016-08-31 01:08:53 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:08:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:08:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:08:53 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:08:53 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:08:53 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:08:53 --> Model Class Initialized
DEBUG - 2016-08-31 01:08:53 --> Model Class Initialized
DEBUG - 2016-08-31 01:08:54 --> Model Class Initialized
DEBUG - 2016-08-31 01:08:54 --> Model Class Initialized
DEBUG - 2016-08-31 01:08:54 --> Model Class Initialized
DEBUG - 2016-08-31 01:08:54 --> Model Class Initialized
DEBUG - 2016-08-31 01:08:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 01:08:54 --> Pagination Class Initialized
DEBUG - 2016-08-31 01:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-31 01:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 01:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 01:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:08:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6ab6771ae9d42e25effdc2b45133f90d
DEBUG - 2016-08-31 01:08:54 --> Final output sent to browser
DEBUG - 2016-08-31 01:08:54 --> Total execution time: 0.9852
DEBUG - 2016-08-31 01:08:56 --> Config Class Initialized
DEBUG - 2016-08-31 01:08:56 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:08:56 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:08:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:08:56 --> URI Class Initialized
DEBUG - 2016-08-31 01:08:56 --> Router Class Initialized
ERROR - 2016-08-31 01:08:56 --> 404 Page Not Found --> back_end/cref_daftar_diklat
DEBUG - 2016-08-31 01:08:56 --> Config Class Initialized
DEBUG - 2016-08-31 01:08:56 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:08:56 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:08:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:08:56 --> URI Class Initialized
DEBUG - 2016-08-31 01:08:56 --> Router Class Initialized
ERROR - 2016-08-31 01:08:56 --> 404 Page Not Found --> back_end/cref_daftar_diklat
DEBUG - 2016-08-31 01:08:56 --> Config Class Initialized
DEBUG - 2016-08-31 01:08:56 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:08:56 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:08:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:08:56 --> URI Class Initialized
DEBUG - 2016-08-31 01:08:56 --> Router Class Initialized
ERROR - 2016-08-31 01:08:56 --> 404 Page Not Found --> back_end/cref_daftar_diklat
DEBUG - 2016-08-31 01:09:57 --> Config Class Initialized
DEBUG - 2016-08-31 01:09:57 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:09:57 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:09:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:09:57 --> URI Class Initialized
DEBUG - 2016-08-31 01:09:57 --> Router Class Initialized
ERROR - 2016-08-31 01:09:57 --> 404 Page Not Found --> back_end/cref_daftar_diklat
DEBUG - 2016-08-31 01:09:57 --> Config Class Initialized
DEBUG - 2016-08-31 01:09:57 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:09:57 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:09:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:09:57 --> URI Class Initialized
DEBUG - 2016-08-31 01:09:57 --> Router Class Initialized
ERROR - 2016-08-31 01:09:57 --> 404 Page Not Found --> back_end/cref_daftar_diklat
DEBUG - 2016-08-31 01:09:57 --> Config Class Initialized
DEBUG - 2016-08-31 01:09:57 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:09:57 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:09:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:09:57 --> URI Class Initialized
DEBUG - 2016-08-31 01:09:57 --> Router Class Initialized
ERROR - 2016-08-31 01:09:57 --> 404 Page Not Found --> back_end/cref_daftar_diklat
DEBUG - 2016-08-31 01:10:00 --> Config Class Initialized
DEBUG - 2016-08-31 01:10:00 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:10:00 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:10:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:10:00 --> URI Class Initialized
DEBUG - 2016-08-31 01:10:00 --> Router Class Initialized
DEBUG - 2016-08-31 01:10:00 --> Output Class Initialized
DEBUG - 2016-08-31 01:10:00 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 01:10:00 --> Security Class Initialized
DEBUG - 2016-08-31 01:10:00 --> Input Class Initialized
DEBUG - 2016-08-31 01:10:00 --> XSS Filtering completed
DEBUG - 2016-08-31 01:10:00 --> XSS Filtering completed
DEBUG - 2016-08-31 01:10:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:10:00 --> Language Class Initialized
DEBUG - 2016-08-31 01:10:00 --> Loader Class Initialized
DEBUG - 2016-08-31 01:10:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:10:00 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:10:00 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:10:00 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:10:00 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:10:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:10:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:10:00 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:10:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:10:00 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:10:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:10:00 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:10:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:10:00 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:10:00 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:10:00 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:10:00 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:10:00 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:10:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:10:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:10:00 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:10:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:10:00 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:10:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:10:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:10:00 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:10:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:10:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:10:00 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:10:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:10:00 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:10:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:10:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:10:00 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:10:00 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:10:00 --> Session Class Initialized
DEBUG - 2016-08-31 01:10:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:10:00 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:10:00 --> Session routines successfully run
DEBUG - 2016-08-31 01:10:00 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:10:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:10:01 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:10:01 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:10:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:10:01 --> Controller Class Initialized
DEBUG - 2016-08-31 01:10:01 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:10:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:10:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:10:01 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:10:01 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:10:01 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:10:01 --> Model Class Initialized
DEBUG - 2016-08-31 01:10:01 --> Model Class Initialized
DEBUG - 2016-08-31 01:10:01 --> Model Class Initialized
DEBUG - 2016-08-31 01:10:01 --> Model Class Initialized
DEBUG - 2016-08-31 01:10:01 --> Model Class Initialized
DEBUG - 2016-08-31 01:10:01 --> Model Class Initialized
DEBUG - 2016-08-31 01:10:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 01:10:01 --> Pagination Class Initialized
DEBUG - 2016-08-31 01:10:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:10:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-31 01:10:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:10:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:10:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:10:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:10:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 01:10:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:10:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:10:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:10:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:10:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:10:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:10:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 01:10:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:10:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:10:01 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6ab6771ae9d42e25effdc2b45133f90d
DEBUG - 2016-08-31 01:10:01 --> Final output sent to browser
DEBUG - 2016-08-31 01:10:01 --> Total execution time: 1.0147
DEBUG - 2016-08-31 01:10:03 --> Config Class Initialized
DEBUG - 2016-08-31 01:10:03 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:10:03 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:10:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:10:03 --> URI Class Initialized
DEBUG - 2016-08-31 01:10:03 --> Router Class Initialized
DEBUG - 2016-08-31 01:10:03 --> Output Class Initialized
DEBUG - 2016-08-31 01:10:03 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 01:10:03 --> Security Class Initialized
DEBUG - 2016-08-31 01:10:03 --> Input Class Initialized
DEBUG - 2016-08-31 01:10:03 --> XSS Filtering completed
DEBUG - 2016-08-31 01:10:03 --> XSS Filtering completed
DEBUG - 2016-08-31 01:10:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:10:03 --> Language Class Initialized
DEBUG - 2016-08-31 01:10:03 --> Loader Class Initialized
DEBUG - 2016-08-31 01:10:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:10:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:10:04 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:10:04 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:10:04 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:10:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:10:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:10:04 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:10:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:10:04 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:10:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:10:04 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:10:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:10:04 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:10:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:10:04 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:10:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:10:04 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:10:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:10:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:10:04 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:10:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:10:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:10:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:10:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:10:04 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:10:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:10:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:10:04 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:10:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:10:04 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:10:04 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:10:04 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:10:04 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:10:04 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:10:04 --> Session Class Initialized
DEBUG - 2016-08-31 01:10:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:10:04 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:10:04 --> Session routines successfully run
DEBUG - 2016-08-31 01:10:04 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:10:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:10:04 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:10:04 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:10:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:10:04 --> Controller Class Initialized
DEBUG - 2016-08-31 01:10:04 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:10:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:10:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:10:04 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:10:04 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:10:04 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:10:04 --> Model Class Initialized
DEBUG - 2016-08-31 01:10:04 --> Model Class Initialized
DEBUG - 2016-08-31 01:10:04 --> Model Class Initialized
DEBUG - 2016-08-31 01:10:04 --> Model Class Initialized
DEBUG - 2016-08-31 01:10:04 --> Model Class Initialized
DEBUG - 2016-08-31 01:10:04 --> Model Class Initialized
DEBUG - 2016-08-31 01:10:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 01:10:04 --> Pagination Class Initialized
DEBUG - 2016-08-31 01:10:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:10:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-31 01:10:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:10:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:10:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:10:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:10:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 01:10:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:10:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:10:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:10:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:10:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:10:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:10:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 01:10:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:10:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:10:05 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6ab6771ae9d42e25effdc2b45133f90d
DEBUG - 2016-08-31 01:10:05 --> Final output sent to browser
DEBUG - 2016-08-31 01:10:05 --> Total execution time: 0.9975
DEBUG - 2016-08-31 01:10:06 --> Config Class Initialized
DEBUG - 2016-08-31 01:10:06 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:10:06 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:10:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:10:06 --> URI Class Initialized
DEBUG - 2016-08-31 01:10:06 --> Router Class Initialized
ERROR - 2016-08-31 01:10:06 --> 404 Page Not Found --> back_end/cref_daftar_diklat
DEBUG - 2016-08-31 01:10:06 --> Config Class Initialized
DEBUG - 2016-08-31 01:10:06 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:10:06 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:10:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:10:06 --> URI Class Initialized
DEBUG - 2016-08-31 01:10:06 --> Router Class Initialized
ERROR - 2016-08-31 01:10:06 --> 404 Page Not Found --> back_end/cref_daftar_diklat
DEBUG - 2016-08-31 01:10:06 --> Config Class Initialized
DEBUG - 2016-08-31 01:10:06 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:10:06 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:10:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:10:06 --> URI Class Initialized
DEBUG - 2016-08-31 01:10:06 --> Router Class Initialized
ERROR - 2016-08-31 01:10:06 --> 404 Page Not Found --> back_end/cref_daftar_diklat
DEBUG - 2016-08-31 01:10:24 --> Config Class Initialized
DEBUG - 2016-08-31 01:10:24 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:10:24 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:10:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:10:24 --> URI Class Initialized
DEBUG - 2016-08-31 01:10:24 --> Router Class Initialized
ERROR - 2016-08-31 01:10:24 --> 404 Page Not Found --> back_end/cref_daftar_diklat
DEBUG - 2016-08-31 01:10:25 --> Config Class Initialized
DEBUG - 2016-08-31 01:10:25 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:10:25 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:10:25 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:10:25 --> URI Class Initialized
DEBUG - 2016-08-31 01:10:25 --> Router Class Initialized
ERROR - 2016-08-31 01:10:25 --> 404 Page Not Found --> back_end/cref_daftar_diklat
DEBUG - 2016-08-31 01:10:26 --> Config Class Initialized
DEBUG - 2016-08-31 01:10:26 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:10:26 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:10:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:10:26 --> URI Class Initialized
DEBUG - 2016-08-31 01:10:26 --> Router Class Initialized
ERROR - 2016-08-31 01:10:26 --> 404 Page Not Found --> back_end/cref_daftar_diklat
DEBUG - 2016-08-31 01:10:27 --> Config Class Initialized
DEBUG - 2016-08-31 01:10:27 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:10:27 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:10:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:10:27 --> URI Class Initialized
DEBUG - 2016-08-31 01:10:27 --> Router Class Initialized
ERROR - 2016-08-31 01:10:27 --> 404 Page Not Found --> back_end/cref_daftar_diklat
DEBUG - 2016-08-31 01:13:06 --> Config Class Initialized
DEBUG - 2016-08-31 01:13:06 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:13:06 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:13:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:13:06 --> URI Class Initialized
DEBUG - 2016-08-31 01:13:06 --> Router Class Initialized
DEBUG - 2016-08-31 01:13:06 --> Output Class Initialized
DEBUG - 2016-08-31 01:13:06 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 01:13:06 --> Security Class Initialized
DEBUG - 2016-08-31 01:13:06 --> Input Class Initialized
DEBUG - 2016-08-31 01:13:06 --> XSS Filtering completed
DEBUG - 2016-08-31 01:13:06 --> XSS Filtering completed
DEBUG - 2016-08-31 01:13:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:13:06 --> Language Class Initialized
DEBUG - 2016-08-31 01:13:06 --> Loader Class Initialized
DEBUG - 2016-08-31 01:13:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:13:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:13:06 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:13:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:13:06 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:13:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:13:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:13:06 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:13:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:13:06 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:13:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:13:06 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:13:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:13:06 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:13:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:13:06 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:13:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:13:06 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:13:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:13:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:13:06 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:13:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:13:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:13:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:13:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:13:06 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:13:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:13:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:13:06 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:13:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:13:07 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:13:07 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:13:07 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:13:07 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:13:07 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:13:07 --> Session Class Initialized
DEBUG - 2016-08-31 01:13:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:13:07 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:13:07 --> Session routines successfully run
DEBUG - 2016-08-31 01:13:07 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:13:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:13:07 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:13:07 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:13:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:13:07 --> Controller Class Initialized
DEBUG - 2016-08-31 01:13:07 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:13:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:13:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:13:07 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:13:07 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:13:07 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:13:07 --> Model Class Initialized
DEBUG - 2016-08-31 01:13:07 --> Model Class Initialized
DEBUG - 2016-08-31 01:13:07 --> Model Class Initialized
DEBUG - 2016-08-31 01:13:07 --> Model Class Initialized
DEBUG - 2016-08-31 01:13:07 --> Model Class Initialized
DEBUG - 2016-08-31 01:13:07 --> Model Class Initialized
DEBUG - 2016-08-31 01:13:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 01:13:07 --> Pagination Class Initialized
DEBUG - 2016-08-31 01:13:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:13:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-31 01:13:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:13:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:13:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:13:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:13:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 01:13:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:13:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:13:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:13:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:13:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:13:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:13:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 01:13:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:13:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:13:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6ab6771ae9d42e25effdc2b45133f90d
DEBUG - 2016-08-31 01:13:07 --> Final output sent to browser
DEBUG - 2016-08-31 01:13:07 --> Total execution time: 1.0407
DEBUG - 2016-08-31 01:13:27 --> Config Class Initialized
DEBUG - 2016-08-31 01:13:27 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:13:27 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:13:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:13:27 --> URI Class Initialized
DEBUG - 2016-08-31 01:13:27 --> Router Class Initialized
DEBUG - 2016-08-31 01:13:27 --> Output Class Initialized
DEBUG - 2016-08-31 01:13:27 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 01:13:27 --> Security Class Initialized
DEBUG - 2016-08-31 01:13:27 --> Input Class Initialized
DEBUG - 2016-08-31 01:13:27 --> XSS Filtering completed
DEBUG - 2016-08-31 01:13:27 --> XSS Filtering completed
DEBUG - 2016-08-31 01:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:13:27 --> Language Class Initialized
DEBUG - 2016-08-31 01:13:27 --> Loader Class Initialized
DEBUG - 2016-08-31 01:13:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:13:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:13:27 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:13:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:13:27 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:13:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:13:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:13:27 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:13:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:13:27 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:13:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:13:27 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:13:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:13:27 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:13:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:13:27 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:13:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:13:27 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:13:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:13:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:13:27 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:13:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:13:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:13:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:13:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:13:27 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:13:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:13:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:13:27 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:13:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:13:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:13:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:13:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:13:27 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:13:28 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:13:28 --> Session Class Initialized
DEBUG - 2016-08-31 01:13:28 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:13:28 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:13:28 --> Session routines successfully run
DEBUG - 2016-08-31 01:13:28 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:13:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:13:28 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:13:28 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:13:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:13:28 --> Controller Class Initialized
DEBUG - 2016-08-31 01:13:28 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:13:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:13:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:13:28 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:13:28 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:13:28 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:13:28 --> Model Class Initialized
DEBUG - 2016-08-31 01:13:28 --> Model Class Initialized
DEBUG - 2016-08-31 01:13:28 --> Model Class Initialized
DEBUG - 2016-08-31 01:13:28 --> Model Class Initialized
DEBUG - 2016-08-31 01:13:28 --> Model Class Initialized
DEBUG - 2016-08-31 01:13:28 --> Model Class Initialized
DEBUG - 2016-08-31 01:13:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 01:13:28 --> Pagination Class Initialized
DEBUG - 2016-08-31 01:13:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:13:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-31 01:13:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:13:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:13:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:13:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:13:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 01:13:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:13:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:13:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:13:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:13:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:13:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:13:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 01:13:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:13:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:13:28 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6ab6771ae9d42e25effdc2b45133f90d
DEBUG - 2016-08-31 01:13:28 --> Final output sent to browser
DEBUG - 2016-08-31 01:13:28 --> Total execution time: 1.0599
DEBUG - 2016-08-31 01:13:30 --> Config Class Initialized
DEBUG - 2016-08-31 01:13:30 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:13:30 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:13:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:13:30 --> URI Class Initialized
DEBUG - 2016-08-31 01:13:30 --> Router Class Initialized
DEBUG - 2016-08-31 01:13:30 --> Output Class Initialized
DEBUG - 2016-08-31 01:13:30 --> Security Class Initialized
DEBUG - 2016-08-31 01:13:30 --> Input Class Initialized
DEBUG - 2016-08-31 01:13:30 --> XSS Filtering completed
DEBUG - 2016-08-31 01:13:30 --> XSS Filtering completed
DEBUG - 2016-08-31 01:13:30 --> XSS Filtering completed
DEBUG - 2016-08-31 01:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:13:30 --> Language Class Initialized
DEBUG - 2016-08-31 01:13:30 --> Loader Class Initialized
DEBUG - 2016-08-31 01:13:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:13:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:13:30 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:13:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:13:30 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:13:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:13:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:13:30 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:13:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:13:30 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:13:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:13:30 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:13:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:13:30 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:13:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:13:30 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:13:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:13:30 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:13:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:13:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:13:30 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:13:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:13:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:13:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:13:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:13:30 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:13:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:13:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:13:30 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:13:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:13:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:13:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:13:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:13:30 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:13:30 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:13:30 --> Session Class Initialized
DEBUG - 2016-08-31 01:13:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:13:30 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:13:30 --> Session routines successfully run
DEBUG - 2016-08-31 01:13:30 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:13:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:13:31 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:13:31 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:13:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:13:31 --> Controller Class Initialized
DEBUG - 2016-08-31 01:13:31 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:13:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:13:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:13:31 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:13:31 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:13:31 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:13:31 --> Model Class Initialized
DEBUG - 2016-08-31 01:13:31 --> Model Class Initialized
DEBUG - 2016-08-31 01:13:31 --> Model Class Initialized
DEBUG - 2016-08-31 01:13:31 --> Model Class Initialized
DEBUG - 2016-08-31 01:13:31 --> Model Class Initialized
DEBUG - 2016-08-31 01:13:31 --> Model Class Initialized
DEBUG - 2016-08-31 01:13:31 --> Model Class Initialized
DEBUG - 2016-08-31 01:13:31 --> Model Class Initialized
DEBUG - 2016-08-31 01:13:31 --> Model Class Initialized
DEBUG - 2016-08-31 01:13:31 --> Model Class Initialized
ERROR - 2016-08-31 01:13:31 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:177) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-08-31 01:17:33 --> Config Class Initialized
DEBUG - 2016-08-31 01:17:33 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:17:33 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:17:33 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:17:33 --> URI Class Initialized
DEBUG - 2016-08-31 01:17:33 --> Router Class Initialized
DEBUG - 2016-08-31 01:17:33 --> Output Class Initialized
DEBUG - 2016-08-31 01:17:33 --> Security Class Initialized
DEBUG - 2016-08-31 01:17:33 --> Input Class Initialized
DEBUG - 2016-08-31 01:17:33 --> XSS Filtering completed
DEBUG - 2016-08-31 01:17:33 --> XSS Filtering completed
DEBUG - 2016-08-31 01:17:33 --> XSS Filtering completed
DEBUG - 2016-08-31 01:17:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:17:33 --> Language Class Initialized
DEBUG - 2016-08-31 01:17:33 --> Loader Class Initialized
DEBUG - 2016-08-31 01:17:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:17:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:17:33 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:17:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:17:33 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:17:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:17:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:17:33 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:17:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:17:33 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:17:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:17:33 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:17:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:17:33 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:17:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:17:33 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:17:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:17:33 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:17:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:17:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:17:33 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:17:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:17:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:17:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:17:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:17:33 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:17:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:17:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:17:33 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:17:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:17:33 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:17:33 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:17:33 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:17:33 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:17:33 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:17:34 --> Session Class Initialized
DEBUG - 2016-08-31 01:17:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:17:34 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:17:34 --> Session routines successfully run
DEBUG - 2016-08-31 01:17:34 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:17:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:17:34 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:17:34 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:17:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:17:34 --> Controller Class Initialized
DEBUG - 2016-08-31 01:17:34 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:17:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:17:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:17:34 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:17:34 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:17:34 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:17:34 --> Model Class Initialized
DEBUG - 2016-08-31 01:17:34 --> Model Class Initialized
DEBUG - 2016-08-31 01:17:34 --> Model Class Initialized
DEBUG - 2016-08-31 01:17:34 --> Model Class Initialized
DEBUG - 2016-08-31 01:17:34 --> Model Class Initialized
DEBUG - 2016-08-31 01:17:34 --> Model Class Initialized
DEBUG - 2016-08-31 01:17:34 --> Model Class Initialized
DEBUG - 2016-08-31 01:17:34 --> Model Class Initialized
DEBUG - 2016-08-31 01:17:34 --> Model Class Initialized
DEBUG - 2016-08-31 01:17:34 --> Model Class Initialized
ERROR - 2016-08-31 01:17:34 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:177) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-08-31 01:18:03 --> Config Class Initialized
DEBUG - 2016-08-31 01:18:03 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:18:03 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:18:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:18:03 --> URI Class Initialized
DEBUG - 2016-08-31 01:18:03 --> Router Class Initialized
DEBUG - 2016-08-31 01:18:03 --> Output Class Initialized
DEBUG - 2016-08-31 01:18:03 --> Security Class Initialized
DEBUG - 2016-08-31 01:18:03 --> Input Class Initialized
DEBUG - 2016-08-31 01:18:03 --> XSS Filtering completed
DEBUG - 2016-08-31 01:18:03 --> XSS Filtering completed
DEBUG - 2016-08-31 01:18:03 --> XSS Filtering completed
DEBUG - 2016-08-31 01:18:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:18:03 --> Language Class Initialized
DEBUG - 2016-08-31 01:18:03 --> Loader Class Initialized
DEBUG - 2016-08-31 01:18:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:18:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:18:03 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:18:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:18:03 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:18:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:18:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:18:03 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:18:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:18:03 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:18:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:18:03 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:18:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:18:03 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:18:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:18:03 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:18:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:18:03 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:18:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:18:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:18:03 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:18:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:18:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:18:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:18:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:18:03 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:18:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:18:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:18:03 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:18:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:18:03 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:18:03 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:18:03 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:18:03 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:18:04 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:18:04 --> Session Class Initialized
DEBUG - 2016-08-31 01:18:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:18:04 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:18:04 --> Session routines successfully run
DEBUG - 2016-08-31 01:18:04 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:18:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:18:04 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:18:04 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:18:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:18:04 --> Controller Class Initialized
DEBUG - 2016-08-31 01:18:04 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:18:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:18:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:18:04 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:18:04 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:18:04 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:18:04 --> Model Class Initialized
DEBUG - 2016-08-31 01:18:04 --> Model Class Initialized
DEBUG - 2016-08-31 01:18:04 --> Model Class Initialized
DEBUG - 2016-08-31 01:18:04 --> Model Class Initialized
DEBUG - 2016-08-31 01:18:04 --> Model Class Initialized
DEBUG - 2016-08-31 01:18:04 --> Model Class Initialized
DEBUG - 2016-08-31 01:18:04 --> Model Class Initialized
DEBUG - 2016-08-31 01:18:04 --> Model Class Initialized
DEBUG - 2016-08-31 01:18:04 --> Model Class Initialized
DEBUG - 2016-08-31 01:18:04 --> Model Class Initialized
ERROR - 2016-08-31 01:18:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:177) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-08-31 01:40:51 --> Config Class Initialized
DEBUG - 2016-08-31 01:40:51 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:40:51 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:40:51 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:40:51 --> URI Class Initialized
DEBUG - 2016-08-31 01:40:51 --> Router Class Initialized
DEBUG - 2016-08-31 01:40:51 --> No URI present. Default controller set.
DEBUG - 2016-08-31 01:40:51 --> Output Class Initialized
DEBUG - 2016-08-31 01:40:51 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 01:40:51 --> Security Class Initialized
DEBUG - 2016-08-31 01:40:51 --> Input Class Initialized
DEBUG - 2016-08-31 01:40:51 --> XSS Filtering completed
DEBUG - 2016-08-31 01:40:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:40:51 --> Language Class Initialized
DEBUG - 2016-08-31 01:40:51 --> Loader Class Initialized
DEBUG - 2016-08-31 01:40:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:40:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:40:51 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:40:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:40:51 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:40:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:40:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:40:51 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:40:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:40:51 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:40:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:40:51 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:40:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:40:51 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:40:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:40:51 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:40:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:40:51 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:40:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:40:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:40:51 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:40:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:40:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:40:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:40:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:40:51 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:40:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:40:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:40:51 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:40:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:40:51 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:40:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:40:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:40:51 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:40:51 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:40:51 --> Session Class Initialized
DEBUG - 2016-08-31 01:40:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:40:51 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:40:51 --> Session routines successfully run
DEBUG - 2016-08-31 01:40:51 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:40:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:40:51 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:40:51 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:40:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:40:51 --> Controller Class Initialized
DEBUG - 2016-08-31 01:40:51 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:40:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:40:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:40:51 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:40:52 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:40:52 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:40:52 --> Model Class Initialized
DEBUG - 2016-08-31 01:40:52 --> Model Class Initialized
DEBUG - 2016-08-31 01:40:52 --> Model Class Initialized
DEBUG - 2016-08-31 01:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-08-31 01:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:40:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-08-31 01:40:52 --> Final output sent to browser
DEBUG - 2016-08-31 01:40:52 --> Total execution time: 0.9911
DEBUG - 2016-08-31 01:40:55 --> Config Class Initialized
DEBUG - 2016-08-31 01:40:55 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:40:55 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:40:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:40:55 --> URI Class Initialized
DEBUG - 2016-08-31 01:40:55 --> Router Class Initialized
DEBUG - 2016-08-31 01:40:55 --> Output Class Initialized
DEBUG - 2016-08-31 01:40:55 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 01:40:55 --> Security Class Initialized
DEBUG - 2016-08-31 01:40:55 --> Input Class Initialized
DEBUG - 2016-08-31 01:40:55 --> XSS Filtering completed
DEBUG - 2016-08-31 01:40:55 --> XSS Filtering completed
DEBUG - 2016-08-31 01:40:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:40:55 --> Language Class Initialized
DEBUG - 2016-08-31 01:40:55 --> Loader Class Initialized
DEBUG - 2016-08-31 01:40:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:40:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:40:55 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:40:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:40:55 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:40:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:40:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:40:55 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:40:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:40:56 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:40:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:40:56 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:40:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:40:56 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:40:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:40:56 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:40:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:40:56 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:40:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:40:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:40:56 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:40:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:40:56 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:40:56 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:40:56 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:40:56 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:40:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:40:56 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:40:56 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:40:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:40:56 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:40:56 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:40:56 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:40:56 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:40:56 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:40:56 --> Session Class Initialized
DEBUG - 2016-08-31 01:40:56 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:40:56 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:40:56 --> Session routines successfully run
DEBUG - 2016-08-31 01:40:56 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:40:56 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:40:56 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:40:56 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:40:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:40:56 --> Controller Class Initialized
DEBUG - 2016-08-31 01:40:56 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:40:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:40:56 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:40:56 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:40:56 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:40:56 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:40:56 --> Model Class Initialized
DEBUG - 2016-08-31 01:40:56 --> Model Class Initialized
DEBUG - 2016-08-31 01:40:56 --> Model Class Initialized
DEBUG - 2016-08-31 01:40:56 --> Model Class Initialized
DEBUG - 2016-08-31 01:40:56 --> Model Class Initialized
DEBUG - 2016-08-31 01:40:56 --> Model Class Initialized
DEBUG - 2016-08-31 01:40:56 --> Model Class Initialized
DEBUG - 2016-08-31 01:40:56 --> Model Class Initialized
DEBUG - 2016-08-31 01:40:56 --> Model Class Initialized
ERROR - 2016-08-31 01:40:56 --> Hak Akses modul/kontroller 'cdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-08-31 01:40:56 --> Config Class Initialized
DEBUG - 2016-08-31 01:40:56 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:40:56 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:40:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:40:56 --> URI Class Initialized
DEBUG - 2016-08-31 01:40:56 --> Router Class Initialized
DEBUG - 2016-08-31 01:40:56 --> Output Class Initialized
DEBUG - 2016-08-31 01:40:56 --> Security Class Initialized
DEBUG - 2016-08-31 01:40:56 --> Input Class Initialized
DEBUG - 2016-08-31 01:40:56 --> XSS Filtering completed
DEBUG - 2016-08-31 01:40:56 --> XSS Filtering completed
DEBUG - 2016-08-31 01:40:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:40:56 --> Language Class Initialized
DEBUG - 2016-08-31 01:40:57 --> Loader Class Initialized
DEBUG - 2016-08-31 01:40:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:40:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:40:57 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:40:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:40:57 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:40:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:40:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:40:57 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:40:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:40:57 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:40:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:40:57 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:40:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:40:57 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:40:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:40:57 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:40:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:40:57 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:40:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:40:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:40:57 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:40:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:40:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:40:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:40:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:40:57 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:40:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:40:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:40:57 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:40:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:40:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:40:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:40:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:40:57 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:40:57 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:40:57 --> Session Class Initialized
DEBUG - 2016-08-31 01:40:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:40:57 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:40:57 --> Session routines successfully run
DEBUG - 2016-08-31 01:40:57 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:40:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:40:57 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:40:57 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:40:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:40:57 --> Controller Class Initialized
DEBUG - 2016-08-31 01:40:57 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:40:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:40:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:40:57 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:40:57 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:40:57 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:40:57 --> Model Class Initialized
DEBUG - 2016-08-31 01:40:57 --> Model Class Initialized
DEBUG - 2016-08-31 01:40:57 --> Model Class Initialized
DEBUG - 2016-08-31 01:40:57 --> Model Class Initialized
DEBUG - 2016-08-31 01:40:58 --> Model Class Initialized
DEBUG - 2016-08-31 01:40:58 --> Model Class Initialized
DEBUG - 2016-08-31 01:40:58 --> Model Class Initialized
DEBUG - 2016-08-31 01:40:58 --> Model Class Initialized
ERROR - 2016-08-31 01:40:58 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-08-31 01:40:58 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-08-31 01:40:58 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-08-31 01:40:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-08-31 01:40:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-08-31 01:40:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-08-31 01:40:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-08-31 01:40:58 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-08-31 01:40:58 --> Final output sent to browser
DEBUG - 2016-08-31 01:40:58 --> Total execution time: 1.3360
DEBUG - 2016-08-31 01:40:58 --> Config Class Initialized
DEBUG - 2016-08-31 01:40:58 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:40:58 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:40:58 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:40:58 --> URI Class Initialized
DEBUG - 2016-08-31 01:40:58 --> Router Class Initialized
ERROR - 2016-08-31 01:40:58 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-08-31 01:41:05 --> Config Class Initialized
DEBUG - 2016-08-31 01:41:05 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:41:05 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:41:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:41:05 --> URI Class Initialized
DEBUG - 2016-08-31 01:41:05 --> Router Class Initialized
DEBUG - 2016-08-31 01:41:05 --> Output Class Initialized
DEBUG - 2016-08-31 01:41:05 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 01:41:05 --> Security Class Initialized
DEBUG - 2016-08-31 01:41:05 --> Input Class Initialized
DEBUG - 2016-08-31 01:41:05 --> XSS Filtering completed
DEBUG - 2016-08-31 01:41:05 --> XSS Filtering completed
DEBUG - 2016-08-31 01:41:05 --> XSS Filtering completed
DEBUG - 2016-08-31 01:41:05 --> XSS Filtering completed
DEBUG - 2016-08-31 01:41:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:41:05 --> Language Class Initialized
DEBUG - 2016-08-31 01:41:05 --> Loader Class Initialized
DEBUG - 2016-08-31 01:41:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:41:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:41:05 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:41:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:41:05 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:41:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:41:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:41:05 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:41:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:41:05 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:41:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:41:05 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:41:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:41:06 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:41:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:41:06 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:41:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:41:06 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:41:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:41:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:41:06 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:41:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:41:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:41:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:41:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:41:06 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:41:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:41:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:41:06 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:41:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:41:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:41:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:41:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:41:06 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:41:06 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:41:06 --> Session Class Initialized
DEBUG - 2016-08-31 01:41:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:41:06 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:41:06 --> Session routines successfully run
DEBUG - 2016-08-31 01:41:06 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:41:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:41:06 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:41:06 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:41:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:41:06 --> Controller Class Initialized
DEBUG - 2016-08-31 01:41:06 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:41:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:41:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:41:06 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:41:06 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:41:06 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:41:06 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:06 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:06 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:06 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:06 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:06 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:06 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:06 --> Model Class Initialized
ERROR - 2016-08-31 01:41:06 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-08-31 01:41:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 01:41:06 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:41:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:41:06 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-08-31 01:41:06 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-08-31 01:41:06 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-08-31 01:41:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-08-31 01:41:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-08-31 01:41:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-08-31 01:41:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-08-31 01:41:06 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-08-31 01:41:07 --> Final output sent to browser
DEBUG - 2016-08-31 01:41:07 --> Total execution time: 1.3207
DEBUG - 2016-08-31 01:41:18 --> Config Class Initialized
DEBUG - 2016-08-31 01:41:18 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:41:18 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:41:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:41:18 --> URI Class Initialized
DEBUG - 2016-08-31 01:41:18 --> Router Class Initialized
DEBUG - 2016-08-31 01:41:18 --> Output Class Initialized
DEBUG - 2016-08-31 01:41:18 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 01:41:18 --> Security Class Initialized
DEBUG - 2016-08-31 01:41:18 --> Input Class Initialized
DEBUG - 2016-08-31 01:41:18 --> XSS Filtering completed
DEBUG - 2016-08-31 01:41:18 --> XSS Filtering completed
DEBUG - 2016-08-31 01:41:18 --> XSS Filtering completed
DEBUG - 2016-08-31 01:41:18 --> XSS Filtering completed
DEBUG - 2016-08-31 01:41:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:41:18 --> Language Class Initialized
DEBUG - 2016-08-31 01:41:18 --> Loader Class Initialized
DEBUG - 2016-08-31 01:41:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:41:18 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:41:18 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:41:18 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:41:18 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:41:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:41:18 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:41:18 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:41:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:41:18 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:41:18 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:41:18 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:41:18 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:41:18 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:41:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:41:19 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:41:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:41:19 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:41:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:41:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:41:19 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:41:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:41:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:41:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:41:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:41:19 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:41:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:41:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:41:19 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:41:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:41:19 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:41:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:41:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:41:19 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:41:19 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:41:19 --> Session Class Initialized
DEBUG - 2016-08-31 01:41:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:41:19 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:41:19 --> Session routines successfully run
DEBUG - 2016-08-31 01:41:19 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:41:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:41:19 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:41:19 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:41:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:41:19 --> Controller Class Initialized
DEBUG - 2016-08-31 01:41:19 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:41:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:41:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:41:19 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:41:19 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:41:19 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:41:19 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:19 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:19 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:19 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:19 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:19 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:19 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:19 --> Model Class Initialized
ERROR - 2016-08-31 01:41:19 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-08-31 01:41:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 01:41:19 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:41:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:41:19 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-08-31 01:41:19 --> Config Class Initialized
DEBUG - 2016-08-31 01:41:19 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:41:19 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:41:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:41:19 --> URI Class Initialized
DEBUG - 2016-08-31 01:41:19 --> Router Class Initialized
DEBUG - 2016-08-31 01:41:19 --> Output Class Initialized
DEBUG - 2016-08-31 01:41:19 --> Security Class Initialized
DEBUG - 2016-08-31 01:41:19 --> Input Class Initialized
DEBUG - 2016-08-31 01:41:19 --> XSS Filtering completed
DEBUG - 2016-08-31 01:41:19 --> XSS Filtering completed
DEBUG - 2016-08-31 01:41:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:41:20 --> Language Class Initialized
DEBUG - 2016-08-31 01:41:20 --> Loader Class Initialized
DEBUG - 2016-08-31 01:41:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:41:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:41:20 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:41:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:41:20 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:41:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:41:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:41:20 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:41:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:41:20 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:41:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:41:20 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:41:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:41:20 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:41:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:41:20 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:41:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:41:20 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:41:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:41:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:41:20 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:41:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:41:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:41:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:41:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:41:20 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:41:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:41:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:41:20 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:41:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:41:20 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:41:20 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:41:20 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:41:20 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:41:20 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:41:20 --> Session Class Initialized
DEBUG - 2016-08-31 01:41:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:41:20 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:41:20 --> Session routines successfully run
DEBUG - 2016-08-31 01:41:20 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:41:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:41:20 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:41:20 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:41:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:41:20 --> Controller Class Initialized
DEBUG - 2016-08-31 01:41:20 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:41:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:41:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:41:20 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:41:20 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:41:20 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:41:20 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:20 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:20 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:20 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:20 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:20 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:20 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:20 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:21 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 01:41:21 --> Pagination Class Initialized
DEBUG - 2016-08-31 01:41:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:41:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-31 01:41:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:41:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:41:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:41:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:41:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 01:41:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:41:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:41:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:41:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:41:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:41:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:41:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 01:41:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:41:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:41:21 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-31 01:41:21 --> Final output sent to browser
DEBUG - 2016-08-31 01:41:21 --> Total execution time: 1.2701
DEBUG - 2016-08-31 01:41:48 --> Config Class Initialized
DEBUG - 2016-08-31 01:41:48 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:41:48 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:41:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:41:48 --> URI Class Initialized
DEBUG - 2016-08-31 01:41:48 --> Router Class Initialized
DEBUG - 2016-08-31 01:41:48 --> Output Class Initialized
DEBUG - 2016-08-31 01:41:48 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 01:41:48 --> Security Class Initialized
DEBUG - 2016-08-31 01:41:48 --> Input Class Initialized
DEBUG - 2016-08-31 01:41:48 --> XSS Filtering completed
DEBUG - 2016-08-31 01:41:48 --> XSS Filtering completed
DEBUG - 2016-08-31 01:41:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:41:48 --> Language Class Initialized
DEBUG - 2016-08-31 01:41:48 --> Loader Class Initialized
DEBUG - 2016-08-31 01:41:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:41:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:41:48 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:41:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:41:48 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:41:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:41:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:41:48 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:41:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:41:48 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:41:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:41:48 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:41:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:41:48 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:41:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:41:48 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:41:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:41:48 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:41:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:41:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:41:48 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:41:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:41:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:41:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:41:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:41:48 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:41:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:41:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:41:48 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:41:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:41:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:41:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:41:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:41:48 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:41:48 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:41:49 --> Session Class Initialized
DEBUG - 2016-08-31 01:41:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:41:49 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:41:49 --> Session routines successfully run
DEBUG - 2016-08-31 01:41:49 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:41:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:41:49 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:41:49 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:41:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:41:49 --> Controller Class Initialized
DEBUG - 2016-08-31 01:41:49 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:41:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:41:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:41:49 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:41:49 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:41:49 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:41:49 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:49 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:49 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:49 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:49 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:49 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:49 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:49 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:49 --> Model Class Initialized
DEBUG - 2016-08-31 01:41:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 01:41:49 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:41:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:41:49 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:41:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-08-31 01:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-08-31 01:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-08-31 01:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-08-31 01:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-08-31 01:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-08-31 01:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:41:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:41:50 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8f8e2926e3f1cbfc3aa536b43cdd0626
DEBUG - 2016-08-31 01:41:50 --> Final output sent to browser
DEBUG - 2016-08-31 01:41:50 --> Total execution time: 1.2894
DEBUG - 2016-08-31 01:42:34 --> Config Class Initialized
DEBUG - 2016-08-31 01:42:34 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:42:34 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:42:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:42:34 --> URI Class Initialized
DEBUG - 2016-08-31 01:42:34 --> Router Class Initialized
DEBUG - 2016-08-31 01:42:34 --> Output Class Initialized
DEBUG - 2016-08-31 01:42:34 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 01:42:34 --> Security Class Initialized
DEBUG - 2016-08-31 01:42:34 --> Input Class Initialized
DEBUG - 2016-08-31 01:42:34 --> XSS Filtering completed
DEBUG - 2016-08-31 01:42:34 --> XSS Filtering completed
DEBUG - 2016-08-31 01:42:34 --> XSS Filtering completed
DEBUG - 2016-08-31 01:42:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:42:34 --> Language Class Initialized
DEBUG - 2016-08-31 01:42:34 --> Loader Class Initialized
DEBUG - 2016-08-31 01:42:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:42:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:42:34 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:42:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:42:34 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:42:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:42:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:42:34 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:42:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:42:34 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:42:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:42:34 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:42:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:42:34 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:42:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:42:34 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:42:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:42:34 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:42:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:42:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:42:34 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:42:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:42:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:42:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:42:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:42:35 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:42:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:42:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:42:35 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:42:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:42:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:42:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:42:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:42:35 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:42:35 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:42:35 --> Session Class Initialized
DEBUG - 2016-08-31 01:42:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:42:35 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:42:35 --> Session routines successfully run
DEBUG - 2016-08-31 01:42:35 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:42:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:42:35 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:42:35 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:42:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:42:35 --> Controller Class Initialized
DEBUG - 2016-08-31 01:42:35 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:42:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:42:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:42:35 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:42:35 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:42:35 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:42:35 --> Model Class Initialized
DEBUG - 2016-08-31 01:42:35 --> Model Class Initialized
DEBUG - 2016-08-31 01:42:35 --> Model Class Initialized
DEBUG - 2016-08-31 01:42:35 --> Model Class Initialized
DEBUG - 2016-08-31 01:42:35 --> Model Class Initialized
DEBUG - 2016-08-31 01:42:35 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5b757aabce4b284c04cf4ac1cfc7451e
DEBUG - 2016-08-31 01:42:35 --> Final output sent to browser
DEBUG - 2016-08-31 01:42:35 --> Total execution time: 1.2355
DEBUG - 2016-08-31 01:43:04 --> Config Class Initialized
DEBUG - 2016-08-31 01:43:04 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:43:04 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:43:04 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:43:04 --> URI Class Initialized
DEBUG - 2016-08-31 01:43:04 --> Router Class Initialized
DEBUG - 2016-08-31 01:43:04 --> Output Class Initialized
DEBUG - 2016-08-31 01:43:04 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 01:43:04 --> Security Class Initialized
DEBUG - 2016-08-31 01:43:04 --> Input Class Initialized
DEBUG - 2016-08-31 01:43:04 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:04 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:04 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:04 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:04 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:04 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:04 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:04 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:04 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:04 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:04 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:04 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:04 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:04 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:04 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:04 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:04 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:04 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:04 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:04 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:04 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:05 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:05 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:43:05 --> Language Class Initialized
DEBUG - 2016-08-31 01:43:05 --> Loader Class Initialized
DEBUG - 2016-08-31 01:43:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:43:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:43:05 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:43:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:43:05 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:43:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:43:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:43:05 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:43:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:43:05 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:43:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:43:05 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:43:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:43:05 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:43:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:43:05 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:43:05 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:43:05 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:43:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:43:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:43:05 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:43:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:43:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:43:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:43:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:43:05 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:43:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:43:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:43:05 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:43:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:43:05 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:43:05 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:43:05 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:43:05 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:43:05 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:43:05 --> Session Class Initialized
DEBUG - 2016-08-31 01:43:05 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:43:05 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:43:05 --> Session routines successfully run
DEBUG - 2016-08-31 01:43:05 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:43:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:43:05 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:43:05 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:43:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:43:05 --> Controller Class Initialized
DEBUG - 2016-08-31 01:43:05 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:43:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:43:05 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:43:05 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:43:05 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:43:05 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:43:05 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:05 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:05 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:05 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:06 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:06 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:06 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:06 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:06 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 01:43:06 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:43:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:43:06 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-08-31 01:43:06 --> Unable to find validation rule: 
DEBUG - 2016-08-31 01:43:06 --> Unable to find validation rule: 
DEBUG - 2016-08-31 01:43:06 --> Unable to find validation rule: 
DEBUG - 2016-08-31 01:43:06 --> Unable to find validation rule: 
DEBUG - 2016-08-31 01:43:06 --> Config Class Initialized
DEBUG - 2016-08-31 01:43:06 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:43:06 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:43:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:43:06 --> URI Class Initialized
DEBUG - 2016-08-31 01:43:06 --> Router Class Initialized
DEBUG - 2016-08-31 01:43:06 --> Output Class Initialized
DEBUG - 2016-08-31 01:43:06 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 01:43:06 --> Security Class Initialized
DEBUG - 2016-08-31 01:43:06 --> Input Class Initialized
DEBUG - 2016-08-31 01:43:06 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:06 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:43:06 --> Language Class Initialized
DEBUG - 2016-08-31 01:43:06 --> Loader Class Initialized
DEBUG - 2016-08-31 01:43:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:43:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:43:06 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:43:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:43:06 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:43:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:43:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:43:06 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:43:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:43:06 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:43:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:43:06 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:43:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:43:06 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:43:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:43:06 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:43:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:43:06 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:43:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:43:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:43:06 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:43:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:43:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:43:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:43:07 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:43:07 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:43:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:43:07 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:43:07 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:43:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:43:07 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:43:07 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:43:07 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:43:07 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:43:07 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:43:07 --> Session Class Initialized
DEBUG - 2016-08-31 01:43:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:43:07 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:43:07 --> Session routines successfully run
DEBUG - 2016-08-31 01:43:07 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:43:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:43:07 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:43:07 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:43:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:43:07 --> Controller Class Initialized
DEBUG - 2016-08-31 01:43:07 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:43:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:43:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:43:07 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:43:07 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:43:07 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:43:07 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:07 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:07 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:07 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:07 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:07 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:07 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:07 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:07 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 01:43:07 --> Pagination Class Initialized
DEBUG - 2016-08-31 01:43:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:43:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-31 01:43:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:43:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:43:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:43:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:43:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 01:43:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:43:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:43:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:43:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:43:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:43:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:43:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 01:43:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:43:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:43:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-31 01:43:07 --> Final output sent to browser
DEBUG - 2016-08-31 01:43:07 --> Total execution time: 1.3102
DEBUG - 2016-08-31 01:43:08 --> Config Class Initialized
DEBUG - 2016-08-31 01:43:08 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:43:08 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:43:08 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:43:08 --> URI Class Initialized
DEBUG - 2016-08-31 01:43:08 --> Router Class Initialized
DEBUG - 2016-08-31 01:43:08 --> Output Class Initialized
DEBUG - 2016-08-31 01:43:08 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 01:43:08 --> Security Class Initialized
DEBUG - 2016-08-31 01:43:08 --> Input Class Initialized
DEBUG - 2016-08-31 01:43:08 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:08 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:43:08 --> Language Class Initialized
DEBUG - 2016-08-31 01:43:08 --> Loader Class Initialized
DEBUG - 2016-08-31 01:43:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:43:08 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:43:08 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:43:08 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:43:08 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:43:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:43:08 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:43:08 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:43:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:43:08 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:43:08 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:43:08 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:43:08 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:43:08 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:43:08 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:43:08 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:43:08 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:43:08 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:43:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:43:08 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:43:08 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:43:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:43:08 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:43:08 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:43:08 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:43:08 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:43:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:43:08 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:43:08 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:43:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:43:08 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:43:08 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:43:08 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:43:08 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:43:08 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:43:08 --> Session Class Initialized
DEBUG - 2016-08-31 01:43:08 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:43:08 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:43:09 --> Session routines successfully run
DEBUG - 2016-08-31 01:43:09 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:43:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:43:09 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:43:09 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:43:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:43:09 --> Controller Class Initialized
DEBUG - 2016-08-31 01:43:09 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:43:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:43:09 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:43:09 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:43:09 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:43:09 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:43:09 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:09 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:09 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:09 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:09 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:09 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:09 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:09 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:09 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 01:43:09 --> Pagination Class Initialized
DEBUG - 2016-08-31 01:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-31 01:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 01:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 01:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:43:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:43:09 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-31 01:43:09 --> Final output sent to browser
DEBUG - 2016-08-31 01:43:09 --> Total execution time: 1.4515
DEBUG - 2016-08-31 01:43:13 --> Config Class Initialized
DEBUG - 2016-08-31 01:43:13 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:43:13 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:43:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:43:13 --> URI Class Initialized
DEBUG - 2016-08-31 01:43:13 --> Router Class Initialized
DEBUG - 2016-08-31 01:43:13 --> Output Class Initialized
DEBUG - 2016-08-31 01:43:13 --> Security Class Initialized
DEBUG - 2016-08-31 01:43:13 --> Input Class Initialized
DEBUG - 2016-08-31 01:43:13 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:13 --> XSS Filtering completed
DEBUG - 2016-08-31 01:43:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:43:14 --> Language Class Initialized
DEBUG - 2016-08-31 01:43:14 --> Loader Class Initialized
DEBUG - 2016-08-31 01:43:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:43:14 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:43:14 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:43:14 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:43:14 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:43:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:43:14 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:43:14 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:43:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:43:14 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:43:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:43:14 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:43:14 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:43:14 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:43:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:43:14 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:43:14 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:43:14 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:43:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:43:14 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:43:14 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:43:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:43:14 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:43:14 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:43:14 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:43:14 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:43:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:43:14 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:43:14 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:43:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:43:14 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:43:14 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:43:14 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:43:14 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:43:14 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:43:14 --> Session Class Initialized
DEBUG - 2016-08-31 01:43:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:43:15 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:43:15 --> Session routines successfully run
DEBUG - 2016-08-31 01:43:15 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:43:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:43:15 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:43:15 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:43:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:43:15 --> Controller Class Initialized
DEBUG - 2016-08-31 01:43:15 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:43:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:43:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:43:15 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:43:15 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:43:15 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:43:15 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:15 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:15 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:15 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:15 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:15 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:15 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:15 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:15 --> Model Class Initialized
DEBUG - 2016-08-31 01:43:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 01:43:15 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:43:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:43:15 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-08-31 01:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-08-31 01:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-08-31 01:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-08-31 01:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-08-31 01:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:43:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:43:16 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6d7eff342f0f035dc15289997d4c901c
DEBUG - 2016-08-31 01:43:16 --> Final output sent to browser
DEBUG - 2016-08-31 01:43:16 --> Total execution time: 1.9841
DEBUG - 2016-08-31 01:50:44 --> Config Class Initialized
DEBUG - 2016-08-31 01:50:44 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:50:44 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:50:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:50:44 --> URI Class Initialized
DEBUG - 2016-08-31 01:50:44 --> Router Class Initialized
DEBUG - 2016-08-31 01:50:44 --> Output Class Initialized
DEBUG - 2016-08-31 01:50:44 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 01:50:44 --> Security Class Initialized
DEBUG - 2016-08-31 01:50:44 --> Input Class Initialized
DEBUG - 2016-08-31 01:50:44 --> XSS Filtering completed
DEBUG - 2016-08-31 01:50:44 --> XSS Filtering completed
DEBUG - 2016-08-31 01:50:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:50:44 --> Language Class Initialized
DEBUG - 2016-08-31 01:50:44 --> Loader Class Initialized
DEBUG - 2016-08-31 01:50:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:50:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:50:44 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:50:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:50:45 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:50:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:50:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:50:45 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:50:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:50:45 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:50:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:50:45 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:50:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:50:45 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:50:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:50:45 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:50:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:50:45 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:50:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:50:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:50:45 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:50:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:50:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:50:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:50:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:50:45 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:50:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:50:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:50:45 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:50:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:50:45 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:50:45 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:50:45 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:50:45 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:50:45 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:50:45 --> Session Class Initialized
DEBUG - 2016-08-31 01:50:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:50:45 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:50:45 --> Session routines successfully run
DEBUG - 2016-08-31 01:50:45 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:50:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:50:45 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:50:45 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:50:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:50:45 --> Controller Class Initialized
DEBUG - 2016-08-31 01:50:45 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:50:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:50:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:50:45 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:50:45 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:50:45 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:50:45 --> Model Class Initialized
DEBUG - 2016-08-31 01:50:45 --> Model Class Initialized
DEBUG - 2016-08-31 01:50:45 --> Model Class Initialized
DEBUG - 2016-08-31 01:50:45 --> Model Class Initialized
DEBUG - 2016-08-31 01:50:45 --> Model Class Initialized
DEBUG - 2016-08-31 01:50:45 --> Model Class Initialized
DEBUG - 2016-08-31 01:50:45 --> Model Class Initialized
DEBUG - 2016-08-31 01:50:45 --> Model Class Initialized
DEBUG - 2016-08-31 01:50:45 --> Model Class Initialized
DEBUG - 2016-08-31 01:50:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 01:50:46 --> Pagination Class Initialized
DEBUG - 2016-08-31 01:50:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:50:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-31 01:50:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:50:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:50:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:50:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:50:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 01:50:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:50:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:50:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:50:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:50:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:50:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:50:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 01:50:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:50:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:50:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/6ab8b0e8914e7f77c92d629ba6bdd93f
DEBUG - 2016-08-31 01:50:46 --> Final output sent to browser
DEBUG - 2016-08-31 01:50:46 --> Total execution time: 1.4630
DEBUG - 2016-08-31 01:50:48 --> Config Class Initialized
DEBUG - 2016-08-31 01:50:48 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:50:48 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:50:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:50:48 --> URI Class Initialized
DEBUG - 2016-08-31 01:50:48 --> Router Class Initialized
DEBUG - 2016-08-31 01:50:48 --> Output Class Initialized
DEBUG - 2016-08-31 01:50:48 --> Security Class Initialized
DEBUG - 2016-08-31 01:50:48 --> Input Class Initialized
DEBUG - 2016-08-31 01:50:48 --> XSS Filtering completed
DEBUG - 2016-08-31 01:50:48 --> XSS Filtering completed
DEBUG - 2016-08-31 01:50:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:50:48 --> Language Class Initialized
DEBUG - 2016-08-31 01:50:48 --> Loader Class Initialized
DEBUG - 2016-08-31 01:50:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:50:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:50:48 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:50:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:50:48 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:50:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:50:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:50:49 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:50:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:50:49 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:50:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:50:49 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:50:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:50:49 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:50:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:50:49 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:50:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:50:49 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:50:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:50:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:50:49 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:50:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:50:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:50:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:50:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:50:49 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:50:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:50:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:50:49 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:50:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:50:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:50:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:50:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:50:49 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:50:49 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:50:49 --> Session Class Initialized
DEBUG - 2016-08-31 01:50:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:50:49 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:50:49 --> Session routines successfully run
DEBUG - 2016-08-31 01:50:49 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:50:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:50:49 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:50:49 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:50:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:50:49 --> Controller Class Initialized
DEBUG - 2016-08-31 01:50:49 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:50:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:50:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:50:49 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:50:49 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:50:49 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:50:49 --> Model Class Initialized
DEBUG - 2016-08-31 01:50:49 --> Model Class Initialized
DEBUG - 2016-08-31 01:50:49 --> Model Class Initialized
DEBUG - 2016-08-31 01:50:49 --> Model Class Initialized
DEBUG - 2016-08-31 01:50:49 --> Model Class Initialized
DEBUG - 2016-08-31 01:50:49 --> Model Class Initialized
DEBUG - 2016-08-31 01:50:49 --> Model Class Initialized
DEBUG - 2016-08-31 01:50:49 --> Model Class Initialized
DEBUG - 2016-08-31 01:50:49 --> Model Class Initialized
DEBUG - 2016-08-31 01:52:56 --> Config Class Initialized
DEBUG - 2016-08-31 01:52:56 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:52:56 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:52:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:52:56 --> URI Class Initialized
DEBUG - 2016-08-31 01:52:56 --> Router Class Initialized
DEBUG - 2016-08-31 01:52:56 --> Output Class Initialized
DEBUG - 2016-08-31 01:52:56 --> Security Class Initialized
DEBUG - 2016-08-31 01:52:56 --> Input Class Initialized
DEBUG - 2016-08-31 01:52:56 --> XSS Filtering completed
DEBUG - 2016-08-31 01:52:57 --> XSS Filtering completed
DEBUG - 2016-08-31 01:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:52:57 --> Language Class Initialized
DEBUG - 2016-08-31 01:52:57 --> Loader Class Initialized
DEBUG - 2016-08-31 01:52:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:52:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:52:57 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:52:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:52:57 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:52:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:52:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:52:57 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:52:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:52:57 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:52:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:52:57 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:52:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:52:57 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:52:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:52:57 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:52:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:52:57 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:52:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:52:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:52:57 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:52:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:52:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:52:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:52:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:52:57 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:52:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:52:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:52:57 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:52:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:52:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:52:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:52:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:52:57 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:52:57 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:52:57 --> Session Class Initialized
DEBUG - 2016-08-31 01:52:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:52:57 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:52:57 --> Session routines successfully run
DEBUG - 2016-08-31 01:52:57 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:52:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:52:57 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:52:57 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:52:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:52:57 --> Controller Class Initialized
DEBUG - 2016-08-31 01:52:57 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:52:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:52:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:52:57 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:52:57 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:52:57 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:52:58 --> Model Class Initialized
DEBUG - 2016-08-31 01:52:58 --> Model Class Initialized
DEBUG - 2016-08-31 01:52:58 --> Model Class Initialized
DEBUG - 2016-08-31 01:52:58 --> Model Class Initialized
DEBUG - 2016-08-31 01:52:58 --> Model Class Initialized
DEBUG - 2016-08-31 01:52:58 --> Model Class Initialized
DEBUG - 2016-08-31 01:52:58 --> Model Class Initialized
DEBUG - 2016-08-31 01:52:58 --> Model Class Initialized
DEBUG - 2016-08-31 01:52:58 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:13 --> Config Class Initialized
DEBUG - 2016-08-31 01:53:13 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:53:13 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:53:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:53:13 --> URI Class Initialized
DEBUG - 2016-08-31 01:53:13 --> Router Class Initialized
DEBUG - 2016-08-31 01:53:13 --> Output Class Initialized
DEBUG - 2016-08-31 01:53:13 --> Security Class Initialized
DEBUG - 2016-08-31 01:53:13 --> Input Class Initialized
DEBUG - 2016-08-31 01:53:13 --> XSS Filtering completed
DEBUG - 2016-08-31 01:53:13 --> XSS Filtering completed
DEBUG - 2016-08-31 01:53:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:53:13 --> Language Class Initialized
DEBUG - 2016-08-31 01:53:13 --> Loader Class Initialized
DEBUG - 2016-08-31 01:53:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:53:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:53:13 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:53:13 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:53:13 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:53:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:53:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:53:13 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:53:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:53:13 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:53:13 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:53:13 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:53:13 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:53:13 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:53:13 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:53:13 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:53:13 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:53:13 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:53:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:53:13 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:53:13 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:53:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:53:13 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:53:14 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:53:14 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:53:14 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:53:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:53:14 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:53:14 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:53:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:53:14 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:53:14 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:53:14 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:53:14 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:53:14 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:53:14 --> Session Class Initialized
DEBUG - 2016-08-31 01:53:14 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:53:14 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:53:14 --> Session routines successfully run
DEBUG - 2016-08-31 01:53:14 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:53:14 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:53:14 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:53:14 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:53:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:53:14 --> Controller Class Initialized
DEBUG - 2016-08-31 01:53:14 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:53:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:53:14 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:53:14 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:53:14 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:53:14 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:53:14 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:14 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:14 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:14 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:14 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:14 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:14 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:14 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:14 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 01:53:14 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:53:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:53:14 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-08-31 01:53:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:53:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-08-31 01:53:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:53:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-08-31 01:53:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:53:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-08-31 01:53:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:53:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-08-31 01:53:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:53:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:53:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:53:15 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8f8e2926e3f1cbfc3aa536b43cdd0626
DEBUG - 2016-08-31 01:53:15 --> Final output sent to browser
DEBUG - 2016-08-31 01:53:15 --> Total execution time: 1.4659
DEBUG - 2016-08-31 01:53:18 --> Config Class Initialized
DEBUG - 2016-08-31 01:53:18 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:53:18 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:53:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:53:18 --> URI Class Initialized
DEBUG - 2016-08-31 01:53:18 --> Router Class Initialized
DEBUG - 2016-08-31 01:53:18 --> Output Class Initialized
DEBUG - 2016-08-31 01:53:19 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 01:53:19 --> Security Class Initialized
DEBUG - 2016-08-31 01:53:19 --> Input Class Initialized
DEBUG - 2016-08-31 01:53:19 --> XSS Filtering completed
DEBUG - 2016-08-31 01:53:19 --> XSS Filtering completed
DEBUG - 2016-08-31 01:53:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:53:19 --> Language Class Initialized
DEBUG - 2016-08-31 01:53:19 --> Loader Class Initialized
DEBUG - 2016-08-31 01:53:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:53:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:53:19 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:53:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:53:19 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:53:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:53:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:53:19 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:53:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:53:19 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:53:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:53:19 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:53:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:53:19 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:53:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:53:19 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:53:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:53:19 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:53:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:53:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:53:19 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:53:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:53:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:53:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:53:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:53:19 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:53:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:53:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:53:19 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:53:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:53:19 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:53:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:53:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:53:19 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:53:19 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:53:19 --> Session Class Initialized
DEBUG - 2016-08-31 01:53:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:53:19 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:53:19 --> Session routines successfully run
DEBUG - 2016-08-31 01:53:19 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:53:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:53:19 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:53:19 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:53:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:53:20 --> Controller Class Initialized
DEBUG - 2016-08-31 01:53:20 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:53:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:53:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:53:20 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:53:20 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:53:20 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:53:20 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:20 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:20 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:20 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:20 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:20 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:20 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:20 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:20 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 01:53:20 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:53:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:53:20 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:53:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:53:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:53:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:53:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:53:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-08-31 01:53:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-08-31 01:53:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-08-31 01:53:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-08-31 01:53:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-08-31 01:53:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-08-31 01:53:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:53:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:53:21 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8f8e2926e3f1cbfc3aa536b43cdd0626
DEBUG - 2016-08-31 01:53:21 --> Final output sent to browser
DEBUG - 2016-08-31 01:53:21 --> Total execution time: 1.5364
DEBUG - 2016-08-31 01:53:54 --> Config Class Initialized
DEBUG - 2016-08-31 01:53:54 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:53:54 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:53:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:53:54 --> URI Class Initialized
DEBUG - 2016-08-31 01:53:54 --> Router Class Initialized
DEBUG - 2016-08-31 01:53:54 --> Output Class Initialized
DEBUG - 2016-08-31 01:53:54 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 01:53:55 --> Security Class Initialized
DEBUG - 2016-08-31 01:53:55 --> Input Class Initialized
DEBUG - 2016-08-31 01:53:55 --> XSS Filtering completed
DEBUG - 2016-08-31 01:53:55 --> XSS Filtering completed
DEBUG - 2016-08-31 01:53:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:53:55 --> Language Class Initialized
DEBUG - 2016-08-31 01:53:55 --> Loader Class Initialized
DEBUG - 2016-08-31 01:53:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:53:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:53:55 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:53:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:53:55 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:53:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:53:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:53:55 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:53:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:53:55 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:53:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:53:55 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:53:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:53:55 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:53:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:53:55 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:53:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:53:55 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:53:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:53:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:53:55 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:53:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:53:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:53:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:53:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:53:55 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:53:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:53:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:53:55 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:53:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:53:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:53:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:53:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:53:55 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:53:55 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:53:55 --> Session Class Initialized
DEBUG - 2016-08-31 01:53:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:53:55 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:53:55 --> Session routines successfully run
DEBUG - 2016-08-31 01:53:55 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:53:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:53:55 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:53:55 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:53:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:53:55 --> Controller Class Initialized
DEBUG - 2016-08-31 01:53:56 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:53:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:53:56 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:53:56 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:53:56 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:53:56 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:53:56 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:56 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:56 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:56 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:56 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:56 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:56 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:56 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:56 --> Model Class Initialized
DEBUG - 2016-08-31 01:53:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 01:53:56 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:53:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:53:56 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:53:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:53:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:53:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:53:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-08-31 01:53:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-08-31 01:53:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-08-31 01:53:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-08-31 01:53:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-08-31 01:53:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-08-31 01:53:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:53:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:53:57 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8f8e2926e3f1cbfc3aa536b43cdd0626
DEBUG - 2016-08-31 01:53:57 --> Final output sent to browser
DEBUG - 2016-08-31 01:53:57 --> Total execution time: 1.5712
DEBUG - 2016-08-31 01:54:31 --> Config Class Initialized
DEBUG - 2016-08-31 01:54:31 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:54:31 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:54:31 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:54:31 --> URI Class Initialized
DEBUG - 2016-08-31 01:54:31 --> Router Class Initialized
DEBUG - 2016-08-31 01:54:31 --> Output Class Initialized
DEBUG - 2016-08-31 01:54:31 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 01:54:31 --> Security Class Initialized
DEBUG - 2016-08-31 01:54:31 --> Input Class Initialized
DEBUG - 2016-08-31 01:54:31 --> XSS Filtering completed
DEBUG - 2016-08-31 01:54:31 --> XSS Filtering completed
DEBUG - 2016-08-31 01:54:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:54:31 --> Language Class Initialized
DEBUG - 2016-08-31 01:54:31 --> Loader Class Initialized
DEBUG - 2016-08-31 01:54:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:54:31 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:54:31 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:54:31 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:54:31 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:54:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:54:31 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:54:31 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:54:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:54:32 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:54:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:54:32 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:54:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:54:32 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:54:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:54:32 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:54:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:54:32 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:54:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:54:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:54:32 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:54:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:54:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:54:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:54:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:54:32 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:54:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:54:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:54:32 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:54:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:54:32 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:54:32 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:54:32 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:54:32 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:54:32 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:54:32 --> Session Class Initialized
DEBUG - 2016-08-31 01:54:32 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:54:32 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:54:32 --> Session routines successfully run
DEBUG - 2016-08-31 01:54:32 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:54:32 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:54:32 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:54:32 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:54:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:54:32 --> Controller Class Initialized
DEBUG - 2016-08-31 01:54:32 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:54:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:54:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:54:32 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:54:32 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:54:32 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:54:32 --> Model Class Initialized
DEBUG - 2016-08-31 01:54:32 --> Model Class Initialized
DEBUG - 2016-08-31 01:54:32 --> Model Class Initialized
DEBUG - 2016-08-31 01:54:32 --> Model Class Initialized
DEBUG - 2016-08-31 01:54:32 --> Model Class Initialized
DEBUG - 2016-08-31 01:54:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 01:54:33 --> Pagination Class Initialized
DEBUG - 2016-08-31 01:54:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:54:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/index.php
DEBUG - 2016-08-31 01:54:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:54:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:54:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:54:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:54:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-08-31 01:54:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:54:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:54:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:54:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:54:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:54:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:54:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-08-31 01:54:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:54:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:54:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/860bebf57fee032e24acce1c64d1c3e7
DEBUG - 2016-08-31 01:54:33 --> Final output sent to browser
DEBUG - 2016-08-31 01:54:33 --> Total execution time: 1.4964
DEBUG - 2016-08-31 01:54:34 --> Config Class Initialized
DEBUG - 2016-08-31 01:54:34 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:54:34 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:54:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:54:34 --> URI Class Initialized
DEBUG - 2016-08-31 01:54:34 --> Router Class Initialized
DEBUG - 2016-08-31 01:54:34 --> Output Class Initialized
DEBUG - 2016-08-31 01:54:34 --> Security Class Initialized
DEBUG - 2016-08-31 01:54:34 --> Input Class Initialized
DEBUG - 2016-08-31 01:54:34 --> XSS Filtering completed
DEBUG - 2016-08-31 01:54:35 --> XSS Filtering completed
DEBUG - 2016-08-31 01:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:54:35 --> Language Class Initialized
DEBUG - 2016-08-31 01:54:35 --> Loader Class Initialized
DEBUG - 2016-08-31 01:54:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:54:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:54:35 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:54:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:54:35 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:54:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:54:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:54:35 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:54:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:54:35 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:54:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:54:35 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:54:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:54:35 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:54:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:54:35 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:54:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:54:35 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:54:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:54:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:54:35 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:54:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:54:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:54:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:54:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:54:35 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:54:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:54:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:54:35 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:54:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:54:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:54:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:54:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:54:35 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:54:35 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:54:35 --> Session Class Initialized
DEBUG - 2016-08-31 01:54:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:54:35 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:54:35 --> Session routines successfully run
DEBUG - 2016-08-31 01:54:35 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:54:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:54:35 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:54:35 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:54:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:54:36 --> Controller Class Initialized
DEBUG - 2016-08-31 01:54:36 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:54:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:54:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:54:36 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:54:36 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:54:36 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:54:36 --> Model Class Initialized
DEBUG - 2016-08-31 01:54:36 --> Model Class Initialized
DEBUG - 2016-08-31 01:54:36 --> Model Class Initialized
DEBUG - 2016-08-31 01:54:36 --> Model Class Initialized
DEBUG - 2016-08-31 01:54:36 --> Model Class Initialized
DEBUG - 2016-08-31 01:54:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:54:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/detail.php
DEBUG - 2016-08-31 01:54:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:54:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:54:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:54:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:54:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:54:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:54:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:54:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:54:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:54:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:54:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:54:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:54:36 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/49e4762d00d24f1c5533f9e9ce9c758c
DEBUG - 2016-08-31 01:54:36 --> Final output sent to browser
DEBUG - 2016-08-31 01:54:36 --> Total execution time: 1.4485
DEBUG - 2016-08-31 01:54:39 --> Config Class Initialized
DEBUG - 2016-08-31 01:54:39 --> Hooks Class Initialized
DEBUG - 2016-08-31 01:54:39 --> Utf8 Class Initialized
DEBUG - 2016-08-31 01:54:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 01:54:39 --> URI Class Initialized
DEBUG - 2016-08-31 01:54:39 --> Router Class Initialized
DEBUG - 2016-08-31 01:54:39 --> Output Class Initialized
DEBUG - 2016-08-31 01:54:39 --> Security Class Initialized
DEBUG - 2016-08-31 01:54:39 --> Input Class Initialized
DEBUG - 2016-08-31 01:54:39 --> XSS Filtering completed
DEBUG - 2016-08-31 01:54:39 --> XSS Filtering completed
DEBUG - 2016-08-31 01:54:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 01:54:39 --> Language Class Initialized
DEBUG - 2016-08-31 01:54:39 --> Loader Class Initialized
DEBUG - 2016-08-31 01:54:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 01:54:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 01:54:39 --> Helper loaded: url_helper
DEBUG - 2016-08-31 01:54:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 01:54:39 --> Helper loaded: file_helper
DEBUG - 2016-08-31 01:54:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:54:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 01:54:39 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 01:54:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 01:54:39 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 01:54:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 01:54:39 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:54:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 01:54:40 --> Helper loaded: common_helper
DEBUG - 2016-08-31 01:54:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 01:54:40 --> Helper loaded: form_helper
DEBUG - 2016-08-31 01:54:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 01:54:40 --> Helper loaded: security_helper
DEBUG - 2016-08-31 01:54:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:54:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 01:54:40 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 01:54:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 01:54:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 01:54:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 01:54:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 01:54:40 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 01:54:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:54:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 01:54:40 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 01:54:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 01:54:40 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 01:54:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 01:54:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 01:54:40 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 01:54:40 --> Database Driver Class Initialized
DEBUG - 2016-08-31 01:54:40 --> Session Class Initialized
DEBUG - 2016-08-31 01:54:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 01:54:40 --> Helper loaded: string_helper
DEBUG - 2016-08-31 01:54:40 --> Session routines successfully run
DEBUG - 2016-08-31 01:54:40 --> Native_session Class Initialized
DEBUG - 2016-08-31 01:54:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 01:54:40 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:54:40 --> Form Validation Class Initialized
DEBUG - 2016-08-31 01:54:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 01:54:40 --> Controller Class Initialized
DEBUG - 2016-08-31 01:54:40 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 01:54:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 01:54:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 01:54:40 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:54:40 --> Carabiner: library configured.
DEBUG - 2016-08-31 01:54:40 --> User Agent Class Initialized
DEBUG - 2016-08-31 01:54:40 --> Model Class Initialized
DEBUG - 2016-08-31 01:54:40 --> Model Class Initialized
DEBUG - 2016-08-31 01:54:40 --> Model Class Initialized
DEBUG - 2016-08-31 01:54:40 --> Model Class Initialized
DEBUG - 2016-08-31 01:54:40 --> Model Class Initialized
DEBUG - 2016-08-31 01:54:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 01:54:41 --> Pagination Class Initialized
DEBUG - 2016-08-31 01:54:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 01:54:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/index.php
DEBUG - 2016-08-31 01:54:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:54:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:54:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:54:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:54:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-08-31 01:54:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:54:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:54:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 01:54:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 01:54:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 01:54:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 01:54:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-08-31 01:54:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 01:54:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 01:54:41 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5c9979c69ddeb9692c5b81a32c379acc
DEBUG - 2016-08-31 01:54:41 --> Final output sent to browser
DEBUG - 2016-08-31 01:54:41 --> Total execution time: 1.5424
DEBUG - 2016-08-31 09:09:36 --> Config Class Initialized
DEBUG - 2016-08-31 09:09:36 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:09:36 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:09:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:09:36 --> URI Class Initialized
DEBUG - 2016-08-31 09:09:36 --> Router Class Initialized
DEBUG - 2016-08-31 09:09:36 --> No URI present. Default controller set.
DEBUG - 2016-08-31 09:09:36 --> Output Class Initialized
DEBUG - 2016-08-31 09:09:36 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 09:09:36 --> Security Class Initialized
DEBUG - 2016-08-31 09:09:36 --> Input Class Initialized
DEBUG - 2016-08-31 09:09:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:09:36 --> Language Class Initialized
DEBUG - 2016-08-31 09:09:36 --> Loader Class Initialized
DEBUG - 2016-08-31 09:09:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:09:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:09:37 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:09:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:09:37 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:09:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:09:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:09:37 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:09:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:09:37 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:09:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:09:37 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:09:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:09:37 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:09:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:09:37 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:09:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:09:37 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:09:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:09:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:09:37 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:09:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:09:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:09:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:09:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:09:37 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:09:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:09:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:09:37 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:09:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:09:37 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:09:37 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:09:37 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:09:37 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:09:37 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:09:37 --> Session Class Initialized
DEBUG - 2016-08-31 09:09:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:09:38 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:09:38 --> A session cookie was not found.
DEBUG - 2016-08-31 09:09:38 --> Session routines successfully run
DEBUG - 2016-08-31 09:09:38 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:09:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:09:38 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:09:38 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:09:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:09:38 --> Controller Class Initialized
DEBUG - 2016-08-31 09:09:38 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:09:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:09:38 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:09:38 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:09:38 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:09:38 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:09:38 --> Model Class Initialized
DEBUG - 2016-08-31 09:09:38 --> Model Class Initialized
DEBUG - 2016-08-31 09:09:38 --> Model Class Initialized
DEBUG - 2016-08-31 09:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-08-31 09:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 09:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 09:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 09:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 09:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 09:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 09:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 09:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 09:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 09:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 09:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 09:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 09:09:38 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-08-31 09:09:38 --> Final output sent to browser
DEBUG - 2016-08-31 09:09:38 --> Total execution time: 1.9108
DEBUG - 2016-08-31 09:10:40 --> Config Class Initialized
DEBUG - 2016-08-31 09:10:40 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:10:40 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:10:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:10:40 --> URI Class Initialized
DEBUG - 2016-08-31 09:10:40 --> Router Class Initialized
DEBUG - 2016-08-31 09:10:40 --> No URI present. Default controller set.
DEBUG - 2016-08-31 09:10:40 --> Output Class Initialized
DEBUG - 2016-08-31 09:10:40 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 09:10:40 --> Security Class Initialized
DEBUG - 2016-08-31 09:10:40 --> Input Class Initialized
DEBUG - 2016-08-31 09:10:40 --> XSS Filtering completed
DEBUG - 2016-08-31 09:10:40 --> XSS Filtering completed
DEBUG - 2016-08-31 09:10:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:10:40 --> Language Class Initialized
DEBUG - 2016-08-31 09:10:40 --> Loader Class Initialized
DEBUG - 2016-08-31 09:10:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:10:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:10:40 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:10:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:10:40 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:10:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:10:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:10:41 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:10:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:10:41 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:10:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:10:41 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:10:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:10:41 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:10:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:10:41 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:10:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:10:41 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:10:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:10:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:10:41 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:10:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:10:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:10:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:10:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:10:41 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:10:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:10:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:10:41 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:10:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:10:41 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:10:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:10:41 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:10:41 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:10:41 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:10:41 --> Session Class Initialized
DEBUG - 2016-08-31 09:10:41 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:10:41 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:10:41 --> Session routines successfully run
DEBUG - 2016-08-31 09:10:41 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:10:41 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:10:41 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:10:41 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:10:41 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:10:41 --> Controller Class Initialized
DEBUG - 2016-08-31 09:10:41 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:10:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:10:41 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:10:41 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:10:41 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:10:41 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:10:41 --> Model Class Initialized
DEBUG - 2016-08-31 09:10:41 --> Model Class Initialized
DEBUG - 2016-08-31 09:10:41 --> Model Class Initialized
DEBUG - 2016-08-31 09:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-08-31 09:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 09:10:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 09:10:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 09:10:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 09:10:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 09:10:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 09:10:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 09:10:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 09:10:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 09:10:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 09:10:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 09:10:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 09:10:42 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-08-31 09:10:42 --> Final output sent to browser
DEBUG - 2016-08-31 09:10:42 --> Total execution time: 1.5199
DEBUG - 2016-08-31 09:12:47 --> Config Class Initialized
DEBUG - 2016-08-31 09:12:47 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:12:47 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:12:47 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:12:47 --> URI Class Initialized
DEBUG - 2016-08-31 09:12:47 --> Router Class Initialized
DEBUG - 2016-08-31 09:12:47 --> No URI present. Default controller set.
DEBUG - 2016-08-31 09:12:47 --> Output Class Initialized
DEBUG - 2016-08-31 09:12:47 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 09:12:47 --> Security Class Initialized
DEBUG - 2016-08-31 09:12:47 --> Input Class Initialized
DEBUG - 2016-08-31 09:12:47 --> XSS Filtering completed
DEBUG - 2016-08-31 09:12:47 --> XSS Filtering completed
DEBUG - 2016-08-31 09:12:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:12:48 --> Language Class Initialized
DEBUG - 2016-08-31 09:12:48 --> Loader Class Initialized
DEBUG - 2016-08-31 09:12:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:12:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:12:48 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:12:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:12:48 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:12:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:12:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:12:48 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:12:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:12:48 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:12:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:12:48 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:12:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:12:48 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:12:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:12:48 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:12:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:12:48 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:12:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:12:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:12:48 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:12:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:12:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:12:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:12:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:12:48 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:12:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:12:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:12:48 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:12:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:12:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:12:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:12:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:12:48 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:12:48 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:12:48 --> Session Class Initialized
DEBUG - 2016-08-31 09:12:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:12:48 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:12:48 --> Session routines successfully run
DEBUG - 2016-08-31 09:12:48 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:12:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:12:48 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:12:48 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:12:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:12:48 --> Controller Class Initialized
DEBUG - 2016-08-31 09:12:48 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:12:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:12:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:12:49 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:12:49 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:12:49 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:12:49 --> Model Class Initialized
DEBUG - 2016-08-31 09:12:49 --> Model Class Initialized
DEBUG - 2016-08-31 09:12:49 --> Model Class Initialized
DEBUG - 2016-08-31 09:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-08-31 09:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 09:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 09:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 09:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 09:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 09:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 09:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 09:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 09:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 09:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 09:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 09:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 09:12:49 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-08-31 09:12:49 --> Final output sent to browser
DEBUG - 2016-08-31 09:12:49 --> Total execution time: 1.5418
DEBUG - 2016-08-31 09:12:53 --> Config Class Initialized
DEBUG - 2016-08-31 09:12:53 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:12:53 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:12:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:12:53 --> URI Class Initialized
DEBUG - 2016-08-31 09:12:53 --> Router Class Initialized
DEBUG - 2016-08-31 09:12:53 --> Output Class Initialized
DEBUG - 2016-08-31 09:12:53 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 09:12:53 --> Security Class Initialized
DEBUG - 2016-08-31 09:12:53 --> Input Class Initialized
DEBUG - 2016-08-31 09:12:53 --> XSS Filtering completed
DEBUG - 2016-08-31 09:12:53 --> XSS Filtering completed
DEBUG - 2016-08-31 09:12:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:12:53 --> Language Class Initialized
DEBUG - 2016-08-31 09:12:53 --> Loader Class Initialized
DEBUG - 2016-08-31 09:12:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:12:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:12:53 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:12:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:12:53 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:12:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:12:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:12:53 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:12:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:12:53 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:12:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:12:53 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:12:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:12:53 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:12:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:12:54 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:12:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:12:54 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:12:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:12:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:12:54 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:12:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:12:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:12:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:12:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:12:54 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:12:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:12:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:12:54 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:12:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:12:54 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:12:54 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:12:54 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:12:54 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:12:54 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:12:54 --> Session Class Initialized
DEBUG - 2016-08-31 09:12:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:12:54 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:12:54 --> Session routines successfully run
DEBUG - 2016-08-31 09:12:54 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:12:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:12:54 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:12:54 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:12:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:12:54 --> Controller Class Initialized
DEBUG - 2016-08-31 09:12:54 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:12:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:12:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:12:54 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:12:54 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:12:54 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:12:54 --> Model Class Initialized
DEBUG - 2016-08-31 09:12:54 --> Model Class Initialized
DEBUG - 2016-08-31 09:12:54 --> Model Class Initialized
DEBUG - 2016-08-31 09:12:54 --> Model Class Initialized
DEBUG - 2016-08-31 09:12:54 --> Model Class Initialized
DEBUG - 2016-08-31 09:12:54 --> Model Class Initialized
DEBUG - 2016-08-31 09:12:54 --> Model Class Initialized
DEBUG - 2016-08-31 09:12:55 --> Model Class Initialized
DEBUG - 2016-08-31 09:12:55 --> Model Class Initialized
ERROR - 2016-08-31 09:12:55 --> Hak Akses modul/kontroller 'cdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-08-31 09:12:55 --> Config Class Initialized
DEBUG - 2016-08-31 09:12:55 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:12:55 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:12:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:12:55 --> URI Class Initialized
DEBUG - 2016-08-31 09:12:55 --> Router Class Initialized
DEBUG - 2016-08-31 09:12:55 --> Output Class Initialized
DEBUG - 2016-08-31 09:12:55 --> Security Class Initialized
DEBUG - 2016-08-31 09:12:55 --> Input Class Initialized
DEBUG - 2016-08-31 09:12:55 --> XSS Filtering completed
DEBUG - 2016-08-31 09:12:55 --> XSS Filtering completed
DEBUG - 2016-08-31 09:12:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:12:55 --> Language Class Initialized
DEBUG - 2016-08-31 09:12:55 --> Loader Class Initialized
DEBUG - 2016-08-31 09:12:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:12:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:12:55 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:12:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:12:55 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:12:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:12:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:12:55 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:12:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:12:55 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:12:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:12:55 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:12:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:12:55 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:12:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:12:55 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:12:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:12:55 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:12:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:12:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:12:55 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:12:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:12:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:12:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:12:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:12:55 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:12:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:12:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:12:55 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:12:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:12:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:12:56 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:12:56 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:12:56 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:12:56 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:12:56 --> Session Class Initialized
DEBUG - 2016-08-31 09:12:56 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:12:56 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:12:56 --> Session routines successfully run
DEBUG - 2016-08-31 09:12:56 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:12:56 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:12:56 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:12:56 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:12:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:12:56 --> Controller Class Initialized
DEBUG - 2016-08-31 09:12:56 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:12:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:12:56 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:12:56 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:12:56 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:12:56 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:12:56 --> Model Class Initialized
DEBUG - 2016-08-31 09:12:56 --> Model Class Initialized
DEBUG - 2016-08-31 09:12:56 --> Model Class Initialized
DEBUG - 2016-08-31 09:12:56 --> Model Class Initialized
DEBUG - 2016-08-31 09:12:56 --> Model Class Initialized
DEBUG - 2016-08-31 09:12:56 --> Model Class Initialized
DEBUG - 2016-08-31 09:12:56 --> Model Class Initialized
DEBUG - 2016-08-31 09:12:56 --> Model Class Initialized
ERROR - 2016-08-31 09:12:56 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-08-31 09:12:56 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-08-31 09:12:56 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-08-31 09:12:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-08-31 09:12:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-08-31 09:12:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-08-31 09:12:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-08-31 09:12:56 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-08-31 09:12:56 --> Final output sent to browser
DEBUG - 2016-08-31 09:12:56 --> Total execution time: 1.5338
DEBUG - 2016-08-31 09:12:56 --> Config Class Initialized
DEBUG - 2016-08-31 09:12:56 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:12:56 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:12:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:12:57 --> URI Class Initialized
DEBUG - 2016-08-31 09:12:57 --> Router Class Initialized
ERROR - 2016-08-31 09:12:57 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-08-31 09:39:05 --> Config Class Initialized
DEBUG - 2016-08-31 09:39:05 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:39:05 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:39:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:39:05 --> URI Class Initialized
DEBUG - 2016-08-31 09:39:05 --> Router Class Initialized
DEBUG - 2016-08-31 09:39:05 --> No URI present. Default controller set.
DEBUG - 2016-08-31 09:39:05 --> Output Class Initialized
DEBUG - 2016-08-31 09:39:05 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 09:39:05 --> Security Class Initialized
DEBUG - 2016-08-31 09:39:05 --> Input Class Initialized
DEBUG - 2016-08-31 09:39:05 --> XSS Filtering completed
DEBUG - 2016-08-31 09:39:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:39:05 --> Language Class Initialized
DEBUG - 2016-08-31 09:39:06 --> Loader Class Initialized
DEBUG - 2016-08-31 09:39:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:39:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:39:06 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:39:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:39:06 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:39:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:39:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:39:06 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:39:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:39:06 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:39:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:39:06 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:39:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:39:06 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:39:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:39:06 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:39:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:39:06 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:39:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:39:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:39:06 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:39:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:39:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:39:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:39:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:39:06 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:39:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:39:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:39:06 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:39:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:39:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:39:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:39:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:39:06 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:39:07 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:39:07 --> Session Class Initialized
DEBUG - 2016-08-31 09:39:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:39:07 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:39:07 --> Session routines successfully run
DEBUG - 2016-08-31 09:39:07 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:39:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:39:07 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:39:07 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:39:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:39:07 --> Controller Class Initialized
DEBUG - 2016-08-31 09:39:07 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:39:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:39:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:39:07 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:39:07 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:39:07 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:39:07 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:07 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:07 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-08-31 09:39:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 09:39:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 09:39:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 09:39:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 09:39:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 09:39:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 09:39:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 09:39:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 09:39:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 09:39:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 09:39:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 09:39:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 09:39:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-08-31 09:39:07 --> Final output sent to browser
DEBUG - 2016-08-31 09:39:08 --> Total execution time: 1.8663
DEBUG - 2016-08-31 09:39:16 --> Config Class Initialized
DEBUG - 2016-08-31 09:39:16 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:39:16 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:39:16 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:39:16 --> URI Class Initialized
DEBUG - 2016-08-31 09:39:16 --> Router Class Initialized
DEBUG - 2016-08-31 09:39:16 --> Output Class Initialized
DEBUG - 2016-08-31 09:39:16 --> Security Class Initialized
DEBUG - 2016-08-31 09:39:16 --> Input Class Initialized
DEBUG - 2016-08-31 09:39:16 --> XSS Filtering completed
DEBUG - 2016-08-31 09:39:16 --> XSS Filtering completed
DEBUG - 2016-08-31 09:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:39:16 --> Language Class Initialized
DEBUG - 2016-08-31 09:39:16 --> Loader Class Initialized
DEBUG - 2016-08-31 09:39:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:39:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:39:16 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:39:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:39:16 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:39:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:39:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:39:16 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:39:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:39:16 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:39:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:39:16 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:39:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:39:16 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:39:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:39:16 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:39:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:39:16 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:39:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:39:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:39:16 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:39:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:39:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:39:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:39:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:39:16 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:39:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:39:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:39:16 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:39:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:39:16 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:39:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:39:17 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:39:17 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:39:17 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:39:17 --> Session Class Initialized
DEBUG - 2016-08-31 09:39:17 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:39:17 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:39:17 --> Session routines successfully run
DEBUG - 2016-08-31 09:39:17 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:39:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:39:17 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:39:17 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:39:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:39:17 --> Controller Class Initialized
DEBUG - 2016-08-31 09:39:17 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:39:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:39:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:39:17 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:39:17 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:39:17 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:39:17 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:17 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:17 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:17 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:17 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:17 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:17 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:17 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:17 --> Model Class Initialized
ERROR - 2016-08-31 09:39:17 --> Hak Akses modul/kontroller 'cdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-08-31 09:39:17 --> Config Class Initialized
DEBUG - 2016-08-31 09:39:17 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:39:17 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:39:17 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:39:17 --> URI Class Initialized
DEBUG - 2016-08-31 09:39:17 --> Router Class Initialized
DEBUG - 2016-08-31 09:39:17 --> Output Class Initialized
DEBUG - 2016-08-31 09:39:17 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 09:39:17 --> Security Class Initialized
DEBUG - 2016-08-31 09:39:17 --> Input Class Initialized
DEBUG - 2016-08-31 09:39:17 --> XSS Filtering completed
DEBUG - 2016-08-31 09:39:17 --> XSS Filtering completed
DEBUG - 2016-08-31 09:39:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:39:17 --> Language Class Initialized
DEBUG - 2016-08-31 09:39:17 --> Loader Class Initialized
DEBUG - 2016-08-31 09:39:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:39:18 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:39:18 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:39:18 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:39:18 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:39:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:39:18 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:39:18 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:39:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:39:18 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:39:18 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:39:18 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:39:18 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:39:18 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:39:18 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:39:18 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:39:18 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:39:18 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:39:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:39:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:39:18 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:39:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:39:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:39:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:39:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:39:18 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:39:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:39:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:39:18 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:39:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:39:18 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:39:18 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:39:18 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:39:18 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:39:18 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:39:18 --> Session Class Initialized
DEBUG - 2016-08-31 09:39:18 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:39:18 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:39:18 --> Session routines successfully run
DEBUG - 2016-08-31 09:39:18 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:39:18 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:39:18 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:39:18 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:39:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:39:18 --> Controller Class Initialized
DEBUG - 2016-08-31 09:39:18 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:39:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:39:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:39:19 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:39:19 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:39:19 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:39:19 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:19 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:19 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:19 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:19 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:19 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:19 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:19 --> Model Class Initialized
ERROR - 2016-08-31 09:39:19 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-08-31 09:39:19 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-08-31 09:39:19 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-08-31 09:39:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-08-31 09:39:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-08-31 09:39:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-08-31 09:39:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-08-31 09:39:19 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-08-31 09:39:19 --> Final output sent to browser
DEBUG - 2016-08-31 09:39:19 --> Total execution time: 1.6158
DEBUG - 2016-08-31 09:39:19 --> Config Class Initialized
DEBUG - 2016-08-31 09:39:19 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:39:19 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:39:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:39:19 --> URI Class Initialized
DEBUG - 2016-08-31 09:39:19 --> Router Class Initialized
ERROR - 2016-08-31 09:39:19 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-08-31 09:39:27 --> Config Class Initialized
DEBUG - 2016-08-31 09:39:28 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:39:28 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:39:28 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:39:28 --> URI Class Initialized
DEBUG - 2016-08-31 09:39:28 --> Router Class Initialized
DEBUG - 2016-08-31 09:39:28 --> Output Class Initialized
DEBUG - 2016-08-31 09:39:28 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 09:39:28 --> Security Class Initialized
DEBUG - 2016-08-31 09:39:28 --> Input Class Initialized
DEBUG - 2016-08-31 09:39:28 --> XSS Filtering completed
DEBUG - 2016-08-31 09:39:28 --> XSS Filtering completed
DEBUG - 2016-08-31 09:39:28 --> XSS Filtering completed
DEBUG - 2016-08-31 09:39:28 --> XSS Filtering completed
DEBUG - 2016-08-31 09:39:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:39:28 --> Language Class Initialized
DEBUG - 2016-08-31 09:39:28 --> Loader Class Initialized
DEBUG - 2016-08-31 09:39:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:39:28 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:39:28 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:39:28 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:39:28 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:39:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:39:28 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:39:28 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:39:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:39:28 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:39:28 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:39:28 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:39:28 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:39:28 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:39:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:39:28 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:39:28 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:39:28 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:39:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:39:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:39:28 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:39:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:39:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:39:28 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:39:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:39:28 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:39:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:39:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:39:29 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:39:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:39:29 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:39:29 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:39:29 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:39:29 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:39:29 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:39:29 --> Session Class Initialized
DEBUG - 2016-08-31 09:39:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:39:29 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:39:29 --> Session routines successfully run
DEBUG - 2016-08-31 09:39:29 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:39:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:39:29 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:39:29 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:39:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:39:29 --> Controller Class Initialized
DEBUG - 2016-08-31 09:39:29 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:39:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:39:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:39:29 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:39:29 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:39:29 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:39:29 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:29 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:29 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:29 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:29 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:29 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:29 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:29 --> Model Class Initialized
ERROR - 2016-08-31 09:39:29 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-08-31 09:39:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 09:39:29 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:39:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:39:29 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-08-31 09:39:29 --> Config Class Initialized
DEBUG - 2016-08-31 09:39:29 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:39:29 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:39:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:39:29 --> URI Class Initialized
DEBUG - 2016-08-31 09:39:30 --> Router Class Initialized
DEBUG - 2016-08-31 09:39:30 --> Output Class Initialized
DEBUG - 2016-08-31 09:39:30 --> Security Class Initialized
DEBUG - 2016-08-31 09:39:30 --> Input Class Initialized
DEBUG - 2016-08-31 09:39:30 --> XSS Filtering completed
DEBUG - 2016-08-31 09:39:30 --> XSS Filtering completed
DEBUG - 2016-08-31 09:39:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:39:30 --> Language Class Initialized
DEBUG - 2016-08-31 09:39:30 --> Loader Class Initialized
DEBUG - 2016-08-31 09:39:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:39:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:39:30 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:39:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:39:30 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:39:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:39:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:39:30 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:39:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:39:30 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:39:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:39:30 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:39:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:39:30 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:39:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:39:30 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:39:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:39:30 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:39:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:39:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:39:30 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:39:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:39:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:39:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:39:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:39:30 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:39:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:39:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:39:30 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:39:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:39:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:39:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:39:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:39:30 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:39:30 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:39:30 --> Session Class Initialized
DEBUG - 2016-08-31 09:39:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:39:30 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:39:31 --> Session routines successfully run
DEBUG - 2016-08-31 09:39:31 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:39:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:39:31 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:39:31 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:39:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:39:31 --> Controller Class Initialized
DEBUG - 2016-08-31 09:39:31 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:39:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:39:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:39:31 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:39:31 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:39:31 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:39:31 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:31 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:31 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:31 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:31 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:31 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:31 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:31 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:31 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 09:39:31 --> Pagination Class Initialized
DEBUG - 2016-08-31 09:39:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 09:39:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-31 09:39:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 09:39:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 09:39:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 09:39:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 09:39:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 09:39:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 09:39:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 09:39:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 09:39:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 09:39:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 09:39:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 09:39:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 09:39:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 09:39:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 09:39:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-31 09:39:31 --> Final output sent to browser
DEBUG - 2016-08-31 09:39:31 --> Total execution time: 1.6869
DEBUG - 2016-08-31 09:39:38 --> Config Class Initialized
DEBUG - 2016-08-31 09:39:38 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:39:38 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:39:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:39:38 --> URI Class Initialized
DEBUG - 2016-08-31 09:39:38 --> Router Class Initialized
DEBUG - 2016-08-31 09:39:38 --> Output Class Initialized
DEBUG - 2016-08-31 09:39:38 --> Security Class Initialized
DEBUG - 2016-08-31 09:39:38 --> Input Class Initialized
DEBUG - 2016-08-31 09:39:38 --> XSS Filtering completed
DEBUG - 2016-08-31 09:39:38 --> XSS Filtering completed
DEBUG - 2016-08-31 09:39:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:39:38 --> Language Class Initialized
DEBUG - 2016-08-31 09:39:38 --> Loader Class Initialized
DEBUG - 2016-08-31 09:39:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:39:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:39:39 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:39:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:39:39 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:39:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:39:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:39:39 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:39:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:39:39 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:39:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:39:39 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:39:39 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:39:39 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:39:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:39:39 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:39:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:39:39 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:39:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:39:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:39:39 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:39:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:39:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:39:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:39:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:39:39 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:39:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:39:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:39:39 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:39:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:39:39 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:39:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:39:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:39:39 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:39:39 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:39:39 --> Session Class Initialized
DEBUG - 2016-08-31 09:39:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:39:39 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:39:39 --> Session routines successfully run
DEBUG - 2016-08-31 09:39:39 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:39:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:39:39 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:39:39 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:39:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:39:39 --> Controller Class Initialized
DEBUG - 2016-08-31 09:39:39 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:39:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:39:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:39:40 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:39:40 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:39:40 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:39:40 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:40 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:40 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:40 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:40 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:40 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:40 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:40 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:40 --> Model Class Initialized
DEBUG - 2016-08-31 09:39:40 --> Model Class Initialized
ERROR - 2016-08-31 09:39:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:177) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-08-31 09:40:46 --> Config Class Initialized
DEBUG - 2016-08-31 09:40:46 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:40:46 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:40:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:40:46 --> URI Class Initialized
DEBUG - 2016-08-31 09:40:46 --> Router Class Initialized
DEBUG - 2016-08-31 09:40:46 --> Output Class Initialized
DEBUG - 2016-08-31 09:40:46 --> Security Class Initialized
DEBUG - 2016-08-31 09:40:46 --> Input Class Initialized
DEBUG - 2016-08-31 09:40:46 --> XSS Filtering completed
DEBUG - 2016-08-31 09:40:46 --> XSS Filtering completed
DEBUG - 2016-08-31 09:40:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:40:46 --> Language Class Initialized
DEBUG - 2016-08-31 09:40:46 --> Loader Class Initialized
DEBUG - 2016-08-31 09:40:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:40:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:40:46 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:40:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:40:46 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:40:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:40:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:40:46 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:40:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:40:46 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:40:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:40:46 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:40:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:40:46 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:40:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:40:46 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:40:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:40:46 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:40:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:40:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:40:47 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:40:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:40:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:40:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:40:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:40:47 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:40:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:40:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:40:47 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:40:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:40:47 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:40:47 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:40:47 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:40:47 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:40:47 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:40:47 --> Session Class Initialized
DEBUG - 2016-08-31 09:40:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:40:47 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:40:47 --> Session routines successfully run
DEBUG - 2016-08-31 09:40:47 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:40:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:40:47 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:40:47 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:40:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:40:47 --> Controller Class Initialized
DEBUG - 2016-08-31 09:40:47 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:40:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:40:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:40:47 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:40:47 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:40:47 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:40:47 --> Model Class Initialized
DEBUG - 2016-08-31 09:40:47 --> Model Class Initialized
DEBUG - 2016-08-31 09:40:47 --> Model Class Initialized
DEBUG - 2016-08-31 09:40:47 --> Model Class Initialized
DEBUG - 2016-08-31 09:40:47 --> Model Class Initialized
DEBUG - 2016-08-31 09:40:47 --> Model Class Initialized
DEBUG - 2016-08-31 09:40:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 09:40:47 --> Pagination Class Initialized
DEBUG - 2016-08-31 09:40:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 09:40:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-31 09:40:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 09:40:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 09:40:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 09:40:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 09:40:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 09:40:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 09:40:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 09:40:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 09:40:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 09:40:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 09:40:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 09:40:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 09:40:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 09:40:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 09:40:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/96f5e1b7885bda6c73eb3c0ea541f3b4
DEBUG - 2016-08-31 09:40:48 --> Final output sent to browser
DEBUG - 2016-08-31 09:40:48 --> Total execution time: 1.6234
DEBUG - 2016-08-31 09:40:50 --> Config Class Initialized
DEBUG - 2016-08-31 09:40:50 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:40:50 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:40:50 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:40:50 --> URI Class Initialized
DEBUG - 2016-08-31 09:40:51 --> Router Class Initialized
DEBUG - 2016-08-31 09:40:51 --> Output Class Initialized
DEBUG - 2016-08-31 09:40:51 --> Security Class Initialized
DEBUG - 2016-08-31 09:40:51 --> Input Class Initialized
DEBUG - 2016-08-31 09:40:51 --> XSS Filtering completed
DEBUG - 2016-08-31 09:40:51 --> XSS Filtering completed
DEBUG - 2016-08-31 09:40:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:40:51 --> Language Class Initialized
DEBUG - 2016-08-31 09:40:51 --> Loader Class Initialized
DEBUG - 2016-08-31 09:40:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:40:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:40:51 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:40:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:40:51 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:40:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:40:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:40:51 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:40:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:40:51 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:40:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:40:51 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:40:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:40:51 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:40:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:40:51 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:40:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:40:51 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:40:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:40:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:40:51 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:40:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:40:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:40:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:40:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:40:51 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:40:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:40:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:40:51 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:40:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:40:51 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:40:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:40:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:40:51 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:40:51 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:40:51 --> Session Class Initialized
DEBUG - 2016-08-31 09:40:52 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:40:52 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:40:52 --> Session routines successfully run
DEBUG - 2016-08-31 09:40:52 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:40:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:40:52 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:40:52 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:40:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:40:52 --> Controller Class Initialized
DEBUG - 2016-08-31 09:40:52 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:40:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:40:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:40:52 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:40:52 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:40:52 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:40:52 --> Model Class Initialized
DEBUG - 2016-08-31 09:40:52 --> Model Class Initialized
DEBUG - 2016-08-31 09:40:52 --> Model Class Initialized
DEBUG - 2016-08-31 09:40:52 --> Model Class Initialized
DEBUG - 2016-08-31 09:40:52 --> Model Class Initialized
DEBUG - 2016-08-31 09:40:52 --> Model Class Initialized
DEBUG - 2016-08-31 09:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 09:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/detail.php
DEBUG - 2016-08-31 09:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 09:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 09:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 09:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 09:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_js.php
DEBUG - 2016-08-31 09:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_isian_js.php
DEBUG - 2016-08-31 09:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 09:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 09:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 09:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 09:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 09:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 09:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_js.php
DEBUG - 2016-08-31 09:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_isian_js.php
DEBUG - 2016-08-31 09:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 09:40:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 09:40:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/27889419d5c256178a830aca2d659b22
DEBUG - 2016-08-31 09:40:52 --> Final output sent to browser
DEBUG - 2016-08-31 09:40:52 --> Total execution time: 1.5911
DEBUG - 2016-08-31 09:41:23 --> Config Class Initialized
DEBUG - 2016-08-31 09:41:23 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:41:23 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:41:23 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:41:23 --> URI Class Initialized
DEBUG - 2016-08-31 09:41:23 --> Router Class Initialized
DEBUG - 2016-08-31 09:41:23 --> Output Class Initialized
DEBUG - 2016-08-31 09:41:23 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 09:41:23 --> Security Class Initialized
DEBUG - 2016-08-31 09:41:23 --> Input Class Initialized
DEBUG - 2016-08-31 09:41:23 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:23 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:23 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:41:24 --> Language Class Initialized
DEBUG - 2016-08-31 09:41:24 --> Loader Class Initialized
DEBUG - 2016-08-31 09:41:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:41:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:41:24 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:41:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:41:24 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:41:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:41:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:41:24 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:41:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:41:24 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:41:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:41:24 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:41:24 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:41:24 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:41:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:41:24 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:41:24 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:41:24 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:41:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:41:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:41:24 --> Config Class Initialized
DEBUG - 2016-08-31 09:41:24 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:41:24 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:41:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:41:24 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:41:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:41:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:41:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:41:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:41:24 --> URI Class Initialized
DEBUG - 2016-08-31 09:41:24 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:41:24 --> Router Class Initialized
DEBUG - 2016-08-31 09:41:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:41:24 --> Output Class Initialized
DEBUG - 2016-08-31 09:41:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:41:24 --> Security Class Initialized
DEBUG - 2016-08-31 09:41:24 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:41:24 --> Input Class Initialized
DEBUG - 2016-08-31 09:41:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:41:24 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:24 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:41:24 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:24 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:41:24 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:41:24 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:41:24 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:41:24 --> Language Class Initialized
DEBUG - 2016-08-31 09:41:24 --> Loader Class Initialized
DEBUG - 2016-08-31 09:41:24 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:41:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:41:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:41:24 --> Session Class Initialized
DEBUG - 2016-08-31 09:41:24 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:41:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:41:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:41:24 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:41:24 --> Session routines successfully run
DEBUG - 2016-08-31 09:41:24 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:41:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:41:24 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:41:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:41:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:41:25 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:41:25 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:41:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:41:25 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:41:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:41:25 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:41:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:41:25 --> Controller Class Initialized
DEBUG - 2016-08-31 09:41:25 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:41:25 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:41:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:41:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:41:25 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:41:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:41:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:41:25 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:41:25 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:41:25 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:41:25 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:41:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:41:25 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:41:25 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:41:25 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:41:25 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:25 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:41:25 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:41:25 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:41:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:41:25 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b5e3eebbe550cd93afc20ddd83908c3b
DEBUG - 2016-08-31 09:41:25 --> Final output sent to browser
DEBUG - 2016-08-31 09:41:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:41:25 --> Total execution time: 1.8405
DEBUG - 2016-08-31 09:41:25 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:41:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:41:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:41:25 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:41:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:41:25 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:41:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:41:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:41:25 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:41:25 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:41:25 --> Session Class Initialized
DEBUG - 2016-08-31 09:41:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:41:25 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:41:25 --> Session routines successfully run
DEBUG - 2016-08-31 09:41:25 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:41:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:41:25 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:41:25 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:41:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:41:25 --> Controller Class Initialized
DEBUG - 2016-08-31 09:41:25 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:41:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:41:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:41:25 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:41:26 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:41:26 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:41:26 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:26 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:26 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:26 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:26 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:26 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b5e3eebbe550cd93afc20ddd83908c3b
DEBUG - 2016-08-31 09:41:26 --> Final output sent to browser
DEBUG - 2016-08-31 09:41:26 --> Total execution time: 1.6546
DEBUG - 2016-08-31 09:41:32 --> Config Class Initialized
DEBUG - 2016-08-31 09:41:32 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:41:32 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:41:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:41:32 --> URI Class Initialized
DEBUG - 2016-08-31 09:41:32 --> Router Class Initialized
DEBUG - 2016-08-31 09:41:32 --> Output Class Initialized
DEBUG - 2016-08-31 09:41:32 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 09:41:32 --> Security Class Initialized
DEBUG - 2016-08-31 09:41:32 --> Input Class Initialized
DEBUG - 2016-08-31 09:41:32 --> Config Class Initialized
DEBUG - 2016-08-31 09:41:32 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:32 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:41:32 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:32 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:41:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:41:32 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:41:32 --> URI Class Initialized
DEBUG - 2016-08-31 09:41:33 --> Language Class Initialized
DEBUG - 2016-08-31 09:41:33 --> Router Class Initialized
DEBUG - 2016-08-31 09:41:33 --> Output Class Initialized
DEBUG - 2016-08-31 09:41:33 --> Loader Class Initialized
DEBUG - 2016-08-31 09:41:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:41:33 --> Security Class Initialized
DEBUG - 2016-08-31 09:41:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:41:33 --> Input Class Initialized
DEBUG - 2016-08-31 09:41:33 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:33 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:41:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:41:33 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:33 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:33 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:41:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:41:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:41:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:41:33 --> Language Class Initialized
DEBUG - 2016-08-31 09:41:33 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:41:33 --> Loader Class Initialized
DEBUG - 2016-08-31 09:41:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:41:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:41:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:41:33 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:41:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:41:33 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:41:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:41:33 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:41:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:41:33 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:41:33 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:41:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:41:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:41:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:41:33 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:41:33 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:41:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:41:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:41:33 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:41:33 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:41:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:41:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:41:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:41:33 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:41:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:41:33 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:41:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:41:33 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:41:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:41:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:41:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:41:33 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:41:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:41:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:41:33 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:41:33 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:41:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:41:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:41:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:41:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:41:33 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:41:33 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:41:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:41:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:41:33 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:41:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:41:33 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:41:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:41:33 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:41:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:41:33 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:41:33 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:41:33 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:41:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:41:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:41:33 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:41:33 --> Session Class Initialized
DEBUG - 2016-08-31 09:41:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:41:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:41:33 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:41:33 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:41:33 --> Session routines successfully run
DEBUG - 2016-08-31 09:41:33 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:41:33 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:41:33 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:41:34 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:41:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:41:34 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:41:34 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:41:34 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:41:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:41:34 --> Controller Class Initialized
DEBUG - 2016-08-31 09:41:34 --> Session Class Initialized
DEBUG - 2016-08-31 09:41:34 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:41:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:41:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:41:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:41:34 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:41:34 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:41:34 --> Session routines successfully run
DEBUG - 2016-08-31 09:41:34 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:41:34 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:41:34 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:41:34 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:34 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:34 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:34 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:34 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1ae1cad65d2be9e2d395bd427adbef6f
DEBUG - 2016-08-31 09:41:34 --> Final output sent to browser
DEBUG - 2016-08-31 09:41:34 --> Total execution time: 1.8824
DEBUG - 2016-08-31 09:41:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:41:34 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:41:34 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:41:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:41:34 --> Controller Class Initialized
DEBUG - 2016-08-31 09:41:34 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:41:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:41:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:41:34 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:41:34 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:41:34 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:41:34 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:34 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:34 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:34 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:34 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1ae1cad65d2be9e2d395bd427adbef6f
DEBUG - 2016-08-31 09:41:34 --> Config Class Initialized
DEBUG - 2016-08-31 09:41:34 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:41:34 --> Final output sent to browser
DEBUG - 2016-08-31 09:41:34 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:41:34 --> Total execution time: 2.0644
DEBUG - 2016-08-31 09:41:35 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:41:35 --> URI Class Initialized
DEBUG - 2016-08-31 09:41:35 --> Router Class Initialized
DEBUG - 2016-08-31 09:41:35 --> Output Class Initialized
DEBUG - 2016-08-31 09:41:35 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 09:41:35 --> Security Class Initialized
DEBUG - 2016-08-31 09:41:35 --> Input Class Initialized
DEBUG - 2016-08-31 09:41:35 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:35 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:35 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:41:35 --> Language Class Initialized
DEBUG - 2016-08-31 09:41:35 --> Loader Class Initialized
DEBUG - 2016-08-31 09:41:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:41:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:41:35 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:41:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:41:35 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:41:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:41:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:41:35 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:41:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:41:35 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:41:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:41:35 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:41:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:41:35 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:41:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:41:35 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:41:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:41:35 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:41:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:41:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:41:35 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:41:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:41:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:41:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:41:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:41:35 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:41:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:41:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:41:35 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:41:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:41:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:41:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:41:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:41:36 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:41:36 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:41:36 --> Session Class Initialized
DEBUG - 2016-08-31 09:41:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:41:36 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:41:36 --> Session routines successfully run
DEBUG - 2016-08-31 09:41:36 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:41:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:41:36 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:41:36 --> Config Class Initialized
DEBUG - 2016-08-31 09:41:36 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:41:36 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:41:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:41:36 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:41:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:41:36 --> Controller Class Initialized
DEBUG - 2016-08-31 09:41:36 --> URI Class Initialized
DEBUG - 2016-08-31 09:41:36 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:41:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:41:36 --> Router Class Initialized
DEBUG - 2016-08-31 09:41:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:41:36 --> Output Class Initialized
DEBUG - 2016-08-31 09:41:36 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:41:36 --> Security Class Initialized
DEBUG - 2016-08-31 09:41:36 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:41:36 --> Input Class Initialized
DEBUG - 2016-08-31 09:41:36 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:36 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:41:36 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:36 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:36 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:36 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:41:36 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:36 --> Language Class Initialized
DEBUG - 2016-08-31 09:41:36 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:36 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:36 --> Loader Class Initialized
DEBUG - 2016-08-31 09:41:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:41:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:41:36 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1ae1cad65d2be9e2d395bd427adbef6f
DEBUG - 2016-08-31 09:41:36 --> Final output sent to browser
DEBUG - 2016-08-31 09:41:36 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:41:36 --> Total execution time: 1.7133
DEBUG - 2016-08-31 09:41:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:41:36 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:41:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:41:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:41:36 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:41:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:41:36 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:41:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:41:36 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:41:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:41:36 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:41:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:41:36 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:41:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:41:37 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:41:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:41:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:41:37 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:41:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:41:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:41:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:41:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:41:37 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:41:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:41:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:41:37 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:41:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:41:37 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:41:37 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:41:37 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:41:37 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:41:37 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:41:37 --> Session Class Initialized
DEBUG - 2016-08-31 09:41:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:41:37 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:41:37 --> Session routines successfully run
DEBUG - 2016-08-31 09:41:37 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:41:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:41:37 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:41:37 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:41:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:41:37 --> Controller Class Initialized
DEBUG - 2016-08-31 09:41:37 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:41:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:41:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:41:37 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:41:37 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:41:37 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:41:37 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:37 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:37 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:37 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:37 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1ae1cad65d2be9e2d395bd427adbef6f
DEBUG - 2016-08-31 09:41:37 --> Final output sent to browser
DEBUG - 2016-08-31 09:41:37 --> Config Class Initialized
DEBUG - 2016-08-31 09:41:38 --> Total execution time: 1.7046
DEBUG - 2016-08-31 09:41:38 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:41:38 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:41:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:41:38 --> URI Class Initialized
DEBUG - 2016-08-31 09:41:38 --> Router Class Initialized
DEBUG - 2016-08-31 09:41:38 --> Output Class Initialized
DEBUG - 2016-08-31 09:41:38 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 09:41:38 --> Security Class Initialized
DEBUG - 2016-08-31 09:41:38 --> Input Class Initialized
DEBUG - 2016-08-31 09:41:38 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:38 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:38 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:41:38 --> Language Class Initialized
DEBUG - 2016-08-31 09:41:38 --> Loader Class Initialized
DEBUG - 2016-08-31 09:41:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:41:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:41:38 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:41:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:41:38 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:41:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:41:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:41:38 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:41:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:41:38 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:41:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:41:38 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:41:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:41:38 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:41:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:41:38 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:41:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:41:38 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:41:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:41:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:41:38 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:41:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:41:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:41:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:41:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:41:38 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:41:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:41:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:41:39 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:41:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:41:39 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:41:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:41:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:41:39 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:41:39 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:41:39 --> Session Class Initialized
DEBUG - 2016-08-31 09:41:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:41:39 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:41:39 --> Session routines successfully run
DEBUG - 2016-08-31 09:41:39 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:41:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:41:39 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:41:39 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:41:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:41:39 --> Controller Class Initialized
DEBUG - 2016-08-31 09:41:39 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:41:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:41:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:41:39 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:41:39 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:41:39 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:41:39 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:39 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:39 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:39 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:39 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:39 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1ae1cad65d2be9e2d395bd427adbef6f
DEBUG - 2016-08-31 09:41:39 --> Final output sent to browser
DEBUG - 2016-08-31 09:41:39 --> Total execution time: 1.7447
DEBUG - 2016-08-31 09:41:40 --> Config Class Initialized
DEBUG - 2016-08-31 09:41:40 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:41:40 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:41:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:41:40 --> URI Class Initialized
DEBUG - 2016-08-31 09:41:40 --> Router Class Initialized
DEBUG - 2016-08-31 09:41:40 --> Output Class Initialized
DEBUG - 2016-08-31 09:41:40 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 09:41:40 --> Security Class Initialized
DEBUG - 2016-08-31 09:41:40 --> Input Class Initialized
DEBUG - 2016-08-31 09:41:40 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:40 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:40 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:41:40 --> Language Class Initialized
DEBUG - 2016-08-31 09:41:40 --> Loader Class Initialized
DEBUG - 2016-08-31 09:41:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:41:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:41:40 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:41:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:41:40 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:41:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:41:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:41:40 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:41:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:41:40 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:41:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:41:40 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:41:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:41:41 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:41:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:41:41 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:41:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:41:41 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:41:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:41:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:41:41 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:41:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:41:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:41:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:41:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:41:41 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:41:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:41:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:41:41 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:41:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:41:41 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:41:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:41:41 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:41:41 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:41:41 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:41:41 --> Session Class Initialized
DEBUG - 2016-08-31 09:41:41 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:41:41 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:41:41 --> Session routines successfully run
DEBUG - 2016-08-31 09:41:41 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:41:41 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:41:41 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:41:41 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:41:41 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:41:41 --> Controller Class Initialized
DEBUG - 2016-08-31 09:41:41 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:41:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:41:41 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:41:41 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:41:41 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:41:41 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:41:41 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:42 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:42 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:42 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:42 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:42 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1ae1cad65d2be9e2d395bd427adbef6f
DEBUG - 2016-08-31 09:41:42 --> Final output sent to browser
DEBUG - 2016-08-31 09:41:42 --> Total execution time: 1.8547
DEBUG - 2016-08-31 09:41:44 --> Config Class Initialized
DEBUG - 2016-08-31 09:41:44 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:41:44 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:41:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:41:45 --> URI Class Initialized
DEBUG - 2016-08-31 09:41:45 --> Router Class Initialized
DEBUG - 2016-08-31 09:41:45 --> Output Class Initialized
DEBUG - 2016-08-31 09:41:45 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 09:41:45 --> Security Class Initialized
DEBUG - 2016-08-31 09:41:45 --> Config Class Initialized
DEBUG - 2016-08-31 09:41:45 --> Input Class Initialized
DEBUG - 2016-08-31 09:41:45 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:41:45 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:45 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:45 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:41:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:41:45 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:41:45 --> URI Class Initialized
DEBUG - 2016-08-31 09:41:45 --> Language Class Initialized
DEBUG - 2016-08-31 09:41:45 --> Router Class Initialized
DEBUG - 2016-08-31 09:41:45 --> Loader Class Initialized
DEBUG - 2016-08-31 09:41:45 --> Output Class Initialized
DEBUG - 2016-08-31 09:41:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:41:45 --> Security Class Initialized
DEBUG - 2016-08-31 09:41:45 --> Input Class Initialized
DEBUG - 2016-08-31 09:41:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:41:45 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:45 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:41:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:41:45 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:45 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:45 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:41:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:41:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:41:45 --> Language Class Initialized
DEBUG - 2016-08-31 09:41:45 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:41:45 --> Loader Class Initialized
DEBUG - 2016-08-31 09:41:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:41:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:41:45 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:41:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:41:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:41:45 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:41:45 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:41:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:41:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:41:45 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:41:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:41:45 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:41:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:41:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:41:45 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:41:45 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:41:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:41:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:41:45 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:41:45 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:41:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:41:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:41:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:41:45 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:41:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:41:45 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:41:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:41:45 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:41:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:41:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:41:46 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:41:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:41:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:41:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:41:46 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:41:46 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:41:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:41:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:41:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:41:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:41:46 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:41:46 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:41:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:41:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:41:46 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:41:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:41:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:41:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:41:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:41:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:41:46 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:41:46 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:41:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:41:46 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:41:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:41:46 --> Session Class Initialized
DEBUG - 2016-08-31 09:41:46 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:41:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:41:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:41:46 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:41:46 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:41:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:41:46 --> Session routines successfully run
DEBUG - 2016-08-31 09:41:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:41:46 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:41:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:41:46 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:41:46 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:41:46 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:41:46 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:41:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:41:46 --> Controller Class Initialized
DEBUG - 2016-08-31 09:41:46 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:41:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:41:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:41:46 --> Session Class Initialized
DEBUG - 2016-08-31 09:41:46 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:41:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:41:46 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:41:46 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:41:46 --> Session routines successfully run
DEBUG - 2016-08-31 09:41:46 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:41:46 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:46 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:41:46 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:46 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:46 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:46 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1ae1cad65d2be9e2d395bd427adbef6f
DEBUG - 2016-08-31 09:41:46 --> Final output sent to browser
DEBUG - 2016-08-31 09:41:46 --> Total execution time: 1.9304
DEBUG - 2016-08-31 09:41:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:41:46 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:41:46 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:41:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:41:47 --> Controller Class Initialized
DEBUG - 2016-08-31 09:41:47 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:41:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:41:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:41:47 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:41:47 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:41:47 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:41:47 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:47 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:47 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:47 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:47 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1ae1cad65d2be9e2d395bd427adbef6f
DEBUG - 2016-08-31 09:41:47 --> Final output sent to browser
DEBUG - 2016-08-31 09:41:47 --> Total execution time: 2.1208
DEBUG - 2016-08-31 09:41:47 --> Config Class Initialized
DEBUG - 2016-08-31 09:41:47 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:41:47 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:41:47 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:41:47 --> URI Class Initialized
DEBUG - 2016-08-31 09:41:47 --> Router Class Initialized
DEBUG - 2016-08-31 09:41:47 --> Output Class Initialized
DEBUG - 2016-08-31 09:41:47 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 09:41:47 --> Security Class Initialized
DEBUG - 2016-08-31 09:41:47 --> Input Class Initialized
DEBUG - 2016-08-31 09:41:48 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:48 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:48 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:41:48 --> Language Class Initialized
DEBUG - 2016-08-31 09:41:48 --> Loader Class Initialized
DEBUG - 2016-08-31 09:41:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:41:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:41:48 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:41:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:41:48 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:41:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:41:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:41:48 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:41:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:41:48 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:41:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:41:48 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:41:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:41:48 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:41:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:41:48 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:41:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:41:48 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:41:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:41:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:41:48 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:41:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:41:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:41:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:41:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:41:48 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:41:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:41:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:41:48 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:41:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:41:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:41:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:41:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:41:48 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:41:48 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:41:49 --> Session Class Initialized
DEBUG - 2016-08-31 09:41:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:41:49 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:41:49 --> Session routines successfully run
DEBUG - 2016-08-31 09:41:49 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:41:49 --> Config Class Initialized
DEBUG - 2016-08-31 09:41:49 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:41:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:41:49 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:41:49 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:41:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:41:49 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:41:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:41:49 --> URI Class Initialized
DEBUG - 2016-08-31 09:41:49 --> Router Class Initialized
DEBUG - 2016-08-31 09:41:49 --> Controller Class Initialized
DEBUG - 2016-08-31 09:41:49 --> Output Class Initialized
DEBUG - 2016-08-31 09:41:49 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:41:49 --> Security Class Initialized
DEBUG - 2016-08-31 09:41:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:41:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:41:49 --> Input Class Initialized
DEBUG - 2016-08-31 09:41:49 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:41:49 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:49 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:41:49 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:49 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:49 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:41:49 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:49 --> Language Class Initialized
DEBUG - 2016-08-31 09:41:49 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:49 --> Loader Class Initialized
DEBUG - 2016-08-31 09:41:49 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:41:49 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:41:49 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:49 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:41:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:41:49 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1ae1cad65d2be9e2d395bd427adbef6f
DEBUG - 2016-08-31 09:41:49 --> Final output sent to browser
DEBUG - 2016-08-31 09:41:49 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:41:49 --> Total execution time: 1.9084
DEBUG - 2016-08-31 09:41:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:41:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:41:49 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:41:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:41:49 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:41:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:41:49 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:41:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:41:49 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:41:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:41:49 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:41:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:41:49 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:41:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:41:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:41:49 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:41:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:41:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:41:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:41:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:41:50 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:41:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:41:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:41:50 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:41:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:41:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:41:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:41:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:41:50 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:41:50 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:41:50 --> Session Class Initialized
DEBUG - 2016-08-31 09:41:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:41:50 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:41:50 --> Session routines successfully run
DEBUG - 2016-08-31 09:41:50 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:41:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:41:50 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:41:50 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:41:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:41:50 --> Controller Class Initialized
DEBUG - 2016-08-31 09:41:50 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:41:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:41:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:41:50 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:41:50 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:41:50 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:41:50 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:50 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:50 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:50 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:50 --> Model Class Initialized
DEBUG - 2016-08-31 09:41:50 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1ae1cad65d2be9e2d395bd427adbef6f
DEBUG - 2016-08-31 09:41:50 --> Final output sent to browser
DEBUG - 2016-08-31 09:41:50 --> Total execution time: 1.7854
DEBUG - 2016-08-31 09:41:59 --> Config Class Initialized
DEBUG - 2016-08-31 09:41:59 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:41:59 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:41:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:41:59 --> URI Class Initialized
DEBUG - 2016-08-31 09:41:59 --> Router Class Initialized
DEBUG - 2016-08-31 09:41:59 --> Output Class Initialized
DEBUG - 2016-08-31 09:41:59 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 09:41:59 --> Security Class Initialized
DEBUG - 2016-08-31 09:41:59 --> Input Class Initialized
DEBUG - 2016-08-31 09:41:59 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:59 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:59 --> XSS Filtering completed
DEBUG - 2016-08-31 09:41:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:41:59 --> Language Class Initialized
DEBUG - 2016-08-31 09:41:59 --> Loader Class Initialized
DEBUG - 2016-08-31 09:42:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:42:00 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:42:00 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:42:00 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:42:00 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:42:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:42:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:42:00 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:42:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:42:00 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:42:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:42:00 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:42:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:42:00 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:42:00 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:42:00 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:42:00 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:42:00 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:42:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:42:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:42:00 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:42:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:42:00 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:42:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:42:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:42:00 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:42:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:42:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:42:00 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:42:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:42:00 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:42:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:42:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:42:00 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:42:00 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:42:00 --> Session Class Initialized
DEBUG - 2016-08-31 09:42:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:42:00 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:42:00 --> Session routines successfully run
DEBUG - 2016-08-31 09:42:01 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:42:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:42:01 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:42:01 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:42:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:42:01 --> Controller Class Initialized
DEBUG - 2016-08-31 09:42:01 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:42:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:42:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:42:01 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:42:01 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:42:01 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:42:01 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:01 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:01 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:01 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:01 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:01 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/3986b17e67923511ff75332baca04769
DEBUG - 2016-08-31 09:42:01 --> Final output sent to browser
DEBUG - 2016-08-31 09:42:01 --> Total execution time: 2.0086
DEBUG - 2016-08-31 09:42:07 --> Config Class Initialized
DEBUG - 2016-08-31 09:42:07 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:42:07 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:42:07 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:42:07 --> URI Class Initialized
DEBUG - 2016-08-31 09:42:07 --> Router Class Initialized
DEBUG - 2016-08-31 09:42:07 --> Output Class Initialized
DEBUG - 2016-08-31 09:42:07 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 09:42:07 --> Security Class Initialized
DEBUG - 2016-08-31 09:42:07 --> Input Class Initialized
DEBUG - 2016-08-31 09:42:07 --> XSS Filtering completed
DEBUG - 2016-08-31 09:42:07 --> XSS Filtering completed
DEBUG - 2016-08-31 09:42:07 --> XSS Filtering completed
DEBUG - 2016-08-31 09:42:07 --> XSS Filtering completed
DEBUG - 2016-08-31 09:42:07 --> XSS Filtering completed
DEBUG - 2016-08-31 09:42:07 --> XSS Filtering completed
DEBUG - 2016-08-31 09:42:07 --> XSS Filtering completed
DEBUG - 2016-08-31 09:42:07 --> XSS Filtering completed
DEBUG - 2016-08-31 09:42:07 --> XSS Filtering completed
DEBUG - 2016-08-31 09:42:07 --> XSS Filtering completed
DEBUG - 2016-08-31 09:42:07 --> XSS Filtering completed
DEBUG - 2016-08-31 09:42:07 --> XSS Filtering completed
DEBUG - 2016-08-31 09:42:07 --> XSS Filtering completed
DEBUG - 2016-08-31 09:42:08 --> XSS Filtering completed
DEBUG - 2016-08-31 09:42:08 --> XSS Filtering completed
DEBUG - 2016-08-31 09:42:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:42:08 --> Language Class Initialized
DEBUG - 2016-08-31 09:42:08 --> Loader Class Initialized
DEBUG - 2016-08-31 09:42:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:42:08 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:42:08 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:42:08 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:42:08 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:42:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:42:08 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:42:08 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:42:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:42:08 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:42:08 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:42:08 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:42:08 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:42:08 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:42:08 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:42:08 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:42:08 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:42:08 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:42:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:42:08 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:42:08 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:42:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:42:08 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:42:08 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:42:08 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:42:08 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:42:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:42:08 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:42:08 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:42:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:42:08 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:42:08 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:42:08 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:42:08 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:42:08 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:42:09 --> Session Class Initialized
DEBUG - 2016-08-31 09:42:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:42:09 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:42:09 --> Session routines successfully run
DEBUG - 2016-08-31 09:42:09 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:42:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:42:09 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:42:09 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:42:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:42:09 --> Controller Class Initialized
DEBUG - 2016-08-31 09:42:09 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:42:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:42:09 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:42:09 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:42:09 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:42:09 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:42:09 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:09 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:09 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:09 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:09 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:09 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 09:42:09 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:42:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:42:09 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-08-31 09:42:09 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:09 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:09 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:09 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:10 --> Config Class Initialized
DEBUG - 2016-08-31 09:42:10 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:42:10 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:42:10 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:42:10 --> URI Class Initialized
DEBUG - 2016-08-31 09:42:10 --> Router Class Initialized
DEBUG - 2016-08-31 09:42:10 --> Output Class Initialized
DEBUG - 2016-08-31 09:42:10 --> Security Class Initialized
DEBUG - 2016-08-31 09:42:10 --> Input Class Initialized
DEBUG - 2016-08-31 09:42:10 --> XSS Filtering completed
DEBUG - 2016-08-31 09:42:10 --> XSS Filtering completed
DEBUG - 2016-08-31 09:42:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:42:10 --> Language Class Initialized
DEBUG - 2016-08-31 09:42:10 --> Loader Class Initialized
DEBUG - 2016-08-31 09:42:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:42:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:42:10 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:42:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:42:10 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:42:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:42:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:42:10 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:42:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:42:10 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:42:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:42:10 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:42:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:42:10 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:42:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:42:10 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:42:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:42:10 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:42:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:42:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:42:11 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:42:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:42:11 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:42:11 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:42:11 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:42:11 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:42:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:42:11 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:42:11 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:42:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:42:11 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:42:11 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:42:11 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:42:11 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:42:11 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:42:11 --> Session Class Initialized
DEBUG - 2016-08-31 09:42:11 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:42:11 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:42:11 --> Session routines successfully run
DEBUG - 2016-08-31 09:42:11 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:42:11 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:42:11 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:42:11 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:42:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:42:11 --> Controller Class Initialized
DEBUG - 2016-08-31 09:42:11 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:42:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:42:11 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:42:11 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:42:11 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:42:11 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:42:11 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:11 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:11 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:11 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:11 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:11 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:11 --> Config Class Initialized
DEBUG - 2016-08-31 09:42:11 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:42:12 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:42:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:42:12 --> URI Class Initialized
DEBUG - 2016-08-31 09:42:12 --> Router Class Initialized
DEBUG - 2016-08-31 09:42:12 --> Output Class Initialized
DEBUG - 2016-08-31 09:42:12 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 09:42:12 --> Security Class Initialized
DEBUG - 2016-08-31 09:42:12 --> Input Class Initialized
DEBUG - 2016-08-31 09:42:12 --> XSS Filtering completed
DEBUG - 2016-08-31 09:42:12 --> XSS Filtering completed
DEBUG - 2016-08-31 09:42:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:42:12 --> Language Class Initialized
DEBUG - 2016-08-31 09:42:12 --> Loader Class Initialized
DEBUG - 2016-08-31 09:42:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:42:12 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:42:12 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:42:12 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:42:12 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:42:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:42:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:42:12 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:42:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:42:12 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:42:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:42:12 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:42:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:42:12 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:42:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:42:12 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:42:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:42:12 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:42:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:42:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:42:12 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:42:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:42:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:42:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:42:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:42:12 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:42:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:42:13 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:42:13 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:42:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:42:13 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:42:13 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:42:13 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:42:13 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:42:13 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:42:13 --> Session Class Initialized
DEBUG - 2016-08-31 09:42:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:42:13 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:42:13 --> Session routines successfully run
DEBUG - 2016-08-31 09:42:13 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:42:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:42:13 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:42:13 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:42:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:42:13 --> Controller Class Initialized
DEBUG - 2016-08-31 09:42:13 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:42:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:42:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:42:13 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:42:13 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:42:13 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:42:13 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:13 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:13 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:13 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:13 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:13 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:13 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:13 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:13 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 09:42:13 --> Pagination Class Initialized
DEBUG - 2016-08-31 09:42:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 09:42:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-31 09:42:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 09:42:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 09:42:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 09:42:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 09:42:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 09:42:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 09:42:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 09:42:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 09:42:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 09:42:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 09:42:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 09:42:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 09:42:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 09:42:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 09:42:14 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-31 09:42:14 --> Final output sent to browser
DEBUG - 2016-08-31 09:42:14 --> Total execution time: 2.0339
DEBUG - 2016-08-31 09:42:19 --> Config Class Initialized
DEBUG - 2016-08-31 09:42:19 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:42:19 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:42:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:42:19 --> URI Class Initialized
DEBUG - 2016-08-31 09:42:19 --> Router Class Initialized
DEBUG - 2016-08-31 09:42:19 --> Output Class Initialized
DEBUG - 2016-08-31 09:42:19 --> Security Class Initialized
DEBUG - 2016-08-31 09:42:19 --> Input Class Initialized
DEBUG - 2016-08-31 09:42:19 --> XSS Filtering completed
DEBUG - 2016-08-31 09:42:19 --> XSS Filtering completed
DEBUG - 2016-08-31 09:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:42:19 --> Language Class Initialized
DEBUG - 2016-08-31 09:42:19 --> Loader Class Initialized
DEBUG - 2016-08-31 09:42:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:42:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:42:20 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:42:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:42:20 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:42:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:42:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:42:20 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:42:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:42:20 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:42:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:42:20 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:42:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:42:20 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:42:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:42:20 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:42:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:42:20 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:42:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:42:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:42:20 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:42:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:42:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:42:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:42:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:42:20 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:42:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:42:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:42:20 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:42:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:42:20 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:42:20 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:42:20 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:42:20 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:42:20 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:42:20 --> Session Class Initialized
DEBUG - 2016-08-31 09:42:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:42:20 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:42:20 --> Session routines successfully run
DEBUG - 2016-08-31 09:42:20 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:42:21 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:42:21 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:42:21 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:42:21 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:42:21 --> Controller Class Initialized
DEBUG - 2016-08-31 09:42:21 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:42:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:42:21 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:42:21 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:42:21 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:42:21 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:42:21 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:21 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:21 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:21 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:21 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:21 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 09:42:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/detail.php
DEBUG - 2016-08-31 09:42:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 09:42:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 09:42:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 09:42:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 09:42:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_js.php
DEBUG - 2016-08-31 09:42:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_isian_js.php
DEBUG - 2016-08-31 09:42:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 09:42:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 09:42:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 09:42:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 09:42:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 09:42:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 09:42:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_js.php
DEBUG - 2016-08-31 09:42:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_isian_js.php
DEBUG - 2016-08-31 09:42:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 09:42:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 09:42:21 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/27889419d5c256178a830aca2d659b22
DEBUG - 2016-08-31 09:42:21 --> Final output sent to browser
DEBUG - 2016-08-31 09:42:22 --> Total execution time: 2.0079
DEBUG - 2016-08-31 09:42:26 --> Config Class Initialized
DEBUG - 2016-08-31 09:42:26 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:42:26 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:42:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:42:26 --> URI Class Initialized
DEBUG - 2016-08-31 09:42:26 --> Router Class Initialized
DEBUG - 2016-08-31 09:42:26 --> Output Class Initialized
DEBUG - 2016-08-31 09:42:26 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 09:42:26 --> Security Class Initialized
DEBUG - 2016-08-31 09:42:26 --> Input Class Initialized
DEBUG - 2016-08-31 09:42:26 --> XSS Filtering completed
DEBUG - 2016-08-31 09:42:26 --> XSS Filtering completed
DEBUG - 2016-08-31 09:42:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:42:26 --> Language Class Initialized
DEBUG - 2016-08-31 09:42:26 --> Loader Class Initialized
DEBUG - 2016-08-31 09:42:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:42:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:42:26 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:42:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:42:26 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:42:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:42:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:42:27 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:42:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:42:27 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:42:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:42:27 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:42:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:42:27 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:42:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:42:27 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:42:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:42:27 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:42:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:42:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:42:27 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:42:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:42:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:42:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:42:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:42:27 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:42:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:42:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:42:27 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:42:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:42:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:42:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:42:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:42:27 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:42:27 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:42:27 --> Session Class Initialized
DEBUG - 2016-08-31 09:42:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:42:27 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:42:27 --> Session routines successfully run
DEBUG - 2016-08-31 09:42:27 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:42:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:42:27 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:42:27 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:42:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:42:28 --> Controller Class Initialized
DEBUG - 2016-08-31 09:42:28 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:42:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:42:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:42:28 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:42:28 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:42:28 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:42:28 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:28 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:28 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:28 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:28 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:28 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:28 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:28 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:28 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 09:42:28 --> Pagination Class Initialized
DEBUG - 2016-08-31 09:42:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 09:42:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-31 09:42:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 09:42:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 09:42:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 09:42:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 09:42:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 09:42:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 09:42:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 09:42:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 09:42:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 09:42:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 09:42:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 09:42:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 09:42:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 09:42:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 09:42:28 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-31 09:42:28 --> Final output sent to browser
DEBUG - 2016-08-31 09:42:29 --> Total execution time: 2.0650
DEBUG - 2016-08-31 09:42:33 --> Config Class Initialized
DEBUG - 2016-08-31 09:42:33 --> Hooks Class Initialized
DEBUG - 2016-08-31 09:42:33 --> Utf8 Class Initialized
DEBUG - 2016-08-31 09:42:33 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 09:42:33 --> URI Class Initialized
DEBUG - 2016-08-31 09:42:33 --> Router Class Initialized
DEBUG - 2016-08-31 09:42:33 --> Output Class Initialized
DEBUG - 2016-08-31 09:42:33 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 09:42:33 --> Security Class Initialized
DEBUG - 2016-08-31 09:42:33 --> Input Class Initialized
DEBUG - 2016-08-31 09:42:33 --> XSS Filtering completed
DEBUG - 2016-08-31 09:42:33 --> XSS Filtering completed
DEBUG - 2016-08-31 09:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 09:42:33 --> Language Class Initialized
DEBUG - 2016-08-31 09:42:33 --> Loader Class Initialized
DEBUG - 2016-08-31 09:42:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 09:42:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 09:42:33 --> Helper loaded: url_helper
DEBUG - 2016-08-31 09:42:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 09:42:33 --> Helper loaded: file_helper
DEBUG - 2016-08-31 09:42:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:42:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 09:42:33 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 09:42:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 09:42:33 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 09:42:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 09:42:33 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:42:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 09:42:33 --> Helper loaded: common_helper
DEBUG - 2016-08-31 09:42:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 09:42:33 --> Helper loaded: form_helper
DEBUG - 2016-08-31 09:42:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 09:42:33 --> Helper loaded: security_helper
DEBUG - 2016-08-31 09:42:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:42:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 09:42:34 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 09:42:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 09:42:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 09:42:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 09:42:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 09:42:34 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 09:42:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:42:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 09:42:34 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 09:42:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 09:42:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 09:42:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 09:42:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 09:42:34 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 09:42:34 --> Database Driver Class Initialized
DEBUG - 2016-08-31 09:42:34 --> Session Class Initialized
DEBUG - 2016-08-31 09:42:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 09:42:34 --> Helper loaded: string_helper
DEBUG - 2016-08-31 09:42:34 --> Session routines successfully run
DEBUG - 2016-08-31 09:42:34 --> Native_session Class Initialized
DEBUG - 2016-08-31 09:42:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 09:42:34 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:42:34 --> Form Validation Class Initialized
DEBUG - 2016-08-31 09:42:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 09:42:34 --> Controller Class Initialized
DEBUG - 2016-08-31 09:42:34 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 09:42:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 09:42:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 09:42:34 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:42:34 --> Carabiner: library configured.
DEBUG - 2016-08-31 09:42:34 --> User Agent Class Initialized
DEBUG - 2016-08-31 09:42:34 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:34 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:34 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:34 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:34 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:34 --> Model Class Initialized
DEBUG - 2016-08-31 09:42:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 09:42:35 --> Pagination Class Initialized
DEBUG - 2016-08-31 09:42:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 09:42:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-31 09:42:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 09:42:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 09:42:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 09:42:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 09:42:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 09:42:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 09:42:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 09:42:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 09:42:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 09:42:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 09:42:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 09:42:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 09:42:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 09:42:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 09:42:35 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/96f5e1b7885bda6c73eb3c0ea541f3b4
DEBUG - 2016-08-31 09:42:35 --> Final output sent to browser
DEBUG - 2016-08-31 09:42:35 --> Total execution time: 1.9828
DEBUG - 2016-08-31 10:40:08 --> Config Class Initialized
DEBUG - 2016-08-31 10:40:09 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:40:09 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:40:10 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:40:10 --> URI Class Initialized
DEBUG - 2016-08-31 10:40:10 --> Router Class Initialized
DEBUG - 2016-08-31 10:40:10 --> No URI present. Default controller set.
DEBUG - 2016-08-31 10:40:10 --> Output Class Initialized
DEBUG - 2016-08-31 10:40:10 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 10:40:10 --> Security Class Initialized
DEBUG - 2016-08-31 10:40:10 --> Input Class Initialized
DEBUG - 2016-08-31 10:40:10 --> XSS Filtering completed
DEBUG - 2016-08-31 10:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:40:10 --> Language Class Initialized
DEBUG - 2016-08-31 10:40:10 --> Loader Class Initialized
DEBUG - 2016-08-31 10:40:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:40:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:40:11 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:40:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:40:11 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:40:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:40:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:40:11 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:40:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:40:11 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:40:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:40:11 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:40:11 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:40:11 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:40:11 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:40:11 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:40:11 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:40:11 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:40:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:40:11 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:40:11 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:40:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:40:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:40:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:40:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:40:12 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:40:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:40:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:40:12 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:40:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:40:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:40:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:40:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:40:12 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:40:12 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:40:12 --> Session Class Initialized
DEBUG - 2016-08-31 10:40:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:40:12 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:40:12 --> Session routines successfully run
DEBUG - 2016-08-31 10:40:12 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:40:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:40:13 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:40:13 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:40:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:40:13 --> Controller Class Initialized
DEBUG - 2016-08-31 10:40:13 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:40:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:40:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:40:13 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:40:13 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:40:13 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:40:13 --> Model Class Initialized
DEBUG - 2016-08-31 10:40:13 --> Model Class Initialized
DEBUG - 2016-08-31 10:40:13 --> Model Class Initialized
DEBUG - 2016-08-31 10:40:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-08-31 10:40:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:40:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:40:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:40:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:40:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:40:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:40:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:40:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:40:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:40:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:40:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:40:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:40:14 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-08-31 10:40:14 --> Final output sent to browser
DEBUG - 2016-08-31 10:40:14 --> Total execution time: 5.6909
DEBUG - 2016-08-31 10:40:28 --> Config Class Initialized
DEBUG - 2016-08-31 10:40:28 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:40:28 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:40:28 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:40:28 --> URI Class Initialized
DEBUG - 2016-08-31 10:40:28 --> Router Class Initialized
DEBUG - 2016-08-31 10:40:28 --> Output Class Initialized
DEBUG - 2016-08-31 10:40:28 --> Security Class Initialized
DEBUG - 2016-08-31 10:40:28 --> Input Class Initialized
DEBUG - 2016-08-31 10:40:28 --> XSS Filtering completed
DEBUG - 2016-08-31 10:40:28 --> XSS Filtering completed
DEBUG - 2016-08-31 10:40:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:40:28 --> Language Class Initialized
DEBUG - 2016-08-31 10:40:29 --> Loader Class Initialized
DEBUG - 2016-08-31 10:40:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:40:29 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:40:29 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:40:29 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:40:29 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:40:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:40:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:40:29 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:40:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:40:29 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:40:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:40:29 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:40:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:40:29 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:40:29 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:40:29 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:40:29 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:40:29 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:40:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:40:29 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:40:29 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:40:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:40:29 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:40:29 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:40:29 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:40:29 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:40:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:40:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:40:29 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:40:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:40:29 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:40:29 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:40:29 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:40:30 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:40:30 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:40:30 --> Session Class Initialized
DEBUG - 2016-08-31 10:40:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:40:30 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:40:30 --> Session routines successfully run
DEBUG - 2016-08-31 10:40:30 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:40:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:40:30 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:40:30 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:40:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:40:30 --> Controller Class Initialized
DEBUG - 2016-08-31 10:40:30 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:40:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:40:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:40:30 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:40:30 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:40:30 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:40:30 --> Model Class Initialized
DEBUG - 2016-08-31 10:40:30 --> Model Class Initialized
DEBUG - 2016-08-31 10:40:30 --> Model Class Initialized
DEBUG - 2016-08-31 10:40:30 --> Model Class Initialized
DEBUG - 2016-08-31 10:40:30 --> Model Class Initialized
DEBUG - 2016-08-31 10:40:30 --> Model Class Initialized
DEBUG - 2016-08-31 10:40:30 --> Model Class Initialized
DEBUG - 2016-08-31 10:40:31 --> Model Class Initialized
ERROR - 2016-08-31 10:40:31 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-08-31 10:40:31 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-08-31 10:40:31 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-08-31 10:40:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-08-31 10:40:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-08-31 10:40:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-08-31 10:40:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-08-31 10:40:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-08-31 10:40:31 --> Final output sent to browser
DEBUG - 2016-08-31 10:40:31 --> Total execution time: 2.6850
DEBUG - 2016-08-31 10:40:31 --> Config Class Initialized
DEBUG - 2016-08-31 10:40:31 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:40:31 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:40:31 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:40:31 --> URI Class Initialized
DEBUG - 2016-08-31 10:40:31 --> Router Class Initialized
ERROR - 2016-08-31 10:40:31 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-08-31 10:41:32 --> Config Class Initialized
DEBUG - 2016-08-31 10:41:32 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:41:32 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:41:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:41:32 --> URI Class Initialized
DEBUG - 2016-08-31 10:41:32 --> Router Class Initialized
DEBUG - 2016-08-31 10:41:32 --> Output Class Initialized
DEBUG - 2016-08-31 10:41:32 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 10:41:33 --> Security Class Initialized
DEBUG - 2016-08-31 10:41:33 --> Input Class Initialized
DEBUG - 2016-08-31 10:41:33 --> XSS Filtering completed
DEBUG - 2016-08-31 10:41:33 --> XSS Filtering completed
DEBUG - 2016-08-31 10:41:33 --> XSS Filtering completed
DEBUG - 2016-08-31 10:41:33 --> XSS Filtering completed
DEBUG - 2016-08-31 10:41:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:41:33 --> Language Class Initialized
DEBUG - 2016-08-31 10:41:33 --> Loader Class Initialized
DEBUG - 2016-08-31 10:41:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:41:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:41:33 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:41:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:41:33 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:41:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:41:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:41:33 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:41:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:41:33 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:41:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:41:33 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:41:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:41:33 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:41:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:41:33 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:41:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:41:33 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:41:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:41:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:41:33 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:41:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:41:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:41:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:41:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:41:33 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:41:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:41:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:41:34 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:41:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:41:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:41:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:41:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:41:34 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:41:34 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:41:34 --> Session Class Initialized
DEBUG - 2016-08-31 10:41:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:41:34 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:41:34 --> Session routines successfully run
DEBUG - 2016-08-31 10:41:34 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:41:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:41:34 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:41:34 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:41:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:41:34 --> Controller Class Initialized
DEBUG - 2016-08-31 10:41:34 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:41:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:41:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:41:34 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:41:34 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:41:34 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:41:34 --> Model Class Initialized
DEBUG - 2016-08-31 10:41:34 --> Model Class Initialized
DEBUG - 2016-08-31 10:41:34 --> Model Class Initialized
DEBUG - 2016-08-31 10:41:34 --> Model Class Initialized
DEBUG - 2016-08-31 10:41:34 --> Model Class Initialized
DEBUG - 2016-08-31 10:41:34 --> Model Class Initialized
DEBUG - 2016-08-31 10:41:34 --> Model Class Initialized
DEBUG - 2016-08-31 10:41:34 --> Model Class Initialized
ERROR - 2016-08-31 10:41:34 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-08-31 10:41:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 10:41:35 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:41:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:41:35 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-08-31 10:41:35 --> Config Class Initialized
DEBUG - 2016-08-31 10:41:35 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:41:35 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:41:35 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:41:35 --> URI Class Initialized
DEBUG - 2016-08-31 10:41:35 --> Router Class Initialized
DEBUG - 2016-08-31 10:41:35 --> No URI present. Default controller set.
DEBUG - 2016-08-31 10:41:35 --> Output Class Initialized
DEBUG - 2016-08-31 10:41:35 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 10:41:35 --> Security Class Initialized
DEBUG - 2016-08-31 10:41:35 --> Input Class Initialized
DEBUG - 2016-08-31 10:41:35 --> XSS Filtering completed
DEBUG - 2016-08-31 10:41:35 --> XSS Filtering completed
DEBUG - 2016-08-31 10:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:41:35 --> Language Class Initialized
DEBUG - 2016-08-31 10:41:35 --> Loader Class Initialized
DEBUG - 2016-08-31 10:41:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:41:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:41:35 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:41:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:41:35 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:41:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:41:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:41:35 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:41:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:41:35 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:41:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:41:35 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:41:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:41:35 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:41:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:41:36 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:41:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:41:36 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:41:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:41:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:41:36 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:41:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:41:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:41:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:41:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:41:36 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:41:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:41:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:41:36 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:41:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:41:36 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:41:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:41:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:41:36 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:41:36 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:41:36 --> Session Class Initialized
DEBUG - 2016-08-31 10:41:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:41:36 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:41:36 --> Session routines successfully run
DEBUG - 2016-08-31 10:41:36 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:41:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:41:36 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:41:36 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:41:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:41:36 --> Controller Class Initialized
DEBUG - 2016-08-31 10:41:36 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:41:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:41:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:41:36 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:41:37 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:41:37 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:41:37 --> Model Class Initialized
DEBUG - 2016-08-31 10:41:37 --> Model Class Initialized
DEBUG - 2016-08-31 10:41:37 --> Model Class Initialized
DEBUG - 2016-08-31 10:41:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-08-31 10:41:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:41:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:41:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:41:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:41:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:41:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:41:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:41:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:41:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:41:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:41:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:41:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:41:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-08-31 10:41:37 --> Final output sent to browser
DEBUG - 2016-08-31 10:41:37 --> Total execution time: 2.0110
DEBUG - 2016-08-31 10:41:45 --> Config Class Initialized
DEBUG - 2016-08-31 10:41:45 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:41:45 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:41:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:41:45 --> URI Class Initialized
DEBUG - 2016-08-31 10:41:45 --> Router Class Initialized
DEBUG - 2016-08-31 10:41:45 --> Output Class Initialized
DEBUG - 2016-08-31 10:41:45 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 10:41:45 --> Security Class Initialized
DEBUG - 2016-08-31 10:41:45 --> Input Class Initialized
DEBUG - 2016-08-31 10:41:45 --> XSS Filtering completed
DEBUG - 2016-08-31 10:41:45 --> XSS Filtering completed
DEBUG - 2016-08-31 10:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:41:45 --> Language Class Initialized
DEBUG - 2016-08-31 10:41:45 --> Loader Class Initialized
DEBUG - 2016-08-31 10:41:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:41:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:41:46 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:41:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:41:46 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:41:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:41:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:41:46 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:41:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:41:46 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:41:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:41:46 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:41:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:41:46 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:41:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:41:46 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:41:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:41:46 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:41:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:41:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:41:46 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:41:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:41:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:41:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:41:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:41:46 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:41:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:41:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:41:46 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:41:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:41:46 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:41:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:41:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:41:46 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:41:46 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:41:47 --> Session Class Initialized
DEBUG - 2016-08-31 10:41:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:41:47 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:41:47 --> Session routines successfully run
DEBUG - 2016-08-31 10:41:47 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:41:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:41:47 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:41:47 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:41:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:41:47 --> Controller Class Initialized
DEBUG - 2016-08-31 10:41:47 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:41:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:41:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:41:47 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:41:47 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:41:47 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:41:47 --> Model Class Initialized
DEBUG - 2016-08-31 10:41:47 --> Model Class Initialized
DEBUG - 2016-08-31 10:41:47 --> Model Class Initialized
DEBUG - 2016-08-31 10:41:47 --> Model Class Initialized
DEBUG - 2016-08-31 10:41:47 --> Model Class Initialized
DEBUG - 2016-08-31 10:41:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 10:41:47 --> Pagination Class Initialized
DEBUG - 2016-08-31 10:41:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 10:41:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/index.php
DEBUG - 2016-08-31 10:41:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:41:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:41:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:41:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:41:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-08-31 10:41:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:41:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:41:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:41:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:41:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:41:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:41:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-08-31 10:41:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:41:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:41:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c2a3e0401bd35d4fcac4bae5f9412231
DEBUG - 2016-08-31 10:41:48 --> Final output sent to browser
DEBUG - 2016-08-31 10:41:48 --> Total execution time: 2.5212
DEBUG - 2016-08-31 10:42:20 --> Config Class Initialized
DEBUG - 2016-08-31 10:42:20 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:42:20 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:42:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:42:20 --> URI Class Initialized
DEBUG - 2016-08-31 10:42:21 --> Router Class Initialized
DEBUG - 2016-08-31 10:42:21 --> Output Class Initialized
DEBUG - 2016-08-31 10:42:21 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 10:42:21 --> Security Class Initialized
DEBUG - 2016-08-31 10:42:21 --> Input Class Initialized
DEBUG - 2016-08-31 10:42:21 --> XSS Filtering completed
DEBUG - 2016-08-31 10:42:21 --> XSS Filtering completed
DEBUG - 2016-08-31 10:42:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:42:21 --> Language Class Initialized
DEBUG - 2016-08-31 10:42:21 --> Loader Class Initialized
DEBUG - 2016-08-31 10:42:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:42:21 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:42:21 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:42:21 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:42:21 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:42:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:42:21 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:42:21 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:42:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:42:21 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:42:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:42:21 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:42:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:42:21 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:42:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:42:21 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:42:21 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:42:21 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:42:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:42:21 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:42:21 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:42:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:42:22 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:42:22 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:42:22 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:42:22 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:42:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:42:22 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:42:22 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:42:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:42:22 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:42:22 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:42:22 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:42:22 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:42:22 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:42:22 --> Session Class Initialized
DEBUG - 2016-08-31 10:42:22 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:42:22 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:42:22 --> Session routines successfully run
DEBUG - 2016-08-31 10:42:22 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:42:22 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:42:22 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:42:22 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:42:22 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:42:22 --> Controller Class Initialized
DEBUG - 2016-08-31 10:42:22 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:42:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:42:22 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:42:22 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:42:22 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:42:22 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:42:22 --> Model Class Initialized
DEBUG - 2016-08-31 10:42:22 --> Model Class Initialized
DEBUG - 2016-08-31 10:42:22 --> Model Class Initialized
DEBUG - 2016-08-31 10:42:22 --> Model Class Initialized
DEBUG - 2016-08-31 10:42:23 --> Model Class Initialized
DEBUG - 2016-08-31 10:42:23 --> Model Class Initialized
DEBUG - 2016-08-31 10:42:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 10:42:23 --> Pagination Class Initialized
DEBUG - 2016-08-31 10:42:23 --> Model Class Initialized
DEBUG - 2016-08-31 10:42:23 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 10:42:23 --> Model Class Initialized
DEBUG - 2016-08-31 10:42:23 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 10:42:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-31 10:42:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-31 10:42:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-31 10:42:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-31 10:42:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:42:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:42:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:42:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:42:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-31 10:42:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:42:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:42:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:42:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:42:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:42:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:42:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-31 10:42:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:42:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:42:24 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b6bd8c4f0f9a3c083ce1836ed8f53795
DEBUG - 2016-08-31 10:42:24 --> Final output sent to browser
DEBUG - 2016-08-31 10:42:24 --> Total execution time: 2.6796
DEBUG - 2016-08-31 10:43:03 --> Config Class Initialized
DEBUG - 2016-08-31 10:43:03 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:43:03 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:43:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:43:03 --> URI Class Initialized
DEBUG - 2016-08-31 10:43:03 --> Router Class Initialized
DEBUG - 2016-08-31 10:43:04 --> Output Class Initialized
DEBUG - 2016-08-31 10:43:04 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 10:43:04 --> Security Class Initialized
DEBUG - 2016-08-31 10:43:04 --> Input Class Initialized
DEBUG - 2016-08-31 10:43:04 --> XSS Filtering completed
DEBUG - 2016-08-31 10:43:04 --> XSS Filtering completed
DEBUG - 2016-08-31 10:43:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:43:04 --> Language Class Initialized
DEBUG - 2016-08-31 10:43:04 --> Loader Class Initialized
DEBUG - 2016-08-31 10:43:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:43:04 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:43:04 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:43:04 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:43:04 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:43:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:43:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:43:04 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:43:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:43:04 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:43:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:43:04 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:43:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:43:04 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:43:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:43:04 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:43:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:43:04 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:43:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:43:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:43:04 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:43:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:43:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:43:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:43:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:43:05 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:43:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:43:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:43:05 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:43:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:43:05 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:43:05 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:43:05 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:43:05 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:43:05 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:43:05 --> Session Class Initialized
DEBUG - 2016-08-31 10:43:05 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:43:05 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:43:05 --> Session routines successfully run
DEBUG - 2016-08-31 10:43:05 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:43:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:43:05 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:43:05 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:43:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:43:05 --> Controller Class Initialized
DEBUG - 2016-08-31 10:43:05 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:43:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:43:05 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:43:05 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:43:05 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:43:05 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:43:05 --> Model Class Initialized
DEBUG - 2016-08-31 10:43:05 --> Model Class Initialized
DEBUG - 2016-08-31 10:43:05 --> Model Class Initialized
DEBUG - 2016-08-31 10:43:06 --> Model Class Initialized
DEBUG - 2016-08-31 10:43:06 --> Model Class Initialized
DEBUG - 2016-08-31 10:43:06 --> Model Class Initialized
DEBUG - 2016-08-31 10:43:06 --> Model Class Initialized
DEBUG - 2016-08-31 10:43:06 --> Model Class Initialized
DEBUG - 2016-08-31 10:43:06 --> Model Class Initialized
DEBUG - 2016-08-31 10:43:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 10:43:06 --> Pagination Class Initialized
DEBUG - 2016-08-31 10:43:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 10:43:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-31 10:43:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:43:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:43:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:43:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:43:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 10:43:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:43:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:43:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:43:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:43:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:43:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:43:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 10:43:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:43:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:43:06 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-31 10:43:06 --> Final output sent to browser
DEBUG - 2016-08-31 10:43:07 --> Total execution time: 2.5806
DEBUG - 2016-08-31 10:43:11 --> Config Class Initialized
DEBUG - 2016-08-31 10:43:11 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:43:11 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:43:11 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:43:11 --> URI Class Initialized
DEBUG - 2016-08-31 10:43:11 --> Router Class Initialized
DEBUG - 2016-08-31 10:43:11 --> Output Class Initialized
DEBUG - 2016-08-31 10:43:11 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 10:43:11 --> Security Class Initialized
DEBUG - 2016-08-31 10:43:11 --> Input Class Initialized
DEBUG - 2016-08-31 10:43:11 --> XSS Filtering completed
DEBUG - 2016-08-31 10:43:11 --> XSS Filtering completed
DEBUG - 2016-08-31 10:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:43:11 --> Language Class Initialized
DEBUG - 2016-08-31 10:43:11 --> Loader Class Initialized
DEBUG - 2016-08-31 10:43:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:43:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:43:11 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:43:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:43:11 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:43:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:43:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:43:11 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:43:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:43:11 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:43:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:43:12 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:43:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:43:12 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:43:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:43:12 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:43:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:43:12 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:43:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:43:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:43:12 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:43:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:43:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:43:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:43:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:43:12 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:43:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:43:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:43:12 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:43:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:43:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:43:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:43:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:43:12 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:43:12 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:43:12 --> Session Class Initialized
DEBUG - 2016-08-31 10:43:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:43:12 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:43:12 --> Session routines successfully run
DEBUG - 2016-08-31 10:43:12 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:43:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:43:12 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:43:12 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:43:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:43:13 --> Controller Class Initialized
DEBUG - 2016-08-31 10:43:13 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:43:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:43:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:43:13 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:43:13 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:43:13 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:43:13 --> Model Class Initialized
DEBUG - 2016-08-31 10:43:13 --> Model Class Initialized
DEBUG - 2016-08-31 10:43:13 --> Model Class Initialized
DEBUG - 2016-08-31 10:43:13 --> Model Class Initialized
DEBUG - 2016-08-31 10:43:13 --> Model Class Initialized
DEBUG - 2016-08-31 10:43:13 --> Model Class Initialized
DEBUG - 2016-08-31 10:43:13 --> Model Class Initialized
DEBUG - 2016-08-31 10:43:13 --> Model Class Initialized
DEBUG - 2016-08-31 10:43:13 --> Model Class Initialized
DEBUG - 2016-08-31 10:43:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 10:43:13 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:43:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:43:13 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-08-31 10:43:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 10:43:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-08-31 10:43:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 10:43:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-08-31 10:43:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 10:43:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-08-31 10:43:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-08-31 10:43:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-08-31 10:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-08-31 10:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:43:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:43:15 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8f8e2926e3f1cbfc3aa536b43cdd0626
DEBUG - 2016-08-31 10:43:15 --> Final output sent to browser
DEBUG - 2016-08-31 10:43:15 --> Total execution time: 2.4440
DEBUG - 2016-08-31 10:45:45 --> Config Class Initialized
DEBUG - 2016-08-31 10:45:45 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:45:45 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:45:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:45:45 --> URI Class Initialized
DEBUG - 2016-08-31 10:45:45 --> Router Class Initialized
DEBUG - 2016-08-31 10:45:45 --> Output Class Initialized
DEBUG - 2016-08-31 10:45:45 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 10:45:45 --> Security Class Initialized
DEBUG - 2016-08-31 10:45:45 --> Input Class Initialized
DEBUG - 2016-08-31 10:45:46 --> XSS Filtering completed
DEBUG - 2016-08-31 10:45:46 --> XSS Filtering completed
DEBUG - 2016-08-31 10:45:46 --> XSS Filtering completed
DEBUG - 2016-08-31 10:45:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:45:46 --> Language Class Initialized
DEBUG - 2016-08-31 10:45:46 --> Loader Class Initialized
DEBUG - 2016-08-31 10:45:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:45:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:45:46 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:45:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:45:46 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:45:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:45:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:45:46 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:45:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:45:46 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:45:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:45:46 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:45:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:45:46 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:45:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:45:46 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:45:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:45:46 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:45:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:45:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:45:46 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:45:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:45:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:45:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:45:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:45:46 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:45:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:45:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:45:46 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:45:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:45:47 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:45:47 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:45:47 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:45:47 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:45:47 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:45:47 --> Session Class Initialized
DEBUG - 2016-08-31 10:45:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:45:47 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:45:47 --> Session routines successfully run
DEBUG - 2016-08-31 10:45:47 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:45:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:45:47 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:45:47 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:45:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:45:47 --> Controller Class Initialized
DEBUG - 2016-08-31 10:45:47 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:45:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:45:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:45:47 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:45:47 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:45:47 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:45:47 --> Model Class Initialized
DEBUG - 2016-08-31 10:45:47 --> Model Class Initialized
DEBUG - 2016-08-31 10:45:47 --> Model Class Initialized
DEBUG - 2016-08-31 10:45:47 --> Model Class Initialized
DEBUG - 2016-08-31 10:45:47 --> Model Class Initialized
DEBUG - 2016-08-31 10:45:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5b757aabce4b284c04cf4ac1cfc7451e
DEBUG - 2016-08-31 10:45:47 --> Final output sent to browser
DEBUG - 2016-08-31 10:45:47 --> Total execution time: 2.2258
DEBUG - 2016-08-31 10:46:15 --> Config Class Initialized
DEBUG - 2016-08-31 10:46:15 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:46:15 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:46:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:46:15 --> URI Class Initialized
DEBUG - 2016-08-31 10:46:15 --> Router Class Initialized
DEBUG - 2016-08-31 10:46:15 --> Output Class Initialized
DEBUG - 2016-08-31 10:46:15 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 10:46:15 --> Security Class Initialized
DEBUG - 2016-08-31 10:46:15 --> Input Class Initialized
DEBUG - 2016-08-31 10:46:15 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:15 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:15 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:15 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:15 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:15 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:15 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:15 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:15 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:15 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:15 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:15 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:16 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:16 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:16 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:16 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:16 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:16 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:16 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:16 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:16 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:16 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:16 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:46:16 --> Language Class Initialized
DEBUG - 2016-08-31 10:46:16 --> Loader Class Initialized
DEBUG - 2016-08-31 10:46:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:46:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:46:16 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:46:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:46:16 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:46:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:46:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:46:16 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:46:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:46:16 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:46:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:46:16 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:46:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:46:16 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:46:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:46:16 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:46:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:46:16 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:46:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:46:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:46:17 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:46:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:46:17 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:46:17 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:46:17 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:46:17 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:46:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:46:17 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:46:17 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:46:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:46:17 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:46:17 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:46:17 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:46:17 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:46:17 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:46:17 --> Session Class Initialized
DEBUG - 2016-08-31 10:46:17 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:46:17 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:46:17 --> Session routines successfully run
DEBUG - 2016-08-31 10:46:17 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:46:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:46:17 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:46:17 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:46:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:46:17 --> Controller Class Initialized
DEBUG - 2016-08-31 10:46:17 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:46:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:46:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:46:17 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:46:17 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:46:17 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:46:17 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:17 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:18 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:18 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:18 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:18 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:18 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:18 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:18 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 10:46:18 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:46:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:46:18 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-08-31 10:46:18 --> Unable to find validation rule: 
DEBUG - 2016-08-31 10:46:18 --> Unable to find validation rule: 
DEBUG - 2016-08-31 10:46:18 --> Unable to find validation rule: 
DEBUG - 2016-08-31 10:46:18 --> Unable to find validation rule: 
DEBUG - 2016-08-31 10:46:18 --> Config Class Initialized
DEBUG - 2016-08-31 10:46:18 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:46:18 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:46:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:46:18 --> URI Class Initialized
DEBUG - 2016-08-31 10:46:18 --> Router Class Initialized
DEBUG - 2016-08-31 10:46:18 --> Output Class Initialized
DEBUG - 2016-08-31 10:46:18 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 10:46:18 --> Security Class Initialized
DEBUG - 2016-08-31 10:46:18 --> Input Class Initialized
DEBUG - 2016-08-31 10:46:18 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:18 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:46:18 --> Language Class Initialized
DEBUG - 2016-08-31 10:46:19 --> Loader Class Initialized
DEBUG - 2016-08-31 10:46:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:46:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:46:19 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:46:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:46:19 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:46:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:46:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:46:19 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:46:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:46:19 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:46:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:46:19 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:46:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:46:19 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:46:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:46:19 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:46:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:46:19 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:46:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:46:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:46:19 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:46:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:46:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:46:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:46:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:46:19 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:46:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:46:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:46:19 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:46:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:46:19 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:46:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:46:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:46:19 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:46:20 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:46:20 --> Session Class Initialized
DEBUG - 2016-08-31 10:46:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:46:20 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:46:20 --> Session routines successfully run
DEBUG - 2016-08-31 10:46:20 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:46:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:46:20 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:46:20 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:46:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:46:20 --> Controller Class Initialized
DEBUG - 2016-08-31 10:46:20 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:46:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:46:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:46:20 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:46:20 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:46:20 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:46:20 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:20 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:20 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:20 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:20 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:20 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:20 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:20 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:20 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 10:46:20 --> Pagination Class Initialized
DEBUG - 2016-08-31 10:46:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 10:46:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-31 10:46:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:46:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:46:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:46:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:46:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 10:46:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:46:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:46:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:46:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:46:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:46:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:46:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 10:46:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:46:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:46:21 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-31 10:46:21 --> Final output sent to browser
DEBUG - 2016-08-31 10:46:21 --> Total execution time: 2.3709
DEBUG - 2016-08-31 10:46:21 --> Config Class Initialized
DEBUG - 2016-08-31 10:46:21 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:46:21 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:46:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:46:21 --> URI Class Initialized
DEBUG - 2016-08-31 10:46:21 --> Router Class Initialized
DEBUG - 2016-08-31 10:46:21 --> Output Class Initialized
DEBUG - 2016-08-31 10:46:21 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 10:46:21 --> Security Class Initialized
DEBUG - 2016-08-31 10:46:21 --> Input Class Initialized
DEBUG - 2016-08-31 10:46:21 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:21 --> XSS Filtering completed
DEBUG - 2016-08-31 10:46:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:46:21 --> Language Class Initialized
DEBUG - 2016-08-31 10:46:21 --> Loader Class Initialized
DEBUG - 2016-08-31 10:46:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:46:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:46:22 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:46:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:46:22 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:46:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:46:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:46:22 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:46:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:46:22 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:46:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:46:22 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:46:22 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:46:22 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:46:22 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:46:22 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:46:22 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:46:22 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:46:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:46:22 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:46:22 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:46:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:46:22 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:46:22 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:46:22 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:46:22 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:46:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:46:22 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:46:22 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:46:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:46:22 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:46:22 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:46:22 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:46:22 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:46:23 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:46:23 --> Session Class Initialized
DEBUG - 2016-08-31 10:46:23 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:46:23 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:46:23 --> Session routines successfully run
DEBUG - 2016-08-31 10:46:23 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:46:23 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:46:23 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:46:23 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:46:23 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:46:23 --> Controller Class Initialized
DEBUG - 2016-08-31 10:46:23 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:46:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:46:23 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:46:23 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:46:23 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:46:23 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:46:23 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:23 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:23 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:23 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:23 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:23 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:23 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:23 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:23 --> Model Class Initialized
DEBUG - 2016-08-31 10:46:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 10:46:23 --> Pagination Class Initialized
DEBUG - 2016-08-31 10:46:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 10:46:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-31 10:46:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:46:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:46:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:46:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:46:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 10:46:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:46:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:46:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:46:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:46:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:46:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:46:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 10:46:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:46:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:46:24 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-31 10:46:24 --> Final output sent to browser
DEBUG - 2016-08-31 10:46:24 --> Total execution time: 2.4632
DEBUG - 2016-08-31 10:47:01 --> Config Class Initialized
DEBUG - 2016-08-31 10:47:01 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:47:01 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:47:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:47:01 --> URI Class Initialized
DEBUG - 2016-08-31 10:47:01 --> Router Class Initialized
DEBUG - 2016-08-31 10:47:01 --> No URI present. Default controller set.
DEBUG - 2016-08-31 10:47:01 --> Output Class Initialized
DEBUG - 2016-08-31 10:47:01 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 10:47:01 --> Security Class Initialized
DEBUG - 2016-08-31 10:47:01 --> Input Class Initialized
DEBUG - 2016-08-31 10:47:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:47:01 --> Language Class Initialized
DEBUG - 2016-08-31 10:47:01 --> Loader Class Initialized
DEBUG - 2016-08-31 10:47:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:47:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:47:01 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:47:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:47:01 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:47:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:47:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:47:01 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:47:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:47:02 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:47:02 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:47:02 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:47:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:47:02 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:47:02 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:47:02 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:47:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:47:02 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:47:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:47:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:47:02 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:47:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:47:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:47:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:47:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:47:02 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:47:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:47:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:47:02 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:47:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:47:02 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:47:02 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:47:02 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:47:02 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:47:02 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:47:02 --> Session Class Initialized
DEBUG - 2016-08-31 10:47:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:47:02 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:47:02 --> A session cookie was not found.
DEBUG - 2016-08-31 10:47:03 --> Session routines successfully run
DEBUG - 2016-08-31 10:47:03 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:47:03 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:47:03 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:47:03 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:47:03 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:47:03 --> Controller Class Initialized
DEBUG - 2016-08-31 10:47:03 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:47:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:47:03 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:47:03 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:47:03 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:47:03 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:47:03 --> Model Class Initialized
DEBUG - 2016-08-31 10:47:03 --> Model Class Initialized
DEBUG - 2016-08-31 10:47:03 --> Model Class Initialized
DEBUG - 2016-08-31 10:47:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-08-31 10:47:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:47:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:47:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:47:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:47:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:47:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:47:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:47:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:47:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:47:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:47:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:47:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:47:03 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-08-31 10:47:03 --> Final output sent to browser
DEBUG - 2016-08-31 10:47:03 --> Total execution time: 2.1629
DEBUG - 2016-08-31 10:48:17 --> Config Class Initialized
DEBUG - 2016-08-31 10:48:17 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:48:17 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:48:17 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:48:17 --> URI Class Initialized
DEBUG - 2016-08-31 10:48:17 --> Router Class Initialized
DEBUG - 2016-08-31 10:48:17 --> Output Class Initialized
DEBUG - 2016-08-31 10:48:17 --> Security Class Initialized
DEBUG - 2016-08-31 10:48:17 --> Input Class Initialized
DEBUG - 2016-08-31 10:48:18 --> XSS Filtering completed
DEBUG - 2016-08-31 10:48:18 --> XSS Filtering completed
DEBUG - 2016-08-31 10:48:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:48:18 --> Language Class Initialized
DEBUG - 2016-08-31 10:48:18 --> Loader Class Initialized
DEBUG - 2016-08-31 10:48:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:48:18 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:48:18 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:48:18 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:48:18 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:48:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:48:18 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:48:18 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:48:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:48:18 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:48:18 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:48:18 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:48:18 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:48:18 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:48:18 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:48:18 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:48:18 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:48:18 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:48:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:48:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:48:18 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:48:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:48:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:48:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:48:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:48:18 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:48:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:48:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:48:19 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:48:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:48:19 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:48:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:48:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:48:19 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:48:19 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:48:19 --> Session Class Initialized
DEBUG - 2016-08-31 10:48:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:48:19 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:48:19 --> Session routines successfully run
DEBUG - 2016-08-31 10:48:19 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:48:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:48:19 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:48:19 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:48:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:48:19 --> Controller Class Initialized
DEBUG - 2016-08-31 10:48:19 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:48:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:48:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:48:19 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:48:19 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:48:19 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:48:19 --> Model Class Initialized
DEBUG - 2016-08-31 10:48:19 --> Model Class Initialized
DEBUG - 2016-08-31 10:48:19 --> Model Class Initialized
DEBUG - 2016-08-31 10:48:19 --> Model Class Initialized
DEBUG - 2016-08-31 10:48:19 --> Model Class Initialized
DEBUG - 2016-08-31 10:48:19 --> Model Class Initialized
DEBUG - 2016-08-31 10:48:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 10:48:20 --> Pagination Class Initialized
DEBUG - 2016-08-31 10:48:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 10:48:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-31 10:48:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:48:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:48:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:48:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:48:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 10:48:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:48:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:48:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:48:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:48:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:48:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:48:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 10:48:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:48:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:48:20 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-08-31 10:48:20 --> Final output sent to browser
DEBUG - 2016-08-31 10:48:20 --> Total execution time: 2.3648
DEBUG - 2016-08-31 10:48:23 --> Config Class Initialized
DEBUG - 2016-08-31 10:48:23 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:48:23 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:48:23 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:48:23 --> URI Class Initialized
DEBUG - 2016-08-31 10:48:23 --> Router Class Initialized
DEBUG - 2016-08-31 10:48:23 --> Output Class Initialized
DEBUG - 2016-08-31 10:48:23 --> Security Class Initialized
DEBUG - 2016-08-31 10:48:23 --> Input Class Initialized
DEBUG - 2016-08-31 10:48:23 --> XSS Filtering completed
DEBUG - 2016-08-31 10:48:23 --> XSS Filtering completed
DEBUG - 2016-08-31 10:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:48:23 --> Language Class Initialized
DEBUG - 2016-08-31 10:48:23 --> Loader Class Initialized
DEBUG - 2016-08-31 10:48:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:48:23 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:48:23 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:48:23 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:48:23 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:48:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:48:23 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:48:23 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:48:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:48:23 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:48:23 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:48:23 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:48:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:48:23 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:48:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:48:23 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:48:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:48:23 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:48:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:48:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:48:24 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:48:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:48:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:48:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:48:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:48:24 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:48:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:48:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:48:24 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:48:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:48:24 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:48:24 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:48:24 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:48:24 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:48:24 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:48:24 --> Session Class Initialized
DEBUG - 2016-08-31 10:48:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:48:24 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:48:24 --> Session routines successfully run
DEBUG - 2016-08-31 10:48:24 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:48:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:48:24 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:48:24 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:48:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:48:24 --> Controller Class Initialized
DEBUG - 2016-08-31 10:48:24 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:48:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:48:24 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:48:25 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:48:25 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:48:25 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:48:25 --> Model Class Initialized
DEBUG - 2016-08-31 10:48:25 --> Model Class Initialized
DEBUG - 2016-08-31 10:48:25 --> Model Class Initialized
DEBUG - 2016-08-31 10:48:25 --> Model Class Initialized
DEBUG - 2016-08-31 10:48:25 --> Model Class Initialized
DEBUG - 2016-08-31 10:48:25 --> Model Class Initialized
DEBUG - 2016-08-31 10:48:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 10:48:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/detail.php
DEBUG - 2016-08-31 10:48:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:48:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:48:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:48:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:48:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_js.php
DEBUG - 2016-08-31 10:48:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_isian_js.php
DEBUG - 2016-08-31 10:48:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:48:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:48:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:48:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:48:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:48:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:48:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_js.php
DEBUG - 2016-08-31 10:48:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_isian_js.php
DEBUG - 2016-08-31 10:48:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:48:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:48:25 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0f29ea8129c887603d77c24cae51d39d
DEBUG - 2016-08-31 10:48:25 --> Final output sent to browser
DEBUG - 2016-08-31 10:48:25 --> Total execution time: 2.3339
DEBUG - 2016-08-31 10:49:19 --> Config Class Initialized
DEBUG - 2016-08-31 10:49:20 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:49:20 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:49:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:49:20 --> URI Class Initialized
DEBUG - 2016-08-31 10:49:20 --> Router Class Initialized
DEBUG - 2016-08-31 10:49:20 --> Output Class Initialized
DEBUG - 2016-08-31 10:49:20 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 10:49:20 --> Security Class Initialized
DEBUG - 2016-08-31 10:49:20 --> Input Class Initialized
DEBUG - 2016-08-31 10:49:20 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:20 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:20 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:49:20 --> Language Class Initialized
DEBUG - 2016-08-31 10:49:20 --> Loader Class Initialized
DEBUG - 2016-08-31 10:49:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:49:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:49:20 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:49:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:49:20 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:49:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:49:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:49:20 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:49:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:49:20 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:49:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:49:20 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:49:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:49:20 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:49:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:49:20 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:49:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:49:21 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:49:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:49:21 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:49:21 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:49:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:49:21 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:49:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:49:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:49:21 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:49:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:49:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:49:21 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:49:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:49:21 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:49:21 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:49:21 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:49:21 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:49:21 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:49:21 --> Session Class Initialized
DEBUG - 2016-08-31 10:49:21 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:49:21 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:49:21 --> Session routines successfully run
DEBUG - 2016-08-31 10:49:21 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:49:21 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:49:21 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:49:21 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:49:21 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:49:21 --> Controller Class Initialized
DEBUG - 2016-08-31 10:49:21 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:49:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:49:21 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:49:22 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:49:22 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:49:22 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:49:22 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:22 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:22 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:22 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:22 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:22 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b5e3eebbe550cd93afc20ddd83908c3b
DEBUG - 2016-08-31 10:49:22 --> Final output sent to browser
DEBUG - 2016-08-31 10:49:22 --> Total execution time: 2.3550
DEBUG - 2016-08-31 10:49:26 --> Config Class Initialized
DEBUG - 2016-08-31 10:49:26 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:49:26 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:49:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:49:26 --> URI Class Initialized
DEBUG - 2016-08-31 10:49:26 --> Router Class Initialized
DEBUG - 2016-08-31 10:49:26 --> Output Class Initialized
DEBUG - 2016-08-31 10:49:26 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 10:49:26 --> Security Class Initialized
DEBUG - 2016-08-31 10:49:26 --> Input Class Initialized
DEBUG - 2016-08-31 10:49:26 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:26 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:26 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:49:26 --> Language Class Initialized
DEBUG - 2016-08-31 10:49:26 --> Loader Class Initialized
DEBUG - 2016-08-31 10:49:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:49:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:49:26 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:49:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:49:26 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:49:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:49:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:49:26 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:49:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:49:26 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:49:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:49:27 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:49:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:49:27 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:49:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:49:27 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:49:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:49:27 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:49:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:49:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:49:27 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:49:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:49:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:49:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:49:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:49:27 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:49:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:49:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:49:27 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:49:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:49:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:49:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:49:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:49:27 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:49:27 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:49:27 --> Session Class Initialized
DEBUG - 2016-08-31 10:49:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:49:27 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:49:28 --> Session routines successfully run
DEBUG - 2016-08-31 10:49:28 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:49:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:49:28 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:49:28 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:49:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:49:28 --> Controller Class Initialized
DEBUG - 2016-08-31 10:49:28 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:49:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:49:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:49:28 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:49:28 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:49:28 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:49:28 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:28 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:28 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:28 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:28 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:28 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1ae1cad65d2be9e2d395bd427adbef6f
DEBUG - 2016-08-31 10:49:28 --> Final output sent to browser
DEBUG - 2016-08-31 10:49:28 --> Total execution time: 2.4456
DEBUG - 2016-08-31 10:49:38 --> Config Class Initialized
DEBUG - 2016-08-31 10:49:38 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:49:38 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:49:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:49:38 --> URI Class Initialized
DEBUG - 2016-08-31 10:49:38 --> Router Class Initialized
DEBUG - 2016-08-31 10:49:38 --> Output Class Initialized
DEBUG - 2016-08-31 10:49:38 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 10:49:38 --> Security Class Initialized
DEBUG - 2016-08-31 10:49:38 --> Input Class Initialized
DEBUG - 2016-08-31 10:49:38 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:38 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:38 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:49:38 --> Language Class Initialized
DEBUG - 2016-08-31 10:49:38 --> Loader Class Initialized
DEBUG - 2016-08-31 10:49:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:49:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:49:38 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:49:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:49:38 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:49:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:49:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:49:38 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:49:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:49:38 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:49:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:49:38 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:49:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:49:38 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:49:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:49:39 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:49:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:49:39 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:49:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:49:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:49:39 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:49:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:49:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:49:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:49:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:49:39 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:49:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:49:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:49:39 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:49:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:49:39 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:49:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:49:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:49:39 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:49:39 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:49:39 --> Session Class Initialized
DEBUG - 2016-08-31 10:49:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:49:39 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:49:39 --> Session routines successfully run
DEBUG - 2016-08-31 10:49:39 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:49:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:49:39 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:49:39 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:49:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:49:39 --> Controller Class Initialized
DEBUG - 2016-08-31 10:49:40 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:49:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:49:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:49:40 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:49:40 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:49:40 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:49:40 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:40 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:40 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:40 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:40 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/3986b17e67923511ff75332baca04769
DEBUG - 2016-08-31 10:49:40 --> Final output sent to browser
DEBUG - 2016-08-31 10:49:40 --> Total execution time: 2.3297
DEBUG - 2016-08-31 10:49:46 --> Config Class Initialized
DEBUG - 2016-08-31 10:49:46 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:49:46 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:49:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:49:46 --> URI Class Initialized
DEBUG - 2016-08-31 10:49:46 --> Router Class Initialized
DEBUG - 2016-08-31 10:49:46 --> Output Class Initialized
DEBUG - 2016-08-31 10:49:46 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 10:49:46 --> Security Class Initialized
DEBUG - 2016-08-31 10:49:47 --> Input Class Initialized
DEBUG - 2016-08-31 10:49:47 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:47 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:47 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:47 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:47 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:47 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:47 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:47 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:47 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:47 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:47 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:47 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:47 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:47 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:47 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:49:47 --> Language Class Initialized
DEBUG - 2016-08-31 10:49:47 --> Loader Class Initialized
DEBUG - 2016-08-31 10:49:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:49:47 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:49:47 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:49:47 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:49:47 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:49:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:49:47 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:49:47 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:49:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:49:47 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:49:47 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:49:47 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:49:47 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:49:48 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:49:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:49:48 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:49:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:49:48 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:49:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:49:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:49:48 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:49:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:49:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:49:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:49:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:49:48 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:49:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:49:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:49:48 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:49:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:49:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:49:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:49:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:49:48 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:49:48 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:49:48 --> Session Class Initialized
DEBUG - 2016-08-31 10:49:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:49:48 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:49:48 --> Session routines successfully run
DEBUG - 2016-08-31 10:49:48 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:49:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:49:48 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:49:48 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:49:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:49:49 --> Controller Class Initialized
DEBUG - 2016-08-31 10:49:49 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:49:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:49:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:49:49 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:49:49 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:49:49 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:49:49 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:49 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:49 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:49 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:49 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:49 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 10:49:49 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:49:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:49:49 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-08-31 10:49:49 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:49 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:49 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:49 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:49 --> Config Class Initialized
DEBUG - 2016-08-31 10:49:49 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:49:49 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:49:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:49:49 --> URI Class Initialized
DEBUG - 2016-08-31 10:49:49 --> Router Class Initialized
DEBUG - 2016-08-31 10:49:50 --> Output Class Initialized
DEBUG - 2016-08-31 10:49:50 --> Security Class Initialized
DEBUG - 2016-08-31 10:49:50 --> Input Class Initialized
DEBUG - 2016-08-31 10:49:50 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:50 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:49:50 --> Language Class Initialized
DEBUG - 2016-08-31 10:49:50 --> Loader Class Initialized
DEBUG - 2016-08-31 10:49:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:49:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:49:50 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:49:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:49:50 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:49:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:49:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:49:50 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:49:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:49:50 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:49:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:49:50 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:49:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:49:50 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:49:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:49:50 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:49:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:49:50 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:49:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:49:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:49:50 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:49:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:49:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:49:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:49:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:49:51 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:49:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:49:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:49:51 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:49:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:49:51 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:49:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:49:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:49:51 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:49:51 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:49:51 --> Session Class Initialized
DEBUG - 2016-08-31 10:49:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:49:51 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:49:51 --> Session routines successfully run
DEBUG - 2016-08-31 10:49:51 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:49:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:49:51 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:49:51 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:49:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:49:51 --> Controller Class Initialized
DEBUG - 2016-08-31 10:49:51 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:49:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:49:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:49:51 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:49:51 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:49:51 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:49:51 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:51 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:51 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:52 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:52 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:52 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:52 --> Config Class Initialized
DEBUG - 2016-08-31 10:49:52 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:49:52 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:49:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:49:52 --> URI Class Initialized
DEBUG - 2016-08-31 10:49:52 --> Router Class Initialized
DEBUG - 2016-08-31 10:49:52 --> Output Class Initialized
DEBUG - 2016-08-31 10:49:52 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 10:49:52 --> Security Class Initialized
DEBUG - 2016-08-31 10:49:52 --> Input Class Initialized
DEBUG - 2016-08-31 10:49:52 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:52 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:49:52 --> Language Class Initialized
DEBUG - 2016-08-31 10:49:52 --> Loader Class Initialized
DEBUG - 2016-08-31 10:49:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:49:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:49:52 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:49:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:49:52 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:49:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:49:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:49:52 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:49:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:49:52 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:49:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:49:52 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:49:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:49:53 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:49:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:49:53 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:49:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:49:53 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:49:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:49:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:49:53 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:49:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:49:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:49:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:49:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:49:53 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:49:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:49:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:49:53 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:49:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:49:53 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:49:53 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:49:53 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:49:53 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:49:53 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:49:53 --> Session Class Initialized
DEBUG - 2016-08-31 10:49:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:49:53 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:49:53 --> Session routines successfully run
DEBUG - 2016-08-31 10:49:53 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:49:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:49:53 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:49:53 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:49:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:49:54 --> Controller Class Initialized
DEBUG - 2016-08-31 10:49:54 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:49:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:49:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:49:54 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:49:54 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:49:54 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:49:54 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:54 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:54 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:54 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:54 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:54 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:54 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:54 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:54 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 10:49:54 --> Pagination Class Initialized
DEBUG - 2016-08-31 10:49:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 10:49:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-31 10:49:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:49:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:49:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:49:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:49:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 10:49:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:49:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:49:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:49:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:49:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:49:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:49:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 10:49:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:49:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:49:55 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-31 10:49:55 --> Final output sent to browser
DEBUG - 2016-08-31 10:49:55 --> Total execution time: 2.5591
DEBUG - 2016-08-31 10:49:55 --> Config Class Initialized
DEBUG - 2016-08-31 10:49:55 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:49:55 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:49:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:49:55 --> URI Class Initialized
DEBUG - 2016-08-31 10:49:55 --> Router Class Initialized
DEBUG - 2016-08-31 10:49:55 --> Output Class Initialized
DEBUG - 2016-08-31 10:49:55 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 10:49:55 --> Security Class Initialized
DEBUG - 2016-08-31 10:49:55 --> Input Class Initialized
DEBUG - 2016-08-31 10:49:55 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:55 --> XSS Filtering completed
DEBUG - 2016-08-31 10:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:49:55 --> Language Class Initialized
DEBUG - 2016-08-31 10:49:55 --> Loader Class Initialized
DEBUG - 2016-08-31 10:49:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:49:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:49:55 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:49:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:49:55 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:49:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:49:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:49:56 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:49:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:49:56 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:49:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:49:56 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:49:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:49:56 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:49:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:49:56 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:49:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:49:56 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:49:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:49:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:49:56 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:49:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:49:56 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:49:56 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:49:56 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:49:56 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:49:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:49:56 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:49:56 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:49:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:49:56 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:49:56 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:49:56 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:49:56 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:49:56 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:49:57 --> Session Class Initialized
DEBUG - 2016-08-31 10:49:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:49:57 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:49:57 --> Session routines successfully run
DEBUG - 2016-08-31 10:49:57 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:49:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:49:57 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:49:57 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:49:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:49:57 --> Controller Class Initialized
DEBUG - 2016-08-31 10:49:57 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:49:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:49:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:49:57 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:49:57 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:49:57 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:49:57 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:57 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:57 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:57 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:57 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:57 --> Model Class Initialized
DEBUG - 2016-08-31 10:49:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 10:49:57 --> Pagination Class Initialized
DEBUG - 2016-08-31 10:49:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 10:49:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-31 10:49:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:49:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:49:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:49:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:49:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 10:49:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:49:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:49:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:49:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:49:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:49:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:49:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 10:49:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:49:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:49:58 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-08-31 10:49:58 --> Final output sent to browser
DEBUG - 2016-08-31 10:49:58 --> Total execution time: 2.5455
DEBUG - 2016-08-31 10:53:37 --> Config Class Initialized
DEBUG - 2016-08-31 10:53:37 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:53:37 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:53:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:53:37 --> URI Class Initialized
DEBUG - 2016-08-31 10:53:37 --> Router Class Initialized
DEBUG - 2016-08-31 10:53:37 --> Output Class Initialized
DEBUG - 2016-08-31 10:53:37 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 10:53:37 --> Security Class Initialized
DEBUG - 2016-08-31 10:53:37 --> Input Class Initialized
DEBUG - 2016-08-31 10:53:37 --> XSS Filtering completed
DEBUG - 2016-08-31 10:53:37 --> XSS Filtering completed
DEBUG - 2016-08-31 10:53:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:53:37 --> Language Class Initialized
DEBUG - 2016-08-31 10:53:37 --> Loader Class Initialized
DEBUG - 2016-08-31 10:53:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:53:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:53:37 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:53:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:53:37 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:53:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:53:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:53:37 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:53:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:53:38 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:53:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:53:38 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:53:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:53:38 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:53:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:53:38 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:53:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:53:38 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:53:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:53:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:53:38 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:53:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:53:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:53:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:53:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:53:38 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:53:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:53:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:53:38 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:53:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:53:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:53:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:53:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:53:38 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:53:38 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:53:38 --> Session Class Initialized
DEBUG - 2016-08-31 10:53:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:53:38 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:53:38 --> Session routines successfully run
DEBUG - 2016-08-31 10:53:39 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:53:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:53:39 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:53:39 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:53:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:53:39 --> Controller Class Initialized
DEBUG - 2016-08-31 10:53:39 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:53:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:53:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:53:39 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:53:39 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:53:39 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:53:39 --> Model Class Initialized
DEBUG - 2016-08-31 10:53:39 --> Model Class Initialized
DEBUG - 2016-08-31 10:53:39 --> Model Class Initialized
DEBUG - 2016-08-31 10:53:39 --> Model Class Initialized
DEBUG - 2016-08-31 10:53:39 --> Model Class Initialized
DEBUG - 2016-08-31 10:53:39 --> Model Class Initialized
DEBUG - 2016-08-31 10:53:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 10:53:39 --> Pagination Class Initialized
DEBUG - 2016-08-31 10:53:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 10:53:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-08-31 10:53:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:53:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:53:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:53:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:53:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 10:53:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:53:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:53:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:53:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:53:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:53:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:53:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-08-31 10:53:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:53:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:53:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-08-31 10:53:40 --> Final output sent to browser
DEBUG - 2016-08-31 10:53:40 --> Total execution time: 2.5703
DEBUG - 2016-08-31 10:53:44 --> Config Class Initialized
DEBUG - 2016-08-31 10:53:44 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:53:44 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:53:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:53:44 --> URI Class Initialized
DEBUG - 2016-08-31 10:53:44 --> Router Class Initialized
DEBUG - 2016-08-31 10:53:44 --> Output Class Initialized
DEBUG - 2016-08-31 10:53:44 --> Security Class Initialized
DEBUG - 2016-08-31 10:53:44 --> Input Class Initialized
DEBUG - 2016-08-31 10:53:44 --> XSS Filtering completed
DEBUG - 2016-08-31 10:53:44 --> XSS Filtering completed
DEBUG - 2016-08-31 10:53:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:53:45 --> Language Class Initialized
DEBUG - 2016-08-31 10:53:45 --> Loader Class Initialized
DEBUG - 2016-08-31 10:53:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:53:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:53:45 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:53:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:53:45 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:53:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:53:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:53:45 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:53:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:53:45 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:53:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:53:45 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:53:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:53:45 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:53:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:53:45 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:53:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:53:45 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:53:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:53:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:53:45 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:53:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:53:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:53:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:53:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:53:45 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:53:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:53:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:53:46 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:53:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:53:46 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:53:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:53:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:53:46 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:53:46 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:53:46 --> Session Class Initialized
DEBUG - 2016-08-31 10:53:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:53:46 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:53:46 --> Session routines successfully run
DEBUG - 2016-08-31 10:53:46 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:53:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:53:46 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:53:46 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:53:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:53:46 --> Controller Class Initialized
DEBUG - 2016-08-31 10:53:46 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:53:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:53:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:53:46 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:53:46 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:53:46 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:53:46 --> Model Class Initialized
DEBUG - 2016-08-31 10:53:46 --> Model Class Initialized
DEBUG - 2016-08-31 10:53:46 --> Model Class Initialized
DEBUG - 2016-08-31 10:53:47 --> Model Class Initialized
DEBUG - 2016-08-31 10:53:47 --> Model Class Initialized
DEBUG - 2016-08-31 10:53:47 --> Model Class Initialized
DEBUG - 2016-08-31 10:53:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 10:53:47 --> Pagination Class Initialized
DEBUG - 2016-08-31 10:53:47 --> Model Class Initialized
DEBUG - 2016-08-31 10:53:47 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 10:53:47 --> Model Class Initialized
DEBUG - 2016-08-31 10:53:47 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 10:53:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-31 10:53:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-31 10:53:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-31 10:53:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-31 10:53:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:53:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:53:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:53:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:53:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-31 10:53:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:53:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:53:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:53:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:53:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:53:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:53:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-31 10:53:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:53:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:53:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/3b8a012aded2aa06b38d95457bf1daeb
DEBUG - 2016-08-31 10:53:48 --> Final output sent to browser
DEBUG - 2016-08-31 10:53:48 --> Total execution time: 2.7180
DEBUG - 2016-08-31 10:56:03 --> Config Class Initialized
DEBUG - 2016-08-31 10:56:03 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:56:03 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:56:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:56:03 --> URI Class Initialized
DEBUG - 2016-08-31 10:56:03 --> Router Class Initialized
DEBUG - 2016-08-31 10:56:03 --> Output Class Initialized
DEBUG - 2016-08-31 10:56:03 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 10:56:03 --> Security Class Initialized
DEBUG - 2016-08-31 10:56:03 --> Input Class Initialized
DEBUG - 2016-08-31 10:56:03 --> XSS Filtering completed
DEBUG - 2016-08-31 10:56:03 --> XSS Filtering completed
DEBUG - 2016-08-31 10:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:56:03 --> Language Class Initialized
DEBUG - 2016-08-31 10:56:03 --> Loader Class Initialized
DEBUG - 2016-08-31 10:56:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:56:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:56:03 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:56:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:56:04 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:56:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:56:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:56:04 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:56:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:56:04 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:56:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:56:04 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:56:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:56:04 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:56:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:56:04 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:56:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:56:04 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:56:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:56:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:56:04 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:56:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:56:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:56:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:56:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:56:04 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:56:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:56:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:56:04 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:56:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:56:04 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:56:04 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:56:04 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:56:04 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:56:05 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:56:05 --> Session Class Initialized
DEBUG - 2016-08-31 10:56:05 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:56:05 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:56:05 --> Session routines successfully run
DEBUG - 2016-08-31 10:56:05 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:56:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:56:05 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:56:05 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:56:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:56:05 --> Controller Class Initialized
DEBUG - 2016-08-31 10:56:05 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:56:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:56:05 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:56:05 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:56:05 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:56:05 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:56:05 --> Model Class Initialized
DEBUG - 2016-08-31 10:56:05 --> Model Class Initialized
DEBUG - 2016-08-31 10:56:05 --> Model Class Initialized
DEBUG - 2016-08-31 10:56:05 --> Model Class Initialized
DEBUG - 2016-08-31 10:56:05 --> Model Class Initialized
DEBUG - 2016-08-31 10:56:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 10:56:05 --> Pagination Class Initialized
DEBUG - 2016-08-31 10:56:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 10:56:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/index.php
DEBUG - 2016-08-31 10:56:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:56:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:56:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:56:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:56:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-08-31 10:56:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:56:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:56:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:56:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:56:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:56:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:56:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-08-31 10:56:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:56:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:56:06 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c2a3e0401bd35d4fcac4bae5f9412231
DEBUG - 2016-08-31 10:56:06 --> Final output sent to browser
DEBUG - 2016-08-31 10:56:06 --> Total execution time: 2.5817
DEBUG - 2016-08-31 10:56:11 --> Config Class Initialized
DEBUG - 2016-08-31 10:56:12 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:56:12 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:56:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:56:12 --> URI Class Initialized
DEBUG - 2016-08-31 10:56:12 --> Router Class Initialized
DEBUG - 2016-08-31 10:56:12 --> Output Class Initialized
DEBUG - 2016-08-31 10:56:12 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 10:56:12 --> Security Class Initialized
DEBUG - 2016-08-31 10:56:12 --> Input Class Initialized
DEBUG - 2016-08-31 10:56:12 --> XSS Filtering completed
DEBUG - 2016-08-31 10:56:12 --> XSS Filtering completed
DEBUG - 2016-08-31 10:56:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:56:12 --> Language Class Initialized
DEBUG - 2016-08-31 10:56:12 --> Loader Class Initialized
DEBUG - 2016-08-31 10:56:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:56:12 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:56:12 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:56:12 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:56:12 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:56:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:56:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:56:12 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:56:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:56:12 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:56:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:56:12 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:56:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:56:12 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:56:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:56:12 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:56:13 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:56:13 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:56:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:56:13 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:56:13 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:56:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:56:13 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:56:13 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:56:13 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:56:13 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:56:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:56:13 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:56:13 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:56:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:56:13 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:56:13 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:56:13 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:56:13 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:56:13 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:56:13 --> Session Class Initialized
DEBUG - 2016-08-31 10:56:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:56:13 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:56:13 --> Session routines successfully run
DEBUG - 2016-08-31 10:56:13 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:56:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:56:13 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:56:13 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:56:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:56:14 --> Controller Class Initialized
DEBUG - 2016-08-31 10:56:14 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:56:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:56:14 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:56:14 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:56:14 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:56:14 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:56:14 --> Model Class Initialized
DEBUG - 2016-08-31 10:56:14 --> Model Class Initialized
DEBUG - 2016-08-31 10:56:14 --> Model Class Initialized
DEBUG - 2016-08-31 10:56:14 --> Model Class Initialized
DEBUG - 2016-08-31 10:56:14 --> Model Class Initialized
DEBUG - 2016-08-31 10:56:14 --> Model Class Initialized
DEBUG - 2016-08-31 10:56:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 10:56:14 --> Pagination Class Initialized
DEBUG - 2016-08-31 10:56:14 --> Model Class Initialized
DEBUG - 2016-08-31 10:56:14 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 10:56:14 --> Model Class Initialized
DEBUG - 2016-08-31 10:56:14 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 10:56:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-31 10:56:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-31 10:56:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-31 10:56:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-31 10:56:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:56:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:56:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:56:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:56:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-31 10:56:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:56:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:56:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:56:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:56:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:56:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:56:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-31 10:56:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:56:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:56:15 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-31 10:56:15 --> Final output sent to browser
DEBUG - 2016-08-31 10:56:15 --> Total execution time: 2.7566
DEBUG - 2016-08-31 10:56:38 --> Config Class Initialized
DEBUG - 2016-08-31 10:56:38 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:56:38 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:56:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:56:38 --> URI Class Initialized
DEBUG - 2016-08-31 10:56:38 --> Router Class Initialized
DEBUG - 2016-08-31 10:56:38 --> Output Class Initialized
DEBUG - 2016-08-31 10:56:38 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 10:56:38 --> Security Class Initialized
DEBUG - 2016-08-31 10:56:38 --> Input Class Initialized
DEBUG - 2016-08-31 10:56:38 --> XSS Filtering completed
DEBUG - 2016-08-31 10:56:38 --> XSS Filtering completed
DEBUG - 2016-08-31 10:56:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:56:38 --> Language Class Initialized
DEBUG - 2016-08-31 10:56:38 --> Loader Class Initialized
DEBUG - 2016-08-31 10:56:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:56:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:56:38 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:56:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:56:38 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:56:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:56:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:56:38 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:56:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:56:38 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:56:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:56:38 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:56:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:56:38 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:56:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:56:39 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:56:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:56:39 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:56:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:56:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:56:39 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:56:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:56:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:56:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:56:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:56:39 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:56:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:56:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:56:39 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:56:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:56:39 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:56:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:56:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:56:39 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:56:39 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:56:39 --> Session Class Initialized
DEBUG - 2016-08-31 10:56:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:56:39 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:56:39 --> Session routines successfully run
DEBUG - 2016-08-31 10:56:39 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:56:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:56:39 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:56:40 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:56:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:56:40 --> Controller Class Initialized
DEBUG - 2016-08-31 10:56:40 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:56:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:56:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:56:40 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:56:40 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:56:40 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:56:40 --> Model Class Initialized
DEBUG - 2016-08-31 10:56:40 --> Model Class Initialized
DEBUG - 2016-08-31 10:56:40 --> Model Class Initialized
DEBUG - 2016-08-31 10:56:40 --> Model Class Initialized
DEBUG - 2016-08-31 10:56:40 --> Model Class Initialized
DEBUG - 2016-08-31 10:56:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 10:56:40 --> Pagination Class Initialized
DEBUG - 2016-08-31 10:56:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 10:56:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/index.php
DEBUG - 2016-08-31 10:56:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:56:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:56:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:56:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:56:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-08-31 10:56:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:56:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:56:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:56:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:56:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:56:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:56:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-08-31 10:56:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:56:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:56:41 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c2a3e0401bd35d4fcac4bae5f9412231
DEBUG - 2016-08-31 10:56:41 --> Final output sent to browser
DEBUG - 2016-08-31 10:56:41 --> Total execution time: 2.6187
DEBUG - 2016-08-31 10:56:45 --> Config Class Initialized
DEBUG - 2016-08-31 10:56:45 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:56:45 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:56:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:56:45 --> URI Class Initialized
DEBUG - 2016-08-31 10:56:45 --> Router Class Initialized
DEBUG - 2016-08-31 10:56:45 --> Output Class Initialized
DEBUG - 2016-08-31 10:56:45 --> Security Class Initialized
DEBUG - 2016-08-31 10:56:45 --> Input Class Initialized
DEBUG - 2016-08-31 10:56:45 --> XSS Filtering completed
DEBUG - 2016-08-31 10:56:45 --> XSS Filtering completed
DEBUG - 2016-08-31 10:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:56:45 --> Language Class Initialized
DEBUG - 2016-08-31 10:56:45 --> Loader Class Initialized
DEBUG - 2016-08-31 10:56:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:56:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:56:46 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:56:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:56:46 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:56:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:56:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:56:46 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:56:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:56:46 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:56:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:56:46 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:56:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:56:46 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:56:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:56:46 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:56:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:56:46 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:56:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:56:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:56:46 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:56:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:56:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:56:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:56:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:56:46 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:56:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:56:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:56:46 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:56:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:56:47 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:56:47 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:56:47 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:56:47 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:56:47 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:56:47 --> Session Class Initialized
DEBUG - 2016-08-31 10:56:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:56:47 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:56:47 --> Session routines successfully run
DEBUG - 2016-08-31 10:56:47 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:56:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:56:47 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:56:47 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:56:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:56:47 --> Controller Class Initialized
DEBUG - 2016-08-31 10:56:47 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:56:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:56:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:56:47 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:56:47 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:56:47 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:56:47 --> Model Class Initialized
DEBUG - 2016-08-31 10:56:47 --> Model Class Initialized
DEBUG - 2016-08-31 10:56:47 --> Model Class Initialized
DEBUG - 2016-08-31 10:56:47 --> Model Class Initialized
DEBUG - 2016-08-31 10:56:47 --> Model Class Initialized
DEBUG - 2016-08-31 10:56:47 --> Model Class Initialized
DEBUG - 2016-08-31 10:56:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 10:56:48 --> Pagination Class Initialized
DEBUG - 2016-08-31 10:56:48 --> Model Class Initialized
DEBUG - 2016-08-31 10:56:48 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 10:56:48 --> Model Class Initialized
DEBUG - 2016-08-31 10:56:48 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 10:56:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-31 10:56:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-31 10:56:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-31 10:56:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-31 10:56:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:56:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:56:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:56:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:56:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-31 10:56:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:56:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:56:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:56:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:56:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:56:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:56:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-31 10:56:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:56:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:56:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/960a658c6234ab9b853a49790042bcbe
DEBUG - 2016-08-31 10:56:48 --> Final output sent to browser
DEBUG - 2016-08-31 10:56:48 --> Total execution time: 2.7678
DEBUG - 2016-08-31 10:59:44 --> Config Class Initialized
DEBUG - 2016-08-31 10:59:44 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:59:44 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:59:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:59:44 --> URI Class Initialized
DEBUG - 2016-08-31 10:59:44 --> Router Class Initialized
DEBUG - 2016-08-31 10:59:44 --> Output Class Initialized
DEBUG - 2016-08-31 10:59:44 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 10:59:44 --> Security Class Initialized
DEBUG - 2016-08-31 10:59:44 --> Input Class Initialized
DEBUG - 2016-08-31 10:59:44 --> XSS Filtering completed
DEBUG - 2016-08-31 10:59:44 --> XSS Filtering completed
DEBUG - 2016-08-31 10:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:59:44 --> Language Class Initialized
DEBUG - 2016-08-31 10:59:44 --> Loader Class Initialized
DEBUG - 2016-08-31 10:59:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:59:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:59:44 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:59:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:59:44 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:59:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:59:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:59:45 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:59:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:59:45 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:59:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:59:45 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:59:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:59:45 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:59:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:59:45 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:59:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:59:45 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:59:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:59:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:59:45 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:59:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:59:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:59:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:59:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:59:45 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:59:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:59:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:59:45 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:59:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:59:45 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:59:45 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:59:45 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:59:45 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:59:45 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:59:46 --> Session Class Initialized
DEBUG - 2016-08-31 10:59:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:59:46 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:59:46 --> Session routines successfully run
DEBUG - 2016-08-31 10:59:46 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:59:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:59:46 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:59:46 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:59:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:59:46 --> Controller Class Initialized
DEBUG - 2016-08-31 10:59:46 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:59:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:59:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:59:46 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:59:46 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:59:46 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:59:46 --> Model Class Initialized
DEBUG - 2016-08-31 10:59:46 --> Model Class Initialized
DEBUG - 2016-08-31 10:59:46 --> Model Class Initialized
DEBUG - 2016-08-31 10:59:46 --> Model Class Initialized
DEBUG - 2016-08-31 10:59:46 --> Model Class Initialized
DEBUG - 2016-08-31 10:59:46 --> Model Class Initialized
DEBUG - 2016-08-31 10:59:46 --> Model Class Initialized
DEBUG - 2016-08-31 10:59:46 --> Model Class Initialized
DEBUG - 2016-08-31 10:59:46 --> Model Class Initialized
DEBUG - 2016-08-31 10:59:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 10:59:47 --> Pagination Class Initialized
DEBUG - 2016-08-31 10:59:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 10:59:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-31 10:59:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:59:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:59:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:59:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:59:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 10:59:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:59:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:59:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 10:59:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 10:59:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 10:59:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 10:59:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-31 10:59:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 10:59:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 10:59:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-31 10:59:47 --> Final output sent to browser
DEBUG - 2016-08-31 10:59:47 --> Total execution time: 2.7617
DEBUG - 2016-08-31 10:59:52 --> Config Class Initialized
DEBUG - 2016-08-31 10:59:52 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:59:52 --> Utf8 Class Initialized
DEBUG - 2016-08-31 10:59:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 10:59:53 --> URI Class Initialized
DEBUG - 2016-08-31 10:59:53 --> Router Class Initialized
DEBUG - 2016-08-31 10:59:53 --> Output Class Initialized
DEBUG - 2016-08-31 10:59:53 --> Security Class Initialized
DEBUG - 2016-08-31 10:59:53 --> Input Class Initialized
DEBUG - 2016-08-31 10:59:53 --> XSS Filtering completed
DEBUG - 2016-08-31 10:59:53 --> XSS Filtering completed
DEBUG - 2016-08-31 10:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 10:59:53 --> Language Class Initialized
DEBUG - 2016-08-31 10:59:53 --> Loader Class Initialized
DEBUG - 2016-08-31 10:59:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 10:59:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 10:59:53 --> Helper loaded: url_helper
DEBUG - 2016-08-31 10:59:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 10:59:53 --> Helper loaded: file_helper
DEBUG - 2016-08-31 10:59:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:59:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 10:59:53 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 10:59:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 10:59:53 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 10:59:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 10:59:53 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:59:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 10:59:53 --> Helper loaded: common_helper
DEBUG - 2016-08-31 10:59:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 10:59:53 --> Helper loaded: form_helper
DEBUG - 2016-08-31 10:59:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 10:59:53 --> Helper loaded: security_helper
DEBUG - 2016-08-31 10:59:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:59:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 10:59:54 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 10:59:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 10:59:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 10:59:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 10:59:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 10:59:54 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 10:59:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:59:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 10:59:54 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 10:59:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 10:59:54 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 10:59:54 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 10:59:54 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 10:59:54 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 10:59:54 --> Database Driver Class Initialized
DEBUG - 2016-08-31 10:59:54 --> Session Class Initialized
DEBUG - 2016-08-31 10:59:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 10:59:54 --> Helper loaded: string_helper
DEBUG - 2016-08-31 10:59:54 --> Session routines successfully run
DEBUG - 2016-08-31 10:59:54 --> Native_session Class Initialized
DEBUG - 2016-08-31 10:59:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 10:59:54 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:59:54 --> Form Validation Class Initialized
DEBUG - 2016-08-31 10:59:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 10:59:54 --> Controller Class Initialized
DEBUG - 2016-08-31 10:59:54 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 10:59:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 10:59:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 10:59:55 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:59:55 --> Carabiner: library configured.
DEBUG - 2016-08-31 10:59:55 --> User Agent Class Initialized
DEBUG - 2016-08-31 10:59:55 --> Model Class Initialized
DEBUG - 2016-08-31 10:59:55 --> Model Class Initialized
DEBUG - 2016-08-31 10:59:55 --> Model Class Initialized
DEBUG - 2016-08-31 10:59:55 --> Model Class Initialized
DEBUG - 2016-08-31 10:59:55 --> Model Class Initialized
DEBUG - 2016-08-31 10:59:55 --> Model Class Initialized
DEBUG - 2016-08-31 10:59:55 --> Model Class Initialized
DEBUG - 2016-08-31 10:59:55 --> Model Class Initialized
DEBUG - 2016-08-31 10:59:55 --> Model Class Initialized
DEBUG - 2016-08-31 10:59:55 --> Model Class Initialized
ERROR - 2016-08-31 10:59:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:177) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-08-31 11:04:58 --> Config Class Initialized
DEBUG - 2016-08-31 11:04:58 --> Hooks Class Initialized
DEBUG - 2016-08-31 11:04:58 --> Utf8 Class Initialized
DEBUG - 2016-08-31 11:04:58 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 11:04:58 --> URI Class Initialized
DEBUG - 2016-08-31 11:04:58 --> Router Class Initialized
DEBUG - 2016-08-31 11:04:58 --> Output Class Initialized
DEBUG - 2016-08-31 11:04:58 --> Security Class Initialized
DEBUG - 2016-08-31 11:04:58 --> Input Class Initialized
DEBUG - 2016-08-31 11:04:58 --> XSS Filtering completed
DEBUG - 2016-08-31 11:04:58 --> XSS Filtering completed
DEBUG - 2016-08-31 11:04:58 --> XSS Filtering completed
DEBUG - 2016-08-31 11:04:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 11:04:58 --> Language Class Initialized
DEBUG - 2016-08-31 11:04:58 --> Loader Class Initialized
DEBUG - 2016-08-31 11:04:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 11:04:58 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 11:04:58 --> Helper loaded: url_helper
DEBUG - 2016-08-31 11:04:58 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 11:04:59 --> Helper loaded: file_helper
DEBUG - 2016-08-31 11:04:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 11:04:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 11:04:59 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 11:04:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 11:04:59 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 11:04:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 11:04:59 --> Helper loaded: common_helper
DEBUG - 2016-08-31 11:04:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 11:04:59 --> Helper loaded: common_helper
DEBUG - 2016-08-31 11:04:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 11:04:59 --> Helper loaded: form_helper
DEBUG - 2016-08-31 11:04:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 11:04:59 --> Helper loaded: security_helper
DEBUG - 2016-08-31 11:04:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 11:04:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 11:04:59 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 11:04:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 11:04:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 11:04:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 11:04:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 11:04:59 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 11:04:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 11:04:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 11:04:59 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 11:04:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 11:04:59 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 11:04:59 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 11:05:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 11:05:00 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 11:05:00 --> Database Driver Class Initialized
DEBUG - 2016-08-31 11:05:00 --> Session Class Initialized
DEBUG - 2016-08-31 11:05:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 11:05:00 --> Helper loaded: string_helper
DEBUG - 2016-08-31 11:05:00 --> Session routines successfully run
DEBUG - 2016-08-31 11:05:00 --> Native_session Class Initialized
DEBUG - 2016-08-31 11:05:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 11:05:00 --> Form Validation Class Initialized
DEBUG - 2016-08-31 11:05:00 --> Form Validation Class Initialized
DEBUG - 2016-08-31 11:05:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 11:05:00 --> Controller Class Initialized
DEBUG - 2016-08-31 11:05:00 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 11:05:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 11:05:00 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 11:05:00 --> Carabiner: library configured.
DEBUG - 2016-08-31 11:05:00 --> Carabiner: library configured.
DEBUG - 2016-08-31 11:05:00 --> User Agent Class Initialized
DEBUG - 2016-08-31 11:05:00 --> Model Class Initialized
DEBUG - 2016-08-31 11:05:00 --> Model Class Initialized
DEBUG - 2016-08-31 11:05:00 --> Model Class Initialized
DEBUG - 2016-08-31 11:05:00 --> Model Class Initialized
DEBUG - 2016-08-31 11:05:00 --> Model Class Initialized
DEBUG - 2016-08-31 11:05:00 --> Model Class Initialized
DEBUG - 2016-08-31 11:05:00 --> Model Class Initialized
DEBUG - 2016-08-31 11:05:00 --> Model Class Initialized
DEBUG - 2016-08-31 11:05:00 --> Model Class Initialized
DEBUG - 2016-08-31 11:05:01 --> Model Class Initialized
ERROR - 2016-08-31 11:05:01 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:177) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-08-31 11:06:36 --> Config Class Initialized
DEBUG - 2016-08-31 11:06:37 --> Hooks Class Initialized
DEBUG - 2016-08-31 11:06:37 --> Utf8 Class Initialized
DEBUG - 2016-08-31 11:06:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 11:06:37 --> URI Class Initialized
DEBUG - 2016-08-31 11:06:37 --> Router Class Initialized
DEBUG - 2016-08-31 11:06:37 --> Output Class Initialized
DEBUG - 2016-08-31 11:06:37 --> Security Class Initialized
DEBUG - 2016-08-31 11:06:37 --> Input Class Initialized
DEBUG - 2016-08-31 11:06:37 --> XSS Filtering completed
DEBUG - 2016-08-31 11:06:37 --> XSS Filtering completed
DEBUG - 2016-08-31 11:06:37 --> XSS Filtering completed
DEBUG - 2016-08-31 11:06:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 11:06:37 --> Language Class Initialized
DEBUG - 2016-08-31 11:06:37 --> Loader Class Initialized
DEBUG - 2016-08-31 11:06:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 11:06:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 11:06:37 --> Helper loaded: url_helper
DEBUG - 2016-08-31 11:06:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 11:06:37 --> Helper loaded: file_helper
DEBUG - 2016-08-31 11:06:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 11:06:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 11:06:37 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 11:06:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 11:06:37 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 11:06:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 11:06:37 --> Helper loaded: common_helper
DEBUG - 2016-08-31 11:06:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 11:06:37 --> Helper loaded: common_helper
DEBUG - 2016-08-31 11:06:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 11:06:38 --> Helper loaded: form_helper
DEBUG - 2016-08-31 11:06:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 11:06:38 --> Helper loaded: security_helper
DEBUG - 2016-08-31 11:06:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 11:06:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 11:06:38 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 11:06:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 11:06:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 11:06:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 11:06:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 11:06:38 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 11:06:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 11:06:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 11:06:38 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 11:06:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 11:06:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 11:06:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 11:06:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 11:06:38 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 11:06:38 --> Database Driver Class Initialized
DEBUG - 2016-08-31 11:06:38 --> Session Class Initialized
DEBUG - 2016-08-31 11:06:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 11:06:38 --> Helper loaded: string_helper
DEBUG - 2016-08-31 11:06:38 --> Session routines successfully run
DEBUG - 2016-08-31 11:06:38 --> Native_session Class Initialized
DEBUG - 2016-08-31 11:06:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 11:06:38 --> Form Validation Class Initialized
DEBUG - 2016-08-31 11:06:38 --> Form Validation Class Initialized
DEBUG - 2016-08-31 11:06:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 11:06:39 --> Controller Class Initialized
DEBUG - 2016-08-31 11:06:39 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 11:06:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 11:06:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 11:06:39 --> Carabiner: library configured.
DEBUG - 2016-08-31 11:06:39 --> Carabiner: library configured.
DEBUG - 2016-08-31 11:06:39 --> User Agent Class Initialized
DEBUG - 2016-08-31 11:06:39 --> Model Class Initialized
DEBUG - 2016-08-31 11:06:39 --> Model Class Initialized
DEBUG - 2016-08-31 11:06:39 --> Model Class Initialized
DEBUG - 2016-08-31 11:06:39 --> Model Class Initialized
DEBUG - 2016-08-31 11:06:39 --> Model Class Initialized
DEBUG - 2016-08-31 11:06:39 --> Model Class Initialized
DEBUG - 2016-08-31 11:06:39 --> Model Class Initialized
DEBUG - 2016-08-31 11:06:39 --> Model Class Initialized
DEBUG - 2016-08-31 11:06:39 --> Model Class Initialized
DEBUG - 2016-08-31 11:06:39 --> Model Class Initialized
ERROR - 2016-08-31 11:06:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:177) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-08-31 13:18:40 --> Config Class Initialized
DEBUG - 2016-08-31 13:18:40 --> Hooks Class Initialized
DEBUG - 2016-08-31 13:18:40 --> Utf8 Class Initialized
DEBUG - 2016-08-31 13:18:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 13:18:40 --> URI Class Initialized
DEBUG - 2016-08-31 13:18:40 --> Router Class Initialized
DEBUG - 2016-08-31 13:18:40 --> No URI present. Default controller set.
DEBUG - 2016-08-31 13:18:40 --> Output Class Initialized
DEBUG - 2016-08-31 13:18:40 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 13:18:40 --> Security Class Initialized
DEBUG - 2016-08-31 13:18:40 --> Input Class Initialized
DEBUG - 2016-08-31 13:18:40 --> XSS Filtering completed
DEBUG - 2016-08-31 13:18:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 13:18:40 --> Language Class Initialized
DEBUG - 2016-08-31 13:18:41 --> Loader Class Initialized
DEBUG - 2016-08-31 13:18:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 13:18:41 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 13:18:41 --> Helper loaded: url_helper
DEBUG - 2016-08-31 13:18:41 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 13:18:41 --> Helper loaded: file_helper
DEBUG - 2016-08-31 13:18:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 13:18:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 13:18:41 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 13:18:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 13:18:41 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 13:18:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 13:18:41 --> Helper loaded: common_helper
DEBUG - 2016-08-31 13:18:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 13:18:41 --> Helper loaded: common_helper
DEBUG - 2016-08-31 13:18:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 13:18:41 --> Helper loaded: form_helper
DEBUG - 2016-08-31 13:18:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 13:18:41 --> Helper loaded: security_helper
DEBUG - 2016-08-31 13:18:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 13:18:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 13:18:41 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 13:18:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 13:18:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 13:18:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 13:18:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 13:18:41 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 13:18:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 13:18:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 13:18:42 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 13:18:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 13:18:42 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 13:18:42 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 13:18:42 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 13:18:42 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 13:18:42 --> Database Driver Class Initialized
DEBUG - 2016-08-31 13:18:42 --> Session Class Initialized
DEBUG - 2016-08-31 13:18:42 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 13:18:42 --> Helper loaded: string_helper
DEBUG - 2016-08-31 13:18:42 --> A session cookie was not found.
DEBUG - 2016-08-31 13:18:42 --> Session routines successfully run
DEBUG - 2016-08-31 13:18:42 --> Native_session Class Initialized
DEBUG - 2016-08-31 13:18:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 13:18:42 --> Form Validation Class Initialized
DEBUG - 2016-08-31 13:18:42 --> Form Validation Class Initialized
DEBUG - 2016-08-31 13:18:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 13:18:42 --> Controller Class Initialized
DEBUG - 2016-08-31 13:18:42 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 13:18:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 13:18:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 13:18:42 --> Carabiner: library configured.
DEBUG - 2016-08-31 13:18:42 --> Carabiner: library configured.
DEBUG - 2016-08-31 13:18:42 --> User Agent Class Initialized
DEBUG - 2016-08-31 13:18:42 --> Model Class Initialized
DEBUG - 2016-08-31 13:18:42 --> Model Class Initialized
DEBUG - 2016-08-31 13:18:42 --> Model Class Initialized
DEBUG - 2016-08-31 13:18:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-08-31 13:18:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 13:18:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 13:18:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 13:18:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 13:18:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 13:18:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 13:18:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 13:18:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 13:18:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 13:18:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 13:18:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 13:18:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 13:18:43 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-08-31 13:18:43 --> Final output sent to browser
DEBUG - 2016-08-31 13:18:43 --> Total execution time: 2.3924
DEBUG - 2016-08-31 13:18:49 --> Config Class Initialized
DEBUG - 2016-08-31 13:18:49 --> Hooks Class Initialized
DEBUG - 2016-08-31 13:18:49 --> Utf8 Class Initialized
DEBUG - 2016-08-31 13:18:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 13:18:49 --> URI Class Initialized
DEBUG - 2016-08-31 13:18:49 --> Router Class Initialized
DEBUG - 2016-08-31 13:18:49 --> Output Class Initialized
DEBUG - 2016-08-31 13:18:49 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 13:18:49 --> Security Class Initialized
DEBUG - 2016-08-31 13:18:49 --> Input Class Initialized
DEBUG - 2016-08-31 13:18:49 --> XSS Filtering completed
DEBUG - 2016-08-31 13:18:49 --> XSS Filtering completed
DEBUG - 2016-08-31 13:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 13:18:49 --> Language Class Initialized
DEBUG - 2016-08-31 13:18:50 --> Loader Class Initialized
DEBUG - 2016-08-31 13:18:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 13:18:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 13:18:50 --> Helper loaded: url_helper
DEBUG - 2016-08-31 13:18:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 13:18:50 --> Helper loaded: file_helper
DEBUG - 2016-08-31 13:18:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 13:18:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 13:18:50 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 13:18:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 13:18:50 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 13:18:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 13:18:50 --> Helper loaded: common_helper
DEBUG - 2016-08-31 13:18:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 13:18:50 --> Helper loaded: common_helper
DEBUG - 2016-08-31 13:18:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 13:18:50 --> Helper loaded: form_helper
DEBUG - 2016-08-31 13:18:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 13:18:50 --> Helper loaded: security_helper
DEBUG - 2016-08-31 13:18:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 13:18:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 13:18:50 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 13:18:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 13:18:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 13:18:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 13:18:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 13:18:50 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 13:18:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 13:18:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 13:18:51 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 13:18:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 13:18:51 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 13:18:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 13:18:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 13:18:51 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 13:18:51 --> Database Driver Class Initialized
DEBUG - 2016-08-31 13:18:51 --> Session Class Initialized
DEBUG - 2016-08-31 13:18:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 13:18:51 --> Helper loaded: string_helper
DEBUG - 2016-08-31 13:18:51 --> Session routines successfully run
DEBUG - 2016-08-31 13:18:51 --> Native_session Class Initialized
DEBUG - 2016-08-31 13:18:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 13:18:51 --> Form Validation Class Initialized
DEBUG - 2016-08-31 13:18:51 --> Form Validation Class Initialized
DEBUG - 2016-08-31 13:18:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 13:18:51 --> Controller Class Initialized
DEBUG - 2016-08-31 13:18:51 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 13:18:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 13:18:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 13:18:51 --> Carabiner: library configured.
DEBUG - 2016-08-31 13:18:51 --> Carabiner: library configured.
DEBUG - 2016-08-31 13:18:51 --> User Agent Class Initialized
DEBUG - 2016-08-31 13:18:51 --> Model Class Initialized
DEBUG - 2016-08-31 13:18:51 --> Model Class Initialized
DEBUG - 2016-08-31 13:18:51 --> Model Class Initialized
DEBUG - 2016-08-31 13:18:51 --> Model Class Initialized
DEBUG - 2016-08-31 13:18:51 --> Model Class Initialized
DEBUG - 2016-08-31 13:18:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 13:18:52 --> Pagination Class Initialized
DEBUG - 2016-08-31 13:18:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 13:18:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/index.php
DEBUG - 2016-08-31 13:18:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 13:18:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 13:18:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 13:18:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 13:18:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-08-31 13:18:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 13:18:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 13:18:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 13:18:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 13:18:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 13:18:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 13:18:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-08-31 13:18:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 13:18:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 13:18:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c2a3e0401bd35d4fcac4bae5f9412231
DEBUG - 2016-08-31 13:18:52 --> Final output sent to browser
DEBUG - 2016-08-31 13:18:52 --> Total execution time: 2.5750
DEBUG - 2016-08-31 13:18:54 --> Config Class Initialized
DEBUG - 2016-08-31 13:18:54 --> Hooks Class Initialized
DEBUG - 2016-08-31 13:18:55 --> Utf8 Class Initialized
DEBUG - 2016-08-31 13:18:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 13:18:55 --> URI Class Initialized
DEBUG - 2016-08-31 13:18:55 --> Router Class Initialized
DEBUG - 2016-08-31 13:18:55 --> Output Class Initialized
DEBUG - 2016-08-31 13:18:55 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 13:18:55 --> Security Class Initialized
DEBUG - 2016-08-31 13:18:55 --> Input Class Initialized
DEBUG - 2016-08-31 13:18:55 --> XSS Filtering completed
DEBUG - 2016-08-31 13:18:55 --> XSS Filtering completed
DEBUG - 2016-08-31 13:18:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 13:18:55 --> Language Class Initialized
DEBUG - 2016-08-31 13:18:55 --> Loader Class Initialized
DEBUG - 2016-08-31 13:18:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 13:18:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 13:18:55 --> Helper loaded: url_helper
DEBUG - 2016-08-31 13:18:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 13:18:55 --> Helper loaded: file_helper
DEBUG - 2016-08-31 13:18:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 13:18:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 13:18:55 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 13:18:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 13:18:55 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 13:18:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 13:18:55 --> Helper loaded: common_helper
DEBUG - 2016-08-31 13:18:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 13:18:55 --> Helper loaded: common_helper
DEBUG - 2016-08-31 13:18:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 13:18:55 --> Helper loaded: form_helper
DEBUG - 2016-08-31 13:18:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 13:18:56 --> Helper loaded: security_helper
DEBUG - 2016-08-31 13:18:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 13:18:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 13:18:56 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 13:18:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 13:18:56 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 13:18:56 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 13:18:56 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 13:18:56 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 13:18:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 13:18:56 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 13:18:56 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 13:18:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 13:18:56 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 13:18:56 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 13:18:56 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 13:18:56 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 13:18:56 --> Database Driver Class Initialized
DEBUG - 2016-08-31 13:18:56 --> Session Class Initialized
DEBUG - 2016-08-31 13:18:56 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 13:18:56 --> Helper loaded: string_helper
DEBUG - 2016-08-31 13:18:56 --> Session routines successfully run
DEBUG - 2016-08-31 13:18:56 --> Native_session Class Initialized
DEBUG - 2016-08-31 13:18:56 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 13:18:56 --> Form Validation Class Initialized
DEBUG - 2016-08-31 13:18:56 --> Form Validation Class Initialized
DEBUG - 2016-08-31 13:18:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 13:18:57 --> Controller Class Initialized
DEBUG - 2016-08-31 13:18:57 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 13:18:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 13:18:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 13:18:57 --> Carabiner: library configured.
DEBUG - 2016-08-31 13:18:57 --> Carabiner: library configured.
DEBUG - 2016-08-31 13:18:57 --> User Agent Class Initialized
DEBUG - 2016-08-31 13:18:57 --> Model Class Initialized
DEBUG - 2016-08-31 13:18:57 --> Model Class Initialized
DEBUG - 2016-08-31 13:18:57 --> Model Class Initialized
DEBUG - 2016-08-31 13:18:57 --> Model Class Initialized
DEBUG - 2016-08-31 13:18:57 --> Model Class Initialized
DEBUG - 2016-08-31 13:18:57 --> Model Class Initialized
DEBUG - 2016-08-31 13:18:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 13:18:57 --> Pagination Class Initialized
DEBUG - 2016-08-31 13:18:57 --> Model Class Initialized
DEBUG - 2016-08-31 13:18:57 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 13:18:57 --> Model Class Initialized
DEBUG - 2016-08-31 13:18:57 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 13:18:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-31 13:18:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-31 14:07:13 --> Config Class Initialized
DEBUG - 2016-08-31 14:07:13 --> Hooks Class Initialized
DEBUG - 2016-08-31 14:07:13 --> Utf8 Class Initialized
DEBUG - 2016-08-31 14:07:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 14:07:13 --> URI Class Initialized
DEBUG - 2016-08-31 14:07:13 --> Router Class Initialized
DEBUG - 2016-08-31 14:07:13 --> Output Class Initialized
DEBUG - 2016-08-31 14:07:14 --> Security Class Initialized
DEBUG - 2016-08-31 14:07:14 --> Input Class Initialized
DEBUG - 2016-08-31 14:07:14 --> XSS Filtering completed
DEBUG - 2016-08-31 14:07:14 --> XSS Filtering completed
DEBUG - 2016-08-31 14:07:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 14:07:14 --> Language Class Initialized
DEBUG - 2016-08-31 14:07:14 --> Loader Class Initialized
DEBUG - 2016-08-31 14:07:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 14:07:14 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 14:07:14 --> Helper loaded: url_helper
DEBUG - 2016-08-31 14:07:14 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 14:07:14 --> Helper loaded: file_helper
DEBUG - 2016-08-31 14:07:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 14:07:14 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 14:07:14 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 14:07:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 14:07:14 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 14:07:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 14:07:14 --> Helper loaded: common_helper
DEBUG - 2016-08-31 14:07:14 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 14:07:14 --> Helper loaded: common_helper
DEBUG - 2016-08-31 14:07:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 14:07:14 --> Helper loaded: form_helper
DEBUG - 2016-08-31 14:07:14 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 14:07:14 --> Helper loaded: security_helper
DEBUG - 2016-08-31 14:07:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 14:07:14 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 14:07:14 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 14:07:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 14:07:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 14:07:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 14:07:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 14:07:15 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 14:07:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 14:07:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 14:07:15 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 14:07:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 14:07:15 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 14:07:15 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 14:07:15 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 14:07:15 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 14:07:15 --> Database Driver Class Initialized
DEBUG - 2016-08-31 14:07:15 --> Session Class Initialized
DEBUG - 2016-08-31 14:07:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 14:07:15 --> Helper loaded: string_helper
DEBUG - 2016-08-31 14:07:15 --> Session routines successfully run
DEBUG - 2016-08-31 14:07:15 --> Native_session Class Initialized
DEBUG - 2016-08-31 14:07:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 14:07:15 --> Form Validation Class Initialized
DEBUG - 2016-08-31 14:07:15 --> Form Validation Class Initialized
DEBUG - 2016-08-31 14:07:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 14:07:15 --> Controller Class Initialized
DEBUG - 2016-08-31 14:07:15 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 14:07:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 14:07:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 14:07:15 --> Carabiner: library configured.
DEBUG - 2016-08-31 14:07:16 --> Carabiner: library configured.
DEBUG - 2016-08-31 14:07:16 --> User Agent Class Initialized
DEBUG - 2016-08-31 14:07:16 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:16 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:16 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:16 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:16 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:16 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 14:07:16 --> Pagination Class Initialized
DEBUG - 2016-08-31 14:07:16 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:16 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 14:07:16 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:16 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 14:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-31 14:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-31 14:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-31 14:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-31 14:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 14:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 14:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 14:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 14:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-31 14:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 14:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 14:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 14:07:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 14:07:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 14:07:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 14:07:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-31 14:07:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 14:07:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 14:07:17 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b6bd8c4f0f9a3c083ce1836ed8f53795
DEBUG - 2016-08-31 14:07:17 --> Final output sent to browser
DEBUG - 2016-08-31 14:07:17 --> Total execution time: 2.7750
DEBUG - 2016-08-31 14:07:40 --> Config Class Initialized
DEBUG - 2016-08-31 14:07:40 --> Hooks Class Initialized
DEBUG - 2016-08-31 14:07:40 --> Utf8 Class Initialized
DEBUG - 2016-08-31 14:07:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 14:07:40 --> URI Class Initialized
DEBUG - 2016-08-31 14:07:40 --> Router Class Initialized
DEBUG - 2016-08-31 14:07:40 --> Output Class Initialized
DEBUG - 2016-08-31 14:07:40 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 14:07:40 --> Security Class Initialized
DEBUG - 2016-08-31 14:07:40 --> Input Class Initialized
DEBUG - 2016-08-31 14:07:40 --> XSS Filtering completed
DEBUG - 2016-08-31 14:07:40 --> XSS Filtering completed
DEBUG - 2016-08-31 14:07:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 14:07:40 --> Language Class Initialized
DEBUG - 2016-08-31 14:07:40 --> Loader Class Initialized
DEBUG - 2016-08-31 14:07:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 14:07:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 14:07:40 --> Helper loaded: url_helper
DEBUG - 2016-08-31 14:07:41 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 14:07:41 --> Helper loaded: file_helper
DEBUG - 2016-08-31 14:07:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 14:07:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 14:07:41 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 14:07:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 14:07:41 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 14:07:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 14:07:41 --> Helper loaded: common_helper
DEBUG - 2016-08-31 14:07:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 14:07:41 --> Helper loaded: common_helper
DEBUG - 2016-08-31 14:07:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 14:07:41 --> Helper loaded: form_helper
DEBUG - 2016-08-31 14:07:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 14:07:41 --> Helper loaded: security_helper
DEBUG - 2016-08-31 14:07:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 14:07:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 14:07:41 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 14:07:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 14:07:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 14:07:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 14:07:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 14:07:41 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 14:07:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 14:07:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 14:07:41 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 14:07:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 14:07:41 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 14:07:42 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 14:07:42 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 14:07:42 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 14:07:42 --> Database Driver Class Initialized
DEBUG - 2016-08-31 14:07:42 --> Session Class Initialized
DEBUG - 2016-08-31 14:07:42 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 14:07:42 --> Helper loaded: string_helper
DEBUG - 2016-08-31 14:07:42 --> Session routines successfully run
DEBUG - 2016-08-31 14:07:42 --> Native_session Class Initialized
DEBUG - 2016-08-31 14:07:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 14:07:42 --> Form Validation Class Initialized
DEBUG - 2016-08-31 14:07:42 --> Form Validation Class Initialized
DEBUG - 2016-08-31 14:07:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 14:07:42 --> Controller Class Initialized
DEBUG - 2016-08-31 14:07:42 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 14:07:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 14:07:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 14:07:42 --> Carabiner: library configured.
DEBUG - 2016-08-31 14:07:42 --> Carabiner: library configured.
DEBUG - 2016-08-31 14:07:42 --> User Agent Class Initialized
DEBUG - 2016-08-31 14:07:42 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:42 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:42 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:42 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:42 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 14:07:43 --> Pagination Class Initialized
DEBUG - 2016-08-31 14:07:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-31 14:07:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/index.php
DEBUG - 2016-08-31 14:07:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 14:07:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 14:07:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 14:07:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 14:07:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-08-31 14:07:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 14:07:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 14:07:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 14:07:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 14:07:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 14:07:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 14:07:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-08-31 14:07:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 14:07:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 14:07:43 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c2a3e0401bd35d4fcac4bae5f9412231
DEBUG - 2016-08-31 14:07:43 --> Final output sent to browser
DEBUG - 2016-08-31 14:07:43 --> Total execution time: 2.8622
DEBUG - 2016-08-31 14:07:46 --> Config Class Initialized
DEBUG - 2016-08-31 14:07:46 --> Hooks Class Initialized
DEBUG - 2016-08-31 14:07:47 --> Utf8 Class Initialized
DEBUG - 2016-08-31 14:07:47 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 14:07:47 --> URI Class Initialized
DEBUG - 2016-08-31 14:07:47 --> Router Class Initialized
DEBUG - 2016-08-31 14:07:47 --> Output Class Initialized
DEBUG - 2016-08-31 14:07:47 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 14:07:47 --> Security Class Initialized
DEBUG - 2016-08-31 14:07:47 --> Input Class Initialized
DEBUG - 2016-08-31 14:07:47 --> XSS Filtering completed
DEBUG - 2016-08-31 14:07:47 --> XSS Filtering completed
DEBUG - 2016-08-31 14:07:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 14:07:47 --> Language Class Initialized
DEBUG - 2016-08-31 14:07:47 --> Loader Class Initialized
DEBUG - 2016-08-31 14:07:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 14:07:47 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 14:07:47 --> Helper loaded: url_helper
DEBUG - 2016-08-31 14:07:47 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 14:07:47 --> Helper loaded: file_helper
DEBUG - 2016-08-31 14:07:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 14:07:47 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 14:07:47 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 14:07:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 14:07:47 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 14:07:47 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 14:07:47 --> Helper loaded: common_helper
DEBUG - 2016-08-31 14:07:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 14:07:48 --> Helper loaded: common_helper
DEBUG - 2016-08-31 14:07:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 14:07:48 --> Helper loaded: form_helper
DEBUG - 2016-08-31 14:07:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 14:07:48 --> Helper loaded: security_helper
DEBUG - 2016-08-31 14:07:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 14:07:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 14:07:48 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 14:07:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 14:07:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 14:07:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 14:07:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 14:07:48 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 14:07:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 14:07:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 14:07:48 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 14:07:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 14:07:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 14:07:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 14:07:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 14:07:48 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 14:07:48 --> Database Driver Class Initialized
DEBUG - 2016-08-31 14:07:48 --> Session Class Initialized
DEBUG - 2016-08-31 14:07:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 14:07:48 --> Helper loaded: string_helper
DEBUG - 2016-08-31 14:07:48 --> Session routines successfully run
DEBUG - 2016-08-31 14:07:49 --> Native_session Class Initialized
DEBUG - 2016-08-31 14:07:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 14:07:49 --> Form Validation Class Initialized
DEBUG - 2016-08-31 14:07:49 --> Form Validation Class Initialized
DEBUG - 2016-08-31 14:07:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 14:07:49 --> Controller Class Initialized
DEBUG - 2016-08-31 14:07:49 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 14:07:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 14:07:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 14:07:49 --> Carabiner: library configured.
DEBUG - 2016-08-31 14:07:49 --> Carabiner: library configured.
DEBUG - 2016-08-31 14:07:49 --> User Agent Class Initialized
DEBUG - 2016-08-31 14:07:49 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:49 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:49 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:49 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:49 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:49 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 14:07:49 --> Pagination Class Initialized
DEBUG - 2016-08-31 14:07:49 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:49 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 14:07:49 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:49 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 14:07:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-31 14:07:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-31 14:07:53 --> Config Class Initialized
DEBUG - 2016-08-31 14:07:53 --> Hooks Class Initialized
DEBUG - 2016-08-31 14:07:53 --> Utf8 Class Initialized
DEBUG - 2016-08-31 14:07:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 14:07:53 --> URI Class Initialized
DEBUG - 2016-08-31 14:07:54 --> Router Class Initialized
DEBUG - 2016-08-31 14:07:54 --> Output Class Initialized
DEBUG - 2016-08-31 14:07:54 --> Security Class Initialized
DEBUG - 2016-08-31 14:07:54 --> Input Class Initialized
DEBUG - 2016-08-31 14:07:54 --> XSS Filtering completed
DEBUG - 2016-08-31 14:07:54 --> XSS Filtering completed
DEBUG - 2016-08-31 14:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 14:07:54 --> Language Class Initialized
DEBUG - 2016-08-31 14:07:54 --> Loader Class Initialized
DEBUG - 2016-08-31 14:07:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 14:07:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 14:07:54 --> Helper loaded: url_helper
DEBUG - 2016-08-31 14:07:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 14:07:54 --> Helper loaded: file_helper
DEBUG - 2016-08-31 14:07:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 14:07:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 14:07:54 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 14:07:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 14:07:54 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 14:07:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 14:07:54 --> Helper loaded: common_helper
DEBUG - 2016-08-31 14:07:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 14:07:54 --> Helper loaded: common_helper
DEBUG - 2016-08-31 14:07:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 14:07:54 --> Helper loaded: form_helper
DEBUG - 2016-08-31 14:07:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 14:07:54 --> Helper loaded: security_helper
DEBUG - 2016-08-31 14:07:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 14:07:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 14:07:55 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 14:07:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 14:07:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 14:07:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 14:07:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 14:07:55 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 14:07:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 14:07:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 14:07:55 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 14:07:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 14:07:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 14:07:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 14:07:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 14:07:55 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 14:07:55 --> Database Driver Class Initialized
DEBUG - 2016-08-31 14:07:55 --> Session Class Initialized
DEBUG - 2016-08-31 14:07:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 14:07:55 --> Helper loaded: string_helper
DEBUG - 2016-08-31 14:07:55 --> Session routines successfully run
DEBUG - 2016-08-31 14:07:55 --> Native_session Class Initialized
DEBUG - 2016-08-31 14:07:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 14:07:55 --> Form Validation Class Initialized
DEBUG - 2016-08-31 14:07:55 --> Form Validation Class Initialized
DEBUG - 2016-08-31 14:07:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 14:07:55 --> Controller Class Initialized
DEBUG - 2016-08-31 14:07:55 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 14:07:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 14:07:56 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 14:07:56 --> Carabiner: library configured.
DEBUG - 2016-08-31 14:07:56 --> Carabiner: library configured.
DEBUG - 2016-08-31 14:07:56 --> User Agent Class Initialized
DEBUG - 2016-08-31 14:07:56 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:56 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:56 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:56 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:56 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:56 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 14:07:56 --> Pagination Class Initialized
DEBUG - 2016-08-31 14:07:56 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:56 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 14:07:56 --> Model Class Initialized
DEBUG - 2016-08-31 14:07:56 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 14:07:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-31 14:07:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-31 14:08:23 --> Config Class Initialized
DEBUG - 2016-08-31 14:08:24 --> Hooks Class Initialized
DEBUG - 2016-08-31 14:08:24 --> Utf8 Class Initialized
DEBUG - 2016-08-31 14:08:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 14:08:24 --> URI Class Initialized
DEBUG - 2016-08-31 14:08:24 --> Router Class Initialized
DEBUG - 2016-08-31 14:08:24 --> Output Class Initialized
DEBUG - 2016-08-31 14:08:24 --> Security Class Initialized
DEBUG - 2016-08-31 14:08:24 --> Input Class Initialized
DEBUG - 2016-08-31 14:08:24 --> XSS Filtering completed
DEBUG - 2016-08-31 14:08:24 --> XSS Filtering completed
DEBUG - 2016-08-31 14:08:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 14:08:24 --> Language Class Initialized
DEBUG - 2016-08-31 14:08:24 --> Loader Class Initialized
DEBUG - 2016-08-31 14:08:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 14:08:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 14:08:24 --> Helper loaded: url_helper
DEBUG - 2016-08-31 14:08:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 14:08:24 --> Helper loaded: file_helper
DEBUG - 2016-08-31 14:08:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 14:08:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 14:08:24 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 14:08:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 14:08:24 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 14:08:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 14:08:25 --> Helper loaded: common_helper
DEBUG - 2016-08-31 14:08:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 14:08:25 --> Helper loaded: common_helper
DEBUG - 2016-08-31 14:08:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 14:08:25 --> Helper loaded: form_helper
DEBUG - 2016-08-31 14:08:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 14:08:25 --> Helper loaded: security_helper
DEBUG - 2016-08-31 14:08:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 14:08:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 14:08:25 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 14:08:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 14:08:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 14:08:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 14:08:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 14:08:25 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 14:08:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 14:08:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 14:08:25 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 14:08:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 14:08:25 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 14:08:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 14:08:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 14:08:25 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 14:08:25 --> Database Driver Class Initialized
DEBUG - 2016-08-31 14:08:25 --> Session Class Initialized
DEBUG - 2016-08-31 14:08:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 14:08:25 --> Helper loaded: string_helper
DEBUG - 2016-08-31 14:08:26 --> Session routines successfully run
DEBUG - 2016-08-31 14:08:26 --> Native_session Class Initialized
DEBUG - 2016-08-31 14:08:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 14:08:26 --> Form Validation Class Initialized
DEBUG - 2016-08-31 14:08:26 --> Form Validation Class Initialized
DEBUG - 2016-08-31 14:08:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 14:08:26 --> Controller Class Initialized
DEBUG - 2016-08-31 14:08:26 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 14:08:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 14:08:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 14:08:26 --> Carabiner: library configured.
DEBUG - 2016-08-31 14:08:26 --> Carabiner: library configured.
DEBUG - 2016-08-31 14:08:26 --> User Agent Class Initialized
DEBUG - 2016-08-31 14:08:26 --> Model Class Initialized
DEBUG - 2016-08-31 14:08:26 --> Model Class Initialized
DEBUG - 2016-08-31 14:08:26 --> Model Class Initialized
DEBUG - 2016-08-31 14:08:26 --> Model Class Initialized
DEBUG - 2016-08-31 14:08:26 --> Model Class Initialized
DEBUG - 2016-08-31 14:08:26 --> Model Class Initialized
DEBUG - 2016-08-31 14:08:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 14:08:26 --> Pagination Class Initialized
DEBUG - 2016-08-31 14:08:26 --> Model Class Initialized
DEBUG - 2016-08-31 14:08:26 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 14:08:26 --> Model Class Initialized
DEBUG - 2016-08-31 14:08:26 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 14:08:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-31 14:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-31 14:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-31 14:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-31 14:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 14:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 14:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 14:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 14:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-31 14:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 14:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 14:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 14:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 14:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 14:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 14:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-31 14:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 14:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 14:08:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-31 14:08:27 --> Final output sent to browser
DEBUG - 2016-08-31 14:08:27 --> Total execution time: 3.0215
DEBUG - 2016-08-31 14:09:30 --> Config Class Initialized
DEBUG - 2016-08-31 14:09:30 --> Hooks Class Initialized
DEBUG - 2016-08-31 14:09:30 --> Utf8 Class Initialized
DEBUG - 2016-08-31 14:09:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 14:09:30 --> URI Class Initialized
DEBUG - 2016-08-31 14:09:30 --> Router Class Initialized
DEBUG - 2016-08-31 14:09:30 --> Output Class Initialized
DEBUG - 2016-08-31 14:09:30 --> Cache file has expired. File deleted
DEBUG - 2016-08-31 14:09:30 --> Security Class Initialized
DEBUG - 2016-08-31 14:09:30 --> Input Class Initialized
DEBUG - 2016-08-31 14:09:31 --> XSS Filtering completed
DEBUG - 2016-08-31 14:09:31 --> XSS Filtering completed
DEBUG - 2016-08-31 14:09:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 14:09:31 --> Language Class Initialized
DEBUG - 2016-08-31 14:09:31 --> Loader Class Initialized
DEBUG - 2016-08-31 14:09:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 14:09:31 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 14:09:31 --> Helper loaded: url_helper
DEBUG - 2016-08-31 14:09:31 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 14:09:31 --> Helper loaded: file_helper
DEBUG - 2016-08-31 14:09:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 14:09:31 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 14:09:31 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 14:09:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 14:09:31 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 14:09:31 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 14:09:31 --> Helper loaded: common_helper
DEBUG - 2016-08-31 14:09:31 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 14:09:31 --> Helper loaded: common_helper
DEBUG - 2016-08-31 14:09:31 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 14:09:31 --> Helper loaded: form_helper
DEBUG - 2016-08-31 14:09:31 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 14:09:31 --> Helper loaded: security_helper
DEBUG - 2016-08-31 14:09:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 14:09:31 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 14:09:31 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 14:09:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 14:09:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 14:09:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 14:09:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 14:09:32 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 14:09:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 14:09:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 14:09:32 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 14:09:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 14:09:32 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 14:09:32 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 14:09:32 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 14:09:32 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 14:09:32 --> Database Driver Class Initialized
DEBUG - 2016-08-31 14:09:32 --> Session Class Initialized
DEBUG - 2016-08-31 14:09:32 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 14:09:32 --> Helper loaded: string_helper
DEBUG - 2016-08-31 14:09:32 --> Session routines successfully run
DEBUG - 2016-08-31 14:09:32 --> Native_session Class Initialized
DEBUG - 2016-08-31 14:09:32 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 14:09:32 --> Form Validation Class Initialized
DEBUG - 2016-08-31 14:09:32 --> Form Validation Class Initialized
DEBUG - 2016-08-31 14:09:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 14:09:32 --> Controller Class Initialized
DEBUG - 2016-08-31 14:09:32 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 14:09:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 14:09:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 14:09:32 --> Carabiner: library configured.
DEBUG - 2016-08-31 14:09:33 --> Carabiner: library configured.
DEBUG - 2016-08-31 14:09:33 --> User Agent Class Initialized
DEBUG - 2016-08-31 14:09:33 --> Model Class Initialized
DEBUG - 2016-08-31 14:09:33 --> Model Class Initialized
DEBUG - 2016-08-31 14:09:33 --> Model Class Initialized
DEBUG - 2016-08-31 14:09:33 --> Model Class Initialized
DEBUG - 2016-08-31 14:09:33 --> Model Class Initialized
DEBUG - 2016-08-31 14:09:33 --> Model Class Initialized
DEBUG - 2016-08-31 14:09:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-31 14:09:33 --> Pagination Class Initialized
DEBUG - 2016-08-31 14:09:33 --> Model Class Initialized
DEBUG - 2016-08-31 14:09:33 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 14:09:33 --> Model Class Initialized
DEBUG - 2016-08-31 14:09:33 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-08-31 14:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-08-31 14:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-08-31 14:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-08-31 14:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-08-31 14:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 14:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 14:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 14:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 14:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-31 14:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 14:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 14:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-31 14:09:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-31 14:09:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-31 14:09:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-31 14:09:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-08-31 14:09:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 14:09:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-31 14:09:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-08-31 14:09:34 --> Final output sent to browser
DEBUG - 2016-08-31 14:09:34 --> Total execution time: 3.0817
DEBUG - 2016-08-31 14:09:34 --> Config Class Initialized
DEBUG - 2016-08-31 14:09:34 --> Hooks Class Initialized
DEBUG - 2016-08-31 14:09:34 --> Utf8 Class Initialized
DEBUG - 2016-08-31 14:09:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 14:09:34 --> URI Class Initialized
DEBUG - 2016-08-31 14:09:34 --> Router Class Initialized
ERROR - 2016-08-31 14:09:35 --> 404 Page Not Found --> front_end
DEBUG - 2016-08-31 14:09:51 --> Config Class Initialized
DEBUG - 2016-08-31 14:09:51 --> Hooks Class Initialized
DEBUG - 2016-08-31 14:09:51 --> Utf8 Class Initialized
DEBUG - 2016-08-31 14:09:51 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 14:09:51 --> URI Class Initialized
DEBUG - 2016-08-31 14:09:51 --> Router Class Initialized
DEBUG - 2016-08-31 14:09:51 --> Output Class Initialized
DEBUG - 2016-08-31 14:09:51 --> Security Class Initialized
DEBUG - 2016-08-31 14:09:51 --> Input Class Initialized
DEBUG - 2016-08-31 14:09:51 --> XSS Filtering completed
DEBUG - 2016-08-31 14:09:51 --> XSS Filtering completed
DEBUG - 2016-08-31 14:09:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 14:09:51 --> Language Class Initialized
DEBUG - 2016-08-31 14:09:51 --> Loader Class Initialized
DEBUG - 2016-08-31 14:09:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 14:09:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 14:09:51 --> Helper loaded: url_helper
DEBUG - 2016-08-31 14:09:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 14:09:51 --> Helper loaded: file_helper
DEBUG - 2016-08-31 14:09:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 14:09:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 14:09:52 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 14:09:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 14:09:52 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 14:09:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 14:09:52 --> Helper loaded: common_helper
DEBUG - 2016-08-31 14:09:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 14:09:52 --> Helper loaded: common_helper
DEBUG - 2016-08-31 14:09:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 14:09:52 --> Helper loaded: form_helper
DEBUG - 2016-08-31 14:09:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 14:09:52 --> Helper loaded: security_helper
DEBUG - 2016-08-31 14:09:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 14:09:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 14:09:52 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 14:09:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 14:09:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 14:09:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 14:09:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 14:09:52 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 14:09:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 14:09:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 14:09:52 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 14:09:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 14:09:52 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 14:09:52 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 14:09:52 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 14:09:52 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 14:09:53 --> Database Driver Class Initialized
DEBUG - 2016-08-31 14:09:53 --> Session Class Initialized
DEBUG - 2016-08-31 14:09:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 14:09:53 --> Helper loaded: string_helper
DEBUG - 2016-08-31 14:09:53 --> Session routines successfully run
DEBUG - 2016-08-31 14:09:53 --> Native_session Class Initialized
DEBUG - 2016-08-31 14:09:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 14:09:53 --> Form Validation Class Initialized
DEBUG - 2016-08-31 14:09:53 --> Form Validation Class Initialized
DEBUG - 2016-08-31 14:09:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 14:09:53 --> Controller Class Initialized
DEBUG - 2016-08-31 14:09:53 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 14:09:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 14:09:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 14:09:53 --> Carabiner: library configured.
DEBUG - 2016-08-31 14:09:53 --> Carabiner: library configured.
DEBUG - 2016-08-31 14:09:53 --> User Agent Class Initialized
DEBUG - 2016-08-31 14:09:53 --> Model Class Initialized
DEBUG - 2016-08-31 14:09:53 --> Model Class Initialized
DEBUG - 2016-08-31 14:09:53 --> Model Class Initialized
ERROR - 2016-08-31 14:09:53 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-08-31 14:10:01 --> Config Class Initialized
DEBUG - 2016-08-31 14:10:01 --> Hooks Class Initialized
DEBUG - 2016-08-31 14:10:01 --> Utf8 Class Initialized
DEBUG - 2016-08-31 14:10:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 14:10:01 --> URI Class Initialized
DEBUG - 2016-08-31 14:10:02 --> Router Class Initialized
DEBUG - 2016-08-31 14:10:02 --> Output Class Initialized
DEBUG - 2016-08-31 14:10:02 --> Security Class Initialized
DEBUG - 2016-08-31 14:10:02 --> Input Class Initialized
DEBUG - 2016-08-31 14:10:02 --> XSS Filtering completed
DEBUG - 2016-08-31 14:10:02 --> XSS Filtering completed
DEBUG - 2016-08-31 14:10:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-31 14:10:02 --> Language Class Initialized
DEBUG - 2016-08-31 14:10:02 --> Loader Class Initialized
DEBUG - 2016-08-31 14:10:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-31 14:10:02 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-31 14:10:02 --> Helper loaded: url_helper
DEBUG - 2016-08-31 14:10:02 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-31 14:10:02 --> Helper loaded: file_helper
DEBUG - 2016-08-31 14:10:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 14:10:02 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-31 14:10:02 --> Helper loaded: conf_helper
DEBUG - 2016-08-31 14:10:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-31 14:10:02 --> Check Exists common_helper.php: No
DEBUG - 2016-08-31 14:10:02 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-31 14:10:02 --> Helper loaded: common_helper
DEBUG - 2016-08-31 14:10:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-31 14:10:02 --> Helper loaded: common_helper
DEBUG - 2016-08-31 14:10:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-31 14:10:03 --> Helper loaded: form_helper
DEBUG - 2016-08-31 14:10:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-31 14:10:03 --> Helper loaded: security_helper
DEBUG - 2016-08-31 14:10:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 14:10:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-31 14:10:03 --> Helper loaded: lang_helper
DEBUG - 2016-08-31 14:10:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-31 14:10:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-31 14:10:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-31 14:10:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-31 14:10:03 --> Helper loaded: atlant_helper
DEBUG - 2016-08-31 14:10:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 14:10:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-31 14:10:03 --> Helper loaded: crypto_helper
DEBUG - 2016-08-31 14:10:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-31 14:10:03 --> Check Exists sidika_helper.php: No
DEBUG - 2016-08-31 14:10:03 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-08-31 14:10:03 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-08-31 14:10:03 --> Helper loaded: sidika_helper
DEBUG - 2016-08-31 14:10:03 --> Database Driver Class Initialized
DEBUG - 2016-08-31 14:10:03 --> Session Class Initialized
DEBUG - 2016-08-31 14:10:03 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-31 14:10:03 --> Helper loaded: string_helper
DEBUG - 2016-08-31 14:10:03 --> Session routines successfully run
DEBUG - 2016-08-31 14:10:03 --> Native_session Class Initialized
DEBUG - 2016-08-31 14:10:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-31 14:10:04 --> Form Validation Class Initialized
DEBUG - 2016-08-31 14:10:04 --> Form Validation Class Initialized
DEBUG - 2016-08-31 14:10:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-31 14:10:04 --> Controller Class Initialized
DEBUG - 2016-08-31 14:10:04 --> Carabiner: Library initialized.
DEBUG - 2016-08-31 14:10:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-31 14:10:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-31 14:10:04 --> Carabiner: library configured.
DEBUG - 2016-08-31 14:10:04 --> Carabiner: library configured.
DEBUG - 2016-08-31 14:10:04 --> User Agent Class Initialized
DEBUG - 2016-08-31 14:10:04 --> Model Class Initialized
DEBUG - 2016-08-31 14:10:04 --> Model Class Initialized
DEBUG - 2016-08-31 14:10:04 --> Model Class Initialized
ERROR - 2016-08-31 14:10:04 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-08-31 14:10:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-08-31 14:10:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-08-31 14:10:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/menu/template_menu.php
DEBUG - 2016-08-31 14:10:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 14:10:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/default.php
DEBUG - 2016-08-31 14:10:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-08-31 14:10:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/menu/template_menu.php
DEBUG - 2016-08-31 14:10:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-31 14:10:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/default.php
DEBUG - 2016-08-31 14:10:04 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-08-31 14:10:04 --> Final output sent to browser
DEBUG - 2016-08-31 14:10:04 --> Total execution time: 2.7970
DEBUG - 2016-08-31 14:10:05 --> Config Class Initialized
DEBUG - 2016-08-31 14:10:05 --> Hooks Class Initialized
DEBUG - 2016-08-31 14:10:05 --> Utf8 Class Initialized
DEBUG - 2016-08-31 14:10:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-31 14:10:05 --> URI Class Initialized
DEBUG - 2016-08-31 14:10:05 --> Router Class Initialized
ERROR - 2016-08-31 14:10:05 --> 404 Page Not Found --> front_end/assets
