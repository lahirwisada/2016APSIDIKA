<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-09-21 14:49:58 --> Config Class Initialized
DEBUG - 2016-09-21 14:49:58 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:49:58 --> Utf8 Class Initialized
DEBUG - 2016-09-21 14:49:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 14:49:58 --> URI Class Initialized
DEBUG - 2016-09-21 14:49:58 --> Router Class Initialized
DEBUG - 2016-09-21 14:49:58 --> Output Class Initialized
DEBUG - 2016-09-21 14:49:58 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 14:49:58 --> Security Class Initialized
DEBUG - 2016-09-21 14:49:58 --> Input Class Initialized
DEBUG - 2016-09-21 14:49:58 --> XSS Filtering completed
DEBUG - 2016-09-21 14:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 14:49:58 --> Language Class Initialized
DEBUG - 2016-09-21 14:49:58 --> Loader Class Initialized
DEBUG - 2016-09-21 14:49:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 14:49:58 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 14:49:58 --> Helper loaded: url_helper
DEBUG - 2016-09-21 14:49:58 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 14:49:58 --> Helper loaded: file_helper
DEBUG - 2016-09-21 14:49:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 14:49:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 14:49:58 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 14:49:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 14:49:58 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 14:49:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 14:49:58 --> Helper loaded: common_helper
DEBUG - 2016-09-21 14:49:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 14:49:58 --> Helper loaded: common_helper
DEBUG - 2016-09-21 14:49:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 14:49:58 --> Helper loaded: form_helper
DEBUG - 2016-09-21 14:49:58 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 14:49:58 --> Helper loaded: security_helper
DEBUG - 2016-09-21 14:49:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 14:49:58 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 14:49:58 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 14:49:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 14:49:58 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 14:49:58 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 14:49:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 14:49:58 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 14:49:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 14:49:58 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 14:49:58 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 14:49:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 14:49:58 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 14:49:58 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 14:49:58 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 14:49:58 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 14:49:58 --> Database Driver Class Initialized
DEBUG - 2016-09-21 14:49:58 --> Session Class Initialized
DEBUG - 2016-09-21 14:49:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 14:49:58 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:49:58 --> A session cookie was not found.
DEBUG - 2016-09-21 14:49:58 --> Session routines successfully run
DEBUG - 2016-09-21 14:49:58 --> Native_session Class Initialized
DEBUG - 2016-09-21 14:49:58 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 14:49:58 --> Form Validation Class Initialized
DEBUG - 2016-09-21 14:49:58 --> Form Validation Class Initialized
DEBUG - 2016-09-21 14:49:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 14:49:58 --> Controller Class Initialized
DEBUG - 2016-09-21 14:49:58 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 14:49:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 14:49:58 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 14:49:58 --> Carabiner: library configured.
DEBUG - 2016-09-21 14:49:58 --> Carabiner: library configured.
DEBUG - 2016-09-21 14:49:58 --> User Agent Class Initialized
DEBUG - 2016-09-21 14:49:58 --> Model Class Initialized
DEBUG - 2016-09-21 14:49:58 --> Model Class Initialized
DEBUG - 2016-09-21 14:49:58 --> Model Class Initialized
DEBUG - 2016-09-21 14:49:58 --> Model Class Initialized
DEBUG - 2016-09-21 14:49:58 --> Model Class Initialized
DEBUG - 2016-09-21 14:49:58 --> Model Class Initialized
DEBUG - 2016-09-21 14:49:58 --> Model Class Initialized
DEBUG - 2016-09-21 14:49:58 --> Model Class Initialized
DEBUG - 2016-09-21 14:49:58 --> Model Class Initialized
DEBUG - 2016-09-21 14:49:58 --> Model Class Initialized
DEBUG - 2016-09-21 14:49:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-21 14:49:59 --> Form Validation Class Initialized
DEBUG - 2016-09-21 14:49:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 14:49:59 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 14:49:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 14:49:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8f8e2926e3f1cbfc3aa536b43cdd0626
DEBUG - 2016-09-21 14:49:59 --> Final output sent to browser
DEBUG - 2016-09-21 14:49:59 --> Total execution time: 0.8428
DEBUG - 2016-09-21 14:51:09 --> Config Class Initialized
DEBUG - 2016-09-21 14:51:09 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:51:09 --> Utf8 Class Initialized
DEBUG - 2016-09-21 14:51:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 14:51:09 --> URI Class Initialized
DEBUG - 2016-09-21 14:51:09 --> Router Class Initialized
DEBUG - 2016-09-21 14:51:09 --> Output Class Initialized
DEBUG - 2016-09-21 14:51:09 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 14:51:09 --> Security Class Initialized
DEBUG - 2016-09-21 14:51:09 --> Input Class Initialized
DEBUG - 2016-09-21 14:51:09 --> XSS Filtering completed
DEBUG - 2016-09-21 14:51:09 --> XSS Filtering completed
DEBUG - 2016-09-21 14:51:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 14:51:09 --> Language Class Initialized
DEBUG - 2016-09-21 14:51:09 --> Loader Class Initialized
DEBUG - 2016-09-21 14:51:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 14:51:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 14:51:09 --> Helper loaded: url_helper
DEBUG - 2016-09-21 14:51:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 14:51:09 --> Helper loaded: file_helper
DEBUG - 2016-09-21 14:51:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 14:51:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 14:51:09 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 14:51:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 14:51:09 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 14:51:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 14:51:09 --> Helper loaded: common_helper
DEBUG - 2016-09-21 14:51:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 14:51:09 --> Helper loaded: common_helper
DEBUG - 2016-09-21 14:51:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 14:51:09 --> Helper loaded: form_helper
DEBUG - 2016-09-21 14:51:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 14:51:09 --> Helper loaded: security_helper
DEBUG - 2016-09-21 14:51:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 14:51:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 14:51:09 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 14:51:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 14:51:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 14:51:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 14:51:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 14:51:09 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 14:51:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 14:51:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 14:51:09 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 14:51:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 14:51:09 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 14:51:09 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 14:51:09 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 14:51:09 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 14:51:09 --> Database Driver Class Initialized
DEBUG - 2016-09-21 14:51:09 --> Session Class Initialized
DEBUG - 2016-09-21 14:51:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 14:51:09 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:51:09 --> Session routines successfully run
DEBUG - 2016-09-21 14:51:09 --> Native_session Class Initialized
DEBUG - 2016-09-21 14:51:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 14:51:09 --> Form Validation Class Initialized
DEBUG - 2016-09-21 14:51:09 --> Form Validation Class Initialized
DEBUG - 2016-09-21 14:51:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 14:51:09 --> Controller Class Initialized
DEBUG - 2016-09-21 14:51:09 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 14:51:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 14:51:09 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 14:51:09 --> Carabiner: library configured.
DEBUG - 2016-09-21 14:51:09 --> Carabiner: library configured.
DEBUG - 2016-09-21 14:51:09 --> User Agent Class Initialized
DEBUG - 2016-09-21 14:51:09 --> Model Class Initialized
DEBUG - 2016-09-21 14:51:09 --> Model Class Initialized
DEBUG - 2016-09-21 14:51:09 --> Model Class Initialized
DEBUG - 2016-09-21 14:51:09 --> Model Class Initialized
DEBUG - 2016-09-21 14:51:09 --> Model Class Initialized
DEBUG - 2016-09-21 14:51:09 --> Model Class Initialized
DEBUG - 2016-09-21 14:51:09 --> Model Class Initialized
DEBUG - 2016-09-21 14:51:09 --> Model Class Initialized
DEBUG - 2016-09-21 14:51:09 --> Model Class Initialized
DEBUG - 2016-09-21 14:51:09 --> Model Class Initialized
DEBUG - 2016-09-21 14:51:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 14:51:10 --> Pagination Class Initialized
DEBUG - 2016-09-21 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-21 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 14:51:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 14:51:10 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-21 14:51:10 --> Final output sent to browser
DEBUG - 2016-09-21 14:51:10 --> Total execution time: 0.5806
DEBUG - 2016-09-21 14:51:12 --> Config Class Initialized
DEBUG - 2016-09-21 14:51:12 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:51:12 --> Utf8 Class Initialized
DEBUG - 2016-09-21 14:51:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 14:51:12 --> URI Class Initialized
DEBUG - 2016-09-21 14:51:12 --> Router Class Initialized
DEBUG - 2016-09-21 14:51:12 --> Output Class Initialized
DEBUG - 2016-09-21 14:51:12 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 14:51:12 --> Security Class Initialized
DEBUG - 2016-09-21 14:51:12 --> Input Class Initialized
DEBUG - 2016-09-21 14:51:12 --> XSS Filtering completed
DEBUG - 2016-09-21 14:51:12 --> XSS Filtering completed
DEBUG - 2016-09-21 14:51:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 14:51:12 --> Language Class Initialized
DEBUG - 2016-09-21 14:51:12 --> Loader Class Initialized
DEBUG - 2016-09-21 14:51:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 14:51:12 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 14:51:12 --> Helper loaded: url_helper
DEBUG - 2016-09-21 14:51:12 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 14:51:12 --> Helper loaded: file_helper
DEBUG - 2016-09-21 14:51:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 14:51:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 14:51:12 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 14:51:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 14:51:12 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 14:51:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 14:51:12 --> Helper loaded: common_helper
DEBUG - 2016-09-21 14:51:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 14:51:12 --> Helper loaded: common_helper
DEBUG - 2016-09-21 14:51:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 14:51:12 --> Helper loaded: form_helper
DEBUG - 2016-09-21 14:51:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 14:51:12 --> Helper loaded: security_helper
DEBUG - 2016-09-21 14:51:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 14:51:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 14:51:12 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 14:51:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 14:51:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 14:51:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 14:51:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 14:51:12 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 14:51:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 14:51:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 14:51:12 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 14:51:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 14:51:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 14:51:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 14:51:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 14:51:12 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 14:51:12 --> Database Driver Class Initialized
DEBUG - 2016-09-21 14:51:12 --> Session Class Initialized
DEBUG - 2016-09-21 14:51:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 14:51:12 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:51:12 --> Session routines successfully run
DEBUG - 2016-09-21 14:51:12 --> Native_session Class Initialized
DEBUG - 2016-09-21 14:51:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 14:51:12 --> Form Validation Class Initialized
DEBUG - 2016-09-21 14:51:12 --> Form Validation Class Initialized
DEBUG - 2016-09-21 14:51:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 14:51:12 --> Controller Class Initialized
DEBUG - 2016-09-21 14:51:12 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 14:51:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 14:51:12 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 14:51:12 --> Carabiner: library configured.
DEBUG - 2016-09-21 14:51:12 --> Carabiner: library configured.
DEBUG - 2016-09-21 14:51:12 --> User Agent Class Initialized
DEBUG - 2016-09-21 14:51:12 --> Model Class Initialized
DEBUG - 2016-09-21 14:51:12 --> Model Class Initialized
DEBUG - 2016-09-21 14:51:12 --> Model Class Initialized
DEBUG - 2016-09-21 14:51:12 --> Model Class Initialized
DEBUG - 2016-09-21 14:51:12 --> Model Class Initialized
DEBUG - 2016-09-21 14:51:12 --> Model Class Initialized
DEBUG - 2016-09-21 14:51:12 --> Model Class Initialized
DEBUG - 2016-09-21 14:51:12 --> Model Class Initialized
DEBUG - 2016-09-21 14:51:12 --> Model Class Initialized
DEBUG - 2016-09-21 14:51:12 --> Model Class Initialized
DEBUG - 2016-09-21 14:51:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-21 14:51:12 --> Form Validation Class Initialized
DEBUG - 2016-09-21 14:51:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 14:51:12 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 14:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 14:51:13 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4abf371e4626b3dd590ee8a993b8c77d
DEBUG - 2016-09-21 14:51:13 --> Final output sent to browser
DEBUG - 2016-09-21 14:51:13 --> Total execution time: 0.3976
DEBUG - 2016-09-21 14:57:40 --> Config Class Initialized
DEBUG - 2016-09-21 14:57:40 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:57:40 --> Utf8 Class Initialized
DEBUG - 2016-09-21 14:57:40 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 14:57:40 --> URI Class Initialized
DEBUG - 2016-09-21 14:57:40 --> Router Class Initialized
DEBUG - 2016-09-21 14:57:40 --> Output Class Initialized
DEBUG - 2016-09-21 14:57:40 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 14:57:40 --> Security Class Initialized
DEBUG - 2016-09-21 14:57:40 --> Input Class Initialized
DEBUG - 2016-09-21 14:57:40 --> XSS Filtering completed
DEBUG - 2016-09-21 14:57:40 --> XSS Filtering completed
DEBUG - 2016-09-21 14:57:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 14:57:40 --> Language Class Initialized
DEBUG - 2016-09-21 14:57:40 --> Loader Class Initialized
DEBUG - 2016-09-21 14:57:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 14:57:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 14:57:40 --> Helper loaded: url_helper
DEBUG - 2016-09-21 14:57:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 14:57:40 --> Helper loaded: file_helper
DEBUG - 2016-09-21 14:57:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 14:57:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 14:57:40 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 14:57:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 14:57:40 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 14:57:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 14:57:40 --> Helper loaded: common_helper
DEBUG - 2016-09-21 14:57:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 14:57:40 --> Helper loaded: common_helper
DEBUG - 2016-09-21 14:57:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 14:57:40 --> Helper loaded: form_helper
DEBUG - 2016-09-21 14:57:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 14:57:40 --> Helper loaded: security_helper
DEBUG - 2016-09-21 14:57:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 14:57:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 14:57:40 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 14:57:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 14:57:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 14:57:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 14:57:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 14:57:40 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 14:57:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 14:57:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 14:57:40 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 14:57:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 14:57:40 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 14:57:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 14:57:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 14:57:40 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 14:57:40 --> Database Driver Class Initialized
DEBUG - 2016-09-21 14:57:40 --> Session Class Initialized
DEBUG - 2016-09-21 14:57:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 14:57:40 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:57:40 --> Session routines successfully run
DEBUG - 2016-09-21 14:57:40 --> Native_session Class Initialized
DEBUG - 2016-09-21 14:57:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 14:57:40 --> Form Validation Class Initialized
DEBUG - 2016-09-21 14:57:40 --> Form Validation Class Initialized
DEBUG - 2016-09-21 14:57:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 14:57:40 --> Controller Class Initialized
DEBUG - 2016-09-21 14:57:40 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 14:57:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 14:57:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 14:57:40 --> Carabiner: library configured.
DEBUG - 2016-09-21 14:57:40 --> Carabiner: library configured.
DEBUG - 2016-09-21 14:57:40 --> User Agent Class Initialized
DEBUG - 2016-09-21 14:57:40 --> Model Class Initialized
DEBUG - 2016-09-21 14:57:40 --> Model Class Initialized
DEBUG - 2016-09-21 14:57:40 --> Model Class Initialized
DEBUG - 2016-09-21 14:57:40 --> Model Class Initialized
DEBUG - 2016-09-21 14:57:40 --> Model Class Initialized
DEBUG - 2016-09-21 14:57:40 --> Model Class Initialized
DEBUG - 2016-09-21 14:57:40 --> Model Class Initialized
DEBUG - 2016-09-21 14:57:40 --> Model Class Initialized
DEBUG - 2016-09-21 14:57:40 --> Model Class Initialized
DEBUG - 2016-09-21 14:57:40 --> Model Class Initialized
DEBUG - 2016-09-21 14:57:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-21 14:57:40 --> Form Validation Class Initialized
DEBUG - 2016-09-21 14:57:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 14:57:40 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 14:57:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 14:57:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4abf371e4626b3dd590ee8a993b8c77d
DEBUG - 2016-09-21 14:57:40 --> Final output sent to browser
DEBUG - 2016-09-21 14:57:40 --> Total execution time: 0.3263
DEBUG - 2016-09-21 14:59:59 --> Config Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Utf8 Class Initialized
DEBUG - 2016-09-21 14:59:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 14:59:59 --> URI Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Router Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Output Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 14:59:59 --> Security Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Input Class Initialized
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 14:59:59 --> Language Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Loader Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 14:59:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 14:59:59 --> Helper loaded: url_helper
DEBUG - 2016-09-21 14:59:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 14:59:59 --> Helper loaded: file_helper
DEBUG - 2016-09-21 14:59:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 14:59:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 14:59:59 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 14:59:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 14:59:59 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 14:59:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 14:59:59 --> Helper loaded: common_helper
DEBUG - 2016-09-21 14:59:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 14:59:59 --> Helper loaded: common_helper
DEBUG - 2016-09-21 14:59:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 14:59:59 --> Helper loaded: form_helper
DEBUG - 2016-09-21 14:59:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 14:59:59 --> Helper loaded: security_helper
DEBUG - 2016-09-21 14:59:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 14:59:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 14:59:59 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 14:59:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 14:59:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 14:59:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 14:59:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 14:59:59 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 14:59:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 14:59:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 14:59:59 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 14:59:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 14:59:59 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 14:59:59 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 14:59:59 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 14:59:59 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 14:59:59 --> Database Driver Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Session Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 14:59:59 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:59:59 --> Session routines successfully run
DEBUG - 2016-09-21 14:59:59 --> Native_session Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 14:59:59 --> Form Validation Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Form Validation Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 14:59:59 --> Controller Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 14:59:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 14:59:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 14:59:59 --> Carabiner: library configured.
DEBUG - 2016-09-21 14:59:59 --> Carabiner: library configured.
DEBUG - 2016-09-21 14:59:59 --> User Agent Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Model Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Model Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Model Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Model Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Model Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Model Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Model Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Model Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Model Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Model Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-21 14:59:59 --> Form Validation Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 14:59:59 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-21 14:59:59 --> Unable to find validation rule: 
DEBUG - 2016-09-21 14:59:59 --> Unable to find validation rule: 
DEBUG - 2016-09-21 14:59:59 --> Unable to find validation rule: 
DEBUG - 2016-09-21 14:59:59 --> Unable to find validation rule: 
ERROR - 2016-09-21 14:59:59 --> Severity: Notice  --> Undefined index: level E:\www\GitHub\2016APSIDIKA\application\models\model_tr_diklat_persyaratan.php 45
ERROR - 2016-09-21 14:59:59 --> Severity: Notice  --> Undefined index: level E:\www\GitHub\2016APSIDIKA\application\models\model_tr_diklat_persyaratan.php 45
DEBUG - 2016-09-21 14:59:59 --> Config Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Hooks Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Utf8 Class Initialized
DEBUG - 2016-09-21 14:59:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 14:59:59 --> URI Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Router Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Output Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 14:59:59 --> Security Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Input Class Initialized
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> XSS Filtering completed
DEBUG - 2016-09-21 14:59:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 14:59:59 --> Language Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Loader Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 14:59:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 14:59:59 --> Helper loaded: url_helper
DEBUG - 2016-09-21 14:59:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 14:59:59 --> Helper loaded: file_helper
DEBUG - 2016-09-21 14:59:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 14:59:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 14:59:59 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 14:59:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 14:59:59 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 14:59:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 14:59:59 --> Helper loaded: common_helper
DEBUG - 2016-09-21 14:59:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 14:59:59 --> Helper loaded: common_helper
DEBUG - 2016-09-21 14:59:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 14:59:59 --> Helper loaded: form_helper
DEBUG - 2016-09-21 14:59:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 14:59:59 --> Helper loaded: security_helper
DEBUG - 2016-09-21 14:59:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 14:59:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 14:59:59 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 14:59:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 14:59:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 14:59:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 14:59:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 14:59:59 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 14:59:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 14:59:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 14:59:59 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 14:59:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 14:59:59 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 14:59:59 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 14:59:59 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 14:59:59 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 14:59:59 --> Database Driver Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Session Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 14:59:59 --> Helper loaded: string_helper
DEBUG - 2016-09-21 14:59:59 --> Session routines successfully run
DEBUG - 2016-09-21 14:59:59 --> Native_session Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 14:59:59 --> Form Validation Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Form Validation Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 14:59:59 --> Controller Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 14:59:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 14:59:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 14:59:59 --> Carabiner: library configured.
DEBUG - 2016-09-21 14:59:59 --> Carabiner: library configured.
DEBUG - 2016-09-21 14:59:59 --> User Agent Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Model Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Model Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Model Class Initialized
DEBUG - 2016-09-21 14:59:59 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 15:00:00 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 15:00:00 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-21 15:00:00 --> Final output sent to browser
DEBUG - 2016-09-21 15:00:00 --> Total execution time: 0.3487
DEBUG - 2016-09-21 15:00:00 --> Config Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Utf8 Class Initialized
DEBUG - 2016-09-21 15:00:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 15:00:00 --> URI Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Router Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Output Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 15:00:00 --> Security Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Input Class Initialized
DEBUG - 2016-09-21 15:00:00 --> XSS Filtering completed
DEBUG - 2016-09-21 15:00:00 --> XSS Filtering completed
DEBUG - 2016-09-21 15:00:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 15:00:00 --> Language Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Loader Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 15:00:00 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 15:00:00 --> Helper loaded: url_helper
DEBUG - 2016-09-21 15:00:00 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 15:00:00 --> Helper loaded: file_helper
DEBUG - 2016-09-21 15:00:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 15:00:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 15:00:00 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 15:00:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 15:00:00 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 15:00:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 15:00:00 --> Helper loaded: common_helper
DEBUG - 2016-09-21 15:00:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 15:00:00 --> Helper loaded: common_helper
DEBUG - 2016-09-21 15:00:00 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 15:00:00 --> Helper loaded: form_helper
DEBUG - 2016-09-21 15:00:00 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 15:00:00 --> Helper loaded: security_helper
DEBUG - 2016-09-21 15:00:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 15:00:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 15:00:00 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 15:00:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 15:00:00 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 15:00:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 15:00:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 15:00:00 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 15:00:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 15:00:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 15:00:00 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 15:00:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 15:00:00 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 15:00:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 15:00:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 15:00:00 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 15:00:00 --> Database Driver Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Session Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 15:00:00 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:00:00 --> Session routines successfully run
DEBUG - 2016-09-21 15:00:00 --> Native_session Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 15:00:00 --> Form Validation Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Form Validation Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 15:00:00 --> Controller Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 15:00:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 15:00:00 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 15:00:00 --> Carabiner: library configured.
DEBUG - 2016-09-21 15:00:00 --> Carabiner: library configured.
DEBUG - 2016-09-21 15:00:00 --> User Agent Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 15:00:00 --> Pagination Class Initialized
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 15:00:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 15:00:00 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-21 15:00:00 --> Final output sent to browser
DEBUG - 2016-09-21 15:00:00 --> Total execution time: 0.3777
DEBUG - 2016-09-21 15:00:03 --> Config Class Initialized
DEBUG - 2016-09-21 15:00:03 --> Hooks Class Initialized
DEBUG - 2016-09-21 15:00:03 --> Utf8 Class Initialized
DEBUG - 2016-09-21 15:00:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 15:00:03 --> URI Class Initialized
DEBUG - 2016-09-21 15:00:03 --> Router Class Initialized
DEBUG - 2016-09-21 15:00:03 --> Output Class Initialized
DEBUG - 2016-09-21 15:00:03 --> Security Class Initialized
DEBUG - 2016-09-21 15:00:03 --> Input Class Initialized
DEBUG - 2016-09-21 15:00:03 --> XSS Filtering completed
DEBUG - 2016-09-21 15:00:03 --> XSS Filtering completed
DEBUG - 2016-09-21 15:00:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 15:00:03 --> Language Class Initialized
DEBUG - 2016-09-21 15:00:03 --> Loader Class Initialized
DEBUG - 2016-09-21 15:00:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 15:00:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 15:00:04 --> Helper loaded: url_helper
DEBUG - 2016-09-21 15:00:04 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 15:00:04 --> Helper loaded: file_helper
DEBUG - 2016-09-21 15:00:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 15:00:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 15:00:04 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 15:00:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 15:00:04 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 15:00:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 15:00:04 --> Helper loaded: common_helper
DEBUG - 2016-09-21 15:00:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 15:00:04 --> Helper loaded: common_helper
DEBUG - 2016-09-21 15:00:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 15:00:04 --> Helper loaded: form_helper
DEBUG - 2016-09-21 15:00:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 15:00:04 --> Helper loaded: security_helper
DEBUG - 2016-09-21 15:00:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 15:00:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 15:00:04 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 15:00:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 15:00:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 15:00:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 15:00:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 15:00:04 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 15:00:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 15:00:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 15:00:04 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 15:00:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 15:00:04 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 15:00:04 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 15:00:04 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 15:00:04 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 15:00:04 --> Database Driver Class Initialized
DEBUG - 2016-09-21 15:00:04 --> Session Class Initialized
DEBUG - 2016-09-21 15:00:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 15:00:04 --> Helper loaded: string_helper
DEBUG - 2016-09-21 15:00:04 --> Session routines successfully run
DEBUG - 2016-09-21 15:00:04 --> Native_session Class Initialized
DEBUG - 2016-09-21 15:00:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 15:00:04 --> Form Validation Class Initialized
DEBUG - 2016-09-21 15:00:04 --> Form Validation Class Initialized
DEBUG - 2016-09-21 15:00:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 15:00:04 --> Controller Class Initialized
DEBUG - 2016-09-21 15:00:04 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 15:00:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 15:00:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 15:00:04 --> Carabiner: library configured.
DEBUG - 2016-09-21 15:00:04 --> Carabiner: library configured.
DEBUG - 2016-09-21 15:00:04 --> User Agent Class Initialized
DEBUG - 2016-09-21 15:00:04 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:04 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:04 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:04 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:04 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:04 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:04 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:04 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:04 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:04 --> Model Class Initialized
DEBUG - 2016-09-21 15:00:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-21 15:00:04 --> Form Validation Class Initialized
DEBUG - 2016-09-21 15:00:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 15:00:04 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 15:00:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 15:00:04 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4abf371e4626b3dd590ee8a993b8c77d
DEBUG - 2016-09-21 15:00:04 --> Final output sent to browser
DEBUG - 2016-09-21 15:00:04 --> Total execution time: 0.4082
DEBUG - 2016-09-21 16:16:08 --> Config Class Initialized
DEBUG - 2016-09-21 16:16:09 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:16:09 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:16:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:16:09 --> URI Class Initialized
DEBUG - 2016-09-21 16:16:09 --> Router Class Initialized
DEBUG - 2016-09-21 16:16:09 --> No URI present. Default controller set.
DEBUG - 2016-09-21 16:16:09 --> Output Class Initialized
DEBUG - 2016-09-21 16:16:09 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 16:16:09 --> Security Class Initialized
DEBUG - 2016-09-21 16:16:09 --> Input Class Initialized
DEBUG - 2016-09-21 16:16:09 --> XSS Filtering completed
DEBUG - 2016-09-21 16:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:16:09 --> Language Class Initialized
DEBUG - 2016-09-21 16:16:09 --> Loader Class Initialized
DEBUG - 2016-09-21 16:16:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:16:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:16:09 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:16:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:16:09 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:16:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:16:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:16:09 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:16:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:16:09 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:16:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:16:09 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:16:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:16:09 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:16:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:16:09 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:16:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:16:09 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:16:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:16:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:16:09 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:16:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:16:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:16:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:16:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:16:09 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:16:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:16:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:16:09 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:16:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:16:09 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:16:09 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:16:09 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:16:09 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:16:09 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:16:09 --> Session Class Initialized
DEBUG - 2016-09-21 16:16:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:16:09 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:16:09 --> Session routines successfully run
DEBUG - 2016-09-21 16:16:09 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:16:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:16:09 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:16:09 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:16:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:16:09 --> Controller Class Initialized
DEBUG - 2016-09-21 16:16:09 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:16:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:16:09 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:16:09 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:16:09 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:16:09 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:16:10 --> Model Class Initialized
DEBUG - 2016-09-21 16:16:10 --> Model Class Initialized
DEBUG - 2016-09-21 16:16:10 --> Model Class Initialized
ERROR - 2016-09-21 16:16:14 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-21 16:16:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-21 16:16:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-21 16:16:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-21 16:16:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:16:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-21 16:16:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-21 16:16:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-21 16:16:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-21 16:16:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-21 16:16:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:16:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-21 16:16:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-21 16:16:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:16:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-21 16:16:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-21 16:16:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-21 16:16:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-21 16:16:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-21 16:16:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:16:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-21 16:16:14 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-21 16:16:14 --> Final output sent to browser
DEBUG - 2016-09-21 16:16:14 --> Total execution time: 5.9749
DEBUG - 2016-09-21 16:16:21 --> Config Class Initialized
DEBUG - 2016-09-21 16:16:21 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:16:21 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:16:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:16:21 --> URI Class Initialized
DEBUG - 2016-09-21 16:16:21 --> Router Class Initialized
DEBUG - 2016-09-21 16:16:21 --> Output Class Initialized
DEBUG - 2016-09-21 16:16:22 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 16:16:22 --> Security Class Initialized
DEBUG - 2016-09-21 16:16:22 --> Input Class Initialized
DEBUG - 2016-09-21 16:16:22 --> XSS Filtering completed
DEBUG - 2016-09-21 16:16:22 --> XSS Filtering completed
DEBUG - 2016-09-21 16:16:22 --> XSS Filtering completed
DEBUG - 2016-09-21 16:16:22 --> XSS Filtering completed
DEBUG - 2016-09-21 16:16:22 --> XSS Filtering completed
DEBUG - 2016-09-21 16:16:22 --> XSS Filtering completed
DEBUG - 2016-09-21 16:16:22 --> XSS Filtering completed
DEBUG - 2016-09-21 16:16:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:16:22 --> Language Class Initialized
DEBUG - 2016-09-21 16:16:22 --> Loader Class Initialized
DEBUG - 2016-09-21 16:16:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:16:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:16:22 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:16:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:16:22 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:16:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:16:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:16:22 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:16:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:16:22 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:16:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:16:22 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:16:22 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:16:22 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:16:22 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:16:22 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:16:22 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:16:22 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:16:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:16:22 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:16:22 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:16:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:16:22 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:16:22 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:16:22 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:16:22 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:16:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:16:22 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:16:22 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:16:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:16:22 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:16:22 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:16:22 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:16:22 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:16:22 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:16:22 --> Session Class Initialized
DEBUG - 2016-09-21 16:16:22 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:16:22 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:16:22 --> Session routines successfully run
DEBUG - 2016-09-21 16:16:22 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:16:22 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:16:22 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:16:22 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:16:22 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:16:22 --> Controller Class Initialized
DEBUG - 2016-09-21 16:16:22 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:16:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:16:22 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:16:22 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:16:22 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:16:22 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:16:22 --> Model Class Initialized
DEBUG - 2016-09-21 16:16:22 --> Model Class Initialized
DEBUG - 2016-09-21 16:16:22 --> Model Class Initialized
DEBUG - 2016-09-21 16:16:22 --> Model Class Initialized
DEBUG - 2016-09-21 16:16:22 --> Model Class Initialized
DEBUG - 2016-09-21 16:16:22 --> Model Class Initialized
DEBUG - 2016-09-21 16:16:22 --> Model Class Initialized
DEBUG - 2016-09-21 16:16:22 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-21 16:16:22 --> Final output sent to browser
DEBUG - 2016-09-21 16:16:22 --> Total execution time: 1.0126
DEBUG - 2016-09-21 16:19:31 --> Config Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:19:31 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:19:31 --> URI Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Router Class Initialized
DEBUG - 2016-09-21 16:19:31 --> No URI present. Default controller set.
DEBUG - 2016-09-21 16:19:31 --> Output Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 16:19:31 --> Security Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Input Class Initialized
DEBUG - 2016-09-21 16:19:31 --> XSS Filtering completed
DEBUG - 2016-09-21 16:19:31 --> XSS Filtering completed
DEBUG - 2016-09-21 16:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:19:31 --> Language Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Loader Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:19:31 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:19:31 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:19:31 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:19:31 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:19:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:19:31 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:19:31 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:19:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:19:31 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:19:31 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:19:31 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:19:31 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:19:31 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:19:31 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:19:31 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:19:31 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:19:31 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:19:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:19:31 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:19:31 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:19:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:19:31 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:19:31 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:19:31 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:19:31 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:19:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:19:31 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:19:31 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:19:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:19:31 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:19:31 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:19:31 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:19:31 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:19:31 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Session Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:19:31 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:19:31 --> Session routines successfully run
DEBUG - 2016-09-21 16:19:31 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:19:31 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:19:31 --> Controller Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:19:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:19:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:19:31 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:19:31 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:19:31 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Model Class Initialized
ERROR - 2016-09-21 16:19:31 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-21 16:19:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-21 16:19:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-21 16:19:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-21 16:19:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:19:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-21 16:19:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-21 16:19:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-21 16:19:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-21 16:19:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-21 16:19:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:19:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-21 16:19:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-21 16:19:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:19:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-21 16:19:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-21 16:19:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-21 16:19:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-21 16:19:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-21 16:19:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:19:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-21 16:19:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-21 16:19:31 --> Final output sent to browser
DEBUG - 2016-09-21 16:19:31 --> Total execution time: 0.3813
DEBUG - 2016-09-21 16:19:31 --> Config Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:19:31 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:19:31 --> URI Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Router Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Output Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 16:19:31 --> Security Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Input Class Initialized
DEBUG - 2016-09-21 16:19:31 --> XSS Filtering completed
DEBUG - 2016-09-21 16:19:31 --> XSS Filtering completed
DEBUG - 2016-09-21 16:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:19:31 --> Language Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Loader Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:19:31 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:19:31 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:19:31 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:19:31 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:19:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:19:31 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:19:31 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:19:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:19:31 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:19:31 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:19:31 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:19:31 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:19:31 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:19:31 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:19:31 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:19:31 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:19:31 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:19:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:19:31 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:19:31 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:19:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:19:31 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:19:31 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:19:31 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:19:31 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:19:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:19:31 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:19:31 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:19:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:19:31 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:19:31 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:19:31 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:19:31 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:19:31 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Session Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:19:31 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:19:31 --> Session routines successfully run
DEBUG - 2016-09-21 16:19:31 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:19:31 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:19:31 --> Controller Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:19:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:19:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:19:31 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:19:31 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:19:31 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:19:31 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:32 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:32 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-21 16:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 16:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 16:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 16:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 16:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 16:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 16:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 16:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 16:19:32 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-09-21 16:19:32 --> Final output sent to browser
DEBUG - 2016-09-21 16:19:32 --> Total execution time: 0.4020
DEBUG - 2016-09-21 16:19:39 --> Config Class Initialized
DEBUG - 2016-09-21 16:19:39 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:19:39 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:19:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:19:39 --> URI Class Initialized
DEBUG - 2016-09-21 16:19:39 --> Router Class Initialized
DEBUG - 2016-09-21 16:19:39 --> Output Class Initialized
DEBUG - 2016-09-21 16:19:39 --> Security Class Initialized
DEBUG - 2016-09-21 16:19:39 --> Input Class Initialized
DEBUG - 2016-09-21 16:19:39 --> XSS Filtering completed
DEBUG - 2016-09-21 16:19:39 --> XSS Filtering completed
DEBUG - 2016-09-21 16:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:19:39 --> Language Class Initialized
DEBUG - 2016-09-21 16:19:39 --> Loader Class Initialized
DEBUG - 2016-09-21 16:19:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:19:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:19:40 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:19:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:19:40 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:19:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:19:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:19:40 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:19:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:19:40 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:19:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:19:40 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:19:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:19:40 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:19:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:19:40 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:19:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:19:40 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:19:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:19:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:19:40 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:19:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:19:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:19:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:19:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:19:40 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:19:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:19:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:19:40 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:19:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:19:40 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:19:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:19:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:19:40 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:19:40 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:19:40 --> Session Class Initialized
DEBUG - 2016-09-21 16:19:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:19:40 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:19:40 --> Session routines successfully run
DEBUG - 2016-09-21 16:19:40 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:19:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:19:40 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:19:40 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:19:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:19:40 --> Controller Class Initialized
DEBUG - 2016-09-21 16:19:40 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:19:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:19:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:19:40 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:19:40 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:19:40 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:19:40 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:40 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:40 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:40 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:40 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:40 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:40 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:40 --> Model Class Initialized
ERROR - 2016-09-21 16:19:40 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-21 16:19:40 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-21 16:19:40 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-09-21 16:19:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-21 16:19:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-21 16:19:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-21 16:19:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-21 16:19:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-09-21 16:19:40 --> Final output sent to browser
DEBUG - 2016-09-21 16:19:40 --> Total execution time: 0.4381
DEBUG - 2016-09-21 16:19:40 --> Config Class Initialized
DEBUG - 2016-09-21 16:19:40 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:19:40 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:19:40 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:19:40 --> URI Class Initialized
DEBUG - 2016-09-21 16:19:40 --> Router Class Initialized
ERROR - 2016-09-21 16:19:40 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-09-21 16:19:50 --> Config Class Initialized
DEBUG - 2016-09-21 16:19:50 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:19:50 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:19:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:19:50 --> URI Class Initialized
DEBUG - 2016-09-21 16:19:50 --> Router Class Initialized
DEBUG - 2016-09-21 16:19:50 --> Output Class Initialized
DEBUG - 2016-09-21 16:19:50 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 16:19:50 --> Security Class Initialized
DEBUG - 2016-09-21 16:19:50 --> Input Class Initialized
DEBUG - 2016-09-21 16:19:50 --> XSS Filtering completed
DEBUG - 2016-09-21 16:19:50 --> XSS Filtering completed
DEBUG - 2016-09-21 16:19:50 --> XSS Filtering completed
DEBUG - 2016-09-21 16:19:50 --> XSS Filtering completed
DEBUG - 2016-09-21 16:19:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:19:50 --> Language Class Initialized
DEBUG - 2016-09-21 16:19:51 --> Loader Class Initialized
DEBUG - 2016-09-21 16:19:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:19:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:19:51 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:19:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:19:51 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:19:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:19:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:19:51 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:19:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:19:51 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:19:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:19:51 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:19:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:19:51 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:19:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:19:51 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:19:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:19:51 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:19:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:19:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:19:51 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:19:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:19:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:19:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:19:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:19:51 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:19:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:19:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:19:51 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:19:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:19:51 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:19:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:19:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:19:51 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:19:51 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:19:51 --> Session Class Initialized
DEBUG - 2016-09-21 16:19:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:19:51 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:19:51 --> Session routines successfully run
DEBUG - 2016-09-21 16:19:51 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:19:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:19:51 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:19:51 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:19:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:19:51 --> Controller Class Initialized
DEBUG - 2016-09-21 16:19:51 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:19:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:19:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:19:51 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:19:51 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:19:51 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:19:51 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:51 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:51 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:51 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:51 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:51 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:51 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:51 --> Model Class Initialized
ERROR - 2016-09-21 16:19:51 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-21 16:19:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-21 16:19:51 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:19:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:19:51 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-21 16:19:51 --> Config Class Initialized
DEBUG - 2016-09-21 16:19:51 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:19:51 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:19:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:19:51 --> URI Class Initialized
DEBUG - 2016-09-21 16:19:51 --> Router Class Initialized
DEBUG - 2016-09-21 16:19:51 --> No URI present. Default controller set.
DEBUG - 2016-09-21 16:19:51 --> Output Class Initialized
DEBUG - 2016-09-21 16:19:51 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 16:19:51 --> Security Class Initialized
DEBUG - 2016-09-21 16:19:51 --> Input Class Initialized
DEBUG - 2016-09-21 16:19:51 --> XSS Filtering completed
DEBUG - 2016-09-21 16:19:51 --> XSS Filtering completed
DEBUG - 2016-09-21 16:19:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:19:51 --> Language Class Initialized
DEBUG - 2016-09-21 16:19:51 --> Loader Class Initialized
DEBUG - 2016-09-21 16:19:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:19:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:19:51 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:19:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:19:51 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:19:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:19:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:19:51 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:19:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:19:51 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:19:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:19:51 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:19:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:19:51 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:19:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:19:51 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:19:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:19:51 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:19:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:19:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:19:51 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:19:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:19:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:19:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:19:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:19:51 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:19:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:19:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:19:51 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:19:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:19:52 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:19:52 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:19:52 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:19:52 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:19:52 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Session Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:19:52 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:19:52 --> Session routines successfully run
DEBUG - 2016-09-21 16:19:52 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:19:52 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:19:52 --> Controller Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:19:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:19:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:19:52 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:19:52 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:19:52 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Model Class Initialized
ERROR - 2016-09-21 16:19:52 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-21 16:19:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-21 16:19:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-21 16:19:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-21 16:19:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:19:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-21 16:19:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-21 16:19:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-21 16:19:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-21 16:19:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-21 16:19:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:19:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-21 16:19:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-21 16:19:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:19:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-21 16:19:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-21 16:19:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-21 16:19:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-21 16:19:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-21 16:19:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:19:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-21 16:19:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-21 16:19:52 --> Final output sent to browser
DEBUG - 2016-09-21 16:19:52 --> Total execution time: 0.4433
DEBUG - 2016-09-21 16:19:52 --> Config Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:19:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:19:52 --> URI Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Router Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Output Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 16:19:52 --> Security Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Input Class Initialized
DEBUG - 2016-09-21 16:19:52 --> XSS Filtering completed
DEBUG - 2016-09-21 16:19:52 --> XSS Filtering completed
DEBUG - 2016-09-21 16:19:52 --> XSS Filtering completed
DEBUG - 2016-09-21 16:19:52 --> XSS Filtering completed
DEBUG - 2016-09-21 16:19:52 --> XSS Filtering completed
DEBUG - 2016-09-21 16:19:52 --> XSS Filtering completed
DEBUG - 2016-09-21 16:19:52 --> XSS Filtering completed
DEBUG - 2016-09-21 16:19:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:19:52 --> Language Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Loader Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:19:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:19:52 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:19:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:19:52 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:19:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:19:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:19:52 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:19:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:19:52 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:19:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:19:52 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:19:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:19:52 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:19:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:19:52 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:19:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:19:52 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:19:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:19:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:19:52 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:19:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:19:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:19:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:19:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:19:52 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:19:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:19:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:19:52 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:19:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:19:52 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:19:52 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:19:52 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:19:52 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:19:52 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Session Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:19:52 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:19:52 --> Session routines successfully run
DEBUG - 2016-09-21 16:19:52 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:19:52 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:19:52 --> Controller Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:19:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:19:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:19:52 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:19:52 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:19:52 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Model Class Initialized
DEBUG - 2016-09-21 16:19:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-21 16:19:52 --> Final output sent to browser
DEBUG - 2016-09-21 16:19:52 --> Total execution time: 0.5387
DEBUG - 2016-09-21 16:20:07 --> Config Class Initialized
DEBUG - 2016-09-21 16:20:07 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:20:07 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:20:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:20:07 --> URI Class Initialized
DEBUG - 2016-09-21 16:20:07 --> Router Class Initialized
DEBUG - 2016-09-21 16:20:07 --> No URI present. Default controller set.
DEBUG - 2016-09-21 16:20:07 --> Output Class Initialized
DEBUG - 2016-09-21 16:20:07 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 16:20:07 --> Security Class Initialized
DEBUG - 2016-09-21 16:20:07 --> Input Class Initialized
DEBUG - 2016-09-21 16:20:07 --> XSS Filtering completed
DEBUG - 2016-09-21 16:20:07 --> XSS Filtering completed
DEBUG - 2016-09-21 16:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:20:07 --> Language Class Initialized
DEBUG - 2016-09-21 16:20:07 --> Loader Class Initialized
DEBUG - 2016-09-21 16:20:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:20:07 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:20:07 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:20:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:20:07 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:20:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:20:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:20:07 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:20:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:20:07 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:20:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:20:07 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:20:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:20:07 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:20:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:20:07 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:20:07 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:20:08 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:20:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:20:08 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:20:08 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:20:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:20:08 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:20:08 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:20:08 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:20:08 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:20:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:20:08 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:20:08 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:20:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:20:08 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:20:08 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:20:08 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:20:08 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:20:08 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Session Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:20:08 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:20:08 --> Session routines successfully run
DEBUG - 2016-09-21 16:20:08 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:20:08 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:20:08 --> Controller Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:20:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:20:08 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:20:08 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:20:08 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:20:08 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Model Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Model Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Model Class Initialized
ERROR - 2016-09-21 16:20:08 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-21 16:20:08 --> Config Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-21 16:20:08 --> Final output sent to browser
DEBUG - 2016-09-21 16:20:08 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Total execution time: 0.4914
DEBUG - 2016-09-21 16:20:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:20:08 --> URI Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Router Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Output Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 16:20:08 --> Security Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Input Class Initialized
DEBUG - 2016-09-21 16:20:08 --> XSS Filtering completed
DEBUG - 2016-09-21 16:20:08 --> XSS Filtering completed
DEBUG - 2016-09-21 16:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:20:08 --> Language Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Loader Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:20:08 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:20:08 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:20:08 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:20:08 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:20:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:20:08 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:20:08 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:20:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:20:08 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:20:08 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:20:08 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:20:08 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:20:08 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:20:08 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:20:08 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:20:08 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:20:08 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:20:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:20:08 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:20:08 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:20:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:20:08 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:20:08 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:20:08 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:20:08 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:20:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:20:08 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:20:08 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:20:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:20:08 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:20:08 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:20:08 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:20:08 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:20:08 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Session Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:20:08 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:20:08 --> Session routines successfully run
DEBUG - 2016-09-21 16:20:08 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:20:08 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:20:08 --> Controller Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:20:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:20:08 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:20:08 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:20:08 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:20:08 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Model Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Model Class Initialized
DEBUG - 2016-09-21 16:20:08 --> Model Class Initialized
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:20:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 16:20:08 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-09-21 16:20:08 --> Final output sent to browser
DEBUG - 2016-09-21 16:20:08 --> Total execution time: 0.4761
DEBUG - 2016-09-21 16:20:11 --> Config Class Initialized
DEBUG - 2016-09-21 16:20:11 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:20:11 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:20:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:20:11 --> URI Class Initialized
DEBUG - 2016-09-21 16:20:11 --> Router Class Initialized
DEBUG - 2016-09-21 16:20:11 --> Output Class Initialized
DEBUG - 2016-09-21 16:20:11 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 16:20:11 --> Security Class Initialized
DEBUG - 2016-09-21 16:20:11 --> Input Class Initialized
DEBUG - 2016-09-21 16:20:11 --> XSS Filtering completed
DEBUG - 2016-09-21 16:20:11 --> XSS Filtering completed
DEBUG - 2016-09-21 16:20:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:20:11 --> Language Class Initialized
DEBUG - 2016-09-21 16:20:11 --> Loader Class Initialized
DEBUG - 2016-09-21 16:20:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:20:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:20:11 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:20:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:20:11 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:20:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:20:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:20:11 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:20:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:20:11 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:20:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:20:11 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:20:11 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:20:11 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:20:11 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:20:11 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:20:11 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:20:11 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:20:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:20:11 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:20:11 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:20:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:20:11 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:20:11 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:20:11 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:20:11 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:20:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:20:11 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:20:11 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:20:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:20:11 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:20:11 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:20:11 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:20:11 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:20:11 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:20:11 --> Session Class Initialized
DEBUG - 2016-09-21 16:20:11 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:20:11 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:20:11 --> Session routines successfully run
DEBUG - 2016-09-21 16:20:11 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:20:11 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:20:11 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:20:11 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:20:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:20:11 --> Controller Class Initialized
DEBUG - 2016-09-21 16:20:11 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:20:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:20:11 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:20:11 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:20:11 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:20:11 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:20:11 --> Model Class Initialized
DEBUG - 2016-09-21 16:20:11 --> Model Class Initialized
DEBUG - 2016-09-21 16:20:11 --> Model Class Initialized
DEBUG - 2016-09-21 16:20:11 --> Model Class Initialized
DEBUG - 2016-09-21 16:20:11 --> Model Class Initialized
DEBUG - 2016-09-21 16:20:11 --> Model Class Initialized
DEBUG - 2016-09-21 16:20:11 --> Model Class Initialized
DEBUG - 2016-09-21 16:20:11 --> Model Class Initialized
DEBUG - 2016-09-21 16:20:11 --> Model Class Initialized
DEBUG - 2016-09-21 16:20:11 --> Model Class Initialized
DEBUG - 2016-09-21 16:20:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 16:20:11 --> Pagination Class Initialized
DEBUG - 2016-09-21 16:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 16:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-21 16:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 16:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 16:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 16:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 16:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 16:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 16:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 16:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 16:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 16:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 16:20:11 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-21 16:20:11 --> Final output sent to browser
DEBUG - 2016-09-21 16:20:11 --> Total execution time: 0.7249
DEBUG - 2016-09-21 16:38:39 --> Config Class Initialized
DEBUG - 2016-09-21 16:38:39 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:38:39 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:38:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:38:40 --> URI Class Initialized
DEBUG - 2016-09-21 16:38:40 --> Router Class Initialized
DEBUG - 2016-09-21 16:38:40 --> Output Class Initialized
DEBUG - 2016-09-21 16:38:40 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 16:38:40 --> Security Class Initialized
DEBUG - 2016-09-21 16:38:40 --> Input Class Initialized
DEBUG - 2016-09-21 16:38:40 --> XSS Filtering completed
DEBUG - 2016-09-21 16:38:40 --> XSS Filtering completed
DEBUG - 2016-09-21 16:38:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:38:40 --> Language Class Initialized
DEBUG - 2016-09-21 16:38:40 --> Loader Class Initialized
DEBUG - 2016-09-21 16:38:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:38:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:38:40 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:38:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:38:40 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:38:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:38:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:38:40 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:38:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:38:40 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:38:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:38:40 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:38:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:38:40 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:38:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:38:40 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:38:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:38:40 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:38:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:38:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:38:40 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:38:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:38:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:38:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:38:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:38:40 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:38:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:38:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:38:40 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:38:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:38:40 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:38:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:38:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:38:40 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:38:40 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:38:40 --> Session Class Initialized
DEBUG - 2016-09-21 16:38:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:38:40 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:38:40 --> Session routines successfully run
DEBUG - 2016-09-21 16:38:40 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:38:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:38:40 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:38:40 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:38:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:38:40 --> Controller Class Initialized
DEBUG - 2016-09-21 16:38:40 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:38:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:38:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:38:40 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:38:40 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:38:40 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:38:40 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:40 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:40 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:40 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:40 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:40 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 16:38:40 --> Pagination Class Initialized
DEBUG - 2016-09-21 16:38:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 16:38:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-09-21 16:38:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 16:38:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 16:38:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:38:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 16:38:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 16:38:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:38:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 16:38:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 16:38:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 16:38:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:38:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 16:38:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 16:38:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:38:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 16:38:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-09-21 16:38:40 --> Final output sent to browser
DEBUG - 2016-09-21 16:38:40 --> Total execution time: 0.6401
DEBUG - 2016-09-21 16:38:43 --> Config Class Initialized
DEBUG - 2016-09-21 16:38:43 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:38:43 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:38:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:38:43 --> URI Class Initialized
DEBUG - 2016-09-21 16:38:43 --> Router Class Initialized
DEBUG - 2016-09-21 16:38:43 --> Output Class Initialized
DEBUG - 2016-09-21 16:38:43 --> Security Class Initialized
DEBUG - 2016-09-21 16:38:43 --> Input Class Initialized
DEBUG - 2016-09-21 16:38:43 --> XSS Filtering completed
DEBUG - 2016-09-21 16:38:43 --> XSS Filtering completed
DEBUG - 2016-09-21 16:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:38:43 --> Language Class Initialized
DEBUG - 2016-09-21 16:38:43 --> Loader Class Initialized
DEBUG - 2016-09-21 16:38:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:38:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:38:43 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:38:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:38:43 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:38:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:38:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:38:43 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:38:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:38:43 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:38:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:38:43 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:38:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:38:43 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:38:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:38:43 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:38:43 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:38:43 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:38:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:38:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:38:43 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:38:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:38:43 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:38:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:38:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:38:43 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:38:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:38:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:38:43 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:38:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:38:43 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:38:43 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:38:43 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:38:43 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:38:43 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:38:43 --> Session Class Initialized
DEBUG - 2016-09-21 16:38:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:38:43 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:38:43 --> Session routines successfully run
DEBUG - 2016-09-21 16:38:43 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:38:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:38:43 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:38:43 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:38:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:38:43 --> Controller Class Initialized
DEBUG - 2016-09-21 16:38:43 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:38:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:38:43 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:38:43 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:38:43 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:38:43 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:38:43 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:43 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:43 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:43 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:43 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:43 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Config Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:38:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:38:44 --> URI Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Router Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Output Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Security Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Input Class Initialized
DEBUG - 2016-09-21 16:38:44 --> XSS Filtering completed
DEBUG - 2016-09-21 16:38:44 --> XSS Filtering completed
DEBUG - 2016-09-21 16:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:38:44 --> Language Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Loader Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:38:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:38:44 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:38:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:38:44 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:38:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:38:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:38:44 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:38:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:38:44 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:38:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:38:44 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:38:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:38:44 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:38:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:38:44 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:38:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:38:44 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:38:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:38:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:38:44 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:38:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:38:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:38:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:38:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:38:44 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:38:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:38:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:38:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:38:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:38:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:38:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:38:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:38:44 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:38:44 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Session Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:38:44 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:38:44 --> Session routines successfully run
DEBUG - 2016-09-21 16:38:44 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:38:44 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:38:44 --> Controller Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:38:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:38:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:38:44 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:38:44 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:38:44 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Config Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:38:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:38:44 --> URI Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Router Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Output Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 16:38:44 --> Security Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Input Class Initialized
DEBUG - 2016-09-21 16:38:44 --> XSS Filtering completed
DEBUG - 2016-09-21 16:38:44 --> XSS Filtering completed
DEBUG - 2016-09-21 16:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:38:44 --> Language Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Loader Class Initialized
DEBUG - 2016-09-21 16:38:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:38:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:38:44 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:38:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:38:44 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:38:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:38:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:38:44 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:38:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:38:44 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:38:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:38:44 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:38:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:38:44 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:38:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:38:44 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:38:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:38:44 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:38:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:38:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:38:44 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:38:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:38:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:38:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:38:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:38:44 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:38:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:38:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:38:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:38:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:38:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:38:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:38:45 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:38:45 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:38:45 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:38:45 --> Session Class Initialized
DEBUG - 2016-09-21 16:38:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:38:45 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:38:45 --> Session routines successfully run
DEBUG - 2016-09-21 16:38:45 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:38:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:38:45 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:38:45 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:38:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:38:45 --> Controller Class Initialized
DEBUG - 2016-09-21 16:38:45 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:38:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:38:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:38:45 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:38:45 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:38:45 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:38:45 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:45 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:45 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:45 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:45 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:45 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:45 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:45 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:45 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:45 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 16:38:45 --> Pagination Class Initialized
DEBUG - 2016-09-21 16:38:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 16:38:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-21 16:38:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 16:38:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 16:38:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:38:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 16:38:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 16:38:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:38:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 16:38:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 16:38:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 16:38:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:38:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 16:38:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 16:38:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:38:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 16:38:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-21 16:38:45 --> Final output sent to browser
DEBUG - 2016-09-21 16:38:45 --> Total execution time: 0.6834
DEBUG - 2016-09-21 16:38:47 --> Config Class Initialized
DEBUG - 2016-09-21 16:38:47 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:38:47 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:38:47 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:38:47 --> URI Class Initialized
DEBUG - 2016-09-21 16:38:47 --> Router Class Initialized
DEBUG - 2016-09-21 16:38:47 --> Output Class Initialized
DEBUG - 2016-09-21 16:38:47 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 16:38:47 --> Security Class Initialized
DEBUG - 2016-09-21 16:38:48 --> Input Class Initialized
DEBUG - 2016-09-21 16:38:48 --> XSS Filtering completed
DEBUG - 2016-09-21 16:38:48 --> XSS Filtering completed
DEBUG - 2016-09-21 16:38:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:38:48 --> Language Class Initialized
DEBUG - 2016-09-21 16:38:48 --> Loader Class Initialized
DEBUG - 2016-09-21 16:38:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:38:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:38:48 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:38:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:38:48 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:38:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:38:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:38:48 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:38:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:38:48 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:38:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:38:48 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:38:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:38:48 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:38:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:38:48 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:38:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:38:48 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:38:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:38:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:38:48 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:38:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:38:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:38:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:38:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:38:48 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:38:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:38:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:38:48 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:38:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:38:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:38:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:38:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:38:48 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:38:48 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:38:48 --> Session Class Initialized
DEBUG - 2016-09-21 16:38:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:38:48 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:38:48 --> Session routines successfully run
DEBUG - 2016-09-21 16:38:48 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:38:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:38:48 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:38:48 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:38:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:38:48 --> Controller Class Initialized
DEBUG - 2016-09-21 16:38:48 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:38:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:38:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:38:48 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:38:48 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:38:48 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:38:48 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:48 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:48 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:48 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:48 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:48 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 16:38:48 --> Pagination Class Initialized
DEBUG - 2016-09-21 16:38:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 16:38:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-09-21 16:38:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 16:38:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 16:38:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:38:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 16:38:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 16:38:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:38:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 16:38:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 16:38:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 16:38:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:38:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 16:38:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 16:38:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:38:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 16:38:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-09-21 16:38:48 --> Final output sent to browser
DEBUG - 2016-09-21 16:38:48 --> Total execution time: 0.6739
DEBUG - 2016-09-21 16:38:53 --> Config Class Initialized
DEBUG - 2016-09-21 16:38:53 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:38:53 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:38:53 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:38:53 --> URI Class Initialized
DEBUG - 2016-09-21 16:38:53 --> Router Class Initialized
DEBUG - 2016-09-21 16:38:53 --> Output Class Initialized
DEBUG - 2016-09-21 16:38:53 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 16:38:53 --> Security Class Initialized
DEBUG - 2016-09-21 16:38:53 --> Input Class Initialized
DEBUG - 2016-09-21 16:38:53 --> XSS Filtering completed
DEBUG - 2016-09-21 16:38:53 --> XSS Filtering completed
DEBUG - 2016-09-21 16:38:53 --> XSS Filtering completed
DEBUG - 2016-09-21 16:38:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:38:53 --> Language Class Initialized
DEBUG - 2016-09-21 16:38:53 --> Loader Class Initialized
DEBUG - 2016-09-21 16:38:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:38:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:38:53 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:38:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:38:53 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:38:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:38:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:38:54 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:38:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:38:54 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:38:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:38:54 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:38:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:38:54 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:38:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:38:54 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:38:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:38:54 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:38:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:38:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:38:54 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:38:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:38:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:38:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:38:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:38:54 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:38:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:38:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:38:54 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:38:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:38:54 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:38:54 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:38:54 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:38:54 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:38:54 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:38:54 --> Session Class Initialized
DEBUG - 2016-09-21 16:38:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:38:54 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:38:54 --> Session routines successfully run
DEBUG - 2016-09-21 16:38:54 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:38:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:38:54 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:38:54 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:38:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:38:54 --> Controller Class Initialized
DEBUG - 2016-09-21 16:38:54 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:38:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:38:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:38:54 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:38:54 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:38:54 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:38:54 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:54 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:54 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:54 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:54 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:54 --> Model Class Initialized
DEBUG - 2016-09-21 16:38:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 16:38:54 --> Pagination Class Initialized
DEBUG - 2016-09-21 16:38:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 16:38:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-09-21 16:38:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 16:38:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 16:38:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:38:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 16:38:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 16:38:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:38:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 16:38:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 16:38:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 16:38:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:38:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 16:38:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 16:38:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:38:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 16:38:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-09-21 16:38:54 --> Final output sent to browser
DEBUG - 2016-09-21 16:38:54 --> Total execution time: 0.6844
DEBUG - 2016-09-21 16:39:11 --> Config Class Initialized
DEBUG - 2016-09-21 16:39:11 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:39:11 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:39:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:39:11 --> URI Class Initialized
DEBUG - 2016-09-21 16:39:11 --> Router Class Initialized
DEBUG - 2016-09-21 16:39:11 --> Output Class Initialized
DEBUG - 2016-09-21 16:39:11 --> Security Class Initialized
DEBUG - 2016-09-21 16:39:11 --> Input Class Initialized
DEBUG - 2016-09-21 16:39:11 --> XSS Filtering completed
DEBUG - 2016-09-21 16:39:11 --> XSS Filtering completed
DEBUG - 2016-09-21 16:39:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:39:11 --> Language Class Initialized
DEBUG - 2016-09-21 16:39:11 --> Loader Class Initialized
DEBUG - 2016-09-21 16:39:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:39:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:39:11 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:39:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:39:11 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:39:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:39:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:39:11 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:39:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:39:11 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:39:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:39:11 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:39:11 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:39:11 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:39:11 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:39:11 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:39:11 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:39:11 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:39:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:39:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:39:12 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:39:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:39:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:39:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:39:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:39:12 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:39:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:39:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:39:12 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:39:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:39:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:39:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:39:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:39:12 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:39:12 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Session Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:39:12 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:39:12 --> Session routines successfully run
DEBUG - 2016-09-21 16:39:12 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:39:12 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:39:12 --> Controller Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:39:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:39:12 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:39:12 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:39:12 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:39:12 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Config Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:39:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:39:12 --> URI Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Router Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Output Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Security Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Input Class Initialized
DEBUG - 2016-09-21 16:39:12 --> XSS Filtering completed
DEBUG - 2016-09-21 16:39:12 --> XSS Filtering completed
DEBUG - 2016-09-21 16:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:39:12 --> Language Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Loader Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:39:12 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:39:12 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:39:12 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:39:12 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:39:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:39:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:39:12 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:39:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:39:12 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:39:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:39:12 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:39:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:39:12 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:39:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:39:12 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:39:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:39:12 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:39:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:39:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:39:12 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:39:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:39:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:39:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:39:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:39:12 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:39:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:39:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:39:12 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:39:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:39:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:39:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:39:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:39:12 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:39:12 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Session Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:39:12 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:39:12 --> Session routines successfully run
DEBUG - 2016-09-21 16:39:12 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:39:12 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:39:12 --> Controller Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:39:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:39:12 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:39:12 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:39:12 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:39:12 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:39:12 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Config Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:39:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:39:13 --> URI Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Router Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Output Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 16:39:13 --> Security Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Input Class Initialized
DEBUG - 2016-09-21 16:39:13 --> XSS Filtering completed
DEBUG - 2016-09-21 16:39:13 --> XSS Filtering completed
DEBUG - 2016-09-21 16:39:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:39:13 --> Language Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Loader Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:39:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:39:13 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:39:13 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:39:13 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:39:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:39:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:39:13 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:39:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:39:13 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:39:13 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:39:13 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:39:13 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:39:13 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:39:13 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:39:13 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:39:13 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:39:13 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:39:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:39:13 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:39:13 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:39:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:39:13 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:39:13 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:39:13 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:39:13 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:39:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:39:13 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:39:13 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:39:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:39:13 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:39:13 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:39:13 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:39:13 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:39:13 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Session Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:39:13 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:39:13 --> Session routines successfully run
DEBUG - 2016-09-21 16:39:13 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:39:13 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:39:13 --> Controller Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:39:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:39:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:39:13 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:39:13 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:39:13 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 16:39:13 --> Pagination Class Initialized
DEBUG - 2016-09-21 16:39:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 16:39:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-21 16:39:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 16:39:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 16:39:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:39:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 16:39:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 16:39:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:39:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 16:39:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 16:39:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 16:39:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:39:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 16:39:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 16:39:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:39:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 16:39:14 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-21 16:39:14 --> Final output sent to browser
DEBUG - 2016-09-21 16:39:14 --> Total execution time: 0.7867
DEBUG - 2016-09-21 16:39:18 --> Config Class Initialized
DEBUG - 2016-09-21 16:39:18 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:39:18 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:39:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:39:19 --> URI Class Initialized
DEBUG - 2016-09-21 16:39:19 --> Router Class Initialized
DEBUG - 2016-09-21 16:39:19 --> Output Class Initialized
DEBUG - 2016-09-21 16:39:19 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 16:39:19 --> Security Class Initialized
DEBUG - 2016-09-21 16:39:19 --> Input Class Initialized
DEBUG - 2016-09-21 16:39:19 --> XSS Filtering completed
DEBUG - 2016-09-21 16:39:19 --> XSS Filtering completed
DEBUG - 2016-09-21 16:39:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:39:19 --> Language Class Initialized
DEBUG - 2016-09-21 16:39:19 --> Loader Class Initialized
DEBUG - 2016-09-21 16:39:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:39:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:39:19 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:39:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:39:19 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:39:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:39:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:39:19 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:39:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:39:19 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:39:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:39:19 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:39:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:39:19 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:39:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:39:19 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:39:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:39:19 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:39:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:39:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:39:19 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:39:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:39:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:39:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:39:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:39:19 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:39:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:39:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:39:19 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:39:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:39:19 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:39:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:39:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:39:19 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:39:19 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:39:19 --> Session Class Initialized
DEBUG - 2016-09-21 16:39:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:39:19 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:39:19 --> Session routines successfully run
DEBUG - 2016-09-21 16:39:19 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:39:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:39:19 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:39:19 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:39:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:39:19 --> Controller Class Initialized
DEBUG - 2016-09-21 16:39:19 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:39:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:39:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:39:19 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:39:19 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:39:19 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:39:19 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:19 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:19 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:19 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:19 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:19 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 16:39:19 --> Pagination Class Initialized
DEBUG - 2016-09-21 16:39:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 16:39:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-09-21 16:39:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 16:39:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 16:39:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:39:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 16:39:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 16:39:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:39:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 16:39:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 16:39:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 16:39:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:39:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 16:39:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 16:39:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:39:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 16:39:19 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-09-21 16:39:19 --> Final output sent to browser
DEBUG - 2016-09-21 16:39:19 --> Total execution time: 0.7523
DEBUG - 2016-09-21 16:39:22 --> Config Class Initialized
DEBUG - 2016-09-21 16:39:22 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:39:22 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:39:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:39:22 --> URI Class Initialized
DEBUG - 2016-09-21 16:39:22 --> Router Class Initialized
DEBUG - 2016-09-21 16:39:22 --> Output Class Initialized
DEBUG - 2016-09-21 16:39:22 --> Security Class Initialized
DEBUG - 2016-09-21 16:39:22 --> Input Class Initialized
DEBUG - 2016-09-21 16:39:22 --> XSS Filtering completed
DEBUG - 2016-09-21 16:39:22 --> XSS Filtering completed
DEBUG - 2016-09-21 16:39:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:39:22 --> Language Class Initialized
DEBUG - 2016-09-21 16:39:22 --> Loader Class Initialized
DEBUG - 2016-09-21 16:39:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:39:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:39:22 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:39:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:39:22 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:39:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:39:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:39:22 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:39:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:39:22 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:39:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:39:22 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:39:22 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:39:22 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:39:22 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:39:22 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:39:22 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:39:22 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:39:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:39:22 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:39:22 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:39:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:39:22 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:39:22 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:39:22 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:39:22 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:39:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:39:22 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:39:22 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:39:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:39:22 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:39:22 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:39:22 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:39:22 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:39:22 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:39:22 --> Session Class Initialized
DEBUG - 2016-09-21 16:39:22 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:39:22 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:39:22 --> Session routines successfully run
DEBUG - 2016-09-21 16:39:22 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:39:22 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:39:22 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:39:22 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:39:22 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:39:22 --> Controller Class Initialized
DEBUG - 2016-09-21 16:39:22 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:39:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:39:22 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:39:22 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:39:22 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:39:22 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:39:22 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:22 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:22 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:22 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:22 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:22 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:22 --> Config Class Initialized
DEBUG - 2016-09-21 16:39:22 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:39:22 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:39:23 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:39:23 --> URI Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Router Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Output Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Security Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Input Class Initialized
DEBUG - 2016-09-21 16:39:23 --> XSS Filtering completed
DEBUG - 2016-09-21 16:39:23 --> XSS Filtering completed
DEBUG - 2016-09-21 16:39:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:39:23 --> Language Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Loader Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:39:23 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:39:23 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:39:23 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:39:23 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:39:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:39:23 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:39:23 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:39:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:39:23 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:39:23 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:39:23 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:39:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:39:23 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:39:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:39:23 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:39:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:39:23 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:39:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:39:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:39:23 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:39:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:39:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:39:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:39:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:39:23 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:39:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:39:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:39:23 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:39:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:39:23 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:39:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:39:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:39:23 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:39:23 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Session Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:39:23 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:39:23 --> Session routines successfully run
DEBUG - 2016-09-21 16:39:23 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:39:23 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:39:23 --> Controller Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:39:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:39:23 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:39:23 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:39:23 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:39:23 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Config Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:39:23 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:39:23 --> URI Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Router Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Output Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 16:39:23 --> Security Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Input Class Initialized
DEBUG - 2016-09-21 16:39:23 --> XSS Filtering completed
DEBUG - 2016-09-21 16:39:23 --> XSS Filtering completed
DEBUG - 2016-09-21 16:39:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:39:23 --> Language Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Loader Class Initialized
DEBUG - 2016-09-21 16:39:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:39:23 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:39:23 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:39:23 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:39:23 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:39:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:39:23 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:39:23 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:39:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:39:23 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:39:23 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:39:23 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:39:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:39:23 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:39:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:39:24 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:39:24 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:39:24 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:39:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:39:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:39:24 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:39:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:39:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:39:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:39:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:39:24 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:39:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:39:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:39:24 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:39:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:39:24 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:39:24 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:39:24 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:39:24 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:39:24 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:39:24 --> Session Class Initialized
DEBUG - 2016-09-21 16:39:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:39:24 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:39:24 --> Session routines successfully run
DEBUG - 2016-09-21 16:39:24 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:39:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:39:24 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:39:24 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:39:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:39:24 --> Controller Class Initialized
DEBUG - 2016-09-21 16:39:24 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:39:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:39:24 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:39:24 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:39:24 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:39:24 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:39:24 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:24 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:24 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:24 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:24 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:24 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:24 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:24 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:24 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:24 --> Model Class Initialized
DEBUG - 2016-09-21 16:39:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 16:39:24 --> Pagination Class Initialized
DEBUG - 2016-09-21 16:39:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 16:39:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-21 16:39:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 16:39:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 16:39:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:39:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 16:39:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 16:39:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:39:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 16:39:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 16:39:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 16:39:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:39:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 16:39:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 16:39:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:39:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 16:39:24 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-21 16:39:24 --> Final output sent to browser
DEBUG - 2016-09-21 16:39:24 --> Total execution time: 0.8474
DEBUG - 2016-09-21 16:48:40 --> Config Class Initialized
DEBUG - 2016-09-21 16:48:40 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:48:40 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:48:40 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:48:40 --> URI Class Initialized
DEBUG - 2016-09-21 16:48:40 --> Router Class Initialized
DEBUG - 2016-09-21 16:48:40 --> Output Class Initialized
DEBUG - 2016-09-21 16:48:40 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 16:48:40 --> Security Class Initialized
DEBUG - 2016-09-21 16:48:40 --> Input Class Initialized
DEBUG - 2016-09-21 16:48:40 --> XSS Filtering completed
DEBUG - 2016-09-21 16:48:40 --> XSS Filtering completed
DEBUG - 2016-09-21 16:48:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:48:40 --> Language Class Initialized
DEBUG - 2016-09-21 16:48:40 --> Loader Class Initialized
DEBUG - 2016-09-21 16:48:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:48:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:48:40 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:48:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:48:40 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:48:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:48:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:48:40 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:48:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:48:40 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:48:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:48:40 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:48:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:48:40 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:48:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:48:40 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:48:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:48:40 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:48:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:48:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:48:40 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:48:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:48:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:48:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:48:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:48:40 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:48:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:48:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:48:40 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:48:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:48:40 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:48:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:48:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:48:40 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:48:40 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:48:40 --> Session Class Initialized
DEBUG - 2016-09-21 16:48:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:48:40 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:48:40 --> Session routines successfully run
DEBUG - 2016-09-21 16:48:40 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:48:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:48:40 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:48:40 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:48:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:48:40 --> Controller Class Initialized
DEBUG - 2016-09-21 16:48:40 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:48:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:48:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:48:40 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:48:40 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:48:40 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:48:40 --> Model Class Initialized
DEBUG - 2016-09-21 16:48:40 --> Model Class Initialized
DEBUG - 2016-09-21 16:48:41 --> Model Class Initialized
DEBUG - 2016-09-21 16:48:41 --> Model Class Initialized
DEBUG - 2016-09-21 16:48:41 --> Model Class Initialized
DEBUG - 2016-09-21 16:48:41 --> Model Class Initialized
DEBUG - 2016-09-21 16:48:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 16:48:41 --> Pagination Class Initialized
DEBUG - 2016-09-21 16:48:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 16:48:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-09-21 16:48:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 16:48:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 16:48:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:48:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 16:48:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 16:48:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:48:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 16:48:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 16:48:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 16:48:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:48:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 16:48:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 16:48:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:48:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 16:48:41 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-09-21 16:48:41 --> Final output sent to browser
DEBUG - 2016-09-21 16:48:41 --> Total execution time: 0.8263
DEBUG - 2016-09-21 16:51:10 --> Config Class Initialized
DEBUG - 2016-09-21 16:51:10 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:51:10 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:51:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:51:10 --> URI Class Initialized
DEBUG - 2016-09-21 16:51:10 --> Router Class Initialized
DEBUG - 2016-09-21 16:51:10 --> Output Class Initialized
DEBUG - 2016-09-21 16:51:10 --> Security Class Initialized
DEBUG - 2016-09-21 16:51:10 --> Input Class Initialized
DEBUG - 2016-09-21 16:51:10 --> XSS Filtering completed
DEBUG - 2016-09-21 16:51:10 --> XSS Filtering completed
DEBUG - 2016-09-21 16:51:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:51:10 --> Language Class Initialized
DEBUG - 2016-09-21 16:51:11 --> Loader Class Initialized
DEBUG - 2016-09-21 16:51:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:51:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:51:11 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:51:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:51:11 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:51:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:51:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:51:11 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:51:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:51:11 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:51:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:51:11 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:51:11 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:51:11 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:51:11 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:51:11 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:51:11 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:51:11 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:51:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:51:11 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:51:11 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:51:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:51:11 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:51:11 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:51:11 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:51:11 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:51:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:51:11 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:51:11 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:51:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:51:11 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:51:11 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:51:11 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:51:11 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:51:11 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:51:11 --> Session Class Initialized
DEBUG - 2016-09-21 16:51:11 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:51:11 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:51:11 --> Session routines successfully run
DEBUG - 2016-09-21 16:51:11 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:51:11 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:51:11 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:51:11 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:51:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:51:11 --> Controller Class Initialized
DEBUG - 2016-09-21 16:51:11 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:51:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:51:11 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:51:11 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:51:11 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:51:11 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:51:11 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:11 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:11 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:11 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:11 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:11 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:11 --> Config Class Initialized
DEBUG - 2016-09-21 16:51:11 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:51:11 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:51:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:51:11 --> URI Class Initialized
DEBUG - 2016-09-21 16:51:11 --> Router Class Initialized
DEBUG - 2016-09-21 16:51:11 --> Output Class Initialized
DEBUG - 2016-09-21 16:51:11 --> Security Class Initialized
DEBUG - 2016-09-21 16:51:11 --> Input Class Initialized
DEBUG - 2016-09-21 16:51:11 --> XSS Filtering completed
DEBUG - 2016-09-21 16:51:11 --> XSS Filtering completed
DEBUG - 2016-09-21 16:51:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:51:11 --> Language Class Initialized
DEBUG - 2016-09-21 16:51:11 --> Loader Class Initialized
DEBUG - 2016-09-21 16:51:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:51:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:51:11 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:51:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:51:11 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:51:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:51:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:51:11 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:51:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:51:11 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:51:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:51:11 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:51:11 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:51:11 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:51:11 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:51:11 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:51:11 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:51:11 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:51:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:51:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:51:12 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:51:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:51:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:51:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:51:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:51:12 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:51:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:51:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:51:12 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:51:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:51:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:51:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:51:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:51:12 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:51:12 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:51:12 --> Session Class Initialized
DEBUG - 2016-09-21 16:51:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:51:12 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:51:12 --> Session routines successfully run
DEBUG - 2016-09-21 16:51:12 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:51:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:51:12 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:51:12 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:51:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:51:12 --> Controller Class Initialized
DEBUG - 2016-09-21 16:51:12 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:51:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:51:12 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:51:12 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:51:12 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:51:12 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:51:12 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:12 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:12 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:12 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:12 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:12 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:12 --> Config Class Initialized
DEBUG - 2016-09-21 16:51:12 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:51:12 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:51:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:51:12 --> URI Class Initialized
DEBUG - 2016-09-21 16:51:12 --> Router Class Initialized
DEBUG - 2016-09-21 16:51:12 --> Output Class Initialized
DEBUG - 2016-09-21 16:51:12 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 16:51:12 --> Security Class Initialized
DEBUG - 2016-09-21 16:51:12 --> Input Class Initialized
DEBUG - 2016-09-21 16:51:12 --> XSS Filtering completed
DEBUG - 2016-09-21 16:51:12 --> XSS Filtering completed
DEBUG - 2016-09-21 16:51:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:51:12 --> Language Class Initialized
DEBUG - 2016-09-21 16:51:12 --> Loader Class Initialized
DEBUG - 2016-09-21 16:51:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:51:12 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:51:12 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:51:12 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:51:12 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:51:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:51:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:51:12 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:51:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:51:12 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:51:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:51:12 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:51:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:51:12 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:51:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:51:12 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:51:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:51:12 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:51:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:51:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:51:12 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:51:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:51:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:51:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:51:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:51:12 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:51:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:51:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:51:12 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:51:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:51:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:51:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:51:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:51:12 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:51:12 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:51:13 --> Session Class Initialized
DEBUG - 2016-09-21 16:51:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:51:13 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:51:13 --> Session routines successfully run
DEBUG - 2016-09-21 16:51:13 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:51:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:51:13 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:51:13 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:51:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:51:13 --> Controller Class Initialized
DEBUG - 2016-09-21 16:51:13 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:51:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:51:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:51:13 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:51:13 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:51:13 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:51:13 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:13 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:13 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:13 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:13 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:13 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:13 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:13 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:13 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:13 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 16:51:13 --> Pagination Class Initialized
DEBUG - 2016-09-21 16:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 16:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-21 16:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 16:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 16:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 16:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 16:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 16:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 16:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 16:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 16:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 16:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:51:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 16:51:13 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-21 16:51:13 --> Final output sent to browser
DEBUG - 2016-09-21 16:51:13 --> Total execution time: 0.8960
DEBUG - 2016-09-21 16:51:16 --> Config Class Initialized
DEBUG - 2016-09-21 16:51:16 --> Hooks Class Initialized
DEBUG - 2016-09-21 16:51:16 --> Utf8 Class Initialized
DEBUG - 2016-09-21 16:51:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 16:51:16 --> URI Class Initialized
DEBUG - 2016-09-21 16:51:16 --> Router Class Initialized
DEBUG - 2016-09-21 16:51:16 --> Output Class Initialized
DEBUG - 2016-09-21 16:51:16 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 16:51:16 --> Security Class Initialized
DEBUG - 2016-09-21 16:51:16 --> Input Class Initialized
DEBUG - 2016-09-21 16:51:16 --> XSS Filtering completed
DEBUG - 2016-09-21 16:51:16 --> XSS Filtering completed
DEBUG - 2016-09-21 16:51:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 16:51:16 --> Language Class Initialized
DEBUG - 2016-09-21 16:51:16 --> Loader Class Initialized
DEBUG - 2016-09-21 16:51:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 16:51:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 16:51:16 --> Helper loaded: url_helper
DEBUG - 2016-09-21 16:51:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 16:51:16 --> Helper loaded: file_helper
DEBUG - 2016-09-21 16:51:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:51:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 16:51:16 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 16:51:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 16:51:16 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 16:51:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 16:51:16 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:51:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 16:51:16 --> Helper loaded: common_helper
DEBUG - 2016-09-21 16:51:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 16:51:16 --> Helper loaded: form_helper
DEBUG - 2016-09-21 16:51:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 16:51:16 --> Helper loaded: security_helper
DEBUG - 2016-09-21 16:51:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:51:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 16:51:16 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 16:51:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 16:51:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 16:51:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 16:51:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 16:51:16 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 16:51:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:51:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 16:51:16 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 16:51:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 16:51:16 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 16:51:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 16:51:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 16:51:16 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 16:51:16 --> Database Driver Class Initialized
DEBUG - 2016-09-21 16:51:16 --> Session Class Initialized
DEBUG - 2016-09-21 16:51:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 16:51:16 --> Helper loaded: string_helper
DEBUG - 2016-09-21 16:51:16 --> Session routines successfully run
DEBUG - 2016-09-21 16:51:16 --> Native_session Class Initialized
DEBUG - 2016-09-21 16:51:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 16:51:16 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:51:16 --> Form Validation Class Initialized
DEBUG - 2016-09-21 16:51:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 16:51:16 --> Controller Class Initialized
DEBUG - 2016-09-21 16:51:16 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 16:51:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 16:51:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 16:51:16 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:51:16 --> Carabiner: library configured.
DEBUG - 2016-09-21 16:51:16 --> User Agent Class Initialized
DEBUG - 2016-09-21 16:51:16 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:16 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:16 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:16 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:16 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:16 --> Model Class Initialized
DEBUG - 2016-09-21 16:51:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 16:51:16 --> Pagination Class Initialized
DEBUG - 2016-09-21 16:51:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 16:51:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-09-21 16:51:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 16:51:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 16:51:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:51:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 16:51:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 16:51:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:51:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 16:51:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 16:51:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 16:51:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 16:51:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 16:51:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 16:51:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 16:51:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 16:51:17 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-09-21 16:51:17 --> Final output sent to browser
DEBUG - 2016-09-21 16:51:17 --> Total execution time: 0.8667
DEBUG - 2016-09-21 17:06:59 --> Config Class Initialized
DEBUG - 2016-09-21 17:06:59 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:06:59 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:06:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:06:59 --> URI Class Initialized
DEBUG - 2016-09-21 17:06:59 --> Router Class Initialized
DEBUG - 2016-09-21 17:06:59 --> Output Class Initialized
DEBUG - 2016-09-21 17:06:59 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 17:06:59 --> Security Class Initialized
DEBUG - 2016-09-21 17:06:59 --> Input Class Initialized
DEBUG - 2016-09-21 17:06:59 --> XSS Filtering completed
DEBUG - 2016-09-21 17:06:59 --> XSS Filtering completed
DEBUG - 2016-09-21 17:06:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:06:59 --> Language Class Initialized
DEBUG - 2016-09-21 17:06:59 --> Loader Class Initialized
DEBUG - 2016-09-21 17:06:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:06:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:06:59 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:06:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:06:59 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:06:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:06:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:06:59 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:06:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:06:59 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:06:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:06:59 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:06:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:06:59 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:06:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:06:59 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:06:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:06:59 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:06:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:06:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:06:59 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:06:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:06:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:06:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:06:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:06:59 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:06:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:06:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:06:59 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:06:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:06:59 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:06:59 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:06:59 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:06:59 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:06:59 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:06:59 --> Session Class Initialized
DEBUG - 2016-09-21 17:06:59 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:06:59 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:06:59 --> Session routines successfully run
DEBUG - 2016-09-21 17:06:59 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:06:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:06:59 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:06:59 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:06:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:06:59 --> Controller Class Initialized
DEBUG - 2016-09-21 17:06:59 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:06:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:06:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:06:59 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:06:59 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:07:00 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:07:00 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:00 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:00 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:00 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:00 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:00 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:07:00 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-09-21 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:07:00 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-09-21 17:07:00 --> Final output sent to browser
DEBUG - 2016-09-21 17:07:00 --> Total execution time: 0.8725
DEBUG - 2016-09-21 17:07:25 --> Config Class Initialized
DEBUG - 2016-09-21 17:07:25 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:07:25 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:07:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:07:25 --> URI Class Initialized
DEBUG - 2016-09-21 17:07:25 --> Router Class Initialized
DEBUG - 2016-09-21 17:07:25 --> Output Class Initialized
DEBUG - 2016-09-21 17:07:25 --> Security Class Initialized
DEBUG - 2016-09-21 17:07:25 --> Input Class Initialized
DEBUG - 2016-09-21 17:07:25 --> XSS Filtering completed
DEBUG - 2016-09-21 17:07:25 --> XSS Filtering completed
DEBUG - 2016-09-21 17:07:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:07:25 --> Language Class Initialized
DEBUG - 2016-09-21 17:07:25 --> Loader Class Initialized
DEBUG - 2016-09-21 17:07:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:07:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:07:25 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:07:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:07:25 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:07:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:07:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:07:25 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:07:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:07:25 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:07:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:07:25 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:07:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:07:25 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:07:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:07:25 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:07:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:07:25 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:07:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:07:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:07:25 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:07:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:07:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:07:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:07:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:07:25 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:07:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:07:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:07:25 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:07:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:07:25 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:07:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:07:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:07:25 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:07:25 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:07:25 --> Session Class Initialized
DEBUG - 2016-09-21 17:07:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:07:25 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:07:25 --> Session routines successfully run
DEBUG - 2016-09-21 17:07:25 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:07:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:07:25 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:07:25 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:07:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:07:25 --> Controller Class Initialized
DEBUG - 2016-09-21 17:07:25 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:07:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:07:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:07:25 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:07:25 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:07:25 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:07:25 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:25 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:25 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:25 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:25 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:25 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:25 --> Config Class Initialized
DEBUG - 2016-09-21 17:07:25 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:07:25 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:07:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:07:25 --> URI Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Router Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Output Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Security Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Input Class Initialized
DEBUG - 2016-09-21 17:07:26 --> XSS Filtering completed
DEBUG - 2016-09-21 17:07:26 --> XSS Filtering completed
DEBUG - 2016-09-21 17:07:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:07:26 --> Language Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Loader Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:07:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:07:26 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:07:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:07:26 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:07:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:07:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:07:26 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:07:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:07:26 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:07:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:07:26 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:07:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:07:26 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:07:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:07:26 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:07:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:07:26 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:07:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:07:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:07:26 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:07:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:07:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:07:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:07:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:07:26 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:07:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:07:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:07:26 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:07:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:07:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:07:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:07:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:07:26 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:07:26 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Session Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:07:26 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:07:26 --> Session routines successfully run
DEBUG - 2016-09-21 17:07:26 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:07:26 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:07:26 --> Controller Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:07:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:07:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:07:26 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:07:26 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:07:26 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Config Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:07:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:07:26 --> URI Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Router Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Output Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 17:07:26 --> Security Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Input Class Initialized
DEBUG - 2016-09-21 17:07:26 --> XSS Filtering completed
DEBUG - 2016-09-21 17:07:26 --> XSS Filtering completed
DEBUG - 2016-09-21 17:07:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:07:26 --> Language Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Loader Class Initialized
DEBUG - 2016-09-21 17:07:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:07:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:07:27 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:07:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:07:27 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:07:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:07:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:07:27 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:07:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:07:27 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:07:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:07:27 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:07:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:07:27 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:07:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:07:27 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:07:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:07:27 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:07:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:07:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:07:27 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:07:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:07:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:07:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:07:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:07:27 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:07:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:07:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:07:27 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:07:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:07:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:07:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:07:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:07:27 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:07:27 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:07:27 --> Session Class Initialized
DEBUG - 2016-09-21 17:07:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:07:27 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:07:27 --> Session routines successfully run
DEBUG - 2016-09-21 17:07:27 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:07:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:07:27 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:07:27 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:07:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:07:27 --> Controller Class Initialized
DEBUG - 2016-09-21 17:07:27 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:07:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:07:27 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:07:27 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:07:27 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:07:27 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:07:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:07:27 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:07:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 17:07:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-21 17:07:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:07:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:07:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:07:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:07:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:07:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:07:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:07:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:07:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:07:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:07:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:07:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:07:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:07:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:07:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-21 17:07:27 --> Final output sent to browser
DEBUG - 2016-09-21 17:07:28 --> Total execution time: 0.9812
DEBUG - 2016-09-21 17:07:30 --> Config Class Initialized
DEBUG - 2016-09-21 17:07:30 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:07:30 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:07:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:07:30 --> URI Class Initialized
DEBUG - 2016-09-21 17:07:30 --> Router Class Initialized
DEBUG - 2016-09-21 17:07:30 --> Output Class Initialized
DEBUG - 2016-09-21 17:07:30 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 17:07:30 --> Security Class Initialized
DEBUG - 2016-09-21 17:07:30 --> Input Class Initialized
DEBUG - 2016-09-21 17:07:30 --> XSS Filtering completed
DEBUG - 2016-09-21 17:07:30 --> XSS Filtering completed
DEBUG - 2016-09-21 17:07:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:07:30 --> Language Class Initialized
DEBUG - 2016-09-21 17:07:30 --> Loader Class Initialized
DEBUG - 2016-09-21 17:07:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:07:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:07:30 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:07:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:07:30 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:07:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:07:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:07:30 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:07:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:07:30 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:07:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:07:30 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:07:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:07:30 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:07:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:07:30 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:07:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:07:30 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:07:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:07:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:07:30 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:07:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:07:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:07:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:07:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:07:30 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:07:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:07:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:07:30 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:07:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:07:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:07:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:07:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:07:31 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:07:31 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:07:31 --> Session Class Initialized
DEBUG - 2016-09-21 17:07:31 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:07:31 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:07:31 --> Session routines successfully run
DEBUG - 2016-09-21 17:07:31 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:07:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:07:31 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:07:31 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:07:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:07:31 --> Controller Class Initialized
DEBUG - 2016-09-21 17:07:31 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:07:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:07:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:07:31 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:07:31 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:07:31 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:07:31 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:31 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:31 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:31 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:31 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:31 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:07:31 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:07:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 17:07:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-09-21 17:07:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:07:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:07:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:07:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:07:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:07:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:07:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:07:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:07:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:07:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:07:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:07:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:07:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:07:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:07:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-09-21 17:07:31 --> Final output sent to browser
DEBUG - 2016-09-21 17:07:31 --> Total execution time: 0.9458
DEBUG - 2016-09-21 17:07:33 --> Config Class Initialized
DEBUG - 2016-09-21 17:07:33 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:07:33 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:07:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:07:33 --> URI Class Initialized
DEBUG - 2016-09-21 17:07:33 --> Router Class Initialized
DEBUG - 2016-09-21 17:07:33 --> Output Class Initialized
DEBUG - 2016-09-21 17:07:33 --> Security Class Initialized
DEBUG - 2016-09-21 17:07:34 --> Input Class Initialized
DEBUG - 2016-09-21 17:07:34 --> XSS Filtering completed
DEBUG - 2016-09-21 17:07:34 --> XSS Filtering completed
DEBUG - 2016-09-21 17:07:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:07:34 --> Language Class Initialized
DEBUG - 2016-09-21 17:07:34 --> Loader Class Initialized
DEBUG - 2016-09-21 17:07:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:07:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:07:34 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:07:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:07:34 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:07:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:07:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:07:34 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:07:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:07:34 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:07:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:07:34 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:07:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:07:34 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:07:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:07:34 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:07:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:07:34 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:07:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:07:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:07:34 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:07:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:07:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:07:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:07:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:07:34 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:07:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:07:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:07:34 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:07:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:07:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:07:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:07:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:07:34 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:07:34 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:07:34 --> Session Class Initialized
DEBUG - 2016-09-21 17:07:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:07:34 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:07:34 --> Session routines successfully run
DEBUG - 2016-09-21 17:07:34 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:07:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:07:34 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:07:34 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:07:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:07:34 --> Controller Class Initialized
DEBUG - 2016-09-21 17:07:34 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:07:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:07:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:07:34 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:07:34 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:07:34 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:07:34 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:34 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:34 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:34 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:34 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:34 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:34 --> Config Class Initialized
DEBUG - 2016-09-21 17:07:34 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:07:34 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:07:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:07:34 --> URI Class Initialized
DEBUG - 2016-09-21 17:07:34 --> Router Class Initialized
DEBUG - 2016-09-21 17:07:34 --> Output Class Initialized
DEBUG - 2016-09-21 17:07:34 --> Security Class Initialized
DEBUG - 2016-09-21 17:07:34 --> Input Class Initialized
DEBUG - 2016-09-21 17:07:34 --> XSS Filtering completed
DEBUG - 2016-09-21 17:07:34 --> XSS Filtering completed
DEBUG - 2016-09-21 17:07:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:07:34 --> Language Class Initialized
DEBUG - 2016-09-21 17:07:35 --> Loader Class Initialized
DEBUG - 2016-09-21 17:07:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:07:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:07:35 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:07:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:07:35 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:07:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:07:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:07:35 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:07:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:07:35 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:07:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:07:35 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:07:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:07:35 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:07:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:07:35 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:07:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:07:35 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:07:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:07:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:07:35 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:07:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:07:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:07:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:07:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:07:35 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:07:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:07:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:07:35 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:07:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:07:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:07:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:07:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:07:35 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:07:35 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:07:35 --> Session Class Initialized
DEBUG - 2016-09-21 17:07:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:07:35 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:07:35 --> Session routines successfully run
DEBUG - 2016-09-21 17:07:35 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:07:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:07:35 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:07:35 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:07:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:07:35 --> Controller Class Initialized
DEBUG - 2016-09-21 17:07:35 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:07:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:07:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:07:35 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:07:35 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:07:35 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:07:35 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:35 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:35 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:35 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:35 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:35 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:35 --> Config Class Initialized
DEBUG - 2016-09-21 17:07:35 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:07:35 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:07:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:07:35 --> URI Class Initialized
DEBUG - 2016-09-21 17:07:35 --> Router Class Initialized
DEBUG - 2016-09-21 17:07:35 --> Output Class Initialized
DEBUG - 2016-09-21 17:07:35 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 17:07:35 --> Security Class Initialized
DEBUG - 2016-09-21 17:07:35 --> Input Class Initialized
DEBUG - 2016-09-21 17:07:35 --> XSS Filtering completed
DEBUG - 2016-09-21 17:07:35 --> XSS Filtering completed
DEBUG - 2016-09-21 17:07:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:07:35 --> Language Class Initialized
DEBUG - 2016-09-21 17:07:35 --> Loader Class Initialized
DEBUG - 2016-09-21 17:07:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:07:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:07:35 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:07:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:07:36 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:07:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:07:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:07:36 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:07:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:07:36 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:07:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:07:36 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:07:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:07:36 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:07:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:07:36 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:07:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:07:36 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:07:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:07:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:07:36 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:07:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:07:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:07:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:07:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:07:36 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:07:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:07:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:07:36 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:07:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:07:36 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:07:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:07:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:07:36 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:07:36 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:07:36 --> Session Class Initialized
DEBUG - 2016-09-21 17:07:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:07:36 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:07:36 --> Session routines successfully run
DEBUG - 2016-09-21 17:07:36 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:07:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:07:36 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:07:36 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:07:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:07:36 --> Controller Class Initialized
DEBUG - 2016-09-21 17:07:36 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:07:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:07:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:07:36 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:07:36 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:07:36 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:07:36 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:36 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:36 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:36 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:36 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:36 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:36 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:36 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:36 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:36 --> Model Class Initialized
DEBUG - 2016-09-21 17:07:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:07:36 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:07:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 17:07:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-21 17:07:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:07:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:07:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:07:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:07:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:07:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:07:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:07:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:07:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:07:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:07:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:07:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:07:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:07:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:07:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-21 17:07:37 --> Final output sent to browser
DEBUG - 2016-09-21 17:07:37 --> Total execution time: 1.0572
DEBUG - 2016-09-21 17:08:07 --> Config Class Initialized
DEBUG - 2016-09-21 17:08:07 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:08:07 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:08:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:08:07 --> URI Class Initialized
DEBUG - 2016-09-21 17:08:07 --> Router Class Initialized
DEBUG - 2016-09-21 17:08:07 --> Output Class Initialized
DEBUG - 2016-09-21 17:08:07 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 17:08:07 --> Security Class Initialized
DEBUG - 2016-09-21 17:08:07 --> Input Class Initialized
DEBUG - 2016-09-21 17:08:07 --> XSS Filtering completed
DEBUG - 2016-09-21 17:08:07 --> XSS Filtering completed
DEBUG - 2016-09-21 17:08:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:08:07 --> Language Class Initialized
DEBUG - 2016-09-21 17:08:07 --> Loader Class Initialized
DEBUG - 2016-09-21 17:08:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:08:07 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:08:07 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:08:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:08:07 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:08:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:08:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:08:07 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:08:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:08:07 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:08:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:08:07 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:08:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:08:08 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:08:08 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:08:08 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:08:08 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:08:08 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:08:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:08:08 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:08:08 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:08:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:08:08 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:08:08 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:08:08 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:08:08 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:08:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:08:08 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:08:08 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:08:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:08:08 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:08:08 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:08:08 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:08:08 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:08:08 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:08:08 --> Session Class Initialized
DEBUG - 2016-09-21 17:08:08 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:08:08 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:08:08 --> Session routines successfully run
DEBUG - 2016-09-21 17:08:08 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:08:08 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:08:08 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:08:08 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:08:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:08:08 --> Controller Class Initialized
DEBUG - 2016-09-21 17:08:08 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:08:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:08:08 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:08:08 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:08:08 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:08:08 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:08:08 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:08 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:08 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:08 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:08 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:08 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:08 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:08 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:08 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:08 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:08:08 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:08:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 17:08:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-21 17:08:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:08:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:08:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:08:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:08:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:08:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:08:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:08:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:08:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:08:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:08:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:08:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:08:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:08:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:08:08 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-21 17:08:08 --> Final output sent to browser
DEBUG - 2016-09-21 17:08:08 --> Total execution time: 1.0769
DEBUG - 2016-09-21 17:08:11 --> Config Class Initialized
DEBUG - 2016-09-21 17:08:11 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:08:11 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:08:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:08:11 --> URI Class Initialized
DEBUG - 2016-09-21 17:08:11 --> Router Class Initialized
DEBUG - 2016-09-21 17:08:11 --> Output Class Initialized
DEBUG - 2016-09-21 17:08:12 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 17:08:12 --> Security Class Initialized
DEBUG - 2016-09-21 17:08:12 --> Input Class Initialized
DEBUG - 2016-09-21 17:08:12 --> XSS Filtering completed
DEBUG - 2016-09-21 17:08:12 --> XSS Filtering completed
DEBUG - 2016-09-21 17:08:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:08:12 --> Language Class Initialized
DEBUG - 2016-09-21 17:08:12 --> Loader Class Initialized
DEBUG - 2016-09-21 17:08:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:08:12 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:08:12 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:08:12 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:08:12 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:08:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:08:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:08:12 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:08:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:08:12 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:08:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:08:12 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:08:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:08:12 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:08:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:08:12 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:08:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:08:12 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:08:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:08:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:08:12 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:08:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:08:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:08:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:08:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:08:12 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:08:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:08:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:08:12 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:08:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:08:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:08:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:08:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:08:12 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:08:12 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:08:12 --> Session Class Initialized
DEBUG - 2016-09-21 17:08:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:08:12 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:08:12 --> Session routines successfully run
DEBUG - 2016-09-21 17:08:12 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:08:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:08:12 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:08:12 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:08:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:08:12 --> Controller Class Initialized
DEBUG - 2016-09-21 17:08:12 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:08:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:08:12 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:08:12 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:08:12 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:08:12 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:08:12 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:12 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:12 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:12 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:12 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:12 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:08:12 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:08:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 17:08:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-09-21 17:08:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:08:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:08:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:08:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:08:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:08:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:08:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:08:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:08:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:08:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:08:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:08:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:08:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:08:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:08:13 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-09-21 17:08:13 --> Final output sent to browser
DEBUG - 2016-09-21 17:08:13 --> Total execution time: 1.0237
DEBUG - 2016-09-21 17:08:19 --> Config Class Initialized
DEBUG - 2016-09-21 17:08:19 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:08:19 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:08:19 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:08:19 --> URI Class Initialized
DEBUG - 2016-09-21 17:08:19 --> Router Class Initialized
DEBUG - 2016-09-21 17:08:19 --> Output Class Initialized
DEBUG - 2016-09-21 17:08:19 --> Security Class Initialized
DEBUG - 2016-09-21 17:08:19 --> Input Class Initialized
DEBUG - 2016-09-21 17:08:19 --> XSS Filtering completed
DEBUG - 2016-09-21 17:08:19 --> XSS Filtering completed
DEBUG - 2016-09-21 17:08:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:08:19 --> Language Class Initialized
DEBUG - 2016-09-21 17:08:19 --> Loader Class Initialized
DEBUG - 2016-09-21 17:08:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:08:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:08:19 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:08:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:08:19 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:08:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:08:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:08:19 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:08:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:08:19 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:08:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:08:19 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:08:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:08:19 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:08:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:08:19 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:08:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:08:19 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:08:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:08:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:08:19 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:08:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:08:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:08:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:08:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:08:19 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:08:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:08:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:08:19 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:08:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:08:19 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:08:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:08:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:08:19 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:08:19 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:08:19 --> Session Class Initialized
DEBUG - 2016-09-21 17:08:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:08:19 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:08:19 --> Session routines successfully run
DEBUG - 2016-09-21 17:08:19 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:08:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:08:19 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:08:19 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:08:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:08:19 --> Controller Class Initialized
DEBUG - 2016-09-21 17:08:19 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:08:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:08:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:08:19 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:08:19 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:08:19 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:08:19 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:19 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:19 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:19 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:20 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:20 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:20 --> Config Class Initialized
DEBUG - 2016-09-21 17:08:20 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:08:20 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:08:20 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:08:20 --> URI Class Initialized
DEBUG - 2016-09-21 17:08:20 --> Router Class Initialized
DEBUG - 2016-09-21 17:08:20 --> Output Class Initialized
DEBUG - 2016-09-21 17:08:20 --> Security Class Initialized
DEBUG - 2016-09-21 17:08:20 --> Input Class Initialized
DEBUG - 2016-09-21 17:08:20 --> XSS Filtering completed
DEBUG - 2016-09-21 17:08:20 --> XSS Filtering completed
DEBUG - 2016-09-21 17:08:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:08:20 --> Language Class Initialized
DEBUG - 2016-09-21 17:08:20 --> Loader Class Initialized
DEBUG - 2016-09-21 17:08:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:08:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:08:20 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:08:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:08:20 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:08:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:08:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:08:20 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:08:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:08:20 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:08:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:08:20 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:08:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:08:20 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:08:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:08:20 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:08:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:08:20 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:08:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:08:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:08:20 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:08:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:08:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:08:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:08:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:08:20 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:08:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:08:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:08:20 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:08:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:08:20 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:08:20 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:08:20 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:08:20 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:08:20 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:08:20 --> Session Class Initialized
DEBUG - 2016-09-21 17:08:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:08:20 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:08:20 --> Session routines successfully run
DEBUG - 2016-09-21 17:08:20 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:08:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:08:20 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:08:20 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:08:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:08:20 --> Controller Class Initialized
DEBUG - 2016-09-21 17:08:20 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:08:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:08:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:08:20 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:08:20 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:08:20 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:08:20 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:20 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:21 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:21 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:21 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:21 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:21 --> Config Class Initialized
DEBUG - 2016-09-21 17:08:21 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:08:21 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:08:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:08:21 --> URI Class Initialized
DEBUG - 2016-09-21 17:08:21 --> Router Class Initialized
DEBUG - 2016-09-21 17:08:21 --> Output Class Initialized
DEBUG - 2016-09-21 17:08:21 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 17:08:21 --> Security Class Initialized
DEBUG - 2016-09-21 17:08:21 --> Input Class Initialized
DEBUG - 2016-09-21 17:08:21 --> XSS Filtering completed
DEBUG - 2016-09-21 17:08:21 --> XSS Filtering completed
DEBUG - 2016-09-21 17:08:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:08:21 --> Language Class Initialized
DEBUG - 2016-09-21 17:08:21 --> Loader Class Initialized
DEBUG - 2016-09-21 17:08:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:08:21 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:08:21 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:08:21 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:08:21 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:08:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:08:21 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:08:21 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:08:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:08:21 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:08:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:08:21 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:08:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:08:21 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:08:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:08:21 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:08:21 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:08:21 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:08:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:08:21 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:08:21 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:08:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:08:21 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:08:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:08:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:08:21 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:08:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:08:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:08:21 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:08:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:08:21 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:08:21 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:08:21 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:08:21 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:08:21 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:08:21 --> Session Class Initialized
DEBUG - 2016-09-21 17:08:21 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:08:21 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:08:21 --> Session routines successfully run
DEBUG - 2016-09-21 17:08:21 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:08:21 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:08:21 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:08:21 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:08:21 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:08:21 --> Controller Class Initialized
DEBUG - 2016-09-21 17:08:21 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:08:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:08:21 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:08:21 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:08:21 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:08:22 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:08:22 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:22 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:22 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:22 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:22 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:22 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:22 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:22 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:22 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:22 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:08:22 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:08:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 17:08:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-21 17:08:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:08:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:08:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:08:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:08:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:08:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:08:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:08:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:08:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:08:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:08:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:08:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:08:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:08:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:08:22 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-21 17:08:22 --> Final output sent to browser
DEBUG - 2016-09-21 17:08:22 --> Total execution time: 1.1545
DEBUG - 2016-09-21 17:08:26 --> Config Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:08:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:08:26 --> URI Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Router Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Output Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 17:08:26 --> Security Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Input Class Initialized
DEBUG - 2016-09-21 17:08:26 --> XSS Filtering completed
DEBUG - 2016-09-21 17:08:26 --> XSS Filtering completed
DEBUG - 2016-09-21 17:08:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:08:26 --> Language Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Loader Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Config Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:08:26 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:08:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:08:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> URI Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:08:26 --> Router Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Output Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Security Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:08:26 --> Input Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> XSS Filtering completed
DEBUG - 2016-09-21 17:08:26 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> XSS Filtering completed
DEBUG - 2016-09-21 17:08:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:08:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Language Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:08:26 --> Loader Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:08:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Config Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:08:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:08:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:08:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> URI Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Router Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:08:26 --> Output Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> Security Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> Input Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> XSS Filtering completed
DEBUG - 2016-09-21 17:08:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> XSS Filtering completed
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:08:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:08:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:08:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:08:26 --> Language Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Loader Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:08:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:08:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:08:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:08:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:08:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:08:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> Session Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:08:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:08:26 --> Session routines successfully run
DEBUG - 2016-09-21 17:08:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:08:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:08:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:08:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:08:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:08:26 --> Config Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Controller Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:08:26 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:08:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:08:26 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:08:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:08:26 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:08:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> URI Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Session Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:08:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Router Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:08:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:08:26 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Output Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:08:26 --> Session routines successfully run
DEBUG - 2016-09-21 17:08:26 --> Security Class Initialized
DEBUG - 2016-09-21 17:08:26 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:08:27 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Input Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:08:27 --> XSS Filtering completed
DEBUG - 2016-09-21 17:08:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:08:27 --> XSS Filtering completed
DEBUG - 2016-09-21 17:08:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:08:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:08:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:08:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Language Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:08:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Loader Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:08:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:08:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:08:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:08:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:08:27 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:08:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:08:27 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:08:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:08:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:08:27 --> Session Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:08:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:08:27 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:08:27 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 17:08:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:08:27 --> Session routines successfully run
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-21 17:08:27 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:08:27 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:08:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:08:27 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:08:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:08:27 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:08:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:08:27 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:08:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:08:27 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:08:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:08:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:08:27 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:08:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:08:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:08:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:08:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-21 17:08:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:08:27 --> Final output sent to browser
DEBUG - 2016-09-21 17:08:27 --> Total execution time: 1.1061
DEBUG - 2016-09-21 17:08:27 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:08:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:08:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:08:27 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:08:27 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:08:27 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:08:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:08:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:08:27 --> Controller Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:08:27 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:08:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:08:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:08:27 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:08:27 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:08:27 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:08:27 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:08:27 --> Session Class Initialized
DEBUG - 2016-09-21 17:08:27 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:08:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:08:27 --> Session routines successfully run
DEBUG - 2016-09-21 17:08:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:08:27 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:08:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:08:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:08:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:08:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:08:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:08:28 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-21 17:08:28 --> Final output sent to browser
DEBUG - 2016-09-21 17:08:28 --> Total execution time: 1.5557
DEBUG - 2016-09-21 17:08:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:08:28 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:08:28 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:08:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:08:28 --> Controller Class Initialized
DEBUG - 2016-09-21 17:08:28 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:08:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:08:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:08:28 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:08:28 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:08:28 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:08:28 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:28 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:28 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:28 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:28 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:28 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:28 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:28 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:28 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:28 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:08:28 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:08:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 17:08:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-21 17:08:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:08:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:08:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:08:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:08:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:08:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:08:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:08:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:08:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:08:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:08:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:08:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:08:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:08:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:08:28 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-21 17:08:28 --> Final output sent to browser
DEBUG - 2016-09-21 17:08:28 --> Total execution time: 2.0078
DEBUG - 2016-09-21 17:08:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:08:28 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:08:28 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:08:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:08:28 --> Controller Class Initialized
DEBUG - 2016-09-21 17:08:28 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:08:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:08:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:08:28 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:08:28 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:08:28 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:08:28 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:28 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:28 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:28 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:29 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:29 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:29 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:29 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:29 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:29 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:08:29 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:08:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 17:08:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-21 17:08:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:08:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:08:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:08:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:08:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:08:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:08:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:08:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:08:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:08:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:08:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:08:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:08:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:08:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:08:29 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-21 17:08:29 --> Final output sent to browser
DEBUG - 2016-09-21 17:08:29 --> Total execution time: 2.2615
DEBUG - 2016-09-21 17:08:36 --> Config Class Initialized
DEBUG - 2016-09-21 17:08:36 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:08:36 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:08:36 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:08:36 --> URI Class Initialized
DEBUG - 2016-09-21 17:08:36 --> Router Class Initialized
DEBUG - 2016-09-21 17:08:36 --> Output Class Initialized
DEBUG - 2016-09-21 17:08:36 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 17:08:36 --> Security Class Initialized
DEBUG - 2016-09-21 17:08:36 --> Input Class Initialized
DEBUG - 2016-09-21 17:08:36 --> XSS Filtering completed
DEBUG - 2016-09-21 17:08:36 --> XSS Filtering completed
DEBUG - 2016-09-21 17:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:08:36 --> Language Class Initialized
DEBUG - 2016-09-21 17:08:36 --> Loader Class Initialized
DEBUG - 2016-09-21 17:08:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:08:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:08:36 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:08:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:08:36 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:08:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:08:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:08:36 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:08:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:08:36 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:08:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:08:36 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:08:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:08:36 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:08:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:08:36 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:08:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:08:36 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:08:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:08:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:08:36 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:08:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:08:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:08:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:08:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:08:36 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:08:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:08:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:08:37 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:08:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:08:37 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:08:37 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:08:37 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:08:37 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:08:37 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:08:37 --> Session Class Initialized
DEBUG - 2016-09-21 17:08:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:08:37 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:08:37 --> Session routines successfully run
DEBUG - 2016-09-21 17:08:37 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:08:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:08:37 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:08:37 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:08:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:08:37 --> Controller Class Initialized
DEBUG - 2016-09-21 17:08:37 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:08:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:08:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:08:37 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:08:37 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:08:37 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:08:37 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:37 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:37 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:37 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:37 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:37 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:08:37 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 17:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-09-21 17:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:08:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:08:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-09-21 17:08:37 --> Final output sent to browser
DEBUG - 2016-09-21 17:08:37 --> Total execution time: 1.1553
DEBUG - 2016-09-21 17:08:51 --> Config Class Initialized
DEBUG - 2016-09-21 17:08:51 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:08:51 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:08:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:08:51 --> URI Class Initialized
DEBUG - 2016-09-21 17:08:51 --> Router Class Initialized
DEBUG - 2016-09-21 17:08:51 --> Output Class Initialized
DEBUG - 2016-09-21 17:08:51 --> Security Class Initialized
DEBUG - 2016-09-21 17:08:51 --> Input Class Initialized
DEBUG - 2016-09-21 17:08:51 --> XSS Filtering completed
DEBUG - 2016-09-21 17:08:51 --> XSS Filtering completed
DEBUG - 2016-09-21 17:08:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:08:51 --> Language Class Initialized
DEBUG - 2016-09-21 17:08:51 --> Loader Class Initialized
DEBUG - 2016-09-21 17:08:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:08:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:08:51 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:08:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:08:51 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:08:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:08:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:08:51 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:08:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:08:51 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:08:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:08:51 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:08:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:08:51 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:08:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:08:51 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:08:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:08:51 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:08:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:08:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:08:51 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:08:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:08:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:08:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:08:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:08:51 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:08:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:08:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:08:51 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:08:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:08:51 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:08:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:08:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:08:51 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:08:51 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:08:51 --> Session Class Initialized
DEBUG - 2016-09-21 17:08:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:08:51 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:08:51 --> Session routines successfully run
DEBUG - 2016-09-21 17:08:51 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:08:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:08:52 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:08:52 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:08:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:08:52 --> Controller Class Initialized
DEBUG - 2016-09-21 17:08:52 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:08:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:08:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:08:52 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:08:52 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:08:52 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:08:52 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:52 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:52 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:52 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:52 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:52 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:52 --> Config Class Initialized
DEBUG - 2016-09-21 17:08:52 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:08:52 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:08:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:08:52 --> URI Class Initialized
DEBUG - 2016-09-21 17:08:52 --> Router Class Initialized
DEBUG - 2016-09-21 17:08:52 --> Output Class Initialized
DEBUG - 2016-09-21 17:08:52 --> Security Class Initialized
DEBUG - 2016-09-21 17:08:52 --> Input Class Initialized
DEBUG - 2016-09-21 17:08:52 --> XSS Filtering completed
DEBUG - 2016-09-21 17:08:52 --> XSS Filtering completed
DEBUG - 2016-09-21 17:08:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:08:52 --> Language Class Initialized
DEBUG - 2016-09-21 17:08:52 --> Loader Class Initialized
DEBUG - 2016-09-21 17:08:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:08:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:08:52 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:08:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:08:52 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:08:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:08:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:08:52 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:08:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:08:52 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:08:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:08:52 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:08:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:08:52 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:08:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:08:52 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:08:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:08:52 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:08:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:08:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:08:52 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:08:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:08:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:08:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:08:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:08:52 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:08:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:08:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:08:52 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:08:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:08:52 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:08:52 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:08:52 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:08:52 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:08:53 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:08:53 --> Session Class Initialized
DEBUG - 2016-09-21 17:08:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:08:53 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:08:53 --> Session routines successfully run
DEBUG - 2016-09-21 17:08:53 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:08:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:08:53 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:08:53 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:08:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:08:53 --> Controller Class Initialized
DEBUG - 2016-09-21 17:08:53 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:08:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:08:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:08:53 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:08:53 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:08:53 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:08:53 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:53 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:53 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:53 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:53 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:53 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:53 --> Config Class Initialized
DEBUG - 2016-09-21 17:08:53 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:08:53 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:08:53 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:08:53 --> URI Class Initialized
DEBUG - 2016-09-21 17:08:53 --> Router Class Initialized
DEBUG - 2016-09-21 17:08:53 --> Output Class Initialized
DEBUG - 2016-09-21 17:08:53 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 17:08:53 --> Security Class Initialized
DEBUG - 2016-09-21 17:08:53 --> Input Class Initialized
DEBUG - 2016-09-21 17:08:53 --> XSS Filtering completed
DEBUG - 2016-09-21 17:08:53 --> XSS Filtering completed
DEBUG - 2016-09-21 17:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:08:53 --> Language Class Initialized
DEBUG - 2016-09-21 17:08:53 --> Loader Class Initialized
DEBUG - 2016-09-21 17:08:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:08:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:08:53 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:08:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:08:53 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:08:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:08:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:08:53 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:08:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:08:53 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:08:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:08:53 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:08:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:08:53 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:08:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:08:53 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:08:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:08:53 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:08:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:08:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:08:53 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:08:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:08:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:08:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:08:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:08:54 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:08:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:08:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:08:54 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:08:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:08:54 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:08:54 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:08:54 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:08:54 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:08:54 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:08:54 --> Session Class Initialized
DEBUG - 2016-09-21 17:08:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:08:54 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:08:54 --> Session routines successfully run
DEBUG - 2016-09-21 17:08:54 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:08:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:08:54 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:08:54 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:08:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:08:54 --> Controller Class Initialized
DEBUG - 2016-09-21 17:08:54 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:08:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:08:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:08:54 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:08:54 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:08:54 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:08:54 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:54 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:54 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:54 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:54 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:54 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:54 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:54 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:54 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:54 --> Model Class Initialized
DEBUG - 2016-09-21 17:08:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:08:54 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 17:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-21 17:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:08:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:08:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-21 17:08:54 --> Final output sent to browser
DEBUG - 2016-09-21 17:08:54 --> Total execution time: 1.2685
DEBUG - 2016-09-21 17:15:05 --> Config Class Initialized
DEBUG - 2016-09-21 17:15:05 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:15:05 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:15:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:15:05 --> URI Class Initialized
DEBUG - 2016-09-21 17:15:05 --> Router Class Initialized
DEBUG - 2016-09-21 17:15:05 --> Output Class Initialized
DEBUG - 2016-09-21 17:15:05 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 17:15:05 --> Security Class Initialized
DEBUG - 2016-09-21 17:15:05 --> Input Class Initialized
DEBUG - 2016-09-21 17:15:05 --> XSS Filtering completed
DEBUG - 2016-09-21 17:15:05 --> XSS Filtering completed
DEBUG - 2016-09-21 17:15:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:15:05 --> Language Class Initialized
DEBUG - 2016-09-21 17:15:05 --> Loader Class Initialized
DEBUG - 2016-09-21 17:15:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:15:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:15:05 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:15:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:15:05 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:15:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:15:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:15:05 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:15:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:15:05 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:15:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:15:05 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:15:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:15:05 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:15:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:15:05 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:15:05 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:15:05 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:15:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:15:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:15:05 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:15:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:15:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:15:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:15:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:15:05 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:15:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:15:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:15:05 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:15:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:15:05 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:15:05 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:15:05 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:15:05 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:15:05 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:15:06 --> Session Class Initialized
DEBUG - 2016-09-21 17:15:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:15:06 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:15:06 --> Session routines successfully run
DEBUG - 2016-09-21 17:15:06 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:15:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:15:06 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:15:06 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:15:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:15:06 --> Controller Class Initialized
DEBUG - 2016-09-21 17:15:06 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:15:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:15:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:15:06 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:15:06 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:15:06 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:15:06 --> Model Class Initialized
DEBUG - 2016-09-21 17:15:06 --> Model Class Initialized
DEBUG - 2016-09-21 17:15:06 --> Model Class Initialized
DEBUG - 2016-09-21 17:15:06 --> Model Class Initialized
DEBUG - 2016-09-21 17:15:06 --> Model Class Initialized
DEBUG - 2016-09-21 17:15:06 --> Model Class Initialized
DEBUG - 2016-09-21 17:15:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:15:06 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:15:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 17:15:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-09-21 17:15:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:15:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:15:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:15:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:15:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:15:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:15:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:15:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:15:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:15:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:15:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:15:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:15:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:15:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:15:06 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-09-21 17:15:06 --> Final output sent to browser
DEBUG - 2016-09-21 17:15:06 --> Total execution time: 1.2239
DEBUG - 2016-09-21 17:17:07 --> Config Class Initialized
DEBUG - 2016-09-21 17:17:07 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:17:07 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:17:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:17:07 --> URI Class Initialized
DEBUG - 2016-09-21 17:17:07 --> Router Class Initialized
DEBUG - 2016-09-21 17:17:07 --> Output Class Initialized
DEBUG - 2016-09-21 17:17:07 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 17:17:07 --> Security Class Initialized
DEBUG - 2016-09-21 17:17:07 --> Input Class Initialized
DEBUG - 2016-09-21 17:17:07 --> XSS Filtering completed
DEBUG - 2016-09-21 17:17:07 --> XSS Filtering completed
DEBUG - 2016-09-21 17:17:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:17:07 --> Language Class Initialized
DEBUG - 2016-09-21 17:17:07 --> Loader Class Initialized
DEBUG - 2016-09-21 17:17:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:17:07 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:17:07 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:17:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:17:07 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:17:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:17:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:17:07 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:17:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:17:07 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:17:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:17:07 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:17:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:17:07 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:17:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:17:07 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:17:08 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:17:08 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:17:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:17:08 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:17:08 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:17:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:17:08 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:17:08 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:17:08 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:17:08 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:17:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:17:08 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:17:08 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:17:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:17:08 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:17:08 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:17:08 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:17:08 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:17:08 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:17:08 --> Session Class Initialized
DEBUG - 2016-09-21 17:17:08 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:17:08 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:17:08 --> Session routines successfully run
DEBUG - 2016-09-21 17:17:08 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:17:08 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:17:08 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:17:08 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:17:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:17:08 --> Controller Class Initialized
DEBUG - 2016-09-21 17:17:08 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:17:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:17:08 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:17:08 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:17:08 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:17:08 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:17:08 --> Model Class Initialized
DEBUG - 2016-09-21 17:17:08 --> Model Class Initialized
DEBUG - 2016-09-21 17:17:08 --> Model Class Initialized
DEBUG - 2016-09-21 17:17:08 --> Model Class Initialized
DEBUG - 2016-09-21 17:17:08 --> Model Class Initialized
DEBUG - 2016-09-21 17:17:08 --> Model Class Initialized
DEBUG - 2016-09-21 17:17:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:17:08 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:17:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 17:17:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-09-21 17:17:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:17:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:17:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:17:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:17:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:17:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:17:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:17:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:17:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:17:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:17:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:17:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:17:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:17:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:17:09 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-09-21 17:17:09 --> Final output sent to browser
DEBUG - 2016-09-21 17:17:09 --> Total execution time: 1.2376
DEBUG - 2016-09-21 17:17:16 --> Config Class Initialized
DEBUG - 2016-09-21 17:17:16 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:17:16 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:17:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:17:16 --> URI Class Initialized
DEBUG - 2016-09-21 17:17:16 --> Router Class Initialized
DEBUG - 2016-09-21 17:17:16 --> Output Class Initialized
DEBUG - 2016-09-21 17:17:16 --> Security Class Initialized
DEBUG - 2016-09-21 17:17:16 --> Input Class Initialized
DEBUG - 2016-09-21 17:17:16 --> XSS Filtering completed
DEBUG - 2016-09-21 17:17:16 --> XSS Filtering completed
DEBUG - 2016-09-21 17:17:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:17:16 --> Language Class Initialized
DEBUG - 2016-09-21 17:17:16 --> Loader Class Initialized
DEBUG - 2016-09-21 17:17:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:17:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:17:17 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:17:17 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:17:17 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:17:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:17:17 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:17:17 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:17:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:17:17 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:17:17 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:17:17 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:17:17 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:17:17 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:17:17 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:17:17 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:17:17 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:17:17 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:17:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:17:17 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:17:17 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:17:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:17:17 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:17:17 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:17:17 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:17:17 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:17:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:17:17 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:17:17 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:17:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:17:17 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:17:17 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:17:17 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:17:17 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:17:17 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:17:17 --> Session Class Initialized
DEBUG - 2016-09-21 17:17:17 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:17:17 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:17:17 --> Session routines successfully run
DEBUG - 2016-09-21 17:17:17 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:17:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:17:17 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:17:17 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:17:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:17:17 --> Controller Class Initialized
DEBUG - 2016-09-21 17:17:17 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:17:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:17:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:17:17 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:17:17 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:17:17 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:17:17 --> Model Class Initialized
DEBUG - 2016-09-21 17:17:17 --> Model Class Initialized
DEBUG - 2016-09-21 17:17:17 --> Model Class Initialized
DEBUG - 2016-09-21 17:17:17 --> Model Class Initialized
DEBUG - 2016-09-21 17:17:17 --> Model Class Initialized
DEBUG - 2016-09-21 17:17:17 --> Model Class Initialized
DEBUG - 2016-09-21 17:19:27 --> Config Class Initialized
DEBUG - 2016-09-21 17:19:27 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:19:27 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:19:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:19:27 --> URI Class Initialized
DEBUG - 2016-09-21 17:19:27 --> Router Class Initialized
DEBUG - 2016-09-21 17:19:27 --> Output Class Initialized
DEBUG - 2016-09-21 17:19:27 --> Security Class Initialized
DEBUG - 2016-09-21 17:19:27 --> Input Class Initialized
DEBUG - 2016-09-21 17:19:27 --> XSS Filtering completed
DEBUG - 2016-09-21 17:19:27 --> XSS Filtering completed
DEBUG - 2016-09-21 17:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:19:27 --> Language Class Initialized
DEBUG - 2016-09-21 17:19:27 --> Loader Class Initialized
DEBUG - 2016-09-21 17:19:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:19:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:19:27 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:19:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:19:27 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:19:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:19:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:19:27 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:19:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:19:27 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:19:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:19:27 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:19:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:19:27 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:19:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:19:27 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:19:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:19:27 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:19:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:19:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:19:27 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:19:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:19:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:19:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:19:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:19:27 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:19:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:19:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:19:27 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:19:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:19:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:19:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:19:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:19:27 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:19:27 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:19:28 --> Session Class Initialized
DEBUG - 2016-09-21 17:19:28 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:19:28 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:19:28 --> Session routines successfully run
DEBUG - 2016-09-21 17:19:28 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:19:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:19:28 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:19:28 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:19:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:19:28 --> Controller Class Initialized
DEBUG - 2016-09-21 17:19:28 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:19:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:19:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:19:28 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:19:28 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:19:28 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:19:28 --> Model Class Initialized
DEBUG - 2016-09-21 17:19:28 --> Model Class Initialized
DEBUG - 2016-09-21 17:19:28 --> Model Class Initialized
DEBUG - 2016-09-21 17:19:28 --> Model Class Initialized
DEBUG - 2016-09-21 17:19:28 --> Model Class Initialized
DEBUG - 2016-09-21 17:19:28 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:06 --> Config Class Initialized
DEBUG - 2016-09-21 17:20:06 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:20:06 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:20:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:20:06 --> URI Class Initialized
DEBUG - 2016-09-21 17:20:06 --> Router Class Initialized
DEBUG - 2016-09-21 17:20:06 --> Output Class Initialized
DEBUG - 2016-09-21 17:20:07 --> Security Class Initialized
DEBUG - 2016-09-21 17:20:07 --> Input Class Initialized
DEBUG - 2016-09-21 17:20:07 --> XSS Filtering completed
DEBUG - 2016-09-21 17:20:07 --> XSS Filtering completed
DEBUG - 2016-09-21 17:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:20:07 --> Language Class Initialized
DEBUG - 2016-09-21 17:20:07 --> Loader Class Initialized
DEBUG - 2016-09-21 17:20:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:20:07 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:20:07 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:20:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:20:07 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:20:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:20:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:20:07 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:20:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:20:07 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:20:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:20:07 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:20:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:20:07 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:20:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:20:07 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:20:07 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:20:07 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:20:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:20:07 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:20:07 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:20:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:20:07 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:20:07 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:20:07 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:20:07 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:20:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:20:07 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:20:07 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:20:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:20:07 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:20:07 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:20:07 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:20:07 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:20:07 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:20:07 --> Session Class Initialized
DEBUG - 2016-09-21 17:20:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:20:07 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:20:07 --> Session routines successfully run
DEBUG - 2016-09-21 17:20:07 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:20:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:20:07 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:20:07 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:20:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:20:07 --> Controller Class Initialized
DEBUG - 2016-09-21 17:20:07 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:20:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:20:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:20:07 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:20:07 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:20:07 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:20:07 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:07 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:08 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:08 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:08 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:08 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:08 --> Config Class Initialized
DEBUG - 2016-09-21 17:20:08 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:20:08 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:20:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:20:08 --> URI Class Initialized
DEBUG - 2016-09-21 17:20:08 --> Router Class Initialized
DEBUG - 2016-09-21 17:20:08 --> Output Class Initialized
DEBUG - 2016-09-21 17:20:08 --> Security Class Initialized
DEBUG - 2016-09-21 17:20:08 --> Input Class Initialized
DEBUG - 2016-09-21 17:20:08 --> XSS Filtering completed
DEBUG - 2016-09-21 17:20:08 --> XSS Filtering completed
DEBUG - 2016-09-21 17:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:20:08 --> Language Class Initialized
DEBUG - 2016-09-21 17:20:08 --> Loader Class Initialized
DEBUG - 2016-09-21 17:20:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:20:08 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:20:08 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:20:08 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:20:08 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:20:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:20:08 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:20:08 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:20:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:20:08 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:20:08 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:20:08 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:20:08 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:20:08 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:20:08 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:20:08 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:20:08 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:20:08 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:20:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:20:08 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:20:08 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:20:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:20:08 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:20:08 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:20:08 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:20:08 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:20:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:20:08 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:20:08 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:20:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:20:08 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:20:08 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:20:08 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:20:08 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:20:08 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:20:08 --> Session Class Initialized
DEBUG - 2016-09-21 17:20:08 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:20:08 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:20:09 --> Session routines successfully run
DEBUG - 2016-09-21 17:20:09 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:20:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:20:09 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:20:09 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:20:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:20:09 --> Controller Class Initialized
DEBUG - 2016-09-21 17:20:09 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:20:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:20:09 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:20:09 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:20:09 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:20:09 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:20:09 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:09 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:09 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:09 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:09 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:09 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:09 --> Config Class Initialized
DEBUG - 2016-09-21 17:20:09 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:20:09 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:20:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:20:09 --> URI Class Initialized
DEBUG - 2016-09-21 17:20:09 --> Router Class Initialized
DEBUG - 2016-09-21 17:20:09 --> Output Class Initialized
DEBUG - 2016-09-21 17:20:09 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 17:20:09 --> Security Class Initialized
DEBUG - 2016-09-21 17:20:09 --> Input Class Initialized
DEBUG - 2016-09-21 17:20:09 --> XSS Filtering completed
DEBUG - 2016-09-21 17:20:09 --> XSS Filtering completed
DEBUG - 2016-09-21 17:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:20:09 --> Language Class Initialized
DEBUG - 2016-09-21 17:20:09 --> Loader Class Initialized
DEBUG - 2016-09-21 17:20:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:20:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:20:09 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:20:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:20:09 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:20:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:20:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:20:09 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:20:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:20:09 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:20:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:20:09 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:20:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:20:09 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:20:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:20:09 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:20:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:20:09 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:20:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:20:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:20:09 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:20:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:20:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:20:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:20:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:20:10 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:20:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:20:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:20:10 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:20:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:20:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:20:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:20:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:20:10 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:20:10 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:20:10 --> Session Class Initialized
DEBUG - 2016-09-21 17:20:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:20:10 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:20:10 --> Session routines successfully run
DEBUG - 2016-09-21 17:20:10 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:20:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:20:10 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:20:10 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:20:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:20:10 --> Controller Class Initialized
DEBUG - 2016-09-21 17:20:10 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:20:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:20:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:20:10 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:20:10 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:20:10 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:20:10 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:10 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:10 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:10 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:10 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:10 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:10 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:10 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:10 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:10 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:20:10 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:20:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 17:20:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-21 17:20:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:20:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:20:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:20:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:20:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:20:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:20:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:20:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:20:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:20:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:20:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:20:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:20:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:20:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:20:11 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-21 17:20:11 --> Final output sent to browser
DEBUG - 2016-09-21 17:20:11 --> Total execution time: 1.3819
DEBUG - 2016-09-21 17:20:46 --> Config Class Initialized
DEBUG - 2016-09-21 17:20:46 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:20:46 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:20:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:20:46 --> URI Class Initialized
DEBUG - 2016-09-21 17:20:46 --> Router Class Initialized
DEBUG - 2016-09-21 17:20:46 --> Output Class Initialized
DEBUG - 2016-09-21 17:20:46 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 17:20:46 --> Security Class Initialized
DEBUG - 2016-09-21 17:20:46 --> Input Class Initialized
DEBUG - 2016-09-21 17:20:46 --> XSS Filtering completed
DEBUG - 2016-09-21 17:20:46 --> XSS Filtering completed
DEBUG - 2016-09-21 17:20:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:20:46 --> Language Class Initialized
DEBUG - 2016-09-21 17:20:46 --> Loader Class Initialized
DEBUG - 2016-09-21 17:20:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:20:47 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:20:47 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:20:47 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:20:47 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:20:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:20:47 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:20:47 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:20:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:20:47 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:20:47 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:20:47 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:20:47 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:20:47 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:20:47 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:20:47 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:20:47 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:20:47 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:20:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:20:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:20:47 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:20:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:20:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:20:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:20:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:20:47 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:20:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:20:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:20:47 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:20:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:20:47 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:20:47 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:20:47 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:20:47 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:20:47 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:20:47 --> Session Class Initialized
DEBUG - 2016-09-21 17:20:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:20:47 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:20:47 --> Session routines successfully run
DEBUG - 2016-09-21 17:20:47 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:20:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:20:47 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:20:47 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:20:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:20:47 --> Controller Class Initialized
DEBUG - 2016-09-21 17:20:47 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:20:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:20:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:20:47 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:20:47 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:20:47 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:20:47 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:47 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:47 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:47 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:47 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:47 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:20:48 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:20:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 17:20:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-09-21 17:20:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:20:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:20:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:20:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:20:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:20:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:20:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:20:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:20:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:20:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:20:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:20:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:20:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:20:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:20:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-09-21 17:20:48 --> Final output sent to browser
DEBUG - 2016-09-21 17:20:48 --> Total execution time: 1.3460
DEBUG - 2016-09-21 17:20:51 --> Config Class Initialized
DEBUG - 2016-09-21 17:20:51 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:20:51 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:20:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:20:51 --> URI Class Initialized
DEBUG - 2016-09-21 17:20:51 --> Router Class Initialized
DEBUG - 2016-09-21 17:20:51 --> Output Class Initialized
DEBUG - 2016-09-21 17:20:51 --> Security Class Initialized
DEBUG - 2016-09-21 17:20:52 --> Input Class Initialized
DEBUG - 2016-09-21 17:20:52 --> XSS Filtering completed
DEBUG - 2016-09-21 17:20:52 --> XSS Filtering completed
DEBUG - 2016-09-21 17:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:20:52 --> Language Class Initialized
DEBUG - 2016-09-21 17:20:52 --> Loader Class Initialized
DEBUG - 2016-09-21 17:20:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:20:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:20:52 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:20:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:20:52 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:20:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:20:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:20:52 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:20:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:20:52 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:20:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:20:52 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:20:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:20:52 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:20:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:20:52 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:20:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:20:52 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:20:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:20:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:20:52 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:20:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:20:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:20:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:20:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:20:52 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:20:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:20:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:20:52 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:20:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:20:52 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:20:52 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:20:52 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:20:52 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:20:52 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:20:52 --> Session Class Initialized
DEBUG - 2016-09-21 17:20:52 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:20:52 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:20:52 --> Session routines successfully run
DEBUG - 2016-09-21 17:20:52 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:20:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:20:52 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:20:52 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:20:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:20:52 --> Controller Class Initialized
DEBUG - 2016-09-21 17:20:52 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:20:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:20:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:20:52 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:20:52 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:20:52 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:20:53 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:53 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:53 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:53 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:53 --> Model Class Initialized
DEBUG - 2016-09-21 17:20:53 --> Model Class Initialized
DEBUG - 2016-09-21 17:24:16 --> Config Class Initialized
DEBUG - 2016-09-21 17:24:16 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:24:16 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:24:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:24:16 --> URI Class Initialized
DEBUG - 2016-09-21 17:24:16 --> Router Class Initialized
DEBUG - 2016-09-21 17:24:16 --> Output Class Initialized
DEBUG - 2016-09-21 17:24:16 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 17:24:16 --> Security Class Initialized
DEBUG - 2016-09-21 17:24:16 --> Input Class Initialized
DEBUG - 2016-09-21 17:24:16 --> XSS Filtering completed
DEBUG - 2016-09-21 17:24:16 --> XSS Filtering completed
DEBUG - 2016-09-21 17:24:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:24:16 --> Language Class Initialized
DEBUG - 2016-09-21 17:24:16 --> Loader Class Initialized
DEBUG - 2016-09-21 17:24:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:24:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:24:16 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:24:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:24:16 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:24:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:24:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:24:16 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:24:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:24:16 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:24:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:24:16 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:24:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:24:16 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:24:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:24:16 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:24:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:24:16 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:24:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:24:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:24:16 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:24:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:24:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:24:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:24:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:24:16 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:24:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:24:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:24:17 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:24:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:24:17 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:24:17 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:24:17 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:24:17 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:24:17 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:24:17 --> Session Class Initialized
DEBUG - 2016-09-21 17:24:17 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:24:17 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:24:17 --> Session routines successfully run
DEBUG - 2016-09-21 17:24:17 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:24:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:24:17 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:24:17 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:24:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:24:17 --> Controller Class Initialized
DEBUG - 2016-09-21 17:24:17 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:24:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:24:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:24:17 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:24:17 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:24:17 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:24:17 --> Model Class Initialized
DEBUG - 2016-09-21 17:24:17 --> Model Class Initialized
DEBUG - 2016-09-21 17:24:17 --> Model Class Initialized
DEBUG - 2016-09-21 17:24:17 --> Model Class Initialized
DEBUG - 2016-09-21 17:24:17 --> Model Class Initialized
DEBUG - 2016-09-21 17:24:17 --> Model Class Initialized
DEBUG - 2016-09-21 17:24:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:24:17 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:24:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
ERROR - 2016-09-21 17:24:17 --> Severity: Notice  --> Undefined property: stdClass::$id_peserta_diklat_crypted E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 98
DEBUG - 2016-09-21 17:24:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-09-21 17:24:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:24:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:24:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:24:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:24:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:24:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:24:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:24:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:24:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:24:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:24:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:24:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:24:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:24:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:24:17 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-09-21 17:24:17 --> Final output sent to browser
DEBUG - 2016-09-21 17:24:18 --> Total execution time: 1.3731
DEBUG - 2016-09-21 17:24:19 --> Config Class Initialized
DEBUG - 2016-09-21 17:24:19 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:24:19 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:24:19 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:24:19 --> URI Class Initialized
DEBUG - 2016-09-21 17:24:19 --> Router Class Initialized
DEBUG - 2016-09-21 17:24:19 --> Output Class Initialized
DEBUG - 2016-09-21 17:24:19 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 17:24:19 --> Security Class Initialized
DEBUG - 2016-09-21 17:24:19 --> Input Class Initialized
DEBUG - 2016-09-21 17:24:19 --> XSS Filtering completed
DEBUG - 2016-09-21 17:24:19 --> XSS Filtering completed
DEBUG - 2016-09-21 17:24:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:24:19 --> Language Class Initialized
DEBUG - 2016-09-21 17:24:19 --> Loader Class Initialized
DEBUG - 2016-09-21 17:24:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:24:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:24:19 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:24:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:24:19 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:24:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:24:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:24:19 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:24:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:24:19 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:24:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:24:19 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:24:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:24:19 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:24:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:24:19 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:24:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:24:20 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:24:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:24:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:24:20 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:24:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:24:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:24:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:24:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:24:20 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:24:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:24:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:24:20 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:24:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:24:20 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:24:20 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:24:20 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:24:20 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:24:20 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:24:20 --> Session Class Initialized
DEBUG - 2016-09-21 17:24:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:24:20 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:24:20 --> Session routines successfully run
DEBUG - 2016-09-21 17:24:20 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:24:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:24:20 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:24:20 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:24:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:24:20 --> Controller Class Initialized
DEBUG - 2016-09-21 17:24:20 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:24:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:24:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:24:20 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:24:20 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:24:20 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:24:20 --> Model Class Initialized
DEBUG - 2016-09-21 17:24:20 --> Model Class Initialized
DEBUG - 2016-09-21 17:24:20 --> Model Class Initialized
DEBUG - 2016-09-21 17:24:20 --> Model Class Initialized
DEBUG - 2016-09-21 17:24:20 --> Model Class Initialized
DEBUG - 2016-09-21 17:24:20 --> Model Class Initialized
DEBUG - 2016-09-21 17:24:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:24:20 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:24:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
ERROR - 2016-09-21 17:24:20 --> Severity: Notice  --> Undefined property: stdClass::$id_peserta_diklat_crypted E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 98
DEBUG - 2016-09-21 17:24:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-09-21 17:24:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:24:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:24:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:24:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:24:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:24:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:24:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:24:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:24:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:24:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:24:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:24:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:24:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:24:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:24:21 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-09-21 17:24:21 --> Final output sent to browser
DEBUG - 2016-09-21 17:24:21 --> Total execution time: 1.3834
DEBUG - 2016-09-21 17:25:33 --> Config Class Initialized
DEBUG - 2016-09-21 17:25:33 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:25:33 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:25:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:25:33 --> URI Class Initialized
DEBUG - 2016-09-21 17:25:33 --> Router Class Initialized
DEBUG - 2016-09-21 17:25:33 --> Output Class Initialized
DEBUG - 2016-09-21 17:25:33 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 17:25:33 --> Security Class Initialized
DEBUG - 2016-09-21 17:25:33 --> Input Class Initialized
DEBUG - 2016-09-21 17:25:33 --> XSS Filtering completed
DEBUG - 2016-09-21 17:25:33 --> XSS Filtering completed
DEBUG - 2016-09-21 17:25:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:25:33 --> Language Class Initialized
DEBUG - 2016-09-21 17:25:33 --> Loader Class Initialized
DEBUG - 2016-09-21 17:25:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:25:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:25:33 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:25:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:25:33 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:25:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:25:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:25:33 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:25:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:25:34 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:25:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:25:34 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:25:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:25:34 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:25:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:25:34 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:25:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:25:34 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:25:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:25:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:25:34 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:25:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:25:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:25:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:25:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:25:34 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:25:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:25:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:25:34 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:25:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:25:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:25:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:25:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:25:34 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:25:34 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:25:34 --> Session Class Initialized
DEBUG - 2016-09-21 17:25:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:25:34 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:25:34 --> Session routines successfully run
DEBUG - 2016-09-21 17:25:34 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:25:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:25:34 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:25:34 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:25:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:25:34 --> Controller Class Initialized
DEBUG - 2016-09-21 17:25:34 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:25:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:25:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:25:34 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:25:34 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:25:34 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:25:34 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:34 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:34 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:34 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:34 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:34 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:25:34 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:25:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 17:25:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-09-21 17:25:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:25:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:25:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:25:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:25:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:25:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:25:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:25:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:25:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:25:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:25:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:25:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:25:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:25:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:25:35 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-09-21 17:25:35 --> Final output sent to browser
DEBUG - 2016-09-21 17:25:35 --> Total execution time: 1.4066
DEBUG - 2016-09-21 17:25:43 --> Config Class Initialized
DEBUG - 2016-09-21 17:25:43 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:25:43 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:25:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:25:43 --> URI Class Initialized
DEBUG - 2016-09-21 17:25:43 --> Router Class Initialized
DEBUG - 2016-09-21 17:25:43 --> Output Class Initialized
DEBUG - 2016-09-21 17:25:43 --> Security Class Initialized
DEBUG - 2016-09-21 17:25:43 --> Input Class Initialized
DEBUG - 2016-09-21 17:25:43 --> XSS Filtering completed
DEBUG - 2016-09-21 17:25:43 --> XSS Filtering completed
DEBUG - 2016-09-21 17:25:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:25:43 --> Language Class Initialized
DEBUG - 2016-09-21 17:25:43 --> Loader Class Initialized
DEBUG - 2016-09-21 17:25:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:25:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:25:43 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:25:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:25:43 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:25:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:25:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:25:43 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:25:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:25:43 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:25:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:25:43 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:25:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:25:43 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:25:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:25:43 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:25:43 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:25:43 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:25:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:25:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:25:43 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:25:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:25:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:25:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:25:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:25:44 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:25:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:25:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:25:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:25:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:25:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:25:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:25:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:25:44 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:25:44 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:25:44 --> Session Class Initialized
DEBUG - 2016-09-21 17:25:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:25:44 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:25:44 --> Session routines successfully run
DEBUG - 2016-09-21 17:25:44 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:25:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:25:44 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:25:44 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:25:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:25:44 --> Controller Class Initialized
DEBUG - 2016-09-21 17:25:44 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:25:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:25:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:25:44 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:25:44 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:25:44 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:25:44 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:44 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:44 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:44 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:44 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:44 --> Model Class Initialized
ERROR - 2016-09-21 17:25:44 --> Severity: Notice  --> Undefined variable: id_value E:\www\GitHub\2016APSIDIKA\application\models\model_tr_peserta_diklat.php 294
DEBUG - 2016-09-21 17:25:44 --> Config Class Initialized
DEBUG - 2016-09-21 17:25:44 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:25:44 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:25:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:25:44 --> URI Class Initialized
DEBUG - 2016-09-21 17:25:44 --> Router Class Initialized
DEBUG - 2016-09-21 17:25:44 --> Output Class Initialized
DEBUG - 2016-09-21 17:25:44 --> Security Class Initialized
DEBUG - 2016-09-21 17:25:44 --> Input Class Initialized
DEBUG - 2016-09-21 17:25:44 --> XSS Filtering completed
DEBUG - 2016-09-21 17:25:44 --> XSS Filtering completed
DEBUG - 2016-09-21 17:25:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:25:44 --> Language Class Initialized
DEBUG - 2016-09-21 17:25:44 --> Loader Class Initialized
DEBUG - 2016-09-21 17:25:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:25:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:25:45 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:25:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:25:45 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:25:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:25:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:25:45 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:25:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:25:45 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:25:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:25:45 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:25:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:25:45 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:25:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:25:45 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:25:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:25:45 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:25:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:25:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:25:45 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:25:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:25:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:25:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:25:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:25:45 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:25:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:25:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:25:45 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:25:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:25:45 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:25:45 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:25:45 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:25:45 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:25:45 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:25:45 --> Session Class Initialized
DEBUG - 2016-09-21 17:25:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:25:45 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:25:45 --> Session routines successfully run
DEBUG - 2016-09-21 17:25:45 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:25:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:25:45 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:25:45 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:25:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:25:45 --> Controller Class Initialized
DEBUG - 2016-09-21 17:25:45 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:25:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:25:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:25:45 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:25:45 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:25:45 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:25:45 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:45 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:46 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:46 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:46 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:46 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:46 --> Config Class Initialized
DEBUG - 2016-09-21 17:25:46 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:25:46 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:25:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:25:46 --> URI Class Initialized
DEBUG - 2016-09-21 17:25:46 --> Router Class Initialized
DEBUG - 2016-09-21 17:25:46 --> Output Class Initialized
DEBUG - 2016-09-21 17:25:46 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 17:25:46 --> Security Class Initialized
DEBUG - 2016-09-21 17:25:46 --> Input Class Initialized
DEBUG - 2016-09-21 17:25:46 --> XSS Filtering completed
DEBUG - 2016-09-21 17:25:46 --> XSS Filtering completed
DEBUG - 2016-09-21 17:25:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:25:46 --> Language Class Initialized
DEBUG - 2016-09-21 17:25:46 --> Loader Class Initialized
DEBUG - 2016-09-21 17:25:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:25:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:25:46 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:25:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:25:46 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:25:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:25:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:25:46 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:25:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:25:46 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:25:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:25:46 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:25:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:25:46 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:25:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:25:46 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:25:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:25:46 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:25:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:25:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:25:46 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:25:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:25:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:25:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:25:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:25:46 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:25:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:25:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:25:46 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:25:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:25:46 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:25:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:25:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:25:46 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:25:47 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:25:47 --> Session Class Initialized
DEBUG - 2016-09-21 17:25:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:25:47 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:25:47 --> Session routines successfully run
DEBUG - 2016-09-21 17:25:47 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:25:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:25:47 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:25:47 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:25:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:25:47 --> Controller Class Initialized
DEBUG - 2016-09-21 17:25:47 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:25:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:25:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:25:47 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:25:47 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:25:47 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:25:47 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:47 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:47 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:47 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:47 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:47 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:47 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:47 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:47 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:47 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:25:47 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-21 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:25:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:25:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-21 17:25:47 --> Final output sent to browser
DEBUG - 2016-09-21 17:25:47 --> Total execution time: 1.5380
DEBUG - 2016-09-21 17:25:50 --> Config Class Initialized
DEBUG - 2016-09-21 17:25:50 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:25:50 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:25:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:25:50 --> URI Class Initialized
DEBUG - 2016-09-21 17:25:50 --> Router Class Initialized
DEBUG - 2016-09-21 17:25:50 --> Output Class Initialized
DEBUG - 2016-09-21 17:25:50 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 17:25:50 --> Security Class Initialized
DEBUG - 2016-09-21 17:25:50 --> Input Class Initialized
DEBUG - 2016-09-21 17:25:50 --> XSS Filtering completed
DEBUG - 2016-09-21 17:25:50 --> XSS Filtering completed
DEBUG - 2016-09-21 17:25:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:25:50 --> Language Class Initialized
DEBUG - 2016-09-21 17:25:50 --> Loader Class Initialized
DEBUG - 2016-09-21 17:25:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:25:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:25:50 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:25:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:25:50 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:25:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:25:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:25:50 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:25:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:25:50 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:25:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:25:50 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:25:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:25:50 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:25:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:25:50 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:25:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:25:50 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:25:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:25:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:25:51 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:25:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:25:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:25:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:25:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:25:51 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:25:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:25:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:25:51 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:25:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:25:51 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:25:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:25:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:25:51 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:25:51 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:25:51 --> Session Class Initialized
DEBUG - 2016-09-21 17:25:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:25:51 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:25:51 --> Session routines successfully run
DEBUG - 2016-09-21 17:25:51 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:25:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:25:51 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:25:51 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:25:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:25:51 --> Controller Class Initialized
DEBUG - 2016-09-21 17:25:51 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:25:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:25:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:25:51 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:25:51 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:25:51 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:25:51 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:51 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:51 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:51 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:51 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:51 --> Model Class Initialized
DEBUG - 2016-09-21 17:25:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:25:51 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:25:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 17:25:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-09-21 17:25:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:25:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:25:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:25:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:25:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:25:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:25:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:25:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:25:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:25:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:25:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:25:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:25:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:25:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:25:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-09-21 17:25:52 --> Final output sent to browser
DEBUG - 2016-09-21 17:25:52 --> Total execution time: 1.4617
DEBUG - 2016-09-21 17:26:32 --> Config Class Initialized
DEBUG - 2016-09-21 17:26:32 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:26:32 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:26:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:26:32 --> URI Class Initialized
DEBUG - 2016-09-21 17:26:32 --> Router Class Initialized
DEBUG - 2016-09-21 17:26:32 --> Output Class Initialized
DEBUG - 2016-09-21 17:26:32 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 17:26:32 --> Security Class Initialized
DEBUG - 2016-09-21 17:26:32 --> Input Class Initialized
DEBUG - 2016-09-21 17:26:32 --> XSS Filtering completed
DEBUG - 2016-09-21 17:26:32 --> XSS Filtering completed
DEBUG - 2016-09-21 17:26:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:26:32 --> Language Class Initialized
DEBUG - 2016-09-21 17:26:32 --> Loader Class Initialized
DEBUG - 2016-09-21 17:26:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:26:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:26:32 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:26:32 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:26:32 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:26:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:26:32 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:26:32 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:26:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:26:32 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:26:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:26:32 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:26:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:26:32 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:26:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:26:32 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:26:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:26:32 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:26:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:26:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:26:32 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:26:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:26:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:26:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:26:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:26:32 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:26:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:26:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:26:32 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:26:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:26:32 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:26:32 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:26:33 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:26:33 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:26:33 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:26:33 --> Session Class Initialized
DEBUG - 2016-09-21 17:26:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:26:33 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:26:33 --> Session routines successfully run
DEBUG - 2016-09-21 17:26:33 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:26:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:26:33 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:26:33 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:26:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:26:33 --> Controller Class Initialized
DEBUG - 2016-09-21 17:26:33 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:26:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:26:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:26:33 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:26:33 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:26:33 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:26:33 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:33 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:33 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:33 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:33 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:33 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:26:33 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:26:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 17:26:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-09-21 17:26:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:26:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:26:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:26:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:26:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:26:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:26:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:26:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:26:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:26:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:26:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:26:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:26:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:26:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:26:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-09-21 17:26:33 --> Final output sent to browser
DEBUG - 2016-09-21 17:26:33 --> Total execution time: 1.4759
DEBUG - 2016-09-21 17:26:39 --> Config Class Initialized
DEBUG - 2016-09-21 17:26:39 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:26:39 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:26:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:26:39 --> URI Class Initialized
DEBUG - 2016-09-21 17:26:39 --> Router Class Initialized
DEBUG - 2016-09-21 17:26:39 --> Output Class Initialized
DEBUG - 2016-09-21 17:26:39 --> Security Class Initialized
DEBUG - 2016-09-21 17:26:39 --> Input Class Initialized
DEBUG - 2016-09-21 17:26:39 --> XSS Filtering completed
DEBUG - 2016-09-21 17:26:39 --> XSS Filtering completed
DEBUG - 2016-09-21 17:26:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:26:39 --> Language Class Initialized
DEBUG - 2016-09-21 17:26:39 --> Loader Class Initialized
DEBUG - 2016-09-21 17:26:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:26:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:26:39 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:26:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:26:39 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:26:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:26:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:26:39 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:26:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:26:39 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:26:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:26:39 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:26:39 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:26:39 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:26:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:26:40 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:26:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:26:40 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:26:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:26:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:26:40 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:26:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:26:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:26:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:26:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:26:40 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:26:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:26:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:26:40 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:26:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:26:40 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:26:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:26:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:26:40 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:26:40 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:26:40 --> Session Class Initialized
DEBUG - 2016-09-21 17:26:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:26:40 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:26:40 --> Session routines successfully run
DEBUG - 2016-09-21 17:26:40 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:26:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:26:40 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:26:40 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:26:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:26:40 --> Controller Class Initialized
DEBUG - 2016-09-21 17:26:40 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:26:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:26:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:26:40 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:26:40 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:26:40 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:26:40 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:40 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:40 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:40 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:40 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:40 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:40 --> Config Class Initialized
DEBUG - 2016-09-21 17:26:40 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:26:40 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:26:40 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:26:41 --> URI Class Initialized
DEBUG - 2016-09-21 17:26:41 --> Router Class Initialized
DEBUG - 2016-09-21 17:26:41 --> Output Class Initialized
DEBUG - 2016-09-21 17:26:41 --> Security Class Initialized
DEBUG - 2016-09-21 17:26:41 --> Input Class Initialized
DEBUG - 2016-09-21 17:26:41 --> XSS Filtering completed
DEBUG - 2016-09-21 17:26:41 --> XSS Filtering completed
DEBUG - 2016-09-21 17:26:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:26:41 --> Language Class Initialized
DEBUG - 2016-09-21 17:26:41 --> Loader Class Initialized
DEBUG - 2016-09-21 17:26:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:26:41 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:26:41 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:26:41 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:26:41 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:26:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:26:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:26:41 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:26:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:26:41 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:26:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:26:41 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:26:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:26:41 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:26:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:26:41 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:26:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:26:41 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:26:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:26:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:26:41 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:26:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:26:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:26:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:26:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:26:41 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:26:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:26:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:26:41 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:26:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:26:41 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:26:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:26:41 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:26:41 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:26:41 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:26:41 --> Session Class Initialized
DEBUG - 2016-09-21 17:26:41 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:26:41 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:26:41 --> Session routines successfully run
DEBUG - 2016-09-21 17:26:42 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:26:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:26:42 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:26:42 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:26:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:26:42 --> Controller Class Initialized
DEBUG - 2016-09-21 17:26:42 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:26:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:26:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:26:42 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:26:42 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:26:42 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:26:42 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:42 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:42 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:42 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:42 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:42 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:42 --> Config Class Initialized
DEBUG - 2016-09-21 17:26:42 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:26:42 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:26:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:26:42 --> URI Class Initialized
DEBUG - 2016-09-21 17:26:42 --> Router Class Initialized
DEBUG - 2016-09-21 17:26:42 --> Output Class Initialized
DEBUG - 2016-09-21 17:26:42 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 17:26:42 --> Security Class Initialized
DEBUG - 2016-09-21 17:26:42 --> Input Class Initialized
DEBUG - 2016-09-21 17:26:42 --> XSS Filtering completed
DEBUG - 2016-09-21 17:26:42 --> XSS Filtering completed
DEBUG - 2016-09-21 17:26:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:26:42 --> Language Class Initialized
DEBUG - 2016-09-21 17:26:42 --> Loader Class Initialized
DEBUG - 2016-09-21 17:26:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:26:42 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:26:42 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:26:42 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:26:42 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:26:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:26:42 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:26:42 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:26:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:26:42 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:26:42 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:26:42 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:26:42 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:26:42 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:26:42 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:26:42 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:26:43 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:26:43 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:26:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:26:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:26:43 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:26:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:26:43 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:26:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:26:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:26:43 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:26:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:26:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:26:43 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:26:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:26:43 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:26:43 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:26:43 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:26:43 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:26:43 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:26:43 --> Session Class Initialized
DEBUG - 2016-09-21 17:26:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:26:43 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:26:43 --> Session routines successfully run
DEBUG - 2016-09-21 17:26:43 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:26:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:26:43 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:26:43 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:26:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:26:43 --> Controller Class Initialized
DEBUG - 2016-09-21 17:26:43 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:26:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:26:43 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:26:43 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:26:43 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:26:43 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:26:43 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:43 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:43 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:43 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:43 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:43 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:43 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:43 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:43 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:43 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:26:43 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:26:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 17:26:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-21 17:26:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:26:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:26:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:26:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:26:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:26:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:26:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:26:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:26:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:26:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:26:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:26:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:26:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:26:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:26:44 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-21 17:26:44 --> Final output sent to browser
DEBUG - 2016-09-21 17:26:44 --> Total execution time: 1.6248
DEBUG - 2016-09-21 17:26:46 --> Config Class Initialized
DEBUG - 2016-09-21 17:26:46 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:26:46 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:26:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:26:46 --> URI Class Initialized
DEBUG - 2016-09-21 17:26:46 --> Router Class Initialized
DEBUG - 2016-09-21 17:26:46 --> Output Class Initialized
DEBUG - 2016-09-21 17:26:46 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 17:26:46 --> Security Class Initialized
DEBUG - 2016-09-21 17:26:46 --> Input Class Initialized
DEBUG - 2016-09-21 17:26:46 --> XSS Filtering completed
DEBUG - 2016-09-21 17:26:46 --> XSS Filtering completed
DEBUG - 2016-09-21 17:26:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:26:46 --> Language Class Initialized
DEBUG - 2016-09-21 17:26:46 --> Loader Class Initialized
DEBUG - 2016-09-21 17:26:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:26:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:26:46 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:26:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:26:46 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:26:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:26:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:26:46 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:26:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:26:46 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:26:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:26:46 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:26:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:26:46 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:26:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:26:46 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:26:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:26:46 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:26:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:26:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:26:47 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:26:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:26:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:26:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:26:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:26:47 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:26:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:26:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:26:47 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:26:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:26:47 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:26:47 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:26:47 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:26:47 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:26:47 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:26:47 --> Session Class Initialized
DEBUG - 2016-09-21 17:26:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:26:47 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:26:47 --> Session routines successfully run
DEBUG - 2016-09-21 17:26:47 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:26:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:26:47 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:26:47 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:26:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:26:47 --> Controller Class Initialized
DEBUG - 2016-09-21 17:26:47 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:26:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:26:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:26:47 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:26:47 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:26:47 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:26:47 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:47 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:47 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:47 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:47 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:47 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:26:47 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:26:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 17:26:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-09-21 17:26:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:26:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:26:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:26:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:26:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:26:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:26:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:26:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:26:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:26:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:26:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:26:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:26:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:26:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:26:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-09-21 17:26:48 --> Final output sent to browser
DEBUG - 2016-09-21 17:26:48 --> Total execution time: 1.5511
DEBUG - 2016-09-21 17:26:50 --> Config Class Initialized
DEBUG - 2016-09-21 17:26:50 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:26:50 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:26:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:26:50 --> URI Class Initialized
DEBUG - 2016-09-21 17:26:50 --> Router Class Initialized
DEBUG - 2016-09-21 17:26:50 --> Output Class Initialized
DEBUG - 2016-09-21 17:26:50 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 17:26:50 --> Security Class Initialized
DEBUG - 2016-09-21 17:26:50 --> Input Class Initialized
DEBUG - 2016-09-21 17:26:50 --> XSS Filtering completed
DEBUG - 2016-09-21 17:26:50 --> XSS Filtering completed
DEBUG - 2016-09-21 17:26:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:26:50 --> Language Class Initialized
DEBUG - 2016-09-21 17:26:50 --> Loader Class Initialized
DEBUG - 2016-09-21 17:26:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:26:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:26:50 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:26:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:26:50 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:26:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:26:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:26:50 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:26:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:26:50 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:26:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:26:50 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:26:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:26:50 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:26:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:26:50 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:26:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:26:50 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:26:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:26:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:26:51 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:26:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:26:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:26:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:26:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:26:51 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:26:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:26:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:26:51 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:26:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:26:51 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:26:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:26:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:26:51 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:26:51 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:26:51 --> Session Class Initialized
DEBUG - 2016-09-21 17:26:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:26:51 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:26:51 --> Session routines successfully run
DEBUG - 2016-09-21 17:26:51 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:26:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:26:51 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:26:51 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:26:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:26:51 --> Controller Class Initialized
DEBUG - 2016-09-21 17:26:51 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:26:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:26:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:26:51 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:26:51 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:26:51 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:26:51 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:51 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:51 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:51 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:51 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:51 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:51 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:51 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:51 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:51 --> Model Class Initialized
DEBUG - 2016-09-21 17:26:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:26:51 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:26:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 17:26:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-21 17:26:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:26:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:26:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:26:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:26:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:26:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:26:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:26:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:26:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:26:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:26:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:26:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:26:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:26:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:26:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-21 17:26:52 --> Final output sent to browser
DEBUG - 2016-09-21 17:26:52 --> Total execution time: 1.6432
DEBUG - 2016-09-21 17:27:25 --> Config Class Initialized
DEBUG - 2016-09-21 17:27:25 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:27:25 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:27:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:27:25 --> URI Class Initialized
DEBUG - 2016-09-21 17:27:25 --> Router Class Initialized
DEBUG - 2016-09-21 17:27:25 --> Output Class Initialized
DEBUG - 2016-09-21 17:27:25 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 17:27:25 --> Security Class Initialized
DEBUG - 2016-09-21 17:27:25 --> Input Class Initialized
DEBUG - 2016-09-21 17:27:25 --> XSS Filtering completed
DEBUG - 2016-09-21 17:27:25 --> XSS Filtering completed
DEBUG - 2016-09-21 17:27:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:27:25 --> Language Class Initialized
DEBUG - 2016-09-21 17:27:25 --> Loader Class Initialized
DEBUG - 2016-09-21 17:27:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:27:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:27:25 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:27:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:27:25 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:27:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:27:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:27:25 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:27:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:27:25 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:27:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:27:25 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:27:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:27:25 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:27:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:27:26 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:27:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:27:26 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:27:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:27:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:27:26 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:27:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:27:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:27:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:27:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:27:26 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:27:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:27:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:27:26 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:27:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:27:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:27:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:27:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:27:26 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:27:26 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:27:26 --> Session Class Initialized
DEBUG - 2016-09-21 17:27:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:27:26 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:27:26 --> Session routines successfully run
DEBUG - 2016-09-21 17:27:26 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:27:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:27:26 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:27:26 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:27:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:27:26 --> Controller Class Initialized
DEBUG - 2016-09-21 17:27:26 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:27:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:27:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:27:26 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:27:26 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:27:26 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:27:26 --> Model Class Initialized
DEBUG - 2016-09-21 17:27:26 --> Model Class Initialized
DEBUG - 2016-09-21 17:27:26 --> Model Class Initialized
DEBUG - 2016-09-21 17:27:26 --> Model Class Initialized
DEBUG - 2016-09-21 17:27:26 --> Model Class Initialized
DEBUG - 2016-09-21 17:27:26 --> Model Class Initialized
DEBUG - 2016-09-21 17:27:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:27:26 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:27:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 17:27:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-09-21 17:27:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:27:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:27:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:27:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:27:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:27:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:27:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:27:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:27:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:27:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:27:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:27:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-21 17:27:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:27:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:27:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-09-21 17:27:27 --> Final output sent to browser
DEBUG - 2016-09-21 17:27:27 --> Total execution time: 1.5876
DEBUG - 2016-09-21 17:28:04 --> Config Class Initialized
DEBUG - 2016-09-21 17:28:04 --> Hooks Class Initialized
DEBUG - 2016-09-21 17:28:04 --> Utf8 Class Initialized
DEBUG - 2016-09-21 17:28:04 --> UTF-8 Support Enabled
DEBUG - 2016-09-21 17:28:04 --> URI Class Initialized
DEBUG - 2016-09-21 17:28:04 --> Router Class Initialized
DEBUG - 2016-09-21 17:28:04 --> Output Class Initialized
DEBUG - 2016-09-21 17:28:04 --> Cache file has expired. File deleted
DEBUG - 2016-09-21 17:28:04 --> Security Class Initialized
DEBUG - 2016-09-21 17:28:04 --> Input Class Initialized
DEBUG - 2016-09-21 17:28:04 --> XSS Filtering completed
DEBUG - 2016-09-21 17:28:04 --> XSS Filtering completed
DEBUG - 2016-09-21 17:28:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-21 17:28:04 --> Language Class Initialized
DEBUG - 2016-09-21 17:28:04 --> Loader Class Initialized
DEBUG - 2016-09-21 17:28:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-21 17:28:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-21 17:28:05 --> Helper loaded: url_helper
DEBUG - 2016-09-21 17:28:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-21 17:28:05 --> Helper loaded: file_helper
DEBUG - 2016-09-21 17:28:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:28:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-21 17:28:05 --> Helper loaded: conf_helper
DEBUG - 2016-09-21 17:28:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-21 17:28:05 --> Check Exists common_helper.php: No
DEBUG - 2016-09-21 17:28:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-21 17:28:05 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:28:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-21 17:28:05 --> Helper loaded: common_helper
DEBUG - 2016-09-21 17:28:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-21 17:28:05 --> Helper loaded: form_helper
DEBUG - 2016-09-21 17:28:05 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-21 17:28:05 --> Helper loaded: security_helper
DEBUG - 2016-09-21 17:28:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:28:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-21 17:28:05 --> Helper loaded: lang_helper
DEBUG - 2016-09-21 17:28:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-21 17:28:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-21 17:28:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-21 17:28:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-21 17:28:05 --> Helper loaded: atlant_helper
DEBUG - 2016-09-21 17:28:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:28:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-21 17:28:05 --> Helper loaded: crypto_helper
DEBUG - 2016-09-21 17:28:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-21 17:28:05 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-21 17:28:05 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-21 17:28:05 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-21 17:28:05 --> Helper loaded: sidika_helper
DEBUG - 2016-09-21 17:28:05 --> Database Driver Class Initialized
DEBUG - 2016-09-21 17:28:05 --> Session Class Initialized
DEBUG - 2016-09-21 17:28:05 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-21 17:28:05 --> Helper loaded: string_helper
DEBUG - 2016-09-21 17:28:05 --> Session routines successfully run
DEBUG - 2016-09-21 17:28:05 --> Native_session Class Initialized
DEBUG - 2016-09-21 17:28:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-21 17:28:05 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:28:05 --> Form Validation Class Initialized
DEBUG - 2016-09-21 17:28:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-21 17:28:05 --> Controller Class Initialized
DEBUG - 2016-09-21 17:28:05 --> Carabiner: Library initialized.
DEBUG - 2016-09-21 17:28:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-21 17:28:05 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-21 17:28:05 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:28:06 --> Carabiner: library configured.
DEBUG - 2016-09-21 17:28:06 --> User Agent Class Initialized
DEBUG - 2016-09-21 17:28:06 --> Model Class Initialized
DEBUG - 2016-09-21 17:28:06 --> Model Class Initialized
DEBUG - 2016-09-21 17:28:06 --> Model Class Initialized
DEBUG - 2016-09-21 17:28:06 --> Model Class Initialized
DEBUG - 2016-09-21 17:28:06 --> Model Class Initialized
DEBUG - 2016-09-21 17:28:06 --> Model Class Initialized
DEBUG - 2016-09-21 17:28:06 --> Model Class Initialized
DEBUG - 2016-09-21 17:28:06 --> Model Class Initialized
DEBUG - 2016-09-21 17:28:06 --> Model Class Initialized
DEBUG - 2016-09-21 17:28:06 --> Model Class Initialized
DEBUG - 2016-09-21 17:28:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-21 17:28:06 --> Pagination Class Initialized
DEBUG - 2016-09-21 17:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-21 17:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-21 17:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-21 17:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-21 17:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-21 17:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-21 17:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-21 17:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-21 17:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-21 17:28:06 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-21 17:28:06 --> Final output sent to browser
DEBUG - 2016-09-21 17:28:06 --> Total execution time: 1.6807
