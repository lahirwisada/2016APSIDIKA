<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-09-18 00:05:54 --> Config Class Initialized
DEBUG - 2016-09-18 00:05:54 --> Hooks Class Initialized
DEBUG - 2016-09-18 00:05:54 --> Utf8 Class Initialized
DEBUG - 2016-09-18 00:05:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 00:05:54 --> URI Class Initialized
DEBUG - 2016-09-18 00:05:54 --> Router Class Initialized
DEBUG - 2016-09-18 00:05:54 --> No URI present. Default controller set.
DEBUG - 2016-09-18 00:05:54 --> Output Class Initialized
DEBUG - 2016-09-18 00:05:54 --> Cache file has expired. File deleted
DEBUG - 2016-09-18 00:05:54 --> Security Class Initialized
DEBUG - 2016-09-18 00:05:54 --> Input Class Initialized
DEBUG - 2016-09-18 00:05:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 00:05:54 --> Language Class Initialized
DEBUG - 2016-09-18 00:05:54 --> Loader Class Initialized
DEBUG - 2016-09-18 00:05:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 00:05:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 00:05:54 --> Helper loaded: url_helper
DEBUG - 2016-09-18 00:05:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 00:05:54 --> Helper loaded: file_helper
DEBUG - 2016-09-18 00:05:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:05:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 00:05:54 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 00:05:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:05:54 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 00:05:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 00:05:54 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:05:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 00:05:54 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:05:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 00:05:54 --> Helper loaded: form_helper
DEBUG - 2016-09-18 00:05:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 00:05:54 --> Helper loaded: security_helper
DEBUG - 2016-09-18 00:05:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:05:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 00:05:54 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 00:05:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:05:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 00:05:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 00:05:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 00:05:54 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 00:05:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:05:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 00:05:54 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 00:05:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:05:54 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 00:05:54 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 00:05:54 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 00:05:54 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 00:05:54 --> Database Driver Class Initialized
DEBUG - 2016-09-18 00:05:54 --> Session Class Initialized
DEBUG - 2016-09-18 00:05:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 00:05:54 --> Helper loaded: string_helper
DEBUG - 2016-09-18 00:05:54 --> A session cookie was not found.
DEBUG - 2016-09-18 00:05:54 --> Session routines successfully run
DEBUG - 2016-09-18 00:05:54 --> Native_session Class Initialized
DEBUG - 2016-09-18 00:05:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 00:05:54 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:05:54 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:05:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 00:05:54 --> Controller Class Initialized
DEBUG - 2016-09-18 00:05:54 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 00:05:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 00:05:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 00:05:54 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:05:54 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:05:54 --> User Agent Class Initialized
DEBUG - 2016-09-18 00:05:54 --> Model Class Initialized
DEBUG - 2016-09-18 00:05:54 --> Model Class Initialized
DEBUG - 2016-09-18 00:05:54 --> Model Class Initialized
ERROR - 2016-09-18 00:05:54 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-18 00:05:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-18 00:05:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-18 00:05:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-18 00:05:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 00:05:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-18 00:05:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-18 00:05:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-18 00:05:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-18 00:05:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-18 00:05:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 00:05:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-18 00:05:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-18 00:05:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 00:05:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-18 00:05:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-18 00:05:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-18 00:05:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-18 00:05:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-18 00:05:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 00:05:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-18 00:05:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-18 00:05:54 --> Final output sent to browser
DEBUG - 2016-09-18 00:05:54 --> Total execution time: 0.4443
DEBUG - 2016-09-18 00:05:57 --> Config Class Initialized
DEBUG - 2016-09-18 00:05:57 --> Hooks Class Initialized
DEBUG - 2016-09-18 00:05:57 --> Utf8 Class Initialized
DEBUG - 2016-09-18 00:05:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 00:05:57 --> URI Class Initialized
DEBUG - 2016-09-18 00:05:57 --> Router Class Initialized
DEBUG - 2016-09-18 00:05:57 --> Output Class Initialized
DEBUG - 2016-09-18 00:05:57 --> Cache file has expired. File deleted
DEBUG - 2016-09-18 00:05:57 --> Security Class Initialized
DEBUG - 2016-09-18 00:05:57 --> Input Class Initialized
DEBUG - 2016-09-18 00:05:57 --> XSS Filtering completed
DEBUG - 2016-09-18 00:05:57 --> XSS Filtering completed
DEBUG - 2016-09-18 00:05:57 --> XSS Filtering completed
DEBUG - 2016-09-18 00:05:57 --> XSS Filtering completed
DEBUG - 2016-09-18 00:05:57 --> XSS Filtering completed
DEBUG - 2016-09-18 00:05:57 --> XSS Filtering completed
DEBUG - 2016-09-18 00:05:57 --> XSS Filtering completed
DEBUG - 2016-09-18 00:05:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 00:05:57 --> Language Class Initialized
DEBUG - 2016-09-18 00:05:57 --> Loader Class Initialized
DEBUG - 2016-09-18 00:05:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 00:05:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 00:05:57 --> Helper loaded: url_helper
DEBUG - 2016-09-18 00:05:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 00:05:57 --> Helper loaded: file_helper
DEBUG - 2016-09-18 00:05:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:05:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 00:05:57 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 00:05:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:05:57 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 00:05:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 00:05:57 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:05:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 00:05:57 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:05:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 00:05:57 --> Helper loaded: form_helper
DEBUG - 2016-09-18 00:05:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 00:05:57 --> Helper loaded: security_helper
DEBUG - 2016-09-18 00:05:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:05:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 00:05:57 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 00:05:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:05:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 00:05:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 00:05:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 00:05:57 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 00:05:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:05:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 00:05:57 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 00:05:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:05:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 00:05:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 00:05:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 00:05:57 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 00:05:57 --> Database Driver Class Initialized
DEBUG - 2016-09-18 00:05:57 --> Session Class Initialized
DEBUG - 2016-09-18 00:05:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 00:05:57 --> Helper loaded: string_helper
DEBUG - 2016-09-18 00:05:57 --> Session routines successfully run
DEBUG - 2016-09-18 00:05:57 --> Native_session Class Initialized
DEBUG - 2016-09-18 00:05:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 00:05:57 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:05:57 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:05:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 00:05:57 --> Controller Class Initialized
DEBUG - 2016-09-18 00:05:57 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 00:05:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 00:05:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 00:05:57 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:05:57 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:05:57 --> User Agent Class Initialized
DEBUG - 2016-09-18 00:05:57 --> Model Class Initialized
DEBUG - 2016-09-18 00:05:57 --> Model Class Initialized
DEBUG - 2016-09-18 00:05:57 --> Model Class Initialized
DEBUG - 2016-09-18 00:05:57 --> Model Class Initialized
DEBUG - 2016-09-18 00:05:57 --> Model Class Initialized
DEBUG - 2016-09-18 00:05:57 --> Model Class Initialized
DEBUG - 2016-09-18 00:05:57 --> Model Class Initialized
DEBUG - 2016-09-18 00:05:57 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-18 00:05:57 --> Final output sent to browser
DEBUG - 2016-09-18 00:05:57 --> Total execution time: 0.6271
DEBUG - 2016-09-18 00:16:34 --> Config Class Initialized
DEBUG - 2016-09-18 00:16:34 --> Hooks Class Initialized
DEBUG - 2016-09-18 00:16:34 --> Utf8 Class Initialized
DEBUG - 2016-09-18 00:16:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 00:16:34 --> URI Class Initialized
DEBUG - 2016-09-18 00:16:34 --> Router Class Initialized
DEBUG - 2016-09-18 00:16:34 --> Output Class Initialized
DEBUG - 2016-09-18 00:16:35 --> Cache file has expired. File deleted
DEBUG - 2016-09-18 00:16:35 --> Security Class Initialized
DEBUG - 2016-09-18 00:16:35 --> Input Class Initialized
DEBUG - 2016-09-18 00:16:35 --> XSS Filtering completed
DEBUG - 2016-09-18 00:16:35 --> XSS Filtering completed
DEBUG - 2016-09-18 00:16:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 00:16:35 --> Language Class Initialized
DEBUG - 2016-09-18 00:16:35 --> Loader Class Initialized
DEBUG - 2016-09-18 00:16:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 00:16:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 00:16:35 --> Helper loaded: url_helper
DEBUG - 2016-09-18 00:16:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 00:16:35 --> Helper loaded: file_helper
DEBUG - 2016-09-18 00:16:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:16:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 00:16:35 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 00:16:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:16:35 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 00:16:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 00:16:35 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:16:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 00:16:35 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:16:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 00:16:35 --> Helper loaded: form_helper
DEBUG - 2016-09-18 00:16:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 00:16:35 --> Helper loaded: security_helper
DEBUG - 2016-09-18 00:16:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:16:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 00:16:35 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 00:16:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:16:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 00:16:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 00:16:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 00:16:35 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 00:16:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:16:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 00:16:35 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 00:16:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:16:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 00:16:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 00:16:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 00:16:35 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 00:16:35 --> Database Driver Class Initialized
DEBUG - 2016-09-18 00:16:35 --> Session Class Initialized
DEBUG - 2016-09-18 00:16:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 00:16:35 --> Helper loaded: string_helper
DEBUG - 2016-09-18 00:16:35 --> Session routines successfully run
DEBUG - 2016-09-18 00:16:35 --> Native_session Class Initialized
DEBUG - 2016-09-18 00:16:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 00:16:35 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:16:35 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:16:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 00:16:35 --> Controller Class Initialized
DEBUG - 2016-09-18 00:16:35 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 00:16:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 00:16:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 00:16:35 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:16:35 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:16:35 --> User Agent Class Initialized
DEBUG - 2016-09-18 00:16:35 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:35 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:35 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-18 00:16:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-18 00:16:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-18 00:16:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 00:16:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-18 00:16:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 00:16:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-18 00:16:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-18 00:16:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-18 00:16:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 00:16:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-18 00:16:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 00:16:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-18 00:16:35 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-09-18 00:16:35 --> Final output sent to browser
DEBUG - 2016-09-18 00:16:35 --> Total execution time: 0.2514
DEBUG - 2016-09-18 00:16:38 --> Config Class Initialized
DEBUG - 2016-09-18 00:16:38 --> Hooks Class Initialized
DEBUG - 2016-09-18 00:16:38 --> Utf8 Class Initialized
DEBUG - 2016-09-18 00:16:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 00:16:38 --> URI Class Initialized
DEBUG - 2016-09-18 00:16:38 --> Router Class Initialized
DEBUG - 2016-09-18 00:16:38 --> Output Class Initialized
DEBUG - 2016-09-18 00:16:38 --> Security Class Initialized
DEBUG - 2016-09-18 00:16:38 --> Input Class Initialized
DEBUG - 2016-09-18 00:16:38 --> XSS Filtering completed
DEBUG - 2016-09-18 00:16:38 --> XSS Filtering completed
DEBUG - 2016-09-18 00:16:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 00:16:38 --> Language Class Initialized
DEBUG - 2016-09-18 00:16:38 --> Loader Class Initialized
DEBUG - 2016-09-18 00:16:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 00:16:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 00:16:38 --> Helper loaded: url_helper
DEBUG - 2016-09-18 00:16:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 00:16:38 --> Helper loaded: file_helper
DEBUG - 2016-09-18 00:16:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:16:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 00:16:38 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 00:16:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:16:38 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 00:16:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 00:16:38 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:16:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 00:16:38 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:16:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 00:16:38 --> Helper loaded: form_helper
DEBUG - 2016-09-18 00:16:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 00:16:38 --> Helper loaded: security_helper
DEBUG - 2016-09-18 00:16:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:16:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 00:16:38 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 00:16:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:16:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 00:16:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 00:16:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 00:16:38 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 00:16:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:16:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 00:16:38 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 00:16:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:16:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 00:16:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 00:16:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 00:16:38 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 00:16:38 --> Database Driver Class Initialized
DEBUG - 2016-09-18 00:16:38 --> Session Class Initialized
DEBUG - 2016-09-18 00:16:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 00:16:38 --> Helper loaded: string_helper
DEBUG - 2016-09-18 00:16:38 --> Session routines successfully run
DEBUG - 2016-09-18 00:16:38 --> Native_session Class Initialized
DEBUG - 2016-09-18 00:16:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 00:16:38 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:16:38 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:16:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 00:16:38 --> Controller Class Initialized
DEBUG - 2016-09-18 00:16:38 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 00:16:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 00:16:38 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 00:16:38 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:16:38 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:16:38 --> User Agent Class Initialized
DEBUG - 2016-09-18 00:16:38 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:38 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:38 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:38 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:38 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:38 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:38 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:38 --> Model Class Initialized
ERROR - 2016-09-18 00:16:38 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-18 00:16:38 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-18 00:16:38 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-09-18 00:16:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-18 00:16:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-18 00:16:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-18 00:16:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-18 00:16:38 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-09-18 00:16:38 --> Final output sent to browser
DEBUG - 2016-09-18 00:16:38 --> Total execution time: 0.2288
DEBUG - 2016-09-18 00:16:38 --> Config Class Initialized
DEBUG - 2016-09-18 00:16:38 --> Hooks Class Initialized
DEBUG - 2016-09-18 00:16:38 --> Utf8 Class Initialized
DEBUG - 2016-09-18 00:16:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 00:16:38 --> URI Class Initialized
DEBUG - 2016-09-18 00:16:38 --> Router Class Initialized
ERROR - 2016-09-18 00:16:38 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-09-18 00:16:47 --> Config Class Initialized
DEBUG - 2016-09-18 00:16:47 --> Hooks Class Initialized
DEBUG - 2016-09-18 00:16:47 --> Utf8 Class Initialized
DEBUG - 2016-09-18 00:16:47 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 00:16:47 --> URI Class Initialized
DEBUG - 2016-09-18 00:16:47 --> Router Class Initialized
DEBUG - 2016-09-18 00:16:47 --> Output Class Initialized
DEBUG - 2016-09-18 00:16:47 --> Cache file has expired. File deleted
DEBUG - 2016-09-18 00:16:47 --> Security Class Initialized
DEBUG - 2016-09-18 00:16:47 --> Input Class Initialized
DEBUG - 2016-09-18 00:16:47 --> XSS Filtering completed
DEBUG - 2016-09-18 00:16:47 --> XSS Filtering completed
DEBUG - 2016-09-18 00:16:47 --> XSS Filtering completed
DEBUG - 2016-09-18 00:16:47 --> XSS Filtering completed
DEBUG - 2016-09-18 00:16:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 00:16:47 --> Language Class Initialized
DEBUG - 2016-09-18 00:16:47 --> Loader Class Initialized
DEBUG - 2016-09-18 00:16:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 00:16:47 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 00:16:47 --> Helper loaded: url_helper
DEBUG - 2016-09-18 00:16:47 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 00:16:47 --> Helper loaded: file_helper
DEBUG - 2016-09-18 00:16:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:16:47 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 00:16:47 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 00:16:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:16:47 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 00:16:47 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 00:16:47 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:16:47 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 00:16:47 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:16:47 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 00:16:47 --> Helper loaded: form_helper
DEBUG - 2016-09-18 00:16:47 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 00:16:47 --> Helper loaded: security_helper
DEBUG - 2016-09-18 00:16:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:16:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 00:16:47 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 00:16:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:16:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 00:16:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 00:16:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 00:16:47 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 00:16:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:16:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 00:16:47 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 00:16:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:16:47 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 00:16:47 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 00:16:47 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 00:16:47 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 00:16:47 --> Database Driver Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Session Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 00:16:48 --> Helper loaded: string_helper
DEBUG - 2016-09-18 00:16:48 --> Session routines successfully run
DEBUG - 2016-09-18 00:16:48 --> Native_session Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 00:16:48 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 00:16:48 --> Controller Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 00:16:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 00:16:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 00:16:48 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:16:48 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:16:48 --> User Agent Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Model Class Initialized
ERROR - 2016-09-18 00:16:48 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-18 00:16:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-18 00:16:48 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 00:16:48 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-18 00:16:48 --> Config Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Hooks Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Utf8 Class Initialized
DEBUG - 2016-09-18 00:16:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 00:16:48 --> URI Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Router Class Initialized
DEBUG - 2016-09-18 00:16:48 --> No URI present. Default controller set.
DEBUG - 2016-09-18 00:16:48 --> Output Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Cache file has expired. File deleted
DEBUG - 2016-09-18 00:16:48 --> Security Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Input Class Initialized
DEBUG - 2016-09-18 00:16:48 --> XSS Filtering completed
DEBUG - 2016-09-18 00:16:48 --> XSS Filtering completed
DEBUG - 2016-09-18 00:16:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 00:16:48 --> Language Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Loader Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 00:16:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 00:16:48 --> Helper loaded: url_helper
DEBUG - 2016-09-18 00:16:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 00:16:48 --> Helper loaded: file_helper
DEBUG - 2016-09-18 00:16:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:16:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 00:16:48 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 00:16:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:16:48 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 00:16:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 00:16:48 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:16:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 00:16:48 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:16:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 00:16:48 --> Helper loaded: form_helper
DEBUG - 2016-09-18 00:16:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 00:16:48 --> Helper loaded: security_helper
DEBUG - 2016-09-18 00:16:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:16:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 00:16:48 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 00:16:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:16:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 00:16:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 00:16:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 00:16:48 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 00:16:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:16:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 00:16:48 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 00:16:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:16:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 00:16:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 00:16:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 00:16:48 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 00:16:48 --> Database Driver Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Session Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 00:16:48 --> Helper loaded: string_helper
DEBUG - 2016-09-18 00:16:48 --> Session routines successfully run
DEBUG - 2016-09-18 00:16:48 --> Native_session Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 00:16:48 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 00:16:48 --> Controller Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 00:16:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 00:16:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 00:16:48 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:16:48 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:16:48 --> User Agent Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Model Class Initialized
ERROR - 2016-09-18 00:16:48 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-18 00:16:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-18 00:16:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-18 00:16:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-18 00:16:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 00:16:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-18 00:16:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-18 00:16:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-18 00:16:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-18 00:16:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-18 00:16:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 00:16:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-18 00:16:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-18 00:16:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 00:16:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-18 00:16:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-18 00:16:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-18 00:16:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-18 00:16:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-18 00:16:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 00:16:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-18 00:16:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-18 00:16:48 --> Final output sent to browser
DEBUG - 2016-09-18 00:16:48 --> Total execution time: 0.2472
DEBUG - 2016-09-18 00:16:48 --> Config Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Hooks Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Utf8 Class Initialized
DEBUG - 2016-09-18 00:16:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 00:16:48 --> URI Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Router Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Output Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Cache file has expired. File deleted
DEBUG - 2016-09-18 00:16:48 --> Security Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Input Class Initialized
DEBUG - 2016-09-18 00:16:48 --> XSS Filtering completed
DEBUG - 2016-09-18 00:16:48 --> XSS Filtering completed
DEBUG - 2016-09-18 00:16:48 --> XSS Filtering completed
DEBUG - 2016-09-18 00:16:48 --> XSS Filtering completed
DEBUG - 2016-09-18 00:16:48 --> XSS Filtering completed
DEBUG - 2016-09-18 00:16:48 --> XSS Filtering completed
DEBUG - 2016-09-18 00:16:48 --> XSS Filtering completed
DEBUG - 2016-09-18 00:16:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 00:16:48 --> Language Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Loader Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 00:16:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 00:16:48 --> Helper loaded: url_helper
DEBUG - 2016-09-18 00:16:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 00:16:48 --> Helper loaded: file_helper
DEBUG - 2016-09-18 00:16:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:16:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 00:16:48 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 00:16:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:16:48 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 00:16:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 00:16:48 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:16:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 00:16:48 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:16:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 00:16:48 --> Helper loaded: form_helper
DEBUG - 2016-09-18 00:16:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 00:16:48 --> Helper loaded: security_helper
DEBUG - 2016-09-18 00:16:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:16:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 00:16:48 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 00:16:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:16:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 00:16:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 00:16:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 00:16:48 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 00:16:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:16:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 00:16:48 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 00:16:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:16:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 00:16:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 00:16:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 00:16:48 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 00:16:48 --> Database Driver Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Session Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 00:16:48 --> Helper loaded: string_helper
DEBUG - 2016-09-18 00:16:48 --> Session routines successfully run
DEBUG - 2016-09-18 00:16:48 --> Native_session Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 00:16:48 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 00:16:48 --> Controller Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 00:16:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 00:16:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 00:16:48 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:16:48 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:16:48 --> User Agent Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-18 00:16:48 --> Final output sent to browser
DEBUG - 2016-09-18 00:16:48 --> Total execution time: 0.3098
DEBUG - 2016-09-18 00:16:52 --> Config Class Initialized
DEBUG - 2016-09-18 00:16:52 --> Hooks Class Initialized
DEBUG - 2016-09-18 00:16:52 --> Utf8 Class Initialized
DEBUG - 2016-09-18 00:16:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 00:16:52 --> URI Class Initialized
DEBUG - 2016-09-18 00:16:52 --> Router Class Initialized
DEBUG - 2016-09-18 00:16:52 --> Output Class Initialized
DEBUG - 2016-09-18 00:16:52 --> Cache file has expired. File deleted
DEBUG - 2016-09-18 00:16:52 --> Security Class Initialized
DEBUG - 2016-09-18 00:16:52 --> Input Class Initialized
DEBUG - 2016-09-18 00:16:52 --> XSS Filtering completed
DEBUG - 2016-09-18 00:16:52 --> XSS Filtering completed
DEBUG - 2016-09-18 00:16:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 00:16:52 --> Language Class Initialized
DEBUG - 2016-09-18 00:16:52 --> Loader Class Initialized
DEBUG - 2016-09-18 00:16:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 00:16:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 00:16:52 --> Helper loaded: url_helper
DEBUG - 2016-09-18 00:16:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 00:16:52 --> Helper loaded: file_helper
DEBUG - 2016-09-18 00:16:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:16:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 00:16:52 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 00:16:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:16:52 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 00:16:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 00:16:52 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:16:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 00:16:52 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:16:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 00:16:52 --> Helper loaded: form_helper
DEBUG - 2016-09-18 00:16:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 00:16:52 --> Helper loaded: security_helper
DEBUG - 2016-09-18 00:16:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:16:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 00:16:52 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 00:16:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:16:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 00:16:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 00:16:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 00:16:52 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 00:16:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:16:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 00:16:52 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 00:16:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:16:52 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 00:16:52 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 00:16:52 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 00:16:52 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 00:16:52 --> Database Driver Class Initialized
DEBUG - 2016-09-18 00:16:52 --> Session Class Initialized
DEBUG - 2016-09-18 00:16:52 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 00:16:52 --> Helper loaded: string_helper
DEBUG - 2016-09-18 00:16:52 --> Session routines successfully run
DEBUG - 2016-09-18 00:16:52 --> Native_session Class Initialized
DEBUG - 2016-09-18 00:16:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 00:16:52 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:16:52 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:16:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 00:16:52 --> Controller Class Initialized
DEBUG - 2016-09-18 00:16:52 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 00:16:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 00:16:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 00:16:52 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:16:52 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:16:52 --> User Agent Class Initialized
DEBUG - 2016-09-18 00:16:52 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:52 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:52 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-18 00:16:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-18 00:16:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-18 00:16:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 00:16:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-18 00:16:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 00:16:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-18 00:16:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-18 00:16:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-18 00:16:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 00:16:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-18 00:16:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 00:16:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-18 00:16:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-09-18 00:16:52 --> Final output sent to browser
DEBUG - 2016-09-18 00:16:52 --> Total execution time: 0.2630
DEBUG - 2016-09-18 00:16:55 --> Config Class Initialized
DEBUG - 2016-09-18 00:16:55 --> Hooks Class Initialized
DEBUG - 2016-09-18 00:16:55 --> Utf8 Class Initialized
DEBUG - 2016-09-18 00:16:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 00:16:55 --> URI Class Initialized
DEBUG - 2016-09-18 00:16:55 --> Router Class Initialized
DEBUG - 2016-09-18 00:16:55 --> Output Class Initialized
DEBUG - 2016-09-18 00:16:55 --> Cache file has expired. File deleted
DEBUG - 2016-09-18 00:16:55 --> Security Class Initialized
DEBUG - 2016-09-18 00:16:55 --> Input Class Initialized
DEBUG - 2016-09-18 00:16:55 --> XSS Filtering completed
DEBUG - 2016-09-18 00:16:55 --> XSS Filtering completed
DEBUG - 2016-09-18 00:16:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 00:16:55 --> Language Class Initialized
DEBUG - 2016-09-18 00:16:55 --> Loader Class Initialized
DEBUG - 2016-09-18 00:16:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 00:16:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 00:16:55 --> Helper loaded: url_helper
DEBUG - 2016-09-18 00:16:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 00:16:55 --> Helper loaded: file_helper
DEBUG - 2016-09-18 00:16:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:16:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 00:16:55 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 00:16:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:16:55 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 00:16:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 00:16:55 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:16:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 00:16:55 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:16:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 00:16:55 --> Helper loaded: form_helper
DEBUG - 2016-09-18 00:16:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 00:16:55 --> Helper loaded: security_helper
DEBUG - 2016-09-18 00:16:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:16:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 00:16:55 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 00:16:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:16:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 00:16:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 00:16:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 00:16:55 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 00:16:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:16:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 00:16:55 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 00:16:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:16:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 00:16:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 00:16:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 00:16:55 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 00:16:55 --> Database Driver Class Initialized
DEBUG - 2016-09-18 00:16:55 --> Session Class Initialized
DEBUG - 2016-09-18 00:16:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 00:16:55 --> Helper loaded: string_helper
DEBUG - 2016-09-18 00:16:55 --> Session routines successfully run
DEBUG - 2016-09-18 00:16:55 --> Native_session Class Initialized
DEBUG - 2016-09-18 00:16:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 00:16:55 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:16:55 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:16:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 00:16:55 --> Controller Class Initialized
DEBUG - 2016-09-18 00:16:55 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 00:16:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 00:16:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 00:16:55 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:16:55 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:16:55 --> User Agent Class Initialized
DEBUG - 2016-09-18 00:16:55 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:55 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:55 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:55 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:55 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:55 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:55 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:55 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:55 --> Model Class Initialized
DEBUG - 2016-09-18 00:16:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-18 00:16:55 --> Pagination Class Initialized
DEBUG - 2016-09-18 00:16:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-18 00:16:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-18 00:16:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-18 00:16:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-18 00:16:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 00:16:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-18 00:16:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-18 00:16:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 00:16:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-18 00:16:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-18 00:16:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-18 00:16:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 00:16:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-18 00:16:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-18 00:16:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 00:16:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-18 00:16:55 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-18 00:16:55 --> Final output sent to browser
DEBUG - 2016-09-18 00:16:55 --> Total execution time: 0.4364
DEBUG - 2016-09-18 00:34:40 --> Config Class Initialized
DEBUG - 2016-09-18 00:34:40 --> Hooks Class Initialized
DEBUG - 2016-09-18 00:34:40 --> Utf8 Class Initialized
DEBUG - 2016-09-18 00:34:40 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 00:34:40 --> URI Class Initialized
DEBUG - 2016-09-18 00:34:40 --> Router Class Initialized
DEBUG - 2016-09-18 00:34:40 --> Output Class Initialized
DEBUG - 2016-09-18 00:34:40 --> Cache file has expired. File deleted
DEBUG - 2016-09-18 00:34:40 --> Security Class Initialized
DEBUG - 2016-09-18 00:34:40 --> Input Class Initialized
DEBUG - 2016-09-18 00:34:40 --> XSS Filtering completed
DEBUG - 2016-09-18 00:34:40 --> XSS Filtering completed
DEBUG - 2016-09-18 00:34:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 00:34:40 --> Language Class Initialized
DEBUG - 2016-09-18 00:34:40 --> Loader Class Initialized
DEBUG - 2016-09-18 00:34:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 00:34:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 00:34:40 --> Helper loaded: url_helper
DEBUG - 2016-09-18 00:34:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 00:34:40 --> Helper loaded: file_helper
DEBUG - 2016-09-18 00:34:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:34:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 00:34:40 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 00:34:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:34:40 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 00:34:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 00:34:40 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:34:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 00:34:40 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:34:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 00:34:40 --> Helper loaded: form_helper
DEBUG - 2016-09-18 00:34:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 00:34:40 --> Helper loaded: security_helper
DEBUG - 2016-09-18 00:34:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:34:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 00:34:40 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 00:34:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:34:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 00:34:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 00:34:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 00:34:40 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 00:34:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:34:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 00:34:40 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 00:34:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:34:40 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 00:34:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 00:34:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 00:34:40 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 00:34:40 --> Database Driver Class Initialized
DEBUG - 2016-09-18 00:34:40 --> Session Class Initialized
DEBUG - 2016-09-18 00:34:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 00:34:40 --> Helper loaded: string_helper
DEBUG - 2016-09-18 00:34:40 --> Session routines successfully run
DEBUG - 2016-09-18 00:34:40 --> Native_session Class Initialized
DEBUG - 2016-09-18 00:34:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 00:34:40 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:34:40 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:34:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 00:34:40 --> Controller Class Initialized
DEBUG - 2016-09-18 00:34:40 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 00:34:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 00:34:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 00:34:40 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:34:40 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:34:40 --> User Agent Class Initialized
DEBUG - 2016-09-18 00:34:40 --> Model Class Initialized
DEBUG - 2016-09-18 00:34:40 --> Model Class Initialized
DEBUG - 2016-09-18 00:34:40 --> Model Class Initialized
DEBUG - 2016-09-18 00:34:40 --> Model Class Initialized
DEBUG - 2016-09-18 00:34:40 --> Model Class Initialized
DEBUG - 2016-09-18 00:34:40 --> Model Class Initialized
DEBUG - 2016-09-18 00:34:40 --> Model Class Initialized
DEBUG - 2016-09-18 00:34:40 --> Model Class Initialized
DEBUG - 2016-09-18 00:34:40 --> Model Class Initialized
DEBUG - 2016-09-18 00:34:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-18 00:34:40 --> Pagination Class Initialized
DEBUG - 2016-09-18 00:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-18 00:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-18 00:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-18 00:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-18 00:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 00:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-18 00:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-18 00:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 00:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-18 00:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-18 00:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-18 00:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 00:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-18 00:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-18 00:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 00:34:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-18 00:34:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-18 00:34:40 --> Final output sent to browser
DEBUG - 2016-09-18 00:34:40 --> Total execution time: 0.3945
DEBUG - 2016-09-18 00:34:43 --> Config Class Initialized
DEBUG - 2016-09-18 00:34:43 --> Hooks Class Initialized
DEBUG - 2016-09-18 00:34:43 --> Utf8 Class Initialized
DEBUG - 2016-09-18 00:34:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 00:34:43 --> URI Class Initialized
DEBUG - 2016-09-18 00:34:43 --> Router Class Initialized
DEBUG - 2016-09-18 00:34:43 --> No URI present. Default controller set.
DEBUG - 2016-09-18 00:34:43 --> Output Class Initialized
DEBUG - 2016-09-18 00:34:43 --> Cache file has expired. File deleted
DEBUG - 2016-09-18 00:34:43 --> Security Class Initialized
DEBUG - 2016-09-18 00:34:43 --> Input Class Initialized
DEBUG - 2016-09-18 00:34:43 --> XSS Filtering completed
DEBUG - 2016-09-18 00:34:43 --> XSS Filtering completed
DEBUG - 2016-09-18 00:34:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 00:34:43 --> Language Class Initialized
DEBUG - 2016-09-18 00:34:43 --> Loader Class Initialized
DEBUG - 2016-09-18 00:34:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 00:34:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 00:34:43 --> Helper loaded: url_helper
DEBUG - 2016-09-18 00:34:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 00:34:43 --> Helper loaded: file_helper
DEBUG - 2016-09-18 00:34:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:34:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 00:34:43 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 00:34:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:34:43 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 00:34:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 00:34:44 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:34:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 00:34:44 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:34:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 00:34:44 --> Helper loaded: form_helper
DEBUG - 2016-09-18 00:34:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 00:34:44 --> Helper loaded: security_helper
DEBUG - 2016-09-18 00:34:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:34:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 00:34:44 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 00:34:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:34:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 00:34:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 00:34:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 00:34:44 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 00:34:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:34:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 00:34:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 00:34:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:34:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 00:34:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 00:34:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 00:34:44 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 00:34:44 --> Database Driver Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Session Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 00:34:44 --> Helper loaded: string_helper
DEBUG - 2016-09-18 00:34:44 --> Session routines successfully run
DEBUG - 2016-09-18 00:34:44 --> Native_session Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 00:34:44 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 00:34:44 --> Controller Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 00:34:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 00:34:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 00:34:44 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:34:44 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:34:44 --> User Agent Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Model Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Model Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Model Class Initialized
ERROR - 2016-09-18 00:34:44 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-18 00:34:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-18 00:34:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-18 00:34:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-18 00:34:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 00:34:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-18 00:34:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-18 00:34:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-18 00:34:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-18 00:34:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-18 00:34:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 00:34:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-18 00:34:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-18 00:34:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 00:34:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-18 00:34:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-18 00:34:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-18 00:34:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-18 00:34:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-18 00:34:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 00:34:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-18 00:34:44 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-18 00:34:44 --> Final output sent to browser
DEBUG - 2016-09-18 00:34:44 --> Total execution time: 0.3340
DEBUG - 2016-09-18 00:34:44 --> Config Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Hooks Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Utf8 Class Initialized
DEBUG - 2016-09-18 00:34:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 00:34:44 --> URI Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Router Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Output Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Cache file has expired. File deleted
DEBUG - 2016-09-18 00:34:44 --> Security Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Input Class Initialized
DEBUG - 2016-09-18 00:34:44 --> XSS Filtering completed
DEBUG - 2016-09-18 00:34:44 --> XSS Filtering completed
DEBUG - 2016-09-18 00:34:44 --> XSS Filtering completed
DEBUG - 2016-09-18 00:34:44 --> XSS Filtering completed
DEBUG - 2016-09-18 00:34:44 --> XSS Filtering completed
DEBUG - 2016-09-18 00:34:44 --> XSS Filtering completed
DEBUG - 2016-09-18 00:34:44 --> XSS Filtering completed
DEBUG - 2016-09-18 00:34:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 00:34:44 --> Language Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Loader Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 00:34:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 00:34:44 --> Helper loaded: url_helper
DEBUG - 2016-09-18 00:34:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 00:34:44 --> Helper loaded: file_helper
DEBUG - 2016-09-18 00:34:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:34:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 00:34:44 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 00:34:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:34:44 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 00:34:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 00:34:44 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:34:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 00:34:44 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:34:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 00:34:44 --> Helper loaded: form_helper
DEBUG - 2016-09-18 00:34:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 00:34:44 --> Helper loaded: security_helper
DEBUG - 2016-09-18 00:34:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:34:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 00:34:44 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 00:34:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:34:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 00:34:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 00:34:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 00:34:44 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 00:34:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:34:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 00:34:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 00:34:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:34:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 00:34:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 00:34:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 00:34:44 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 00:34:44 --> Database Driver Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Session Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 00:34:44 --> Helper loaded: string_helper
DEBUG - 2016-09-18 00:34:44 --> Session routines successfully run
DEBUG - 2016-09-18 00:34:44 --> Native_session Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 00:34:44 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 00:34:44 --> Controller Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 00:34:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 00:34:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 00:34:44 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:34:44 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:34:44 --> User Agent Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Model Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Model Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Model Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Model Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Model Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Model Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Model Class Initialized
DEBUG - 2016-09-18 00:34:44 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-18 00:34:44 --> Final output sent to browser
DEBUG - 2016-09-18 00:34:44 --> Total execution time: 0.4111
DEBUG - 2016-09-18 00:34:48 --> Config Class Initialized
DEBUG - 2016-09-18 00:34:48 --> Hooks Class Initialized
DEBUG - 2016-09-18 00:34:48 --> Utf8 Class Initialized
DEBUG - 2016-09-18 00:34:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 00:34:48 --> URI Class Initialized
DEBUG - 2016-09-18 00:34:48 --> Router Class Initialized
DEBUG - 2016-09-18 00:34:48 --> Output Class Initialized
DEBUG - 2016-09-18 00:34:48 --> Security Class Initialized
DEBUG - 2016-09-18 00:34:48 --> Input Class Initialized
DEBUG - 2016-09-18 00:34:48 --> XSS Filtering completed
DEBUG - 2016-09-18 00:34:48 --> XSS Filtering completed
DEBUG - 2016-09-18 00:34:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 00:34:48 --> Language Class Initialized
DEBUG - 2016-09-18 00:34:48 --> Loader Class Initialized
DEBUG - 2016-09-18 00:34:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 00:34:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 00:34:48 --> Helper loaded: url_helper
DEBUG - 2016-09-18 00:34:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 00:34:48 --> Helper loaded: file_helper
DEBUG - 2016-09-18 00:34:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:34:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 00:34:48 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 00:34:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:34:48 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 00:34:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 00:34:48 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:34:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 00:34:48 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:34:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 00:34:48 --> Helper loaded: form_helper
DEBUG - 2016-09-18 00:34:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 00:34:48 --> Helper loaded: security_helper
DEBUG - 2016-09-18 00:34:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:34:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 00:34:48 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 00:34:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:34:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 00:34:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 00:34:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 00:34:48 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 00:34:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:34:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 00:34:48 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 00:34:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:34:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 00:34:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 00:34:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 00:34:48 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 00:34:48 --> Database Driver Class Initialized
DEBUG - 2016-09-18 00:34:48 --> Session Class Initialized
DEBUG - 2016-09-18 00:34:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 00:34:48 --> Helper loaded: string_helper
DEBUG - 2016-09-18 00:34:48 --> Session routines successfully run
DEBUG - 2016-09-18 00:34:48 --> Native_session Class Initialized
DEBUG - 2016-09-18 00:34:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 00:34:48 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:34:48 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:34:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 00:34:48 --> Controller Class Initialized
DEBUG - 2016-09-18 00:34:48 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 00:34:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 00:34:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 00:34:48 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:34:48 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:34:48 --> User Agent Class Initialized
DEBUG - 2016-09-18 00:34:48 --> Model Class Initialized
DEBUG - 2016-09-18 00:34:48 --> Model Class Initialized
DEBUG - 2016-09-18 00:34:48 --> Model Class Initialized
DEBUG - 2016-09-18 00:34:48 --> Model Class Initialized
DEBUG - 2016-09-18 00:34:48 --> Model Class Initialized
DEBUG - 2016-09-18 00:34:48 --> Model Class Initialized
DEBUG - 2016-09-18 00:34:48 --> Model Class Initialized
ERROR - 2016-09-18 00:34:48 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-18 00:35:37 --> Config Class Initialized
DEBUG - 2016-09-18 00:35:37 --> Hooks Class Initialized
DEBUG - 2016-09-18 00:35:37 --> Utf8 Class Initialized
DEBUG - 2016-09-18 00:35:37 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 00:35:37 --> URI Class Initialized
DEBUG - 2016-09-18 00:35:37 --> Router Class Initialized
DEBUG - 2016-09-18 00:35:37 --> Output Class Initialized
DEBUG - 2016-09-18 00:35:37 --> Security Class Initialized
DEBUG - 2016-09-18 00:35:37 --> Input Class Initialized
DEBUG - 2016-09-18 00:35:37 --> XSS Filtering completed
DEBUG - 2016-09-18 00:35:37 --> XSS Filtering completed
DEBUG - 2016-09-18 00:35:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 00:35:37 --> Language Class Initialized
DEBUG - 2016-09-18 00:35:37 --> Loader Class Initialized
DEBUG - 2016-09-18 00:35:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 00:35:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 00:35:37 --> Helper loaded: url_helper
DEBUG - 2016-09-18 00:35:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 00:35:37 --> Helper loaded: file_helper
DEBUG - 2016-09-18 00:35:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:35:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 00:35:37 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 00:35:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:35:37 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 00:35:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 00:35:37 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:35:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 00:35:37 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:35:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 00:35:37 --> Helper loaded: form_helper
DEBUG - 2016-09-18 00:35:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 00:35:37 --> Helper loaded: security_helper
DEBUG - 2016-09-18 00:35:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:35:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 00:35:37 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 00:35:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:35:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 00:35:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 00:35:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 00:35:37 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 00:35:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:35:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 00:35:37 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 00:35:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:35:37 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 00:35:37 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 00:35:37 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 00:35:37 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 00:35:37 --> Database Driver Class Initialized
DEBUG - 2016-09-18 00:35:37 --> Session Class Initialized
DEBUG - 2016-09-18 00:35:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 00:35:37 --> Helper loaded: string_helper
DEBUG - 2016-09-18 00:35:37 --> Session routines successfully run
DEBUG - 2016-09-18 00:35:37 --> Native_session Class Initialized
DEBUG - 2016-09-18 00:35:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 00:35:37 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:35:37 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:35:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 00:35:37 --> Controller Class Initialized
DEBUG - 2016-09-18 00:35:37 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 00:35:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 00:35:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 00:35:37 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:35:37 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:35:37 --> User Agent Class Initialized
DEBUG - 2016-09-18 00:35:37 --> Model Class Initialized
DEBUG - 2016-09-18 00:35:37 --> Model Class Initialized
DEBUG - 2016-09-18 00:35:37 --> Model Class Initialized
DEBUG - 2016-09-18 00:35:37 --> Model Class Initialized
DEBUG - 2016-09-18 00:35:37 --> Model Class Initialized
DEBUG - 2016-09-18 00:35:37 --> Model Class Initialized
DEBUG - 2016-09-18 00:35:37 --> Model Class Initialized
ERROR - 2016-09-18 00:35:37 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
ERROR - 2016-09-18 00:35:37 --> Severity: Notice  --> Undefined property: Fdaftar_diklat::$model_tr_diklat E:\www\GitHub\2016APSIDIKA\application\controllers\front_end\fdaftar_diklat.php 27
DEBUG - 2016-09-18 00:36:00 --> Config Class Initialized
DEBUG - 2016-09-18 00:36:00 --> Hooks Class Initialized
DEBUG - 2016-09-18 00:36:01 --> Utf8 Class Initialized
DEBUG - 2016-09-18 00:36:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 00:36:01 --> URI Class Initialized
DEBUG - 2016-09-18 00:36:01 --> Router Class Initialized
DEBUG - 2016-09-18 00:36:01 --> Output Class Initialized
DEBUG - 2016-09-18 00:36:01 --> Security Class Initialized
DEBUG - 2016-09-18 00:36:01 --> Input Class Initialized
DEBUG - 2016-09-18 00:36:01 --> XSS Filtering completed
DEBUG - 2016-09-18 00:36:01 --> XSS Filtering completed
DEBUG - 2016-09-18 00:36:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 00:36:01 --> Language Class Initialized
DEBUG - 2016-09-18 00:36:01 --> Loader Class Initialized
DEBUG - 2016-09-18 00:36:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 00:36:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 00:36:01 --> Helper loaded: url_helper
DEBUG - 2016-09-18 00:36:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 00:36:01 --> Helper loaded: file_helper
DEBUG - 2016-09-18 00:36:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:36:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 00:36:01 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 00:36:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:36:01 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 00:36:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 00:36:01 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:36:01 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 00:36:01 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:36:01 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 00:36:01 --> Helper loaded: form_helper
DEBUG - 2016-09-18 00:36:01 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 00:36:01 --> Helper loaded: security_helper
DEBUG - 2016-09-18 00:36:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:36:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 00:36:01 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 00:36:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:36:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 00:36:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 00:36:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 00:36:01 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 00:36:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:36:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 00:36:01 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 00:36:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:36:01 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 00:36:01 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 00:36:01 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 00:36:01 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 00:36:01 --> Database Driver Class Initialized
DEBUG - 2016-09-18 00:36:01 --> Session Class Initialized
DEBUG - 2016-09-18 00:36:01 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 00:36:01 --> Helper loaded: string_helper
DEBUG - 2016-09-18 00:36:01 --> Session routines successfully run
DEBUG - 2016-09-18 00:36:01 --> Native_session Class Initialized
DEBUG - 2016-09-18 00:36:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 00:36:01 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:36:01 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:36:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 00:36:01 --> Controller Class Initialized
DEBUG - 2016-09-18 00:36:01 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 00:36:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 00:36:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 00:36:01 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:36:01 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:36:01 --> User Agent Class Initialized
DEBUG - 2016-09-18 00:36:01 --> Model Class Initialized
DEBUG - 2016-09-18 00:36:01 --> Model Class Initialized
DEBUG - 2016-09-18 00:36:01 --> Model Class Initialized
DEBUG - 2016-09-18 00:36:01 --> Model Class Initialized
DEBUG - 2016-09-18 00:36:01 --> Model Class Initialized
DEBUG - 2016-09-18 00:36:01 --> Model Class Initialized
DEBUG - 2016-09-18 00:36:01 --> Model Class Initialized
DEBUG - 2016-09-18 00:36:01 --> Model Class Initialized
ERROR - 2016-09-18 00:36:01 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-18 00:36:04 --> Config Class Initialized
DEBUG - 2016-09-18 00:36:04 --> Hooks Class Initialized
DEBUG - 2016-09-18 00:36:04 --> Utf8 Class Initialized
DEBUG - 2016-09-18 00:36:04 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 00:36:04 --> URI Class Initialized
DEBUG - 2016-09-18 00:36:04 --> Router Class Initialized
DEBUG - 2016-09-18 00:36:04 --> Output Class Initialized
DEBUG - 2016-09-18 00:36:04 --> Security Class Initialized
DEBUG - 2016-09-18 00:36:04 --> Input Class Initialized
DEBUG - 2016-09-18 00:36:04 --> XSS Filtering completed
DEBUG - 2016-09-18 00:36:04 --> XSS Filtering completed
DEBUG - 2016-09-18 00:36:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 00:36:04 --> Language Class Initialized
DEBUG - 2016-09-18 00:36:04 --> Loader Class Initialized
DEBUG - 2016-09-18 00:36:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 00:36:04 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 00:36:04 --> Helper loaded: url_helper
DEBUG - 2016-09-18 00:36:04 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 00:36:04 --> Helper loaded: file_helper
DEBUG - 2016-09-18 00:36:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:36:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 00:36:04 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 00:36:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 00:36:04 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 00:36:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 00:36:04 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:36:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 00:36:04 --> Helper loaded: common_helper
DEBUG - 2016-09-18 00:36:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 00:36:04 --> Helper loaded: form_helper
DEBUG - 2016-09-18 00:36:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 00:36:04 --> Helper loaded: security_helper
DEBUG - 2016-09-18 00:36:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:36:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 00:36:04 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 00:36:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 00:36:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 00:36:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 00:36:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 00:36:04 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 00:36:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:36:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 00:36:04 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 00:36:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 00:36:04 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 00:36:04 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 00:36:04 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 00:36:04 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 00:36:04 --> Database Driver Class Initialized
DEBUG - 2016-09-18 00:36:04 --> Session Class Initialized
DEBUG - 2016-09-18 00:36:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 00:36:04 --> Helper loaded: string_helper
DEBUG - 2016-09-18 00:36:04 --> Session routines successfully run
DEBUG - 2016-09-18 00:36:04 --> Native_session Class Initialized
DEBUG - 2016-09-18 00:36:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 00:36:04 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:36:04 --> Form Validation Class Initialized
DEBUG - 2016-09-18 00:36:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 00:36:04 --> Controller Class Initialized
DEBUG - 2016-09-18 00:36:04 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 00:36:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 00:36:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 00:36:04 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:36:04 --> Carabiner: library configured.
DEBUG - 2016-09-18 00:36:04 --> User Agent Class Initialized
DEBUG - 2016-09-18 00:36:04 --> Model Class Initialized
DEBUG - 2016-09-18 00:36:04 --> Model Class Initialized
DEBUG - 2016-09-18 00:36:04 --> Model Class Initialized
DEBUG - 2016-09-18 00:36:04 --> Model Class Initialized
DEBUG - 2016-09-18 00:36:04 --> Model Class Initialized
DEBUG - 2016-09-18 00:36:04 --> Model Class Initialized
DEBUG - 2016-09-18 00:36:04 --> Model Class Initialized
DEBUG - 2016-09-18 00:36:04 --> Model Class Initialized
ERROR - 2016-09-18 00:36:04 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-18 02:01:42 --> Config Class Initialized
DEBUG - 2016-09-18 02:01:42 --> Hooks Class Initialized
DEBUG - 2016-09-18 02:01:42 --> Utf8 Class Initialized
DEBUG - 2016-09-18 02:01:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 02:01:42 --> URI Class Initialized
DEBUG - 2016-09-18 02:01:42 --> Router Class Initialized
DEBUG - 2016-09-18 02:01:42 --> Output Class Initialized
DEBUG - 2016-09-18 02:01:42 --> Security Class Initialized
DEBUG - 2016-09-18 02:01:42 --> Input Class Initialized
DEBUG - 2016-09-18 02:01:42 --> XSS Filtering completed
DEBUG - 2016-09-18 02:01:42 --> XSS Filtering completed
DEBUG - 2016-09-18 02:01:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 02:01:42 --> Language Class Initialized
DEBUG - 2016-09-18 02:01:42 --> Loader Class Initialized
DEBUG - 2016-09-18 02:01:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 02:01:42 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 02:01:42 --> Helper loaded: url_helper
DEBUG - 2016-09-18 02:01:42 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 02:01:42 --> Helper loaded: file_helper
DEBUG - 2016-09-18 02:01:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 02:01:42 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 02:01:42 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 02:01:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 02:01:42 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 02:01:42 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 02:01:42 --> Helper loaded: common_helper
DEBUG - 2016-09-18 02:01:42 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 02:01:42 --> Helper loaded: common_helper
DEBUG - 2016-09-18 02:01:42 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 02:01:42 --> Helper loaded: form_helper
DEBUG - 2016-09-18 02:01:42 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 02:01:42 --> Helper loaded: security_helper
DEBUG - 2016-09-18 02:01:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 02:01:42 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 02:01:42 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 02:01:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 02:01:42 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 02:01:42 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 02:01:42 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 02:01:42 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 02:01:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 02:01:42 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 02:01:42 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 02:01:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 02:01:42 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 02:01:42 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 02:01:42 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 02:01:42 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 02:01:42 --> Database Driver Class Initialized
DEBUG - 2016-09-18 02:01:42 --> Session Class Initialized
DEBUG - 2016-09-18 02:01:42 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 02:01:42 --> Helper loaded: string_helper
DEBUG - 2016-09-18 02:01:42 --> Session routines successfully run
DEBUG - 2016-09-18 02:01:42 --> Native_session Class Initialized
DEBUG - 2016-09-18 02:01:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 02:01:42 --> Form Validation Class Initialized
DEBUG - 2016-09-18 02:01:42 --> Form Validation Class Initialized
DEBUG - 2016-09-18 02:01:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 02:01:42 --> Controller Class Initialized
DEBUG - 2016-09-18 02:01:42 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 02:01:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 02:01:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 02:01:42 --> Carabiner: library configured.
DEBUG - 2016-09-18 02:01:42 --> Carabiner: library configured.
DEBUG - 2016-09-18 02:01:42 --> User Agent Class Initialized
DEBUG - 2016-09-18 02:01:42 --> Model Class Initialized
DEBUG - 2016-09-18 02:01:42 --> Model Class Initialized
DEBUG - 2016-09-18 02:01:42 --> Model Class Initialized
DEBUG - 2016-09-18 02:01:42 --> Model Class Initialized
DEBUG - 2016-09-18 02:01:42 --> Model Class Initialized
DEBUG - 2016-09-18 02:01:42 --> Model Class Initialized
DEBUG - 2016-09-18 02:01:42 --> Model Class Initialized
DEBUG - 2016-09-18 02:01:42 --> Model Class Initialized
ERROR - 2016-09-18 02:01:42 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-18 02:02:52 --> Config Class Initialized
DEBUG - 2016-09-18 02:02:52 --> Hooks Class Initialized
DEBUG - 2016-09-18 02:02:52 --> Utf8 Class Initialized
DEBUG - 2016-09-18 02:02:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 02:02:52 --> URI Class Initialized
DEBUG - 2016-09-18 02:02:52 --> Router Class Initialized
DEBUG - 2016-09-18 02:02:52 --> Output Class Initialized
DEBUG - 2016-09-18 02:02:52 --> Security Class Initialized
DEBUG - 2016-09-18 02:02:52 --> Input Class Initialized
DEBUG - 2016-09-18 02:02:52 --> XSS Filtering completed
DEBUG - 2016-09-18 02:02:52 --> XSS Filtering completed
DEBUG - 2016-09-18 02:02:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 02:02:52 --> Language Class Initialized
DEBUG - 2016-09-18 02:02:52 --> Loader Class Initialized
DEBUG - 2016-09-18 02:02:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 02:02:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 02:02:52 --> Helper loaded: url_helper
DEBUG - 2016-09-18 02:02:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 02:02:52 --> Helper loaded: file_helper
DEBUG - 2016-09-18 02:02:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 02:02:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 02:02:52 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 02:02:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 02:02:52 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 02:02:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 02:02:52 --> Helper loaded: common_helper
DEBUG - 2016-09-18 02:02:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 02:02:52 --> Helper loaded: common_helper
DEBUG - 2016-09-18 02:02:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 02:02:52 --> Helper loaded: form_helper
DEBUG - 2016-09-18 02:02:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 02:02:52 --> Helper loaded: security_helper
DEBUG - 2016-09-18 02:02:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 02:02:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 02:02:52 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 02:02:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 02:02:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 02:02:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 02:02:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 02:02:52 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 02:02:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 02:02:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 02:02:52 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 02:02:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 02:02:52 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 02:02:52 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 02:02:52 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 02:02:52 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 02:02:52 --> Database Driver Class Initialized
DEBUG - 2016-09-18 02:02:52 --> Session Class Initialized
DEBUG - 2016-09-18 02:02:52 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 02:02:52 --> Helper loaded: string_helper
DEBUG - 2016-09-18 02:02:52 --> Session routines successfully run
DEBUG - 2016-09-18 02:02:52 --> Native_session Class Initialized
DEBUG - 2016-09-18 02:02:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 02:02:52 --> Form Validation Class Initialized
DEBUG - 2016-09-18 02:02:52 --> Form Validation Class Initialized
DEBUG - 2016-09-18 02:02:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 02:02:52 --> Controller Class Initialized
DEBUG - 2016-09-18 02:02:52 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 02:02:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 02:02:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 02:02:52 --> Carabiner: library configured.
DEBUG - 2016-09-18 02:02:52 --> Carabiner: library configured.
DEBUG - 2016-09-18 02:02:52 --> User Agent Class Initialized
DEBUG - 2016-09-18 02:02:52 --> Model Class Initialized
DEBUG - 2016-09-18 02:02:52 --> Model Class Initialized
DEBUG - 2016-09-18 02:02:52 --> Model Class Initialized
DEBUG - 2016-09-18 02:02:52 --> Model Class Initialized
DEBUG - 2016-09-18 02:02:52 --> Model Class Initialized
DEBUG - 2016-09-18 02:02:52 --> Model Class Initialized
DEBUG - 2016-09-18 02:02:52 --> Model Class Initialized
DEBUG - 2016-09-18 02:02:52 --> Model Class Initialized
ERROR - 2016-09-18 02:02:52 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-18 02:02:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-18 02:02:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-18 02:02:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 02:02:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-18 02:02:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-18 02:02:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-18 02:02:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 02:02:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-18 02:02:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-18 02:02:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 02:02:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-18 02:02:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-18 02:02:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-18 02:02:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 02:02:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-18 02:02:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/73f5e075ee35be5f6c1c98a57562112a
DEBUG - 2016-09-18 02:02:52 --> Final output sent to browser
DEBUG - 2016-09-18 02:02:52 --> Total execution time: 0.5975
DEBUG - 2016-09-18 02:03:25 --> Config Class Initialized
DEBUG - 2016-09-18 02:03:25 --> Hooks Class Initialized
DEBUG - 2016-09-18 02:03:25 --> Utf8 Class Initialized
DEBUG - 2016-09-18 02:03:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 02:03:25 --> URI Class Initialized
DEBUG - 2016-09-18 02:03:25 --> Router Class Initialized
DEBUG - 2016-09-18 02:03:25 --> Output Class Initialized
DEBUG - 2016-09-18 02:03:25 --> Cache file has expired. File deleted
DEBUG - 2016-09-18 02:03:25 --> Security Class Initialized
DEBUG - 2016-09-18 02:03:25 --> Input Class Initialized
DEBUG - 2016-09-18 02:03:25 --> XSS Filtering completed
DEBUG - 2016-09-18 02:03:25 --> XSS Filtering completed
DEBUG - 2016-09-18 02:03:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 02:03:25 --> Language Class Initialized
DEBUG - 2016-09-18 02:03:25 --> Loader Class Initialized
DEBUG - 2016-09-18 02:03:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 02:03:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 02:03:25 --> Helper loaded: url_helper
DEBUG - 2016-09-18 02:03:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 02:03:25 --> Helper loaded: file_helper
DEBUG - 2016-09-18 02:03:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 02:03:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 02:03:25 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 02:03:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 02:03:25 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 02:03:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 02:03:25 --> Helper loaded: common_helper
DEBUG - 2016-09-18 02:03:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 02:03:25 --> Helper loaded: common_helper
DEBUG - 2016-09-18 02:03:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 02:03:25 --> Helper loaded: form_helper
DEBUG - 2016-09-18 02:03:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 02:03:25 --> Helper loaded: security_helper
DEBUG - 2016-09-18 02:03:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 02:03:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 02:03:25 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 02:03:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 02:03:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 02:03:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 02:03:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 02:03:25 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 02:03:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 02:03:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 02:03:25 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 02:03:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 02:03:25 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 02:03:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 02:03:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 02:03:25 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 02:03:25 --> Database Driver Class Initialized
DEBUG - 2016-09-18 02:03:25 --> Session Class Initialized
DEBUG - 2016-09-18 02:03:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 02:03:25 --> Helper loaded: string_helper
DEBUG - 2016-09-18 02:03:25 --> Session routines successfully run
DEBUG - 2016-09-18 02:03:25 --> Native_session Class Initialized
DEBUG - 2016-09-18 02:03:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 02:03:25 --> Form Validation Class Initialized
DEBUG - 2016-09-18 02:03:25 --> Form Validation Class Initialized
DEBUG - 2016-09-18 02:03:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 02:03:25 --> Controller Class Initialized
DEBUG - 2016-09-18 02:03:25 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 02:03:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 02:03:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 02:03:25 --> Carabiner: library configured.
DEBUG - 2016-09-18 02:03:25 --> Carabiner: library configured.
DEBUG - 2016-09-18 02:03:26 --> User Agent Class Initialized
DEBUG - 2016-09-18 02:03:26 --> Model Class Initialized
DEBUG - 2016-09-18 02:03:26 --> Model Class Initialized
DEBUG - 2016-09-18 02:03:26 --> Model Class Initialized
DEBUG - 2016-09-18 02:03:26 --> Model Class Initialized
DEBUG - 2016-09-18 02:03:26 --> Model Class Initialized
DEBUG - 2016-09-18 02:03:26 --> Model Class Initialized
DEBUG - 2016-09-18 02:03:26 --> Model Class Initialized
DEBUG - 2016-09-18 02:03:26 --> Model Class Initialized
ERROR - 2016-09-18 02:03:26 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-18 02:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-18 02:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-18 02:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 02:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-18 02:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-18 02:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-18 02:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 02:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-18 02:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-18 02:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 02:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-18 02:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-18 02:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-18 02:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 02:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-18 02:03:26 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/73f5e075ee35be5f6c1c98a57562112a
DEBUG - 2016-09-18 02:03:26 --> Final output sent to browser
DEBUG - 2016-09-18 02:03:26 --> Total execution time: 0.6630
DEBUG - 2016-09-18 02:04:35 --> Config Class Initialized
DEBUG - 2016-09-18 02:04:35 --> Hooks Class Initialized
DEBUG - 2016-09-18 02:04:35 --> Utf8 Class Initialized
DEBUG - 2016-09-18 02:04:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 02:04:35 --> URI Class Initialized
DEBUG - 2016-09-18 02:04:35 --> Router Class Initialized
DEBUG - 2016-09-18 02:04:35 --> Output Class Initialized
DEBUG - 2016-09-18 02:04:35 --> Cache file has expired. File deleted
DEBUG - 2016-09-18 02:04:36 --> Security Class Initialized
DEBUG - 2016-09-18 02:04:36 --> Input Class Initialized
DEBUG - 2016-09-18 02:04:36 --> XSS Filtering completed
DEBUG - 2016-09-18 02:04:36 --> XSS Filtering completed
DEBUG - 2016-09-18 02:04:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 02:04:36 --> Language Class Initialized
DEBUG - 2016-09-18 02:04:36 --> Loader Class Initialized
DEBUG - 2016-09-18 02:04:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 02:04:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 02:04:36 --> Helper loaded: url_helper
DEBUG - 2016-09-18 02:04:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 02:04:36 --> Helper loaded: file_helper
DEBUG - 2016-09-18 02:04:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 02:04:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 02:04:36 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 02:04:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 02:04:36 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 02:04:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 02:04:36 --> Helper loaded: common_helper
DEBUG - 2016-09-18 02:04:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 02:04:36 --> Helper loaded: common_helper
DEBUG - 2016-09-18 02:04:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 02:04:36 --> Helper loaded: form_helper
DEBUG - 2016-09-18 02:04:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 02:04:36 --> Helper loaded: security_helper
DEBUG - 2016-09-18 02:04:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 02:04:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 02:04:36 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 02:04:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 02:04:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 02:04:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 02:04:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 02:04:36 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 02:04:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 02:04:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 02:04:36 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 02:04:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 02:04:36 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 02:04:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 02:04:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 02:04:36 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 02:04:36 --> Database Driver Class Initialized
DEBUG - 2016-09-18 02:04:36 --> Session Class Initialized
DEBUG - 2016-09-18 02:04:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 02:04:36 --> Helper loaded: string_helper
DEBUG - 2016-09-18 02:04:36 --> Session routines successfully run
DEBUG - 2016-09-18 02:04:36 --> Native_session Class Initialized
DEBUG - 2016-09-18 02:04:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 02:04:36 --> Form Validation Class Initialized
DEBUG - 2016-09-18 02:04:36 --> Form Validation Class Initialized
DEBUG - 2016-09-18 02:04:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 02:04:36 --> Controller Class Initialized
DEBUG - 2016-09-18 02:04:36 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 02:04:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 02:04:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 02:04:36 --> Carabiner: library configured.
DEBUG - 2016-09-18 02:04:36 --> Carabiner: library configured.
DEBUG - 2016-09-18 02:04:36 --> User Agent Class Initialized
DEBUG - 2016-09-18 02:04:36 --> Model Class Initialized
DEBUG - 2016-09-18 02:04:36 --> Model Class Initialized
DEBUG - 2016-09-18 02:04:36 --> Model Class Initialized
DEBUG - 2016-09-18 02:04:36 --> Model Class Initialized
DEBUG - 2016-09-18 02:04:36 --> Model Class Initialized
DEBUG - 2016-09-18 02:04:36 --> Model Class Initialized
DEBUG - 2016-09-18 02:04:36 --> Model Class Initialized
DEBUG - 2016-09-18 02:04:36 --> Model Class Initialized
ERROR - 2016-09-18 02:04:36 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-18 02:04:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-18 02:04:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-18 02:04:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 02:04:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-18 02:04:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-18 02:04:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-18 02:04:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 02:04:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-18 02:04:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-18 02:04:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 02:04:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-18 02:04:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-18 02:04:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-18 02:04:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 02:04:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-18 02:04:36 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/73f5e075ee35be5f6c1c98a57562112a
DEBUG - 2016-09-18 02:04:36 --> Final output sent to browser
DEBUG - 2016-09-18 02:04:36 --> Total execution time: 0.6568
DEBUG - 2016-09-18 02:05:05 --> Config Class Initialized
DEBUG - 2016-09-18 02:05:05 --> Hooks Class Initialized
DEBUG - 2016-09-18 02:05:05 --> Utf8 Class Initialized
DEBUG - 2016-09-18 02:05:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 02:05:05 --> URI Class Initialized
DEBUG - 2016-09-18 02:05:05 --> Router Class Initialized
DEBUG - 2016-09-18 02:05:05 --> Output Class Initialized
DEBUG - 2016-09-18 02:05:05 --> Cache file has expired. File deleted
DEBUG - 2016-09-18 02:05:05 --> Security Class Initialized
DEBUG - 2016-09-18 02:05:05 --> Input Class Initialized
DEBUG - 2016-09-18 02:05:05 --> XSS Filtering completed
DEBUG - 2016-09-18 02:05:05 --> XSS Filtering completed
DEBUG - 2016-09-18 02:05:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 02:05:05 --> Language Class Initialized
DEBUG - 2016-09-18 02:05:05 --> Loader Class Initialized
DEBUG - 2016-09-18 02:05:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 02:05:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 02:05:05 --> Helper loaded: url_helper
DEBUG - 2016-09-18 02:05:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 02:05:05 --> Helper loaded: file_helper
DEBUG - 2016-09-18 02:05:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 02:05:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 02:05:05 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 02:05:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 02:05:05 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 02:05:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 02:05:05 --> Helper loaded: common_helper
DEBUG - 2016-09-18 02:05:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 02:05:05 --> Helper loaded: common_helper
DEBUG - 2016-09-18 02:05:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 02:05:05 --> Helper loaded: form_helper
DEBUG - 2016-09-18 02:05:05 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 02:05:05 --> Helper loaded: security_helper
DEBUG - 2016-09-18 02:05:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 02:05:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 02:05:05 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 02:05:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 02:05:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 02:05:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 02:05:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 02:05:05 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 02:05:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 02:05:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 02:05:06 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 02:05:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 02:05:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 02:05:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 02:05:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 02:05:06 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 02:05:06 --> Database Driver Class Initialized
DEBUG - 2016-09-18 02:05:06 --> Session Class Initialized
DEBUG - 2016-09-18 02:05:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 02:05:06 --> Helper loaded: string_helper
DEBUG - 2016-09-18 02:05:06 --> Session routines successfully run
DEBUG - 2016-09-18 02:05:06 --> Native_session Class Initialized
DEBUG - 2016-09-18 02:05:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 02:05:06 --> Form Validation Class Initialized
DEBUG - 2016-09-18 02:05:06 --> Form Validation Class Initialized
DEBUG - 2016-09-18 02:05:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 02:05:06 --> Controller Class Initialized
DEBUG - 2016-09-18 02:05:06 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 02:05:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 02:05:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 02:05:06 --> Carabiner: library configured.
DEBUG - 2016-09-18 02:05:06 --> Carabiner: library configured.
DEBUG - 2016-09-18 02:05:06 --> User Agent Class Initialized
DEBUG - 2016-09-18 02:05:06 --> Model Class Initialized
DEBUG - 2016-09-18 02:05:06 --> Model Class Initialized
DEBUG - 2016-09-18 02:05:06 --> Model Class Initialized
DEBUG - 2016-09-18 02:05:06 --> Model Class Initialized
DEBUG - 2016-09-18 02:05:06 --> Model Class Initialized
DEBUG - 2016-09-18 02:05:06 --> Model Class Initialized
DEBUG - 2016-09-18 02:05:06 --> Model Class Initialized
DEBUG - 2016-09-18 02:05:06 --> Model Class Initialized
ERROR - 2016-09-18 02:05:06 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-18 02:05:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-18 02:05:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-18 02:05:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 02:05:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-18 02:05:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-18 02:05:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-18 02:05:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 02:05:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-18 02:05:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-18 02:05:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 02:05:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-18 02:05:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-18 02:05:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-18 02:05:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 02:05:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-18 02:05:06 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/73f5e075ee35be5f6c1c98a57562112a
DEBUG - 2016-09-18 02:05:06 --> Final output sent to browser
DEBUG - 2016-09-18 02:05:06 --> Total execution time: 0.6592
DEBUG - 2016-09-18 02:06:35 --> Config Class Initialized
DEBUG - 2016-09-18 02:06:35 --> Hooks Class Initialized
DEBUG - 2016-09-18 02:06:35 --> Utf8 Class Initialized
DEBUG - 2016-09-18 02:06:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 02:06:35 --> URI Class Initialized
DEBUG - 2016-09-18 02:06:35 --> Router Class Initialized
DEBUG - 2016-09-18 02:06:35 --> Output Class Initialized
DEBUG - 2016-09-18 02:06:35 --> Cache file has expired. File deleted
DEBUG - 2016-09-18 02:06:35 --> Security Class Initialized
DEBUG - 2016-09-18 02:06:35 --> Input Class Initialized
DEBUG - 2016-09-18 02:06:35 --> XSS Filtering completed
DEBUG - 2016-09-18 02:06:35 --> XSS Filtering completed
DEBUG - 2016-09-18 02:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 02:06:35 --> Language Class Initialized
DEBUG - 2016-09-18 02:06:35 --> Loader Class Initialized
DEBUG - 2016-09-18 02:06:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 02:06:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 02:06:35 --> Helper loaded: url_helper
DEBUG - 2016-09-18 02:06:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 02:06:35 --> Helper loaded: file_helper
DEBUG - 2016-09-18 02:06:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 02:06:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 02:06:35 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 02:06:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 02:06:35 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 02:06:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 02:06:35 --> Helper loaded: common_helper
DEBUG - 2016-09-18 02:06:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 02:06:35 --> Helper loaded: common_helper
DEBUG - 2016-09-18 02:06:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 02:06:35 --> Helper loaded: form_helper
DEBUG - 2016-09-18 02:06:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 02:06:35 --> Helper loaded: security_helper
DEBUG - 2016-09-18 02:06:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 02:06:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 02:06:35 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 02:06:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 02:06:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 02:06:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 02:06:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 02:06:35 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 02:06:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 02:06:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 02:06:35 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 02:06:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 02:06:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 02:06:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 02:06:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 02:06:35 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 02:06:35 --> Database Driver Class Initialized
DEBUG - 2016-09-18 02:06:35 --> Session Class Initialized
DEBUG - 2016-09-18 02:06:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 02:06:35 --> Helper loaded: string_helper
DEBUG - 2016-09-18 02:06:35 --> Session routines successfully run
DEBUG - 2016-09-18 02:06:35 --> Native_session Class Initialized
DEBUG - 2016-09-18 02:06:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 02:06:36 --> Form Validation Class Initialized
DEBUG - 2016-09-18 02:06:36 --> Form Validation Class Initialized
DEBUG - 2016-09-18 02:06:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 02:06:36 --> Controller Class Initialized
DEBUG - 2016-09-18 02:06:36 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 02:06:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 02:06:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 02:06:36 --> Carabiner: library configured.
DEBUG - 2016-09-18 02:06:36 --> Carabiner: library configured.
DEBUG - 2016-09-18 02:06:36 --> User Agent Class Initialized
DEBUG - 2016-09-18 02:06:36 --> Model Class Initialized
DEBUG - 2016-09-18 02:06:36 --> Model Class Initialized
DEBUG - 2016-09-18 02:06:36 --> Model Class Initialized
DEBUG - 2016-09-18 02:06:36 --> Model Class Initialized
DEBUG - 2016-09-18 02:06:36 --> Model Class Initialized
DEBUG - 2016-09-18 02:06:36 --> Model Class Initialized
DEBUG - 2016-09-18 02:06:36 --> Model Class Initialized
DEBUG - 2016-09-18 02:06:36 --> Model Class Initialized
ERROR - 2016-09-18 02:06:36 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-18 02:06:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-18 02:06:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-18 02:06:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 02:06:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-18 02:06:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-18 02:06:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-18 02:06:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 02:06:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-18 02:06:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-18 02:06:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 02:06:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-18 02:06:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-18 02:06:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-18 02:06:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 02:06:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-18 02:06:36 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/73f5e075ee35be5f6c1c98a57562112a
DEBUG - 2016-09-18 02:06:36 --> Final output sent to browser
DEBUG - 2016-09-18 02:06:36 --> Total execution time: 0.7156
DEBUG - 2016-09-18 02:07:05 --> Config Class Initialized
DEBUG - 2016-09-18 02:07:05 --> Hooks Class Initialized
DEBUG - 2016-09-18 02:07:05 --> Utf8 Class Initialized
DEBUG - 2016-09-18 02:07:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 02:07:05 --> URI Class Initialized
DEBUG - 2016-09-18 02:07:05 --> Router Class Initialized
DEBUG - 2016-09-18 02:07:05 --> Output Class Initialized
DEBUG - 2016-09-18 02:07:05 --> Cache file has expired. File deleted
DEBUG - 2016-09-18 02:07:05 --> Security Class Initialized
DEBUG - 2016-09-18 02:07:05 --> Input Class Initialized
DEBUG - 2016-09-18 02:07:05 --> XSS Filtering completed
DEBUG - 2016-09-18 02:07:05 --> XSS Filtering completed
DEBUG - 2016-09-18 02:07:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 02:07:05 --> Language Class Initialized
DEBUG - 2016-09-18 02:07:05 --> Loader Class Initialized
DEBUG - 2016-09-18 02:07:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 02:07:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 02:07:05 --> Helper loaded: url_helper
DEBUG - 2016-09-18 02:07:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 02:07:05 --> Helper loaded: file_helper
DEBUG - 2016-09-18 02:07:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 02:07:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 02:07:05 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 02:07:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 02:07:05 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 02:07:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 02:07:05 --> Helper loaded: common_helper
DEBUG - 2016-09-18 02:07:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 02:07:05 --> Helper loaded: common_helper
DEBUG - 2016-09-18 02:07:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 02:07:05 --> Helper loaded: form_helper
DEBUG - 2016-09-18 02:07:05 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 02:07:05 --> Helper loaded: security_helper
DEBUG - 2016-09-18 02:07:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 02:07:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 02:07:05 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 02:07:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 02:07:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 02:07:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 02:07:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 02:07:05 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 02:07:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 02:07:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 02:07:05 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 02:07:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 02:07:05 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 02:07:05 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 02:07:05 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 02:07:05 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 02:07:05 --> Database Driver Class Initialized
DEBUG - 2016-09-18 02:07:05 --> Session Class Initialized
DEBUG - 2016-09-18 02:07:05 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 02:07:05 --> Helper loaded: string_helper
DEBUG - 2016-09-18 02:07:05 --> Session routines successfully run
DEBUG - 2016-09-18 02:07:05 --> Native_session Class Initialized
DEBUG - 2016-09-18 02:07:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 02:07:05 --> Form Validation Class Initialized
DEBUG - 2016-09-18 02:07:05 --> Form Validation Class Initialized
DEBUG - 2016-09-18 02:07:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 02:07:05 --> Controller Class Initialized
DEBUG - 2016-09-18 02:07:05 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 02:07:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 02:07:05 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 02:07:05 --> Carabiner: library configured.
DEBUG - 2016-09-18 02:07:05 --> Carabiner: library configured.
DEBUG - 2016-09-18 02:07:05 --> User Agent Class Initialized
DEBUG - 2016-09-18 02:07:05 --> Model Class Initialized
DEBUG - 2016-09-18 02:07:05 --> Model Class Initialized
DEBUG - 2016-09-18 02:07:05 --> Model Class Initialized
DEBUG - 2016-09-18 02:07:05 --> Model Class Initialized
DEBUG - 2016-09-18 02:07:05 --> Model Class Initialized
DEBUG - 2016-09-18 02:07:05 --> Model Class Initialized
DEBUG - 2016-09-18 02:07:06 --> Model Class Initialized
DEBUG - 2016-09-18 02:07:06 --> Model Class Initialized
ERROR - 2016-09-18 02:07:06 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-18 02:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-18 02:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-18 02:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 02:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-18 02:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-18 02:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-18 02:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 02:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-18 02:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-18 02:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 02:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-18 02:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-18 02:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-18 02:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 02:07:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-18 02:07:06 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/73f5e075ee35be5f6c1c98a57562112a
DEBUG - 2016-09-18 02:07:06 --> Final output sent to browser
DEBUG - 2016-09-18 02:07:06 --> Total execution time: 0.7354
DEBUG - 2016-09-18 02:07:43 --> Config Class Initialized
DEBUG - 2016-09-18 02:07:43 --> Hooks Class Initialized
DEBUG - 2016-09-18 02:07:43 --> Utf8 Class Initialized
DEBUG - 2016-09-18 02:07:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 02:07:43 --> URI Class Initialized
DEBUG - 2016-09-18 02:07:43 --> Router Class Initialized
DEBUG - 2016-09-18 02:07:43 --> Output Class Initialized
DEBUG - 2016-09-18 02:07:43 --> Cache file has expired. File deleted
DEBUG - 2016-09-18 02:07:43 --> Security Class Initialized
DEBUG - 2016-09-18 02:07:43 --> Input Class Initialized
DEBUG - 2016-09-18 02:07:43 --> XSS Filtering completed
DEBUG - 2016-09-18 02:07:43 --> XSS Filtering completed
DEBUG - 2016-09-18 02:07:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 02:07:43 --> Language Class Initialized
DEBUG - 2016-09-18 02:07:43 --> Loader Class Initialized
DEBUG - 2016-09-18 02:07:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 02:07:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 02:07:43 --> Helper loaded: url_helper
DEBUG - 2016-09-18 02:07:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 02:07:43 --> Helper loaded: file_helper
DEBUG - 2016-09-18 02:07:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 02:07:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 02:07:44 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 02:07:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 02:07:44 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 02:07:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 02:07:44 --> Helper loaded: common_helper
DEBUG - 2016-09-18 02:07:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 02:07:44 --> Helper loaded: common_helper
DEBUG - 2016-09-18 02:07:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 02:07:44 --> Helper loaded: form_helper
DEBUG - 2016-09-18 02:07:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 02:07:44 --> Helper loaded: security_helper
DEBUG - 2016-09-18 02:07:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 02:07:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 02:07:44 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 02:07:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 02:07:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 02:07:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 02:07:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 02:07:44 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 02:07:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 02:07:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 02:07:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 02:07:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 02:07:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 02:07:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 02:07:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 02:07:44 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 02:07:44 --> Database Driver Class Initialized
DEBUG - 2016-09-18 02:07:44 --> Session Class Initialized
DEBUG - 2016-09-18 02:07:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 02:07:44 --> Helper loaded: string_helper
DEBUG - 2016-09-18 02:07:44 --> Session routines successfully run
DEBUG - 2016-09-18 02:07:44 --> Native_session Class Initialized
DEBUG - 2016-09-18 02:07:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 02:07:44 --> Form Validation Class Initialized
DEBUG - 2016-09-18 02:07:44 --> Form Validation Class Initialized
DEBUG - 2016-09-18 02:07:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 02:07:44 --> Controller Class Initialized
DEBUG - 2016-09-18 02:07:44 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 02:07:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 02:07:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 02:07:44 --> Carabiner: library configured.
DEBUG - 2016-09-18 02:07:44 --> Carabiner: library configured.
DEBUG - 2016-09-18 02:07:44 --> User Agent Class Initialized
DEBUG - 2016-09-18 02:07:44 --> Model Class Initialized
DEBUG - 2016-09-18 02:07:44 --> Model Class Initialized
DEBUG - 2016-09-18 02:07:44 --> Model Class Initialized
DEBUG - 2016-09-18 02:07:44 --> Model Class Initialized
DEBUG - 2016-09-18 02:07:44 --> Model Class Initialized
DEBUG - 2016-09-18 02:07:44 --> Model Class Initialized
DEBUG - 2016-09-18 02:07:44 --> Model Class Initialized
DEBUG - 2016-09-18 02:07:44 --> Model Class Initialized
ERROR - 2016-09-18 02:07:44 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-18 02:07:46 --> Config Class Initialized
DEBUG - 2016-09-18 02:07:46 --> Hooks Class Initialized
DEBUG - 2016-09-18 02:07:46 --> Utf8 Class Initialized
DEBUG - 2016-09-18 02:07:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 02:07:46 --> URI Class Initialized
DEBUG - 2016-09-18 02:07:46 --> Router Class Initialized
DEBUG - 2016-09-18 02:07:46 --> Output Class Initialized
DEBUG - 2016-09-18 02:07:46 --> Security Class Initialized
DEBUG - 2016-09-18 02:07:46 --> Input Class Initialized
DEBUG - 2016-09-18 02:07:46 --> XSS Filtering completed
DEBUG - 2016-09-18 02:07:46 --> XSS Filtering completed
DEBUG - 2016-09-18 02:07:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 02:07:46 --> Language Class Initialized
DEBUG - 2016-09-18 02:07:46 --> Loader Class Initialized
DEBUG - 2016-09-18 02:07:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 02:07:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 02:07:46 --> Helper loaded: url_helper
DEBUG - 2016-09-18 02:07:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 02:07:46 --> Helper loaded: file_helper
DEBUG - 2016-09-18 02:07:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 02:07:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 02:07:46 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 02:07:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 02:07:46 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 02:07:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 02:07:46 --> Helper loaded: common_helper
DEBUG - 2016-09-18 02:07:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 02:07:46 --> Helper loaded: common_helper
DEBUG - 2016-09-18 02:07:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 02:07:46 --> Helper loaded: form_helper
DEBUG - 2016-09-18 02:07:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 02:07:46 --> Helper loaded: security_helper
DEBUG - 2016-09-18 02:07:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 02:07:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 02:07:46 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 02:07:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 02:07:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 02:07:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 02:07:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 02:07:46 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 02:07:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 02:07:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 02:07:46 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 02:07:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 02:07:46 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 02:07:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 02:07:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 02:07:46 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 02:07:46 --> Database Driver Class Initialized
DEBUG - 2016-09-18 02:07:46 --> Session Class Initialized
DEBUG - 2016-09-18 02:07:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 02:07:46 --> Helper loaded: string_helper
DEBUG - 2016-09-18 02:07:46 --> Session routines successfully run
DEBUG - 2016-09-18 02:07:46 --> Native_session Class Initialized
DEBUG - 2016-09-18 02:07:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 02:07:46 --> Form Validation Class Initialized
DEBUG - 2016-09-18 02:07:46 --> Form Validation Class Initialized
DEBUG - 2016-09-18 02:07:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 02:07:46 --> Controller Class Initialized
DEBUG - 2016-09-18 02:07:46 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 02:07:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 02:07:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 02:07:46 --> Carabiner: library configured.
DEBUG - 2016-09-18 02:07:46 --> Carabiner: library configured.
DEBUG - 2016-09-18 02:07:46 --> User Agent Class Initialized
DEBUG - 2016-09-18 02:07:46 --> Model Class Initialized
DEBUG - 2016-09-18 02:07:46 --> Model Class Initialized
DEBUG - 2016-09-18 02:07:46 --> Model Class Initialized
DEBUG - 2016-09-18 02:07:46 --> Model Class Initialized
DEBUG - 2016-09-18 02:07:46 --> Model Class Initialized
DEBUG - 2016-09-18 02:07:46 --> Model Class Initialized
DEBUG - 2016-09-18 02:07:46 --> Model Class Initialized
DEBUG - 2016-09-18 02:07:46 --> Model Class Initialized
ERROR - 2016-09-18 02:07:46 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-18 02:09:32 --> Config Class Initialized
DEBUG - 2016-09-18 02:09:32 --> Hooks Class Initialized
DEBUG - 2016-09-18 02:09:32 --> Utf8 Class Initialized
DEBUG - 2016-09-18 02:09:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 02:09:32 --> URI Class Initialized
DEBUG - 2016-09-18 02:09:32 --> Router Class Initialized
DEBUG - 2016-09-18 02:09:32 --> Output Class Initialized
DEBUG - 2016-09-18 02:09:32 --> Security Class Initialized
DEBUG - 2016-09-18 02:09:32 --> Input Class Initialized
DEBUG - 2016-09-18 02:09:32 --> XSS Filtering completed
DEBUG - 2016-09-18 02:09:32 --> XSS Filtering completed
DEBUG - 2016-09-18 02:09:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 02:09:32 --> Language Class Initialized
DEBUG - 2016-09-18 02:09:32 --> Loader Class Initialized
DEBUG - 2016-09-18 02:09:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 02:09:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 02:09:32 --> Helper loaded: url_helper
DEBUG - 2016-09-18 02:09:32 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 02:09:32 --> Helper loaded: file_helper
DEBUG - 2016-09-18 02:09:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 02:09:32 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 02:09:32 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 02:09:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 02:09:32 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 02:09:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 02:09:32 --> Helper loaded: common_helper
DEBUG - 2016-09-18 02:09:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 02:09:32 --> Helper loaded: common_helper
DEBUG - 2016-09-18 02:09:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 02:09:32 --> Helper loaded: form_helper
DEBUG - 2016-09-18 02:09:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 02:09:32 --> Helper loaded: security_helper
DEBUG - 2016-09-18 02:09:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 02:09:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 02:09:32 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 02:09:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 02:09:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 02:09:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 02:09:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 02:09:32 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 02:09:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 02:09:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 02:09:32 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 02:09:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 02:09:32 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 02:09:32 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 02:09:32 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 02:09:32 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 02:09:32 --> Database Driver Class Initialized
DEBUG - 2016-09-18 02:09:32 --> Session Class Initialized
DEBUG - 2016-09-18 02:09:32 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 02:09:32 --> Helper loaded: string_helper
DEBUG - 2016-09-18 02:09:32 --> Session routines successfully run
DEBUG - 2016-09-18 02:09:32 --> Native_session Class Initialized
DEBUG - 2016-09-18 02:09:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 02:09:33 --> Form Validation Class Initialized
DEBUG - 2016-09-18 02:09:33 --> Form Validation Class Initialized
DEBUG - 2016-09-18 02:09:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 02:09:33 --> Controller Class Initialized
DEBUG - 2016-09-18 02:09:33 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 02:09:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 02:09:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 02:09:33 --> Carabiner: library configured.
DEBUG - 2016-09-18 02:09:33 --> Carabiner: library configured.
DEBUG - 2016-09-18 02:09:33 --> User Agent Class Initialized
DEBUG - 2016-09-18 02:09:33 --> Model Class Initialized
DEBUG - 2016-09-18 02:09:33 --> Model Class Initialized
DEBUG - 2016-09-18 02:09:33 --> Model Class Initialized
DEBUG - 2016-09-18 02:09:33 --> Model Class Initialized
DEBUG - 2016-09-18 02:09:33 --> Model Class Initialized
DEBUG - 2016-09-18 02:09:33 --> Model Class Initialized
DEBUG - 2016-09-18 02:09:33 --> Model Class Initialized
DEBUG - 2016-09-18 02:09:33 --> Model Class Initialized
ERROR - 2016-09-18 02:09:33 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-18 02:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-18 02:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-18 02:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 02:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-18 02:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-18 02:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-18 02:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 02:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-18 02:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-18 02:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 02:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-18 02:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-18 02:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-18 02:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 02:09:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-18 02:09:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/73f5e075ee35be5f6c1c98a57562112a
DEBUG - 2016-09-18 02:09:33 --> Final output sent to browser
DEBUG - 2016-09-18 02:09:33 --> Total execution time: 0.7727
DEBUG - 2016-09-18 02:09:37 --> Config Class Initialized
DEBUG - 2016-09-18 02:09:37 --> Hooks Class Initialized
DEBUG - 2016-09-18 02:09:37 --> Utf8 Class Initialized
DEBUG - 2016-09-18 02:09:37 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 02:09:37 --> URI Class Initialized
DEBUG - 2016-09-18 02:09:37 --> Router Class Initialized
DEBUG - 2016-09-18 02:09:37 --> Output Class Initialized
DEBUG - 2016-09-18 02:09:37 --> Cache file has expired. File deleted
DEBUG - 2016-09-18 02:09:37 --> Security Class Initialized
DEBUG - 2016-09-18 02:09:37 --> Input Class Initialized
DEBUG - 2016-09-18 02:09:37 --> XSS Filtering completed
DEBUG - 2016-09-18 02:09:37 --> XSS Filtering completed
DEBUG - 2016-09-18 02:09:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 02:09:37 --> Language Class Initialized
DEBUG - 2016-09-18 02:09:37 --> Loader Class Initialized
DEBUG - 2016-09-18 02:09:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 02:09:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 02:09:37 --> Helper loaded: url_helper
DEBUG - 2016-09-18 02:09:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 02:09:37 --> Helper loaded: file_helper
DEBUG - 2016-09-18 02:09:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 02:09:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 02:09:37 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 02:09:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 02:09:37 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 02:09:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 02:09:37 --> Helper loaded: common_helper
DEBUG - 2016-09-18 02:09:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 02:09:37 --> Helper loaded: common_helper
DEBUG - 2016-09-18 02:09:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 02:09:37 --> Helper loaded: form_helper
DEBUG - 2016-09-18 02:09:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 02:09:37 --> Helper loaded: security_helper
DEBUG - 2016-09-18 02:09:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 02:09:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 02:09:37 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 02:09:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 02:09:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 02:09:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 02:09:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 02:09:37 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 02:09:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 02:09:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 02:09:37 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 02:09:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 02:09:37 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 02:09:37 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 02:09:37 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 02:09:37 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 02:09:37 --> Database Driver Class Initialized
DEBUG - 2016-09-18 02:09:38 --> Session Class Initialized
DEBUG - 2016-09-18 02:09:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 02:09:38 --> Helper loaded: string_helper
DEBUG - 2016-09-18 02:09:38 --> Session routines successfully run
DEBUG - 2016-09-18 02:09:38 --> Native_session Class Initialized
DEBUG - 2016-09-18 02:09:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 02:09:38 --> Form Validation Class Initialized
DEBUG - 2016-09-18 02:09:38 --> Form Validation Class Initialized
DEBUG - 2016-09-18 02:09:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 02:09:38 --> Controller Class Initialized
DEBUG - 2016-09-18 02:09:38 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 02:09:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 02:09:38 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 02:09:38 --> Carabiner: library configured.
DEBUG - 2016-09-18 02:09:38 --> Carabiner: library configured.
DEBUG - 2016-09-18 02:09:38 --> User Agent Class Initialized
DEBUG - 2016-09-18 02:09:38 --> Model Class Initialized
DEBUG - 2016-09-18 02:09:38 --> Model Class Initialized
DEBUG - 2016-09-18 02:09:38 --> Model Class Initialized
DEBUG - 2016-09-18 02:09:38 --> Model Class Initialized
DEBUG - 2016-09-18 02:09:38 --> Model Class Initialized
DEBUG - 2016-09-18 02:09:38 --> Model Class Initialized
DEBUG - 2016-09-18 02:09:38 --> Model Class Initialized
DEBUG - 2016-09-18 02:09:38 --> Model Class Initialized
ERROR - 2016-09-18 02:09:38 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-18 02:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-18 02:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-18 02:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 02:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-18 02:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-18 02:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-18 02:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 02:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-18 02:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-18 02:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 02:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-18 02:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-18 02:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-18 02:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 02:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-18 02:09:38 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/73f5e075ee35be5f6c1c98a57562112a
DEBUG - 2016-09-18 02:09:38 --> Final output sent to browser
DEBUG - 2016-09-18 02:09:38 --> Total execution time: 0.7893
DEBUG - 2016-09-18 02:09:41 --> Config Class Initialized
DEBUG - 2016-09-18 02:09:41 --> Hooks Class Initialized
DEBUG - 2016-09-18 02:09:41 --> Utf8 Class Initialized
DEBUG - 2016-09-18 02:09:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-18 02:09:41 --> URI Class Initialized
DEBUG - 2016-09-18 02:09:41 --> Router Class Initialized
DEBUG - 2016-09-18 02:09:41 --> Output Class Initialized
DEBUG - 2016-09-18 02:09:41 --> Cache file has expired. File deleted
DEBUG - 2016-09-18 02:09:41 --> Security Class Initialized
DEBUG - 2016-09-18 02:09:41 --> Input Class Initialized
DEBUG - 2016-09-18 02:09:41 --> XSS Filtering completed
DEBUG - 2016-09-18 02:09:41 --> XSS Filtering completed
DEBUG - 2016-09-18 02:09:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-18 02:09:41 --> Language Class Initialized
DEBUG - 2016-09-18 02:09:41 --> Loader Class Initialized
DEBUG - 2016-09-18 02:09:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-18 02:09:41 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-18 02:09:41 --> Helper loaded: url_helper
DEBUG - 2016-09-18 02:09:41 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-18 02:09:41 --> Helper loaded: file_helper
DEBUG - 2016-09-18 02:09:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 02:09:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-18 02:09:41 --> Helper loaded: conf_helper
DEBUG - 2016-09-18 02:09:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-18 02:09:41 --> Check Exists common_helper.php: No
DEBUG - 2016-09-18 02:09:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-18 02:09:41 --> Helper loaded: common_helper
DEBUG - 2016-09-18 02:09:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-18 02:09:41 --> Helper loaded: common_helper
DEBUG - 2016-09-18 02:09:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-18 02:09:41 --> Helper loaded: form_helper
DEBUG - 2016-09-18 02:09:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-18 02:09:41 --> Helper loaded: security_helper
DEBUG - 2016-09-18 02:09:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 02:09:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-18 02:09:41 --> Helper loaded: lang_helper
DEBUG - 2016-09-18 02:09:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-18 02:09:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-18 02:09:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-18 02:09:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-18 02:09:41 --> Helper loaded: atlant_helper
DEBUG - 2016-09-18 02:09:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 02:09:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-18 02:09:41 --> Helper loaded: crypto_helper
DEBUG - 2016-09-18 02:09:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-18 02:09:41 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-18 02:09:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-18 02:09:41 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-18 02:09:41 --> Helper loaded: sidika_helper
DEBUG - 2016-09-18 02:09:41 --> Database Driver Class Initialized
DEBUG - 2016-09-18 02:09:41 --> Session Class Initialized
DEBUG - 2016-09-18 02:09:41 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-18 02:09:41 --> Helper loaded: string_helper
DEBUG - 2016-09-18 02:09:41 --> Session routines successfully run
DEBUG - 2016-09-18 02:09:41 --> Native_session Class Initialized
DEBUG - 2016-09-18 02:09:41 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-18 02:09:42 --> Form Validation Class Initialized
DEBUG - 2016-09-18 02:09:42 --> Form Validation Class Initialized
DEBUG - 2016-09-18 02:09:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-18 02:09:42 --> Controller Class Initialized
DEBUG - 2016-09-18 02:09:42 --> Carabiner: Library initialized.
DEBUG - 2016-09-18 02:09:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-18 02:09:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-18 02:09:42 --> Carabiner: library configured.
DEBUG - 2016-09-18 02:09:42 --> Carabiner: library configured.
DEBUG - 2016-09-18 02:09:42 --> User Agent Class Initialized
DEBUG - 2016-09-18 02:09:42 --> Model Class Initialized
DEBUG - 2016-09-18 02:09:42 --> Model Class Initialized
DEBUG - 2016-09-18 02:09:42 --> Model Class Initialized
DEBUG - 2016-09-18 02:09:42 --> Model Class Initialized
DEBUG - 2016-09-18 02:09:42 --> Model Class Initialized
DEBUG - 2016-09-18 02:09:42 --> Model Class Initialized
DEBUG - 2016-09-18 02:09:42 --> Model Class Initialized
DEBUG - 2016-09-18 02:09:42 --> Model Class Initialized
ERROR - 2016-09-18 02:09:42 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-18 02:09:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-18 02:09:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-18 02:09:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 02:09:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-18 02:09:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-18 02:09:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-18 02:09:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 02:09:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-18 02:09:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-18 02:09:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-18 02:09:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-18 02:09:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-18 02:09:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-18 02:09:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-18 02:09:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-18 02:09:42 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/73f5e075ee35be5f6c1c98a57562112a
DEBUG - 2016-09-18 02:09:42 --> Final output sent to browser
DEBUG - 2016-09-18 02:09:42 --> Total execution time: 0.8185
