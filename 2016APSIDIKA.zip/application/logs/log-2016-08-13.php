<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-08-13 18:51:01 --> Config Class Initialized
DEBUG - 2016-08-13 18:51:01 --> Hooks Class Initialized
DEBUG - 2016-08-13 18:51:01 --> Utf8 Class Initialized
DEBUG - 2016-08-13 18:51:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-13 18:51:01 --> URI Class Initialized
DEBUG - 2016-08-13 18:51:01 --> Router Class Initialized
DEBUG - 2016-08-13 18:51:01 --> Output Class Initialized
DEBUG - 2016-08-13 18:51:01 --> Cache file has expired. File deleted
DEBUG - 2016-08-13 18:51:01 --> Security Class Initialized
DEBUG - 2016-08-13 18:51:01 --> Input Class Initialized
DEBUG - 2016-08-13 18:51:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-13 18:51:01 --> Language Class Initialized
DEBUG - 2016-08-13 18:51:01 --> Loader Class Initialized
DEBUG - 2016-08-13 18:51:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-13 18:51:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-13 18:51:01 --> Helper loaded: url_helper
DEBUG - 2016-08-13 18:51:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-13 18:51:01 --> Helper loaded: file_helper
DEBUG - 2016-08-13 18:51:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-13 18:51:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-13 18:51:01 --> Helper loaded: conf_helper
DEBUG - 2016-08-13 18:51:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-13 18:51:01 --> Check Exists common_helper.php: No
DEBUG - 2016-08-13 18:51:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-13 18:51:01 --> Helper loaded: common_helper
DEBUG - 2016-08-13 18:51:01 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-13 18:51:01 --> Helper loaded: common_helper
DEBUG - 2016-08-13 18:51:01 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-13 18:51:01 --> Helper loaded: form_helper
DEBUG - 2016-08-13 18:51:01 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-13 18:51:01 --> Helper loaded: security_helper
DEBUG - 2016-08-13 18:51:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-13 18:51:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-13 18:51:01 --> Helper loaded: lang_helper
DEBUG - 2016-08-13 18:51:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-13 18:51:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-13 18:51:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-13 18:51:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-13 18:51:01 --> Helper loaded: atlant_helper
DEBUG - 2016-08-13 18:51:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-13 18:51:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-13 18:51:01 --> Helper loaded: crypto_helper
DEBUG - 2016-08-13 18:51:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-13 18:51:01 --> Database Driver Class Initialized
DEBUG - 2016-08-13 18:51:02 --> Session Class Initialized
DEBUG - 2016-08-13 18:51:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-13 18:51:02 --> Helper loaded: string_helper
DEBUG - 2016-08-13 18:51:02 --> A session cookie was not found.
DEBUG - 2016-08-13 18:51:02 --> Session routines successfully run
DEBUG - 2016-08-13 18:51:02 --> Native_session Class Initialized
DEBUG - 2016-08-13 18:51:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-13 18:51:02 --> Form Validation Class Initialized
DEBUG - 2016-08-13 18:51:02 --> Form Validation Class Initialized
DEBUG - 2016-08-13 18:51:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-13 18:51:02 --> Controller Class Initialized
DEBUG - 2016-08-13 18:51:02 --> Carabiner: Library initialized.
DEBUG - 2016-08-13 18:51:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-13 18:51:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-13 18:51:02 --> Carabiner: library configured.
DEBUG - 2016-08-13 18:51:02 --> Carabiner: library configured.
DEBUG - 2016-08-13 18:51:02 --> User Agent Class Initialized
DEBUG - 2016-08-13 18:51:02 --> Model Class Initialized
DEBUG - 2016-08-13 18:51:02 --> Model Class Initialized
DEBUG - 2016-08-13 18:51:02 --> Model Class Initialized
DEBUG - 2016-08-13 18:51:04 --> Model Class Initialized
DEBUG - 2016-08-13 18:51:04 --> Model Class Initialized
DEBUG - 2016-08-13 18:51:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-13 18:51:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-08-13 18:51:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-13 18:51:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-13 18:51:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-13 18:51:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-13 18:51:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-08-13 18:51:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-13 18:51:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-13 18:51:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-13 18:51:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-13 18:51:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-13 18:51:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-13 18:51:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-08-13 18:51:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-13 18:51:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-13 18:51:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-08-13 18:51:07 --> Final output sent to browser
DEBUG - 2016-08-13 18:51:07 --> Total execution time: 6.3487
DEBUG - 2016-08-13 18:51:12 --> Config Class Initialized
DEBUG - 2016-08-13 18:51:12 --> Hooks Class Initialized
DEBUG - 2016-08-13 18:51:12 --> Utf8 Class Initialized
DEBUG - 2016-08-13 18:51:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-13 18:51:12 --> URI Class Initialized
DEBUG - 2016-08-13 18:51:12 --> Router Class Initialized
DEBUG - 2016-08-13 18:51:12 --> Output Class Initialized
DEBUG - 2016-08-13 18:51:12 --> Cache file has expired. File deleted
DEBUG - 2016-08-13 18:51:12 --> Security Class Initialized
DEBUG - 2016-08-13 18:51:12 --> Input Class Initialized
DEBUG - 2016-08-13 18:51:12 --> XSS Filtering completed
DEBUG - 2016-08-13 18:51:12 --> XSS Filtering completed
DEBUG - 2016-08-13 18:51:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-13 18:51:12 --> Language Class Initialized
DEBUG - 2016-08-13 18:51:12 --> Loader Class Initialized
DEBUG - 2016-08-13 18:51:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-13 18:51:12 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-13 18:51:12 --> Helper loaded: url_helper
DEBUG - 2016-08-13 18:51:12 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-13 18:51:12 --> Helper loaded: file_helper
DEBUG - 2016-08-13 18:51:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-13 18:51:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-13 18:51:12 --> Helper loaded: conf_helper
DEBUG - 2016-08-13 18:51:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-13 18:51:12 --> Check Exists common_helper.php: No
DEBUG - 2016-08-13 18:51:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-13 18:51:12 --> Helper loaded: common_helper
DEBUG - 2016-08-13 18:51:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-13 18:51:12 --> Helper loaded: common_helper
DEBUG - 2016-08-13 18:51:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-13 18:51:12 --> Helper loaded: form_helper
DEBUG - 2016-08-13 18:51:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-13 18:51:12 --> Helper loaded: security_helper
DEBUG - 2016-08-13 18:51:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-13 18:51:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-13 18:51:12 --> Helper loaded: lang_helper
DEBUG - 2016-08-13 18:51:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-13 18:51:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-13 18:51:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-13 18:51:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-13 18:51:12 --> Helper loaded: atlant_helper
DEBUG - 2016-08-13 18:51:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-13 18:51:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-13 18:51:12 --> Helper loaded: crypto_helper
DEBUG - 2016-08-13 18:51:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-13 18:51:12 --> Database Driver Class Initialized
DEBUG - 2016-08-13 18:51:12 --> Session Class Initialized
DEBUG - 2016-08-13 18:51:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-13 18:51:12 --> Helper loaded: string_helper
DEBUG - 2016-08-13 18:51:12 --> Session routines successfully run
DEBUG - 2016-08-13 18:51:12 --> Native_session Class Initialized
DEBUG - 2016-08-13 18:51:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-13 18:51:12 --> Form Validation Class Initialized
DEBUG - 2016-08-13 18:51:12 --> Form Validation Class Initialized
DEBUG - 2016-08-13 18:51:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-13 18:51:12 --> Controller Class Initialized
DEBUG - 2016-08-13 18:51:12 --> Carabiner: Library initialized.
DEBUG - 2016-08-13 18:51:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-13 18:51:12 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-13 18:51:12 --> Carabiner: library configured.
DEBUG - 2016-08-13 18:51:12 --> Carabiner: library configured.
DEBUG - 2016-08-13 18:51:12 --> User Agent Class Initialized
DEBUG - 2016-08-13 18:51:12 --> Model Class Initialized
DEBUG - 2016-08-13 18:51:12 --> Model Class Initialized
DEBUG - 2016-08-13 18:51:12 --> Model Class Initialized
DEBUG - 2016-08-13 18:51:12 --> Model Class Initialized
DEBUG - 2016-08-13 18:51:12 --> Model Class Initialized
ERROR - 2016-08-13 18:51:12 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-08-13 18:51:12 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-08-13 18:51:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-13 18:51:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-08-13 18:51:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-13 18:51:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-13 18:51:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-13 18:51:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-13 18:51:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-08-13 18:51:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-13 18:51:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-13 18:51:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-13 18:51:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-13 18:51:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-13 18:51:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-13 18:51:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-08-13 18:51:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-13 18:51:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-13 18:51:12 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-08-13 18:51:12 --> Final output sent to browser
DEBUG - 2016-08-13 18:51:12 --> Total execution time: 0.3836
