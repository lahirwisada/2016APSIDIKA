<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-11-28 00:49:34 --> Config Class Initialized
DEBUG - 2016-11-28 00:49:34 --> Hooks Class Initialized
DEBUG - 2016-11-28 00:49:34 --> Utf8 Class Initialized
DEBUG - 2016-11-28 00:49:34 --> UTF-8 Support Enabled
DEBUG - 2016-11-28 00:49:34 --> URI Class Initialized
DEBUG - 2016-11-28 00:49:34 --> Router Class Initialized
DEBUG - 2016-11-28 00:49:34 --> No URI present. Default controller set.
DEBUG - 2016-11-28 00:49:34 --> Output Class Initialized
DEBUG - 2016-11-28 00:49:34 --> Cache file has expired. File deleted
DEBUG - 2016-11-28 00:49:34 --> Security Class Initialized
DEBUG - 2016-11-28 00:49:34 --> Input Class Initialized
DEBUG - 2016-11-28 00:49:34 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:34 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-28 00:49:34 --> Language Class Initialized
DEBUG - 2016-11-28 00:49:34 --> Loader Class Initialized
DEBUG - 2016-11-28 00:49:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-28 00:49:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-28 00:49:34 --> Helper loaded: url_helper
DEBUG - 2016-11-28 00:49:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-28 00:49:34 --> Helper loaded: file_helper
DEBUG - 2016-11-28 00:49:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:49:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-28 00:49:34 --> Helper loaded: conf_helper
DEBUG - 2016-11-28 00:49:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:49:34 --> Check Exists common_helper.php: No
DEBUG - 2016-11-28 00:49:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-28 00:49:34 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:49:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-28 00:49:34 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:49:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-28 00:49:34 --> Helper loaded: form_helper
DEBUG - 2016-11-28 00:49:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-28 00:49:34 --> Helper loaded: security_helper
DEBUG - 2016-11-28 00:49:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:49:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-28 00:49:34 --> Helper loaded: lang_helper
DEBUG - 2016-11-28 00:49:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:49:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-28 00:49:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-28 00:49:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-28 00:49:34 --> Helper loaded: atlant_helper
DEBUG - 2016-11-28 00:49:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:49:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-28 00:49:34 --> Helper loaded: crypto_helper
DEBUG - 2016-11-28 00:49:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:49:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-28 00:49:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-28 00:49:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-28 00:49:34 --> Helper loaded: sidika_helper
DEBUG - 2016-11-28 00:49:34 --> Database Driver Class Initialized
DEBUG - 2016-11-28 00:49:34 --> Session Class Initialized
DEBUG - 2016-11-28 00:49:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-28 00:49:34 --> Helper loaded: string_helper
DEBUG - 2016-11-28 00:49:34 --> Session routines successfully run
DEBUG - 2016-11-28 00:49:34 --> Native_session Class Initialized
DEBUG - 2016-11-28 00:49:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-28 00:49:34 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:49:34 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:49:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-28 00:49:34 --> Controller Class Initialized
DEBUG - 2016-11-28 00:49:34 --> Carabiner: Library initialized.
DEBUG - 2016-11-28 00:49:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-28 00:49:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-28 00:49:34 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:49:34 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:49:34 --> User Agent Class Initialized
DEBUG - 2016-11-28 00:49:34 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:34 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:34 --> Model Class Initialized
ERROR - 2016-11-28 00:49:34 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-11-28 00:49:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-11-28 00:49:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-11-28 00:49:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-28 00:49:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-28 00:49:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-28 00:49:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-28 00:49:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-28 00:49:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-11-28 00:49:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-11-28 00:49:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-28 00:49:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-28 00:49:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-28 00:49:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-28 00:49:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-28 00:49:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-28 00:49:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-28 00:49:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-11-28 00:49:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-11-28 00:49:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-28 00:49:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-28 00:49:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-11-28 00:49:34 --> Final output sent to browser
DEBUG - 2016-11-28 00:49:34 --> Total execution time: 0.5480
DEBUG - 2016-11-28 00:49:35 --> Config Class Initialized
DEBUG - 2016-11-28 00:49:35 --> Hooks Class Initialized
DEBUG - 2016-11-28 00:49:35 --> Utf8 Class Initialized
DEBUG - 2016-11-28 00:49:35 --> UTF-8 Support Enabled
DEBUG - 2016-11-28 00:49:35 --> URI Class Initialized
DEBUG - 2016-11-28 00:49:35 --> Router Class Initialized
DEBUG - 2016-11-28 00:49:35 --> Output Class Initialized
DEBUG - 2016-11-28 00:49:35 --> Cache file has expired. File deleted
DEBUG - 2016-11-28 00:49:35 --> Security Class Initialized
DEBUG - 2016-11-28 00:49:35 --> Input Class Initialized
DEBUG - 2016-11-28 00:49:35 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:35 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:35 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:35 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:35 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:35 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:35 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-28 00:49:35 --> Language Class Initialized
DEBUG - 2016-11-28 00:49:35 --> Loader Class Initialized
DEBUG - 2016-11-28 00:49:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-28 00:49:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-28 00:49:35 --> Helper loaded: url_helper
DEBUG - 2016-11-28 00:49:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-28 00:49:35 --> Helper loaded: file_helper
DEBUG - 2016-11-28 00:49:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:49:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-28 00:49:35 --> Helper loaded: conf_helper
DEBUG - 2016-11-28 00:49:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:49:35 --> Check Exists common_helper.php: No
DEBUG - 2016-11-28 00:49:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-28 00:49:35 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:49:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-28 00:49:35 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:49:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-28 00:49:35 --> Helper loaded: form_helper
DEBUG - 2016-11-28 00:49:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-28 00:49:35 --> Helper loaded: security_helper
DEBUG - 2016-11-28 00:49:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:49:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-28 00:49:35 --> Helper loaded: lang_helper
DEBUG - 2016-11-28 00:49:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:49:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-28 00:49:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-28 00:49:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-28 00:49:35 --> Helper loaded: atlant_helper
DEBUG - 2016-11-28 00:49:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:49:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-28 00:49:35 --> Helper loaded: crypto_helper
DEBUG - 2016-11-28 00:49:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:49:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-28 00:49:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-28 00:49:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-28 00:49:35 --> Helper loaded: sidika_helper
DEBUG - 2016-11-28 00:49:35 --> Database Driver Class Initialized
DEBUG - 2016-11-28 00:49:36 --> Session Class Initialized
DEBUG - 2016-11-28 00:49:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-28 00:49:36 --> Helper loaded: string_helper
DEBUG - 2016-11-28 00:49:36 --> Session routines successfully run
DEBUG - 2016-11-28 00:49:36 --> Native_session Class Initialized
DEBUG - 2016-11-28 00:49:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-28 00:49:36 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:49:36 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:49:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-28 00:49:36 --> Controller Class Initialized
DEBUG - 2016-11-28 00:49:36 --> Carabiner: Library initialized.
DEBUG - 2016-11-28 00:49:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-28 00:49:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-28 00:49:36 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:49:36 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:49:36 --> User Agent Class Initialized
DEBUG - 2016-11-28 00:49:36 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:36 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:36 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:36 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:36 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:36 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:36 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-11-28 00:49:37 --> Final output sent to browser
DEBUG - 2016-11-28 00:49:37 --> Total execution time: 1.2826
DEBUG - 2016-11-28 00:49:37 --> Config Class Initialized
DEBUG - 2016-11-28 00:49:37 --> Hooks Class Initialized
DEBUG - 2016-11-28 00:49:37 --> Utf8 Class Initialized
DEBUG - 2016-11-28 00:49:37 --> UTF-8 Support Enabled
DEBUG - 2016-11-28 00:49:37 --> URI Class Initialized
DEBUG - 2016-11-28 00:49:37 --> Router Class Initialized
DEBUG - 2016-11-28 00:49:37 --> Output Class Initialized
DEBUG - 2016-11-28 00:49:37 --> Cache file has expired. File deleted
DEBUG - 2016-11-28 00:49:37 --> Security Class Initialized
DEBUG - 2016-11-28 00:49:37 --> Input Class Initialized
DEBUG - 2016-11-28 00:49:37 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:37 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-28 00:49:37 --> Language Class Initialized
DEBUG - 2016-11-28 00:49:37 --> Loader Class Initialized
DEBUG - 2016-11-28 00:49:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-28 00:49:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-28 00:49:37 --> Helper loaded: url_helper
DEBUG - 2016-11-28 00:49:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-28 00:49:37 --> Helper loaded: file_helper
DEBUG - 2016-11-28 00:49:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:49:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-28 00:49:37 --> Helper loaded: conf_helper
DEBUG - 2016-11-28 00:49:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:49:37 --> Check Exists common_helper.php: No
DEBUG - 2016-11-28 00:49:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-28 00:49:37 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:49:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-28 00:49:37 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:49:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-28 00:49:37 --> Helper loaded: form_helper
DEBUG - 2016-11-28 00:49:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-28 00:49:37 --> Helper loaded: security_helper
DEBUG - 2016-11-28 00:49:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:49:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-28 00:49:37 --> Helper loaded: lang_helper
DEBUG - 2016-11-28 00:49:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:49:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-28 00:49:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-28 00:49:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-28 00:49:37 --> Helper loaded: atlant_helper
DEBUG - 2016-11-28 00:49:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:49:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-28 00:49:37 --> Helper loaded: crypto_helper
DEBUG - 2016-11-28 00:49:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:49:37 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-28 00:49:37 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-28 00:49:37 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-28 00:49:37 --> Helper loaded: sidika_helper
DEBUG - 2016-11-28 00:49:37 --> Database Driver Class Initialized
DEBUG - 2016-11-28 00:49:37 --> Session Class Initialized
DEBUG - 2016-11-28 00:49:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-28 00:49:37 --> Helper loaded: string_helper
DEBUG - 2016-11-28 00:49:37 --> Session routines successfully run
DEBUG - 2016-11-28 00:49:37 --> Native_session Class Initialized
DEBUG - 2016-11-28 00:49:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-28 00:49:37 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:49:37 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:49:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-28 00:49:37 --> Controller Class Initialized
DEBUG - 2016-11-28 00:49:37 --> Carabiner: Library initialized.
DEBUG - 2016-11-28 00:49:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-28 00:49:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-28 00:49:37 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:49:37 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:49:37 --> User Agent Class Initialized
DEBUG - 2016-11-28 00:49:37 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:37 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:37 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-11-28 00:49:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-28 00:49:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-28 00:49:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-28 00:49:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-28 00:49:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-28 00:49:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-28 00:49:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-28 00:49:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-28 00:49:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-28 00:49:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-28 00:49:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-28 00:49:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-28 00:49:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-11-28 00:49:37 --> Final output sent to browser
DEBUG - 2016-11-28 00:49:37 --> Total execution time: 0.2633
DEBUG - 2016-11-28 00:49:39 --> Config Class Initialized
DEBUG - 2016-11-28 00:49:39 --> Hooks Class Initialized
DEBUG - 2016-11-28 00:49:39 --> Utf8 Class Initialized
DEBUG - 2016-11-28 00:49:39 --> UTF-8 Support Enabled
DEBUG - 2016-11-28 00:49:39 --> URI Class Initialized
DEBUG - 2016-11-28 00:49:39 --> Router Class Initialized
DEBUG - 2016-11-28 00:49:39 --> Output Class Initialized
DEBUG - 2016-11-28 00:49:39 --> Security Class Initialized
DEBUG - 2016-11-28 00:49:39 --> Input Class Initialized
DEBUG - 2016-11-28 00:49:39 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:39 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-28 00:49:39 --> Language Class Initialized
DEBUG - 2016-11-28 00:49:39 --> Loader Class Initialized
DEBUG - 2016-11-28 00:49:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-28 00:49:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-28 00:49:39 --> Helper loaded: url_helper
DEBUG - 2016-11-28 00:49:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-28 00:49:39 --> Helper loaded: file_helper
DEBUG - 2016-11-28 00:49:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:49:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-28 00:49:39 --> Helper loaded: conf_helper
DEBUG - 2016-11-28 00:49:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:49:39 --> Check Exists common_helper.php: No
DEBUG - 2016-11-28 00:49:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: form_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: security_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: lang_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: atlant_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: crypto_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: sidika_helper
DEBUG - 2016-11-28 00:49:40 --> Database Driver Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Session Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: string_helper
DEBUG - 2016-11-28 00:49:40 --> Session routines successfully run
DEBUG - 2016-11-28 00:49:40 --> Native_session Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-28 00:49:40 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-28 00:49:40 --> Controller Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Carabiner: Library initialized.
DEBUG - 2016-11-28 00:49:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-28 00:49:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-28 00:49:40 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:49:40 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:49:40 --> User Agent Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Config Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Hooks Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Utf8 Class Initialized
DEBUG - 2016-11-28 00:49:40 --> UTF-8 Support Enabled
DEBUG - 2016-11-28 00:49:40 --> URI Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Router Class Initialized
DEBUG - 2016-11-28 00:49:40 --> No URI present. Default controller set.
DEBUG - 2016-11-28 00:49:40 --> Output Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Cache file has expired. File deleted
DEBUG - 2016-11-28 00:49:40 --> Security Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Input Class Initialized
DEBUG - 2016-11-28 00:49:40 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:40 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-28 00:49:40 --> Language Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Loader Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-28 00:49:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: url_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: file_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: conf_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists common_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: form_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: security_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: lang_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: atlant_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: crypto_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: sidika_helper
DEBUG - 2016-11-28 00:49:40 --> Database Driver Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Session Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: string_helper
DEBUG - 2016-11-28 00:49:40 --> Session routines successfully run
DEBUG - 2016-11-28 00:49:40 --> Native_session Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-28 00:49:40 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-28 00:49:40 --> Controller Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Carabiner: Library initialized.
DEBUG - 2016-11-28 00:49:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-28 00:49:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-28 00:49:40 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:49:40 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:49:40 --> User Agent Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Model Class Initialized
ERROR - 2016-11-28 00:49:40 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-11-28 00:49:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-11-28 00:49:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-11-28 00:49:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-28 00:49:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-28 00:49:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-28 00:49:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-28 00:49:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-28 00:49:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-11-28 00:49:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-11-28 00:49:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-28 00:49:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-28 00:49:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-28 00:49:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-28 00:49:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-28 00:49:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-28 00:49:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-28 00:49:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-11-28 00:49:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-11-28 00:49:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-28 00:49:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-28 00:49:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-11-28 00:49:40 --> Final output sent to browser
DEBUG - 2016-11-28 00:49:40 --> Total execution time: 0.2563
DEBUG - 2016-11-28 00:49:40 --> Config Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Hooks Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Utf8 Class Initialized
DEBUG - 2016-11-28 00:49:40 --> UTF-8 Support Enabled
DEBUG - 2016-11-28 00:49:40 --> URI Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Router Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Output Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Cache file has expired. File deleted
DEBUG - 2016-11-28 00:49:40 --> Security Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Input Class Initialized
DEBUG - 2016-11-28 00:49:40 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:40 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:40 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:40 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:40 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:40 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:40 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-28 00:49:40 --> Language Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Loader Class Initialized
DEBUG - 2016-11-28 00:49:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-28 00:49:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: url_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: file_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: conf_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists common_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: form_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: security_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: lang_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: atlant_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: crypto_helper
DEBUG - 2016-11-28 00:49:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-28 00:49:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-28 00:49:40 --> Helper loaded: sidika_helper
DEBUG - 2016-11-28 00:49:40 --> Database Driver Class Initialized
DEBUG - 2016-11-28 00:49:41 --> Session Class Initialized
DEBUG - 2016-11-28 00:49:41 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-28 00:49:41 --> Helper loaded: string_helper
DEBUG - 2016-11-28 00:49:41 --> Session routines successfully run
DEBUG - 2016-11-28 00:49:41 --> Native_session Class Initialized
DEBUG - 2016-11-28 00:49:41 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-28 00:49:41 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:49:41 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:49:41 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-28 00:49:41 --> Controller Class Initialized
DEBUG - 2016-11-28 00:49:41 --> Carabiner: Library initialized.
DEBUG - 2016-11-28 00:49:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-28 00:49:41 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-28 00:49:41 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:49:41 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:49:41 --> User Agent Class Initialized
DEBUG - 2016-11-28 00:49:41 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:41 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:41 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:41 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:41 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:41 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:41 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:41 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-11-28 00:49:41 --> Final output sent to browser
DEBUG - 2016-11-28 00:49:41 --> Total execution time: 0.3414
DEBUG - 2016-11-28 00:49:44 --> Config Class Initialized
DEBUG - 2016-11-28 00:49:44 --> Hooks Class Initialized
DEBUG - 2016-11-28 00:49:44 --> Utf8 Class Initialized
DEBUG - 2016-11-28 00:49:44 --> UTF-8 Support Enabled
DEBUG - 2016-11-28 00:49:44 --> URI Class Initialized
DEBUG - 2016-11-28 00:49:44 --> Router Class Initialized
DEBUG - 2016-11-28 00:49:44 --> Output Class Initialized
DEBUG - 2016-11-28 00:49:44 --> Cache file has expired. File deleted
DEBUG - 2016-11-28 00:49:44 --> Security Class Initialized
DEBUG - 2016-11-28 00:49:44 --> Input Class Initialized
DEBUG - 2016-11-28 00:49:44 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:44 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-28 00:49:44 --> Language Class Initialized
DEBUG - 2016-11-28 00:49:44 --> Loader Class Initialized
DEBUG - 2016-11-28 00:49:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-28 00:49:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-28 00:49:44 --> Helper loaded: url_helper
DEBUG - 2016-11-28 00:49:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-28 00:49:44 --> Helper loaded: file_helper
DEBUG - 2016-11-28 00:49:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:49:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-28 00:49:44 --> Helper loaded: conf_helper
DEBUG - 2016-11-28 00:49:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:49:44 --> Check Exists common_helper.php: No
DEBUG - 2016-11-28 00:49:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-28 00:49:44 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:49:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-28 00:49:44 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:49:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-28 00:49:44 --> Helper loaded: form_helper
DEBUG - 2016-11-28 00:49:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-28 00:49:44 --> Helper loaded: security_helper
DEBUG - 2016-11-28 00:49:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:49:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-28 00:49:44 --> Helper loaded: lang_helper
DEBUG - 2016-11-28 00:49:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:49:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-28 00:49:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-28 00:49:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-28 00:49:44 --> Helper loaded: atlant_helper
DEBUG - 2016-11-28 00:49:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:49:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-28 00:49:44 --> Helper loaded: crypto_helper
DEBUG - 2016-11-28 00:49:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:49:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-28 00:49:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-28 00:49:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-28 00:49:44 --> Helper loaded: sidika_helper
DEBUG - 2016-11-28 00:49:44 --> Database Driver Class Initialized
DEBUG - 2016-11-28 00:49:44 --> Session Class Initialized
DEBUG - 2016-11-28 00:49:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-28 00:49:44 --> Helper loaded: string_helper
DEBUG - 2016-11-28 00:49:44 --> Session routines successfully run
DEBUG - 2016-11-28 00:49:44 --> Native_session Class Initialized
DEBUG - 2016-11-28 00:49:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-28 00:49:44 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:49:44 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:49:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-28 00:49:44 --> Controller Class Initialized
DEBUG - 2016-11-28 00:49:44 --> Carabiner: Library initialized.
DEBUG - 2016-11-28 00:49:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-28 00:49:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-28 00:49:44 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:49:44 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:49:44 --> User Agent Class Initialized
DEBUG - 2016-11-28 00:49:44 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:44 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:44 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-11-28 00:49:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-28 00:49:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-28 00:49:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-28 00:49:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-28 00:49:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-28 00:49:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-28 00:49:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-28 00:49:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-28 00:49:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-28 00:49:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-28 00:49:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-28 00:49:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-28 00:49:44 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-11-28 00:49:44 --> Final output sent to browser
DEBUG - 2016-11-28 00:49:44 --> Total execution time: 0.2640
DEBUG - 2016-11-28 00:49:45 --> Config Class Initialized
DEBUG - 2016-11-28 00:49:45 --> Hooks Class Initialized
DEBUG - 2016-11-28 00:49:45 --> Utf8 Class Initialized
DEBUG - 2016-11-28 00:49:45 --> UTF-8 Support Enabled
DEBUG - 2016-11-28 00:49:45 --> URI Class Initialized
DEBUG - 2016-11-28 00:49:45 --> Router Class Initialized
DEBUG - 2016-11-28 00:49:45 --> Output Class Initialized
DEBUG - 2016-11-28 00:49:45 --> Security Class Initialized
DEBUG - 2016-11-28 00:49:45 --> Input Class Initialized
DEBUG - 2016-11-28 00:49:45 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:45 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-28 00:49:45 --> Language Class Initialized
DEBUG - 2016-11-28 00:49:45 --> Loader Class Initialized
DEBUG - 2016-11-28 00:49:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-28 00:49:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-28 00:49:45 --> Helper loaded: url_helper
DEBUG - 2016-11-28 00:49:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-28 00:49:45 --> Helper loaded: file_helper
DEBUG - 2016-11-28 00:49:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:49:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-28 00:49:45 --> Helper loaded: conf_helper
DEBUG - 2016-11-28 00:49:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:49:45 --> Check Exists common_helper.php: No
DEBUG - 2016-11-28 00:49:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-28 00:49:45 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:49:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-28 00:49:45 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:49:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-28 00:49:45 --> Helper loaded: form_helper
DEBUG - 2016-11-28 00:49:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-28 00:49:45 --> Helper loaded: security_helper
DEBUG - 2016-11-28 00:49:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:49:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-28 00:49:45 --> Helper loaded: lang_helper
DEBUG - 2016-11-28 00:49:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:49:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-28 00:49:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-28 00:49:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-28 00:49:45 --> Helper loaded: atlant_helper
DEBUG - 2016-11-28 00:49:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:49:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-28 00:49:46 --> Helper loaded: crypto_helper
DEBUG - 2016-11-28 00:49:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:49:46 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-28 00:49:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-28 00:49:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-28 00:49:46 --> Helper loaded: sidika_helper
DEBUG - 2016-11-28 00:49:46 --> Database Driver Class Initialized
DEBUG - 2016-11-28 00:49:46 --> Session Class Initialized
DEBUG - 2016-11-28 00:49:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-28 00:49:46 --> Helper loaded: string_helper
DEBUG - 2016-11-28 00:49:46 --> Session routines successfully run
DEBUG - 2016-11-28 00:49:46 --> Native_session Class Initialized
DEBUG - 2016-11-28 00:49:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-28 00:49:46 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:49:46 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:49:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-28 00:49:46 --> Controller Class Initialized
DEBUG - 2016-11-28 00:49:46 --> Carabiner: Library initialized.
DEBUG - 2016-11-28 00:49:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-28 00:49:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-28 00:49:46 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:49:46 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:49:46 --> User Agent Class Initialized
DEBUG - 2016-11-28 00:49:46 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:46 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:46 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:46 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:46 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:46 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:46 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:46 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-11-28 00:49:46 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-11-28 00:49:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-11-28 00:49:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-11-28 00:49:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-11-28 00:49:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-11-28 00:49:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-11-28 00:49:46 --> Final output sent to browser
DEBUG - 2016-11-28 00:49:46 --> Total execution time: 0.3564
DEBUG - 2016-11-28 00:49:46 --> Config Class Initialized
DEBUG - 2016-11-28 00:49:46 --> Hooks Class Initialized
DEBUG - 2016-11-28 00:49:46 --> Utf8 Class Initialized
DEBUG - 2016-11-28 00:49:46 --> UTF-8 Support Enabled
DEBUG - 2016-11-28 00:49:46 --> URI Class Initialized
DEBUG - 2016-11-28 00:49:46 --> Router Class Initialized
ERROR - 2016-11-28 00:49:46 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-11-28 00:49:51 --> Config Class Initialized
DEBUG - 2016-11-28 00:49:51 --> Hooks Class Initialized
DEBUG - 2016-11-28 00:49:51 --> Utf8 Class Initialized
DEBUG - 2016-11-28 00:49:51 --> UTF-8 Support Enabled
DEBUG - 2016-11-28 00:49:51 --> URI Class Initialized
DEBUG - 2016-11-28 00:49:51 --> Router Class Initialized
DEBUG - 2016-11-28 00:49:51 --> Output Class Initialized
DEBUG - 2016-11-28 00:49:51 --> Cache file has expired. File deleted
DEBUG - 2016-11-28 00:49:51 --> Security Class Initialized
DEBUG - 2016-11-28 00:49:51 --> Input Class Initialized
DEBUG - 2016-11-28 00:49:51 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:51 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:51 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:51 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-28 00:49:51 --> Language Class Initialized
DEBUG - 2016-11-28 00:49:51 --> Loader Class Initialized
DEBUG - 2016-11-28 00:49:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-28 00:49:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-28 00:49:51 --> Helper loaded: url_helper
DEBUG - 2016-11-28 00:49:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-28 00:49:51 --> Helper loaded: file_helper
DEBUG - 2016-11-28 00:49:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:49:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-28 00:49:51 --> Helper loaded: conf_helper
DEBUG - 2016-11-28 00:49:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:49:51 --> Check Exists common_helper.php: No
DEBUG - 2016-11-28 00:49:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-28 00:49:51 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:49:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-28 00:49:51 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:49:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-28 00:49:51 --> Helper loaded: form_helper
DEBUG - 2016-11-28 00:49:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-28 00:49:51 --> Helper loaded: security_helper
DEBUG - 2016-11-28 00:49:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:49:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-28 00:49:51 --> Helper loaded: lang_helper
DEBUG - 2016-11-28 00:49:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:49:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-28 00:49:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-28 00:49:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-28 00:49:51 --> Helper loaded: atlant_helper
DEBUG - 2016-11-28 00:49:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:49:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-28 00:49:51 --> Helper loaded: crypto_helper
DEBUG - 2016-11-28 00:49:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:49:51 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-28 00:49:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-28 00:49:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-28 00:49:51 --> Helper loaded: sidika_helper
DEBUG - 2016-11-28 00:49:51 --> Database Driver Class Initialized
DEBUG - 2016-11-28 00:49:51 --> Session Class Initialized
DEBUG - 2016-11-28 00:49:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-28 00:49:51 --> Helper loaded: string_helper
DEBUG - 2016-11-28 00:49:51 --> Session routines successfully run
DEBUG - 2016-11-28 00:49:51 --> Native_session Class Initialized
DEBUG - 2016-11-28 00:49:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-28 00:49:51 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:49:51 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:49:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-28 00:49:51 --> Controller Class Initialized
DEBUG - 2016-11-28 00:49:51 --> Carabiner: Library initialized.
DEBUG - 2016-11-28 00:49:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-28 00:49:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-28 00:49:51 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:49:51 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:49:51 --> User Agent Class Initialized
DEBUG - 2016-11-28 00:49:51 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:51 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:51 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:51 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:51 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:51 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:51 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-11-28 00:49:51 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:49:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-28 00:49:51 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-11-28 00:49:52 --> Config Class Initialized
DEBUG - 2016-11-28 00:49:52 --> Hooks Class Initialized
DEBUG - 2016-11-28 00:49:52 --> Utf8 Class Initialized
DEBUG - 2016-11-28 00:49:52 --> UTF-8 Support Enabled
DEBUG - 2016-11-28 00:49:52 --> URI Class Initialized
DEBUG - 2016-11-28 00:49:52 --> Router Class Initialized
DEBUG - 2016-11-28 00:49:52 --> No URI present. Default controller set.
DEBUG - 2016-11-28 00:49:52 --> Output Class Initialized
DEBUG - 2016-11-28 00:49:52 --> Cache file has expired. File deleted
DEBUG - 2016-11-28 00:49:52 --> Security Class Initialized
DEBUG - 2016-11-28 00:49:52 --> Input Class Initialized
DEBUG - 2016-11-28 00:49:52 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:52 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-28 00:49:52 --> Language Class Initialized
DEBUG - 2016-11-28 00:49:52 --> Loader Class Initialized
DEBUG - 2016-11-28 00:49:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-28 00:49:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-28 00:49:52 --> Helper loaded: url_helper
DEBUG - 2016-11-28 00:49:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-28 00:49:52 --> Helper loaded: file_helper
DEBUG - 2016-11-28 00:49:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:49:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-28 00:49:52 --> Helper loaded: conf_helper
DEBUG - 2016-11-28 00:49:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:49:52 --> Check Exists common_helper.php: No
DEBUG - 2016-11-28 00:49:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-28 00:49:52 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:49:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-28 00:49:52 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:49:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-28 00:49:52 --> Helper loaded: form_helper
DEBUG - 2016-11-28 00:49:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-28 00:49:52 --> Helper loaded: security_helper
DEBUG - 2016-11-28 00:49:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:49:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-28 00:49:52 --> Helper loaded: lang_helper
DEBUG - 2016-11-28 00:49:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:49:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-28 00:49:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-28 00:49:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-28 00:49:52 --> Helper loaded: atlant_helper
DEBUG - 2016-11-28 00:49:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:49:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-28 00:49:52 --> Helper loaded: crypto_helper
DEBUG - 2016-11-28 00:49:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:49:52 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-28 00:49:52 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-28 00:49:52 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-28 00:49:52 --> Helper loaded: sidika_helper
DEBUG - 2016-11-28 00:49:52 --> Database Driver Class Initialized
DEBUG - 2016-11-28 00:49:52 --> Session Class Initialized
DEBUG - 2016-11-28 00:49:52 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-28 00:49:52 --> Helper loaded: string_helper
DEBUG - 2016-11-28 00:49:52 --> Session routines successfully run
DEBUG - 2016-11-28 00:49:52 --> Native_session Class Initialized
DEBUG - 2016-11-28 00:49:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-28 00:49:52 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:49:52 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:49:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-28 00:49:52 --> Controller Class Initialized
DEBUG - 2016-11-28 00:49:52 --> Carabiner: Library initialized.
DEBUG - 2016-11-28 00:49:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-28 00:49:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-28 00:49:52 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:49:52 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:49:52 --> User Agent Class Initialized
DEBUG - 2016-11-28 00:49:52 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:52 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:52 --> Model Class Initialized
ERROR - 2016-11-28 00:49:52 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-11-28 00:49:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-11-28 00:49:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-11-28 00:49:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-28 00:49:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-28 00:49:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-28 00:49:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-28 00:49:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-28 00:49:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-11-28 00:49:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-11-28 00:49:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-28 00:49:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-28 00:49:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-28 00:49:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-28 00:49:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-28 00:49:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-28 00:49:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-28 00:49:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-11-28 00:49:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-11-28 00:49:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-28 00:49:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-28 00:49:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-11-28 00:49:52 --> Final output sent to browser
DEBUG - 2016-11-28 00:49:52 --> Total execution time: 0.3468
DEBUG - 2016-11-28 00:49:52 --> Config Class Initialized
DEBUG - 2016-11-28 00:49:52 --> Hooks Class Initialized
DEBUG - 2016-11-28 00:49:52 --> Utf8 Class Initialized
DEBUG - 2016-11-28 00:49:52 --> UTF-8 Support Enabled
DEBUG - 2016-11-28 00:49:52 --> URI Class Initialized
DEBUG - 2016-11-28 00:49:52 --> Router Class Initialized
DEBUG - 2016-11-28 00:49:52 --> Output Class Initialized
DEBUG - 2016-11-28 00:49:52 --> Cache file has expired. File deleted
DEBUG - 2016-11-28 00:49:52 --> Security Class Initialized
DEBUG - 2016-11-28 00:49:52 --> Input Class Initialized
DEBUG - 2016-11-28 00:49:52 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:52 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:52 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:52 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:52 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:52 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:52 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-28 00:49:52 --> Language Class Initialized
DEBUG - 2016-11-28 00:49:52 --> Loader Class Initialized
DEBUG - 2016-11-28 00:49:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-28 00:49:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-28 00:49:52 --> Helper loaded: url_helper
DEBUG - 2016-11-28 00:49:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-28 00:49:52 --> Helper loaded: file_helper
DEBUG - 2016-11-28 00:49:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:49:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-28 00:49:52 --> Helper loaded: conf_helper
DEBUG - 2016-11-28 00:49:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:49:52 --> Check Exists common_helper.php: No
DEBUG - 2016-11-28 00:49:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-28 00:49:52 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:49:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-28 00:49:52 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:49:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-28 00:49:52 --> Helper loaded: form_helper
DEBUG - 2016-11-28 00:49:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-28 00:49:52 --> Helper loaded: security_helper
DEBUG - 2016-11-28 00:49:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:49:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-28 00:49:52 --> Helper loaded: lang_helper
DEBUG - 2016-11-28 00:49:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:49:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-28 00:49:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-28 00:49:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-28 00:49:53 --> Helper loaded: atlant_helper
DEBUG - 2016-11-28 00:49:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:49:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-28 00:49:53 --> Helper loaded: crypto_helper
DEBUG - 2016-11-28 00:49:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:49:53 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-28 00:49:53 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-28 00:49:53 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-28 00:49:53 --> Helper loaded: sidika_helper
DEBUG - 2016-11-28 00:49:53 --> Database Driver Class Initialized
DEBUG - 2016-11-28 00:49:53 --> Session Class Initialized
DEBUG - 2016-11-28 00:49:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-28 00:49:53 --> Helper loaded: string_helper
DEBUG - 2016-11-28 00:49:53 --> Session routines successfully run
DEBUG - 2016-11-28 00:49:53 --> Native_session Class Initialized
DEBUG - 2016-11-28 00:49:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-28 00:49:53 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:49:53 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:49:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-28 00:49:53 --> Controller Class Initialized
DEBUG - 2016-11-28 00:49:53 --> Carabiner: Library initialized.
DEBUG - 2016-11-28 00:49:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-28 00:49:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-28 00:49:53 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:49:53 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:49:53 --> User Agent Class Initialized
DEBUG - 2016-11-28 00:49:53 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:53 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:53 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:53 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:53 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:53 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:53 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:53 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-11-28 00:49:53 --> Final output sent to browser
DEBUG - 2016-11-28 00:49:53 --> Total execution time: 0.4845
DEBUG - 2016-11-28 00:49:54 --> Config Class Initialized
DEBUG - 2016-11-28 00:49:54 --> Hooks Class Initialized
DEBUG - 2016-11-28 00:49:54 --> Utf8 Class Initialized
DEBUG - 2016-11-28 00:49:54 --> UTF-8 Support Enabled
DEBUG - 2016-11-28 00:49:54 --> URI Class Initialized
DEBUG - 2016-11-28 00:49:54 --> Router Class Initialized
DEBUG - 2016-11-28 00:49:54 --> Output Class Initialized
DEBUG - 2016-11-28 00:49:54 --> Cache file has expired. File deleted
DEBUG - 2016-11-28 00:49:54 --> Security Class Initialized
DEBUG - 2016-11-28 00:49:54 --> Input Class Initialized
DEBUG - 2016-11-28 00:49:54 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:54 --> XSS Filtering completed
DEBUG - 2016-11-28 00:49:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-28 00:49:54 --> Language Class Initialized
DEBUG - 2016-11-28 00:49:54 --> Loader Class Initialized
DEBUG - 2016-11-28 00:49:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-28 00:49:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-28 00:49:54 --> Helper loaded: url_helper
DEBUG - 2016-11-28 00:49:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-28 00:49:54 --> Helper loaded: file_helper
DEBUG - 2016-11-28 00:49:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:49:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-28 00:49:55 --> Helper loaded: conf_helper
DEBUG - 2016-11-28 00:49:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:49:55 --> Check Exists common_helper.php: No
DEBUG - 2016-11-28 00:49:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-28 00:49:55 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:49:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-28 00:49:55 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:49:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-28 00:49:55 --> Helper loaded: form_helper
DEBUG - 2016-11-28 00:49:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-28 00:49:55 --> Helper loaded: security_helper
DEBUG - 2016-11-28 00:49:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:49:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-28 00:49:55 --> Helper loaded: lang_helper
DEBUG - 2016-11-28 00:49:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:49:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-28 00:49:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-28 00:49:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-28 00:49:55 --> Helper loaded: atlant_helper
DEBUG - 2016-11-28 00:49:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:49:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-28 00:49:55 --> Helper loaded: crypto_helper
DEBUG - 2016-11-28 00:49:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:49:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-28 00:49:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-28 00:49:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-28 00:49:55 --> Helper loaded: sidika_helper
DEBUG - 2016-11-28 00:49:55 --> Database Driver Class Initialized
DEBUG - 2016-11-28 00:49:55 --> Session Class Initialized
DEBUG - 2016-11-28 00:49:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-28 00:49:55 --> Helper loaded: string_helper
DEBUG - 2016-11-28 00:49:55 --> Session routines successfully run
DEBUG - 2016-11-28 00:49:55 --> Native_session Class Initialized
DEBUG - 2016-11-28 00:49:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-28 00:49:55 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:49:55 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:49:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-28 00:49:55 --> Controller Class Initialized
DEBUG - 2016-11-28 00:49:55 --> Carabiner: Library initialized.
DEBUG - 2016-11-28 00:49:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-28 00:49:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-28 00:49:55 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:49:55 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:49:55 --> User Agent Class Initialized
DEBUG - 2016-11-28 00:49:55 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:55 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:55 --> Model Class Initialized
DEBUG - 2016-11-28 00:49:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-11-28 00:49:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-28 00:49:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-28 00:49:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-28 00:49:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-28 00:49:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-28 00:49:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-28 00:49:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-28 00:49:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-28 00:49:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-28 00:49:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-28 00:49:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-28 00:49:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-28 00:49:55 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-11-28 00:49:55 --> Final output sent to browser
DEBUG - 2016-11-28 00:49:55 --> Total execution time: 0.3904
DEBUG - 2016-11-28 00:50:00 --> Config Class Initialized
DEBUG - 2016-11-28 00:50:00 --> Hooks Class Initialized
DEBUG - 2016-11-28 00:50:00 --> Utf8 Class Initialized
DEBUG - 2016-11-28 00:50:00 --> UTF-8 Support Enabled
DEBUG - 2016-11-28 00:50:00 --> URI Class Initialized
DEBUG - 2016-11-28 00:50:00 --> Router Class Initialized
DEBUG - 2016-11-28 00:50:00 --> Output Class Initialized
DEBUG - 2016-11-28 00:50:00 --> Cache file has expired. File deleted
DEBUG - 2016-11-28 00:50:00 --> Security Class Initialized
DEBUG - 2016-11-28 00:50:00 --> Input Class Initialized
DEBUG - 2016-11-28 00:50:00 --> XSS Filtering completed
DEBUG - 2016-11-28 00:50:00 --> XSS Filtering completed
DEBUG - 2016-11-28 00:50:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-28 00:50:00 --> Language Class Initialized
DEBUG - 2016-11-28 00:50:00 --> Loader Class Initialized
DEBUG - 2016-11-28 00:50:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-28 00:50:00 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-28 00:50:00 --> Helper loaded: url_helper
DEBUG - 2016-11-28 00:50:00 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-28 00:50:00 --> Helper loaded: file_helper
DEBUG - 2016-11-28 00:50:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:50:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-28 00:50:00 --> Helper loaded: conf_helper
DEBUG - 2016-11-28 00:50:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:50:00 --> Check Exists common_helper.php: No
DEBUG - 2016-11-28 00:50:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-28 00:50:00 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:50:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-28 00:50:00 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:50:00 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-28 00:50:00 --> Helper loaded: form_helper
DEBUG - 2016-11-28 00:50:00 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-28 00:50:00 --> Helper loaded: security_helper
DEBUG - 2016-11-28 00:50:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:50:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-28 00:50:00 --> Helper loaded: lang_helper
DEBUG - 2016-11-28 00:50:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:50:00 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-28 00:50:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-28 00:50:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-28 00:50:00 --> Helper loaded: atlant_helper
DEBUG - 2016-11-28 00:50:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:50:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-28 00:50:00 --> Helper loaded: crypto_helper
DEBUG - 2016-11-28 00:50:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:50:00 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-28 00:50:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-28 00:50:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-28 00:50:00 --> Helper loaded: sidika_helper
DEBUG - 2016-11-28 00:50:00 --> Database Driver Class Initialized
DEBUG - 2016-11-28 00:50:00 --> Session Class Initialized
DEBUG - 2016-11-28 00:50:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-28 00:50:00 --> Helper loaded: string_helper
DEBUG - 2016-11-28 00:50:00 --> Session routines successfully run
DEBUG - 2016-11-28 00:50:00 --> Native_session Class Initialized
DEBUG - 2016-11-28 00:50:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-28 00:50:00 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:50:00 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:50:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-28 00:50:00 --> Controller Class Initialized
DEBUG - 2016-11-28 00:50:00 --> Carabiner: Library initialized.
DEBUG - 2016-11-28 00:50:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-28 00:50:00 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-28 00:50:00 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:50:00 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:50:00 --> User Agent Class Initialized
DEBUG - 2016-11-28 00:50:00 --> Model Class Initialized
DEBUG - 2016-11-28 00:50:00 --> Model Class Initialized
DEBUG - 2016-11-28 00:50:00 --> Model Class Initialized
DEBUG - 2016-11-28 00:50:00 --> Model Class Initialized
DEBUG - 2016-11-28 00:50:00 --> Model Class Initialized
DEBUG - 2016-11-28 00:50:00 --> Model Class Initialized
DEBUG - 2016-11-28 00:50:00 --> Model Class Initialized
DEBUG - 2016-11-28 00:50:00 --> Model Class Initialized
DEBUG - 2016-11-28 00:50:00 --> Model Class Initialized
DEBUG - 2016-11-28 00:50:00 --> Model Class Initialized
DEBUG - 2016-11-28 00:50:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-11-28 00:50:00 --> Pagination Class Initialized
DEBUG - 2016-11-28 00:50:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-28 00:50:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-11-28 00:50:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-28 00:50:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-28 00:50:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-28 00:50:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-28 00:50:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-11-28 00:50:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-28 00:50:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-28 00:50:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-28 00:50:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-28 00:50:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-28 00:50:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-28 00:50:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-11-28 00:50:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-28 00:50:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-28 00:50:00 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-11-28 00:50:00 --> Final output sent to browser
DEBUG - 2016-11-28 00:50:00 --> Total execution time: 0.5321
DEBUG - 2016-11-28 00:50:02 --> Config Class Initialized
DEBUG - 2016-11-28 00:50:02 --> Hooks Class Initialized
DEBUG - 2016-11-28 00:50:02 --> Utf8 Class Initialized
DEBUG - 2016-11-28 00:50:02 --> UTF-8 Support Enabled
DEBUG - 2016-11-28 00:50:02 --> URI Class Initialized
DEBUG - 2016-11-28 00:50:02 --> Router Class Initialized
DEBUG - 2016-11-28 00:50:02 --> Output Class Initialized
DEBUG - 2016-11-28 00:50:02 --> Cache file has expired. File deleted
DEBUG - 2016-11-28 00:50:02 --> Security Class Initialized
DEBUG - 2016-11-28 00:50:02 --> Input Class Initialized
DEBUG - 2016-11-28 00:50:02 --> XSS Filtering completed
DEBUG - 2016-11-28 00:50:02 --> XSS Filtering completed
DEBUG - 2016-11-28 00:50:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-28 00:50:02 --> Language Class Initialized
DEBUG - 2016-11-28 00:50:02 --> Loader Class Initialized
DEBUG - 2016-11-28 00:50:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-28 00:50:02 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-28 00:50:02 --> Helper loaded: url_helper
DEBUG - 2016-11-28 00:50:02 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-28 00:50:02 --> Helper loaded: file_helper
DEBUG - 2016-11-28 00:50:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:50:02 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-28 00:50:02 --> Helper loaded: conf_helper
DEBUG - 2016-11-28 00:50:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:50:02 --> Check Exists common_helper.php: No
DEBUG - 2016-11-28 00:50:02 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-28 00:50:02 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:50:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-28 00:50:02 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:50:02 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-28 00:50:02 --> Helper loaded: form_helper
DEBUG - 2016-11-28 00:50:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-28 00:50:02 --> Helper loaded: security_helper
DEBUG - 2016-11-28 00:50:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:50:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-28 00:50:02 --> Helper loaded: lang_helper
DEBUG - 2016-11-28 00:50:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:50:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-28 00:50:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-28 00:50:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-28 00:50:02 --> Helper loaded: atlant_helper
DEBUG - 2016-11-28 00:50:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:50:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-28 00:50:02 --> Helper loaded: crypto_helper
DEBUG - 2016-11-28 00:50:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:50:02 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-28 00:50:02 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-28 00:50:02 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-28 00:50:02 --> Helper loaded: sidika_helper
DEBUG - 2016-11-28 00:50:02 --> Database Driver Class Initialized
DEBUG - 2016-11-28 00:50:02 --> Session Class Initialized
DEBUG - 2016-11-28 00:50:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-28 00:50:02 --> Helper loaded: string_helper
DEBUG - 2016-11-28 00:50:02 --> Session routines successfully run
DEBUG - 2016-11-28 00:50:02 --> Native_session Class Initialized
DEBUG - 2016-11-28 00:50:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-28 00:50:02 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:50:02 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:50:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-28 00:50:02 --> Controller Class Initialized
DEBUG - 2016-11-28 00:50:02 --> Carabiner: Library initialized.
DEBUG - 2016-11-28 00:50:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-28 00:50:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-28 00:50:02 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:50:02 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:50:02 --> User Agent Class Initialized
DEBUG - 2016-11-28 00:50:02 --> Model Class Initialized
DEBUG - 2016-11-28 00:50:02 --> Model Class Initialized
DEBUG - 2016-11-28 00:50:02 --> Model Class Initialized
DEBUG - 2016-11-28 00:50:02 --> Model Class Initialized
DEBUG - 2016-11-28 00:50:02 --> Model Class Initialized
DEBUG - 2016-11-28 00:50:02 --> Model Class Initialized
DEBUG - 2016-11-28 00:50:02 --> Model Class Initialized
DEBUG - 2016-11-28 00:50:02 --> Model Class Initialized
DEBUG - 2016-11-28 00:50:02 --> Model Class Initialized
DEBUG - 2016-11-28 00:50:02 --> Model Class Initialized
DEBUG - 2016-11-28 00:50:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-11-28 00:50:02 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:50:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-28 00:50:02 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-28 00:50:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-28 00:50:02 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8f8e2926e3f1cbfc3aa536b43cdd0626
DEBUG - 2016-11-28 00:50:02 --> Final output sent to browser
DEBUG - 2016-11-28 00:50:02 --> Total execution time: 0.6069
DEBUG - 2016-11-28 00:50:26 --> Config Class Initialized
DEBUG - 2016-11-28 00:50:26 --> Hooks Class Initialized
DEBUG - 2016-11-28 00:50:26 --> Utf8 Class Initialized
DEBUG - 2016-11-28 00:50:26 --> UTF-8 Support Enabled
DEBUG - 2016-11-28 00:50:26 --> URI Class Initialized
DEBUG - 2016-11-28 00:50:26 --> Router Class Initialized
DEBUG - 2016-11-28 00:50:26 --> Output Class Initialized
DEBUG - 2016-11-28 00:50:26 --> Cache file has expired. File deleted
DEBUG - 2016-11-28 00:50:26 --> Security Class Initialized
DEBUG - 2016-11-28 00:50:26 --> Input Class Initialized
DEBUG - 2016-11-28 00:50:26 --> XSS Filtering completed
DEBUG - 2016-11-28 00:50:26 --> XSS Filtering completed
DEBUG - 2016-11-28 00:50:26 --> XSS Filtering completed
DEBUG - 2016-11-28 00:50:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-28 00:50:26 --> Language Class Initialized
DEBUG - 2016-11-28 00:50:26 --> Loader Class Initialized
DEBUG - 2016-11-28 00:50:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-28 00:50:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-28 00:50:26 --> Helper loaded: url_helper
DEBUG - 2016-11-28 00:50:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-28 00:50:26 --> Helper loaded: file_helper
DEBUG - 2016-11-28 00:50:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:50:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-28 00:50:26 --> Helper loaded: conf_helper
DEBUG - 2016-11-28 00:50:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-28 00:50:26 --> Check Exists common_helper.php: No
DEBUG - 2016-11-28 00:50:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-28 00:50:26 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:50:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-28 00:50:26 --> Helper loaded: common_helper
DEBUG - 2016-11-28 00:50:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-28 00:50:26 --> Helper loaded: form_helper
DEBUG - 2016-11-28 00:50:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-28 00:50:26 --> Helper loaded: security_helper
DEBUG - 2016-11-28 00:50:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:50:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-28 00:50:26 --> Helper loaded: lang_helper
DEBUG - 2016-11-28 00:50:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-28 00:50:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-28 00:50:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-28 00:50:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-28 00:50:26 --> Helper loaded: atlant_helper
DEBUG - 2016-11-28 00:50:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:50:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-28 00:50:26 --> Helper loaded: crypto_helper
DEBUG - 2016-11-28 00:50:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-28 00:50:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-28 00:50:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-28 00:50:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-28 00:50:26 --> Helper loaded: sidika_helper
DEBUG - 2016-11-28 00:50:26 --> Database Driver Class Initialized
DEBUG - 2016-11-28 00:50:26 --> Session Class Initialized
DEBUG - 2016-11-28 00:50:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-28 00:50:26 --> Helper loaded: string_helper
DEBUG - 2016-11-28 00:50:26 --> Session routines successfully run
DEBUG - 2016-11-28 00:50:26 --> Native_session Class Initialized
DEBUG - 2016-11-28 00:50:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-28 00:50:26 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:50:26 --> Form Validation Class Initialized
DEBUG - 2016-11-28 00:50:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-28 00:50:26 --> Controller Class Initialized
DEBUG - 2016-11-28 00:50:26 --> Carabiner: Library initialized.
DEBUG - 2016-11-28 00:50:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-28 00:50:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-28 00:50:26 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:50:26 --> Carabiner: library configured.
DEBUG - 2016-11-28 00:50:26 --> User Agent Class Initialized
DEBUG - 2016-11-28 00:50:26 --> Model Class Initialized
DEBUG - 2016-11-28 00:50:26 --> Model Class Initialized
DEBUG - 2016-11-28 00:50:26 --> Model Class Initialized
DEBUG - 2016-11-28 00:50:26 --> Model Class Initialized
DEBUG - 2016-11-28 00:50:26 --> Model Class Initialized
DEBUG - 2016-11-28 00:50:26 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5b757aabce4b284c04cf4ac1cfc7451e
DEBUG - 2016-11-28 00:50:26 --> Final output sent to browser
DEBUG - 2016-11-28 00:50:26 --> Total execution time: 0.5205
