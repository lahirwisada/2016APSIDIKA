<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-09-14 08:32:01 --> Config Class Initialized
DEBUG - 2016-09-14 08:32:01 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:32:01 --> Utf8 Class Initialized
DEBUG - 2016-09-14 08:32:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 08:32:01 --> URI Class Initialized
DEBUG - 2016-09-14 08:32:01 --> Router Class Initialized
DEBUG - 2016-09-14 08:32:01 --> Output Class Initialized
DEBUG - 2016-09-14 08:32:01 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 08:32:01 --> Security Class Initialized
DEBUG - 2016-09-14 08:32:01 --> Input Class Initialized
DEBUG - 2016-09-14 08:32:01 --> XSS Filtering completed
DEBUG - 2016-09-14 08:32:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 08:32:01 --> Language Class Initialized
DEBUG - 2016-09-14 08:32:01 --> Loader Class Initialized
DEBUG - 2016-09-14 08:32:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 08:32:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 08:32:01 --> Helper loaded: url_helper
DEBUG - 2016-09-14 08:32:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 08:32:01 --> Helper loaded: file_helper
DEBUG - 2016-09-14 08:32:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 08:32:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 08:32:01 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 08:32:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 08:32:01 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 08:32:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 08:32:01 --> Helper loaded: common_helper
DEBUG - 2016-09-14 08:32:01 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 08:32:01 --> Helper loaded: common_helper
DEBUG - 2016-09-14 08:32:01 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 08:32:01 --> Helper loaded: form_helper
DEBUG - 2016-09-14 08:32:01 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 08:32:01 --> Helper loaded: security_helper
DEBUG - 2016-09-14 08:32:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 08:32:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 08:32:01 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 08:32:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 08:32:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 08:32:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 08:32:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 08:32:01 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 08:32:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 08:32:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 08:32:01 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 08:32:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 08:32:01 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 08:32:01 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 08:32:01 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 08:32:01 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 08:32:01 --> Database Driver Class Initialized
DEBUG - 2016-09-14 08:32:02 --> Session Class Initialized
DEBUG - 2016-09-14 08:32:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 08:32:02 --> Helper loaded: string_helper
DEBUG - 2016-09-14 08:32:02 --> A session cookie was not found.
DEBUG - 2016-09-14 08:32:02 --> Session routines successfully run
DEBUG - 2016-09-14 08:32:02 --> Native_session Class Initialized
DEBUG - 2016-09-14 08:32:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 08:32:02 --> Form Validation Class Initialized
DEBUG - 2016-09-14 08:32:02 --> Form Validation Class Initialized
DEBUG - 2016-09-14 08:32:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 08:32:02 --> Controller Class Initialized
DEBUG - 2016-09-14 08:32:02 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 08:32:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 08:32:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 08:32:02 --> Carabiner: library configured.
DEBUG - 2016-09-14 08:32:02 --> Carabiner: library configured.
DEBUG - 2016-09-14 08:32:02 --> User Agent Class Initialized
DEBUG - 2016-09-14 08:32:02 --> Model Class Initialized
DEBUG - 2016-09-14 08:32:02 --> Model Class Initialized
DEBUG - 2016-09-14 08:32:02 --> Model Class Initialized
DEBUG - 2016-09-14 08:32:02 --> Model Class Initialized
DEBUG - 2016-09-14 08:32:02 --> Model Class Initialized
DEBUG - 2016-09-14 08:32:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-14 08:32:02 --> Pagination Class Initialized
DEBUG - 2016-09-14 08:32:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-14 08:32:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/index.php
DEBUG - 2016-09-14 08:32:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-14 08:32:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-14 08:32:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 08:32:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 08:32:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-09-14 08:32:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 08:32:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-14 08:32:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-14 08:32:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-14 08:32:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 08:32:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 08:32:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-09-14 08:32:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 08:32:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-14 08:32:02 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/860bebf57fee032e24acce1c64d1c3e7
DEBUG - 2016-09-14 08:32:02 --> Final output sent to browser
DEBUG - 2016-09-14 08:32:02 --> Total execution time: 0.1977
DEBUG - 2016-09-14 08:32:04 --> Config Class Initialized
DEBUG - 2016-09-14 08:32:04 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:32:04 --> Utf8 Class Initialized
DEBUG - 2016-09-14 08:32:04 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 08:32:04 --> URI Class Initialized
DEBUG - 2016-09-14 08:32:04 --> Router Class Initialized
DEBUG - 2016-09-14 08:32:04 --> No URI present. Default controller set.
DEBUG - 2016-09-14 08:32:04 --> Output Class Initialized
DEBUG - 2016-09-14 08:32:04 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 08:32:04 --> Security Class Initialized
DEBUG - 2016-09-14 08:32:04 --> Input Class Initialized
DEBUG - 2016-09-14 08:32:04 --> XSS Filtering completed
DEBUG - 2016-09-14 08:32:04 --> XSS Filtering completed
DEBUG - 2016-09-14 08:32:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 08:32:04 --> Language Class Initialized
DEBUG - 2016-09-14 08:32:04 --> Loader Class Initialized
DEBUG - 2016-09-14 08:32:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 08:32:04 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 08:32:04 --> Helper loaded: url_helper
DEBUG - 2016-09-14 08:32:04 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 08:32:04 --> Helper loaded: file_helper
DEBUG - 2016-09-14 08:32:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 08:32:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 08:32:04 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 08:32:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 08:32:04 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 08:32:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 08:32:04 --> Helper loaded: common_helper
DEBUG - 2016-09-14 08:32:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 08:32:04 --> Helper loaded: common_helper
DEBUG - 2016-09-14 08:32:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 08:32:04 --> Helper loaded: form_helper
DEBUG - 2016-09-14 08:32:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 08:32:04 --> Helper loaded: security_helper
DEBUG - 2016-09-14 08:32:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 08:32:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 08:32:04 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 08:32:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 08:32:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 08:32:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 08:32:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 08:32:04 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 08:32:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 08:32:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 08:32:04 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 08:32:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 08:32:04 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 08:32:04 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 08:32:04 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 08:32:04 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 08:32:04 --> Database Driver Class Initialized
DEBUG - 2016-09-14 08:32:04 --> Session Class Initialized
DEBUG - 2016-09-14 08:32:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 08:32:04 --> Helper loaded: string_helper
DEBUG - 2016-09-14 08:32:04 --> Session routines successfully run
DEBUG - 2016-09-14 08:32:04 --> Native_session Class Initialized
DEBUG - 2016-09-14 08:32:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 08:32:04 --> Form Validation Class Initialized
DEBUG - 2016-09-14 08:32:04 --> Form Validation Class Initialized
DEBUG - 2016-09-14 08:32:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 08:32:04 --> Controller Class Initialized
DEBUG - 2016-09-14 08:32:04 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 08:32:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 08:32:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 08:32:04 --> Carabiner: library configured.
DEBUG - 2016-09-14 08:32:04 --> Carabiner: library configured.
DEBUG - 2016-09-14 08:32:04 --> User Agent Class Initialized
DEBUG - 2016-09-14 08:32:04 --> Model Class Initialized
DEBUG - 2016-09-14 08:32:04 --> Model Class Initialized
DEBUG - 2016-09-14 08:32:04 --> Model Class Initialized
ERROR - 2016-09-14 08:32:04 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 08:32:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 08:32:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 08:32:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 08:32:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 08:32:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 08:32:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 08:32:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 08:32:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 08:32:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 08:32:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 08:32:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 08:32:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 08:32:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 08:32:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 08:32:04 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-14 08:32:04 --> Final output sent to browser
DEBUG - 2016-09-14 08:32:04 --> Total execution time: 0.1733
DEBUG - 2016-09-14 08:32:08 --> Config Class Initialized
DEBUG - 2016-09-14 08:32:08 --> Hooks Class Initialized
DEBUG - 2016-09-14 08:32:08 --> Utf8 Class Initialized
DEBUG - 2016-09-14 08:32:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 08:32:08 --> URI Class Initialized
DEBUG - 2016-09-14 08:32:08 --> Router Class Initialized
DEBUG - 2016-09-14 08:32:08 --> No URI present. Default controller set.
DEBUG - 2016-09-14 08:32:08 --> Output Class Initialized
DEBUG - 2016-09-14 08:32:08 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 08:32:08 --> Security Class Initialized
DEBUG - 2016-09-14 08:32:08 --> Input Class Initialized
DEBUG - 2016-09-14 08:32:08 --> XSS Filtering completed
DEBUG - 2016-09-14 08:32:08 --> XSS Filtering completed
DEBUG - 2016-09-14 08:32:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 08:32:08 --> Language Class Initialized
DEBUG - 2016-09-14 08:32:08 --> Loader Class Initialized
DEBUG - 2016-09-14 08:32:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 08:32:08 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 08:32:08 --> Helper loaded: url_helper
DEBUG - 2016-09-14 08:32:08 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 08:32:08 --> Helper loaded: file_helper
DEBUG - 2016-09-14 08:32:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 08:32:08 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 08:32:08 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 08:32:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 08:32:08 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 08:32:08 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 08:32:08 --> Helper loaded: common_helper
DEBUG - 2016-09-14 08:32:08 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 08:32:08 --> Helper loaded: common_helper
DEBUG - 2016-09-14 08:32:08 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 08:32:08 --> Helper loaded: form_helper
DEBUG - 2016-09-14 08:32:08 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 08:32:08 --> Helper loaded: security_helper
DEBUG - 2016-09-14 08:32:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 08:32:08 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 08:32:08 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 08:32:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 08:32:08 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 08:32:08 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 08:32:08 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 08:32:08 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 08:32:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 08:32:08 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 08:32:08 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 08:32:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 08:32:08 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 08:32:08 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 08:32:08 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 08:32:08 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 08:32:08 --> Database Driver Class Initialized
DEBUG - 2016-09-14 08:32:08 --> Session Class Initialized
DEBUG - 2016-09-14 08:32:08 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 08:32:08 --> Helper loaded: string_helper
DEBUG - 2016-09-14 08:32:08 --> Session routines successfully run
DEBUG - 2016-09-14 08:32:08 --> Native_session Class Initialized
DEBUG - 2016-09-14 08:32:08 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 08:32:08 --> Form Validation Class Initialized
DEBUG - 2016-09-14 08:32:08 --> Form Validation Class Initialized
DEBUG - 2016-09-14 08:32:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 08:32:08 --> Controller Class Initialized
DEBUG - 2016-09-14 08:32:08 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 08:32:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 08:32:08 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 08:32:08 --> Carabiner: library configured.
DEBUG - 2016-09-14 08:32:08 --> Carabiner: library configured.
DEBUG - 2016-09-14 08:32:08 --> User Agent Class Initialized
DEBUG - 2016-09-14 08:32:08 --> Model Class Initialized
DEBUG - 2016-09-14 08:32:08 --> Model Class Initialized
DEBUG - 2016-09-14 08:32:08 --> Model Class Initialized
ERROR - 2016-09-14 08:32:08 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 08:32:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 08:32:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 08:32:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 08:32:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 08:32:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 08:32:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 08:32:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 08:32:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 08:32:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 08:32:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 08:32:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 08:32:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 08:32:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 08:32:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 08:32:08 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-14 08:32:08 --> Final output sent to browser
DEBUG - 2016-09-14 08:32:08 --> Total execution time: 0.2226
DEBUG - 2016-09-14 12:20:43 --> Config Class Initialized
DEBUG - 2016-09-14 12:20:43 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:20:43 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:20:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:20:43 --> URI Class Initialized
DEBUG - 2016-09-14 12:20:43 --> Router Class Initialized
DEBUG - 2016-09-14 12:20:43 --> No URI present. Default controller set.
DEBUG - 2016-09-14 12:20:43 --> Output Class Initialized
DEBUG - 2016-09-14 12:20:43 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 12:20:43 --> Security Class Initialized
DEBUG - 2016-09-14 12:20:43 --> Input Class Initialized
DEBUG - 2016-09-14 12:20:43 --> XSS Filtering completed
DEBUG - 2016-09-14 12:20:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:20:43 --> Language Class Initialized
DEBUG - 2016-09-14 12:20:43 --> Loader Class Initialized
DEBUG - 2016-09-14 12:20:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:20:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:20:43 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:20:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:20:43 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:20:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:20:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:20:43 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:20:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:20:43 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:20:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:20:43 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:20:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:20:43 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:20:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:20:43 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:20:43 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:20:43 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:20:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:20:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:20:43 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:20:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:20:43 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:20:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:20:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:20:43 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:20:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:20:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:20:43 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:20:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:20:43 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:20:43 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:20:43 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:20:43 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:20:43 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:20:43 --> Session Class Initialized
DEBUG - 2016-09-14 12:20:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:20:43 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:20:43 --> A session cookie was not found.
DEBUG - 2016-09-14 12:20:43 --> Session routines successfully run
DEBUG - 2016-09-14 12:20:43 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:20:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:20:43 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:20:43 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:20:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:20:43 --> Controller Class Initialized
DEBUG - 2016-09-14 12:20:43 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:20:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:20:43 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:20:43 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:20:43 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:20:43 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:20:43 --> Model Class Initialized
DEBUG - 2016-09-14 12:20:43 --> Model Class Initialized
DEBUG - 2016-09-14 12:20:43 --> Model Class Initialized
ERROR - 2016-09-14 12:20:43 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:20:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:20:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:20:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:20:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:20:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:20:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:20:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:20:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:20:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:20:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:20:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:20:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:20:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:20:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:20:44 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-14 12:20:44 --> Final output sent to browser
DEBUG - 2016-09-14 12:20:44 --> Total execution time: 0.3976
DEBUG - 2016-09-14 12:25:43 --> Config Class Initialized
DEBUG - 2016-09-14 12:25:43 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:25:43 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:25:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:25:43 --> URI Class Initialized
DEBUG - 2016-09-14 12:25:43 --> Router Class Initialized
DEBUG - 2016-09-14 12:25:43 --> No URI present. Default controller set.
DEBUG - 2016-09-14 12:25:43 --> Output Class Initialized
DEBUG - 2016-09-14 12:25:43 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 12:25:43 --> Security Class Initialized
DEBUG - 2016-09-14 12:25:43 --> Input Class Initialized
DEBUG - 2016-09-14 12:25:43 --> XSS Filtering completed
DEBUG - 2016-09-14 12:25:43 --> XSS Filtering completed
DEBUG - 2016-09-14 12:25:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:25:43 --> Language Class Initialized
DEBUG - 2016-09-14 12:25:43 --> Loader Class Initialized
DEBUG - 2016-09-14 12:25:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:25:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:25:43 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:25:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:25:43 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:25:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:25:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:25:43 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:25:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:25:43 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:25:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:25:43 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:25:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:25:43 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:25:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:25:43 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:25:43 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:25:43 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:25:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:25:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:25:43 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:25:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:25:43 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:25:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:25:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:25:43 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:25:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:25:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:25:43 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:25:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:25:43 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:25:43 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:25:43 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:25:43 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:25:43 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:25:43 --> Session Class Initialized
DEBUG - 2016-09-14 12:25:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:25:43 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:25:43 --> Session routines successfully run
DEBUG - 2016-09-14 12:25:43 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:25:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:25:43 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:25:43 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:25:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:25:43 --> Controller Class Initialized
DEBUG - 2016-09-14 12:25:43 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:25:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:25:43 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:25:43 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:25:43 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:25:43 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:25:43 --> Model Class Initialized
DEBUG - 2016-09-14 12:25:43 --> Model Class Initialized
DEBUG - 2016-09-14 12:25:43 --> Model Class Initialized
ERROR - 2016-09-14 12:25:43 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:25:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:25:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:25:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:25:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:25:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:25:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:25:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:25:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:25:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:25:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:25:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:25:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:25:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:25:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:25:43 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-14 12:25:43 --> Final output sent to browser
DEBUG - 2016-09-14 12:25:43 --> Total execution time: 0.2308
DEBUG - 2016-09-14 12:25:56 --> Config Class Initialized
DEBUG - 2016-09-14 12:25:56 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:25:56 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:25:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:25:56 --> URI Class Initialized
DEBUG - 2016-09-14 12:25:56 --> Router Class Initialized
DEBUG - 2016-09-14 12:25:56 --> No URI present. Default controller set.
DEBUG - 2016-09-14 12:25:56 --> Output Class Initialized
DEBUG - 2016-09-14 12:25:56 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 12:25:56 --> Security Class Initialized
DEBUG - 2016-09-14 12:25:56 --> Input Class Initialized
DEBUG - 2016-09-14 12:25:56 --> XSS Filtering completed
DEBUG - 2016-09-14 12:25:56 --> XSS Filtering completed
DEBUG - 2016-09-14 12:25:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:25:56 --> Language Class Initialized
DEBUG - 2016-09-14 12:25:56 --> Loader Class Initialized
DEBUG - 2016-09-14 12:25:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:25:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:25:56 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:25:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:25:56 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:25:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:25:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:25:56 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:25:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:25:56 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:25:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:25:56 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:25:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:25:56 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:25:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:25:56 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:25:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:25:56 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:25:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:25:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:25:56 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:25:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:25:56 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:25:56 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:25:56 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:25:56 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:25:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:25:56 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:25:56 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:25:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:25:56 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:25:56 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:25:56 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:25:56 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:25:56 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:25:56 --> Session Class Initialized
DEBUG - 2016-09-14 12:25:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:25:57 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:25:57 --> Session routines successfully run
DEBUG - 2016-09-14 12:25:57 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:25:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:25:57 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:25:57 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:25:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:25:57 --> Controller Class Initialized
DEBUG - 2016-09-14 12:25:57 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:25:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:25:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:25:57 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:25:57 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:25:57 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:25:57 --> Model Class Initialized
DEBUG - 2016-09-14 12:25:57 --> Model Class Initialized
DEBUG - 2016-09-14 12:25:57 --> Model Class Initialized
ERROR - 2016-09-14 12:25:57 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:25:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:25:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:25:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:25:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:25:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:25:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:25:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:25:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:25:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:25:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:25:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:25:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:25:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:25:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:25:57 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-14 12:25:57 --> Final output sent to browser
DEBUG - 2016-09-14 12:25:57 --> Total execution time: 0.2611
DEBUG - 2016-09-14 12:27:50 --> Config Class Initialized
DEBUG - 2016-09-14 12:27:50 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:27:50 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:27:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:27:50 --> URI Class Initialized
DEBUG - 2016-09-14 12:27:50 --> Router Class Initialized
DEBUG - 2016-09-14 12:27:50 --> No URI present. Default controller set.
DEBUG - 2016-09-14 12:27:50 --> Output Class Initialized
DEBUG - 2016-09-14 12:27:50 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 12:27:50 --> Security Class Initialized
DEBUG - 2016-09-14 12:27:50 --> Input Class Initialized
DEBUG - 2016-09-14 12:27:50 --> XSS Filtering completed
DEBUG - 2016-09-14 12:27:50 --> XSS Filtering completed
DEBUG - 2016-09-14 12:27:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:27:50 --> Language Class Initialized
DEBUG - 2016-09-14 12:27:50 --> Loader Class Initialized
DEBUG - 2016-09-14 12:27:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:27:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:27:50 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:27:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:27:50 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:27:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:27:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:27:50 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:27:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:27:50 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:27:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:27:50 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:27:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:27:50 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:27:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:27:50 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:27:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:27:50 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:27:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:27:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:27:50 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:27:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:27:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:27:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:27:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:27:50 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:27:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:27:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:27:50 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:27:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:27:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:27:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:27:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:27:50 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:27:50 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:27:50 --> Session Class Initialized
DEBUG - 2016-09-14 12:27:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:27:50 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:27:50 --> Session routines successfully run
DEBUG - 2016-09-14 12:27:50 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:27:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:27:50 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:27:50 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:27:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:27:50 --> Controller Class Initialized
DEBUG - 2016-09-14 12:27:50 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:27:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:27:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:27:50 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:27:50 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:27:50 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:27:50 --> Model Class Initialized
DEBUG - 2016-09-14 12:27:50 --> Model Class Initialized
DEBUG - 2016-09-14 12:27:50 --> Model Class Initialized
ERROR - 2016-09-14 12:27:50 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:27:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:27:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:27:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:27:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:27:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:27:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:27:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:27:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:27:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:27:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:27:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:27:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:27:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:27:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:27:50 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-14 12:27:50 --> Final output sent to browser
DEBUG - 2016-09-14 12:27:50 --> Total execution time: 0.2761
DEBUG - 2016-09-14 12:28:06 --> Config Class Initialized
DEBUG - 2016-09-14 12:28:06 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:28:06 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:28:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:28:06 --> URI Class Initialized
DEBUG - 2016-09-14 12:28:06 --> Router Class Initialized
DEBUG - 2016-09-14 12:28:06 --> No URI present. Default controller set.
DEBUG - 2016-09-14 12:28:06 --> Output Class Initialized
DEBUG - 2016-09-14 12:28:06 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 12:28:06 --> Security Class Initialized
DEBUG - 2016-09-14 12:28:06 --> Input Class Initialized
DEBUG - 2016-09-14 12:28:06 --> XSS Filtering completed
DEBUG - 2016-09-14 12:28:06 --> XSS Filtering completed
DEBUG - 2016-09-14 12:28:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:28:06 --> Language Class Initialized
DEBUG - 2016-09-14 12:28:06 --> Loader Class Initialized
DEBUG - 2016-09-14 12:28:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:28:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:28:06 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:28:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:28:06 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:28:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:28:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:28:06 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:28:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:28:06 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:28:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:28:06 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:28:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:28:06 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:28:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:28:06 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:28:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:28:06 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:28:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:28:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:28:06 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:28:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:28:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:28:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:28:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:28:06 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:28:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:28:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:28:06 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:28:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:28:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:28:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:28:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:28:06 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:28:06 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:28:06 --> Session Class Initialized
DEBUG - 2016-09-14 12:28:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:28:06 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:28:06 --> Session routines successfully run
DEBUG - 2016-09-14 12:28:06 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:28:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:28:06 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:28:06 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:28:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:28:06 --> Controller Class Initialized
DEBUG - 2016-09-14 12:28:06 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:28:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:28:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:28:06 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:28:06 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:28:06 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:28:06 --> Model Class Initialized
DEBUG - 2016-09-14 12:28:06 --> Model Class Initialized
DEBUG - 2016-09-14 12:28:06 --> Model Class Initialized
ERROR - 2016-09-14 12:28:06 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:28:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:28:06 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-14 12:28:06 --> Final output sent to browser
DEBUG - 2016-09-14 12:28:06 --> Total execution time: 0.3088
DEBUG - 2016-09-14 12:28:25 --> Config Class Initialized
DEBUG - 2016-09-14 12:28:25 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:28:25 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:28:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:28:25 --> URI Class Initialized
DEBUG - 2016-09-14 12:28:25 --> Router Class Initialized
ERROR - 2016-09-14 12:28:25 --> 404 Page Not Found --> home
DEBUG - 2016-09-14 12:28:31 --> Config Class Initialized
DEBUG - 2016-09-14 12:28:31 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:28:31 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:28:31 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:28:31 --> URI Class Initialized
DEBUG - 2016-09-14 12:28:31 --> Router Class Initialized
DEBUG - 2016-09-14 12:28:31 --> Output Class Initialized
DEBUG - 2016-09-14 12:28:31 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 12:28:31 --> Security Class Initialized
DEBUG - 2016-09-14 12:28:31 --> Input Class Initialized
DEBUG - 2016-09-14 12:28:31 --> XSS Filtering completed
DEBUG - 2016-09-14 12:28:31 --> XSS Filtering completed
DEBUG - 2016-09-14 12:28:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:28:31 --> Language Class Initialized
DEBUG - 2016-09-14 12:28:31 --> Loader Class Initialized
DEBUG - 2016-09-14 12:28:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:28:31 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:28:31 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:28:31 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:28:31 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:28:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:28:31 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:28:31 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:28:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:28:31 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:28:31 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:28:31 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:28:31 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:28:31 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:28:31 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:28:31 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:28:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:28:32 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:28:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:28:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:28:32 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:28:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:28:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:28:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:28:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:28:32 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:28:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:28:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:28:32 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:28:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:28:32 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:28:32 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:28:32 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:28:32 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:28:32 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:28:32 --> Session Class Initialized
DEBUG - 2016-09-14 12:28:32 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:28:32 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:28:32 --> Session routines successfully run
DEBUG - 2016-09-14 12:28:32 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:28:32 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:28:32 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:28:32 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:28:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:28:32 --> Controller Class Initialized
DEBUG - 2016-09-14 12:28:32 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:28:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:28:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:28:32 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:28:32 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:28:32 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:28:32 --> Model Class Initialized
DEBUG - 2016-09-14 12:28:32 --> Model Class Initialized
DEBUG - 2016-09-14 12:28:32 --> Model Class Initialized
ERROR - 2016-09-14 12:28:32 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:28:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:28:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:28:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:28:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:28:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:28:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:28:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:28:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:28:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:28:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:28:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:28:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:28:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:28:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:28:32 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 12:28:32 --> Final output sent to browser
DEBUG - 2016-09-14 12:28:32 --> Total execution time: 0.3726
DEBUG - 2016-09-14 12:28:38 --> Config Class Initialized
DEBUG - 2016-09-14 12:28:38 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:28:38 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:28:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:28:38 --> URI Class Initialized
DEBUG - 2016-09-14 12:28:38 --> Router Class Initialized
DEBUG - 2016-09-14 12:28:38 --> Output Class Initialized
DEBUG - 2016-09-14 12:28:38 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 12:28:38 --> Security Class Initialized
DEBUG - 2016-09-14 12:28:38 --> Input Class Initialized
DEBUG - 2016-09-14 12:28:38 --> XSS Filtering completed
DEBUG - 2016-09-14 12:28:38 --> XSS Filtering completed
DEBUG - 2016-09-14 12:28:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:28:38 --> Language Class Initialized
DEBUG - 2016-09-14 12:28:38 --> Loader Class Initialized
DEBUG - 2016-09-14 12:28:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:28:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:28:38 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:28:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:28:38 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:28:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:28:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:28:38 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:28:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:28:38 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:28:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:28:38 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:28:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:28:38 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:28:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:28:38 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:28:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:28:38 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:28:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:28:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:28:38 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:28:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:28:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:28:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:28:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:28:38 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:28:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:28:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:28:38 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:28:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:28:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:28:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:28:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:28:38 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:28:38 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:28:38 --> Session Class Initialized
DEBUG - 2016-09-14 12:28:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:28:38 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:28:38 --> Session routines successfully run
DEBUG - 2016-09-14 12:28:38 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:28:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:28:38 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:28:38 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:28:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:28:38 --> Controller Class Initialized
DEBUG - 2016-09-14 12:28:38 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:28:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:28:38 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:28:38 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:28:38 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:28:38 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:28:38 --> Model Class Initialized
DEBUG - 2016-09-14 12:28:38 --> Model Class Initialized
DEBUG - 2016-09-14 12:28:38 --> Model Class Initialized
ERROR - 2016-09-14 12:28:38 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:28:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:28:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:28:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:28:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:28:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:28:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:28:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:28:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:28:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:28:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:28:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:28:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:28:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:28:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:28:38 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 12:28:38 --> Final output sent to browser
DEBUG - 2016-09-14 12:28:38 --> Total execution time: 0.3472
DEBUG - 2016-09-14 12:29:22 --> Config Class Initialized
DEBUG - 2016-09-14 12:29:22 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:29:22 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:29:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:29:22 --> URI Class Initialized
DEBUG - 2016-09-14 12:29:22 --> Router Class Initialized
DEBUG - 2016-09-14 12:29:22 --> Output Class Initialized
DEBUG - 2016-09-14 12:29:22 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 12:29:22 --> Security Class Initialized
DEBUG - 2016-09-14 12:29:22 --> Input Class Initialized
DEBUG - 2016-09-14 12:29:22 --> XSS Filtering completed
DEBUG - 2016-09-14 12:29:22 --> XSS Filtering completed
DEBUG - 2016-09-14 12:29:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:29:22 --> Language Class Initialized
DEBUG - 2016-09-14 12:29:22 --> Loader Class Initialized
DEBUG - 2016-09-14 12:29:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:29:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:29:22 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:29:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:29:22 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:29:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:29:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:29:22 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:29:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:29:22 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:29:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:29:22 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:29:22 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:29:22 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:29:22 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:29:22 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:29:22 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:29:22 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:29:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:29:22 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:29:22 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:29:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:29:22 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:29:22 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:29:22 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:29:22 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:29:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:29:22 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:29:22 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:29:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:29:22 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:29:22 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:29:22 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:29:22 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:29:22 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:29:22 --> Session Class Initialized
DEBUG - 2016-09-14 12:29:22 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:29:22 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:29:22 --> Session routines successfully run
DEBUG - 2016-09-14 12:29:22 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:29:22 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:29:22 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:29:22 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:29:22 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:29:22 --> Controller Class Initialized
DEBUG - 2016-09-14 12:29:22 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:29:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:29:22 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:29:22 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:29:22 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:29:22 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:29:22 --> Model Class Initialized
DEBUG - 2016-09-14 12:29:22 --> Model Class Initialized
DEBUG - 2016-09-14 12:29:22 --> Model Class Initialized
ERROR - 2016-09-14 12:29:22 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:29:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:29:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:29:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:29:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:29:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:29:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:29:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:29:53 --> Config Class Initialized
DEBUG - 2016-09-14 12:29:53 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:29:53 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:29:53 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:29:53 --> URI Class Initialized
DEBUG - 2016-09-14 12:29:53 --> Router Class Initialized
DEBUG - 2016-09-14 12:29:53 --> Output Class Initialized
DEBUG - 2016-09-14 12:29:53 --> Security Class Initialized
DEBUG - 2016-09-14 12:29:53 --> Input Class Initialized
DEBUG - 2016-09-14 12:29:53 --> XSS Filtering completed
DEBUG - 2016-09-14 12:29:53 --> XSS Filtering completed
DEBUG - 2016-09-14 12:29:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:29:53 --> Language Class Initialized
DEBUG - 2016-09-14 12:29:53 --> Loader Class Initialized
DEBUG - 2016-09-14 12:29:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:29:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:29:53 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:29:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:29:53 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:29:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:29:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:29:53 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:29:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:29:53 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:29:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:29:53 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:29:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:29:53 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:29:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:29:53 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:29:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:29:53 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:29:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:29:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:29:53 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:29:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:29:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:29:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:29:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:29:53 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:29:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:29:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:29:53 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:29:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:29:53 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:29:53 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:29:53 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:29:53 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:29:53 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:29:53 --> Session Class Initialized
DEBUG - 2016-09-14 12:29:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:29:53 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:29:53 --> Session routines successfully run
DEBUG - 2016-09-14 12:29:53 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:29:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:29:53 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:29:53 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:29:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:29:53 --> Controller Class Initialized
DEBUG - 2016-09-14 12:29:53 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:29:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:29:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:29:53 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:29:53 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:29:53 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:29:53 --> Model Class Initialized
DEBUG - 2016-09-14 12:29:53 --> Model Class Initialized
DEBUG - 2016-09-14 12:29:53 --> Model Class Initialized
ERROR - 2016-09-14 12:29:53 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:29:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:29:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:29:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:29:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:29:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:29:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:29:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:30:25 --> Config Class Initialized
DEBUG - 2016-09-14 12:30:25 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:30:25 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:30:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:30:25 --> URI Class Initialized
DEBUG - 2016-09-14 12:30:25 --> Router Class Initialized
DEBUG - 2016-09-14 12:30:25 --> Output Class Initialized
DEBUG - 2016-09-14 12:30:25 --> Security Class Initialized
DEBUG - 2016-09-14 12:30:25 --> Input Class Initialized
DEBUG - 2016-09-14 12:30:25 --> XSS Filtering completed
DEBUG - 2016-09-14 12:30:25 --> XSS Filtering completed
DEBUG - 2016-09-14 12:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:30:25 --> Language Class Initialized
DEBUG - 2016-09-14 12:30:25 --> Loader Class Initialized
DEBUG - 2016-09-14 12:30:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:30:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:30:25 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:30:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:30:25 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:30:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:30:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:30:25 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:30:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:30:25 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:30:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:30:25 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:30:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:30:25 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:30:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:30:25 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:30:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:30:25 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:30:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:30:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:30:25 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:30:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:30:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:30:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:30:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:30:25 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:30:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:30:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:30:25 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:30:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:30:25 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:30:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:30:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:30:25 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:30:25 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:30:25 --> Session Class Initialized
DEBUG - 2016-09-14 12:30:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:30:25 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:30:25 --> Session routines successfully run
DEBUG - 2016-09-14 12:30:25 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:30:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:30:25 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:30:25 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:30:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:30:25 --> Controller Class Initialized
DEBUG - 2016-09-14 12:30:25 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:30:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:30:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:30:25 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:30:25 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:30:25 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:30:25 --> Model Class Initialized
DEBUG - 2016-09-14 12:30:25 --> Model Class Initialized
DEBUG - 2016-09-14 12:30:25 --> Model Class Initialized
ERROR - 2016-09-14 12:30:25 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:30:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:30:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:30:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:30:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:30:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:30:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:30:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:31:03 --> Config Class Initialized
DEBUG - 2016-09-14 12:31:03 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:31:03 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:31:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:31:03 --> URI Class Initialized
DEBUG - 2016-09-14 12:31:03 --> Router Class Initialized
DEBUG - 2016-09-14 12:31:03 --> Output Class Initialized
DEBUG - 2016-09-14 12:31:03 --> Security Class Initialized
DEBUG - 2016-09-14 12:31:03 --> Input Class Initialized
DEBUG - 2016-09-14 12:31:03 --> XSS Filtering completed
DEBUG - 2016-09-14 12:31:03 --> XSS Filtering completed
DEBUG - 2016-09-14 12:31:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:31:03 --> Language Class Initialized
DEBUG - 2016-09-14 12:31:03 --> Loader Class Initialized
DEBUG - 2016-09-14 12:31:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:31:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:31:03 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:31:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:31:03 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:31:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:31:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:31:03 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:31:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:31:03 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:31:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:31:03 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:31:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:31:03 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:31:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:31:03 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:31:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:31:03 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:31:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:31:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:31:03 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:31:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:31:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:31:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:31:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:31:03 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:31:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:31:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:31:04 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:31:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:31:04 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:31:04 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:31:04 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:31:04 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:31:04 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:31:04 --> Session Class Initialized
DEBUG - 2016-09-14 12:31:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:31:04 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:31:04 --> Session routines successfully run
DEBUG - 2016-09-14 12:31:04 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:31:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:31:04 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:31:04 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:31:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:31:04 --> Controller Class Initialized
DEBUG - 2016-09-14 12:31:04 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:31:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:31:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:31:04 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:31:04 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:31:04 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:31:04 --> Model Class Initialized
DEBUG - 2016-09-14 12:31:04 --> Model Class Initialized
DEBUG - 2016-09-14 12:31:04 --> Model Class Initialized
ERROR - 2016-09-14 12:31:04 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:31:39 --> Config Class Initialized
DEBUG - 2016-09-14 12:31:39 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:31:39 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:31:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:31:39 --> URI Class Initialized
DEBUG - 2016-09-14 12:31:39 --> Router Class Initialized
DEBUG - 2016-09-14 12:31:39 --> Output Class Initialized
DEBUG - 2016-09-14 12:31:39 --> Security Class Initialized
DEBUG - 2016-09-14 12:31:39 --> Input Class Initialized
DEBUG - 2016-09-14 12:31:39 --> XSS Filtering completed
DEBUG - 2016-09-14 12:31:39 --> XSS Filtering completed
DEBUG - 2016-09-14 12:31:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:31:39 --> Language Class Initialized
DEBUG - 2016-09-14 12:31:39 --> Loader Class Initialized
DEBUG - 2016-09-14 12:31:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:31:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:31:39 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:31:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:31:39 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:31:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:31:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:31:39 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:31:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:31:39 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:31:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:31:39 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:31:39 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:31:39 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:31:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:31:39 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:31:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:31:39 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:31:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:31:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:31:39 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:31:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:31:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:31:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:31:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:31:39 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:31:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:31:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:31:39 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:31:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:31:39 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:31:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:31:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:31:39 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:31:39 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:31:39 --> Session Class Initialized
DEBUG - 2016-09-14 12:31:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:31:39 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:31:39 --> Session routines successfully run
DEBUG - 2016-09-14 12:31:39 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:31:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:31:39 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:31:39 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:31:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:31:39 --> Controller Class Initialized
DEBUG - 2016-09-14 12:31:39 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:31:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:31:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:31:39 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:31:39 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:31:39 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:31:39 --> Model Class Initialized
DEBUG - 2016-09-14 12:31:39 --> Model Class Initialized
DEBUG - 2016-09-14 12:31:39 --> Model Class Initialized
ERROR - 2016-09-14 12:31:39 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:31:56 --> Config Class Initialized
DEBUG - 2016-09-14 12:31:56 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:31:56 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:31:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:31:56 --> URI Class Initialized
DEBUG - 2016-09-14 12:31:56 --> Router Class Initialized
DEBUG - 2016-09-14 12:31:56 --> Output Class Initialized
DEBUG - 2016-09-14 12:31:56 --> Security Class Initialized
DEBUG - 2016-09-14 12:31:56 --> Input Class Initialized
DEBUG - 2016-09-14 12:31:56 --> XSS Filtering completed
DEBUG - 2016-09-14 12:31:56 --> XSS Filtering completed
DEBUG - 2016-09-14 12:31:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:31:56 --> Language Class Initialized
DEBUG - 2016-09-14 12:31:56 --> Loader Class Initialized
DEBUG - 2016-09-14 12:31:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:31:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:31:56 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:31:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:31:56 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:31:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:31:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:31:56 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:31:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:31:56 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:31:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:31:56 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:31:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:31:56 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:31:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:31:56 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:31:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:31:56 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:31:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:31:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:31:56 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:31:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:31:56 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:31:56 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:31:56 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:31:56 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:31:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:31:56 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:31:56 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:31:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:31:56 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:31:56 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:31:56 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:31:56 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:31:56 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:31:56 --> Session Class Initialized
DEBUG - 2016-09-14 12:31:56 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:31:56 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:31:56 --> Session routines successfully run
DEBUG - 2016-09-14 12:31:56 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:31:56 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:31:56 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:31:56 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:31:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:31:56 --> Controller Class Initialized
DEBUG - 2016-09-14 12:31:56 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:31:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:31:56 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:31:56 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:31:56 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:31:56 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:31:56 --> Model Class Initialized
DEBUG - 2016-09-14 12:31:56 --> Model Class Initialized
DEBUG - 2016-09-14 12:31:56 --> Model Class Initialized
ERROR - 2016-09-14 12:31:56 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:31:56 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 12:31:56 --> Final output sent to browser
DEBUG - 2016-09-14 12:31:56 --> Total execution time: 0.4031
DEBUG - 2016-09-14 12:32:05 --> Config Class Initialized
DEBUG - 2016-09-14 12:32:05 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:32:05 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:32:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:32:05 --> URI Class Initialized
DEBUG - 2016-09-14 12:32:05 --> Router Class Initialized
DEBUG - 2016-09-14 12:32:05 --> Output Class Initialized
DEBUG - 2016-09-14 12:32:05 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 12:32:05 --> Security Class Initialized
DEBUG - 2016-09-14 12:32:05 --> Input Class Initialized
DEBUG - 2016-09-14 12:32:05 --> XSS Filtering completed
DEBUG - 2016-09-14 12:32:05 --> XSS Filtering completed
DEBUG - 2016-09-14 12:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:32:05 --> Language Class Initialized
DEBUG - 2016-09-14 12:32:05 --> Loader Class Initialized
DEBUG - 2016-09-14 12:32:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:32:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:32:05 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:32:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:32:05 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:32:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:32:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:32:05 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:32:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:32:05 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:32:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:32:05 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:32:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:32:05 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:32:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:32:05 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:32:05 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:32:05 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:32:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:32:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:32:05 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:32:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:32:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:32:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:32:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:32:05 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:32:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:32:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:32:05 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:32:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:32:05 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:32:05 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:32:05 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:32:05 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:32:05 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:32:05 --> Session Class Initialized
DEBUG - 2016-09-14 12:32:05 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:32:05 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:32:05 --> Session routines successfully run
DEBUG - 2016-09-14 12:32:05 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:32:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:32:05 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:32:05 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:32:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:32:05 --> Controller Class Initialized
DEBUG - 2016-09-14 12:32:05 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:32:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:32:05 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:32:05 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:32:05 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:32:06 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:32:06 --> Model Class Initialized
DEBUG - 2016-09-14 12:32:06 --> Model Class Initialized
DEBUG - 2016-09-14 12:32:06 --> Model Class Initialized
ERROR - 2016-09-14 12:32:06 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:32:06 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 12:32:06 --> Final output sent to browser
DEBUG - 2016-09-14 12:32:06 --> Total execution time: 0.4328
DEBUG - 2016-09-14 12:32:15 --> Config Class Initialized
DEBUG - 2016-09-14 12:32:15 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:32:15 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:32:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:32:15 --> URI Class Initialized
DEBUG - 2016-09-14 12:32:15 --> Router Class Initialized
DEBUG - 2016-09-14 12:32:15 --> Output Class Initialized
DEBUG - 2016-09-14 12:32:15 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 12:32:15 --> Security Class Initialized
DEBUG - 2016-09-14 12:32:15 --> Input Class Initialized
DEBUG - 2016-09-14 12:32:15 --> XSS Filtering completed
DEBUG - 2016-09-14 12:32:15 --> XSS Filtering completed
DEBUG - 2016-09-14 12:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:32:15 --> Language Class Initialized
DEBUG - 2016-09-14 12:32:15 --> Loader Class Initialized
DEBUG - 2016-09-14 12:32:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:32:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:32:15 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:32:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:32:15 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:32:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:32:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:32:15 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:32:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:32:15 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:32:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:32:15 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:32:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:32:15 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:32:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:32:15 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:32:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:32:15 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:32:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:32:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:32:15 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:32:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:32:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:32:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:32:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:32:15 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:32:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:32:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:32:15 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:32:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:32:15 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:32:15 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:32:15 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:32:15 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:32:15 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:32:15 --> Session Class Initialized
DEBUG - 2016-09-14 12:32:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:32:15 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:32:15 --> Session routines successfully run
DEBUG - 2016-09-14 12:32:15 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:32:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:32:15 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:32:15 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:32:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:32:15 --> Controller Class Initialized
DEBUG - 2016-09-14 12:32:15 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:32:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:32:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:32:15 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:32:15 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:32:15 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:32:15 --> Model Class Initialized
DEBUG - 2016-09-14 12:32:15 --> Model Class Initialized
DEBUG - 2016-09-14 12:32:15 --> Model Class Initialized
ERROR - 2016-09-14 12:32:15 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:32:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:32:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:32:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:32:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:32:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:32:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:32:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:32:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:32:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:32:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:32:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:32:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:32:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:32:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:32:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:32:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:32:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:32:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:32:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:32:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:32:16 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 12:32:16 --> Final output sent to browser
DEBUG - 2016-09-14 12:32:16 --> Total execution time: 0.4502
DEBUG - 2016-09-14 12:32:30 --> Config Class Initialized
DEBUG - 2016-09-14 12:32:30 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:32:30 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:32:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:32:30 --> URI Class Initialized
DEBUG - 2016-09-14 12:32:30 --> Router Class Initialized
DEBUG - 2016-09-14 12:32:30 --> Output Class Initialized
DEBUG - 2016-09-14 12:32:30 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 12:32:30 --> Security Class Initialized
DEBUG - 2016-09-14 12:32:30 --> Input Class Initialized
DEBUG - 2016-09-14 12:32:30 --> XSS Filtering completed
DEBUG - 2016-09-14 12:32:30 --> XSS Filtering completed
DEBUG - 2016-09-14 12:32:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:32:30 --> Language Class Initialized
DEBUG - 2016-09-14 12:32:30 --> Loader Class Initialized
DEBUG - 2016-09-14 12:32:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:32:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:32:30 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:32:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:32:30 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:32:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:32:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:32:30 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:32:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:32:30 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:32:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:32:30 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:32:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:32:30 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:32:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:32:30 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:32:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:32:30 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:32:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:32:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:32:30 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:32:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:32:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:32:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:32:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:32:30 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:32:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:32:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:32:30 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:32:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:32:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:32:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:32:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:32:30 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:32:30 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:32:30 --> Session Class Initialized
DEBUG - 2016-09-14 12:32:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:32:30 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:32:30 --> Session routines successfully run
DEBUG - 2016-09-14 12:32:30 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:32:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:32:30 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:32:30 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:32:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:32:30 --> Controller Class Initialized
DEBUG - 2016-09-14 12:32:30 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:32:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:32:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:32:30 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:32:30 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:32:30 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:32:30 --> Model Class Initialized
DEBUG - 2016-09-14 12:32:30 --> Model Class Initialized
DEBUG - 2016-09-14 12:32:30 --> Model Class Initialized
ERROR - 2016-09-14 12:32:30 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:32:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:32:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:32:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:32:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:32:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:32:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:32:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:32:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:32:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:32:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:32:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:32:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:32:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:32:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:32:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:32:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:32:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:32:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:32:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:32:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:32:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 12:32:31 --> Final output sent to browser
DEBUG - 2016-09-14 12:32:31 --> Total execution time: 0.4640
DEBUG - 2016-09-14 12:32:50 --> Config Class Initialized
DEBUG - 2016-09-14 12:32:50 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:32:50 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:32:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:32:50 --> URI Class Initialized
DEBUG - 2016-09-14 12:32:50 --> Router Class Initialized
DEBUG - 2016-09-14 12:32:50 --> Output Class Initialized
DEBUG - 2016-09-14 12:32:50 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 12:32:50 --> Security Class Initialized
DEBUG - 2016-09-14 12:32:50 --> Input Class Initialized
DEBUG - 2016-09-14 12:32:50 --> XSS Filtering completed
DEBUG - 2016-09-14 12:32:50 --> XSS Filtering completed
DEBUG - 2016-09-14 12:32:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:32:50 --> Language Class Initialized
DEBUG - 2016-09-14 12:32:50 --> Loader Class Initialized
DEBUG - 2016-09-14 12:32:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:32:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:32:50 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:32:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:32:50 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:32:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:32:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:32:50 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:32:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:32:50 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:32:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:32:50 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:32:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:32:50 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:32:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:32:50 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:32:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:32:50 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:32:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:32:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:32:50 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:32:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:32:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:32:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:32:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:32:50 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:32:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:32:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:32:50 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:32:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:32:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:32:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:32:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:32:50 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:32:50 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:32:50 --> Session Class Initialized
DEBUG - 2016-09-14 12:32:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:32:50 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:32:50 --> Session routines successfully run
DEBUG - 2016-09-14 12:32:50 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:32:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:32:50 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:32:50 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:32:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:32:50 --> Controller Class Initialized
DEBUG - 2016-09-14 12:32:50 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:32:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:32:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:32:50 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:32:50 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:32:50 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:32:50 --> Model Class Initialized
DEBUG - 2016-09-14 12:32:50 --> Model Class Initialized
DEBUG - 2016-09-14 12:32:50 --> Model Class Initialized
ERROR - 2016-09-14 12:32:50 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:32:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:32:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:32:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:32:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:32:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:32:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:32:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:32:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:32:51 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 12:32:51 --> Final output sent to browser
DEBUG - 2016-09-14 12:32:51 --> Total execution time: 0.5041
DEBUG - 2016-09-14 12:33:27 --> Config Class Initialized
DEBUG - 2016-09-14 12:33:27 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:33:27 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:33:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:33:27 --> URI Class Initialized
DEBUG - 2016-09-14 12:33:27 --> Router Class Initialized
DEBUG - 2016-09-14 12:33:27 --> Output Class Initialized
DEBUG - 2016-09-14 12:33:27 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 12:33:27 --> Security Class Initialized
DEBUG - 2016-09-14 12:33:27 --> Input Class Initialized
DEBUG - 2016-09-14 12:33:27 --> XSS Filtering completed
DEBUG - 2016-09-14 12:33:27 --> XSS Filtering completed
DEBUG - 2016-09-14 12:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:33:27 --> Language Class Initialized
DEBUG - 2016-09-14 12:33:27 --> Loader Class Initialized
DEBUG - 2016-09-14 12:33:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:33:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:33:27 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:33:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:33:27 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:33:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:33:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:33:27 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:33:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:33:27 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:33:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:33:27 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:33:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:33:27 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:33:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:33:27 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:33:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:33:27 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:33:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:33:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:33:27 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:33:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:33:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:33:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:33:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:33:27 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:33:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:33:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:33:27 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:33:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:33:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:33:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:33:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:33:27 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:33:27 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:33:27 --> Session Class Initialized
DEBUG - 2016-09-14 12:33:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:33:27 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:33:27 --> Session routines successfully run
DEBUG - 2016-09-14 12:33:27 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:33:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:33:27 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:33:27 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:33:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:33:27 --> Controller Class Initialized
DEBUG - 2016-09-14 12:33:27 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:33:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:33:27 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:33:27 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:33:27 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:33:27 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:33:27 --> Model Class Initialized
DEBUG - 2016-09-14 12:33:27 --> Model Class Initialized
DEBUG - 2016-09-14 12:33:27 --> Model Class Initialized
ERROR - 2016-09-14 12:33:27 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:33:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:33:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:33:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:33:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:33:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:33:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:33:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:33:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:33:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:33:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:33:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:33:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:33:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:33:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:33:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:33:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:33:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:33:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:33:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:33:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:33:28 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 12:33:28 --> Final output sent to browser
DEBUG - 2016-09-14 12:33:28 --> Total execution time: 0.5122
DEBUG - 2016-09-14 12:36:03 --> Config Class Initialized
DEBUG - 2016-09-14 12:36:03 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:36:03 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:36:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:36:03 --> URI Class Initialized
DEBUG - 2016-09-14 12:36:03 --> Router Class Initialized
DEBUG - 2016-09-14 12:36:03 --> Output Class Initialized
DEBUG - 2016-09-14 12:36:03 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 12:36:03 --> Security Class Initialized
DEBUG - 2016-09-14 12:36:03 --> Input Class Initialized
DEBUG - 2016-09-14 12:36:03 --> XSS Filtering completed
DEBUG - 2016-09-14 12:36:03 --> XSS Filtering completed
DEBUG - 2016-09-14 12:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:36:03 --> Language Class Initialized
DEBUG - 2016-09-14 12:36:03 --> Loader Class Initialized
DEBUG - 2016-09-14 12:36:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:36:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:36:03 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:36:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:36:03 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:36:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:36:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:36:03 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:36:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:36:03 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:36:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:36:03 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:36:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:36:03 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:36:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:36:03 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:36:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:36:03 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:36:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:36:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:36:03 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:36:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:36:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:36:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:36:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:36:04 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:36:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:36:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:36:04 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:36:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:36:04 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:36:04 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:36:04 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:36:04 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:36:04 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:36:04 --> Session Class Initialized
DEBUG - 2016-09-14 12:36:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:36:04 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:36:04 --> Session routines successfully run
DEBUG - 2016-09-14 12:36:04 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:36:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:36:04 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:36:04 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:36:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:36:04 --> Controller Class Initialized
DEBUG - 2016-09-14 12:36:04 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:36:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:36:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:36:04 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:36:04 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:36:04 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:36:04 --> Model Class Initialized
DEBUG - 2016-09-14 12:36:04 --> Model Class Initialized
DEBUG - 2016-09-14 12:36:04 --> Model Class Initialized
ERROR - 2016-09-14 12:36:04 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:36:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:36:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:36:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:36:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:36:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:36:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:36:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:36:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:36:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:36:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:36:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:36:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:36:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:36:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:36:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:36:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:36:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:36:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:36:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:36:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:36:04 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 12:36:04 --> Final output sent to browser
DEBUG - 2016-09-14 12:36:04 --> Total execution time: 0.5326
DEBUG - 2016-09-14 12:36:12 --> Config Class Initialized
DEBUG - 2016-09-14 12:36:12 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:36:12 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:36:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:36:12 --> URI Class Initialized
DEBUG - 2016-09-14 12:36:12 --> Router Class Initialized
DEBUG - 2016-09-14 12:36:12 --> Output Class Initialized
DEBUG - 2016-09-14 12:36:12 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 12:36:12 --> Security Class Initialized
DEBUG - 2016-09-14 12:36:12 --> Input Class Initialized
DEBUG - 2016-09-14 12:36:12 --> XSS Filtering completed
DEBUG - 2016-09-14 12:36:12 --> XSS Filtering completed
DEBUG - 2016-09-14 12:36:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:36:12 --> Language Class Initialized
DEBUG - 2016-09-14 12:36:12 --> Loader Class Initialized
DEBUG - 2016-09-14 12:36:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:36:12 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:36:12 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:36:12 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:36:12 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:36:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:36:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:36:12 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:36:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:36:12 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:36:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:36:12 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:36:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:36:12 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:36:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:36:12 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:36:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:36:12 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:36:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:36:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:36:12 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:36:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:36:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:36:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:36:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:36:12 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:36:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:36:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:36:12 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:36:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:36:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:36:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:36:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:36:12 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:36:12 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:36:13 --> Session Class Initialized
DEBUG - 2016-09-14 12:36:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:36:13 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:36:13 --> Session routines successfully run
DEBUG - 2016-09-14 12:36:13 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:36:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:36:13 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:36:13 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:36:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:36:13 --> Controller Class Initialized
DEBUG - 2016-09-14 12:36:13 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:36:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:36:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:36:13 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:36:13 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:36:13 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:36:13 --> Model Class Initialized
DEBUG - 2016-09-14 12:36:13 --> Model Class Initialized
DEBUG - 2016-09-14 12:36:13 --> Model Class Initialized
ERROR - 2016-09-14 12:36:13 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:36:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:36:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:36:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:36:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:36:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:36:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:36:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:36:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:36:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:36:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:36:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:36:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:36:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:36:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:36:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:36:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:36:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:36:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:36:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:36:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:36:13 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 12:36:13 --> Final output sent to browser
DEBUG - 2016-09-14 12:36:13 --> Total execution time: 0.5862
DEBUG - 2016-09-14 12:42:11 --> Config Class Initialized
DEBUG - 2016-09-14 12:42:11 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:42:11 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:42:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:42:11 --> URI Class Initialized
DEBUG - 2016-09-14 12:42:11 --> Router Class Initialized
DEBUG - 2016-09-14 12:42:11 --> Output Class Initialized
DEBUG - 2016-09-14 12:42:11 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 12:42:11 --> Security Class Initialized
DEBUG - 2016-09-14 12:42:11 --> Input Class Initialized
DEBUG - 2016-09-14 12:42:11 --> XSS Filtering completed
DEBUG - 2016-09-14 12:42:11 --> XSS Filtering completed
DEBUG - 2016-09-14 12:42:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:42:11 --> Language Class Initialized
DEBUG - 2016-09-14 12:42:11 --> Loader Class Initialized
DEBUG - 2016-09-14 12:42:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:42:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:42:11 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:42:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:42:11 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:42:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:42:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:42:11 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:42:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:42:11 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:42:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:42:11 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:42:11 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:42:11 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:42:11 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:42:11 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:42:11 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:42:11 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:42:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:42:11 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:42:11 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:42:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:42:11 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:42:11 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:42:11 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:42:11 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:42:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:42:11 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:42:11 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:42:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:42:11 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:42:11 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:42:11 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:42:11 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:42:11 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:42:11 --> Session Class Initialized
DEBUG - 2016-09-14 12:42:11 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:42:11 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:42:11 --> Session routines successfully run
DEBUG - 2016-09-14 12:42:11 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:42:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:42:12 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:42:12 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:42:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:42:12 --> Controller Class Initialized
DEBUG - 2016-09-14 12:42:12 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:42:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:42:12 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:42:12 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:42:12 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:42:12 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:42:12 --> Model Class Initialized
DEBUG - 2016-09-14 12:42:12 --> Model Class Initialized
DEBUG - 2016-09-14 12:42:12 --> Model Class Initialized
DEBUG - 2016-09-14 12:42:12 --> Model Class Initialized
DEBUG - 2016-09-14 12:42:12 --> Model Class Initialized
DEBUG - 2016-09-14 12:42:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-14 12:42:12 --> Pagination Class Initialized
DEBUG - 2016-09-14 12:42:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-14 12:42:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/index.php
DEBUG - 2016-09-14 12:42:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-14 12:42:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-14 12:42:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:42:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:42:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-09-14 12:42:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:42:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-14 12:42:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-14 12:42:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-14 12:42:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:42:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:42:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-09-14 12:42:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:42:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-14 12:42:12 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/860bebf57fee032e24acce1c64d1c3e7
DEBUG - 2016-09-14 12:42:12 --> Final output sent to browser
DEBUG - 2016-09-14 12:42:12 --> Total execution time: 0.9039
DEBUG - 2016-09-14 12:42:32 --> Config Class Initialized
DEBUG - 2016-09-14 12:42:32 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:42:32 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:42:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:42:32 --> URI Class Initialized
DEBUG - 2016-09-14 12:42:32 --> Router Class Initialized
DEBUG - 2016-09-14 12:42:32 --> Output Class Initialized
DEBUG - 2016-09-14 12:42:32 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 12:42:32 --> Security Class Initialized
DEBUG - 2016-09-14 12:42:32 --> Input Class Initialized
DEBUG - 2016-09-14 12:42:32 --> XSS Filtering completed
DEBUG - 2016-09-14 12:42:32 --> XSS Filtering completed
DEBUG - 2016-09-14 12:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:42:32 --> Language Class Initialized
DEBUG - 2016-09-14 12:42:32 --> Loader Class Initialized
DEBUG - 2016-09-14 12:42:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:42:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:42:32 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:42:32 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:42:32 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:42:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:42:32 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:42:32 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:42:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:42:32 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:42:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:42:32 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:42:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:42:32 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:42:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:42:32 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:42:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:42:32 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:42:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:42:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:42:32 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:42:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:42:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:42:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:42:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:42:32 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:42:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:42:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:42:32 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:42:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:42:32 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:42:32 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:42:32 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:42:32 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:42:33 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:42:33 --> Session Class Initialized
DEBUG - 2016-09-14 12:42:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:42:33 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:42:33 --> Session routines successfully run
DEBUG - 2016-09-14 12:42:33 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:42:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:42:33 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:42:33 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:42:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:42:33 --> Controller Class Initialized
DEBUG - 2016-09-14 12:42:33 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:42:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:42:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:42:33 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:42:33 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:42:33 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:42:33 --> Model Class Initialized
DEBUG - 2016-09-14 12:42:33 --> Model Class Initialized
DEBUG - 2016-09-14 12:42:33 --> Model Class Initialized
DEBUG - 2016-09-14 12:42:33 --> Model Class Initialized
DEBUG - 2016-09-14 12:42:33 --> Model Class Initialized
DEBUG - 2016-09-14 12:42:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-14 12:42:33 --> Pagination Class Initialized
DEBUG - 2016-09-14 12:42:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-14 12:42:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/index.php
DEBUG - 2016-09-14 12:42:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-14 12:42:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-14 12:42:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:42:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:42:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-09-14 12:42:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:42:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-14 12:42:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-14 12:42:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-14 12:42:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:42:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:42:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-09-14 12:42:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:42:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-14 12:42:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/860bebf57fee032e24acce1c64d1c3e7
DEBUG - 2016-09-14 12:42:33 --> Final output sent to browser
DEBUG - 2016-09-14 12:42:33 --> Total execution time: 0.6495
DEBUG - 2016-09-14 12:42:41 --> Config Class Initialized
DEBUG - 2016-09-14 12:42:41 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:42:41 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:42:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:42:41 --> URI Class Initialized
DEBUG - 2016-09-14 12:42:41 --> Router Class Initialized
DEBUG - 2016-09-14 12:42:41 --> Output Class Initialized
DEBUG - 2016-09-14 12:42:42 --> Security Class Initialized
DEBUG - 2016-09-14 12:42:42 --> Input Class Initialized
DEBUG - 2016-09-14 12:42:42 --> XSS Filtering completed
DEBUG - 2016-09-14 12:42:42 --> XSS Filtering completed
DEBUG - 2016-09-14 12:42:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:42:42 --> Language Class Initialized
DEBUG - 2016-09-14 12:42:42 --> Loader Class Initialized
DEBUG - 2016-09-14 12:42:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:42:42 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:42:42 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:42:42 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:42:42 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:42:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:42:42 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:42:42 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:42:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:42:42 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:42:42 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:42:42 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:42:42 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:42:42 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:42:42 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:42:42 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:42:42 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:42:42 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:42:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:42:42 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:42:42 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:42:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:42:42 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:42:42 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:42:42 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:42:42 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:42:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:42:42 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:42:42 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:42:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:42:42 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:42:42 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:42:42 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:42:42 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:42:42 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:42:42 --> Session Class Initialized
DEBUG - 2016-09-14 12:42:42 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:42:42 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:42:42 --> Session routines successfully run
DEBUG - 2016-09-14 12:42:42 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:42:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:42:42 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:42:42 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:42:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:42:42 --> Controller Class Initialized
DEBUG - 2016-09-14 12:42:42 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:42:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:42:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:42:42 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:42:42 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:42:42 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:42:42 --> Model Class Initialized
DEBUG - 2016-09-14 12:42:42 --> Model Class Initialized
DEBUG - 2016-09-14 12:42:42 --> Model Class Initialized
DEBUG - 2016-09-14 12:42:42 --> Model Class Initialized
DEBUG - 2016-09-14 12:42:42 --> Model Class Initialized
DEBUG - 2016-09-14 12:42:42 --> Model Class Initialized
DEBUG - 2016-09-14 12:42:42 --> Model Class Initialized
DEBUG - 2016-09-14 12:47:45 --> Config Class Initialized
DEBUG - 2016-09-14 12:47:45 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:47:45 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:47:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:47:45 --> URI Class Initialized
DEBUG - 2016-09-14 12:47:45 --> Router Class Initialized
DEBUG - 2016-09-14 12:47:45 --> Output Class Initialized
DEBUG - 2016-09-14 12:47:45 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 12:47:45 --> Security Class Initialized
DEBUG - 2016-09-14 12:47:45 --> Input Class Initialized
DEBUG - 2016-09-14 12:47:45 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:45 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:47:45 --> Language Class Initialized
DEBUG - 2016-09-14 12:47:45 --> Loader Class Initialized
DEBUG - 2016-09-14 12:47:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:47:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:47:45 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:47:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:47:45 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:47:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:47:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:47:45 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:47:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:47:45 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:47:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:47:45 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:47:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:47:45 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:47:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:47:45 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:47:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:47:45 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:47:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:47:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:47:45 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:47:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:47:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:47:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:47:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:47:45 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:47:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:47:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:47:45 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:47:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:47:45 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:47:45 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:47:45 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:47:45 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:47:45 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:47:45 --> Session Class Initialized
DEBUG - 2016-09-14 12:47:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:47:45 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:47:45 --> Session routines successfully run
DEBUG - 2016-09-14 12:47:45 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:47:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:47:45 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:47:45 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:47:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:47:45 --> Controller Class Initialized
DEBUG - 2016-09-14 12:47:45 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:47:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:47:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:47:45 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:47:45 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:47:45 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:47:45 --> Model Class Initialized
DEBUG - 2016-09-14 12:47:45 --> Model Class Initialized
DEBUG - 2016-09-14 12:47:45 --> Model Class Initialized
ERROR - 2016-09-14 12:47:45 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:47:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:47:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:47:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:47:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:47:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:47:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:47:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:47:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:47:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:47:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:47:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:47:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:47:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:47:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:47:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:47:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:47:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:47:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:47:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:47:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:47:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 12:47:45 --> Final output sent to browser
DEBUG - 2016-09-14 12:47:45 --> Total execution time: 0.6308
DEBUG - 2016-09-14 12:47:46 --> Config Class Initialized
DEBUG - 2016-09-14 12:47:46 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:47:46 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:47:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:47:46 --> URI Class Initialized
DEBUG - 2016-09-14 12:47:46 --> Router Class Initialized
DEBUG - 2016-09-14 12:47:47 --> Output Class Initialized
DEBUG - 2016-09-14 12:47:47 --> Security Class Initialized
DEBUG - 2016-09-14 12:47:47 --> Input Class Initialized
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> XSS Filtering completed
DEBUG - 2016-09-14 12:47:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:47:47 --> Language Class Initialized
DEBUG - 2016-09-14 12:47:47 --> Loader Class Initialized
DEBUG - 2016-09-14 12:47:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:47:47 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:47:47 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:47:47 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:47:47 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:47:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:47:47 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:47:47 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:47:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:47:47 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:47:47 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:47:47 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:47:47 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:47:47 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:47:47 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:47:47 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:47:47 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:47:47 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:47:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:47:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:47:47 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:47:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:47:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:47:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:47:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:47:47 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:47:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:47:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:47:47 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:47:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:47:47 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:47:47 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:47:47 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:47:47 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:47:47 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:47:47 --> Session Class Initialized
DEBUG - 2016-09-14 12:47:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:47:47 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:47:47 --> Session routines successfully run
DEBUG - 2016-09-14 12:47:47 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:47:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:47:47 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:47:47 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:47:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:47:47 --> Controller Class Initialized
DEBUG - 2016-09-14 12:47:47 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:47:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:47:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:47:47 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:47:47 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:47:47 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:47:47 --> Model Class Initialized
DEBUG - 2016-09-14 12:47:47 --> Model Class Initialized
DEBUG - 2016-09-14 12:47:47 --> Model Class Initialized
DEBUG - 2016-09-14 12:47:47 --> Model Class Initialized
DEBUG - 2016-09-14 12:47:47 --> Model Class Initialized
DEBUG - 2016-09-14 12:47:47 --> Model Class Initialized
DEBUG - 2016-09-14 12:47:47 --> Model Class Initialized
DEBUG - 2016-09-14 12:47:59 --> Config Class Initialized
DEBUG - 2016-09-14 12:47:59 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:47:59 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:47:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:47:59 --> URI Class Initialized
DEBUG - 2016-09-14 12:47:59 --> Router Class Initialized
DEBUG - 2016-09-14 12:47:59 --> Output Class Initialized
DEBUG - 2016-09-14 12:47:59 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 12:47:59 --> Security Class Initialized
DEBUG - 2016-09-14 12:47:59 --> Input Class Initialized
DEBUG - 2016-09-14 12:47:59 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:00 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:48:00 --> Language Class Initialized
DEBUG - 2016-09-14 12:48:00 --> Loader Class Initialized
DEBUG - 2016-09-14 12:48:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:48:00 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:48:00 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:48:00 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:48:00 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:48:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:48:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:48:00 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:48:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:48:00 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:48:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:48:00 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:48:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:48:00 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:48:00 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:48:00 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:48:00 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:48:00 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:48:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:48:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:48:00 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:48:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:48:00 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:48:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:48:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:48:00 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:48:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:48:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:48:00 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:48:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:48:00 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:48:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:48:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:48:00 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:48:00 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:48:00 --> Session Class Initialized
DEBUG - 2016-09-14 12:48:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:48:00 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:48:00 --> Session routines successfully run
DEBUG - 2016-09-14 12:48:00 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:48:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:48:00 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:48:00 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:48:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:48:00 --> Controller Class Initialized
DEBUG - 2016-09-14 12:48:00 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:48:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:48:00 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:48:00 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:48:00 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:48:00 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:48:00 --> Model Class Initialized
DEBUG - 2016-09-14 12:48:00 --> Model Class Initialized
DEBUG - 2016-09-14 12:48:00 --> Model Class Initialized
ERROR - 2016-09-14 12:48:00 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:48:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:48:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:48:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:48:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:48:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:48:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:48:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:48:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:48:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:48:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:48:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:48:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:48:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:48:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:48:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:48:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:48:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:48:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:48:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:48:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:48:00 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 12:48:00 --> Final output sent to browser
DEBUG - 2016-09-14 12:48:00 --> Total execution time: 0.6747
DEBUG - 2016-09-14 12:48:01 --> Config Class Initialized
DEBUG - 2016-09-14 12:48:01 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:48:01 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:48:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:48:01 --> URI Class Initialized
DEBUG - 2016-09-14 12:48:01 --> Router Class Initialized
DEBUG - 2016-09-14 12:48:01 --> Output Class Initialized
DEBUG - 2016-09-14 12:48:01 --> Security Class Initialized
DEBUG - 2016-09-14 12:48:01 --> Input Class Initialized
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> XSS Filtering completed
DEBUG - 2016-09-14 12:48:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:48:01 --> Language Class Initialized
DEBUG - 2016-09-14 12:48:01 --> Loader Class Initialized
DEBUG - 2016-09-14 12:48:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:48:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:48:01 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:48:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:48:01 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:48:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:48:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:48:01 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:48:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:48:01 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:48:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:48:01 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:48:01 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:48:01 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:48:01 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:48:02 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:48:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:48:02 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:48:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:48:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:48:02 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:48:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:48:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:48:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:48:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:48:02 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:48:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:48:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:48:02 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:48:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:48:02 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:48:02 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:48:02 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:48:02 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:48:02 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:48:02 --> Session Class Initialized
DEBUG - 2016-09-14 12:48:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:48:02 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:48:02 --> Session routines successfully run
DEBUG - 2016-09-14 12:48:02 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:48:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:48:02 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:48:02 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:48:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:48:02 --> Controller Class Initialized
DEBUG - 2016-09-14 12:48:02 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:48:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:48:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:48:02 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:48:02 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:48:02 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:48:02 --> Model Class Initialized
DEBUG - 2016-09-14 12:48:02 --> Model Class Initialized
DEBUG - 2016-09-14 12:48:02 --> Model Class Initialized
DEBUG - 2016-09-14 12:48:02 --> Model Class Initialized
DEBUG - 2016-09-14 12:48:02 --> Model Class Initialized
DEBUG - 2016-09-14 12:48:02 --> Model Class Initialized
DEBUG - 2016-09-14 12:48:02 --> Model Class Initialized
DEBUG - 2016-09-14 12:53:26 --> Config Class Initialized
DEBUG - 2016-09-14 12:53:26 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:53:26 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:53:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:53:26 --> URI Class Initialized
DEBUG - 2016-09-14 12:53:26 --> Router Class Initialized
DEBUG - 2016-09-14 12:53:26 --> Output Class Initialized
DEBUG - 2016-09-14 12:53:26 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 12:53:26 --> Security Class Initialized
DEBUG - 2016-09-14 12:53:26 --> Input Class Initialized
DEBUG - 2016-09-14 12:53:26 --> XSS Filtering completed
DEBUG - 2016-09-14 12:53:26 --> XSS Filtering completed
DEBUG - 2016-09-14 12:53:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:53:26 --> Language Class Initialized
DEBUG - 2016-09-14 12:53:26 --> Loader Class Initialized
DEBUG - 2016-09-14 12:53:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:53:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:53:26 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:53:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:53:26 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:53:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:53:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:53:26 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:53:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:53:26 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:53:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:53:26 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:53:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:53:26 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:53:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:53:26 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:53:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:53:26 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:53:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:53:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:53:26 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:53:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:53:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:53:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:53:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:53:26 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:53:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:53:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:53:26 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:53:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:53:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:53:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:53:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:53:26 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:53:26 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:53:27 --> Session Class Initialized
DEBUG - 2016-09-14 12:53:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:53:27 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:53:27 --> Session routines successfully run
DEBUG - 2016-09-14 12:53:27 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:53:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:53:27 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:53:27 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:53:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:53:27 --> Controller Class Initialized
DEBUG - 2016-09-14 12:53:27 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:53:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:53:27 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:53:27 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:53:27 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:53:27 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:53:27 --> Model Class Initialized
DEBUG - 2016-09-14 12:53:27 --> Model Class Initialized
DEBUG - 2016-09-14 12:53:27 --> Model Class Initialized
ERROR - 2016-09-14 12:53:27 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:53:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:53:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:53:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:53:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:53:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:53:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:53:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:53:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:53:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:53:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:53:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:53:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:53:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:53:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:53:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:53:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:53:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:53:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:53:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:53:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:53:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 12:53:27 --> Final output sent to browser
DEBUG - 2016-09-14 12:53:27 --> Total execution time: 0.7009
DEBUG - 2016-09-14 12:57:48 --> Config Class Initialized
DEBUG - 2016-09-14 12:57:48 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:57:48 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:57:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:57:48 --> URI Class Initialized
DEBUG - 2016-09-14 12:57:48 --> Router Class Initialized
DEBUG - 2016-09-14 12:57:48 --> Output Class Initialized
DEBUG - 2016-09-14 12:57:48 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 12:57:48 --> Security Class Initialized
DEBUG - 2016-09-14 12:57:48 --> Input Class Initialized
DEBUG - 2016-09-14 12:57:48 --> XSS Filtering completed
DEBUG - 2016-09-14 12:57:48 --> XSS Filtering completed
DEBUG - 2016-09-14 12:57:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:57:48 --> Language Class Initialized
DEBUG - 2016-09-14 12:57:48 --> Loader Class Initialized
DEBUG - 2016-09-14 12:57:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:57:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:57:48 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:57:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:57:48 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:57:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:57:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:57:48 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:57:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:57:48 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:57:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:57:49 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:57:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:57:49 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:57:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:57:49 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:57:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:57:49 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:57:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:57:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:57:49 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:57:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:57:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:57:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:57:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:57:49 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:57:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:57:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:57:49 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:57:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:57:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:57:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:57:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:57:49 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:57:49 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:57:49 --> Session Class Initialized
DEBUG - 2016-09-14 12:57:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:57:49 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:57:49 --> Session routines successfully run
DEBUG - 2016-09-14 12:57:49 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:57:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:57:49 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:57:49 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:57:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:57:49 --> Controller Class Initialized
DEBUG - 2016-09-14 12:57:49 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:57:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:57:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:57:49 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:57:49 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:57:49 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:57:49 --> Model Class Initialized
DEBUG - 2016-09-14 12:57:49 --> Model Class Initialized
DEBUG - 2016-09-14 12:57:49 --> Model Class Initialized
ERROR - 2016-09-14 12:57:49 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:57:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:57:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:57:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:57:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:57:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:57:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:57:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:57:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:57:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:57:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:57:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:57:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:57:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:57:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:57:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:57:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:57:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:57:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:57:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:57:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:57:49 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 12:57:49 --> Final output sent to browser
DEBUG - 2016-09-14 12:57:49 --> Total execution time: 0.7272
DEBUG - 2016-09-14 12:58:12 --> Config Class Initialized
DEBUG - 2016-09-14 12:58:12 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:58:12 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:58:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:58:12 --> URI Class Initialized
DEBUG - 2016-09-14 12:58:12 --> Router Class Initialized
DEBUG - 2016-09-14 12:58:12 --> Output Class Initialized
DEBUG - 2016-09-14 12:58:12 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 12:58:12 --> Security Class Initialized
DEBUG - 2016-09-14 12:58:12 --> Input Class Initialized
DEBUG - 2016-09-14 12:58:12 --> XSS Filtering completed
DEBUG - 2016-09-14 12:58:12 --> XSS Filtering completed
DEBUG - 2016-09-14 12:58:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:58:12 --> Language Class Initialized
DEBUG - 2016-09-14 12:58:12 --> Loader Class Initialized
DEBUG - 2016-09-14 12:58:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:58:12 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:58:12 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:58:12 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:58:12 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:58:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:58:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:58:12 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:58:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:58:12 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:58:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:58:12 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:58:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:58:12 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:58:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:58:12 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:58:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:58:12 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:58:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:58:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:58:12 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:58:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:58:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:58:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:58:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:58:12 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:58:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:58:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:58:12 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:58:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:58:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:58:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:58:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:58:12 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:58:12 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:58:12 --> Session Class Initialized
DEBUG - 2016-09-14 12:58:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:58:12 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:58:12 --> Session routines successfully run
DEBUG - 2016-09-14 12:58:12 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:58:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:58:12 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:58:12 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:58:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:58:12 --> Controller Class Initialized
DEBUG - 2016-09-14 12:58:12 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:58:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:58:12 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:58:12 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:58:12 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:58:12 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:58:12 --> Model Class Initialized
DEBUG - 2016-09-14 12:58:12 --> Model Class Initialized
DEBUG - 2016-09-14 12:58:12 --> Model Class Initialized
ERROR - 2016-09-14 12:58:12 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:58:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:58:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:58:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:58:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:58:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:58:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:58:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:58:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:58:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:58:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:58:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:58:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:58:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:58:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:58:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:58:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:58:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:58:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:58:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:58:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:58:12 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 12:58:12 --> Final output sent to browser
DEBUG - 2016-09-14 12:58:13 --> Total execution time: 0.7402
DEBUG - 2016-09-14 12:58:35 --> Config Class Initialized
DEBUG - 2016-09-14 12:58:35 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:58:35 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:58:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:58:35 --> URI Class Initialized
DEBUG - 2016-09-14 12:58:35 --> Router Class Initialized
DEBUG - 2016-09-14 12:58:35 --> Output Class Initialized
DEBUG - 2016-09-14 12:58:35 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 12:58:35 --> Security Class Initialized
DEBUG - 2016-09-14 12:58:35 --> Input Class Initialized
DEBUG - 2016-09-14 12:58:35 --> XSS Filtering completed
DEBUG - 2016-09-14 12:58:35 --> XSS Filtering completed
DEBUG - 2016-09-14 12:58:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:58:35 --> Language Class Initialized
DEBUG - 2016-09-14 12:58:35 --> Loader Class Initialized
DEBUG - 2016-09-14 12:58:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:58:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:58:35 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:58:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:58:35 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:58:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:58:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:58:35 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:58:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:58:35 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:58:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:58:35 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:58:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:58:35 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:58:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:58:36 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:58:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:58:36 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:58:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:58:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:58:36 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:58:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:58:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:58:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:58:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:58:36 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:58:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:58:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:58:36 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:58:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:58:36 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:58:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:58:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:58:36 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:58:36 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:58:36 --> Session Class Initialized
DEBUG - 2016-09-14 12:58:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:58:36 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:58:36 --> Session routines successfully run
DEBUG - 2016-09-14 12:58:36 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:58:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:58:36 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:58:36 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:58:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:58:36 --> Controller Class Initialized
DEBUG - 2016-09-14 12:58:36 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:58:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:58:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:58:36 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:58:36 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:58:36 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:58:36 --> Model Class Initialized
DEBUG - 2016-09-14 12:58:36 --> Model Class Initialized
DEBUG - 2016-09-14 12:58:36 --> Model Class Initialized
ERROR - 2016-09-14 12:58:36 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:58:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:58:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:58:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:58:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:58:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:58:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:58:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:58:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:58:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:58:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:58:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:58:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:58:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:58:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:58:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:58:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:58:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:58:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:58:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:58:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:58:36 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 12:58:36 --> Final output sent to browser
DEBUG - 2016-09-14 12:58:36 --> Total execution time: 0.7657
DEBUG - 2016-09-14 12:58:49 --> Config Class Initialized
DEBUG - 2016-09-14 12:58:49 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:58:49 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:58:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:58:49 --> URI Class Initialized
DEBUG - 2016-09-14 12:58:49 --> Router Class Initialized
DEBUG - 2016-09-14 12:58:49 --> Output Class Initialized
DEBUG - 2016-09-14 12:58:49 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 12:58:49 --> Security Class Initialized
DEBUG - 2016-09-14 12:58:49 --> Input Class Initialized
DEBUG - 2016-09-14 12:58:49 --> XSS Filtering completed
DEBUG - 2016-09-14 12:58:49 --> XSS Filtering completed
DEBUG - 2016-09-14 12:58:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:58:49 --> Language Class Initialized
DEBUG - 2016-09-14 12:58:49 --> Loader Class Initialized
DEBUG - 2016-09-14 12:58:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:58:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:58:49 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:58:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:58:49 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:58:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:58:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:58:49 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:58:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:58:49 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:58:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:58:49 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:58:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:58:49 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:58:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:58:49 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:58:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:58:49 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:58:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:58:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:58:49 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:58:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:58:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:58:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:58:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:58:49 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:58:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:58:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:58:49 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:58:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:58:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:58:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:58:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:58:49 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:58:49 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:58:49 --> Session Class Initialized
DEBUG - 2016-09-14 12:58:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:58:49 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:58:49 --> Session routines successfully run
DEBUG - 2016-09-14 12:58:49 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:58:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:58:49 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:58:49 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:58:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:58:49 --> Controller Class Initialized
DEBUG - 2016-09-14 12:58:49 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:58:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:58:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:58:49 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:58:49 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:58:49 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:58:49 --> Model Class Initialized
DEBUG - 2016-09-14 12:58:49 --> Model Class Initialized
DEBUG - 2016-09-14 12:58:49 --> Model Class Initialized
ERROR - 2016-09-14 12:58:49 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:58:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:58:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:58:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:58:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:58:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:58:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:58:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:58:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:58:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:58:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:58:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:58:50 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 12:58:50 --> Final output sent to browser
DEBUG - 2016-09-14 12:58:50 --> Total execution time: 0.7852
DEBUG - 2016-09-14 12:59:30 --> Config Class Initialized
DEBUG - 2016-09-14 12:59:30 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:59:30 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:59:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:59:30 --> URI Class Initialized
DEBUG - 2016-09-14 12:59:30 --> Router Class Initialized
DEBUG - 2016-09-14 12:59:30 --> Output Class Initialized
DEBUG - 2016-09-14 12:59:30 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 12:59:30 --> Security Class Initialized
DEBUG - 2016-09-14 12:59:30 --> Input Class Initialized
DEBUG - 2016-09-14 12:59:30 --> XSS Filtering completed
DEBUG - 2016-09-14 12:59:30 --> XSS Filtering completed
DEBUG - 2016-09-14 12:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:59:30 --> Language Class Initialized
DEBUG - 2016-09-14 12:59:30 --> Loader Class Initialized
DEBUG - 2016-09-14 12:59:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:59:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:59:30 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:59:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:59:30 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:59:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:59:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:59:30 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:59:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:59:30 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:59:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:59:30 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:59:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:59:30 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:59:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:59:30 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:59:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:59:30 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:59:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:59:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:59:30 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:59:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:59:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:59:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:59:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:59:30 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:59:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:59:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:59:30 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:59:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:59:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:59:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:59:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:59:30 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:59:30 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:59:30 --> Session Class Initialized
DEBUG - 2016-09-14 12:59:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:59:30 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:59:30 --> Session routines successfully run
DEBUG - 2016-09-14 12:59:30 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:59:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:59:30 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:59:30 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:59:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:59:30 --> Controller Class Initialized
DEBUG - 2016-09-14 12:59:30 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:59:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:59:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:59:30 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:59:30 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:59:30 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:59:30 --> Model Class Initialized
DEBUG - 2016-09-14 12:59:30 --> Model Class Initialized
DEBUG - 2016-09-14 12:59:30 --> Model Class Initialized
ERROR - 2016-09-14 12:59:30 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:59:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:59:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:59:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 12:59:31 --> Final output sent to browser
DEBUG - 2016-09-14 12:59:31 --> Total execution time: 0.7996
DEBUG - 2016-09-14 12:59:34 --> Config Class Initialized
DEBUG - 2016-09-14 12:59:34 --> Hooks Class Initialized
DEBUG - 2016-09-14 12:59:34 --> Utf8 Class Initialized
DEBUG - 2016-09-14 12:59:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 12:59:34 --> URI Class Initialized
DEBUG - 2016-09-14 12:59:35 --> Router Class Initialized
DEBUG - 2016-09-14 12:59:35 --> Output Class Initialized
DEBUG - 2016-09-14 12:59:35 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 12:59:35 --> Security Class Initialized
DEBUG - 2016-09-14 12:59:35 --> Input Class Initialized
DEBUG - 2016-09-14 12:59:35 --> XSS Filtering completed
DEBUG - 2016-09-14 12:59:35 --> XSS Filtering completed
DEBUG - 2016-09-14 12:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 12:59:35 --> Language Class Initialized
DEBUG - 2016-09-14 12:59:35 --> Loader Class Initialized
DEBUG - 2016-09-14 12:59:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 12:59:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 12:59:35 --> Helper loaded: url_helper
DEBUG - 2016-09-14 12:59:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 12:59:35 --> Helper loaded: file_helper
DEBUG - 2016-09-14 12:59:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:59:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 12:59:35 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 12:59:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 12:59:35 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 12:59:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 12:59:35 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:59:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 12:59:35 --> Helper loaded: common_helper
DEBUG - 2016-09-14 12:59:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 12:59:35 --> Helper loaded: form_helper
DEBUG - 2016-09-14 12:59:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 12:59:35 --> Helper loaded: security_helper
DEBUG - 2016-09-14 12:59:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:59:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 12:59:35 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 12:59:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 12:59:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 12:59:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 12:59:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 12:59:35 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 12:59:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:59:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 12:59:35 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 12:59:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 12:59:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 12:59:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 12:59:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 12:59:35 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 12:59:35 --> Database Driver Class Initialized
DEBUG - 2016-09-14 12:59:35 --> Session Class Initialized
DEBUG - 2016-09-14 12:59:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 12:59:35 --> Helper loaded: string_helper
DEBUG - 2016-09-14 12:59:35 --> Session routines successfully run
DEBUG - 2016-09-14 12:59:35 --> Native_session Class Initialized
DEBUG - 2016-09-14 12:59:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 12:59:35 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:59:35 --> Form Validation Class Initialized
DEBUG - 2016-09-14 12:59:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 12:59:35 --> Controller Class Initialized
DEBUG - 2016-09-14 12:59:35 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 12:59:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 12:59:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 12:59:35 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:59:35 --> Carabiner: library configured.
DEBUG - 2016-09-14 12:59:35 --> User Agent Class Initialized
DEBUG - 2016-09-14 12:59:35 --> Model Class Initialized
DEBUG - 2016-09-14 12:59:35 --> Model Class Initialized
DEBUG - 2016-09-14 12:59:35 --> Model Class Initialized
ERROR - 2016-09-14 12:59:35 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 12:59:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 12:59:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 12:59:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:59:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:59:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:59:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:59:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:59:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:59:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:59:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:59:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:59:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 12:59:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 12:59:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 12:59:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 12:59:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 12:59:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 12:59:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 12:59:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 12:59:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 12:59:36 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 12:59:36 --> Final output sent to browser
DEBUG - 2016-09-14 12:59:36 --> Total execution time: 0.8170
DEBUG - 2016-09-14 13:00:25 --> Config Class Initialized
DEBUG - 2016-09-14 13:00:25 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:00:25 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:00:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:00:25 --> URI Class Initialized
DEBUG - 2016-09-14 13:00:25 --> Router Class Initialized
DEBUG - 2016-09-14 13:00:25 --> Output Class Initialized
DEBUG - 2016-09-14 13:00:25 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 13:00:25 --> Security Class Initialized
DEBUG - 2016-09-14 13:00:25 --> Input Class Initialized
DEBUG - 2016-09-14 13:00:25 --> XSS Filtering completed
DEBUG - 2016-09-14 13:00:25 --> XSS Filtering completed
DEBUG - 2016-09-14 13:00:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 13:00:25 --> Language Class Initialized
DEBUG - 2016-09-14 13:00:25 --> Loader Class Initialized
DEBUG - 2016-09-14 13:00:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 13:00:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 13:00:25 --> Helper loaded: url_helper
DEBUG - 2016-09-14 13:00:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 13:00:25 --> Helper loaded: file_helper
DEBUG - 2016-09-14 13:00:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:00:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 13:00:25 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 13:00:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:00:26 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 13:00:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 13:00:26 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:00:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 13:00:26 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:00:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 13:00:26 --> Helper loaded: form_helper
DEBUG - 2016-09-14 13:00:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 13:00:26 --> Helper loaded: security_helper
DEBUG - 2016-09-14 13:00:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:00:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 13:00:26 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 13:00:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:00:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 13:00:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 13:00:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 13:00:26 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 13:00:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:00:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 13:00:26 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 13:00:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:00:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 13:00:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 13:00:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 13:00:26 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 13:00:26 --> Database Driver Class Initialized
DEBUG - 2016-09-14 13:00:26 --> Session Class Initialized
DEBUG - 2016-09-14 13:00:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 13:00:26 --> Helper loaded: string_helper
DEBUG - 2016-09-14 13:00:26 --> Session routines successfully run
DEBUG - 2016-09-14 13:00:26 --> Native_session Class Initialized
DEBUG - 2016-09-14 13:00:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 13:00:26 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:00:26 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:00:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 13:00:26 --> Controller Class Initialized
DEBUG - 2016-09-14 13:00:26 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 13:00:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 13:00:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 13:00:26 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:00:26 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:00:26 --> User Agent Class Initialized
DEBUG - 2016-09-14 13:00:26 --> Model Class Initialized
DEBUG - 2016-09-14 13:00:26 --> Model Class Initialized
DEBUG - 2016-09-14 13:00:26 --> Model Class Initialized
ERROR - 2016-09-14 13:00:26 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 13:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 13:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 13:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 13:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 13:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 13:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 13:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 13:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 13:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 13:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 13:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 13:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 13:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 13:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 13:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 13:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:00:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 13:00:26 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 13:00:26 --> Final output sent to browser
DEBUG - 2016-09-14 13:00:26 --> Total execution time: 0.8475
DEBUG - 2016-09-14 13:01:21 --> Config Class Initialized
DEBUG - 2016-09-14 13:01:21 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:01:21 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:01:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:01:21 --> URI Class Initialized
DEBUG - 2016-09-14 13:01:21 --> Router Class Initialized
DEBUG - 2016-09-14 13:01:21 --> Output Class Initialized
DEBUG - 2016-09-14 13:01:21 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 13:01:21 --> Security Class Initialized
DEBUG - 2016-09-14 13:01:21 --> Input Class Initialized
DEBUG - 2016-09-14 13:01:21 --> XSS Filtering completed
DEBUG - 2016-09-14 13:01:21 --> XSS Filtering completed
DEBUG - 2016-09-14 13:01:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 13:01:21 --> Language Class Initialized
DEBUG - 2016-09-14 13:01:21 --> Loader Class Initialized
DEBUG - 2016-09-14 13:01:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 13:01:21 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 13:01:21 --> Helper loaded: url_helper
DEBUG - 2016-09-14 13:01:21 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 13:01:21 --> Helper loaded: file_helper
DEBUG - 2016-09-14 13:01:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:01:21 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 13:01:21 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 13:01:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:01:21 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 13:01:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 13:01:21 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:01:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 13:01:21 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:01:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 13:01:21 --> Helper loaded: form_helper
DEBUG - 2016-09-14 13:01:21 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 13:01:21 --> Helper loaded: security_helper
DEBUG - 2016-09-14 13:01:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:01:21 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 13:01:21 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 13:01:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:01:21 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 13:01:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 13:01:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 13:01:21 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 13:01:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:01:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 13:01:21 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 13:01:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:01:22 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 13:01:22 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 13:01:22 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 13:01:22 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 13:01:22 --> Database Driver Class Initialized
DEBUG - 2016-09-14 13:01:22 --> Session Class Initialized
DEBUG - 2016-09-14 13:01:22 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 13:01:22 --> Helper loaded: string_helper
DEBUG - 2016-09-14 13:01:22 --> Session routines successfully run
DEBUG - 2016-09-14 13:01:22 --> Native_session Class Initialized
DEBUG - 2016-09-14 13:01:22 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 13:01:22 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:01:22 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:01:22 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 13:01:22 --> Controller Class Initialized
DEBUG - 2016-09-14 13:01:22 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 13:01:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 13:01:22 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 13:01:22 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:01:22 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:01:22 --> User Agent Class Initialized
DEBUG - 2016-09-14 13:01:22 --> Model Class Initialized
DEBUG - 2016-09-14 13:01:22 --> Model Class Initialized
DEBUG - 2016-09-14 13:01:22 --> Model Class Initialized
ERROR - 2016-09-14 13:01:22 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 13:01:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 13:01:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 13:01:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 13:01:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:01:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 13:01:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 13:01:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-14 13:01:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 13:01:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 13:01:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:01:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 13:01:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 13:01:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:01:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 13:01:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 13:01:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-14 13:01:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 13:01:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 13:01:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:01:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 13:01:22 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 13:01:22 --> Final output sent to browser
DEBUG - 2016-09-14 13:01:22 --> Total execution time: 0.8578
DEBUG - 2016-09-14 13:03:03 --> Config Class Initialized
DEBUG - 2016-09-14 13:03:03 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:03:03 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:03:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:03:03 --> URI Class Initialized
DEBUG - 2016-09-14 13:03:03 --> Router Class Initialized
DEBUG - 2016-09-14 13:03:03 --> Output Class Initialized
DEBUG - 2016-09-14 13:03:03 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 13:03:03 --> Security Class Initialized
DEBUG - 2016-09-14 13:03:03 --> Input Class Initialized
DEBUG - 2016-09-14 13:03:03 --> XSS Filtering completed
DEBUG - 2016-09-14 13:03:03 --> XSS Filtering completed
DEBUG - 2016-09-14 13:03:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 13:03:03 --> Language Class Initialized
DEBUG - 2016-09-14 13:03:03 --> Loader Class Initialized
DEBUG - 2016-09-14 13:03:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 13:03:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 13:03:03 --> Helper loaded: url_helper
DEBUG - 2016-09-14 13:03:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 13:03:04 --> Helper loaded: file_helper
DEBUG - 2016-09-14 13:03:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:03:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 13:03:04 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 13:03:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:03:04 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 13:03:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 13:03:04 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:03:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 13:03:04 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:03:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 13:03:04 --> Helper loaded: form_helper
DEBUG - 2016-09-14 13:03:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 13:03:04 --> Helper loaded: security_helper
DEBUG - 2016-09-14 13:03:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:03:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 13:03:04 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 13:03:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:03:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 13:03:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 13:03:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 13:03:04 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 13:03:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:03:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 13:03:04 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 13:03:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:03:04 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 13:03:04 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 13:03:04 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 13:03:04 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 13:03:04 --> Database Driver Class Initialized
DEBUG - 2016-09-14 13:03:04 --> Session Class Initialized
DEBUG - 2016-09-14 13:03:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 13:03:04 --> Helper loaded: string_helper
DEBUG - 2016-09-14 13:03:04 --> Session routines successfully run
DEBUG - 2016-09-14 13:03:04 --> Native_session Class Initialized
DEBUG - 2016-09-14 13:03:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 13:03:04 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:03:04 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:03:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 13:03:04 --> Controller Class Initialized
DEBUG - 2016-09-14 13:03:04 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 13:03:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 13:03:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 13:03:04 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:03:04 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:03:04 --> User Agent Class Initialized
DEBUG - 2016-09-14 13:03:04 --> Model Class Initialized
DEBUG - 2016-09-14 13:03:04 --> Model Class Initialized
DEBUG - 2016-09-14 13:03:04 --> Model Class Initialized
ERROR - 2016-09-14 13:03:04 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 13:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 13:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 13:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 13:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 13:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 13:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-14 13:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 13:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 13:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 13:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 13:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 13:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 13:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-14 13:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 13:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 13:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:03:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 13:03:04 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 13:03:04 --> Final output sent to browser
DEBUG - 2016-09-14 13:03:04 --> Total execution time: 0.8728
DEBUG - 2016-09-14 13:03:05 --> Config Class Initialized
DEBUG - 2016-09-14 13:03:05 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:03:05 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:03:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:03:05 --> URI Class Initialized
DEBUG - 2016-09-14 13:03:05 --> Router Class Initialized
ERROR - 2016-09-14 13:03:05 --> 404 Page Not Found --> adaftar_diklat
DEBUG - 2016-09-14 13:03:10 --> Config Class Initialized
DEBUG - 2016-09-14 13:03:10 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:03:10 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:03:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:03:10 --> URI Class Initialized
DEBUG - 2016-09-14 13:03:10 --> Router Class Initialized
DEBUG - 2016-09-14 13:03:10 --> Output Class Initialized
DEBUG - 2016-09-14 13:03:10 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 13:03:10 --> Security Class Initialized
DEBUG - 2016-09-14 13:03:10 --> Input Class Initialized
DEBUG - 2016-09-14 13:03:10 --> XSS Filtering completed
DEBUG - 2016-09-14 13:03:10 --> XSS Filtering completed
DEBUG - 2016-09-14 13:03:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 13:03:10 --> Language Class Initialized
DEBUG - 2016-09-14 13:03:10 --> Loader Class Initialized
DEBUG - 2016-09-14 13:03:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 13:03:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 13:03:10 --> Helper loaded: url_helper
DEBUG - 2016-09-14 13:03:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 13:03:10 --> Helper loaded: file_helper
DEBUG - 2016-09-14 13:03:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:03:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 13:03:10 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 13:03:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:03:10 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 13:03:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 13:03:10 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:03:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 13:03:10 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:03:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 13:03:10 --> Helper loaded: form_helper
DEBUG - 2016-09-14 13:03:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 13:03:10 --> Helper loaded: security_helper
DEBUG - 2016-09-14 13:03:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:03:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 13:03:10 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 13:03:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:03:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 13:03:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 13:03:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 13:03:10 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 13:03:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:03:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 13:03:10 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 13:03:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:03:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 13:03:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 13:03:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 13:03:10 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 13:03:10 --> Database Driver Class Initialized
DEBUG - 2016-09-14 13:03:10 --> Session Class Initialized
DEBUG - 2016-09-14 13:03:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 13:03:10 --> Helper loaded: string_helper
DEBUG - 2016-09-14 13:03:10 --> Session routines successfully run
DEBUG - 2016-09-14 13:03:10 --> Native_session Class Initialized
DEBUG - 2016-09-14 13:03:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 13:03:10 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:03:10 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:03:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 13:03:11 --> Controller Class Initialized
DEBUG - 2016-09-14 13:03:11 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 13:03:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 13:03:11 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 13:03:11 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:03:11 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:03:11 --> User Agent Class Initialized
DEBUG - 2016-09-14 13:03:11 --> Model Class Initialized
DEBUG - 2016-09-14 13:03:11 --> Model Class Initialized
DEBUG - 2016-09-14 13:03:11 --> Model Class Initialized
ERROR - 2016-09-14 13:03:11 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 13:03:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 13:03:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 13:03:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 13:03:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:03:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 13:03:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 13:03:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-14 13:03:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 13:03:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 13:03:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:03:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 13:03:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 13:03:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:03:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 13:03:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 13:03:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-14 13:03:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 13:03:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 13:03:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:03:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 13:03:11 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 13:03:11 --> Final output sent to browser
DEBUG - 2016-09-14 13:03:11 --> Total execution time: 0.8774
DEBUG - 2016-09-14 13:03:11 --> Config Class Initialized
DEBUG - 2016-09-14 13:03:11 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:03:11 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:03:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:03:11 --> URI Class Initialized
DEBUG - 2016-09-14 13:03:11 --> Router Class Initialized
ERROR - 2016-09-14 13:03:11 --> 404 Page Not Found --> adaftar_diklat
DEBUG - 2016-09-14 13:03:18 --> Config Class Initialized
DEBUG - 2016-09-14 13:03:18 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:03:18 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:03:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:03:18 --> URI Class Initialized
DEBUG - 2016-09-14 13:03:18 --> Router Class Initialized
ERROR - 2016-09-14 13:03:18 --> 404 Page Not Found --> adaftar_diklat
DEBUG - 2016-09-14 13:03:46 --> Config Class Initialized
DEBUG - 2016-09-14 13:03:46 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:03:46 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:03:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:03:46 --> URI Class Initialized
DEBUG - 2016-09-14 13:03:46 --> Router Class Initialized
DEBUG - 2016-09-14 13:03:46 --> Output Class Initialized
DEBUG - 2016-09-14 13:03:46 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 13:03:46 --> Security Class Initialized
DEBUG - 2016-09-14 13:03:46 --> Input Class Initialized
DEBUG - 2016-09-14 13:03:46 --> XSS Filtering completed
DEBUG - 2016-09-14 13:03:46 --> XSS Filtering completed
DEBUG - 2016-09-14 13:03:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 13:03:46 --> Language Class Initialized
DEBUG - 2016-09-14 13:03:46 --> Loader Class Initialized
DEBUG - 2016-09-14 13:03:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 13:03:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 13:03:46 --> Helper loaded: url_helper
DEBUG - 2016-09-14 13:03:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 13:03:46 --> Helper loaded: file_helper
DEBUG - 2016-09-14 13:03:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:03:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 13:03:46 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 13:03:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:03:46 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 13:03:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 13:03:46 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:03:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 13:03:47 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:03:47 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 13:03:47 --> Helper loaded: form_helper
DEBUG - 2016-09-14 13:03:47 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 13:03:47 --> Helper loaded: security_helper
DEBUG - 2016-09-14 13:03:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:03:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 13:03:47 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 13:03:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:03:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 13:03:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 13:03:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 13:03:47 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 13:03:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:03:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 13:03:47 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 13:03:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:03:47 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 13:03:47 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 13:03:47 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 13:03:47 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 13:03:47 --> Database Driver Class Initialized
DEBUG - 2016-09-14 13:03:47 --> Session Class Initialized
DEBUG - 2016-09-14 13:03:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 13:03:47 --> Helper loaded: string_helper
DEBUG - 2016-09-14 13:03:47 --> Session routines successfully run
DEBUG - 2016-09-14 13:03:47 --> Native_session Class Initialized
DEBUG - 2016-09-14 13:03:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 13:03:47 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:03:47 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:03:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 13:03:47 --> Controller Class Initialized
DEBUG - 2016-09-14 13:03:47 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 13:03:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 13:03:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 13:03:47 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:03:47 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:03:47 --> User Agent Class Initialized
DEBUG - 2016-09-14 13:03:47 --> Model Class Initialized
DEBUG - 2016-09-14 13:03:47 --> Model Class Initialized
DEBUG - 2016-09-14 13:03:47 --> Model Class Initialized
ERROR - 2016-09-14 13:03:47 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 13:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 13:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 13:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 13:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 13:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 13:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-14 13:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 13:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 13:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 13:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 13:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 13:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 13:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-14 13:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 13:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 13:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:03:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 13:03:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 13:03:47 --> Final output sent to browser
DEBUG - 2016-09-14 13:03:47 --> Total execution time: 0.9236
DEBUG - 2016-09-14 13:03:48 --> Config Class Initialized
DEBUG - 2016-09-14 13:03:48 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:03:48 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:03:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:03:48 --> URI Class Initialized
DEBUG - 2016-09-14 13:03:48 --> Router Class Initialized
ERROR - 2016-09-14 13:03:48 --> 404 Page Not Found --> adaftar_diklat
DEBUG - 2016-09-14 13:03:58 --> Config Class Initialized
DEBUG - 2016-09-14 13:03:58 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:03:58 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:03:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:03:58 --> URI Class Initialized
DEBUG - 2016-09-14 13:03:58 --> Router Class Initialized
DEBUG - 2016-09-14 13:03:58 --> Output Class Initialized
DEBUG - 2016-09-14 13:03:58 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 13:03:58 --> Security Class Initialized
DEBUG - 2016-09-14 13:03:58 --> Input Class Initialized
DEBUG - 2016-09-14 13:03:58 --> XSS Filtering completed
DEBUG - 2016-09-14 13:03:58 --> XSS Filtering completed
DEBUG - 2016-09-14 13:03:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 13:03:58 --> Language Class Initialized
DEBUG - 2016-09-14 13:03:58 --> Loader Class Initialized
DEBUG - 2016-09-14 13:03:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 13:03:58 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 13:03:58 --> Helper loaded: url_helper
DEBUG - 2016-09-14 13:03:58 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 13:03:58 --> Helper loaded: file_helper
DEBUG - 2016-09-14 13:03:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:03:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 13:03:58 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 13:03:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:03:58 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 13:03:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 13:03:58 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:03:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 13:03:58 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:03:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 13:03:58 --> Helper loaded: form_helper
DEBUG - 2016-09-14 13:03:58 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 13:03:58 --> Helper loaded: security_helper
DEBUG - 2016-09-14 13:03:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:03:58 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 13:03:58 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 13:03:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:03:58 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 13:03:58 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 13:03:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 13:03:58 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 13:03:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:03:58 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 13:03:58 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 13:03:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:03:58 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 13:03:58 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 13:03:58 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 13:03:58 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 13:03:58 --> Database Driver Class Initialized
DEBUG - 2016-09-14 13:03:58 --> Session Class Initialized
DEBUG - 2016-09-14 13:03:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 13:03:58 --> Helper loaded: string_helper
DEBUG - 2016-09-14 13:03:58 --> Session routines successfully run
DEBUG - 2016-09-14 13:03:58 --> Native_session Class Initialized
DEBUG - 2016-09-14 13:03:58 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 13:03:58 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:03:59 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:03:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 13:03:59 --> Controller Class Initialized
DEBUG - 2016-09-14 13:03:59 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 13:03:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 13:03:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 13:03:59 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:03:59 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:03:59 --> User Agent Class Initialized
DEBUG - 2016-09-14 13:03:59 --> Model Class Initialized
DEBUG - 2016-09-14 13:03:59 --> Model Class Initialized
DEBUG - 2016-09-14 13:03:59 --> Model Class Initialized
ERROR - 2016-09-14 13:03:59 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 13:03:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 13:03:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 13:03:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 13:03:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:03:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 13:03:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 13:03:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-14 13:03:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 13:03:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 13:03:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:03:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 13:03:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 13:03:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:03:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 13:03:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 13:03:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-14 13:03:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 13:03:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 13:03:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:03:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 13:03:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 13:03:59 --> Final output sent to browser
DEBUG - 2016-09-14 13:03:59 --> Total execution time: 0.9436
DEBUG - 2016-09-14 13:03:59 --> Config Class Initialized
DEBUG - 2016-09-14 13:03:59 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:03:59 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:04:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:04:00 --> URI Class Initialized
DEBUG - 2016-09-14 13:04:00 --> Router Class Initialized
ERROR - 2016-09-14 13:04:00 --> 404 Page Not Found --> adaftar_diklat
DEBUG - 2016-09-14 13:04:31 --> Config Class Initialized
DEBUG - 2016-09-14 13:04:31 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:04:31 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:04:31 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:04:31 --> URI Class Initialized
DEBUG - 2016-09-14 13:04:31 --> Router Class Initialized
DEBUG - 2016-09-14 13:04:31 --> Output Class Initialized
DEBUG - 2016-09-14 13:04:31 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 13:04:31 --> Security Class Initialized
DEBUG - 2016-09-14 13:04:31 --> Input Class Initialized
DEBUG - 2016-09-14 13:04:31 --> XSS Filtering completed
DEBUG - 2016-09-14 13:04:31 --> XSS Filtering completed
DEBUG - 2016-09-14 13:04:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 13:04:31 --> Language Class Initialized
DEBUG - 2016-09-14 13:04:32 --> Loader Class Initialized
DEBUG - 2016-09-14 13:04:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 13:04:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 13:04:32 --> Helper loaded: url_helper
DEBUG - 2016-09-14 13:04:32 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 13:04:32 --> Helper loaded: file_helper
DEBUG - 2016-09-14 13:04:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:04:32 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 13:04:32 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 13:04:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:04:32 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 13:04:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 13:04:32 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:04:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 13:04:32 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:04:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 13:04:32 --> Helper loaded: form_helper
DEBUG - 2016-09-14 13:04:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 13:04:32 --> Helper loaded: security_helper
DEBUG - 2016-09-14 13:04:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:04:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 13:04:32 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 13:04:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:04:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 13:04:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 13:04:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 13:04:32 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 13:04:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:04:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 13:04:32 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 13:04:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:04:32 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 13:04:32 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 13:04:32 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 13:04:32 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 13:04:32 --> Database Driver Class Initialized
DEBUG - 2016-09-14 13:04:32 --> Session Class Initialized
DEBUG - 2016-09-14 13:04:32 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 13:04:32 --> Helper loaded: string_helper
DEBUG - 2016-09-14 13:04:32 --> Session routines successfully run
DEBUG - 2016-09-14 13:04:32 --> Native_session Class Initialized
DEBUG - 2016-09-14 13:04:32 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 13:04:32 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:04:32 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:04:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 13:04:32 --> Controller Class Initialized
DEBUG - 2016-09-14 13:04:32 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 13:04:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 13:04:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 13:04:32 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:04:32 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:04:32 --> User Agent Class Initialized
DEBUG - 2016-09-14 13:04:32 --> Model Class Initialized
DEBUG - 2016-09-14 13:04:32 --> Model Class Initialized
DEBUG - 2016-09-14 13:04:32 --> Model Class Initialized
ERROR - 2016-09-14 13:04:32 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 13:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 13:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 13:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 13:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 13:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 13:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-14 13:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 13:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 13:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 13:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 13:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 13:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 13:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-14 13:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 13:04:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 13:04:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:04:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 13:04:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 13:04:33 --> Final output sent to browser
DEBUG - 2016-09-14 13:04:33 --> Total execution time: 0.9583
DEBUG - 2016-09-14 13:04:33 --> Config Class Initialized
DEBUG - 2016-09-14 13:04:33 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:04:33 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:04:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:04:33 --> URI Class Initialized
DEBUG - 2016-09-14 13:04:33 --> Router Class Initialized
ERROR - 2016-09-14 13:04:33 --> 404 Page Not Found --> adaftar_diklat
DEBUG - 2016-09-14 13:04:37 --> Config Class Initialized
DEBUG - 2016-09-14 13:04:37 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:04:37 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:04:37 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:04:37 --> URI Class Initialized
DEBUG - 2016-09-14 13:04:37 --> Router Class Initialized
DEBUG - 2016-09-14 13:04:37 --> Output Class Initialized
DEBUG - 2016-09-14 13:04:37 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 13:04:37 --> Security Class Initialized
DEBUG - 2016-09-14 13:04:37 --> Input Class Initialized
DEBUG - 2016-09-14 13:04:37 --> XSS Filtering completed
DEBUG - 2016-09-14 13:04:37 --> XSS Filtering completed
DEBUG - 2016-09-14 13:04:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 13:04:37 --> Language Class Initialized
DEBUG - 2016-09-14 13:04:37 --> Loader Class Initialized
DEBUG - 2016-09-14 13:04:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 13:04:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 13:04:37 --> Helper loaded: url_helper
DEBUG - 2016-09-14 13:04:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 13:04:37 --> Helper loaded: file_helper
DEBUG - 2016-09-14 13:04:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:04:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 13:04:37 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 13:04:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:04:37 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 13:04:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 13:04:37 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:04:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 13:04:37 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:04:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 13:04:37 --> Helper loaded: form_helper
DEBUG - 2016-09-14 13:04:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 13:04:37 --> Helper loaded: security_helper
DEBUG - 2016-09-14 13:04:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:04:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 13:04:37 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 13:04:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:04:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 13:04:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 13:04:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 13:04:37 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 13:04:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:04:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 13:04:38 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 13:04:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:04:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 13:04:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 13:04:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 13:04:38 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 13:04:38 --> Database Driver Class Initialized
DEBUG - 2016-09-14 13:04:38 --> Session Class Initialized
DEBUG - 2016-09-14 13:04:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 13:04:38 --> Helper loaded: string_helper
DEBUG - 2016-09-14 13:04:38 --> Session routines successfully run
DEBUG - 2016-09-14 13:04:38 --> Native_session Class Initialized
DEBUG - 2016-09-14 13:04:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 13:04:38 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:04:38 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:04:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 13:04:38 --> Controller Class Initialized
DEBUG - 2016-09-14 13:04:38 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 13:04:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 13:04:38 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 13:04:38 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:04:38 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:04:38 --> User Agent Class Initialized
DEBUG - 2016-09-14 13:04:38 --> Model Class Initialized
DEBUG - 2016-09-14 13:04:38 --> Model Class Initialized
DEBUG - 2016-09-14 13:04:38 --> Model Class Initialized
ERROR - 2016-09-14 13:04:38 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 13:04:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 13:04:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 13:04:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 13:04:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:04:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 13:04:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 13:04:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-14 13:04:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 13:04:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 13:04:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:04:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 13:04:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 13:04:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:04:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 13:04:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 13:04:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-14 13:04:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 13:04:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 13:04:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:04:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 13:04:38 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 13:04:38 --> Final output sent to browser
DEBUG - 2016-09-14 13:04:38 --> Total execution time: 0.9611
DEBUG - 2016-09-14 13:04:39 --> Config Class Initialized
DEBUG - 2016-09-14 13:04:39 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:04:39 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:04:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:04:39 --> URI Class Initialized
DEBUG - 2016-09-14 13:04:39 --> Router Class Initialized
ERROR - 2016-09-14 13:04:39 --> 404 Page Not Found --> adaftar_diklat
DEBUG - 2016-09-14 13:05:23 --> Config Class Initialized
DEBUG - 2016-09-14 13:05:23 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:05:23 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:05:23 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:05:23 --> URI Class Initialized
DEBUG - 2016-09-14 13:05:23 --> Router Class Initialized
DEBUG - 2016-09-14 13:05:23 --> Output Class Initialized
DEBUG - 2016-09-14 13:05:23 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 13:05:23 --> Security Class Initialized
DEBUG - 2016-09-14 13:05:23 --> Input Class Initialized
DEBUG - 2016-09-14 13:05:23 --> XSS Filtering completed
DEBUG - 2016-09-14 13:05:23 --> XSS Filtering completed
DEBUG - 2016-09-14 13:05:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 13:05:23 --> Language Class Initialized
DEBUG - 2016-09-14 13:05:23 --> Loader Class Initialized
DEBUG - 2016-09-14 13:05:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 13:05:23 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 13:05:23 --> Helper loaded: url_helper
DEBUG - 2016-09-14 13:05:23 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 13:05:23 --> Helper loaded: file_helper
DEBUG - 2016-09-14 13:05:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:05:23 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 13:05:23 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 13:05:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:05:23 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 13:05:23 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 13:05:23 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:05:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 13:05:24 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:05:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 13:05:24 --> Helper loaded: form_helper
DEBUG - 2016-09-14 13:05:24 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 13:05:24 --> Helper loaded: security_helper
DEBUG - 2016-09-14 13:05:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:05:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 13:05:24 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 13:05:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:05:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 13:05:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 13:05:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 13:05:24 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 13:05:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:05:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 13:05:24 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 13:05:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:05:24 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 13:05:24 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 13:05:24 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 13:05:24 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 13:05:24 --> Database Driver Class Initialized
DEBUG - 2016-09-14 13:05:24 --> Session Class Initialized
DEBUG - 2016-09-14 13:05:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 13:05:24 --> Helper loaded: string_helper
DEBUG - 2016-09-14 13:05:24 --> Session routines successfully run
DEBUG - 2016-09-14 13:05:24 --> Native_session Class Initialized
DEBUG - 2016-09-14 13:05:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 13:05:24 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:05:24 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:05:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 13:05:24 --> Controller Class Initialized
DEBUG - 2016-09-14 13:05:24 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 13:05:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 13:05:24 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 13:05:24 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:05:24 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:05:24 --> User Agent Class Initialized
DEBUG - 2016-09-14 13:05:24 --> Model Class Initialized
DEBUG - 2016-09-14 13:05:24 --> Model Class Initialized
DEBUG - 2016-09-14 13:05:24 --> Model Class Initialized
ERROR - 2016-09-14 13:05:24 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 13:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 13:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 13:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 13:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 13:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 13:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-14 13:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 13:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 13:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 13:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 13:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 13:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 13:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-14 13:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 13:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 13:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 13:05:24 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 13:05:24 --> Final output sent to browser
DEBUG - 2016-09-14 13:05:24 --> Total execution time: 0.9986
DEBUG - 2016-09-14 13:05:25 --> Config Class Initialized
DEBUG - 2016-09-14 13:05:25 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:05:25 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:05:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:05:25 --> URI Class Initialized
DEBUG - 2016-09-14 13:05:25 --> Router Class Initialized
ERROR - 2016-09-14 13:05:25 --> 404 Page Not Found --> adaftar_diklat
DEBUG - 2016-09-14 13:06:02 --> Config Class Initialized
DEBUG - 2016-09-14 13:06:02 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:06:02 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:06:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:06:02 --> URI Class Initialized
DEBUG - 2016-09-14 13:06:02 --> Router Class Initialized
DEBUG - 2016-09-14 13:06:02 --> Output Class Initialized
DEBUG - 2016-09-14 13:06:02 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 13:06:02 --> Security Class Initialized
DEBUG - 2016-09-14 13:06:02 --> Input Class Initialized
DEBUG - 2016-09-14 13:06:02 --> XSS Filtering completed
DEBUG - 2016-09-14 13:06:02 --> XSS Filtering completed
DEBUG - 2016-09-14 13:06:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 13:06:02 --> Language Class Initialized
DEBUG - 2016-09-14 13:06:02 --> Loader Class Initialized
DEBUG - 2016-09-14 13:06:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 13:06:02 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 13:06:02 --> Helper loaded: url_helper
DEBUG - 2016-09-14 13:06:02 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 13:06:02 --> Helper loaded: file_helper
DEBUG - 2016-09-14 13:06:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:06:02 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 13:06:02 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 13:06:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:06:02 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 13:06:02 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 13:06:02 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:06:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 13:06:02 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:06:02 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 13:06:02 --> Helper loaded: form_helper
DEBUG - 2016-09-14 13:06:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 13:06:02 --> Helper loaded: security_helper
DEBUG - 2016-09-14 13:06:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:06:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 13:06:02 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 13:06:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:06:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 13:06:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 13:06:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 13:06:02 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 13:06:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:06:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 13:06:02 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 13:06:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:06:02 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 13:06:02 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 13:06:02 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 13:06:02 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 13:06:02 --> Database Driver Class Initialized
DEBUG - 2016-09-14 13:06:02 --> Session Class Initialized
DEBUG - 2016-09-14 13:06:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 13:06:02 --> Helper loaded: string_helper
DEBUG - 2016-09-14 13:06:02 --> Session routines successfully run
DEBUG - 2016-09-14 13:06:02 --> Native_session Class Initialized
DEBUG - 2016-09-14 13:06:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 13:06:02 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:06:02 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:06:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 13:06:02 --> Controller Class Initialized
DEBUG - 2016-09-14 13:06:02 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 13:06:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 13:06:03 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 13:06:03 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:06:03 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:06:03 --> User Agent Class Initialized
DEBUG - 2016-09-14 13:06:03 --> Model Class Initialized
DEBUG - 2016-09-14 13:06:03 --> Model Class Initialized
DEBUG - 2016-09-14 13:06:03 --> Model Class Initialized
ERROR - 2016-09-14 13:06:03 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 13:06:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 13:06:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 13:06:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 13:06:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:06:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 13:06:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 13:06:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-14 13:06:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 13:06:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 13:06:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:06:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 13:06:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 13:06:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:06:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 13:06:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 13:06:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-14 13:06:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 13:06:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 13:06:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:06:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 13:06:03 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 13:06:03 --> Final output sent to browser
DEBUG - 2016-09-14 13:06:03 --> Total execution time: 1.0293
DEBUG - 2016-09-14 13:06:03 --> Config Class Initialized
DEBUG - 2016-09-14 13:06:03 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:06:03 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:06:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:06:03 --> URI Class Initialized
DEBUG - 2016-09-14 13:06:04 --> Router Class Initialized
ERROR - 2016-09-14 13:06:04 --> 404 Page Not Found --> adaftar_diklat
DEBUG - 2016-09-14 13:20:33 --> Config Class Initialized
DEBUG - 2016-09-14 13:20:33 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:20:33 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:20:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:20:33 --> URI Class Initialized
DEBUG - 2016-09-14 13:20:33 --> Router Class Initialized
DEBUG - 2016-09-14 13:20:33 --> Output Class Initialized
DEBUG - 2016-09-14 13:20:33 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 13:20:33 --> Security Class Initialized
DEBUG - 2016-09-14 13:20:33 --> Input Class Initialized
DEBUG - 2016-09-14 13:20:33 --> XSS Filtering completed
DEBUG - 2016-09-14 13:20:33 --> XSS Filtering completed
DEBUG - 2016-09-14 13:20:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 13:20:33 --> Language Class Initialized
DEBUG - 2016-09-14 13:20:33 --> Loader Class Initialized
DEBUG - 2016-09-14 13:20:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 13:20:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 13:20:33 --> Helper loaded: url_helper
DEBUG - 2016-09-14 13:20:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 13:20:33 --> Helper loaded: file_helper
DEBUG - 2016-09-14 13:20:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:20:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 13:20:33 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 13:20:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:20:33 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 13:20:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 13:20:33 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:20:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 13:20:33 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:20:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 13:20:33 --> Helper loaded: form_helper
DEBUG - 2016-09-14 13:20:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 13:20:33 --> Helper loaded: security_helper
DEBUG - 2016-09-14 13:20:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:20:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 13:20:33 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 13:20:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:20:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 13:20:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 13:20:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 13:20:33 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 13:20:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:20:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 13:20:33 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 13:20:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:20:33 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 13:20:33 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 13:20:33 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 13:20:33 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 13:20:33 --> Database Driver Class Initialized
DEBUG - 2016-09-14 13:20:33 --> Session Class Initialized
DEBUG - 2016-09-14 13:20:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 13:20:34 --> Helper loaded: string_helper
DEBUG - 2016-09-14 13:20:34 --> Session routines successfully run
DEBUG - 2016-09-14 13:20:34 --> Native_session Class Initialized
DEBUG - 2016-09-14 13:20:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 13:20:34 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:20:34 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:20:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 13:20:34 --> Controller Class Initialized
DEBUG - 2016-09-14 13:20:34 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 13:20:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 13:20:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 13:20:34 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:20:34 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:20:34 --> User Agent Class Initialized
DEBUG - 2016-09-14 13:20:34 --> Model Class Initialized
DEBUG - 2016-09-14 13:20:34 --> Model Class Initialized
DEBUG - 2016-09-14 13:20:34 --> Model Class Initialized
ERROR - 2016-09-14 13:20:34 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 13:20:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 13:20:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 13:20:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 13:20:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:20:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 13:20:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 13:20:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-14 13:20:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 13:20:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 13:20:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:20:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 13:20:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 13:20:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:20:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 13:20:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 13:20:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-14 13:20:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 13:20:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 13:20:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:20:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 13:20:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 13:20:34 --> Final output sent to browser
DEBUG - 2016-09-14 13:20:34 --> Total execution time: 1.1852
DEBUG - 2016-09-14 13:20:35 --> Config Class Initialized
DEBUG - 2016-09-14 13:20:35 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:20:35 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:20:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:20:35 --> URI Class Initialized
DEBUG - 2016-09-14 13:20:35 --> Router Class Initialized
ERROR - 2016-09-14 13:20:35 --> 404 Page Not Found --> adaftar_diklat
DEBUG - 2016-09-14 13:21:45 --> Config Class Initialized
DEBUG - 2016-09-14 13:21:45 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:21:45 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:21:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:21:45 --> URI Class Initialized
DEBUG - 2016-09-14 13:21:45 --> Router Class Initialized
DEBUG - 2016-09-14 13:21:45 --> Output Class Initialized
DEBUG - 2016-09-14 13:21:45 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 13:21:45 --> Security Class Initialized
DEBUG - 2016-09-14 13:21:45 --> Input Class Initialized
DEBUG - 2016-09-14 13:21:45 --> XSS Filtering completed
DEBUG - 2016-09-14 13:21:45 --> XSS Filtering completed
DEBUG - 2016-09-14 13:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 13:21:45 --> Language Class Initialized
DEBUG - 2016-09-14 13:21:45 --> Loader Class Initialized
DEBUG - 2016-09-14 13:21:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 13:21:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 13:21:45 --> Helper loaded: url_helper
DEBUG - 2016-09-14 13:21:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 13:21:45 --> Helper loaded: file_helper
DEBUG - 2016-09-14 13:21:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:21:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 13:21:45 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 13:21:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:21:45 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 13:21:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 13:21:45 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:21:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 13:21:45 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:21:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 13:21:45 --> Helper loaded: form_helper
DEBUG - 2016-09-14 13:21:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 13:21:45 --> Helper loaded: security_helper
DEBUG - 2016-09-14 13:21:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:21:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 13:21:45 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 13:21:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:21:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 13:21:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 13:21:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 13:21:45 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 13:21:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:21:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 13:21:45 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 13:21:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:21:46 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 13:21:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 13:21:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 13:21:46 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 13:21:46 --> Database Driver Class Initialized
DEBUG - 2016-09-14 13:21:46 --> Session Class Initialized
DEBUG - 2016-09-14 13:21:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 13:21:46 --> Helper loaded: string_helper
DEBUG - 2016-09-14 13:21:46 --> Session routines successfully run
DEBUG - 2016-09-14 13:21:46 --> Native_session Class Initialized
DEBUG - 2016-09-14 13:21:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 13:21:46 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:21:46 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:21:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 13:21:46 --> Controller Class Initialized
DEBUG - 2016-09-14 13:21:46 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 13:21:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 13:21:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 13:21:46 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:21:46 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:21:46 --> User Agent Class Initialized
DEBUG - 2016-09-14 13:21:46 --> Model Class Initialized
DEBUG - 2016-09-14 13:21:46 --> Model Class Initialized
DEBUG - 2016-09-14 13:21:46 --> Model Class Initialized
ERROR - 2016-09-14 13:21:46 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 13:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 13:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 13:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 13:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 13:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 13:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-14 13:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 13:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 13:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 13:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 13:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 13:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 13:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-14 13:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 13:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 13:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 13:21:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 13:21:46 --> Final output sent to browser
DEBUG - 2016-09-14 13:21:46 --> Total execution time: 1.0803
DEBUG - 2016-09-14 13:21:47 --> Config Class Initialized
DEBUG - 2016-09-14 13:21:47 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:21:47 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:21:47 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:21:47 --> URI Class Initialized
DEBUG - 2016-09-14 13:21:47 --> Router Class Initialized
ERROR - 2016-09-14 13:21:47 --> 404 Page Not Found --> adaftar_diklat
DEBUG - 2016-09-14 13:33:31 --> Config Class Initialized
DEBUG - 2016-09-14 13:33:31 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:33:31 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:33:31 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:33:31 --> URI Class Initialized
DEBUG - 2016-09-14 13:33:31 --> Router Class Initialized
DEBUG - 2016-09-14 13:33:31 --> Output Class Initialized
DEBUG - 2016-09-14 13:33:31 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 13:33:31 --> Security Class Initialized
DEBUG - 2016-09-14 13:33:31 --> Input Class Initialized
DEBUG - 2016-09-14 13:33:31 --> XSS Filtering completed
DEBUG - 2016-09-14 13:33:31 --> XSS Filtering completed
DEBUG - 2016-09-14 13:33:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 13:33:31 --> Language Class Initialized
DEBUG - 2016-09-14 13:33:31 --> Loader Class Initialized
DEBUG - 2016-09-14 13:33:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 13:33:31 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 13:33:31 --> Helper loaded: url_helper
DEBUG - 2016-09-14 13:33:31 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 13:33:31 --> Helper loaded: file_helper
DEBUG - 2016-09-14 13:33:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:33:31 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 13:33:31 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 13:33:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:33:31 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 13:33:31 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 13:33:32 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:33:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 13:33:32 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:33:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 13:33:32 --> Helper loaded: form_helper
DEBUG - 2016-09-14 13:33:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 13:33:32 --> Helper loaded: security_helper
DEBUG - 2016-09-14 13:33:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:33:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 13:33:32 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 13:33:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:33:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 13:33:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 13:33:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 13:33:32 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 13:33:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:33:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 13:33:32 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 13:33:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:33:32 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 13:33:32 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 13:33:32 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 13:33:32 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 13:33:32 --> Database Driver Class Initialized
DEBUG - 2016-09-14 13:33:32 --> Session Class Initialized
DEBUG - 2016-09-14 13:33:32 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 13:33:32 --> Helper loaded: string_helper
DEBUG - 2016-09-14 13:33:32 --> Session routines successfully run
DEBUG - 2016-09-14 13:33:32 --> Native_session Class Initialized
DEBUG - 2016-09-14 13:33:32 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 13:33:32 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:33:32 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:33:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 13:33:32 --> Controller Class Initialized
DEBUG - 2016-09-14 13:33:32 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 13:33:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 13:33:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 13:33:32 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:33:32 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:33:32 --> User Agent Class Initialized
DEBUG - 2016-09-14 13:33:32 --> Model Class Initialized
DEBUG - 2016-09-14 13:33:32 --> Model Class Initialized
DEBUG - 2016-09-14 13:33:32 --> Model Class Initialized
ERROR - 2016-09-14 13:33:32 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-14 13:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-14 13:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-14 13:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 13:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 13:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 13:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-14 13:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 13:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 13:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 13:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-14 13:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:33:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-14 13:33:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-14 13:33:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-14 13:33:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-14 13:33:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-14 13:33:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:33:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-14 13:33:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-14 13:33:33 --> Final output sent to browser
DEBUG - 2016-09-14 13:33:33 --> Total execution time: 1.1871
DEBUG - 2016-09-14 13:33:39 --> Config Class Initialized
DEBUG - 2016-09-14 13:33:39 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:33:39 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:33:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:33:39 --> URI Class Initialized
DEBUG - 2016-09-14 13:33:39 --> Router Class Initialized
ERROR - 2016-09-14 13:33:39 --> 404 Page Not Found --> adaftar_diklat
DEBUG - 2016-09-14 13:33:40 --> Config Class Initialized
DEBUG - 2016-09-14 13:33:40 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:33:40 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:33:40 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:33:40 --> URI Class Initialized
DEBUG - 2016-09-14 13:33:40 --> Router Class Initialized
DEBUG - 2016-09-14 13:33:40 --> Output Class Initialized
DEBUG - 2016-09-14 13:33:40 --> Security Class Initialized
DEBUG - 2016-09-14 13:33:40 --> Input Class Initialized
DEBUG - 2016-09-14 13:33:40 --> XSS Filtering completed
DEBUG - 2016-09-14 13:33:40 --> XSS Filtering completed
DEBUG - 2016-09-14 13:33:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 13:33:40 --> Language Class Initialized
DEBUG - 2016-09-14 13:33:40 --> Loader Class Initialized
DEBUG - 2016-09-14 13:33:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 13:33:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 13:33:40 --> Helper loaded: url_helper
DEBUG - 2016-09-14 13:33:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 13:33:40 --> Helper loaded: file_helper
DEBUG - 2016-09-14 13:33:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:33:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 13:33:41 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 13:33:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:33:41 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 13:33:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 13:33:41 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:33:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 13:33:41 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:33:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 13:33:41 --> Helper loaded: form_helper
DEBUG - 2016-09-14 13:33:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 13:33:41 --> Helper loaded: security_helper
DEBUG - 2016-09-14 13:33:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:33:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 13:33:41 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 13:33:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:33:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 13:33:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 13:33:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 13:33:41 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 13:33:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:33:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 13:33:41 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 13:33:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:33:41 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 13:33:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 13:33:41 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 13:33:41 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 13:33:41 --> Database Driver Class Initialized
DEBUG - 2016-09-14 13:33:41 --> Session Class Initialized
DEBUG - 2016-09-14 13:33:41 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 13:33:41 --> Helper loaded: string_helper
DEBUG - 2016-09-14 13:33:42 --> Session routines successfully run
DEBUG - 2016-09-14 13:33:42 --> Native_session Class Initialized
DEBUG - 2016-09-14 13:33:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 13:33:42 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:33:42 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:33:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 13:33:42 --> Controller Class Initialized
DEBUG - 2016-09-14 13:33:42 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 13:33:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 13:33:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 13:33:42 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:33:42 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:33:42 --> User Agent Class Initialized
DEBUG - 2016-09-14 13:33:42 --> Model Class Initialized
DEBUG - 2016-09-14 13:33:42 --> Model Class Initialized
DEBUG - 2016-09-14 13:33:43 --> Model Class Initialized
DEBUG - 2016-09-14 13:33:43 --> Model Class Initialized
DEBUG - 2016-09-14 13:33:43 --> Model Class Initialized
DEBUG - 2016-09-14 13:33:44 --> Model Class Initialized
DEBUG - 2016-09-14 13:33:44 --> Model Class Initialized
DEBUG - 2016-09-14 13:33:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-14 13:33:45 --> Pagination Class Initialized
DEBUG - 2016-09-14 13:33:46 --> Config Class Initialized
DEBUG - 2016-09-14 13:33:46 --> Hooks Class Initialized
DEBUG - 2016-09-14 13:33:46 --> Utf8 Class Initialized
DEBUG - 2016-09-14 13:33:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-14 13:33:46 --> URI Class Initialized
DEBUG - 2016-09-14 13:33:46 --> Router Class Initialized
DEBUG - 2016-09-14 13:33:46 --> Output Class Initialized
DEBUG - 2016-09-14 13:33:46 --> Cache file has expired. File deleted
DEBUG - 2016-09-14 13:33:46 --> Security Class Initialized
DEBUG - 2016-09-14 13:33:46 --> Input Class Initialized
DEBUG - 2016-09-14 13:33:46 --> XSS Filtering completed
DEBUG - 2016-09-14 13:33:46 --> XSS Filtering completed
DEBUG - 2016-09-14 13:33:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-14 13:33:46 --> Language Class Initialized
DEBUG - 2016-09-14 13:33:46 --> Loader Class Initialized
DEBUG - 2016-09-14 13:33:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-14 13:33:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-14 13:33:46 --> Helper loaded: url_helper
DEBUG - 2016-09-14 13:33:47 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-14 13:33:47 --> Helper loaded: file_helper
DEBUG - 2016-09-14 13:33:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:33:47 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-14 13:33:47 --> Helper loaded: conf_helper
DEBUG - 2016-09-14 13:33:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-14 13:33:47 --> Check Exists common_helper.php: No
DEBUG - 2016-09-14 13:33:47 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-14 13:33:47 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:33:47 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-14 13:33:47 --> Helper loaded: common_helper
DEBUG - 2016-09-14 13:33:47 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-14 13:33:47 --> Helper loaded: form_helper
DEBUG - 2016-09-14 13:33:47 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-14 13:33:47 --> Helper loaded: security_helper
DEBUG - 2016-09-14 13:33:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:33:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-14 13:33:47 --> Helper loaded: lang_helper
DEBUG - 2016-09-14 13:33:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-14 13:33:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-14 13:33:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-14 13:33:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-14 13:33:47 --> Helper loaded: atlant_helper
DEBUG - 2016-09-14 13:33:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:33:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-14 13:33:47 --> Helper loaded: crypto_helper
DEBUG - 2016-09-14 13:33:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-14 13:33:47 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-14 13:33:47 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-14 13:33:47 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-14 13:33:47 --> Helper loaded: sidika_helper
DEBUG - 2016-09-14 13:33:47 --> Database Driver Class Initialized
DEBUG - 2016-09-14 13:33:47 --> Session Class Initialized
DEBUG - 2016-09-14 13:33:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-14 13:33:47 --> Helper loaded: string_helper
DEBUG - 2016-09-14 13:33:47 --> Session routines successfully run
DEBUG - 2016-09-14 13:33:47 --> Native_session Class Initialized
DEBUG - 2016-09-14 13:33:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-14 13:33:47 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:33:47 --> Form Validation Class Initialized
DEBUG - 2016-09-14 13:33:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-14 13:33:47 --> Controller Class Initialized
DEBUG - 2016-09-14 13:33:47 --> Carabiner: Library initialized.
DEBUG - 2016-09-14 13:33:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-14 13:33:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-14 13:33:47 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:33:47 --> Carabiner: library configured.
DEBUG - 2016-09-14 13:33:47 --> User Agent Class Initialized
DEBUG - 2016-09-14 13:33:47 --> Model Class Initialized
DEBUG - 2016-09-14 13:33:48 --> Model Class Initialized
DEBUG - 2016-09-14 13:33:48 --> Model Class Initialized
DEBUG - 2016-09-14 13:33:48 --> Model Class Initialized
DEBUG - 2016-09-14 13:33:48 --> Model Class Initialized
DEBUG - 2016-09-14 13:33:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-14 13:33:48 --> Pagination Class Initialized
DEBUG - 2016-09-14 13:33:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-14 13:33:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/index.php
DEBUG - 2016-09-14 13:33:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-14 13:33:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-14 13:33:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:33:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 13:33:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-09-14 13:33:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:33:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-14 13:33:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-14 13:33:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-14 13:33:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-14 13:33:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-14 13:33:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-09-14 13:33:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-14 13:33:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-14 13:33:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/860bebf57fee032e24acce1c64d1c3e7
DEBUG - 2016-09-14 13:33:48 --> Final output sent to browser
DEBUG - 2016-09-14 13:33:48 --> Total execution time: 1.9992
