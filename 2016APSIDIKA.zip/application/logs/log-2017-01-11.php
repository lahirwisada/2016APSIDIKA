<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2017-01-11 08:09:25 --> Config Class Initialized
DEBUG - 2017-01-11 08:09:25 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:09:25 --> Utf8 Class Initialized
DEBUG - 2017-01-11 08:09:25 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 08:09:25 --> URI Class Initialized
DEBUG - 2017-01-11 08:09:25 --> Router Class Initialized
DEBUG - 2017-01-11 08:09:25 --> No URI present. Default controller set.
DEBUG - 2017-01-11 08:09:25 --> Output Class Initialized
DEBUG - 2017-01-11 08:09:25 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 08:09:25 --> Security Class Initialized
DEBUG - 2017-01-11 08:09:25 --> Input Class Initialized
DEBUG - 2017-01-11 08:09:25 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:25 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 08:09:25 --> Language Class Initialized
DEBUG - 2017-01-11 08:09:25 --> Loader Class Initialized
DEBUG - 2017-01-11 08:09:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 08:09:25 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 08:09:25 --> Helper loaded: url_helper
DEBUG - 2017-01-11 08:09:25 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 08:09:25 --> Helper loaded: file_helper
DEBUG - 2017-01-11 08:09:25 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 08:09:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 08:09:25 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 08:09:25 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 08:09:25 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 08:09:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 08:09:25 --> Helper loaded: common_helper
DEBUG - 2017-01-11 08:09:25 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 08:09:25 --> Helper loaded: common_helper
DEBUG - 2017-01-11 08:09:25 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 08:09:25 --> Helper loaded: form_helper
DEBUG - 2017-01-11 08:09:25 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 08:09:25 --> Helper loaded: security_helper
DEBUG - 2017-01-11 08:09:25 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 08:09:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 08:09:25 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 08:09:25 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 08:09:25 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 08:09:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 08:09:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 08:09:25 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 08:09:25 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 08:09:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 08:09:25 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 08:09:25 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 08:09:25 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 08:09:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 08:09:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 08:09:25 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 08:09:25 --> Database Driver Class Initialized
DEBUG - 2017-01-11 08:09:25 --> Session Class Initialized
DEBUG - 2017-01-11 08:09:25 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 08:09:25 --> Helper loaded: string_helper
DEBUG - 2017-01-11 08:09:25 --> Session routines successfully run
DEBUG - 2017-01-11 08:09:25 --> Native_session Class Initialized
DEBUG - 2017-01-11 08:09:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 08:09:25 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:09:25 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:09:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 08:09:25 --> Controller Class Initialized
DEBUG - 2017-01-11 08:09:25 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 08:09:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 08:09:25 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 08:09:25 --> Carabiner: library configured.
DEBUG - 2017-01-11 08:09:25 --> Carabiner: library configured.
DEBUG - 2017-01-11 08:09:25 --> User Agent Class Initialized
DEBUG - 2017-01-11 08:09:25 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:25 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:25 --> Model Class Initialized
ERROR - 2017-01-11 08:09:25 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2017-01-11 08:09:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2017-01-11 08:09:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2017-01-11 08:09:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-11 08:09:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 08:09:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-11 08:09:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-11 08:09:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-11 08:09:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-11 08:09:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-11 08:09:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 08:09:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-11 08:09:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-11 08:09:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 08:09:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-11 08:09:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-11 08:09:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-11 08:09:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-11 08:09:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-11 08:09:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 08:09:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-11 08:09:25 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2017-01-11 08:09:25 --> Final output sent to browser
DEBUG - 2017-01-11 08:09:25 --> Total execution time: 0.6058
DEBUG - 2017-01-11 08:09:26 --> Config Class Initialized
DEBUG - 2017-01-11 08:09:26 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:09:26 --> Utf8 Class Initialized
DEBUG - 2017-01-11 08:09:26 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 08:09:26 --> URI Class Initialized
DEBUG - 2017-01-11 08:09:26 --> Router Class Initialized
DEBUG - 2017-01-11 08:09:26 --> Output Class Initialized
DEBUG - 2017-01-11 08:09:26 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 08:09:26 --> Security Class Initialized
DEBUG - 2017-01-11 08:09:26 --> Input Class Initialized
DEBUG - 2017-01-11 08:09:26 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:26 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:26 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:26 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:26 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:26 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:26 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:26 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 08:09:26 --> Language Class Initialized
DEBUG - 2017-01-11 08:09:26 --> Loader Class Initialized
DEBUG - 2017-01-11 08:09:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 08:09:26 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 08:09:26 --> Helper loaded: url_helper
DEBUG - 2017-01-11 08:09:26 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 08:09:26 --> Helper loaded: file_helper
DEBUG - 2017-01-11 08:09:26 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 08:09:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 08:09:26 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 08:09:26 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 08:09:26 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 08:09:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 08:09:26 --> Helper loaded: common_helper
DEBUG - 2017-01-11 08:09:26 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 08:09:26 --> Helper loaded: common_helper
DEBUG - 2017-01-11 08:09:26 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 08:09:26 --> Helper loaded: form_helper
DEBUG - 2017-01-11 08:09:26 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 08:09:26 --> Helper loaded: security_helper
DEBUG - 2017-01-11 08:09:26 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 08:09:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 08:09:26 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 08:09:26 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 08:09:26 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 08:09:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 08:09:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 08:09:26 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 08:09:26 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 08:09:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 08:09:26 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 08:09:26 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 08:09:26 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 08:09:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 08:09:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 08:09:26 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 08:09:26 --> Database Driver Class Initialized
DEBUG - 2017-01-11 08:09:26 --> Session Class Initialized
DEBUG - 2017-01-11 08:09:26 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 08:09:26 --> Helper loaded: string_helper
DEBUG - 2017-01-11 08:09:26 --> Session routines successfully run
DEBUG - 2017-01-11 08:09:26 --> Native_session Class Initialized
DEBUG - 2017-01-11 08:09:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 08:09:26 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:09:26 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:09:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 08:09:26 --> Controller Class Initialized
DEBUG - 2017-01-11 08:09:26 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 08:09:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 08:09:26 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 08:09:26 --> Carabiner: library configured.
DEBUG - 2017-01-11 08:09:26 --> Carabiner: library configured.
DEBUG - 2017-01-11 08:09:26 --> User Agent Class Initialized
DEBUG - 2017-01-11 08:09:26 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:26 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:26 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:26 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:26 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:26 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:26 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:26 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2017-01-11 08:09:26 --> Final output sent to browser
DEBUG - 2017-01-11 08:09:26 --> Total execution time: 0.2982
DEBUG - 2017-01-11 08:09:34 --> Config Class Initialized
DEBUG - 2017-01-11 08:09:34 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:09:34 --> Utf8 Class Initialized
DEBUG - 2017-01-11 08:09:34 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 08:09:34 --> URI Class Initialized
DEBUG - 2017-01-11 08:09:34 --> Router Class Initialized
DEBUG - 2017-01-11 08:09:34 --> Output Class Initialized
DEBUG - 2017-01-11 08:09:34 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 08:09:34 --> Security Class Initialized
DEBUG - 2017-01-11 08:09:34 --> Input Class Initialized
DEBUG - 2017-01-11 08:09:34 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:34 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:34 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 08:09:34 --> Language Class Initialized
DEBUG - 2017-01-11 08:09:34 --> Loader Class Initialized
DEBUG - 2017-01-11 08:09:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 08:09:34 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 08:09:34 --> Helper loaded: url_helper
DEBUG - 2017-01-11 08:09:34 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 08:09:34 --> Helper loaded: file_helper
DEBUG - 2017-01-11 08:09:34 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 08:09:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 08:09:34 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 08:09:34 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 08:09:34 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 08:09:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 08:09:34 --> Helper loaded: common_helper
DEBUG - 2017-01-11 08:09:34 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 08:09:34 --> Helper loaded: common_helper
DEBUG - 2017-01-11 08:09:34 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 08:09:34 --> Helper loaded: form_helper
DEBUG - 2017-01-11 08:09:34 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 08:09:34 --> Helper loaded: security_helper
DEBUG - 2017-01-11 08:09:34 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 08:09:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 08:09:34 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 08:09:34 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 08:09:34 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 08:09:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 08:09:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 08:09:34 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 08:09:34 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 08:09:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 08:09:34 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 08:09:34 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 08:09:34 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 08:09:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 08:09:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 08:09:34 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 08:09:34 --> Database Driver Class Initialized
DEBUG - 2017-01-11 08:09:34 --> Session Class Initialized
DEBUG - 2017-01-11 08:09:34 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 08:09:34 --> Helper loaded: string_helper
DEBUG - 2017-01-11 08:09:34 --> Session routines successfully run
DEBUG - 2017-01-11 08:09:34 --> Native_session Class Initialized
DEBUG - 2017-01-11 08:09:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 08:09:34 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:09:34 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:09:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 08:09:34 --> Controller Class Initialized
DEBUG - 2017-01-11 08:09:34 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 08:09:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 08:09:34 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 08:09:34 --> Carabiner: library configured.
DEBUG - 2017-01-11 08:09:34 --> Carabiner: library configured.
DEBUG - 2017-01-11 08:09:34 --> User Agent Class Initialized
DEBUG - 2017-01-11 08:09:34 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:34 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:34 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2017-01-11 08:09:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-11 08:09:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-11 08:09:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 08:09:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-11 08:09:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 08:09:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-11 08:09:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-11 08:09:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-11 08:09:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 08:09:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-11 08:09:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 08:09:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-11 08:09:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2017-01-11 08:09:34 --> Final output sent to browser
DEBUG - 2017-01-11 08:09:34 --> Total execution time: 0.2199
DEBUG - 2017-01-11 08:09:38 --> Config Class Initialized
DEBUG - 2017-01-11 08:09:38 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:09:38 --> Utf8 Class Initialized
DEBUG - 2017-01-11 08:09:38 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 08:09:38 --> URI Class Initialized
DEBUG - 2017-01-11 08:09:38 --> Router Class Initialized
DEBUG - 2017-01-11 08:09:38 --> Output Class Initialized
DEBUG - 2017-01-11 08:09:38 --> Security Class Initialized
DEBUG - 2017-01-11 08:09:38 --> Input Class Initialized
DEBUG - 2017-01-11 08:09:38 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:38 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:38 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 08:09:38 --> Language Class Initialized
DEBUG - 2017-01-11 08:09:38 --> Loader Class Initialized
DEBUG - 2017-01-11 08:09:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 08:09:38 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 08:09:38 --> Helper loaded: url_helper
DEBUG - 2017-01-11 08:09:38 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 08:09:38 --> Helper loaded: file_helper
DEBUG - 2017-01-11 08:09:38 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 08:09:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 08:09:38 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 08:09:38 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 08:09:38 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 08:09:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 08:09:38 --> Helper loaded: common_helper
DEBUG - 2017-01-11 08:09:38 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 08:09:38 --> Helper loaded: common_helper
DEBUG - 2017-01-11 08:09:38 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 08:09:38 --> Helper loaded: form_helper
DEBUG - 2017-01-11 08:09:38 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 08:09:38 --> Helper loaded: security_helper
DEBUG - 2017-01-11 08:09:38 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 08:09:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 08:09:38 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 08:09:38 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 08:09:38 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 08:09:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 08:09:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 08:09:38 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 08:09:38 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 08:09:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 08:09:38 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 08:09:38 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 08:09:38 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 08:09:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 08:09:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 08:09:38 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 08:09:38 --> Database Driver Class Initialized
DEBUG - 2017-01-11 08:09:38 --> Session Class Initialized
DEBUG - 2017-01-11 08:09:38 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 08:09:38 --> Helper loaded: string_helper
DEBUG - 2017-01-11 08:09:38 --> Session routines successfully run
DEBUG - 2017-01-11 08:09:38 --> Native_session Class Initialized
DEBUG - 2017-01-11 08:09:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 08:09:38 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:09:38 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:09:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 08:09:38 --> Controller Class Initialized
DEBUG - 2017-01-11 08:09:38 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 08:09:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 08:09:38 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 08:09:38 --> Carabiner: library configured.
DEBUG - 2017-01-11 08:09:38 --> Carabiner: library configured.
DEBUG - 2017-01-11 08:09:38 --> User Agent Class Initialized
DEBUG - 2017-01-11 08:09:38 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:38 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:38 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:38 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:38 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:38 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:38 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:38 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2017-01-11 08:09:38 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2017-01-11 08:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2017-01-11 08:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2017-01-11 08:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2017-01-11 08:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2017-01-11 08:09:38 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2017-01-11 08:09:38 --> Final output sent to browser
DEBUG - 2017-01-11 08:09:38 --> Total execution time: 0.2371
DEBUG - 2017-01-11 08:09:38 --> Config Class Initialized
DEBUG - 2017-01-11 08:09:38 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:09:38 --> Utf8 Class Initialized
DEBUG - 2017-01-11 08:09:38 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 08:09:38 --> URI Class Initialized
DEBUG - 2017-01-11 08:09:38 --> Router Class Initialized
ERROR - 2017-01-11 08:09:38 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2017-01-11 08:09:40 --> Config Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Utf8 Class Initialized
DEBUG - 2017-01-11 08:09:40 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 08:09:40 --> URI Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Router Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Output Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 08:09:40 --> Security Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Input Class Initialized
DEBUG - 2017-01-11 08:09:40 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:40 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:40 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:40 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 08:09:40 --> Language Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Loader Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 08:09:40 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 08:09:40 --> Helper loaded: url_helper
DEBUG - 2017-01-11 08:09:40 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 08:09:40 --> Helper loaded: file_helper
DEBUG - 2017-01-11 08:09:40 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 08:09:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 08:09:40 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 08:09:40 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 08:09:40 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 08:09:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 08:09:40 --> Helper loaded: common_helper
DEBUG - 2017-01-11 08:09:40 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 08:09:40 --> Helper loaded: common_helper
DEBUG - 2017-01-11 08:09:40 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 08:09:40 --> Helper loaded: form_helper
DEBUG - 2017-01-11 08:09:40 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 08:09:40 --> Helper loaded: security_helper
DEBUG - 2017-01-11 08:09:40 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 08:09:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 08:09:40 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 08:09:40 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 08:09:40 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 08:09:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 08:09:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 08:09:40 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 08:09:40 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 08:09:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 08:09:40 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 08:09:40 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 08:09:40 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 08:09:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 08:09:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 08:09:40 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 08:09:40 --> Database Driver Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Session Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 08:09:40 --> Helper loaded: string_helper
DEBUG - 2017-01-11 08:09:40 --> Session routines successfully run
DEBUG - 2017-01-11 08:09:40 --> Native_session Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 08:09:40 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 08:09:40 --> Controller Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 08:09:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 08:09:40 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 08:09:40 --> Carabiner: library configured.
DEBUG - 2017-01-11 08:09:40 --> Carabiner: library configured.
DEBUG - 2017-01-11 08:09:40 --> User Agent Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2017-01-11 08:09:40 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 08:09:40 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2017-01-11 08:09:40 --> Config Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Utf8 Class Initialized
DEBUG - 2017-01-11 08:09:40 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 08:09:40 --> URI Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Router Class Initialized
DEBUG - 2017-01-11 08:09:40 --> No URI present. Default controller set.
DEBUG - 2017-01-11 08:09:40 --> Output Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 08:09:40 --> Security Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Input Class Initialized
DEBUG - 2017-01-11 08:09:40 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:40 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:40 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 08:09:40 --> Language Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Loader Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 08:09:40 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 08:09:40 --> Helper loaded: url_helper
DEBUG - 2017-01-11 08:09:40 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 08:09:40 --> Helper loaded: file_helper
DEBUG - 2017-01-11 08:09:40 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 08:09:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 08:09:40 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 08:09:40 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 08:09:40 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 08:09:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 08:09:40 --> Helper loaded: common_helper
DEBUG - 2017-01-11 08:09:40 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 08:09:40 --> Helper loaded: common_helper
DEBUG - 2017-01-11 08:09:40 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 08:09:40 --> Helper loaded: form_helper
DEBUG - 2017-01-11 08:09:40 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 08:09:40 --> Helper loaded: security_helper
DEBUG - 2017-01-11 08:09:40 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 08:09:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 08:09:40 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 08:09:40 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 08:09:40 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 08:09:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 08:09:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 08:09:40 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 08:09:40 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 08:09:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 08:09:40 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 08:09:40 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 08:09:40 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 08:09:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 08:09:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 08:09:40 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 08:09:40 --> Database Driver Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Session Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 08:09:40 --> Helper loaded: string_helper
DEBUG - 2017-01-11 08:09:40 --> Session routines successfully run
DEBUG - 2017-01-11 08:09:40 --> Native_session Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 08:09:40 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 08:09:40 --> Controller Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 08:09:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 08:09:40 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 08:09:40 --> Carabiner: library configured.
DEBUG - 2017-01-11 08:09:40 --> Carabiner: library configured.
DEBUG - 2017-01-11 08:09:40 --> User Agent Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Model Class Initialized
ERROR - 2017-01-11 08:09:40 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2017-01-11 08:09:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2017-01-11 08:09:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2017-01-11 08:09:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-11 08:09:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 08:09:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-11 08:09:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-11 08:09:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-11 08:09:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-11 08:09:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-11 08:09:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 08:09:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-11 08:09:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-11 08:09:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 08:09:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-11 08:09:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-11 08:09:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-11 08:09:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-11 08:09:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-11 08:09:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 08:09:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-11 08:09:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2017-01-11 08:09:40 --> Final output sent to browser
DEBUG - 2017-01-11 08:09:40 --> Total execution time: 0.2720
DEBUG - 2017-01-11 08:09:40 --> Config Class Initialized
DEBUG - 2017-01-11 08:09:40 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:09:41 --> Utf8 Class Initialized
DEBUG - 2017-01-11 08:09:41 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 08:09:41 --> URI Class Initialized
DEBUG - 2017-01-11 08:09:41 --> Router Class Initialized
DEBUG - 2017-01-11 08:09:41 --> Output Class Initialized
DEBUG - 2017-01-11 08:09:41 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 08:09:41 --> Security Class Initialized
DEBUG - 2017-01-11 08:09:41 --> Input Class Initialized
DEBUG - 2017-01-11 08:09:41 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:41 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:41 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:41 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:41 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:41 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:41 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 08:09:41 --> Language Class Initialized
DEBUG - 2017-01-11 08:09:41 --> Loader Class Initialized
DEBUG - 2017-01-11 08:09:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 08:09:41 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 08:09:41 --> Helper loaded: url_helper
DEBUG - 2017-01-11 08:09:41 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 08:09:41 --> Helper loaded: file_helper
DEBUG - 2017-01-11 08:09:41 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 08:09:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 08:09:41 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 08:09:41 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 08:09:41 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 08:09:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 08:09:41 --> Helper loaded: common_helper
DEBUG - 2017-01-11 08:09:41 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 08:09:41 --> Helper loaded: common_helper
DEBUG - 2017-01-11 08:09:41 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 08:09:41 --> Helper loaded: form_helper
DEBUG - 2017-01-11 08:09:41 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 08:09:41 --> Helper loaded: security_helper
DEBUG - 2017-01-11 08:09:41 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 08:09:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 08:09:41 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 08:09:41 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 08:09:41 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 08:09:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 08:09:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 08:09:41 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 08:09:41 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 08:09:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 08:09:41 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 08:09:41 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 08:09:41 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 08:09:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 08:09:41 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 08:09:41 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 08:09:41 --> Database Driver Class Initialized
DEBUG - 2017-01-11 08:09:41 --> Session Class Initialized
DEBUG - 2017-01-11 08:09:41 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 08:09:41 --> Helper loaded: string_helper
DEBUG - 2017-01-11 08:09:41 --> Session routines successfully run
DEBUG - 2017-01-11 08:09:41 --> Native_session Class Initialized
DEBUG - 2017-01-11 08:09:41 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 08:09:41 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:09:41 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:09:41 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 08:09:41 --> Controller Class Initialized
DEBUG - 2017-01-11 08:09:41 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 08:09:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 08:09:41 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 08:09:41 --> Carabiner: library configured.
DEBUG - 2017-01-11 08:09:41 --> Carabiner: library configured.
DEBUG - 2017-01-11 08:09:41 --> User Agent Class Initialized
DEBUG - 2017-01-11 08:09:41 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:41 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:41 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:41 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:41 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:41 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:41 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:41 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2017-01-11 08:09:41 --> Final output sent to browser
DEBUG - 2017-01-11 08:09:41 --> Total execution time: 0.3501
DEBUG - 2017-01-11 08:09:42 --> Config Class Initialized
DEBUG - 2017-01-11 08:09:42 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:09:42 --> Utf8 Class Initialized
DEBUG - 2017-01-11 08:09:42 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 08:09:42 --> URI Class Initialized
DEBUG - 2017-01-11 08:09:42 --> Router Class Initialized
DEBUG - 2017-01-11 08:09:42 --> Output Class Initialized
DEBUG - 2017-01-11 08:09:42 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 08:09:42 --> Security Class Initialized
DEBUG - 2017-01-11 08:09:42 --> Input Class Initialized
DEBUG - 2017-01-11 08:09:42 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:42 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:42 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 08:09:42 --> Language Class Initialized
DEBUG - 2017-01-11 08:09:42 --> Loader Class Initialized
DEBUG - 2017-01-11 08:09:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 08:09:42 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 08:09:42 --> Helper loaded: url_helper
DEBUG - 2017-01-11 08:09:42 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 08:09:42 --> Helper loaded: file_helper
DEBUG - 2017-01-11 08:09:42 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 08:09:42 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 08:09:42 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 08:09:42 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 08:09:42 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 08:09:42 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 08:09:42 --> Helper loaded: common_helper
DEBUG - 2017-01-11 08:09:42 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 08:09:42 --> Helper loaded: common_helper
DEBUG - 2017-01-11 08:09:42 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 08:09:42 --> Helper loaded: form_helper
DEBUG - 2017-01-11 08:09:42 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 08:09:42 --> Helper loaded: security_helper
DEBUG - 2017-01-11 08:09:42 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 08:09:42 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 08:09:42 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 08:09:42 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 08:09:42 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 08:09:42 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 08:09:42 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 08:09:42 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 08:09:42 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 08:09:42 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 08:09:42 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 08:09:42 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 08:09:42 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 08:09:42 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 08:09:42 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 08:09:42 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 08:09:42 --> Database Driver Class Initialized
DEBUG - 2017-01-11 08:09:42 --> Session Class Initialized
DEBUG - 2017-01-11 08:09:42 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 08:09:42 --> Helper loaded: string_helper
DEBUG - 2017-01-11 08:09:42 --> Session routines successfully run
DEBUG - 2017-01-11 08:09:42 --> Native_session Class Initialized
DEBUG - 2017-01-11 08:09:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 08:09:42 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:09:42 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:09:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 08:09:42 --> Controller Class Initialized
DEBUG - 2017-01-11 08:09:42 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 08:09:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 08:09:42 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 08:09:42 --> Carabiner: library configured.
DEBUG - 2017-01-11 08:09:42 --> Carabiner: library configured.
DEBUG - 2017-01-11 08:09:42 --> User Agent Class Initialized
DEBUG - 2017-01-11 08:09:42 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:42 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:42 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2017-01-11 08:09:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-11 08:09:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-11 08:09:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 08:09:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-11 08:09:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 08:09:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-11 08:09:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-11 08:09:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-11 08:09:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 08:09:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-11 08:09:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 08:09:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-11 08:09:43 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2017-01-11 08:09:43 --> Final output sent to browser
DEBUG - 2017-01-11 08:09:43 --> Total execution time: 0.3031
DEBUG - 2017-01-11 08:09:46 --> Config Class Initialized
DEBUG - 2017-01-11 08:09:46 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:09:46 --> Utf8 Class Initialized
DEBUG - 2017-01-11 08:09:46 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 08:09:46 --> URI Class Initialized
DEBUG - 2017-01-11 08:09:46 --> Router Class Initialized
DEBUG - 2017-01-11 08:09:46 --> Output Class Initialized
DEBUG - 2017-01-11 08:09:46 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 08:09:46 --> Security Class Initialized
DEBUG - 2017-01-11 08:09:46 --> Input Class Initialized
DEBUG - 2017-01-11 08:09:46 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:46 --> XSS Filtering completed
DEBUG - 2017-01-11 08:09:46 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 08:09:46 --> Language Class Initialized
DEBUG - 2017-01-11 08:09:46 --> Loader Class Initialized
DEBUG - 2017-01-11 08:09:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 08:09:46 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 08:09:46 --> Helper loaded: url_helper
DEBUG - 2017-01-11 08:09:46 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 08:09:46 --> Helper loaded: file_helper
DEBUG - 2017-01-11 08:09:46 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 08:09:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 08:09:46 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 08:09:46 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 08:09:46 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 08:09:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 08:09:46 --> Helper loaded: common_helper
DEBUG - 2017-01-11 08:09:46 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 08:09:46 --> Helper loaded: common_helper
DEBUG - 2017-01-11 08:09:46 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 08:09:46 --> Helper loaded: form_helper
DEBUG - 2017-01-11 08:09:46 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 08:09:46 --> Helper loaded: security_helper
DEBUG - 2017-01-11 08:09:46 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 08:09:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 08:09:46 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 08:09:46 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 08:09:46 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 08:09:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 08:09:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 08:09:46 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 08:09:46 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 08:09:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 08:09:46 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 08:09:46 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 08:09:46 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 08:09:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 08:09:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 08:09:46 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 08:09:46 --> Database Driver Class Initialized
DEBUG - 2017-01-11 08:09:46 --> Session Class Initialized
DEBUG - 2017-01-11 08:09:46 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 08:09:46 --> Helper loaded: string_helper
DEBUG - 2017-01-11 08:09:46 --> Session routines successfully run
DEBUG - 2017-01-11 08:09:46 --> Native_session Class Initialized
DEBUG - 2017-01-11 08:09:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 08:09:46 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:09:46 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:09:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 08:09:46 --> Controller Class Initialized
DEBUG - 2017-01-11 08:09:46 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 08:09:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 08:09:46 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 08:09:46 --> Carabiner: library configured.
DEBUG - 2017-01-11 08:09:46 --> Carabiner: library configured.
DEBUG - 2017-01-11 08:09:46 --> User Agent Class Initialized
DEBUG - 2017-01-11 08:09:46 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:46 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:46 --> Model Class Initialized
DEBUG - 2017-01-11 08:09:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2017-01-11 08:09:46 --> Pagination Class Initialized
DEBUG - 2017-01-11 08:09:46 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2017-01-11 08:09:46 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/index.php
DEBUG - 2017-01-11 08:09:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-11 08:09:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-11 08:09:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 08:09:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-11 08:09:46 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2017-01-11 08:09:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 08:09:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-11 08:09:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-11 08:09:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-11 08:09:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 08:09:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-11 08:09:46 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2017-01-11 08:09:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 08:09:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-11 08:09:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8118d087c6d6c5bac3947ef2cf7a3513
DEBUG - 2017-01-11 08:09:46 --> Final output sent to browser
DEBUG - 2017-01-11 08:09:46 --> Total execution time: 0.3875
DEBUG - 2017-01-11 08:10:09 --> Config Class Initialized
DEBUG - 2017-01-11 08:10:09 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:10:09 --> Utf8 Class Initialized
DEBUG - 2017-01-11 08:10:09 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 08:10:09 --> URI Class Initialized
DEBUG - 2017-01-11 08:10:09 --> Router Class Initialized
DEBUG - 2017-01-11 08:10:09 --> Output Class Initialized
DEBUG - 2017-01-11 08:10:09 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 08:10:09 --> Security Class Initialized
DEBUG - 2017-01-11 08:10:09 --> Input Class Initialized
DEBUG - 2017-01-11 08:10:09 --> XSS Filtering completed
DEBUG - 2017-01-11 08:10:09 --> XSS Filtering completed
DEBUG - 2017-01-11 08:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 08:10:09 --> Language Class Initialized
DEBUG - 2017-01-11 08:10:09 --> Loader Class Initialized
DEBUG - 2017-01-11 08:10:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 08:10:09 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 08:10:09 --> Helper loaded: url_helper
DEBUG - 2017-01-11 08:10:09 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 08:10:09 --> Helper loaded: file_helper
DEBUG - 2017-01-11 08:10:09 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 08:10:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 08:10:09 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 08:10:09 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 08:10:09 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 08:10:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 08:10:09 --> Helper loaded: common_helper
DEBUG - 2017-01-11 08:10:09 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 08:10:09 --> Helper loaded: common_helper
DEBUG - 2017-01-11 08:10:09 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 08:10:09 --> Helper loaded: form_helper
DEBUG - 2017-01-11 08:10:09 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 08:10:09 --> Helper loaded: security_helper
DEBUG - 2017-01-11 08:10:09 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 08:10:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 08:10:09 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 08:10:09 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 08:10:09 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 08:10:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 08:10:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 08:10:10 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 08:10:10 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 08:10:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 08:10:10 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 08:10:10 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 08:10:10 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 08:10:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 08:10:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 08:10:10 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 08:10:10 --> Database Driver Class Initialized
DEBUG - 2017-01-11 08:10:10 --> Session Class Initialized
DEBUG - 2017-01-11 08:10:10 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 08:10:10 --> Helper loaded: string_helper
DEBUG - 2017-01-11 08:10:10 --> Session routines successfully run
DEBUG - 2017-01-11 08:10:10 --> Native_session Class Initialized
DEBUG - 2017-01-11 08:10:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 08:10:10 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:10:10 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:10:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 08:10:10 --> Controller Class Initialized
DEBUG - 2017-01-11 08:10:10 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 08:10:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 08:10:10 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 08:10:10 --> Carabiner: library configured.
DEBUG - 2017-01-11 08:10:10 --> Carabiner: library configured.
DEBUG - 2017-01-11 08:10:10 --> User Agent Class Initialized
DEBUG - 2017-01-11 08:10:10 --> Model Class Initialized
DEBUG - 2017-01-11 08:10:10 --> Model Class Initialized
DEBUG - 2017-01-11 08:10:10 --> Model Class Initialized
DEBUG - 2017-01-11 08:10:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2017-01-11 08:10:10 --> Pagination Class Initialized
DEBUG - 2017-01-11 08:10:10 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2017-01-11 08:10:10 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/index.php
DEBUG - 2017-01-11 08:10:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-11 08:10:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-11 08:10:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 08:10:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-11 08:10:10 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2017-01-11 08:10:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 08:10:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-11 08:10:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-11 08:10:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-11 08:10:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 08:10:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-11 08:10:10 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2017-01-11 08:10:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 08:10:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-11 08:10:10 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8118d087c6d6c5bac3947ef2cf7a3513
DEBUG - 2017-01-11 08:10:10 --> Final output sent to browser
DEBUG - 2017-01-11 08:10:10 --> Total execution time: 0.3558
DEBUG - 2017-01-11 08:10:13 --> Config Class Initialized
DEBUG - 2017-01-11 08:10:13 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:10:14 --> Utf8 Class Initialized
DEBUG - 2017-01-11 08:10:14 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 08:10:14 --> URI Class Initialized
DEBUG - 2017-01-11 08:10:14 --> Router Class Initialized
DEBUG - 2017-01-11 08:10:14 --> Output Class Initialized
DEBUG - 2017-01-11 08:10:14 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 08:10:14 --> Security Class Initialized
DEBUG - 2017-01-11 08:10:14 --> Input Class Initialized
DEBUG - 2017-01-11 08:10:14 --> XSS Filtering completed
DEBUG - 2017-01-11 08:10:14 --> XSS Filtering completed
DEBUG - 2017-01-11 08:10:14 --> XSS Filtering completed
DEBUG - 2017-01-11 08:10:14 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 08:10:14 --> Language Class Initialized
DEBUG - 2017-01-11 08:10:14 --> Loader Class Initialized
DEBUG - 2017-01-11 08:10:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 08:10:14 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 08:10:14 --> Helper loaded: url_helper
DEBUG - 2017-01-11 08:10:14 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 08:10:14 --> Helper loaded: file_helper
DEBUG - 2017-01-11 08:10:14 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 08:10:14 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 08:10:14 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 08:10:14 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 08:10:14 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 08:10:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 08:10:14 --> Helper loaded: common_helper
DEBUG - 2017-01-11 08:10:14 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 08:10:14 --> Helper loaded: common_helper
DEBUG - 2017-01-11 08:10:14 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 08:10:14 --> Helper loaded: form_helper
DEBUG - 2017-01-11 08:10:14 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 08:10:14 --> Helper loaded: security_helper
DEBUG - 2017-01-11 08:10:14 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 08:10:14 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 08:10:14 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 08:10:14 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 08:10:14 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 08:10:14 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 08:10:14 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 08:10:14 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 08:10:14 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 08:10:14 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 08:10:14 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 08:10:14 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 08:10:14 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 08:10:14 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 08:10:14 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 08:10:14 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 08:10:14 --> Database Driver Class Initialized
DEBUG - 2017-01-11 08:10:14 --> Session Class Initialized
DEBUG - 2017-01-11 08:10:14 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 08:10:14 --> Helper loaded: string_helper
DEBUG - 2017-01-11 08:10:14 --> Session routines successfully run
DEBUG - 2017-01-11 08:10:14 --> Native_session Class Initialized
DEBUG - 2017-01-11 08:10:14 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 08:10:14 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:10:14 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:10:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 08:10:14 --> Controller Class Initialized
DEBUG - 2017-01-11 08:10:14 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 08:10:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 08:10:14 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 08:10:14 --> Carabiner: library configured.
DEBUG - 2017-01-11 08:10:14 --> Carabiner: library configured.
DEBUG - 2017-01-11 08:10:14 --> User Agent Class Initialized
DEBUG - 2017-01-11 08:10:14 --> Model Class Initialized
DEBUG - 2017-01-11 08:10:14 --> Model Class Initialized
DEBUG - 2017-01-11 08:10:14 --> Model Class Initialized
DEBUG - 2017-01-11 08:10:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2017-01-11 08:10:14 --> Pagination Class Initialized
DEBUG - 2017-01-11 08:10:14 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2017-01-11 08:10:14 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/index.php
DEBUG - 2017-01-11 08:10:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-11 08:10:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-11 08:10:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 08:10:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-11 08:10:14 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2017-01-11 08:10:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 08:10:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-11 08:10:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-11 08:10:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-11 08:10:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 08:10:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-11 08:10:14 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2017-01-11 08:10:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 08:10:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-11 08:10:14 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b786644f21b76d4817636e54616a2716
DEBUG - 2017-01-11 08:10:14 --> Final output sent to browser
DEBUG - 2017-01-11 08:10:14 --> Total execution time: 0.3987
DEBUG - 2017-01-11 08:10:16 --> Config Class Initialized
DEBUG - 2017-01-11 08:10:16 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:10:16 --> Utf8 Class Initialized
DEBUG - 2017-01-11 08:10:16 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 08:10:16 --> URI Class Initialized
DEBUG - 2017-01-11 08:10:16 --> Router Class Initialized
DEBUG - 2017-01-11 08:10:16 --> Output Class Initialized
DEBUG - 2017-01-11 08:10:16 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 08:10:16 --> Security Class Initialized
DEBUG - 2017-01-11 08:10:16 --> Input Class Initialized
DEBUG - 2017-01-11 08:10:16 --> XSS Filtering completed
DEBUG - 2017-01-11 08:10:16 --> XSS Filtering completed
DEBUG - 2017-01-11 08:10:16 --> XSS Filtering completed
DEBUG - 2017-01-11 08:10:16 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 08:10:16 --> Language Class Initialized
DEBUG - 2017-01-11 08:10:16 --> Loader Class Initialized
DEBUG - 2017-01-11 08:10:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 08:10:16 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 08:10:16 --> Helper loaded: url_helper
DEBUG - 2017-01-11 08:10:16 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 08:10:16 --> Helper loaded: file_helper
DEBUG - 2017-01-11 08:10:16 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 08:10:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 08:10:16 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 08:10:16 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 08:10:16 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 08:10:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 08:10:16 --> Helper loaded: common_helper
DEBUG - 2017-01-11 08:10:16 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 08:10:16 --> Helper loaded: common_helper
DEBUG - 2017-01-11 08:10:16 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 08:10:16 --> Helper loaded: form_helper
DEBUG - 2017-01-11 08:10:16 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 08:10:17 --> Helper loaded: security_helper
DEBUG - 2017-01-11 08:10:17 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 08:10:17 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 08:10:17 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 08:10:17 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 08:10:17 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 08:10:17 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 08:10:17 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 08:10:17 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 08:10:17 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 08:10:17 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 08:10:17 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 08:10:17 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 08:10:17 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 08:10:17 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 08:10:17 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 08:10:17 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 08:10:17 --> Database Driver Class Initialized
DEBUG - 2017-01-11 08:10:17 --> Session Class Initialized
DEBUG - 2017-01-11 08:10:17 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 08:10:17 --> Helper loaded: string_helper
DEBUG - 2017-01-11 08:10:17 --> Session routines successfully run
DEBUG - 2017-01-11 08:10:17 --> Native_session Class Initialized
DEBUG - 2017-01-11 08:10:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 08:10:17 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:10:17 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:10:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 08:10:17 --> Controller Class Initialized
DEBUG - 2017-01-11 08:10:17 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 08:10:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 08:10:17 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 08:10:17 --> Carabiner: library configured.
DEBUG - 2017-01-11 08:10:17 --> Carabiner: library configured.
DEBUG - 2017-01-11 08:10:17 --> User Agent Class Initialized
DEBUG - 2017-01-11 08:10:17 --> Model Class Initialized
DEBUG - 2017-01-11 08:10:17 --> Model Class Initialized
DEBUG - 2017-01-11 08:10:17 --> Model Class Initialized
DEBUG - 2017-01-11 08:10:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2017-01-11 08:10:17 --> Pagination Class Initialized
DEBUG - 2017-01-11 08:10:17 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2017-01-11 08:10:17 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/index.php
DEBUG - 2017-01-11 08:10:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-11 08:10:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-11 08:10:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 08:10:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-11 08:10:17 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2017-01-11 08:10:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 08:10:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-11 08:10:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-11 08:10:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-11 08:10:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 08:10:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-11 08:10:17 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2017-01-11 08:10:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 08:10:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-11 08:10:17 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b786644f21b76d4817636e54616a2716
DEBUG - 2017-01-11 08:10:17 --> Final output sent to browser
DEBUG - 2017-01-11 08:10:17 --> Total execution time: 0.3951
DEBUG - 2017-01-11 08:10:29 --> Config Class Initialized
DEBUG - 2017-01-11 08:10:29 --> Hooks Class Initialized
DEBUG - 2017-01-11 08:10:29 --> Utf8 Class Initialized
DEBUG - 2017-01-11 08:10:29 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 08:10:29 --> URI Class Initialized
DEBUG - 2017-01-11 08:10:29 --> Router Class Initialized
DEBUG - 2017-01-11 08:10:29 --> Output Class Initialized
DEBUG - 2017-01-11 08:10:29 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 08:10:29 --> Security Class Initialized
DEBUG - 2017-01-11 08:10:29 --> Input Class Initialized
DEBUG - 2017-01-11 08:10:29 --> XSS Filtering completed
DEBUG - 2017-01-11 08:10:29 --> XSS Filtering completed
DEBUG - 2017-01-11 08:10:29 --> XSS Filtering completed
DEBUG - 2017-01-11 08:10:29 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 08:10:29 --> Language Class Initialized
DEBUG - 2017-01-11 08:10:29 --> Loader Class Initialized
DEBUG - 2017-01-11 08:10:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 08:10:29 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 08:10:29 --> Helper loaded: url_helper
DEBUG - 2017-01-11 08:10:29 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 08:10:29 --> Helper loaded: file_helper
DEBUG - 2017-01-11 08:10:29 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 08:10:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 08:10:29 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 08:10:29 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 08:10:29 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 08:10:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 08:10:29 --> Helper loaded: common_helper
DEBUG - 2017-01-11 08:10:29 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 08:10:29 --> Helper loaded: common_helper
DEBUG - 2017-01-11 08:10:29 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 08:10:29 --> Helper loaded: form_helper
DEBUG - 2017-01-11 08:10:29 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 08:10:29 --> Helper loaded: security_helper
DEBUG - 2017-01-11 08:10:29 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 08:10:29 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 08:10:29 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 08:10:29 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 08:10:29 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 08:10:29 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 08:10:29 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 08:10:29 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 08:10:29 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 08:10:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 08:10:29 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 08:10:29 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 08:10:29 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 08:10:29 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 08:10:29 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 08:10:29 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 08:10:29 --> Database Driver Class Initialized
DEBUG - 2017-01-11 08:10:29 --> Session Class Initialized
DEBUG - 2017-01-11 08:10:29 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 08:10:29 --> Helper loaded: string_helper
DEBUG - 2017-01-11 08:10:29 --> Session routines successfully run
DEBUG - 2017-01-11 08:10:29 --> Native_session Class Initialized
DEBUG - 2017-01-11 08:10:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 08:10:29 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:10:29 --> Form Validation Class Initialized
DEBUG - 2017-01-11 08:10:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 08:10:29 --> Controller Class Initialized
DEBUG - 2017-01-11 08:10:29 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 08:10:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 08:10:29 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 08:10:29 --> Carabiner: library configured.
DEBUG - 2017-01-11 08:10:29 --> Carabiner: library configured.
DEBUG - 2017-01-11 08:10:29 --> User Agent Class Initialized
DEBUG - 2017-01-11 08:10:29 --> Model Class Initialized
DEBUG - 2017-01-11 08:10:29 --> Model Class Initialized
DEBUG - 2017-01-11 08:10:29 --> Model Class Initialized
DEBUG - 2017-01-11 08:10:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2017-01-11 08:10:29 --> Pagination Class Initialized
DEBUG - 2017-01-11 08:10:29 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2017-01-11 08:10:29 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/index.php
DEBUG - 2017-01-11 08:10:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-11 08:10:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-11 08:10:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 08:10:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-11 08:10:30 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2017-01-11 08:10:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 08:10:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-11 08:10:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-11 08:10:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-11 08:10:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 08:10:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-11 08:10:30 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2017-01-11 08:10:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 08:10:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-11 08:10:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b786644f21b76d4817636e54616a2716
DEBUG - 2017-01-11 08:10:30 --> Final output sent to browser
DEBUG - 2017-01-11 08:10:30 --> Total execution time: 0.4247
DEBUG - 2017-01-11 22:21:40 --> Config Class Initialized
DEBUG - 2017-01-11 22:21:41 --> Hooks Class Initialized
DEBUG - 2017-01-11 22:21:41 --> Utf8 Class Initialized
DEBUG - 2017-01-11 22:21:41 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 22:21:41 --> URI Class Initialized
DEBUG - 2017-01-11 22:21:41 --> Router Class Initialized
DEBUG - 2017-01-11 22:21:41 --> No URI present. Default controller set.
DEBUG - 2017-01-11 22:21:41 --> Output Class Initialized
DEBUG - 2017-01-11 22:21:41 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 22:21:41 --> Security Class Initialized
DEBUG - 2017-01-11 22:21:41 --> Input Class Initialized
DEBUG - 2017-01-11 22:21:41 --> XSS Filtering completed
DEBUG - 2017-01-11 22:21:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 22:21:41 --> Language Class Initialized
DEBUG - 2017-01-11 22:21:41 --> Loader Class Initialized
DEBUG - 2017-01-11 22:21:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 22:21:41 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 22:21:41 --> Helper loaded: url_helper
DEBUG - 2017-01-11 22:21:41 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 22:21:41 --> Helper loaded: file_helper
DEBUG - 2017-01-11 22:21:41 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:21:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 22:21:41 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 22:21:41 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:21:41 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 22:21:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 22:21:41 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:21:41 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 22:21:41 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:21:41 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 22:21:41 --> Helper loaded: form_helper
DEBUG - 2017-01-11 22:21:41 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 22:21:41 --> Helper loaded: security_helper
DEBUG - 2017-01-11 22:21:41 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:21:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 22:21:41 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 22:21:41 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:21:41 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 22:21:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 22:21:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 22:21:41 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 22:21:41 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:21:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 22:21:41 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 22:21:41 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:21:41 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 22:21:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 22:21:41 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 22:21:41 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 22:21:41 --> Database Driver Class Initialized
DEBUG - 2017-01-11 22:21:41 --> Session Class Initialized
DEBUG - 2017-01-11 22:21:41 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 22:21:41 --> Helper loaded: string_helper
DEBUG - 2017-01-11 22:21:41 --> Session routines successfully run
DEBUG - 2017-01-11 22:21:41 --> Native_session Class Initialized
DEBUG - 2017-01-11 22:21:41 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 22:21:41 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:21:41 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:21:41 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 22:21:41 --> Controller Class Initialized
DEBUG - 2017-01-11 22:21:41 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 22:21:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 22:21:41 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 22:21:41 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:21:41 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:21:41 --> User Agent Class Initialized
DEBUG - 2017-01-11 22:21:41 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:41 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:41 --> Model Class Initialized
ERROR - 2017-01-11 22:21:42 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2017-01-11 22:21:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2017-01-11 22:21:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2017-01-11 22:21:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-11 22:21:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 22:21:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-11 22:21:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-11 22:21:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-11 22:21:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-11 22:21:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-11 22:21:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 22:21:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-11 22:21:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-11 22:21:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 22:21:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-11 22:21:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-11 22:21:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-11 22:21:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-11 22:21:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-11 22:21:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 22:21:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-11 22:21:43 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2017-01-11 22:21:43 --> Final output sent to browser
DEBUG - 2017-01-11 22:21:43 --> Total execution time: 2.4652
DEBUG - 2017-01-11 22:21:44 --> Config Class Initialized
DEBUG - 2017-01-11 22:21:44 --> Hooks Class Initialized
DEBUG - 2017-01-11 22:21:44 --> Utf8 Class Initialized
DEBUG - 2017-01-11 22:21:44 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 22:21:44 --> URI Class Initialized
DEBUG - 2017-01-11 22:21:44 --> Router Class Initialized
DEBUG - 2017-01-11 22:21:44 --> Output Class Initialized
DEBUG - 2017-01-11 22:21:44 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 22:21:44 --> Security Class Initialized
DEBUG - 2017-01-11 22:21:44 --> Input Class Initialized
DEBUG - 2017-01-11 22:21:44 --> XSS Filtering completed
DEBUG - 2017-01-11 22:21:44 --> XSS Filtering completed
DEBUG - 2017-01-11 22:21:44 --> XSS Filtering completed
DEBUG - 2017-01-11 22:21:44 --> XSS Filtering completed
DEBUG - 2017-01-11 22:21:44 --> XSS Filtering completed
DEBUG - 2017-01-11 22:21:44 --> XSS Filtering completed
DEBUG - 2017-01-11 22:21:44 --> XSS Filtering completed
DEBUG - 2017-01-11 22:21:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 22:21:44 --> Language Class Initialized
DEBUG - 2017-01-11 22:21:44 --> Loader Class Initialized
DEBUG - 2017-01-11 22:21:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 22:21:44 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 22:21:44 --> Helper loaded: url_helper
DEBUG - 2017-01-11 22:21:44 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 22:21:44 --> Helper loaded: file_helper
DEBUG - 2017-01-11 22:21:44 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:21:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 22:21:44 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 22:21:44 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:21:44 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 22:21:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 22:21:44 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:21:44 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 22:21:44 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:21:44 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 22:21:44 --> Helper loaded: form_helper
DEBUG - 2017-01-11 22:21:44 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 22:21:44 --> Helper loaded: security_helper
DEBUG - 2017-01-11 22:21:44 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:21:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 22:21:44 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 22:21:44 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:21:44 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 22:21:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 22:21:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 22:21:44 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 22:21:44 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:21:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 22:21:44 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 22:21:44 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:21:44 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 22:21:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 22:21:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 22:21:44 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 22:21:44 --> Database Driver Class Initialized
DEBUG - 2017-01-11 22:21:44 --> Session Class Initialized
DEBUG - 2017-01-11 22:21:44 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 22:21:44 --> Helper loaded: string_helper
DEBUG - 2017-01-11 22:21:44 --> Session routines successfully run
DEBUG - 2017-01-11 22:21:44 --> Native_session Class Initialized
DEBUG - 2017-01-11 22:21:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 22:21:44 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:21:44 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:21:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 22:21:44 --> Controller Class Initialized
DEBUG - 2017-01-11 22:21:44 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 22:21:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 22:21:44 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 22:21:44 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:21:44 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:21:44 --> User Agent Class Initialized
DEBUG - 2017-01-11 22:21:44 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:44 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:44 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:44 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:44 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:44 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:44 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:45 --> Config Class Initialized
DEBUG - 2017-01-11 22:21:45 --> Hooks Class Initialized
DEBUG - 2017-01-11 22:21:45 --> Utf8 Class Initialized
DEBUG - 2017-01-11 22:21:45 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 22:21:45 --> URI Class Initialized
DEBUG - 2017-01-11 22:21:45 --> Router Class Initialized
DEBUG - 2017-01-11 22:21:45 --> No URI present. Default controller set.
DEBUG - 2017-01-11 22:21:45 --> Output Class Initialized
DEBUG - 2017-01-11 22:21:45 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 22:21:45 --> Security Class Initialized
DEBUG - 2017-01-11 22:21:45 --> Input Class Initialized
DEBUG - 2017-01-11 22:21:45 --> XSS Filtering completed
DEBUG - 2017-01-11 22:21:45 --> XSS Filtering completed
DEBUG - 2017-01-11 22:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 22:21:45 --> Language Class Initialized
DEBUG - 2017-01-11 22:21:45 --> Loader Class Initialized
DEBUG - 2017-01-11 22:21:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 22:21:45 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 22:21:45 --> Helper loaded: url_helper
DEBUG - 2017-01-11 22:21:45 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 22:21:45 --> Helper loaded: file_helper
DEBUG - 2017-01-11 22:21:45 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:21:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 22:21:45 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 22:21:45 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:21:45 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 22:21:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 22:21:45 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:21:45 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 22:21:45 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:21:45 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 22:21:45 --> Helper loaded: form_helper
DEBUG - 2017-01-11 22:21:45 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 22:21:45 --> Helper loaded: security_helper
DEBUG - 2017-01-11 22:21:45 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:21:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 22:21:45 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 22:21:45 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:21:45 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 22:21:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 22:21:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 22:21:45 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 22:21:45 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:21:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 22:21:45 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 22:21:45 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:21:45 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 22:21:45 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 22:21:45 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 22:21:45 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 22:21:45 --> Database Driver Class Initialized
DEBUG - 2017-01-11 22:21:45 --> Session Class Initialized
DEBUG - 2017-01-11 22:21:45 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 22:21:45 --> Helper loaded: string_helper
DEBUG - 2017-01-11 22:21:45 --> Session routines successfully run
DEBUG - 2017-01-11 22:21:45 --> Native_session Class Initialized
DEBUG - 2017-01-11 22:21:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2017-01-11 22:21:46 --> Final output sent to browser
DEBUG - 2017-01-11 22:21:46 --> Total execution time: 1.6965
DEBUG - 2017-01-11 22:21:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 22:21:46 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:21:46 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:21:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 22:21:46 --> Controller Class Initialized
DEBUG - 2017-01-11 22:21:46 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 22:21:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 22:21:46 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 22:21:46 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:21:46 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:21:46 --> User Agent Class Initialized
DEBUG - 2017-01-11 22:21:46 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:46 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:46 --> Model Class Initialized
ERROR - 2017-01-11 22:21:46 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2017-01-11 22:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2017-01-11 22:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2017-01-11 22:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-11 22:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 22:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-11 22:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-11 22:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-11 22:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-11 22:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-11 22:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 22:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-11 22:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-11 22:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 22:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-11 22:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-11 22:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-11 22:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-11 22:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-11 22:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 22:21:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-11 22:21:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2017-01-11 22:21:46 --> Final output sent to browser
DEBUG - 2017-01-11 22:21:46 --> Total execution time: 0.7209
DEBUG - 2017-01-11 22:21:46 --> Config Class Initialized
DEBUG - 2017-01-11 22:21:46 --> Hooks Class Initialized
DEBUG - 2017-01-11 22:21:46 --> Utf8 Class Initialized
DEBUG - 2017-01-11 22:21:46 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 22:21:46 --> URI Class Initialized
DEBUG - 2017-01-11 22:21:46 --> Router Class Initialized
DEBUG - 2017-01-11 22:21:46 --> Output Class Initialized
DEBUG - 2017-01-11 22:21:46 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 22:21:46 --> Security Class Initialized
DEBUG - 2017-01-11 22:21:46 --> Input Class Initialized
DEBUG - 2017-01-11 22:21:46 --> XSS Filtering completed
DEBUG - 2017-01-11 22:21:46 --> XSS Filtering completed
DEBUG - 2017-01-11 22:21:46 --> XSS Filtering completed
DEBUG - 2017-01-11 22:21:46 --> XSS Filtering completed
DEBUG - 2017-01-11 22:21:46 --> XSS Filtering completed
DEBUG - 2017-01-11 22:21:46 --> XSS Filtering completed
DEBUG - 2017-01-11 22:21:46 --> XSS Filtering completed
DEBUG - 2017-01-11 22:21:46 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 22:21:46 --> Language Class Initialized
DEBUG - 2017-01-11 22:21:46 --> Loader Class Initialized
DEBUG - 2017-01-11 22:21:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 22:21:46 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 22:21:46 --> Helper loaded: url_helper
DEBUG - 2017-01-11 22:21:46 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 22:21:46 --> Helper loaded: file_helper
DEBUG - 2017-01-11 22:21:46 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:21:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 22:21:46 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 22:21:46 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:21:46 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 22:21:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 22:21:46 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:21:46 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 22:21:46 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:21:46 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 22:21:46 --> Helper loaded: form_helper
DEBUG - 2017-01-11 22:21:46 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 22:21:46 --> Helper loaded: security_helper
DEBUG - 2017-01-11 22:21:46 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:21:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 22:21:46 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 22:21:46 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:21:46 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 22:21:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 22:21:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 22:21:46 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 22:21:46 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:21:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 22:21:46 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 22:21:46 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:21:46 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 22:21:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 22:21:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 22:21:46 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 22:21:46 --> Database Driver Class Initialized
DEBUG - 2017-01-11 22:21:46 --> Session Class Initialized
DEBUG - 2017-01-11 22:21:46 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 22:21:46 --> Helper loaded: string_helper
DEBUG - 2017-01-11 22:21:46 --> Session routines successfully run
DEBUG - 2017-01-11 22:21:46 --> Native_session Class Initialized
DEBUG - 2017-01-11 22:21:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 22:21:46 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:21:46 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:21:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 22:21:46 --> Controller Class Initialized
DEBUG - 2017-01-11 22:21:46 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 22:21:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 22:21:46 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 22:21:46 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:21:46 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:21:46 --> User Agent Class Initialized
DEBUG - 2017-01-11 22:21:46 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:46 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:46 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:46 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:47 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:47 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:47 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2017-01-11 22:21:47 --> Final output sent to browser
DEBUG - 2017-01-11 22:21:47 --> Total execution time: 0.5868
DEBUG - 2017-01-11 22:21:47 --> Config Class Initialized
DEBUG - 2017-01-11 22:21:47 --> Hooks Class Initialized
DEBUG - 2017-01-11 22:21:47 --> Utf8 Class Initialized
DEBUG - 2017-01-11 22:21:47 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 22:21:47 --> URI Class Initialized
DEBUG - 2017-01-11 22:21:47 --> Router Class Initialized
DEBUG - 2017-01-11 22:21:47 --> Output Class Initialized
DEBUG - 2017-01-11 22:21:47 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 22:21:47 --> Security Class Initialized
DEBUG - 2017-01-11 22:21:47 --> Input Class Initialized
DEBUG - 2017-01-11 22:21:47 --> XSS Filtering completed
DEBUG - 2017-01-11 22:21:47 --> XSS Filtering completed
DEBUG - 2017-01-11 22:21:47 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 22:21:47 --> Language Class Initialized
DEBUG - 2017-01-11 22:21:47 --> Loader Class Initialized
DEBUG - 2017-01-11 22:21:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 22:21:47 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 22:21:47 --> Helper loaded: url_helper
DEBUG - 2017-01-11 22:21:47 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 22:21:47 --> Helper loaded: file_helper
DEBUG - 2017-01-11 22:21:47 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:21:47 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 22:21:47 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 22:21:48 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:21:48 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 22:21:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 22:21:48 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:21:48 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 22:21:48 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:21:48 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 22:21:48 --> Helper loaded: form_helper
DEBUG - 2017-01-11 22:21:48 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 22:21:48 --> Helper loaded: security_helper
DEBUG - 2017-01-11 22:21:48 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:21:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 22:21:48 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 22:21:48 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:21:48 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 22:21:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 22:21:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 22:21:48 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 22:21:48 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:21:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 22:21:48 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 22:21:48 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:21:48 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 22:21:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 22:21:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 22:21:48 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 22:21:48 --> Database Driver Class Initialized
DEBUG - 2017-01-11 22:21:48 --> Session Class Initialized
DEBUG - 2017-01-11 22:21:48 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 22:21:48 --> Helper loaded: string_helper
DEBUG - 2017-01-11 22:21:48 --> Session routines successfully run
DEBUG - 2017-01-11 22:21:48 --> Native_session Class Initialized
DEBUG - 2017-01-11 22:21:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 22:21:48 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:21:48 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:21:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 22:21:48 --> Controller Class Initialized
DEBUG - 2017-01-11 22:21:48 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 22:21:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 22:21:48 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 22:21:48 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:21:48 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:21:48 --> User Agent Class Initialized
DEBUG - 2017-01-11 22:21:48 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:48 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:48 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2017-01-11 22:21:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-11 22:21:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-11 22:21:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 22:21:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-11 22:21:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 22:21:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-11 22:21:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-11 22:21:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-11 22:21:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 22:21:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-11 22:21:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 22:21:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-11 22:21:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2017-01-11 22:21:48 --> Final output sent to browser
DEBUG - 2017-01-11 22:21:48 --> Total execution time: 0.6198
DEBUG - 2017-01-11 22:21:52 --> Config Class Initialized
DEBUG - 2017-01-11 22:21:52 --> Hooks Class Initialized
DEBUG - 2017-01-11 22:21:52 --> Utf8 Class Initialized
DEBUG - 2017-01-11 22:21:52 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 22:21:52 --> URI Class Initialized
DEBUG - 2017-01-11 22:21:52 --> Router Class Initialized
DEBUG - 2017-01-11 22:21:52 --> Output Class Initialized
DEBUG - 2017-01-11 22:21:52 --> Security Class Initialized
DEBUG - 2017-01-11 22:21:52 --> Input Class Initialized
DEBUG - 2017-01-11 22:21:52 --> XSS Filtering completed
DEBUG - 2017-01-11 22:21:52 --> XSS Filtering completed
DEBUG - 2017-01-11 22:21:52 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 22:21:52 --> Language Class Initialized
DEBUG - 2017-01-11 22:21:52 --> Loader Class Initialized
DEBUG - 2017-01-11 22:21:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 22:21:52 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 22:21:52 --> Helper loaded: url_helper
DEBUG - 2017-01-11 22:21:52 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 22:21:52 --> Helper loaded: file_helper
DEBUG - 2017-01-11 22:21:52 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:21:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 22:21:52 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 22:21:52 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:21:52 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 22:21:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 22:21:52 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:21:52 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 22:21:52 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:21:52 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 22:21:52 --> Helper loaded: form_helper
DEBUG - 2017-01-11 22:21:52 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 22:21:52 --> Helper loaded: security_helper
DEBUG - 2017-01-11 22:21:52 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:21:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 22:21:52 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 22:21:52 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:21:52 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 22:21:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 22:21:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 22:21:52 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 22:21:52 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:21:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 22:21:52 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 22:21:52 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:21:52 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 22:21:52 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 22:21:52 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 22:21:52 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 22:21:52 --> Database Driver Class Initialized
DEBUG - 2017-01-11 22:21:52 --> Session Class Initialized
DEBUG - 2017-01-11 22:21:52 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 22:21:52 --> Helper loaded: string_helper
DEBUG - 2017-01-11 22:21:52 --> Session routines successfully run
DEBUG - 2017-01-11 22:21:52 --> Native_session Class Initialized
DEBUG - 2017-01-11 22:21:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 22:21:52 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:21:52 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:21:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 22:21:52 --> Controller Class Initialized
DEBUG - 2017-01-11 22:21:52 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 22:21:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 22:21:52 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 22:21:52 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:21:52 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:21:52 --> User Agent Class Initialized
DEBUG - 2017-01-11 22:21:52 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:52 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:52 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:52 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:53 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:53 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:53 --> Model Class Initialized
DEBUG - 2017-01-11 22:21:53 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2017-01-11 22:21:53 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2017-01-11 22:21:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2017-01-11 22:21:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2017-01-11 22:21:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2017-01-11 22:21:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2017-01-11 22:21:53 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2017-01-11 22:21:53 --> Final output sent to browser
DEBUG - 2017-01-11 22:21:53 --> Total execution time: 0.5816
DEBUG - 2017-01-11 22:21:53 --> Config Class Initialized
DEBUG - 2017-01-11 22:21:53 --> Hooks Class Initialized
DEBUG - 2017-01-11 22:21:53 --> Utf8 Class Initialized
DEBUG - 2017-01-11 22:21:53 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 22:21:53 --> URI Class Initialized
DEBUG - 2017-01-11 22:21:53 --> Router Class Initialized
ERROR - 2017-01-11 22:21:53 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2017-01-11 22:22:41 --> Config Class Initialized
DEBUG - 2017-01-11 22:22:41 --> Hooks Class Initialized
DEBUG - 2017-01-11 22:22:41 --> Utf8 Class Initialized
DEBUG - 2017-01-11 22:22:41 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 22:22:41 --> URI Class Initialized
DEBUG - 2017-01-11 22:22:41 --> Router Class Initialized
DEBUG - 2017-01-11 22:22:41 --> Output Class Initialized
DEBUG - 2017-01-11 22:22:41 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 22:22:41 --> Security Class Initialized
DEBUG - 2017-01-11 22:22:41 --> Input Class Initialized
DEBUG - 2017-01-11 22:22:41 --> XSS Filtering completed
DEBUG - 2017-01-11 22:22:41 --> XSS Filtering completed
DEBUG - 2017-01-11 22:22:41 --> XSS Filtering completed
DEBUG - 2017-01-11 22:22:41 --> XSS Filtering completed
DEBUG - 2017-01-11 22:22:41 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 22:22:41 --> Language Class Initialized
DEBUG - 2017-01-11 22:22:41 --> Loader Class Initialized
DEBUG - 2017-01-11 22:22:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 22:22:41 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 22:22:41 --> Helper loaded: url_helper
DEBUG - 2017-01-11 22:22:41 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 22:22:41 --> Helper loaded: file_helper
DEBUG - 2017-01-11 22:22:41 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:22:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 22:22:41 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 22:22:41 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:22:41 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 22:22:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 22:22:41 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:22:41 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 22:22:41 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:22:41 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 22:22:41 --> Helper loaded: form_helper
DEBUG - 2017-01-11 22:22:41 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 22:22:41 --> Helper loaded: security_helper
DEBUG - 2017-01-11 22:22:41 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:22:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 22:22:41 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 22:22:41 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:22:41 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 22:22:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 22:22:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 22:22:41 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 22:22:41 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:22:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 22:22:41 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 22:22:41 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:22:41 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 22:22:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 22:22:42 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 22:22:42 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 22:22:42 --> Database Driver Class Initialized
DEBUG - 2017-01-11 22:22:42 --> Session Class Initialized
DEBUG - 2017-01-11 22:22:42 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 22:22:42 --> Helper loaded: string_helper
DEBUG - 2017-01-11 22:22:42 --> Session routines successfully run
DEBUG - 2017-01-11 22:22:42 --> Native_session Class Initialized
DEBUG - 2017-01-11 22:22:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 22:22:42 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:22:42 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:22:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 22:22:42 --> Controller Class Initialized
DEBUG - 2017-01-11 22:22:42 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 22:22:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 22:22:42 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 22:22:42 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:22:42 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:22:42 --> User Agent Class Initialized
DEBUG - 2017-01-11 22:22:42 --> Model Class Initialized
DEBUG - 2017-01-11 22:22:42 --> Model Class Initialized
DEBUG - 2017-01-11 22:22:42 --> Model Class Initialized
DEBUG - 2017-01-11 22:22:42 --> Model Class Initialized
DEBUG - 2017-01-11 22:22:42 --> Model Class Initialized
DEBUG - 2017-01-11 22:22:42 --> Model Class Initialized
DEBUG - 2017-01-11 22:22:42 --> Model Class Initialized
DEBUG - 2017-01-11 22:22:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2017-01-11 22:22:42 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:22:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 22:22:42 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2017-01-11 22:22:43 --> Config Class Initialized
DEBUG - 2017-01-11 22:22:43 --> Hooks Class Initialized
DEBUG - 2017-01-11 22:22:43 --> Utf8 Class Initialized
DEBUG - 2017-01-11 22:22:43 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 22:22:43 --> URI Class Initialized
DEBUG - 2017-01-11 22:22:43 --> Router Class Initialized
DEBUG - 2017-01-11 22:22:43 --> No URI present. Default controller set.
DEBUG - 2017-01-11 22:22:43 --> Output Class Initialized
DEBUG - 2017-01-11 22:22:43 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 22:22:43 --> Security Class Initialized
DEBUG - 2017-01-11 22:22:43 --> Input Class Initialized
DEBUG - 2017-01-11 22:22:43 --> XSS Filtering completed
DEBUG - 2017-01-11 22:22:43 --> XSS Filtering completed
DEBUG - 2017-01-11 22:22:43 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 22:22:43 --> Language Class Initialized
DEBUG - 2017-01-11 22:22:43 --> Loader Class Initialized
DEBUG - 2017-01-11 22:22:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 22:22:43 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 22:22:43 --> Helper loaded: url_helper
DEBUG - 2017-01-11 22:22:43 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 22:22:43 --> Helper loaded: file_helper
DEBUG - 2017-01-11 22:22:43 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:22:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 22:22:43 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 22:22:43 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:22:43 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 22:22:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 22:22:43 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:22:43 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 22:22:43 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:22:43 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 22:22:43 --> Helper loaded: form_helper
DEBUG - 2017-01-11 22:22:43 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 22:22:43 --> Helper loaded: security_helper
DEBUG - 2017-01-11 22:22:43 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:22:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 22:22:43 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 22:22:43 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:22:43 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 22:22:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 22:22:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 22:22:43 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 22:22:43 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:22:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 22:22:43 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 22:22:43 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:22:43 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 22:22:43 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 22:22:43 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 22:22:43 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 22:22:43 --> Database Driver Class Initialized
DEBUG - 2017-01-11 22:22:43 --> Session Class Initialized
DEBUG - 2017-01-11 22:22:43 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 22:22:43 --> Helper loaded: string_helper
DEBUG - 2017-01-11 22:22:43 --> Session routines successfully run
DEBUG - 2017-01-11 22:22:43 --> Native_session Class Initialized
DEBUG - 2017-01-11 22:22:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 22:22:43 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:22:43 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:22:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 22:22:43 --> Controller Class Initialized
DEBUG - 2017-01-11 22:22:43 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 22:22:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 22:22:43 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 22:22:43 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:22:43 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:22:43 --> User Agent Class Initialized
DEBUG - 2017-01-11 22:22:43 --> Model Class Initialized
DEBUG - 2017-01-11 22:22:43 --> Model Class Initialized
DEBUG - 2017-01-11 22:22:43 --> Model Class Initialized
ERROR - 2017-01-11 22:22:43 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2017-01-11 22:22:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2017-01-11 22:22:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2017-01-11 22:22:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-11 22:22:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 22:22:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-11 22:22:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-11 22:22:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-11 22:22:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-11 22:22:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-11 22:22:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 22:22:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-11 22:22:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-11 22:22:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 22:22:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-11 22:22:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-11 22:22:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-11 22:22:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-11 22:22:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-11 22:22:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 22:22:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-11 22:22:43 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2017-01-11 22:22:43 --> Final output sent to browser
DEBUG - 2017-01-11 22:22:43 --> Total execution time: 0.5828
DEBUG - 2017-01-11 22:22:44 --> Config Class Initialized
DEBUG - 2017-01-11 22:22:44 --> Hooks Class Initialized
DEBUG - 2017-01-11 22:22:44 --> Utf8 Class Initialized
DEBUG - 2017-01-11 22:22:44 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 22:22:44 --> URI Class Initialized
DEBUG - 2017-01-11 22:22:44 --> Router Class Initialized
DEBUG - 2017-01-11 22:22:44 --> Output Class Initialized
DEBUG - 2017-01-11 22:22:44 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 22:22:44 --> Security Class Initialized
DEBUG - 2017-01-11 22:22:44 --> Input Class Initialized
DEBUG - 2017-01-11 22:22:44 --> XSS Filtering completed
DEBUG - 2017-01-11 22:22:44 --> XSS Filtering completed
DEBUG - 2017-01-11 22:22:44 --> XSS Filtering completed
DEBUG - 2017-01-11 22:22:44 --> XSS Filtering completed
DEBUG - 2017-01-11 22:22:44 --> XSS Filtering completed
DEBUG - 2017-01-11 22:22:44 --> XSS Filtering completed
DEBUG - 2017-01-11 22:22:44 --> XSS Filtering completed
DEBUG - 2017-01-11 22:22:44 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 22:22:44 --> Language Class Initialized
DEBUG - 2017-01-11 22:22:44 --> Loader Class Initialized
DEBUG - 2017-01-11 22:22:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 22:22:44 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 22:22:44 --> Helper loaded: url_helper
DEBUG - 2017-01-11 22:22:44 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 22:22:44 --> Helper loaded: file_helper
DEBUG - 2017-01-11 22:22:44 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:22:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 22:22:44 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 22:22:44 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:22:44 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 22:22:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 22:22:44 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:22:44 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 22:22:44 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:22:44 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 22:22:44 --> Helper loaded: form_helper
DEBUG - 2017-01-11 22:22:44 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 22:22:44 --> Helper loaded: security_helper
DEBUG - 2017-01-11 22:22:44 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:22:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 22:22:44 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 22:22:44 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:22:44 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 22:22:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 22:22:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 22:22:44 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 22:22:44 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:22:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 22:22:44 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 22:22:44 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:22:44 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 22:22:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 22:22:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 22:22:44 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 22:22:44 --> Database Driver Class Initialized
DEBUG - 2017-01-11 22:22:44 --> Session Class Initialized
DEBUG - 2017-01-11 22:22:44 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 22:22:44 --> Helper loaded: string_helper
DEBUG - 2017-01-11 22:22:44 --> Session routines successfully run
DEBUG - 2017-01-11 22:22:44 --> Native_session Class Initialized
DEBUG - 2017-01-11 22:22:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 22:22:44 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:22:44 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:22:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 22:22:44 --> Controller Class Initialized
DEBUG - 2017-01-11 22:22:44 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 22:22:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 22:22:44 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 22:22:44 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:22:44 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:22:44 --> User Agent Class Initialized
DEBUG - 2017-01-11 22:22:44 --> Model Class Initialized
DEBUG - 2017-01-11 22:22:44 --> Model Class Initialized
DEBUG - 2017-01-11 22:22:44 --> Model Class Initialized
DEBUG - 2017-01-11 22:22:44 --> Model Class Initialized
DEBUG - 2017-01-11 22:22:44 --> Model Class Initialized
DEBUG - 2017-01-11 22:22:44 --> Model Class Initialized
DEBUG - 2017-01-11 22:22:44 --> Model Class Initialized
DEBUG - 2017-01-11 22:22:44 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2017-01-11 22:22:44 --> Final output sent to browser
DEBUG - 2017-01-11 22:22:44 --> Total execution time: 0.7264
DEBUG - 2017-01-11 22:22:46 --> Config Class Initialized
DEBUG - 2017-01-11 22:22:46 --> Hooks Class Initialized
DEBUG - 2017-01-11 22:22:46 --> Utf8 Class Initialized
DEBUG - 2017-01-11 22:22:46 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 22:22:46 --> URI Class Initialized
DEBUG - 2017-01-11 22:22:46 --> Router Class Initialized
DEBUG - 2017-01-11 22:22:46 --> Output Class Initialized
DEBUG - 2017-01-11 22:22:46 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 22:22:46 --> Security Class Initialized
DEBUG - 2017-01-11 22:22:46 --> Input Class Initialized
DEBUG - 2017-01-11 22:22:46 --> XSS Filtering completed
DEBUG - 2017-01-11 22:22:46 --> XSS Filtering completed
DEBUG - 2017-01-11 22:22:46 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 22:22:46 --> Language Class Initialized
DEBUG - 2017-01-11 22:22:46 --> Loader Class Initialized
DEBUG - 2017-01-11 22:22:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 22:22:46 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 22:22:46 --> Helper loaded: url_helper
DEBUG - 2017-01-11 22:22:46 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 22:22:46 --> Helper loaded: file_helper
DEBUG - 2017-01-11 22:22:46 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:22:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 22:22:46 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 22:22:46 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:22:46 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 22:22:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 22:22:46 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:22:46 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 22:22:46 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:22:46 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 22:22:46 --> Helper loaded: form_helper
DEBUG - 2017-01-11 22:22:46 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 22:22:46 --> Helper loaded: security_helper
DEBUG - 2017-01-11 22:22:46 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:22:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 22:22:46 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 22:22:46 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:22:46 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 22:22:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 22:22:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 22:22:46 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 22:22:46 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:22:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 22:22:46 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 22:22:46 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:22:46 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 22:22:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 22:22:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 22:22:46 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 22:22:46 --> Database Driver Class Initialized
DEBUG - 2017-01-11 22:22:46 --> Session Class Initialized
DEBUG - 2017-01-11 22:22:46 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 22:22:46 --> Helper loaded: string_helper
DEBUG - 2017-01-11 22:22:46 --> Session routines successfully run
DEBUG - 2017-01-11 22:22:46 --> Native_session Class Initialized
DEBUG - 2017-01-11 22:22:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 22:22:46 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:22:46 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:22:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 22:22:46 --> Controller Class Initialized
DEBUG - 2017-01-11 22:22:46 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 22:22:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 22:22:46 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 22:22:46 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:22:46 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:22:46 --> User Agent Class Initialized
DEBUG - 2017-01-11 22:22:46 --> Model Class Initialized
DEBUG - 2017-01-11 22:22:46 --> Model Class Initialized
DEBUG - 2017-01-11 22:22:46 --> Model Class Initialized
DEBUG - 2017-01-11 22:22:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2017-01-11 22:22:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-11 22:22:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-11 22:22:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 22:22:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-11 22:22:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 22:22:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-11 22:22:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-11 22:22:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-11 22:22:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 22:22:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-11 22:22:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 22:22:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-11 22:22:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2017-01-11 22:22:46 --> Final output sent to browser
DEBUG - 2017-01-11 22:22:46 --> Total execution time: 0.6059
DEBUG - 2017-01-11 22:22:59 --> Config Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Hooks Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Utf8 Class Initialized
DEBUG - 2017-01-11 22:22:59 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 22:22:59 --> URI Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Router Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Output Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Security Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Input Class Initialized
DEBUG - 2017-01-11 22:22:59 --> XSS Filtering completed
DEBUG - 2017-01-11 22:22:59 --> XSS Filtering completed
DEBUG - 2017-01-11 22:22:59 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 22:22:59 --> Language Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Loader Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 22:22:59 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 22:22:59 --> Helper loaded: url_helper
DEBUG - 2017-01-11 22:22:59 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 22:22:59 --> Helper loaded: file_helper
DEBUG - 2017-01-11 22:22:59 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:22:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 22:22:59 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 22:22:59 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:22:59 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 22:22:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 22:22:59 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:22:59 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 22:22:59 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:22:59 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 22:22:59 --> Helper loaded: form_helper
DEBUG - 2017-01-11 22:22:59 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 22:22:59 --> Helper loaded: security_helper
DEBUG - 2017-01-11 22:22:59 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:22:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 22:22:59 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 22:22:59 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:22:59 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 22:22:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 22:22:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 22:22:59 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 22:22:59 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:22:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 22:22:59 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 22:22:59 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:22:59 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 22:22:59 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 22:22:59 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 22:22:59 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 22:22:59 --> Database Driver Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Session Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 22:22:59 --> Helper loaded: string_helper
DEBUG - 2017-01-11 22:22:59 --> Session routines successfully run
DEBUG - 2017-01-11 22:22:59 --> Native_session Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 22:22:59 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 22:22:59 --> Controller Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 22:22:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 22:22:59 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 22:22:59 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:22:59 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:22:59 --> User Agent Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Model Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Model Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Model Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Model Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Model Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Model Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Model Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Config Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Hooks Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Utf8 Class Initialized
DEBUG - 2017-01-11 22:22:59 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 22:22:59 --> URI Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Router Class Initialized
DEBUG - 2017-01-11 22:22:59 --> No URI present. Default controller set.
DEBUG - 2017-01-11 22:22:59 --> Output Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 22:22:59 --> Security Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Input Class Initialized
DEBUG - 2017-01-11 22:22:59 --> XSS Filtering completed
DEBUG - 2017-01-11 22:22:59 --> XSS Filtering completed
DEBUG - 2017-01-11 22:22:59 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 22:22:59 --> Language Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Loader Class Initialized
DEBUG - 2017-01-11 22:22:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 22:23:00 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 22:23:00 --> Helper loaded: url_helper
DEBUG - 2017-01-11 22:23:00 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 22:23:00 --> Helper loaded: file_helper
DEBUG - 2017-01-11 22:23:00 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:23:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 22:23:00 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 22:23:00 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:23:00 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 22:23:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 22:23:00 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:23:00 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 22:23:00 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:23:00 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 22:23:00 --> Helper loaded: form_helper
DEBUG - 2017-01-11 22:23:00 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 22:23:00 --> Helper loaded: security_helper
DEBUG - 2017-01-11 22:23:00 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:23:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 22:23:00 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 22:23:00 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:23:00 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 22:23:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 22:23:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 22:23:00 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 22:23:00 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:23:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 22:23:00 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 22:23:00 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:23:00 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 22:23:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 22:23:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 22:23:00 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 22:23:00 --> Database Driver Class Initialized
DEBUG - 2017-01-11 22:23:00 --> Session Class Initialized
DEBUG - 2017-01-11 22:23:00 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 22:23:00 --> Helper loaded: string_helper
DEBUG - 2017-01-11 22:23:00 --> Session routines successfully run
DEBUG - 2017-01-11 22:23:00 --> Native_session Class Initialized
DEBUG - 2017-01-11 22:23:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 22:23:00 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:23:00 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:23:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 22:23:00 --> Controller Class Initialized
DEBUG - 2017-01-11 22:23:00 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 22:23:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 22:23:00 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 22:23:00 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:23:00 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:23:00 --> User Agent Class Initialized
DEBUG - 2017-01-11 22:23:00 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:00 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:00 --> Model Class Initialized
ERROR - 2017-01-11 22:23:00 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2017-01-11 22:23:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2017-01-11 22:23:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2017-01-11 22:23:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-11 22:23:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 22:23:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-11 22:23:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-11 22:23:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-11 22:23:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-11 22:23:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-11 22:23:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 22:23:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-11 22:23:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-11 22:23:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 22:23:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-11 22:23:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-11 22:23:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-11 22:23:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-11 22:23:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-11 22:23:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 22:23:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-11 22:23:00 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2017-01-11 22:23:00 --> Final output sent to browser
DEBUG - 2017-01-11 22:23:00 --> Total execution time: 0.6970
DEBUG - 2017-01-11 22:23:00 --> Config Class Initialized
DEBUG - 2017-01-11 22:23:00 --> Hooks Class Initialized
DEBUG - 2017-01-11 22:23:00 --> Utf8 Class Initialized
DEBUG - 2017-01-11 22:23:00 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 22:23:00 --> URI Class Initialized
DEBUG - 2017-01-11 22:23:00 --> Router Class Initialized
DEBUG - 2017-01-11 22:23:00 --> Output Class Initialized
DEBUG - 2017-01-11 22:23:00 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 22:23:00 --> Security Class Initialized
DEBUG - 2017-01-11 22:23:00 --> Input Class Initialized
DEBUG - 2017-01-11 22:23:00 --> XSS Filtering completed
DEBUG - 2017-01-11 22:23:01 --> XSS Filtering completed
DEBUG - 2017-01-11 22:23:01 --> XSS Filtering completed
DEBUG - 2017-01-11 22:23:01 --> XSS Filtering completed
DEBUG - 2017-01-11 22:23:01 --> XSS Filtering completed
DEBUG - 2017-01-11 22:23:01 --> XSS Filtering completed
DEBUG - 2017-01-11 22:23:01 --> XSS Filtering completed
DEBUG - 2017-01-11 22:23:01 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 22:23:01 --> Language Class Initialized
DEBUG - 2017-01-11 22:23:01 --> Loader Class Initialized
DEBUG - 2017-01-11 22:23:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 22:23:01 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 22:23:01 --> Helper loaded: url_helper
DEBUG - 2017-01-11 22:23:01 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 22:23:01 --> Helper loaded: file_helper
DEBUG - 2017-01-11 22:23:01 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:23:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 22:23:01 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 22:23:01 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:23:01 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 22:23:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 22:23:01 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:23:01 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 22:23:01 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:23:01 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 22:23:01 --> Helper loaded: form_helper
DEBUG - 2017-01-11 22:23:01 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 22:23:01 --> Helper loaded: security_helper
DEBUG - 2017-01-11 22:23:01 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:23:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 22:23:01 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 22:23:01 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:23:01 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 22:23:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 22:23:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 22:23:01 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 22:23:01 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:23:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 22:23:01 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 22:23:01 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:23:01 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 22:23:01 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 22:23:01 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 22:23:01 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 22:23:01 --> Database Driver Class Initialized
DEBUG - 2017-01-11 22:23:01 --> Session Class Initialized
DEBUG - 2017-01-11 22:23:01 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 22:23:01 --> Helper loaded: string_helper
DEBUG - 2017-01-11 22:23:01 --> Session routines successfully run
DEBUG - 2017-01-11 22:23:01 --> Native_session Class Initialized
DEBUG - 2017-01-11 22:23:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 22:23:01 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:23:01 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:23:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 22:23:01 --> Controller Class Initialized
DEBUG - 2017-01-11 22:23:01 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 22:23:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 22:23:01 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 22:23:01 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:23:01 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:23:01 --> User Agent Class Initialized
DEBUG - 2017-01-11 22:23:01 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:01 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:01 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:01 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:01 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:01 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:01 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:01 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2017-01-11 22:23:01 --> Final output sent to browser
DEBUG - 2017-01-11 22:23:01 --> Total execution time: 0.8416
DEBUG - 2017-01-11 22:23:02 --> Config Class Initialized
DEBUG - 2017-01-11 22:23:02 --> Hooks Class Initialized
DEBUG - 2017-01-11 22:23:02 --> Utf8 Class Initialized
DEBUG - 2017-01-11 22:23:02 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 22:23:02 --> URI Class Initialized
DEBUG - 2017-01-11 22:23:02 --> Router Class Initialized
DEBUG - 2017-01-11 22:23:02 --> Output Class Initialized
DEBUG - 2017-01-11 22:23:02 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 22:23:02 --> Security Class Initialized
DEBUG - 2017-01-11 22:23:02 --> Input Class Initialized
DEBUG - 2017-01-11 22:23:02 --> XSS Filtering completed
DEBUG - 2017-01-11 22:23:02 --> XSS Filtering completed
DEBUG - 2017-01-11 22:23:02 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 22:23:02 --> Language Class Initialized
DEBUG - 2017-01-11 22:23:02 --> Loader Class Initialized
DEBUG - 2017-01-11 22:23:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 22:23:02 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 22:23:02 --> Helper loaded: url_helper
DEBUG - 2017-01-11 22:23:02 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 22:23:02 --> Helper loaded: file_helper
DEBUG - 2017-01-11 22:23:02 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:23:02 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 22:23:02 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 22:23:02 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:23:02 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 22:23:02 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 22:23:02 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:23:02 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 22:23:02 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:23:02 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 22:23:02 --> Helper loaded: form_helper
DEBUG - 2017-01-11 22:23:02 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 22:23:02 --> Helper loaded: security_helper
DEBUG - 2017-01-11 22:23:02 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:23:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 22:23:02 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 22:23:02 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:23:02 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 22:23:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 22:23:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 22:23:02 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 22:23:02 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:23:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 22:23:02 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 22:23:02 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:23:02 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 22:23:02 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 22:23:02 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 22:23:02 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 22:23:03 --> Database Driver Class Initialized
DEBUG - 2017-01-11 22:23:03 --> Session Class Initialized
DEBUG - 2017-01-11 22:23:03 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 22:23:03 --> Helper loaded: string_helper
DEBUG - 2017-01-11 22:23:03 --> Session routines successfully run
DEBUG - 2017-01-11 22:23:03 --> Native_session Class Initialized
DEBUG - 2017-01-11 22:23:03 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 22:23:03 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:23:03 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:23:03 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 22:23:03 --> Controller Class Initialized
DEBUG - 2017-01-11 22:23:03 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 22:23:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 22:23:03 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 22:23:03 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:23:03 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:23:03 --> User Agent Class Initialized
DEBUG - 2017-01-11 22:23:03 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:03 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:03 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2017-01-11 22:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-11 22:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-11 22:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 22:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-11 22:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 22:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-11 22:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2017-01-11 22:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2017-01-11 22:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 22:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2017-01-11 22:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 22:23:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2017-01-11 22:23:03 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2017-01-11 22:23:03 --> Final output sent to browser
DEBUG - 2017-01-11 22:23:03 --> Total execution time: 0.7093
DEBUG - 2017-01-11 22:23:05 --> Config Class Initialized
DEBUG - 2017-01-11 22:23:05 --> Hooks Class Initialized
DEBUG - 2017-01-11 22:23:05 --> Utf8 Class Initialized
DEBUG - 2017-01-11 22:23:05 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 22:23:05 --> URI Class Initialized
DEBUG - 2017-01-11 22:23:05 --> Router Class Initialized
DEBUG - 2017-01-11 22:23:05 --> Output Class Initialized
DEBUG - 2017-01-11 22:23:05 --> Security Class Initialized
DEBUG - 2017-01-11 22:23:05 --> Input Class Initialized
DEBUG - 2017-01-11 22:23:05 --> XSS Filtering completed
DEBUG - 2017-01-11 22:23:05 --> XSS Filtering completed
DEBUG - 2017-01-11 22:23:05 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 22:23:05 --> Language Class Initialized
DEBUG - 2017-01-11 22:23:05 --> Loader Class Initialized
DEBUG - 2017-01-11 22:23:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 22:23:05 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 22:23:05 --> Helper loaded: url_helper
DEBUG - 2017-01-11 22:23:05 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 22:23:05 --> Helper loaded: file_helper
DEBUG - 2017-01-11 22:23:05 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:23:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 22:23:05 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 22:23:05 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:23:05 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 22:23:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 22:23:05 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:23:05 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 22:23:05 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:23:05 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 22:23:05 --> Helper loaded: form_helper
DEBUG - 2017-01-11 22:23:05 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 22:23:05 --> Helper loaded: security_helper
DEBUG - 2017-01-11 22:23:05 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:23:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 22:23:05 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 22:23:05 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:23:05 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 22:23:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 22:23:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 22:23:05 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 22:23:05 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:23:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 22:23:05 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 22:23:05 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:23:05 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 22:23:05 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 22:23:05 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 22:23:05 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 22:23:05 --> Database Driver Class Initialized
DEBUG - 2017-01-11 22:23:05 --> Session Class Initialized
DEBUG - 2017-01-11 22:23:05 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 22:23:05 --> Helper loaded: string_helper
DEBUG - 2017-01-11 22:23:05 --> Session routines successfully run
DEBUG - 2017-01-11 22:23:05 --> Native_session Class Initialized
DEBUG - 2017-01-11 22:23:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 22:23:05 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:23:05 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:23:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 22:23:05 --> Controller Class Initialized
DEBUG - 2017-01-11 22:23:05 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 22:23:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 22:23:05 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 22:23:05 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:23:05 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:23:05 --> User Agent Class Initialized
DEBUG - 2017-01-11 22:23:05 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:05 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:05 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:05 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:05 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:05 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:05 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:05 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2017-01-11 22:23:05 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2017-01-11 22:23:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2017-01-11 22:23:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2017-01-11 22:23:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2017-01-11 22:23:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2017-01-11 22:23:05 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2017-01-11 22:23:05 --> Final output sent to browser
DEBUG - 2017-01-11 22:23:06 --> Total execution time: 0.7567
DEBUG - 2017-01-11 22:23:09 --> Config Class Initialized
DEBUG - 2017-01-11 22:23:09 --> Hooks Class Initialized
DEBUG - 2017-01-11 22:23:09 --> Utf8 Class Initialized
DEBUG - 2017-01-11 22:23:09 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 22:23:09 --> URI Class Initialized
DEBUG - 2017-01-11 22:23:09 --> Router Class Initialized
DEBUG - 2017-01-11 22:23:09 --> Output Class Initialized
DEBUG - 2017-01-11 22:23:09 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 22:23:09 --> Security Class Initialized
DEBUG - 2017-01-11 22:23:09 --> Input Class Initialized
DEBUG - 2017-01-11 22:23:09 --> XSS Filtering completed
DEBUG - 2017-01-11 22:23:09 --> XSS Filtering completed
DEBUG - 2017-01-11 22:23:09 --> XSS Filtering completed
DEBUG - 2017-01-11 22:23:09 --> XSS Filtering completed
DEBUG - 2017-01-11 22:23:09 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 22:23:09 --> Language Class Initialized
DEBUG - 2017-01-11 22:23:09 --> Loader Class Initialized
DEBUG - 2017-01-11 22:23:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 22:23:09 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 22:23:09 --> Helper loaded: url_helper
DEBUG - 2017-01-11 22:23:09 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 22:23:09 --> Helper loaded: file_helper
DEBUG - 2017-01-11 22:23:09 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:23:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 22:23:09 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 22:23:09 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:23:09 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 22:23:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 22:23:09 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:23:09 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 22:23:09 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:23:09 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 22:23:09 --> Helper loaded: form_helper
DEBUG - 2017-01-11 22:23:09 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 22:23:09 --> Helper loaded: security_helper
DEBUG - 2017-01-11 22:23:09 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:23:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 22:23:10 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 22:23:10 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:23:10 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 22:23:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 22:23:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 22:23:10 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 22:23:10 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:23:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 22:23:10 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 22:23:10 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:23:10 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 22:23:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 22:23:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 22:23:10 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 22:23:10 --> Database Driver Class Initialized
DEBUG - 2017-01-11 22:23:10 --> Session Class Initialized
DEBUG - 2017-01-11 22:23:10 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 22:23:10 --> Helper loaded: string_helper
DEBUG - 2017-01-11 22:23:10 --> Session routines successfully run
DEBUG - 2017-01-11 22:23:10 --> Native_session Class Initialized
DEBUG - 2017-01-11 22:23:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 22:23:10 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:23:10 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:23:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 22:23:10 --> Controller Class Initialized
DEBUG - 2017-01-11 22:23:10 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 22:23:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 22:23:10 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 22:23:10 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:23:10 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:23:10 --> User Agent Class Initialized
DEBUG - 2017-01-11 22:23:10 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:10 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:10 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:10 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:10 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:10 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:10 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2017-01-11 22:23:10 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:23:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 22:23:10 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2017-01-11 22:23:10 --> Config Class Initialized
DEBUG - 2017-01-11 22:23:10 --> Hooks Class Initialized
DEBUG - 2017-01-11 22:23:10 --> Utf8 Class Initialized
DEBUG - 2017-01-11 22:23:10 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 22:23:10 --> URI Class Initialized
DEBUG - 2017-01-11 22:23:10 --> Router Class Initialized
DEBUG - 2017-01-11 22:23:10 --> No URI present. Default controller set.
DEBUG - 2017-01-11 22:23:10 --> Output Class Initialized
DEBUG - 2017-01-11 22:23:10 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 22:23:10 --> Security Class Initialized
DEBUG - 2017-01-11 22:23:10 --> Input Class Initialized
DEBUG - 2017-01-11 22:23:10 --> XSS Filtering completed
DEBUG - 2017-01-11 22:23:10 --> XSS Filtering completed
DEBUG - 2017-01-11 22:23:10 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 22:23:10 --> Language Class Initialized
DEBUG - 2017-01-11 22:23:10 --> Loader Class Initialized
DEBUG - 2017-01-11 22:23:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 22:23:10 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 22:23:10 --> Helper loaded: url_helper
DEBUG - 2017-01-11 22:23:10 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 22:23:10 --> Helper loaded: file_helper
DEBUG - 2017-01-11 22:23:10 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:23:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 22:23:10 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 22:23:10 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:23:10 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 22:23:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 22:23:10 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:23:10 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 22:23:10 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:23:10 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 22:23:10 --> Helper loaded: form_helper
DEBUG - 2017-01-11 22:23:10 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 22:23:10 --> Helper loaded: security_helper
DEBUG - 2017-01-11 22:23:10 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:23:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 22:23:10 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 22:23:10 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:23:10 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 22:23:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 22:23:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 22:23:10 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 22:23:10 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:23:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 22:23:10 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 22:23:10 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:23:10 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 22:23:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 22:23:11 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 22:23:11 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 22:23:11 --> Database Driver Class Initialized
DEBUG - 2017-01-11 22:23:11 --> Session Class Initialized
DEBUG - 2017-01-11 22:23:11 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 22:23:11 --> Helper loaded: string_helper
DEBUG - 2017-01-11 22:23:11 --> Session routines successfully run
DEBUG - 2017-01-11 22:23:11 --> Native_session Class Initialized
DEBUG - 2017-01-11 22:23:11 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 22:23:11 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:23:11 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:23:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 22:23:11 --> Controller Class Initialized
DEBUG - 2017-01-11 22:23:11 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 22:23:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 22:23:11 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 22:23:11 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:23:11 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:23:11 --> User Agent Class Initialized
DEBUG - 2017-01-11 22:23:11 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:11 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:11 --> Model Class Initialized
ERROR - 2017-01-11 22:23:11 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2017-01-11 22:23:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2017-01-11 22:23:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2017-01-11 22:23:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-11 22:23:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 22:23:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-11 22:23:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-11 22:23:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-11 22:23:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-11 22:23:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-11 22:23:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 22:23:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-11 22:23:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2017-01-11 22:23:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2017-01-11 22:23:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2017-01-11 22:23:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2017-01-11 22:23:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2017-01-11 22:23:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2017-01-11 22:23:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2017-01-11 22:23:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2017-01-11 22:23:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2017-01-11 22:23:11 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2017-01-11 22:23:11 --> Final output sent to browser
DEBUG - 2017-01-11 22:23:11 --> Total execution time: 0.7952
DEBUG - 2017-01-11 22:23:11 --> Config Class Initialized
DEBUG - 2017-01-11 22:23:11 --> Hooks Class Initialized
DEBUG - 2017-01-11 22:23:11 --> Utf8 Class Initialized
DEBUG - 2017-01-11 22:23:11 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 22:23:11 --> URI Class Initialized
DEBUG - 2017-01-11 22:23:11 --> Router Class Initialized
DEBUG - 2017-01-11 22:23:11 --> Output Class Initialized
DEBUG - 2017-01-11 22:23:11 --> Cache file has expired. File deleted
DEBUG - 2017-01-11 22:23:11 --> Security Class Initialized
DEBUG - 2017-01-11 22:23:11 --> Input Class Initialized
DEBUG - 2017-01-11 22:23:11 --> XSS Filtering completed
DEBUG - 2017-01-11 22:23:11 --> XSS Filtering completed
DEBUG - 2017-01-11 22:23:11 --> XSS Filtering completed
DEBUG - 2017-01-11 22:23:11 --> XSS Filtering completed
DEBUG - 2017-01-11 22:23:11 --> XSS Filtering completed
DEBUG - 2017-01-11 22:23:11 --> XSS Filtering completed
DEBUG - 2017-01-11 22:23:11 --> XSS Filtering completed
DEBUG - 2017-01-11 22:23:11 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 22:23:11 --> Language Class Initialized
DEBUG - 2017-01-11 22:23:11 --> Loader Class Initialized
DEBUG - 2017-01-11 22:23:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 22:23:11 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 22:23:11 --> Helper loaded: url_helper
DEBUG - 2017-01-11 22:23:11 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 22:23:11 --> Helper loaded: file_helper
DEBUG - 2017-01-11 22:23:11 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:23:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 22:23:11 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 22:23:11 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:23:11 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 22:23:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 22:23:12 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:23:12 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 22:23:12 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:23:12 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 22:23:12 --> Helper loaded: form_helper
DEBUG - 2017-01-11 22:23:12 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 22:23:12 --> Helper loaded: security_helper
DEBUG - 2017-01-11 22:23:12 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:23:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 22:23:12 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 22:23:12 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:23:12 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 22:23:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 22:23:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 22:23:12 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 22:23:12 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:23:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 22:23:12 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 22:23:12 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:23:12 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 22:23:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 22:23:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 22:23:12 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 22:23:12 --> Database Driver Class Initialized
DEBUG - 2017-01-11 22:23:12 --> Session Class Initialized
DEBUG - 2017-01-11 22:23:12 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 22:23:12 --> Helper loaded: string_helper
DEBUG - 2017-01-11 22:23:12 --> Session routines successfully run
DEBUG - 2017-01-11 22:23:12 --> Native_session Class Initialized
DEBUG - 2017-01-11 22:23:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 22:23:12 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:23:12 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:23:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 22:23:12 --> Controller Class Initialized
DEBUG - 2017-01-11 22:23:12 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 22:23:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 22:23:12 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 22:23:12 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:23:12 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:23:12 --> User Agent Class Initialized
DEBUG - 2017-01-11 22:23:12 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:12 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:12 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:12 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:12 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:12 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:12 --> Model Class Initialized
DEBUG - 2017-01-11 22:23:12 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2017-01-11 22:23:12 --> Final output sent to browser
DEBUG - 2017-01-11 22:23:12 --> Total execution time: 0.9524
DEBUG - 2017-01-11 22:32:18 --> Config Class Initialized
DEBUG - 2017-01-11 22:32:18 --> Hooks Class Initialized
DEBUG - 2017-01-11 22:32:18 --> Utf8 Class Initialized
DEBUG - 2017-01-11 22:32:18 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 22:32:18 --> URI Class Initialized
DEBUG - 2017-01-11 22:32:18 --> Router Class Initialized
DEBUG - 2017-01-11 22:32:18 --> Output Class Initialized
DEBUG - 2017-01-11 22:32:18 --> Security Class Initialized
DEBUG - 2017-01-11 22:32:18 --> Input Class Initialized
DEBUG - 2017-01-11 22:32:18 --> XSS Filtering completed
DEBUG - 2017-01-11 22:32:18 --> XSS Filtering completed
DEBUG - 2017-01-11 22:32:18 --> XSS Filtering completed
DEBUG - 2017-01-11 22:32:18 --> XSS Filtering completed
DEBUG - 2017-01-11 22:32:18 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 22:32:18 --> Language Class Initialized
DEBUG - 2017-01-11 22:32:18 --> Loader Class Initialized
DEBUG - 2017-01-11 22:32:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 22:32:18 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 22:32:18 --> Helper loaded: url_helper
DEBUG - 2017-01-11 22:32:18 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 22:32:18 --> Helper loaded: file_helper
DEBUG - 2017-01-11 22:32:18 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:32:18 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 22:32:18 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 22:32:18 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:32:18 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 22:32:18 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 22:32:18 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:32:18 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 22:32:18 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:32:18 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 22:32:18 --> Helper loaded: form_helper
DEBUG - 2017-01-11 22:32:18 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 22:32:18 --> Helper loaded: security_helper
DEBUG - 2017-01-11 22:32:18 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:32:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 22:32:18 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 22:32:18 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:32:18 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 22:32:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 22:32:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 22:32:18 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 22:32:18 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:32:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 22:32:18 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 22:32:18 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:32:18 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 22:32:18 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 22:32:18 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 22:32:18 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 22:32:18 --> Database Driver Class Initialized
DEBUG - 2017-01-11 22:32:18 --> Session Class Initialized
DEBUG - 2017-01-11 22:32:18 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 22:32:18 --> Helper loaded: string_helper
DEBUG - 2017-01-11 22:32:18 --> Session routines successfully run
DEBUG - 2017-01-11 22:32:18 --> Native_session Class Initialized
DEBUG - 2017-01-11 22:32:18 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 22:32:18 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:32:18 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:32:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 22:32:18 --> Controller Class Initialized
DEBUG - 2017-01-11 22:32:18 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 22:32:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 22:32:18 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 22:32:18 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:32:18 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:32:18 --> User Agent Class Initialized
DEBUG - 2017-01-11 22:32:18 --> Model Class Initialized
DEBUG - 2017-01-11 22:32:18 --> Model Class Initialized
ERROR - 2017-01-11 22:32:18 --> 404 Page Not Found --> 
DEBUG - 2017-01-11 22:32:18 --> Config Class Initialized
DEBUG - 2017-01-11 22:32:18 --> Hooks Class Initialized
DEBUG - 2017-01-11 22:32:18 --> Utf8 Class Initialized
DEBUG - 2017-01-11 22:32:18 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 22:32:18 --> URI Class Initialized
DEBUG - 2017-01-11 22:32:18 --> Router Class Initialized
ERROR - 2017-01-11 22:32:18 --> 404 Page Not Found --> developer_administrator/img
DEBUG - 2017-01-11 22:32:19 --> Config Class Initialized
DEBUG - 2017-01-11 22:32:19 --> Hooks Class Initialized
DEBUG - 2017-01-11 22:32:19 --> Utf8 Class Initialized
DEBUG - 2017-01-11 22:32:19 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 22:32:19 --> URI Class Initialized
DEBUG - 2017-01-11 22:32:19 --> Router Class Initialized
DEBUG - 2017-01-11 22:32:19 --> Output Class Initialized
DEBUG - 2017-01-11 22:32:19 --> Security Class Initialized
DEBUG - 2017-01-11 22:32:19 --> Input Class Initialized
DEBUG - 2017-01-11 22:32:19 --> XSS Filtering completed
DEBUG - 2017-01-11 22:32:19 --> XSS Filtering completed
DEBUG - 2017-01-11 22:32:19 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 22:32:19 --> Language Class Initialized
DEBUG - 2017-01-11 22:32:19 --> Loader Class Initialized
DEBUG - 2017-01-11 22:32:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 22:32:19 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 22:32:19 --> Helper loaded: url_helper
DEBUG - 2017-01-11 22:32:19 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 22:32:19 --> Helper loaded: file_helper
DEBUG - 2017-01-11 22:32:19 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:32:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 22:32:19 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 22:32:19 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:32:19 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 22:32:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 22:32:19 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:32:19 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 22:32:19 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:32:19 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 22:32:19 --> Helper loaded: form_helper
DEBUG - 2017-01-11 22:32:19 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 22:32:19 --> Helper loaded: security_helper
DEBUG - 2017-01-11 22:32:19 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:32:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 22:32:19 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 22:32:19 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:32:19 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 22:32:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 22:32:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 22:32:19 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 22:32:19 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:32:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 22:32:19 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 22:32:19 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:32:19 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 22:32:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 22:32:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 22:32:19 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 22:32:19 --> Database Driver Class Initialized
DEBUG - 2017-01-11 22:32:19 --> Session Class Initialized
DEBUG - 2017-01-11 22:32:19 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 22:32:19 --> Helper loaded: string_helper
DEBUG - 2017-01-11 22:32:19 --> Session routines successfully run
DEBUG - 2017-01-11 22:32:19 --> Native_session Class Initialized
DEBUG - 2017-01-11 22:32:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 22:32:19 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:32:19 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:32:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 22:32:19 --> Controller Class Initialized
DEBUG - 2017-01-11 22:32:19 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 22:32:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 22:32:19 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 22:32:19 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:32:19 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:32:19 --> User Agent Class Initialized
DEBUG - 2017-01-11 22:32:19 --> Model Class Initialized
DEBUG - 2017-01-11 22:32:19 --> Model Class Initialized
ERROR - 2017-01-11 22:32:19 --> 404 Page Not Found --> 
DEBUG - 2017-01-11 22:32:36 --> Config Class Initialized
DEBUG - 2017-01-11 22:32:36 --> Hooks Class Initialized
DEBUG - 2017-01-11 22:32:36 --> Utf8 Class Initialized
DEBUG - 2017-01-11 22:32:36 --> UTF-8 Support Enabled
DEBUG - 2017-01-11 22:32:36 --> URI Class Initialized
DEBUG - 2017-01-11 22:32:36 --> Router Class Initialized
DEBUG - 2017-01-11 22:32:36 --> Output Class Initialized
DEBUG - 2017-01-11 22:32:36 --> Security Class Initialized
DEBUG - 2017-01-11 22:32:36 --> Input Class Initialized
DEBUG - 2017-01-11 22:32:36 --> XSS Filtering completed
DEBUG - 2017-01-11 22:32:36 --> XSS Filtering completed
DEBUG - 2017-01-11 22:32:36 --> XSS Filtering completed
DEBUG - 2017-01-11 22:32:36 --> XSS Filtering completed
DEBUG - 2017-01-11 22:32:36 --> Global POST and COOKIE data sanitized
DEBUG - 2017-01-11 22:32:36 --> Language Class Initialized
DEBUG - 2017-01-11 22:32:36 --> Loader Class Initialized
DEBUG - 2017-01-11 22:32:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2017-01-11 22:32:36 --> Check Exists url_helper.php: Yes
DEBUG - 2017-01-11 22:32:36 --> Helper loaded: url_helper
DEBUG - 2017-01-11 22:32:36 --> Check Exists file_helper.php: Yes
DEBUG - 2017-01-11 22:32:36 --> Helper loaded: file_helper
DEBUG - 2017-01-11 22:32:36 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:32:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2017-01-11 22:32:36 --> Helper loaded: conf_helper
DEBUG - 2017-01-11 22:32:36 --> Check Exists conf_helper.php: No
DEBUG - 2017-01-11 22:32:36 --> Check Exists common_helper.php: No
DEBUG - 2017-01-11 22:32:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2017-01-11 22:32:36 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:32:36 --> Check Exists common_helper.php: Yes
DEBUG - 2017-01-11 22:32:36 --> Helper loaded: common_helper
DEBUG - 2017-01-11 22:32:36 --> Check Exists form_helper.php: Yes
DEBUG - 2017-01-11 22:32:36 --> Helper loaded: form_helper
DEBUG - 2017-01-11 22:32:36 --> Check Exists security_helper.php: Yes
DEBUG - 2017-01-11 22:32:36 --> Helper loaded: security_helper
DEBUG - 2017-01-11 22:32:36 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:32:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2017-01-11 22:32:36 --> Helper loaded: lang_helper
DEBUG - 2017-01-11 22:32:36 --> Check Exists lang_helper.php: No
DEBUG - 2017-01-11 22:32:36 --> Check Exists atlant_helper.php: No
DEBUG - 2017-01-11 22:32:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2017-01-11 22:32:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2017-01-11 22:32:36 --> Helper loaded: atlant_helper
DEBUG - 2017-01-11 22:32:36 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:32:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2017-01-11 22:32:36 --> Helper loaded: crypto_helper
DEBUG - 2017-01-11 22:32:36 --> Check Exists crypto_helper.php: No
DEBUG - 2017-01-11 22:32:36 --> Check Exists sidika_helper.php: No
DEBUG - 2017-01-11 22:32:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2017-01-11 22:32:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2017-01-11 22:32:36 --> Helper loaded: sidika_helper
DEBUG - 2017-01-11 22:32:36 --> Database Driver Class Initialized
DEBUG - 2017-01-11 22:32:36 --> Session Class Initialized
DEBUG - 2017-01-11 22:32:36 --> Check Exists string_helper.php: Yes
DEBUG - 2017-01-11 22:32:36 --> Helper loaded: string_helper
DEBUG - 2017-01-11 22:32:36 --> Session routines successfully run
DEBUG - 2017-01-11 22:32:36 --> Native_session Class Initialized
DEBUG - 2017-01-11 22:32:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2017-01-11 22:32:36 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:32:36 --> Form Validation Class Initialized
DEBUG - 2017-01-11 22:32:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2017-01-11 22:32:36 --> Controller Class Initialized
DEBUG - 2017-01-11 22:32:36 --> Carabiner: Library initialized.
DEBUG - 2017-01-11 22:32:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2017-01-11 22:32:36 --> Carabiner: config loaded from config file.
DEBUG - 2017-01-11 22:32:36 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:32:36 --> Carabiner: library configured.
DEBUG - 2017-01-11 22:32:36 --> User Agent Class Initialized
DEBUG - 2017-01-11 22:32:36 --> Model Class Initialized
DEBUG - 2017-01-11 22:32:36 --> Model Class Initialized
