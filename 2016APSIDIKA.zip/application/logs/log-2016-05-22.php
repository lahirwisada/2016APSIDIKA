<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-05-22 00:52:02 --> Config Class Initialized
DEBUG - 2016-05-22 00:52:02 --> Hooks Class Initialized
DEBUG - 2016-05-22 00:52:02 --> Utf8 Class Initialized
DEBUG - 2016-05-22 00:52:02 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 00:52:02 --> URI Class Initialized
DEBUG - 2016-05-22 00:52:02 --> Router Class Initialized
DEBUG - 2016-05-22 00:52:02 --> Output Class Initialized
DEBUG - 2016-05-22 00:52:02 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 00:52:02 --> Security Class Initialized
DEBUG - 2016-05-22 00:52:02 --> Input Class Initialized
DEBUG - 2016-05-22 00:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 00:52:02 --> Language Class Initialized
DEBUG - 2016-05-22 00:52:02 --> Loader Class Initialized
DEBUG - 2016-05-22 00:52:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 00:52:02 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 00:52:02 --> Helper loaded: url_helper
DEBUG - 2016-05-22 00:52:02 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 00:52:02 --> Helper loaded: file_helper
DEBUG - 2016-05-22 00:52:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 00:52:02 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 00:52:02 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 00:52:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 00:52:02 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 00:52:02 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 00:52:02 --> Helper loaded: common_helper
DEBUG - 2016-05-22 00:52:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 00:52:02 --> Helper loaded: common_helper
DEBUG - 2016-05-22 00:52:02 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 00:52:02 --> Helper loaded: form_helper
DEBUG - 2016-05-22 00:52:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 00:52:02 --> Helper loaded: security_helper
DEBUG - 2016-05-22 00:52:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 00:52:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 00:52:03 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 00:52:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 00:52:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 00:52:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 00:52:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 00:52:03 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 00:52:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 00:52:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 00:52:03 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 00:52:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 00:52:03 --> Database Driver Class Initialized
DEBUG - 2016-05-22 00:52:03 --> Session Class Initialized
DEBUG - 2016-05-22 00:52:03 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 00:52:03 --> Helper loaded: string_helper
DEBUG - 2016-05-22 00:52:03 --> A session cookie was not found.
DEBUG - 2016-05-22 00:52:03 --> Session routines successfully run
DEBUG - 2016-05-22 00:52:03 --> Native_session Class Initialized
DEBUG - 2016-05-22 00:52:03 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 00:52:03 --> Form Validation Class Initialized
DEBUG - 2016-05-22 00:52:03 --> Form Validation Class Initialized
DEBUG - 2016-05-22 00:52:03 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 00:52:03 --> Controller Class Initialized
DEBUG - 2016-05-22 00:52:03 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 00:52:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 00:52:03 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 00:52:03 --> Carabiner: library configured.
DEBUG - 2016-05-22 00:52:03 --> Carabiner: library configured.
DEBUG - 2016-05-22 00:52:03 --> User Agent Class Initialized
DEBUG - 2016-05-22 00:52:03 --> Model Class Initialized
DEBUG - 2016-05-22 00:52:03 --> Model Class Initialized
DEBUG - 2016-05-22 00:52:03 --> Model Class Initialized
DEBUG - 2016-05-22 00:52:03 --> Model Class Initialized
DEBUG - 2016-05-22 00:52:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-22 00:52:04 --> Pagination Class Initialized
DEBUG - 2016-05-22 00:52:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 00:52:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/index.php
DEBUG - 2016-05-22 00:52:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 00:52:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 00:52:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 00:52:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 00:52:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-05-22 00:52:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 00:52:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 00:52:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 00:52:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 00:52:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 00:52:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 00:52:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-05-22 00:52:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 00:52:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 00:52:05 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0afc8ae14bdb2df5b4e2fbf4366db4fc
DEBUG - 2016-05-22 00:52:05 --> Final output sent to browser
DEBUG - 2016-05-22 00:52:05 --> Total execution time: 1.8515
DEBUG - 2016-05-22 00:52:16 --> Config Class Initialized
DEBUG - 2016-05-22 00:52:16 --> Hooks Class Initialized
DEBUG - 2016-05-22 00:52:16 --> Utf8 Class Initialized
DEBUG - 2016-05-22 00:52:16 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 00:52:16 --> URI Class Initialized
DEBUG - 2016-05-22 00:52:16 --> Router Class Initialized
ERROR - 2016-05-22 00:52:17 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-05-22 00:52:26 --> Config Class Initialized
DEBUG - 2016-05-22 00:52:26 --> Hooks Class Initialized
DEBUG - 2016-05-22 00:52:26 --> Utf8 Class Initialized
DEBUG - 2016-05-22 00:52:26 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 00:52:26 --> URI Class Initialized
DEBUG - 2016-05-22 00:52:26 --> Router Class Initialized
DEBUG - 2016-05-22 00:52:26 --> Output Class Initialized
DEBUG - 2016-05-22 00:52:27 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 00:52:27 --> Security Class Initialized
DEBUG - 2016-05-22 00:52:27 --> Input Class Initialized
DEBUG - 2016-05-22 00:52:27 --> XSS Filtering completed
DEBUG - 2016-05-22 00:52:27 --> XSS Filtering completed
DEBUG - 2016-05-22 00:52:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 00:52:27 --> Language Class Initialized
DEBUG - 2016-05-22 00:52:27 --> Loader Class Initialized
DEBUG - 2016-05-22 00:52:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 00:52:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 00:52:27 --> Helper loaded: url_helper
DEBUG - 2016-05-22 00:52:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 00:52:27 --> Helper loaded: file_helper
DEBUG - 2016-05-22 00:52:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 00:52:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 00:52:27 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 00:52:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 00:52:27 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 00:52:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 00:52:27 --> Helper loaded: common_helper
DEBUG - 2016-05-22 00:52:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 00:52:27 --> Helper loaded: common_helper
DEBUG - 2016-05-22 00:52:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 00:52:27 --> Helper loaded: form_helper
DEBUG - 2016-05-22 00:52:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 00:52:27 --> Helper loaded: security_helper
DEBUG - 2016-05-22 00:52:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 00:52:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 00:52:27 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 00:52:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 00:52:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 00:52:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 00:52:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 00:52:27 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 00:52:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 00:52:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 00:52:27 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 00:52:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 00:52:27 --> Database Driver Class Initialized
DEBUG - 2016-05-22 00:52:28 --> Session Class Initialized
DEBUG - 2016-05-22 00:52:28 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 00:52:28 --> Helper loaded: string_helper
DEBUG - 2016-05-22 00:52:28 --> Session routines successfully run
DEBUG - 2016-05-22 00:52:28 --> Native_session Class Initialized
DEBUG - 2016-05-22 00:52:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 00:52:28 --> Form Validation Class Initialized
DEBUG - 2016-05-22 00:52:28 --> Form Validation Class Initialized
DEBUG - 2016-05-22 00:52:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 00:52:28 --> Controller Class Initialized
DEBUG - 2016-05-22 00:52:28 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 00:52:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 00:52:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 00:52:28 --> Carabiner: library configured.
DEBUG - 2016-05-22 00:52:28 --> Carabiner: library configured.
DEBUG - 2016-05-22 00:52:28 --> User Agent Class Initialized
DEBUG - 2016-05-22 00:52:28 --> Model Class Initialized
DEBUG - 2016-05-22 00:52:28 --> Model Class Initialized
DEBUG - 2016-05-22 00:52:28 --> Model Class Initialized
DEBUG - 2016-05-22 00:52:28 --> Config Class Initialized
DEBUG - 2016-05-22 00:52:28 --> Hooks Class Initialized
DEBUG - 2016-05-22 00:52:28 --> Utf8 Class Initialized
DEBUG - 2016-05-22 00:52:28 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 00:52:28 --> URI Class Initialized
DEBUG - 2016-05-22 00:52:28 --> Router Class Initialized
DEBUG - 2016-05-22 00:52:28 --> Output Class Initialized
DEBUG - 2016-05-22 00:52:28 --> Model Class Initialized
DEBUG - 2016-05-22 00:52:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-22 00:52:28 --> Pagination Class Initialized
DEBUG - 2016-05-22 00:52:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 00:52:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/index.php
DEBUG - 2016-05-22 00:52:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 00:52:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 00:52:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 00:52:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 00:52:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-05-22 00:52:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 00:52:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 00:52:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 00:52:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 00:52:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 00:52:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 00:52:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-05-22 00:52:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 00:52:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 00:52:28 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/860bebf57fee032e24acce1c64d1c3e7
DEBUG - 2016-05-22 00:52:28 --> Final output sent to browser
DEBUG - 2016-05-22 00:52:28 --> Total execution time: 2.0183
DEBUG - 2016-05-22 00:52:28 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 00:52:28 --> Security Class Initialized
DEBUG - 2016-05-22 00:52:28 --> Input Class Initialized
DEBUG - 2016-05-22 00:52:28 --> XSS Filtering completed
DEBUG - 2016-05-22 00:52:28 --> XSS Filtering completed
DEBUG - 2016-05-22 00:52:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 00:52:28 --> Language Class Initialized
DEBUG - 2016-05-22 00:52:28 --> Loader Class Initialized
DEBUG - 2016-05-22 00:52:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 00:52:28 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 00:52:28 --> Helper loaded: url_helper
DEBUG - 2016-05-22 00:52:28 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 00:52:28 --> Helper loaded: file_helper
DEBUG - 2016-05-22 00:52:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 00:52:28 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 00:52:28 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 00:52:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 00:52:28 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 00:52:28 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 00:52:28 --> Helper loaded: common_helper
DEBUG - 2016-05-22 00:52:28 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 00:52:28 --> Helper loaded: common_helper
DEBUG - 2016-05-22 00:52:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 00:52:28 --> Helper loaded: form_helper
DEBUG - 2016-05-22 00:52:28 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 00:52:28 --> Helper loaded: security_helper
DEBUG - 2016-05-22 00:52:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 00:52:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 00:52:28 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 00:52:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 00:52:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 00:52:28 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 00:52:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 00:52:28 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 00:52:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 00:52:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 00:52:29 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 00:52:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 00:52:29 --> Database Driver Class Initialized
DEBUG - 2016-05-22 00:52:29 --> Session Class Initialized
DEBUG - 2016-05-22 00:52:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 00:52:29 --> Helper loaded: string_helper
DEBUG - 2016-05-22 00:52:29 --> Session routines successfully run
DEBUG - 2016-05-22 00:52:29 --> Native_session Class Initialized
DEBUG - 2016-05-22 00:52:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 00:52:29 --> Form Validation Class Initialized
DEBUG - 2016-05-22 00:52:29 --> Form Validation Class Initialized
DEBUG - 2016-05-22 00:52:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 00:52:29 --> Controller Class Initialized
DEBUG - 2016-05-22 00:52:29 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 00:52:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 00:52:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 00:52:29 --> Carabiner: library configured.
DEBUG - 2016-05-22 00:52:29 --> Carabiner: library configured.
DEBUG - 2016-05-22 00:52:29 --> User Agent Class Initialized
DEBUG - 2016-05-22 00:52:29 --> Model Class Initialized
DEBUG - 2016-05-22 00:52:29 --> Model Class Initialized
DEBUG - 2016-05-22 00:52:29 --> Model Class Initialized
DEBUG - 2016-05-22 00:52:29 --> Model Class Initialized
DEBUG - 2016-05-22 00:52:29 --> Model Class Initialized
DEBUG - 2016-05-22 00:52:30 --> Model Class Initialized
DEBUG - 2016-05-22 00:52:30 --> Model Class Initialized
DEBUG - 2016-05-22 00:52:31 --> Model Class Initialized
DEBUG - 2016-05-22 00:52:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-22 00:52:32 --> Pagination Class Initialized
DEBUG - 2016-05-22 00:52:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 00:52:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-05-22 00:52:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 00:52:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 00:52:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 00:52:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 00:52:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-22 00:52:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 00:52:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 00:52:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 00:52:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 00:52:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 00:52:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 00:52:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-22 00:52:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 00:52:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 00:52:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-05-22 00:52:33 --> Final output sent to browser
DEBUG - 2016-05-22 00:52:33 --> Total execution time: 3.9119
DEBUG - 2016-05-22 00:52:36 --> Config Class Initialized
DEBUG - 2016-05-22 00:52:36 --> Hooks Class Initialized
DEBUG - 2016-05-22 00:52:36 --> Utf8 Class Initialized
DEBUG - 2016-05-22 00:52:36 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 00:52:36 --> URI Class Initialized
DEBUG - 2016-05-22 00:52:36 --> Router Class Initialized
ERROR - 2016-05-22 00:52:36 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-05-22 00:52:44 --> Config Class Initialized
DEBUG - 2016-05-22 00:52:44 --> Hooks Class Initialized
DEBUG - 2016-05-22 00:52:44 --> Utf8 Class Initialized
DEBUG - 2016-05-22 00:52:44 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 00:52:44 --> URI Class Initialized
DEBUG - 2016-05-22 00:52:44 --> Router Class Initialized
DEBUG - 2016-05-22 00:52:44 --> Output Class Initialized
DEBUG - 2016-05-22 00:52:45 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 00:52:45 --> Security Class Initialized
DEBUG - 2016-05-22 00:52:45 --> Input Class Initialized
DEBUG - 2016-05-22 00:52:45 --> XSS Filtering completed
DEBUG - 2016-05-22 00:52:45 --> XSS Filtering completed
DEBUG - 2016-05-22 00:52:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 00:52:45 --> Language Class Initialized
DEBUG - 2016-05-22 00:52:45 --> Loader Class Initialized
DEBUG - 2016-05-22 00:52:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 00:52:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 00:52:45 --> Helper loaded: url_helper
DEBUG - 2016-05-22 00:52:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 00:52:45 --> Helper loaded: file_helper
DEBUG - 2016-05-22 00:52:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 00:52:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 00:52:45 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 00:52:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 00:52:45 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 00:52:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 00:52:45 --> Helper loaded: common_helper
DEBUG - 2016-05-22 00:52:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 00:52:45 --> Helper loaded: common_helper
DEBUG - 2016-05-22 00:52:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 00:52:45 --> Helper loaded: form_helper
DEBUG - 2016-05-22 00:52:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 00:52:45 --> Helper loaded: security_helper
DEBUG - 2016-05-22 00:52:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 00:52:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 00:52:45 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 00:52:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 00:52:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 00:52:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 00:52:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 00:52:45 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 00:52:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 00:52:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 00:52:45 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 00:52:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 00:52:45 --> Database Driver Class Initialized
DEBUG - 2016-05-22 00:52:45 --> Session Class Initialized
DEBUG - 2016-05-22 00:52:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 00:52:45 --> Helper loaded: string_helper
DEBUG - 2016-05-22 00:52:45 --> Session routines successfully run
DEBUG - 2016-05-22 00:52:45 --> Native_session Class Initialized
DEBUG - 2016-05-22 00:52:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 00:52:45 --> Form Validation Class Initialized
DEBUG - 2016-05-22 00:52:45 --> Form Validation Class Initialized
DEBUG - 2016-05-22 00:52:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 00:52:45 --> Controller Class Initialized
DEBUG - 2016-05-22 00:52:45 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 00:52:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 00:52:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 00:52:45 --> Carabiner: library configured.
DEBUG - 2016-05-22 00:52:45 --> Carabiner: library configured.
DEBUG - 2016-05-22 00:52:45 --> User Agent Class Initialized
DEBUG - 2016-05-22 00:52:45 --> Model Class Initialized
DEBUG - 2016-05-22 00:52:45 --> Model Class Initialized
DEBUG - 2016-05-22 00:52:45 --> Model Class Initialized
DEBUG - 2016-05-22 00:52:45 --> Model Class Initialized
DEBUG - 2016-05-22 00:52:45 --> Model Class Initialized
DEBUG - 2016-05-22 00:52:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-22 00:52:45 --> Pagination Class Initialized
DEBUG - 2016-05-22 00:52:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 00:52:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-05-22 00:52:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 00:52:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 00:52:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 00:52:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 00:52:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-05-22 00:52:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 00:52:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 00:52:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 00:52:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 00:52:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 00:52:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 00:52:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-05-22 00:52:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 00:52:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 00:52:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5cf2ac055215a66f98ba4d6c33c8329d
DEBUG - 2016-05-22 00:52:46 --> Final output sent to browser
DEBUG - 2016-05-22 00:52:46 --> Total execution time: 0.9669
DEBUG - 2016-05-22 00:53:03 --> Config Class Initialized
DEBUG - 2016-05-22 00:53:03 --> Hooks Class Initialized
DEBUG - 2016-05-22 00:53:03 --> Utf8 Class Initialized
DEBUG - 2016-05-22 00:53:03 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 00:53:03 --> URI Class Initialized
DEBUG - 2016-05-22 00:53:03 --> Router Class Initialized
DEBUG - 2016-05-22 00:53:03 --> Output Class Initialized
DEBUG - 2016-05-22 00:53:03 --> Security Class Initialized
DEBUG - 2016-05-22 00:53:03 --> Input Class Initialized
DEBUG - 2016-05-22 00:53:03 --> XSS Filtering completed
DEBUG - 2016-05-22 00:53:03 --> XSS Filtering completed
DEBUG - 2016-05-22 00:53:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 00:53:03 --> Language Class Initialized
DEBUG - 2016-05-22 00:53:03 --> Loader Class Initialized
DEBUG - 2016-05-22 00:53:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 00:53:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 00:53:03 --> Helper loaded: url_helper
DEBUG - 2016-05-22 00:53:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 00:53:03 --> Helper loaded: file_helper
DEBUG - 2016-05-22 00:53:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 00:53:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 00:53:03 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 00:53:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 00:53:04 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 00:53:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 00:53:04 --> Helper loaded: common_helper
DEBUG - 2016-05-22 00:53:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 00:53:04 --> Helper loaded: common_helper
DEBUG - 2016-05-22 00:53:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 00:53:04 --> Helper loaded: form_helper
DEBUG - 2016-05-22 00:53:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 00:53:04 --> Helper loaded: security_helper
DEBUG - 2016-05-22 00:53:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 00:53:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 00:53:04 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 00:53:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 00:53:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 00:53:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 00:53:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 00:53:04 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 00:53:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 00:53:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 00:53:04 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 00:53:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 00:53:04 --> Database Driver Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Session Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 00:53:04 --> Helper loaded: string_helper
DEBUG - 2016-05-22 00:53:04 --> Session routines successfully run
DEBUG - 2016-05-22 00:53:04 --> Native_session Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 00:53:04 --> Form Validation Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Form Validation Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 00:53:04 --> Controller Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 00:53:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 00:53:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 00:53:04 --> Carabiner: library configured.
DEBUG - 2016-05-22 00:53:04 --> Carabiner: library configured.
DEBUG - 2016-05-22 00:53:04 --> User Agent Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Model Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Model Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Model Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Model Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Model Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Config Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Hooks Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Utf8 Class Initialized
DEBUG - 2016-05-22 00:53:04 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 00:53:04 --> URI Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Router Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Output Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 00:53:04 --> Security Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Input Class Initialized
DEBUG - 2016-05-22 00:53:04 --> XSS Filtering completed
DEBUG - 2016-05-22 00:53:04 --> XSS Filtering completed
DEBUG - 2016-05-22 00:53:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 00:53:04 --> Language Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Loader Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 00:53:04 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 00:53:04 --> Helper loaded: url_helper
DEBUG - 2016-05-22 00:53:04 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 00:53:04 --> Helper loaded: file_helper
DEBUG - 2016-05-22 00:53:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 00:53:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 00:53:04 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 00:53:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 00:53:04 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 00:53:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 00:53:04 --> Helper loaded: common_helper
DEBUG - 2016-05-22 00:53:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 00:53:04 --> Helper loaded: common_helper
DEBUG - 2016-05-22 00:53:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 00:53:04 --> Helper loaded: form_helper
DEBUG - 2016-05-22 00:53:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 00:53:04 --> Helper loaded: security_helper
DEBUG - 2016-05-22 00:53:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 00:53:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 00:53:04 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 00:53:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 00:53:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 00:53:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 00:53:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 00:53:04 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 00:53:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 00:53:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 00:53:04 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 00:53:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 00:53:04 --> Database Driver Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Session Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 00:53:04 --> Helper loaded: string_helper
DEBUG - 2016-05-22 00:53:04 --> Session routines successfully run
DEBUG - 2016-05-22 00:53:04 --> Native_session Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 00:53:04 --> Form Validation Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Form Validation Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 00:53:04 --> Controller Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 00:53:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 00:53:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 00:53:04 --> Carabiner: library configured.
DEBUG - 2016-05-22 00:53:04 --> Carabiner: library configured.
DEBUG - 2016-05-22 00:53:04 --> User Agent Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Model Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Model Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Model Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Model Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Model Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Model Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Model Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Model Class Initialized
DEBUG - 2016-05-22 00:53:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-22 00:53:04 --> Pagination Class Initialized
DEBUG - 2016-05-22 00:53:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 00:53:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-05-22 00:53:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 00:53:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 00:53:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 00:53:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 00:53:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-22 00:53:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 00:53:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 00:53:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 00:53:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 00:53:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 00:53:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 00:53:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-22 00:53:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 00:53:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 00:53:04 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-05-22 00:53:04 --> Final output sent to browser
DEBUG - 2016-05-22 00:53:04 --> Total execution time: 0.3133
DEBUG - 2016-05-22 00:53:12 --> Config Class Initialized
DEBUG - 2016-05-22 00:53:12 --> Hooks Class Initialized
DEBUG - 2016-05-22 00:53:12 --> Utf8 Class Initialized
DEBUG - 2016-05-22 00:53:12 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 00:53:12 --> URI Class Initialized
DEBUG - 2016-05-22 00:53:12 --> Router Class Initialized
DEBUG - 2016-05-22 00:53:12 --> Output Class Initialized
DEBUG - 2016-05-22 00:53:12 --> Security Class Initialized
DEBUG - 2016-05-22 00:53:12 --> Input Class Initialized
DEBUG - 2016-05-22 00:53:12 --> XSS Filtering completed
DEBUG - 2016-05-22 00:53:12 --> XSS Filtering completed
DEBUG - 2016-05-22 00:53:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 00:53:12 --> Language Class Initialized
DEBUG - 2016-05-22 00:53:12 --> Loader Class Initialized
DEBUG - 2016-05-22 00:53:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 00:53:12 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 00:53:12 --> Helper loaded: url_helper
DEBUG - 2016-05-22 00:53:12 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 00:53:12 --> Helper loaded: file_helper
DEBUG - 2016-05-22 00:53:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 00:53:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 00:53:12 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 00:53:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 00:53:12 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 00:53:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 00:53:12 --> Helper loaded: common_helper
DEBUG - 2016-05-22 00:53:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 00:53:12 --> Helper loaded: common_helper
DEBUG - 2016-05-22 00:53:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 00:53:12 --> Helper loaded: form_helper
DEBUG - 2016-05-22 00:53:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 00:53:12 --> Helper loaded: security_helper
DEBUG - 2016-05-22 00:53:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 00:53:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 00:53:12 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 00:53:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 00:53:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 00:53:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 00:53:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 00:53:12 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 00:53:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 00:53:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 00:53:12 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 00:53:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 00:53:12 --> Database Driver Class Initialized
DEBUG - 2016-05-22 00:53:12 --> Session Class Initialized
DEBUG - 2016-05-22 00:53:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 00:53:12 --> Helper loaded: string_helper
DEBUG - 2016-05-22 00:53:12 --> Session routines successfully run
DEBUG - 2016-05-22 00:53:12 --> Native_session Class Initialized
DEBUG - 2016-05-22 00:53:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 00:53:12 --> Form Validation Class Initialized
DEBUG - 2016-05-22 00:53:12 --> Form Validation Class Initialized
DEBUG - 2016-05-22 00:53:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 00:53:12 --> Controller Class Initialized
DEBUG - 2016-05-22 00:53:12 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 00:53:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 00:53:12 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 00:53:12 --> Carabiner: library configured.
DEBUG - 2016-05-22 00:53:12 --> Carabiner: library configured.
DEBUG - 2016-05-22 00:53:12 --> User Agent Class Initialized
DEBUG - 2016-05-22 00:53:12 --> Model Class Initialized
DEBUG - 2016-05-22 00:53:12 --> Model Class Initialized
DEBUG - 2016-05-22 00:53:12 --> Model Class Initialized
DEBUG - 2016-05-22 00:53:12 --> Model Class Initialized
DEBUG - 2016-05-22 00:53:12 --> Model Class Initialized
DEBUG - 2016-05-22 00:53:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 00:53:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-22 00:53:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 00:53:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 00:53:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 00:53:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 00:53:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 00:53:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 00:53:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 00:53:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 00:53:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 00:53:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 00:53:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 00:53:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 00:53:13 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-05-22 00:53:13 --> Final output sent to browser
DEBUG - 2016-05-22 00:53:13 --> Total execution time: 0.4478
DEBUG - 2016-05-22 00:53:32 --> Config Class Initialized
DEBUG - 2016-05-22 00:53:32 --> Hooks Class Initialized
DEBUG - 2016-05-22 00:53:32 --> Utf8 Class Initialized
DEBUG - 2016-05-22 00:53:32 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 00:53:32 --> URI Class Initialized
DEBUG - 2016-05-22 00:53:32 --> Router Class Initialized
DEBUG - 2016-05-22 00:53:32 --> Output Class Initialized
DEBUG - 2016-05-22 00:53:32 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 00:53:32 --> Security Class Initialized
DEBUG - 2016-05-22 00:53:32 --> Input Class Initialized
DEBUG - 2016-05-22 00:53:32 --> XSS Filtering completed
DEBUG - 2016-05-22 00:53:32 --> XSS Filtering completed
DEBUG - 2016-05-22 00:53:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 00:53:32 --> Language Class Initialized
DEBUG - 2016-05-22 00:53:32 --> Loader Class Initialized
DEBUG - 2016-05-22 00:53:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 00:53:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 00:53:32 --> Helper loaded: url_helper
DEBUG - 2016-05-22 00:53:32 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 00:53:32 --> Helper loaded: file_helper
DEBUG - 2016-05-22 00:53:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 00:53:32 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 00:53:32 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 00:53:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 00:53:32 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 00:53:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 00:53:32 --> Helper loaded: common_helper
DEBUG - 2016-05-22 00:53:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 00:53:32 --> Helper loaded: common_helper
DEBUG - 2016-05-22 00:53:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 00:53:32 --> Helper loaded: form_helper
DEBUG - 2016-05-22 00:53:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 00:53:32 --> Helper loaded: security_helper
DEBUG - 2016-05-22 00:53:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 00:53:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 00:53:32 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 00:53:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 00:53:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 00:53:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 00:53:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 00:53:32 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 00:53:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 00:53:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 00:53:32 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 00:53:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 00:53:32 --> Database Driver Class Initialized
DEBUG - 2016-05-22 00:53:32 --> Session Class Initialized
DEBUG - 2016-05-22 00:53:32 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 00:53:32 --> Helper loaded: string_helper
DEBUG - 2016-05-22 00:53:32 --> Session routines successfully run
DEBUG - 2016-05-22 00:53:32 --> Native_session Class Initialized
DEBUG - 2016-05-22 00:53:32 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 00:53:32 --> Form Validation Class Initialized
DEBUG - 2016-05-22 00:53:32 --> Form Validation Class Initialized
DEBUG - 2016-05-22 00:53:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 00:53:32 --> Controller Class Initialized
DEBUG - 2016-05-22 00:53:32 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 00:53:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 00:53:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 00:53:32 --> Carabiner: library configured.
DEBUG - 2016-05-22 00:53:32 --> Carabiner: library configured.
DEBUG - 2016-05-22 00:53:32 --> User Agent Class Initialized
DEBUG - 2016-05-22 00:53:32 --> Model Class Initialized
DEBUG - 2016-05-22 00:53:32 --> Model Class Initialized
DEBUG - 2016-05-22 00:53:32 --> Model Class Initialized
DEBUG - 2016-05-22 00:53:32 --> Model Class Initialized
DEBUG - 2016-05-22 00:53:32 --> Model Class Initialized
ERROR - 2016-05-22 00:53:32 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-05-22 00:53:32 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-05-22 00:53:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 00:53:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-22 00:53:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 00:53:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 00:53:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 00:53:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 00:53:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 00:53:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 00:53:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 00:53:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 00:53:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 00:53:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 00:53:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 00:53:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 00:53:32 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-05-22 00:53:32 --> Final output sent to browser
DEBUG - 2016-05-22 00:53:32 --> Total execution time: 0.3803
DEBUG - 2016-05-22 00:56:46 --> Config Class Initialized
DEBUG - 2016-05-22 00:56:46 --> Hooks Class Initialized
DEBUG - 2016-05-22 00:56:46 --> Utf8 Class Initialized
DEBUG - 2016-05-22 00:56:46 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 00:56:46 --> URI Class Initialized
DEBUG - 2016-05-22 00:56:46 --> Router Class Initialized
DEBUG - 2016-05-22 00:56:47 --> Output Class Initialized
DEBUG - 2016-05-22 00:56:47 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 00:56:47 --> Security Class Initialized
DEBUG - 2016-05-22 00:56:47 --> Input Class Initialized
DEBUG - 2016-05-22 00:56:47 --> XSS Filtering completed
DEBUG - 2016-05-22 00:56:47 --> XSS Filtering completed
DEBUG - 2016-05-22 00:56:47 --> XSS Filtering completed
DEBUG - 2016-05-22 00:56:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 00:56:47 --> Language Class Initialized
DEBUG - 2016-05-22 00:56:47 --> Loader Class Initialized
DEBUG - 2016-05-22 00:56:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 00:56:47 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 00:56:47 --> Helper loaded: url_helper
DEBUG - 2016-05-22 00:56:47 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 00:56:47 --> Helper loaded: file_helper
DEBUG - 2016-05-22 00:56:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 00:56:47 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 00:56:47 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 00:56:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 00:56:47 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 00:56:47 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 00:56:48 --> Helper loaded: common_helper
DEBUG - 2016-05-22 00:56:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 00:56:48 --> Helper loaded: common_helper
DEBUG - 2016-05-22 00:56:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 00:56:48 --> Helper loaded: form_helper
DEBUG - 2016-05-22 00:56:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 00:56:48 --> Helper loaded: security_helper
DEBUG - 2016-05-22 00:56:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 00:56:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 00:56:48 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 00:56:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 00:56:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 00:56:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 00:56:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 00:56:48 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 00:56:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 00:56:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 00:56:48 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 00:56:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 00:56:49 --> Database Driver Class Initialized
DEBUG - 2016-05-22 00:56:49 --> Session Class Initialized
DEBUG - 2016-05-22 00:56:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 00:56:49 --> Helper loaded: string_helper
DEBUG - 2016-05-22 00:56:49 --> Session routines successfully run
DEBUG - 2016-05-22 00:56:49 --> Native_session Class Initialized
DEBUG - 2016-05-22 00:56:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 00:56:49 --> Form Validation Class Initialized
DEBUG - 2016-05-22 00:56:50 --> Form Validation Class Initialized
DEBUG - 2016-05-22 00:56:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 00:56:50 --> Controller Class Initialized
DEBUG - 2016-05-22 00:56:50 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 00:56:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 00:56:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 00:56:50 --> Carabiner: library configured.
DEBUG - 2016-05-22 00:56:50 --> Carabiner: library configured.
DEBUG - 2016-05-22 00:56:50 --> User Agent Class Initialized
DEBUG - 2016-05-22 00:56:50 --> Model Class Initialized
DEBUG - 2016-05-22 00:56:50 --> Model Class Initialized
DEBUG - 2016-05-22 00:56:50 --> Model Class Initialized
DEBUG - 2016-05-22 00:56:52 --> Model Class Initialized
DEBUG - 2016-05-22 00:56:53 --> Model Class Initialized
DEBUG - 2016-05-22 00:58:28 --> Config Class Initialized
DEBUG - 2016-05-22 00:58:28 --> Hooks Class Initialized
DEBUG - 2016-05-22 00:58:28 --> Utf8 Class Initialized
DEBUG - 2016-05-22 00:58:28 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 00:58:28 --> URI Class Initialized
DEBUG - 2016-05-22 00:58:29 --> Router Class Initialized
DEBUG - 2016-05-22 00:58:29 --> Output Class Initialized
DEBUG - 2016-05-22 00:58:29 --> Security Class Initialized
DEBUG - 2016-05-22 00:58:29 --> Input Class Initialized
DEBUG - 2016-05-22 00:58:29 --> XSS Filtering completed
DEBUG - 2016-05-22 00:58:29 --> XSS Filtering completed
DEBUG - 2016-05-22 00:58:29 --> XSS Filtering completed
DEBUG - 2016-05-22 00:58:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 00:58:29 --> Language Class Initialized
DEBUG - 2016-05-22 00:58:29 --> Loader Class Initialized
DEBUG - 2016-05-22 00:58:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 00:58:29 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 00:58:30 --> Helper loaded: url_helper
DEBUG - 2016-05-22 00:58:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 00:58:30 --> Helper loaded: file_helper
DEBUG - 2016-05-22 00:58:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 00:58:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 00:58:30 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 00:58:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 00:58:30 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 00:58:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 00:58:30 --> Helper loaded: common_helper
DEBUG - 2016-05-22 00:58:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 00:58:30 --> Helper loaded: common_helper
DEBUG - 2016-05-22 00:58:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 00:58:30 --> Helper loaded: form_helper
DEBUG - 2016-05-22 00:58:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 00:58:30 --> Helper loaded: security_helper
DEBUG - 2016-05-22 00:58:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 00:58:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 00:58:30 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 00:58:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 00:58:31 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 00:58:31 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 00:58:31 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 00:58:31 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 00:58:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 00:58:31 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 00:58:31 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 00:58:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 00:58:32 --> Database Driver Class Initialized
DEBUG - 2016-05-22 00:58:34 --> Session Class Initialized
DEBUG - 2016-05-22 00:58:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 00:58:34 --> Helper loaded: string_helper
DEBUG - 2016-05-22 00:58:34 --> Session routines successfully run
DEBUG - 2016-05-22 00:58:34 --> Native_session Class Initialized
DEBUG - 2016-05-22 00:58:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 00:58:35 --> Form Validation Class Initialized
DEBUG - 2016-05-22 00:58:35 --> Form Validation Class Initialized
DEBUG - 2016-05-22 00:58:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 00:58:35 --> Controller Class Initialized
DEBUG - 2016-05-22 00:58:35 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 00:58:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 00:58:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 00:58:35 --> Carabiner: library configured.
DEBUG - 2016-05-22 00:58:35 --> Carabiner: library configured.
DEBUG - 2016-05-22 00:58:35 --> User Agent Class Initialized
DEBUG - 2016-05-22 00:58:35 --> Model Class Initialized
DEBUG - 2016-05-22 00:58:35 --> Model Class Initialized
DEBUG - 2016-05-22 00:58:35 --> Model Class Initialized
DEBUG - 2016-05-22 00:58:37 --> Model Class Initialized
DEBUG - 2016-05-22 00:58:37 --> Model Class Initialized
DEBUG - 2016-05-22 02:58:11 --> Config Class Initialized
DEBUG - 2016-05-22 02:58:11 --> Hooks Class Initialized
DEBUG - 2016-05-22 02:58:12 --> Utf8 Class Initialized
DEBUG - 2016-05-22 02:58:12 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 02:58:12 --> URI Class Initialized
DEBUG - 2016-05-22 02:58:12 --> Router Class Initialized
DEBUG - 2016-05-22 02:58:12 --> Output Class Initialized
DEBUG - 2016-05-22 02:58:12 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 02:58:13 --> Security Class Initialized
DEBUG - 2016-05-22 02:58:13 --> Input Class Initialized
DEBUG - 2016-05-22 02:58:13 --> XSS Filtering completed
DEBUG - 2016-05-22 02:58:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 02:58:13 --> Language Class Initialized
DEBUG - 2016-05-22 02:58:14 --> Loader Class Initialized
DEBUG - 2016-05-22 02:58:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 02:58:14 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 02:58:14 --> Helper loaded: url_helper
DEBUG - 2016-05-22 02:58:14 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 02:58:14 --> Helper loaded: file_helper
DEBUG - 2016-05-22 02:58:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 02:58:14 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 02:58:14 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 02:58:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 02:58:14 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 02:58:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 02:58:15 --> Helper loaded: common_helper
DEBUG - 2016-05-22 02:58:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 02:58:15 --> Helper loaded: common_helper
DEBUG - 2016-05-22 02:58:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 02:58:15 --> Helper loaded: form_helper
DEBUG - 2016-05-22 02:58:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 02:58:15 --> Helper loaded: security_helper
DEBUG - 2016-05-22 02:58:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 02:58:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 02:58:15 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 02:58:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 02:58:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 02:58:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 02:58:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 02:58:15 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 02:58:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 02:58:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 02:58:15 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 02:58:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 02:58:16 --> Database Driver Class Initialized
DEBUG - 2016-05-22 02:58:16 --> Session Class Initialized
DEBUG - 2016-05-22 02:58:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 02:58:16 --> Helper loaded: string_helper
DEBUG - 2016-05-22 02:58:16 --> Session routines successfully run
DEBUG - 2016-05-22 02:58:16 --> Native_session Class Initialized
DEBUG - 2016-05-22 02:58:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 02:58:17 --> Form Validation Class Initialized
DEBUG - 2016-05-22 02:58:17 --> Form Validation Class Initialized
DEBUG - 2016-05-22 02:58:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 02:58:17 --> Controller Class Initialized
DEBUG - 2016-05-22 02:58:18 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 02:58:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 02:58:18 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 02:58:18 --> Carabiner: library configured.
DEBUG - 2016-05-22 02:58:18 --> Carabiner: library configured.
DEBUG - 2016-05-22 02:58:18 --> User Agent Class Initialized
DEBUG - 2016-05-22 02:58:19 --> Model Class Initialized
DEBUG - 2016-05-22 02:58:19 --> Model Class Initialized
DEBUG - 2016-05-22 02:58:19 --> Model Class Initialized
DEBUG - 2016-05-22 02:58:20 --> Model Class Initialized
DEBUG - 2016-05-22 02:58:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-22 02:58:21 --> Pagination Class Initialized
DEBUG - 2016-05-22 02:58:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 02:58:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/index.php
DEBUG - 2016-05-22 02:58:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 02:58:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 02:58:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 02:58:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 02:58:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-05-22 02:58:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 02:58:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 02:58:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 02:58:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 02:58:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 02:58:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 02:58:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-05-22 02:58:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 02:58:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 02:58:22 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0afc8ae14bdb2df5b4e2fbf4366db4fc
DEBUG - 2016-05-22 02:58:22 --> Final output sent to browser
DEBUG - 2016-05-22 02:58:22 --> Total execution time: 9.6717
DEBUG - 2016-05-22 02:59:01 --> Config Class Initialized
DEBUG - 2016-05-22 02:59:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 02:59:01 --> Utf8 Class Initialized
DEBUG - 2016-05-22 02:59:01 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 02:59:01 --> URI Class Initialized
DEBUG - 2016-05-22 02:59:01 --> Router Class Initialized
ERROR - 2016-05-22 02:59:02 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-05-22 02:59:06 --> Config Class Initialized
DEBUG - 2016-05-22 02:59:06 --> Hooks Class Initialized
DEBUG - 2016-05-22 02:59:06 --> Utf8 Class Initialized
DEBUG - 2016-05-22 02:59:06 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 02:59:06 --> URI Class Initialized
DEBUG - 2016-05-22 02:59:06 --> Router Class Initialized
DEBUG - 2016-05-22 02:59:06 --> Output Class Initialized
DEBUG - 2016-05-22 02:59:06 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 02:59:06 --> Security Class Initialized
DEBUG - 2016-05-22 02:59:06 --> Input Class Initialized
DEBUG - 2016-05-22 02:59:06 --> XSS Filtering completed
DEBUG - 2016-05-22 02:59:06 --> XSS Filtering completed
DEBUG - 2016-05-22 02:59:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 02:59:06 --> Language Class Initialized
DEBUG - 2016-05-22 02:59:06 --> Loader Class Initialized
DEBUG - 2016-05-22 02:59:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 02:59:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 02:59:06 --> Helper loaded: url_helper
DEBUG - 2016-05-22 02:59:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 02:59:06 --> Helper loaded: file_helper
DEBUG - 2016-05-22 02:59:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 02:59:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 02:59:06 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 02:59:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 02:59:06 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 02:59:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 02:59:06 --> Helper loaded: common_helper
DEBUG - 2016-05-22 02:59:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 02:59:06 --> Helper loaded: common_helper
DEBUG - 2016-05-22 02:59:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 02:59:06 --> Helper loaded: form_helper
DEBUG - 2016-05-22 02:59:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 02:59:06 --> Helper loaded: security_helper
DEBUG - 2016-05-22 02:59:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 02:59:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 02:59:06 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 02:59:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 02:59:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 02:59:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 02:59:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 02:59:06 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 02:59:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 02:59:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 02:59:06 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 02:59:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 02:59:06 --> Database Driver Class Initialized
DEBUG - 2016-05-22 02:59:07 --> Session Class Initialized
DEBUG - 2016-05-22 02:59:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 02:59:07 --> Helper loaded: string_helper
DEBUG - 2016-05-22 02:59:07 --> Session routines successfully run
DEBUG - 2016-05-22 02:59:07 --> Native_session Class Initialized
DEBUG - 2016-05-22 02:59:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 02:59:07 --> Form Validation Class Initialized
DEBUG - 2016-05-22 02:59:07 --> Form Validation Class Initialized
DEBUG - 2016-05-22 02:59:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 02:59:07 --> Controller Class Initialized
DEBUG - 2016-05-22 02:59:07 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 02:59:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 02:59:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 02:59:07 --> Carabiner: library configured.
DEBUG - 2016-05-22 02:59:07 --> Carabiner: library configured.
DEBUG - 2016-05-22 02:59:07 --> User Agent Class Initialized
DEBUG - 2016-05-22 02:59:07 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:07 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:07 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:07 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:07 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:08 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:08 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:08 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-22 02:59:10 --> Pagination Class Initialized
DEBUG - 2016-05-22 02:59:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 02:59:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-05-22 02:59:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 02:59:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 02:59:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 02:59:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 02:59:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-22 02:59:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 02:59:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 02:59:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 02:59:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 02:59:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 02:59:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 02:59:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-22 02:59:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 02:59:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 02:59:11 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-05-22 02:59:11 --> Final output sent to browser
DEBUG - 2016-05-22 02:59:11 --> Total execution time: 4.1993
DEBUG - 2016-05-22 02:59:25 --> Config Class Initialized
DEBUG - 2016-05-22 02:59:25 --> Hooks Class Initialized
DEBUG - 2016-05-22 02:59:25 --> Utf8 Class Initialized
DEBUG - 2016-05-22 02:59:25 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 02:59:25 --> URI Class Initialized
DEBUG - 2016-05-22 02:59:25 --> Router Class Initialized
ERROR - 2016-05-22 02:59:25 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-05-22 02:59:32 --> Config Class Initialized
DEBUG - 2016-05-22 02:59:34 --> Hooks Class Initialized
DEBUG - 2016-05-22 02:59:34 --> Utf8 Class Initialized
DEBUG - 2016-05-22 02:59:34 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 02:59:34 --> URI Class Initialized
DEBUG - 2016-05-22 02:59:34 --> Router Class Initialized
DEBUG - 2016-05-22 02:59:34 --> Output Class Initialized
DEBUG - 2016-05-22 02:59:34 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 02:59:34 --> Security Class Initialized
DEBUG - 2016-05-22 02:59:34 --> Input Class Initialized
DEBUG - 2016-05-22 02:59:34 --> XSS Filtering completed
DEBUG - 2016-05-22 02:59:34 --> XSS Filtering completed
DEBUG - 2016-05-22 02:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 02:59:35 --> Language Class Initialized
DEBUG - 2016-05-22 02:59:35 --> Loader Class Initialized
DEBUG - 2016-05-22 02:59:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 02:59:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 02:59:35 --> Helper loaded: url_helper
DEBUG - 2016-05-22 02:59:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 02:59:35 --> Helper loaded: file_helper
DEBUG - 2016-05-22 02:59:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 02:59:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 02:59:35 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 02:59:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 02:59:35 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 02:59:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 02:59:35 --> Helper loaded: common_helper
DEBUG - 2016-05-22 02:59:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 02:59:35 --> Helper loaded: common_helper
DEBUG - 2016-05-22 02:59:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 02:59:35 --> Helper loaded: form_helper
DEBUG - 2016-05-22 02:59:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 02:59:35 --> Helper loaded: security_helper
DEBUG - 2016-05-22 02:59:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 02:59:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 02:59:35 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 02:59:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 02:59:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 02:59:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 02:59:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 02:59:35 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 02:59:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 02:59:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 02:59:35 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 02:59:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 02:59:35 --> Database Driver Class Initialized
DEBUG - 2016-05-22 02:59:35 --> Session Class Initialized
DEBUG - 2016-05-22 02:59:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 02:59:35 --> Helper loaded: string_helper
DEBUG - 2016-05-22 02:59:35 --> Session routines successfully run
DEBUG - 2016-05-22 02:59:35 --> Native_session Class Initialized
DEBUG - 2016-05-22 02:59:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 02:59:35 --> Form Validation Class Initialized
DEBUG - 2016-05-22 02:59:35 --> Form Validation Class Initialized
DEBUG - 2016-05-22 02:59:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 02:59:35 --> Controller Class Initialized
DEBUG - 2016-05-22 02:59:35 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 02:59:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 02:59:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 02:59:35 --> Carabiner: library configured.
DEBUG - 2016-05-22 02:59:35 --> Carabiner: library configured.
DEBUG - 2016-05-22 02:59:35 --> User Agent Class Initialized
DEBUG - 2016-05-22 02:59:35 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:35 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:36 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:36 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:36 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-22 02:59:37 --> Pagination Class Initialized
DEBUG - 2016-05-22 02:59:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 02:59:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-05-22 02:59:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 02:59:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 02:59:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 02:59:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 02:59:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-05-22 02:59:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 02:59:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 02:59:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 02:59:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 02:59:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 02:59:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 02:59:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-05-22 02:59:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 02:59:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 02:59:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5cf2ac055215a66f98ba4d6c33c8329d
DEBUG - 2016-05-22 02:59:37 --> Final output sent to browser
DEBUG - 2016-05-22 02:59:37 --> Total execution time: 4.2178
DEBUG - 2016-05-22 02:59:50 --> Config Class Initialized
DEBUG - 2016-05-22 02:59:50 --> Hooks Class Initialized
DEBUG - 2016-05-22 02:59:50 --> Utf8 Class Initialized
DEBUG - 2016-05-22 02:59:50 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 02:59:50 --> URI Class Initialized
DEBUG - 2016-05-22 02:59:50 --> Router Class Initialized
DEBUG - 2016-05-22 02:59:50 --> Output Class Initialized
DEBUG - 2016-05-22 02:59:50 --> Security Class Initialized
DEBUG - 2016-05-22 02:59:50 --> Input Class Initialized
DEBUG - 2016-05-22 02:59:50 --> XSS Filtering completed
DEBUG - 2016-05-22 02:59:50 --> XSS Filtering completed
DEBUG - 2016-05-22 02:59:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 02:59:50 --> Language Class Initialized
DEBUG - 2016-05-22 02:59:50 --> Loader Class Initialized
DEBUG - 2016-05-22 02:59:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 02:59:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 02:59:50 --> Helper loaded: url_helper
DEBUG - 2016-05-22 02:59:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 02:59:50 --> Helper loaded: file_helper
DEBUG - 2016-05-22 02:59:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 02:59:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 02:59:51 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 02:59:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 02:59:51 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 02:59:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 02:59:51 --> Helper loaded: common_helper
DEBUG - 2016-05-22 02:59:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 02:59:51 --> Helper loaded: common_helper
DEBUG - 2016-05-22 02:59:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 02:59:51 --> Helper loaded: form_helper
DEBUG - 2016-05-22 02:59:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 02:59:51 --> Helper loaded: security_helper
DEBUG - 2016-05-22 02:59:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 02:59:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 02:59:51 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 02:59:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 02:59:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 02:59:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 02:59:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 02:59:51 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 02:59:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 02:59:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 02:59:51 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 02:59:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 02:59:51 --> Database Driver Class Initialized
DEBUG - 2016-05-22 02:59:51 --> Session Class Initialized
DEBUG - 2016-05-22 02:59:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 02:59:51 --> Helper loaded: string_helper
DEBUG - 2016-05-22 02:59:51 --> Session routines successfully run
DEBUG - 2016-05-22 02:59:51 --> Native_session Class Initialized
DEBUG - 2016-05-22 02:59:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 02:59:51 --> Form Validation Class Initialized
DEBUG - 2016-05-22 02:59:51 --> Form Validation Class Initialized
DEBUG - 2016-05-22 02:59:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 02:59:51 --> Controller Class Initialized
DEBUG - 2016-05-22 02:59:51 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 02:59:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 02:59:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 02:59:51 --> Carabiner: library configured.
DEBUG - 2016-05-22 02:59:51 --> Carabiner: library configured.
DEBUG - 2016-05-22 02:59:51 --> User Agent Class Initialized
DEBUG - 2016-05-22 02:59:51 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:51 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:51 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:51 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:51 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:51 --> Config Class Initialized
DEBUG - 2016-05-22 02:59:51 --> Hooks Class Initialized
DEBUG - 2016-05-22 02:59:51 --> Utf8 Class Initialized
DEBUG - 2016-05-22 02:59:51 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 02:59:51 --> URI Class Initialized
DEBUG - 2016-05-22 02:59:51 --> Router Class Initialized
DEBUG - 2016-05-22 02:59:51 --> Output Class Initialized
DEBUG - 2016-05-22 02:59:51 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 02:59:51 --> Security Class Initialized
DEBUG - 2016-05-22 02:59:51 --> Input Class Initialized
DEBUG - 2016-05-22 02:59:51 --> XSS Filtering completed
DEBUG - 2016-05-22 02:59:51 --> XSS Filtering completed
DEBUG - 2016-05-22 02:59:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 02:59:51 --> Language Class Initialized
DEBUG - 2016-05-22 02:59:51 --> Loader Class Initialized
DEBUG - 2016-05-22 02:59:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 02:59:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 02:59:51 --> Helper loaded: url_helper
DEBUG - 2016-05-22 02:59:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 02:59:51 --> Helper loaded: file_helper
DEBUG - 2016-05-22 02:59:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 02:59:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 02:59:51 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 02:59:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 02:59:51 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 02:59:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 02:59:51 --> Helper loaded: common_helper
DEBUG - 2016-05-22 02:59:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 02:59:51 --> Helper loaded: common_helper
DEBUG - 2016-05-22 02:59:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 02:59:51 --> Helper loaded: form_helper
DEBUG - 2016-05-22 02:59:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 02:59:51 --> Helper loaded: security_helper
DEBUG - 2016-05-22 02:59:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 02:59:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 02:59:51 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 02:59:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 02:59:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 02:59:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 02:59:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 02:59:51 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 02:59:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 02:59:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 02:59:51 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 02:59:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 02:59:51 --> Database Driver Class Initialized
DEBUG - 2016-05-22 02:59:52 --> Session Class Initialized
DEBUG - 2016-05-22 02:59:52 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 02:59:52 --> Helper loaded: string_helper
DEBUG - 2016-05-22 02:59:52 --> Session routines successfully run
DEBUG - 2016-05-22 02:59:52 --> Native_session Class Initialized
DEBUG - 2016-05-22 02:59:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 02:59:52 --> Form Validation Class Initialized
DEBUG - 2016-05-22 02:59:52 --> Form Validation Class Initialized
DEBUG - 2016-05-22 02:59:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 02:59:52 --> Controller Class Initialized
DEBUG - 2016-05-22 02:59:52 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 02:59:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 02:59:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 02:59:52 --> Carabiner: library configured.
DEBUG - 2016-05-22 02:59:52 --> Carabiner: library configured.
DEBUG - 2016-05-22 02:59:52 --> User Agent Class Initialized
DEBUG - 2016-05-22 02:59:52 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:52 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:52 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:52 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:52 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:52 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:52 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:52 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-22 02:59:52 --> Pagination Class Initialized
DEBUG - 2016-05-22 02:59:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 02:59:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-05-22 02:59:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 02:59:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 02:59:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 02:59:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 02:59:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-22 02:59:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 02:59:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 02:59:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 02:59:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 02:59:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 02:59:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 02:59:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-22 02:59:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 02:59:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 02:59:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-05-22 02:59:52 --> Final output sent to browser
DEBUG - 2016-05-22 02:59:52 --> Total execution time: 0.6845
DEBUG - 2016-05-22 02:59:54 --> Config Class Initialized
DEBUG - 2016-05-22 02:59:54 --> Hooks Class Initialized
DEBUG - 2016-05-22 02:59:54 --> Utf8 Class Initialized
DEBUG - 2016-05-22 02:59:54 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 02:59:54 --> URI Class Initialized
DEBUG - 2016-05-22 02:59:54 --> Router Class Initialized
DEBUG - 2016-05-22 02:59:54 --> Output Class Initialized
DEBUG - 2016-05-22 02:59:54 --> Security Class Initialized
DEBUG - 2016-05-22 02:59:54 --> Input Class Initialized
DEBUG - 2016-05-22 02:59:55 --> XSS Filtering completed
DEBUG - 2016-05-22 02:59:55 --> XSS Filtering completed
DEBUG - 2016-05-22 02:59:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 02:59:55 --> Language Class Initialized
DEBUG - 2016-05-22 02:59:55 --> Loader Class Initialized
DEBUG - 2016-05-22 02:59:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 02:59:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 02:59:55 --> Helper loaded: url_helper
DEBUG - 2016-05-22 02:59:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 02:59:55 --> Helper loaded: file_helper
DEBUG - 2016-05-22 02:59:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 02:59:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 02:59:55 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 02:59:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 02:59:55 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 02:59:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 02:59:55 --> Helper loaded: common_helper
DEBUG - 2016-05-22 02:59:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 02:59:55 --> Helper loaded: common_helper
DEBUG - 2016-05-22 02:59:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 02:59:55 --> Helper loaded: form_helper
DEBUG - 2016-05-22 02:59:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 02:59:55 --> Helper loaded: security_helper
DEBUG - 2016-05-22 02:59:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 02:59:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 02:59:55 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 02:59:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 02:59:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 02:59:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 02:59:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 02:59:55 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 02:59:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 02:59:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 02:59:55 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 02:59:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 02:59:55 --> Database Driver Class Initialized
DEBUG - 2016-05-22 02:59:55 --> Session Class Initialized
DEBUG - 2016-05-22 02:59:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 02:59:55 --> Helper loaded: string_helper
DEBUG - 2016-05-22 02:59:55 --> Session routines successfully run
DEBUG - 2016-05-22 02:59:55 --> Native_session Class Initialized
DEBUG - 2016-05-22 02:59:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 02:59:55 --> Form Validation Class Initialized
DEBUG - 2016-05-22 02:59:55 --> Form Validation Class Initialized
DEBUG - 2016-05-22 02:59:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 02:59:55 --> Controller Class Initialized
DEBUG - 2016-05-22 02:59:55 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 02:59:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 02:59:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 02:59:55 --> Carabiner: library configured.
DEBUG - 2016-05-22 02:59:55 --> Carabiner: library configured.
DEBUG - 2016-05-22 02:59:55 --> User Agent Class Initialized
DEBUG - 2016-05-22 02:59:55 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:55 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:55 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:55 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:55 --> Model Class Initialized
DEBUG - 2016-05-22 02:59:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 02:59:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-22 02:59:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 02:59:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 02:59:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 02:59:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 02:59:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 02:59:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 02:59:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 02:59:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 02:59:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 02:59:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 02:59:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 02:59:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 02:59:56 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-05-22 02:59:56 --> Final output sent to browser
DEBUG - 2016-05-22 02:59:56 --> Total execution time: 1.2781
DEBUG - 2016-05-22 03:00:09 --> Config Class Initialized
DEBUG - 2016-05-22 03:00:09 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:00:09 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:00:09 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:00:09 --> URI Class Initialized
DEBUG - 2016-05-22 03:00:09 --> Router Class Initialized
DEBUG - 2016-05-22 03:00:09 --> Output Class Initialized
DEBUG - 2016-05-22 03:00:10 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 03:00:10 --> Security Class Initialized
DEBUG - 2016-05-22 03:00:10 --> Input Class Initialized
DEBUG - 2016-05-22 03:00:10 --> XSS Filtering completed
DEBUG - 2016-05-22 03:00:10 --> XSS Filtering completed
DEBUG - 2016-05-22 03:00:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:00:10 --> Language Class Initialized
DEBUG - 2016-05-22 03:00:10 --> Loader Class Initialized
DEBUG - 2016-05-22 03:00:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:00:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:00:10 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:00:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:00:10 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:00:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:00:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:00:10 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:00:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:00:10 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:00:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:00:10 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:00:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:00:10 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:00:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:00:10 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:00:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:00:10 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:00:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:00:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:00:10 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:00:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:00:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:00:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:00:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:00:10 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:00:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:00:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:00:10 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:00:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:00:10 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:00:10 --> Session Class Initialized
DEBUG - 2016-05-22 03:00:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:00:10 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:00:10 --> Session routines successfully run
DEBUG - 2016-05-22 03:00:10 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:00:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:00:10 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:00:10 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:00:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:00:10 --> Controller Class Initialized
DEBUG - 2016-05-22 03:00:10 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:00:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:00:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:00:10 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:00:10 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:00:10 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:00:10 --> Model Class Initialized
DEBUG - 2016-05-22 03:00:10 --> Model Class Initialized
DEBUG - 2016-05-22 03:00:10 --> Model Class Initialized
DEBUG - 2016-05-22 03:00:10 --> Model Class Initialized
DEBUG - 2016-05-22 03:00:10 --> Model Class Initialized
ERROR - 2016-05-22 03:00:10 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-05-22 03:00:10 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-05-22 03:00:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 03:00:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-22 03:00:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 03:00:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 03:00:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 03:00:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 03:00:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 03:00:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 03:00:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 03:00:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 03:00:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 03:00:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 03:00:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 03:00:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 03:00:10 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-05-22 03:00:10 --> Final output sent to browser
DEBUG - 2016-05-22 03:00:10 --> Total execution time: 1.1285
DEBUG - 2016-05-22 03:01:01 --> Config Class Initialized
DEBUG - 2016-05-22 03:01:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:01:01 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:01:01 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:01:01 --> URI Class Initialized
DEBUG - 2016-05-22 03:01:01 --> Router Class Initialized
DEBUG - 2016-05-22 03:01:01 --> Output Class Initialized
DEBUG - 2016-05-22 03:01:01 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 03:01:01 --> Security Class Initialized
DEBUG - 2016-05-22 03:01:01 --> Input Class Initialized
DEBUG - 2016-05-22 03:01:01 --> XSS Filtering completed
DEBUG - 2016-05-22 03:01:01 --> XSS Filtering completed
DEBUG - 2016-05-22 03:01:01 --> XSS Filtering completed
DEBUG - 2016-05-22 03:01:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:01:01 --> Language Class Initialized
DEBUG - 2016-05-22 03:01:01 --> Loader Class Initialized
DEBUG - 2016-05-22 03:01:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:01:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:01:01 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:01:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:01:01 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:01:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:01:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:01:01 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:01:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:01:01 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:01:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:01:01 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:01:01 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:01:01 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:01:01 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:01:01 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:01:01 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:01:01 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:01:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:01:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:01:01 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:01:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:01:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:01:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:01:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:01:01 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:01:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:01:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:01:01 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:01:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:01:01 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:01:01 --> Session Class Initialized
DEBUG - 2016-05-22 03:01:01 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:01:01 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:01:01 --> Session routines successfully run
DEBUG - 2016-05-22 03:01:01 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:01:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:01:01 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:01:01 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:01:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:01:02 --> Controller Class Initialized
DEBUG - 2016-05-22 03:01:02 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:01:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:01:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:01:02 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:01:02 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:01:02 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:01:02 --> Model Class Initialized
DEBUG - 2016-05-22 03:01:02 --> Model Class Initialized
DEBUG - 2016-05-22 03:01:02 --> Model Class Initialized
DEBUG - 2016-05-22 03:01:02 --> Model Class Initialized
DEBUG - 2016-05-22 03:01:02 --> Model Class Initialized
DEBUG - 2016-05-22 03:01:55 --> Config Class Initialized
DEBUG - 2016-05-22 03:01:55 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:01:55 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:01:55 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:01:55 --> URI Class Initialized
DEBUG - 2016-05-22 03:01:55 --> Router Class Initialized
DEBUG - 2016-05-22 03:01:55 --> Output Class Initialized
DEBUG - 2016-05-22 03:01:56 --> Security Class Initialized
DEBUG - 2016-05-22 03:01:56 --> Input Class Initialized
DEBUG - 2016-05-22 03:01:56 --> XSS Filtering completed
DEBUG - 2016-05-22 03:01:56 --> XSS Filtering completed
DEBUG - 2016-05-22 03:01:56 --> XSS Filtering completed
DEBUG - 2016-05-22 03:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:01:56 --> Language Class Initialized
DEBUG - 2016-05-22 03:01:57 --> Loader Class Initialized
DEBUG - 2016-05-22 03:01:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:01:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:01:57 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:01:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:01:58 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:01:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:01:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:01:58 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:01:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:01:58 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:01:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:01:58 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:01:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:01:58 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:01:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:01:58 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:01:58 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:01:58 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:01:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:01:58 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:01:58 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:01:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:01:58 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:01:58 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:01:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:01:58 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:01:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:01:58 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:01:58 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:01:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:01:59 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:01:59 --> Session Class Initialized
DEBUG - 2016-05-22 03:01:59 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:01:59 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:01:59 --> Session routines successfully run
DEBUG - 2016-05-22 03:01:59 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:01:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:01:59 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:01:59 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:01:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:02:00 --> Controller Class Initialized
DEBUG - 2016-05-22 03:02:00 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:02:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:02:00 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:02:00 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:02:00 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:02:00 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:02:00 --> Model Class Initialized
DEBUG - 2016-05-22 03:02:00 --> Model Class Initialized
DEBUG - 2016-05-22 03:02:00 --> Model Class Initialized
DEBUG - 2016-05-22 03:02:01 --> Model Class Initialized
DEBUG - 2016-05-22 03:02:01 --> Model Class Initialized
DEBUG - 2016-05-22 03:03:17 --> Config Class Initialized
DEBUG - 2016-05-22 03:03:17 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:03:17 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:03:17 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:03:17 --> URI Class Initialized
DEBUG - 2016-05-22 03:03:17 --> Router Class Initialized
DEBUG - 2016-05-22 03:03:17 --> Output Class Initialized
DEBUG - 2016-05-22 03:03:17 --> Security Class Initialized
DEBUG - 2016-05-22 03:03:17 --> Input Class Initialized
DEBUG - 2016-05-22 03:03:17 --> XSS Filtering completed
DEBUG - 2016-05-22 03:03:17 --> XSS Filtering completed
DEBUG - 2016-05-22 03:03:17 --> XSS Filtering completed
DEBUG - 2016-05-22 03:03:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:03:17 --> Language Class Initialized
DEBUG - 2016-05-22 03:03:17 --> Loader Class Initialized
DEBUG - 2016-05-22 03:03:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:03:17 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:03:17 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:03:17 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:03:17 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:03:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:03:17 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:03:17 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:03:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:03:17 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:03:17 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:03:17 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:03:17 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:03:17 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:03:17 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:03:17 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:03:17 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:03:17 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:03:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:03:17 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:03:17 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:03:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:03:17 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:03:17 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:03:17 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:03:17 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:03:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:03:17 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:03:17 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:03:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:03:17 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:03:17 --> Session Class Initialized
DEBUG - 2016-05-22 03:03:17 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:03:17 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:03:17 --> Session routines successfully run
DEBUG - 2016-05-22 03:03:17 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:03:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:03:17 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:03:17 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:03:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:03:17 --> Controller Class Initialized
DEBUG - 2016-05-22 03:03:17 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:03:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:03:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:03:17 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:03:17 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:03:17 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:03:17 --> Model Class Initialized
DEBUG - 2016-05-22 03:03:17 --> Model Class Initialized
DEBUG - 2016-05-22 03:03:17 --> Model Class Initialized
DEBUG - 2016-05-22 03:03:17 --> Model Class Initialized
DEBUG - 2016-05-22 03:03:17 --> Model Class Initialized
DEBUG - 2016-05-22 03:03:51 --> Config Class Initialized
DEBUG - 2016-05-22 03:03:51 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:03:51 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:03:51 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:03:51 --> URI Class Initialized
DEBUG - 2016-05-22 03:03:51 --> Router Class Initialized
DEBUG - 2016-05-22 03:03:51 --> Output Class Initialized
DEBUG - 2016-05-22 03:03:51 --> Security Class Initialized
DEBUG - 2016-05-22 03:03:51 --> Input Class Initialized
DEBUG - 2016-05-22 03:03:51 --> XSS Filtering completed
DEBUG - 2016-05-22 03:03:51 --> XSS Filtering completed
DEBUG - 2016-05-22 03:03:51 --> XSS Filtering completed
DEBUG - 2016-05-22 03:03:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:03:51 --> Language Class Initialized
DEBUG - 2016-05-22 03:03:51 --> Loader Class Initialized
DEBUG - 2016-05-22 03:03:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:03:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:03:51 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:03:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:03:51 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:03:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:03:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:03:51 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:03:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:03:51 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:03:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:03:51 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:03:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:03:51 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:03:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:03:51 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:03:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:03:51 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:03:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:03:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:03:51 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:03:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:03:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:03:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:03:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:03:51 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:03:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:03:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:03:51 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:03:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:03:51 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:03:51 --> Session Class Initialized
DEBUG - 2016-05-22 03:03:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:03:51 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:03:51 --> Session routines successfully run
DEBUG - 2016-05-22 03:03:51 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:03:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:03:51 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:03:51 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:03:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:03:51 --> Controller Class Initialized
DEBUG - 2016-05-22 03:03:51 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:03:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:03:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:03:51 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:03:51 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:03:51 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:03:51 --> Model Class Initialized
DEBUG - 2016-05-22 03:03:51 --> Model Class Initialized
DEBUG - 2016-05-22 03:03:51 --> Model Class Initialized
DEBUG - 2016-05-22 03:03:51 --> Model Class Initialized
DEBUG - 2016-05-22 03:03:51 --> Model Class Initialized
DEBUG - 2016-05-22 03:04:06 --> Config Class Initialized
DEBUG - 2016-05-22 03:04:06 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:04:06 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:04:06 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:04:06 --> URI Class Initialized
DEBUG - 2016-05-22 03:04:06 --> Router Class Initialized
DEBUG - 2016-05-22 03:04:06 --> Output Class Initialized
DEBUG - 2016-05-22 03:04:06 --> Security Class Initialized
DEBUG - 2016-05-22 03:04:06 --> Input Class Initialized
DEBUG - 2016-05-22 03:04:06 --> XSS Filtering completed
DEBUG - 2016-05-22 03:04:06 --> XSS Filtering completed
DEBUG - 2016-05-22 03:04:06 --> XSS Filtering completed
DEBUG - 2016-05-22 03:04:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:04:06 --> Language Class Initialized
DEBUG - 2016-05-22 03:04:06 --> Loader Class Initialized
DEBUG - 2016-05-22 03:04:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:04:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:04:06 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:04:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:04:06 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:04:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:04:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:04:06 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:04:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:04:06 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:04:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:04:06 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:04:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:04:06 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:04:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:04:06 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:04:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:04:06 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:04:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:04:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:04:06 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:04:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:04:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:04:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:04:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:04:06 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:04:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:04:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:04:06 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:04:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:04:06 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:04:06 --> Session Class Initialized
DEBUG - 2016-05-22 03:04:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:04:06 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:04:06 --> Session routines successfully run
DEBUG - 2016-05-22 03:04:06 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:04:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:04:06 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:04:06 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:04:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:04:06 --> Controller Class Initialized
DEBUG - 2016-05-22 03:04:06 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:04:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:04:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:04:06 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:04:06 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:04:06 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:04:06 --> Model Class Initialized
DEBUG - 2016-05-22 03:04:06 --> Model Class Initialized
DEBUG - 2016-05-22 03:04:06 --> Model Class Initialized
DEBUG - 2016-05-22 03:04:06 --> Model Class Initialized
DEBUG - 2016-05-22 03:04:06 --> Model Class Initialized
DEBUG - 2016-05-22 03:04:53 --> Config Class Initialized
DEBUG - 2016-05-22 03:04:53 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:04:53 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:04:53 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:04:53 --> URI Class Initialized
DEBUG - 2016-05-22 03:04:53 --> Router Class Initialized
DEBUG - 2016-05-22 03:04:53 --> Output Class Initialized
DEBUG - 2016-05-22 03:04:53 --> Security Class Initialized
DEBUG - 2016-05-22 03:04:53 --> Input Class Initialized
DEBUG - 2016-05-22 03:04:53 --> XSS Filtering completed
DEBUG - 2016-05-22 03:04:53 --> XSS Filtering completed
DEBUG - 2016-05-22 03:04:53 --> XSS Filtering completed
DEBUG - 2016-05-22 03:04:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:04:53 --> Language Class Initialized
DEBUG - 2016-05-22 03:04:53 --> Loader Class Initialized
DEBUG - 2016-05-22 03:04:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:04:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:04:53 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:04:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:04:53 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:04:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:04:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:04:53 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:04:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:04:53 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:04:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:04:53 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:04:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:04:53 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:04:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:04:53 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:04:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:04:53 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:04:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:04:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:04:53 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:04:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:04:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:04:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:04:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:04:53 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:04:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:04:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:04:53 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:04:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:04:53 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:04:53 --> Session Class Initialized
DEBUG - 2016-05-22 03:04:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:04:53 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:04:53 --> Session routines successfully run
DEBUG - 2016-05-22 03:04:53 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:04:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:04:53 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:04:53 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:04:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:04:53 --> Controller Class Initialized
DEBUG - 2016-05-22 03:04:53 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:04:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:04:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:04:53 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:04:53 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:04:53 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:04:53 --> Model Class Initialized
DEBUG - 2016-05-22 03:04:53 --> Model Class Initialized
DEBUG - 2016-05-22 03:04:53 --> Model Class Initialized
DEBUG - 2016-05-22 03:04:53 --> Model Class Initialized
DEBUG - 2016-05-22 03:04:53 --> Model Class Initialized
ERROR - 2016-05-22 03:04:53 --> Severity: Notice  --> Undefined variable: _upload_path E:\www\GitHub\2016APSIDIKA\application\models\model_tr_peserta_diklat.php 191
DEBUG - 2016-05-22 03:05:06 --> Config Class Initialized
DEBUG - 2016-05-22 03:05:06 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:05:06 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:05:07 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:05:07 --> URI Class Initialized
DEBUG - 2016-05-22 03:05:07 --> Router Class Initialized
DEBUG - 2016-05-22 03:05:07 --> Output Class Initialized
DEBUG - 2016-05-22 03:05:07 --> Security Class Initialized
DEBUG - 2016-05-22 03:05:07 --> Input Class Initialized
DEBUG - 2016-05-22 03:05:07 --> XSS Filtering completed
DEBUG - 2016-05-22 03:05:07 --> XSS Filtering completed
DEBUG - 2016-05-22 03:05:07 --> XSS Filtering completed
DEBUG - 2016-05-22 03:05:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:05:07 --> Language Class Initialized
DEBUG - 2016-05-22 03:05:07 --> Loader Class Initialized
DEBUG - 2016-05-22 03:05:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:05:07 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:05:07 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:05:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:05:07 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:05:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:05:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:05:07 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:05:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:05:07 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:05:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:05:07 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:05:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:05:07 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:05:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:05:07 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:05:07 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:05:07 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:05:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:05:07 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:05:07 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:05:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:05:07 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:05:07 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:05:07 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:05:07 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:05:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:05:07 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:05:07 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:05:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:05:07 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:05:07 --> Session Class Initialized
DEBUG - 2016-05-22 03:05:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:05:07 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:05:07 --> Session routines successfully run
DEBUG - 2016-05-22 03:05:07 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:05:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:05:07 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:05:07 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:05:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:05:07 --> Controller Class Initialized
DEBUG - 2016-05-22 03:05:07 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:05:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:05:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:05:07 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:05:07 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:05:07 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:05:07 --> Model Class Initialized
DEBUG - 2016-05-22 03:05:07 --> Model Class Initialized
DEBUG - 2016-05-22 03:05:07 --> Model Class Initialized
DEBUG - 2016-05-22 03:05:07 --> Model Class Initialized
DEBUG - 2016-05-22 03:05:07 --> Model Class Initialized
ERROR - 2016-05-22 03:05:07 --> Severity: Warning  --> mkdir(): File exists E:\www\lwscodeigniterwrapper\helpers\LWS_common_helper.php 837
DEBUG - 2016-05-22 03:05:52 --> Config Class Initialized
DEBUG - 2016-05-22 03:05:52 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:05:52 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:05:52 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:05:52 --> URI Class Initialized
DEBUG - 2016-05-22 03:05:52 --> Router Class Initialized
DEBUG - 2016-05-22 03:05:52 --> Output Class Initialized
DEBUG - 2016-05-22 03:05:52 --> Security Class Initialized
DEBUG - 2016-05-22 03:05:52 --> Input Class Initialized
DEBUG - 2016-05-22 03:05:52 --> XSS Filtering completed
DEBUG - 2016-05-22 03:05:52 --> XSS Filtering completed
DEBUG - 2016-05-22 03:05:52 --> XSS Filtering completed
DEBUG - 2016-05-22 03:05:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:05:52 --> Language Class Initialized
DEBUG - 2016-05-22 03:05:52 --> Loader Class Initialized
DEBUG - 2016-05-22 03:05:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:05:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:05:52 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:05:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:05:52 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:05:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:05:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:05:52 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:05:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:05:52 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:05:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:05:52 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:05:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:05:52 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:05:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:05:52 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:05:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:05:52 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:05:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:05:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:05:52 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:05:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:05:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:05:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:05:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:05:52 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:05:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:05:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:05:52 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:05:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:05:52 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:05:53 --> Session Class Initialized
DEBUG - 2016-05-22 03:05:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:05:53 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:05:53 --> Session routines successfully run
DEBUG - 2016-05-22 03:05:53 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:05:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:05:53 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:05:53 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:05:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:05:53 --> Controller Class Initialized
DEBUG - 2016-05-22 03:05:53 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:05:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:05:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:05:53 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:05:53 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:05:53 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:05:53 --> Model Class Initialized
DEBUG - 2016-05-22 03:05:53 --> Model Class Initialized
DEBUG - 2016-05-22 03:05:53 --> Model Class Initialized
DEBUG - 2016-05-22 03:05:53 --> Model Class Initialized
DEBUG - 2016-05-22 03:05:53 --> Model Class Initialized
DEBUG - 2016-05-22 03:09:38 --> Config Class Initialized
DEBUG - 2016-05-22 03:09:38 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:09:38 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:09:38 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:09:38 --> URI Class Initialized
DEBUG - 2016-05-22 03:09:39 --> Router Class Initialized
DEBUG - 2016-05-22 03:09:39 --> Output Class Initialized
DEBUG - 2016-05-22 03:09:39 --> Security Class Initialized
DEBUG - 2016-05-22 03:09:39 --> Input Class Initialized
DEBUG - 2016-05-22 03:09:39 --> XSS Filtering completed
DEBUG - 2016-05-22 03:09:39 --> XSS Filtering completed
DEBUG - 2016-05-22 03:09:39 --> XSS Filtering completed
DEBUG - 2016-05-22 03:09:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:09:40 --> Language Class Initialized
DEBUG - 2016-05-22 03:09:40 --> Loader Class Initialized
DEBUG - 2016-05-22 03:09:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:09:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:09:41 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:09:41 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:09:41 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:09:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:09:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:09:41 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:09:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:09:41 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:09:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:09:41 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:09:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:09:41 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:09:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:09:41 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:09:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:09:41 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:09:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:09:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:09:41 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:09:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:09:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:09:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:09:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:09:41 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:09:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:09:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:09:42 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:09:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:09:45 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:09:46 --> Session Class Initialized
DEBUG - 2016-05-22 03:09:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:09:46 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:09:46 --> Session routines successfully run
DEBUG - 2016-05-22 03:09:46 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:09:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:09:46 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:09:46 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:09:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:09:47 --> Controller Class Initialized
DEBUG - 2016-05-22 03:09:47 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:09:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:09:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:09:47 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:09:47 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:09:47 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:09:47 --> Model Class Initialized
DEBUG - 2016-05-22 03:09:48 --> Model Class Initialized
DEBUG - 2016-05-22 03:09:48 --> Model Class Initialized
DEBUG - 2016-05-22 03:09:48 --> Model Class Initialized
DEBUG - 2016-05-22 03:09:48 --> Model Class Initialized
ERROR - 2016-05-22 03:09:50 --> Severity: Warning  --> mkdir(): File exists E:\www\lwscodeigniterwrapper\helpers\LWS_common_helper.php 854
DEBUG - 2016-05-22 03:11:09 --> Config Class Initialized
DEBUG - 2016-05-22 03:11:09 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:11:09 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:11:09 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:11:09 --> URI Class Initialized
DEBUG - 2016-05-22 03:11:09 --> Router Class Initialized
DEBUG - 2016-05-22 03:11:09 --> Output Class Initialized
DEBUG - 2016-05-22 03:11:09 --> Security Class Initialized
DEBUG - 2016-05-22 03:11:09 --> Input Class Initialized
DEBUG - 2016-05-22 03:11:09 --> XSS Filtering completed
DEBUG - 2016-05-22 03:11:09 --> XSS Filtering completed
DEBUG - 2016-05-22 03:11:09 --> XSS Filtering completed
DEBUG - 2016-05-22 03:11:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:11:09 --> Language Class Initialized
DEBUG - 2016-05-22 03:11:09 --> Loader Class Initialized
DEBUG - 2016-05-22 03:11:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:11:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:11:10 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:11:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:11:10 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:11:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:11:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:11:10 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:11:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:11:10 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:11:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:11:10 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:11:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:11:10 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:11:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:11:10 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:11:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:11:10 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:11:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:11:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:11:10 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:11:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:11:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:11:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:11:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:11:10 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:11:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:11:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:11:10 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:11:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:11:10 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:11:10 --> Session Class Initialized
DEBUG - 2016-05-22 03:11:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:11:10 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:11:10 --> Session routines successfully run
DEBUG - 2016-05-22 03:11:10 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:11:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:11:10 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:11:10 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:11:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:11:10 --> Controller Class Initialized
DEBUG - 2016-05-22 03:11:10 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:11:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:11:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:11:10 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:11:10 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:11:10 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:11:10 --> Model Class Initialized
DEBUG - 2016-05-22 03:11:10 --> Model Class Initialized
DEBUG - 2016-05-22 03:11:10 --> Model Class Initialized
DEBUG - 2016-05-22 03:11:10 --> Model Class Initialized
DEBUG - 2016-05-22 03:11:10 --> Model Class Initialized
ERROR - 2016-05-22 03:11:10 --> Severity: Warning  --> mkdir(): File exists E:\www\lwscodeigniterwrapper\helpers\LWS_common_helper.php 854
DEBUG - 2016-05-22 03:11:10 --> Upload Class Initialized
DEBUG - 2016-05-22 03:11:10 --> Upload Class Initialized
DEBUG - 2016-05-22 03:11:10 --> Class Library loaded: LWS_Upload on upload
DEBUG - 2016-05-22 03:11:10 --> Language file loaded: language/indonesia/upload_lang.php
ERROR - 2016-05-22 03:11:10 --> Path unggah tampaknya tidak sah.
ERROR - 2016-05-22 03:11:10 --> Path unggah tampaknya tidak sah.
DEBUG - 2016-05-22 03:11:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 03:11:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-22 03:11:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 03:11:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 03:11:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 03:11:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 03:11:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 03:11:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 03:11:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 03:11:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 03:11:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 03:11:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 03:11:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 03:11:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 03:11:11 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-05-22 03:11:11 --> Final output sent to browser
DEBUG - 2016-05-22 03:11:11 --> Total execution time: 0.9962
DEBUG - 2016-05-22 03:11:28 --> Config Class Initialized
DEBUG - 2016-05-22 03:11:28 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:11:28 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:11:28 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:11:28 --> URI Class Initialized
DEBUG - 2016-05-22 03:11:28 --> Router Class Initialized
DEBUG - 2016-05-22 03:11:28 --> Output Class Initialized
DEBUG - 2016-05-22 03:11:28 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 03:11:28 --> Security Class Initialized
DEBUG - 2016-05-22 03:11:28 --> Input Class Initialized
DEBUG - 2016-05-22 03:11:28 --> XSS Filtering completed
DEBUG - 2016-05-22 03:11:28 --> XSS Filtering completed
DEBUG - 2016-05-22 03:11:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:11:28 --> Language Class Initialized
DEBUG - 2016-05-22 03:11:28 --> Loader Class Initialized
DEBUG - 2016-05-22 03:11:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:11:28 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:11:28 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:11:28 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:11:28 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:11:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:11:28 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:11:28 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:11:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:11:28 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:11:28 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:11:28 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:11:28 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:11:28 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:11:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:11:28 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:11:28 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:11:28 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:11:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:11:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:11:28 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:11:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:11:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:11:28 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:11:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:11:28 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:11:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:11:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:11:28 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:11:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:11:28 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:11:28 --> Session Class Initialized
DEBUG - 2016-05-22 03:11:28 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:11:28 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:11:28 --> Session routines successfully run
DEBUG - 2016-05-22 03:11:28 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:11:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:11:28 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:11:28 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:11:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:11:28 --> Controller Class Initialized
DEBUG - 2016-05-22 03:11:28 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:11:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:11:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:11:28 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:11:28 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:11:28 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:11:28 --> Model Class Initialized
DEBUG - 2016-05-22 03:11:28 --> Model Class Initialized
DEBUG - 2016-05-22 03:11:28 --> Model Class Initialized
DEBUG - 2016-05-22 03:11:28 --> Model Class Initialized
DEBUG - 2016-05-22 03:11:29 --> Model Class Initialized
ERROR - 2016-05-22 03:11:29 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-05-22 03:11:29 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-05-22 03:11:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 03:11:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-22 03:11:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 03:11:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 03:11:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 03:11:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 03:11:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 03:11:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 03:11:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 03:11:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 03:11:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 03:11:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 03:11:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 03:11:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 03:11:29 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-05-22 03:11:29 --> Final output sent to browser
DEBUG - 2016-05-22 03:11:29 --> Total execution time: 0.8181
DEBUG - 2016-05-22 03:12:34 --> Config Class Initialized
DEBUG - 2016-05-22 03:12:34 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:12:34 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:12:34 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:12:34 --> URI Class Initialized
DEBUG - 2016-05-22 03:12:34 --> Router Class Initialized
DEBUG - 2016-05-22 03:12:34 --> Output Class Initialized
DEBUG - 2016-05-22 03:12:34 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 03:12:34 --> Security Class Initialized
DEBUG - 2016-05-22 03:12:34 --> Input Class Initialized
DEBUG - 2016-05-22 03:12:34 --> XSS Filtering completed
DEBUG - 2016-05-22 03:12:34 --> XSS Filtering completed
DEBUG - 2016-05-22 03:12:34 --> XSS Filtering completed
DEBUG - 2016-05-22 03:12:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:12:34 --> Language Class Initialized
DEBUG - 2016-05-22 03:12:34 --> Loader Class Initialized
DEBUG - 2016-05-22 03:12:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:12:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:12:34 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:12:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:12:34 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:12:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:12:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:12:34 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:12:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:12:34 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:12:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:12:34 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:12:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:12:34 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:12:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:12:34 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:12:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:12:34 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:12:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:12:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:12:34 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:12:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:12:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:12:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:12:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:12:34 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:12:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:12:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:12:34 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:12:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:12:34 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:12:34 --> Session Class Initialized
DEBUG - 2016-05-22 03:12:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:12:34 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:12:34 --> Session routines successfully run
DEBUG - 2016-05-22 03:12:34 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:12:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:12:34 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:12:34 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:12:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:12:34 --> Controller Class Initialized
DEBUG - 2016-05-22 03:12:34 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:12:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:12:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:12:34 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:12:34 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:12:34 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:12:35 --> Model Class Initialized
DEBUG - 2016-05-22 03:12:35 --> Model Class Initialized
DEBUG - 2016-05-22 03:12:35 --> Model Class Initialized
DEBUG - 2016-05-22 03:12:35 --> Model Class Initialized
DEBUG - 2016-05-22 03:12:35 --> Model Class Initialized
ERROR - 2016-05-22 03:12:35 --> Severity: Warning  --> mkdir(): File exists E:\www\lwscodeigniterwrapper\helpers\LWS_common_helper.php 854
DEBUG - 2016-05-22 03:13:10 --> Config Class Initialized
DEBUG - 2016-05-22 03:13:10 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:13:10 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:13:10 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:13:10 --> URI Class Initialized
DEBUG - 2016-05-22 03:13:10 --> Router Class Initialized
DEBUG - 2016-05-22 03:13:10 --> Output Class Initialized
DEBUG - 2016-05-22 03:13:10 --> Security Class Initialized
DEBUG - 2016-05-22 03:13:10 --> Input Class Initialized
DEBUG - 2016-05-22 03:13:10 --> XSS Filtering completed
DEBUG - 2016-05-22 03:13:10 --> XSS Filtering completed
DEBUG - 2016-05-22 03:13:10 --> XSS Filtering completed
DEBUG - 2016-05-22 03:13:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:13:10 --> Language Class Initialized
DEBUG - 2016-05-22 03:13:10 --> Loader Class Initialized
DEBUG - 2016-05-22 03:13:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:13:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:13:10 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:13:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:13:10 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:13:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:13:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:13:10 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:13:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:13:10 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:13:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:13:10 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:13:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:13:10 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:13:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:13:10 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:13:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:13:10 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:13:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:13:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:13:10 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:13:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:13:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:13:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:13:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:13:10 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:13:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:13:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:13:10 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:13:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:13:10 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:13:10 --> Session Class Initialized
DEBUG - 2016-05-22 03:13:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:13:10 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:13:10 --> Session routines successfully run
DEBUG - 2016-05-22 03:13:10 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:13:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:13:10 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:13:10 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:13:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:13:10 --> Controller Class Initialized
DEBUG - 2016-05-22 03:13:10 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:13:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:13:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:13:10 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:13:10 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:13:10 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:13:10 --> Model Class Initialized
DEBUG - 2016-05-22 03:13:10 --> Model Class Initialized
DEBUG - 2016-05-22 03:13:10 --> Model Class Initialized
DEBUG - 2016-05-22 03:13:10 --> Model Class Initialized
DEBUG - 2016-05-22 03:13:10 --> Model Class Initialized
ERROR - 2016-05-22 03:13:10 --> Severity: Warning  --> mkdir(): File exists E:\www\lwscodeigniterwrapper\helpers\LWS_common_helper.php 854
DEBUG - 2016-05-22 03:13:22 --> Config Class Initialized
DEBUG - 2016-05-22 03:13:22 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:13:22 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:13:22 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:13:22 --> URI Class Initialized
DEBUG - 2016-05-22 03:13:22 --> Router Class Initialized
DEBUG - 2016-05-22 03:13:22 --> Output Class Initialized
DEBUG - 2016-05-22 03:13:22 --> Security Class Initialized
DEBUG - 2016-05-22 03:13:22 --> Input Class Initialized
DEBUG - 2016-05-22 03:13:22 --> XSS Filtering completed
DEBUG - 2016-05-22 03:13:22 --> XSS Filtering completed
DEBUG - 2016-05-22 03:13:22 --> XSS Filtering completed
DEBUG - 2016-05-22 03:13:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:13:22 --> Language Class Initialized
DEBUG - 2016-05-22 03:13:22 --> Loader Class Initialized
DEBUG - 2016-05-22 03:13:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:13:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:13:22 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:13:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:13:22 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:13:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:13:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:13:22 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:13:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:13:22 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:13:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:13:22 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:13:22 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:13:22 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:13:22 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:13:22 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:13:22 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:13:22 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:13:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:13:22 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:13:22 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:13:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:13:22 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:13:22 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:13:22 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:13:22 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:13:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:13:22 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:13:22 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:13:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:13:22 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:13:22 --> Session Class Initialized
DEBUG - 2016-05-22 03:13:22 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:13:22 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:13:22 --> Session routines successfully run
DEBUG - 2016-05-22 03:13:22 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:13:22 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:13:22 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:13:22 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:13:22 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:13:22 --> Controller Class Initialized
DEBUG - 2016-05-22 03:13:22 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:13:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:13:23 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:13:23 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:13:23 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:13:23 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:13:23 --> Model Class Initialized
DEBUG - 2016-05-22 03:13:23 --> Model Class Initialized
DEBUG - 2016-05-22 03:13:23 --> Model Class Initialized
DEBUG - 2016-05-22 03:13:23 --> Model Class Initialized
DEBUG - 2016-05-22 03:13:23 --> Model Class Initialized
ERROR - 2016-05-22 03:13:23 --> Severity: Warning  --> mkdir(): File exists E:\www\lwscodeigniterwrapper\helpers\LWS_common_helper.php 854
DEBUG - 2016-05-22 03:13:34 --> Config Class Initialized
DEBUG - 2016-05-22 03:13:34 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:13:34 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:13:34 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:13:34 --> URI Class Initialized
DEBUG - 2016-05-22 03:13:34 --> Router Class Initialized
DEBUG - 2016-05-22 03:13:34 --> Output Class Initialized
DEBUG - 2016-05-22 03:13:34 --> Security Class Initialized
DEBUG - 2016-05-22 03:13:34 --> Input Class Initialized
DEBUG - 2016-05-22 03:13:34 --> XSS Filtering completed
DEBUG - 2016-05-22 03:13:34 --> XSS Filtering completed
DEBUG - 2016-05-22 03:13:34 --> XSS Filtering completed
DEBUG - 2016-05-22 03:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:13:34 --> Language Class Initialized
DEBUG - 2016-05-22 03:13:34 --> Loader Class Initialized
DEBUG - 2016-05-22 03:13:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:13:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:13:34 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:13:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:13:34 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:13:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:13:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:13:34 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:13:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:13:34 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:13:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:13:34 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:13:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:13:34 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:13:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:13:34 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:13:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:13:34 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:13:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:13:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:13:34 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:13:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:13:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:13:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:13:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:13:34 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:13:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:13:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:13:34 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:13:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:13:34 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:13:35 --> Session Class Initialized
DEBUG - 2016-05-22 03:13:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:13:35 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:13:35 --> Session routines successfully run
DEBUG - 2016-05-22 03:13:35 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:13:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:13:35 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:13:35 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:13:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:13:35 --> Controller Class Initialized
DEBUG - 2016-05-22 03:13:35 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:13:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:13:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:13:35 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:13:35 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:13:35 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:13:35 --> Model Class Initialized
DEBUG - 2016-05-22 03:13:35 --> Model Class Initialized
DEBUG - 2016-05-22 03:13:35 --> Model Class Initialized
DEBUG - 2016-05-22 03:13:35 --> Model Class Initialized
DEBUG - 2016-05-22 03:13:35 --> Model Class Initialized
ERROR - 2016-05-22 03:13:35 --> Severity: Warning  --> mkdir(): File exists E:\www\lwscodeigniterwrapper\helpers\LWS_common_helper.php 854
DEBUG - 2016-05-22 03:14:03 --> Config Class Initialized
DEBUG - 2016-05-22 03:14:03 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:14:03 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:14:03 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:14:03 --> URI Class Initialized
DEBUG - 2016-05-22 03:14:03 --> Router Class Initialized
DEBUG - 2016-05-22 03:14:03 --> Output Class Initialized
DEBUG - 2016-05-22 03:14:03 --> Security Class Initialized
DEBUG - 2016-05-22 03:14:03 --> Input Class Initialized
DEBUG - 2016-05-22 03:14:03 --> XSS Filtering completed
DEBUG - 2016-05-22 03:14:03 --> XSS Filtering completed
DEBUG - 2016-05-22 03:14:03 --> XSS Filtering completed
DEBUG - 2016-05-22 03:14:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:14:03 --> Language Class Initialized
DEBUG - 2016-05-22 03:14:03 --> Loader Class Initialized
DEBUG - 2016-05-22 03:14:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:14:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:14:03 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:14:04 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:14:04 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:14:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:14:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:14:04 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:14:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:14:04 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:14:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:14:04 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:14:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:14:04 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:14:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:14:04 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:14:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:14:04 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:14:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:14:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:14:04 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:14:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:14:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:14:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:14:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:14:04 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:14:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:14:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:14:04 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:14:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:14:04 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:14:04 --> Session Class Initialized
DEBUG - 2016-05-22 03:14:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:14:04 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:14:04 --> Session routines successfully run
DEBUG - 2016-05-22 03:14:04 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:14:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:14:04 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:14:04 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:14:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:14:04 --> Controller Class Initialized
DEBUG - 2016-05-22 03:14:04 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:14:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:14:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:14:04 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:14:04 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:14:04 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:14:04 --> Model Class Initialized
DEBUG - 2016-05-22 03:14:04 --> Model Class Initialized
DEBUG - 2016-05-22 03:14:04 --> Model Class Initialized
DEBUG - 2016-05-22 03:14:04 --> Model Class Initialized
DEBUG - 2016-05-22 03:14:04 --> Model Class Initialized
DEBUG - 2016-05-22 03:14:25 --> Config Class Initialized
DEBUG - 2016-05-22 03:14:25 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:14:25 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:14:25 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:14:25 --> URI Class Initialized
DEBUG - 2016-05-22 03:14:25 --> Router Class Initialized
DEBUG - 2016-05-22 03:14:25 --> Output Class Initialized
DEBUG - 2016-05-22 03:14:25 --> Security Class Initialized
DEBUG - 2016-05-22 03:14:25 --> Input Class Initialized
DEBUG - 2016-05-22 03:14:25 --> XSS Filtering completed
DEBUG - 2016-05-22 03:14:25 --> XSS Filtering completed
DEBUG - 2016-05-22 03:14:25 --> XSS Filtering completed
DEBUG - 2016-05-22 03:14:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:14:25 --> Language Class Initialized
DEBUG - 2016-05-22 03:14:25 --> Loader Class Initialized
DEBUG - 2016-05-22 03:14:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:14:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:14:25 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:14:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:14:25 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:14:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:14:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:14:25 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:14:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:14:25 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:14:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:14:25 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:14:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:14:25 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:14:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:14:25 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:14:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:14:25 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:14:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:14:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:14:25 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:14:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:14:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:14:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:14:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:14:26 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:14:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:14:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:14:26 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:14:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:14:26 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:14:26 --> Session Class Initialized
DEBUG - 2016-05-22 03:14:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:14:26 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:14:26 --> Session routines successfully run
DEBUG - 2016-05-22 03:14:26 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:14:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:14:26 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:14:26 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:14:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:14:26 --> Controller Class Initialized
DEBUG - 2016-05-22 03:14:26 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:14:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:14:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:14:26 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:14:26 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:14:26 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:14:26 --> Model Class Initialized
DEBUG - 2016-05-22 03:14:26 --> Model Class Initialized
DEBUG - 2016-05-22 03:14:26 --> Model Class Initialized
DEBUG - 2016-05-22 03:14:26 --> Model Class Initialized
DEBUG - 2016-05-22 03:14:26 --> Model Class Initialized
DEBUG - 2016-05-22 03:14:59 --> Config Class Initialized
DEBUG - 2016-05-22 03:14:59 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:14:59 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:14:59 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:14:59 --> URI Class Initialized
DEBUG - 2016-05-22 03:14:59 --> Router Class Initialized
DEBUG - 2016-05-22 03:14:59 --> Output Class Initialized
DEBUG - 2016-05-22 03:14:59 --> Security Class Initialized
DEBUG - 2016-05-22 03:14:59 --> Input Class Initialized
DEBUG - 2016-05-22 03:14:59 --> XSS Filtering completed
DEBUG - 2016-05-22 03:14:59 --> XSS Filtering completed
DEBUG - 2016-05-22 03:14:59 --> XSS Filtering completed
DEBUG - 2016-05-22 03:14:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:14:59 --> Language Class Initialized
DEBUG - 2016-05-22 03:14:59 --> Loader Class Initialized
DEBUG - 2016-05-22 03:14:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:14:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:14:59 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:14:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:14:59 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:14:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:14:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:14:59 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:14:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:14:59 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:14:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:14:59 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:14:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:14:59 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:14:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:14:59 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:14:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:15:00 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:15:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:15:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:15:00 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:15:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:15:00 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:15:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:15:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:15:00 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:15:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:15:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:15:00 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:15:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:15:00 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:15:00 --> Session Class Initialized
DEBUG - 2016-05-22 03:15:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:15:00 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:15:00 --> Session routines successfully run
DEBUG - 2016-05-22 03:15:00 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:15:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:15:00 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:15:00 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:15:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:15:00 --> Controller Class Initialized
DEBUG - 2016-05-22 03:15:00 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:15:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:15:00 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:15:00 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:15:00 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:15:00 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:15:00 --> Model Class Initialized
DEBUG - 2016-05-22 03:15:00 --> Model Class Initialized
DEBUG - 2016-05-22 03:15:00 --> Model Class Initialized
DEBUG - 2016-05-22 03:15:00 --> Model Class Initialized
DEBUG - 2016-05-22 03:15:00 --> Model Class Initialized
DEBUG - 2016-05-22 03:15:24 --> Config Class Initialized
DEBUG - 2016-05-22 03:15:24 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:15:24 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:15:24 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:15:24 --> URI Class Initialized
DEBUG - 2016-05-22 03:15:24 --> Router Class Initialized
DEBUG - 2016-05-22 03:15:24 --> Output Class Initialized
DEBUG - 2016-05-22 03:15:24 --> Security Class Initialized
DEBUG - 2016-05-22 03:15:24 --> Input Class Initialized
DEBUG - 2016-05-22 03:15:24 --> XSS Filtering completed
DEBUG - 2016-05-22 03:15:24 --> XSS Filtering completed
DEBUG - 2016-05-22 03:15:24 --> XSS Filtering completed
DEBUG - 2016-05-22 03:15:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:15:24 --> Language Class Initialized
DEBUG - 2016-05-22 03:15:24 --> Loader Class Initialized
DEBUG - 2016-05-22 03:15:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:15:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:15:24 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:15:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:15:24 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:15:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:15:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:15:24 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:15:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:15:24 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:15:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:15:24 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:15:24 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:15:24 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:15:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:15:24 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:15:24 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:15:24 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:15:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:15:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:15:24 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:15:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:15:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:15:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:15:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:15:24 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:15:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:15:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:15:24 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:15:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:15:24 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:15:24 --> Session Class Initialized
DEBUG - 2016-05-22 03:15:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:15:24 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:15:24 --> Session routines successfully run
DEBUG - 2016-05-22 03:15:24 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:15:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:15:24 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:15:24 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:15:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:15:24 --> Controller Class Initialized
DEBUG - 2016-05-22 03:15:24 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:15:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:15:24 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:15:24 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:15:24 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:15:24 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:15:24 --> Model Class Initialized
DEBUG - 2016-05-22 03:15:24 --> Model Class Initialized
DEBUG - 2016-05-22 03:15:24 --> Model Class Initialized
DEBUG - 2016-05-22 03:15:24 --> Model Class Initialized
DEBUG - 2016-05-22 03:15:24 --> Model Class Initialized
DEBUG - 2016-05-22 03:15:36 --> Config Class Initialized
DEBUG - 2016-05-22 03:15:36 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:15:36 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:15:36 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:15:36 --> URI Class Initialized
DEBUG - 2016-05-22 03:15:36 --> Router Class Initialized
DEBUG - 2016-05-22 03:15:36 --> Output Class Initialized
DEBUG - 2016-05-22 03:15:36 --> Security Class Initialized
DEBUG - 2016-05-22 03:15:36 --> Input Class Initialized
DEBUG - 2016-05-22 03:15:36 --> XSS Filtering completed
DEBUG - 2016-05-22 03:15:36 --> XSS Filtering completed
DEBUG - 2016-05-22 03:15:36 --> XSS Filtering completed
DEBUG - 2016-05-22 03:15:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:15:36 --> Language Class Initialized
DEBUG - 2016-05-22 03:15:36 --> Loader Class Initialized
DEBUG - 2016-05-22 03:15:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:15:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:15:36 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:15:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:15:36 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:15:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:15:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:15:37 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:15:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:15:37 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:15:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:15:37 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:15:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:15:37 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:15:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:15:37 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:15:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:15:37 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:15:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:15:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:15:37 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:15:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:15:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:15:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:15:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:15:37 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:15:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:15:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:15:37 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:15:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:15:37 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:15:37 --> Session Class Initialized
DEBUG - 2016-05-22 03:15:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:15:37 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:15:37 --> Session routines successfully run
DEBUG - 2016-05-22 03:15:37 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:15:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:15:37 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:15:37 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:15:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:15:37 --> Controller Class Initialized
DEBUG - 2016-05-22 03:15:37 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:15:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:15:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:15:37 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:15:37 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:15:37 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:15:37 --> Model Class Initialized
DEBUG - 2016-05-22 03:15:37 --> Model Class Initialized
DEBUG - 2016-05-22 03:15:37 --> Model Class Initialized
DEBUG - 2016-05-22 03:15:37 --> Model Class Initialized
DEBUG - 2016-05-22 03:15:37 --> Model Class Initialized
DEBUG - 2016-05-22 03:15:53 --> Config Class Initialized
DEBUG - 2016-05-22 03:15:53 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:15:53 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:15:53 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:15:53 --> URI Class Initialized
DEBUG - 2016-05-22 03:15:53 --> Router Class Initialized
DEBUG - 2016-05-22 03:15:53 --> Output Class Initialized
DEBUG - 2016-05-22 03:15:53 --> Security Class Initialized
DEBUG - 2016-05-22 03:15:53 --> Input Class Initialized
DEBUG - 2016-05-22 03:15:53 --> XSS Filtering completed
DEBUG - 2016-05-22 03:15:53 --> XSS Filtering completed
DEBUG - 2016-05-22 03:15:53 --> XSS Filtering completed
DEBUG - 2016-05-22 03:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:15:54 --> Language Class Initialized
DEBUG - 2016-05-22 03:15:54 --> Loader Class Initialized
DEBUG - 2016-05-22 03:15:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:15:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:15:54 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:15:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:15:54 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:15:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:15:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:15:54 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:15:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:15:54 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:15:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:15:54 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:15:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:15:54 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:15:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:15:54 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:15:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:15:54 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:15:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:15:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:15:54 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:15:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:15:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:15:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:15:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:15:54 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:15:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:15:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:15:54 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:15:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:15:54 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:15:54 --> Session Class Initialized
DEBUG - 2016-05-22 03:15:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:15:54 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:15:54 --> Session routines successfully run
DEBUG - 2016-05-22 03:15:54 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:15:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:15:54 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:15:54 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:15:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:15:54 --> Controller Class Initialized
DEBUG - 2016-05-22 03:15:54 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:15:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:15:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:15:54 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:15:54 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:15:54 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:15:54 --> Model Class Initialized
DEBUG - 2016-05-22 03:15:54 --> Model Class Initialized
DEBUG - 2016-05-22 03:15:54 --> Model Class Initialized
DEBUG - 2016-05-22 03:15:54 --> Model Class Initialized
DEBUG - 2016-05-22 03:15:54 --> Model Class Initialized
DEBUG - 2016-05-22 03:16:42 --> Config Class Initialized
DEBUG - 2016-05-22 03:16:42 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:16:42 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:16:42 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:16:42 --> URI Class Initialized
DEBUG - 2016-05-22 03:16:42 --> Router Class Initialized
DEBUG - 2016-05-22 03:16:42 --> Output Class Initialized
DEBUG - 2016-05-22 03:16:42 --> Security Class Initialized
DEBUG - 2016-05-22 03:16:42 --> Input Class Initialized
DEBUG - 2016-05-22 03:16:42 --> XSS Filtering completed
DEBUG - 2016-05-22 03:16:42 --> XSS Filtering completed
DEBUG - 2016-05-22 03:16:42 --> XSS Filtering completed
DEBUG - 2016-05-22 03:16:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:16:42 --> Language Class Initialized
DEBUG - 2016-05-22 03:16:42 --> Loader Class Initialized
DEBUG - 2016-05-22 03:16:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:16:42 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:16:42 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:16:42 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:16:42 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:16:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:16:42 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:16:42 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:16:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:16:42 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:16:42 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:16:42 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:16:42 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:16:42 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:16:42 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:16:42 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:16:42 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:16:42 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:16:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:16:42 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:16:42 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:16:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:16:42 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:16:42 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:16:42 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:16:42 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:16:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:16:42 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:16:42 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:16:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:16:42 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:16:43 --> Session Class Initialized
DEBUG - 2016-05-22 03:16:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:16:43 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:16:43 --> Session routines successfully run
DEBUG - 2016-05-22 03:16:43 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:16:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:16:43 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:16:43 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:16:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:16:43 --> Controller Class Initialized
DEBUG - 2016-05-22 03:16:43 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:16:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:16:43 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:16:43 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:16:43 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:16:43 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:16:43 --> Model Class Initialized
DEBUG - 2016-05-22 03:16:43 --> Model Class Initialized
DEBUG - 2016-05-22 03:16:43 --> Model Class Initialized
DEBUG - 2016-05-22 03:16:43 --> Model Class Initialized
DEBUG - 2016-05-22 03:16:43 --> Model Class Initialized
DEBUG - 2016-05-22 03:17:25 --> Config Class Initialized
DEBUG - 2016-05-22 03:17:25 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:17:25 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:17:25 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:17:25 --> URI Class Initialized
DEBUG - 2016-05-22 03:17:25 --> Router Class Initialized
DEBUG - 2016-05-22 03:17:25 --> Output Class Initialized
DEBUG - 2016-05-22 03:17:25 --> Security Class Initialized
DEBUG - 2016-05-22 03:17:25 --> Input Class Initialized
DEBUG - 2016-05-22 03:17:25 --> XSS Filtering completed
DEBUG - 2016-05-22 03:17:25 --> XSS Filtering completed
DEBUG - 2016-05-22 03:17:25 --> XSS Filtering completed
DEBUG - 2016-05-22 03:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:17:25 --> Language Class Initialized
DEBUG - 2016-05-22 03:17:25 --> Loader Class Initialized
DEBUG - 2016-05-22 03:17:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:17:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:17:25 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:17:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:17:25 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:17:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:17:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:17:25 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:17:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:17:26 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:17:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:17:26 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:17:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:17:26 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:17:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:17:26 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:17:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:17:26 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:17:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:17:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:17:26 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:17:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:17:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:17:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:17:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:17:26 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:17:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:17:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:17:26 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:17:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:17:26 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:17:26 --> Session Class Initialized
DEBUG - 2016-05-22 03:17:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:17:26 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:17:26 --> Session routines successfully run
DEBUG - 2016-05-22 03:17:26 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:17:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:17:26 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:17:26 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:17:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:17:26 --> Controller Class Initialized
DEBUG - 2016-05-22 03:17:26 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:17:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:17:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:17:26 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:17:26 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:17:26 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:17:26 --> Model Class Initialized
DEBUG - 2016-05-22 03:17:26 --> Model Class Initialized
DEBUG - 2016-05-22 03:17:26 --> Model Class Initialized
DEBUG - 2016-05-22 03:17:26 --> Model Class Initialized
DEBUG - 2016-05-22 03:17:26 --> Model Class Initialized
DEBUG - 2016-05-22 03:18:01 --> Config Class Initialized
DEBUG - 2016-05-22 03:18:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:18:01 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:18:02 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:18:02 --> URI Class Initialized
DEBUG - 2016-05-22 03:18:02 --> Router Class Initialized
DEBUG - 2016-05-22 03:18:02 --> Output Class Initialized
DEBUG - 2016-05-22 03:18:02 --> Security Class Initialized
DEBUG - 2016-05-22 03:18:02 --> Input Class Initialized
DEBUG - 2016-05-22 03:18:02 --> XSS Filtering completed
DEBUG - 2016-05-22 03:18:02 --> XSS Filtering completed
DEBUG - 2016-05-22 03:18:02 --> XSS Filtering completed
DEBUG - 2016-05-22 03:18:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:18:02 --> Language Class Initialized
DEBUG - 2016-05-22 03:18:02 --> Loader Class Initialized
DEBUG - 2016-05-22 03:18:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:18:02 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:18:02 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:18:02 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:18:02 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:18:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:18:02 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:18:02 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:18:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:18:02 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:18:02 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:18:02 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:18:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:18:02 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:18:02 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:18:02 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:18:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:18:02 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:18:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:18:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:18:02 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:18:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:18:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:18:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:18:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:18:02 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:18:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:18:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:18:02 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:18:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:18:02 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:18:02 --> Session Class Initialized
DEBUG - 2016-05-22 03:18:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:18:02 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:18:02 --> Session routines successfully run
DEBUG - 2016-05-22 03:18:02 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:18:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:18:02 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:18:02 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:18:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:18:02 --> Controller Class Initialized
DEBUG - 2016-05-22 03:18:02 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:18:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:18:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:18:02 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:18:02 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:18:02 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:18:02 --> Model Class Initialized
DEBUG - 2016-05-22 03:18:02 --> Model Class Initialized
DEBUG - 2016-05-22 03:18:02 --> Model Class Initialized
DEBUG - 2016-05-22 03:18:02 --> Model Class Initialized
DEBUG - 2016-05-22 03:18:02 --> Model Class Initialized
DEBUG - 2016-05-22 03:18:17 --> Config Class Initialized
DEBUG - 2016-05-22 03:18:17 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:18:17 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:18:17 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:18:17 --> URI Class Initialized
DEBUG - 2016-05-22 03:18:17 --> Router Class Initialized
DEBUG - 2016-05-22 03:18:17 --> Output Class Initialized
DEBUG - 2016-05-22 03:18:17 --> Security Class Initialized
DEBUG - 2016-05-22 03:18:17 --> Input Class Initialized
DEBUG - 2016-05-22 03:18:17 --> XSS Filtering completed
DEBUG - 2016-05-22 03:18:17 --> XSS Filtering completed
DEBUG - 2016-05-22 03:18:17 --> XSS Filtering completed
DEBUG - 2016-05-22 03:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:18:18 --> Language Class Initialized
DEBUG - 2016-05-22 03:18:18 --> Loader Class Initialized
DEBUG - 2016-05-22 03:18:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:18:18 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:18:18 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:18:18 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:18:18 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:18:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:18:18 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:18:18 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:18:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:18:18 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:18:18 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:18:18 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:18:18 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:18:18 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:18:18 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:18:18 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:18:18 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:18:18 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:18:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:18:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:18:18 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:18:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:18:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:18:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:18:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:18:18 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:18:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:18:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:18:18 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:18:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:18:18 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:18:18 --> Session Class Initialized
DEBUG - 2016-05-22 03:18:18 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:18:18 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:18:18 --> Session routines successfully run
DEBUG - 2016-05-22 03:18:18 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:18:18 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:18:18 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:18:18 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:18:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:18:18 --> Controller Class Initialized
DEBUG - 2016-05-22 03:18:18 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:18:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:18:18 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:18:18 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:18:18 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:18:18 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:18:18 --> Model Class Initialized
DEBUG - 2016-05-22 03:18:18 --> Model Class Initialized
DEBUG - 2016-05-22 03:18:18 --> Model Class Initialized
DEBUG - 2016-05-22 03:18:18 --> Model Class Initialized
DEBUG - 2016-05-22 03:18:18 --> Model Class Initialized
DEBUG - 2016-05-22 03:18:24 --> Config Class Initialized
DEBUG - 2016-05-22 03:18:24 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:18:24 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:18:24 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:18:24 --> URI Class Initialized
DEBUG - 2016-05-22 03:18:24 --> Router Class Initialized
DEBUG - 2016-05-22 03:18:24 --> Output Class Initialized
DEBUG - 2016-05-22 03:18:24 --> Security Class Initialized
DEBUG - 2016-05-22 03:18:24 --> Input Class Initialized
DEBUG - 2016-05-22 03:18:24 --> XSS Filtering completed
DEBUG - 2016-05-22 03:18:24 --> XSS Filtering completed
DEBUG - 2016-05-22 03:18:24 --> XSS Filtering completed
DEBUG - 2016-05-22 03:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:18:24 --> Language Class Initialized
DEBUG - 2016-05-22 03:18:24 --> Loader Class Initialized
DEBUG - 2016-05-22 03:18:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:18:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:18:24 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:18:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:18:24 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:18:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:18:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:18:24 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:18:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:18:24 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:18:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:18:24 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:18:24 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:18:24 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:18:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:18:25 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:18:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:18:25 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:18:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:18:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:18:25 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:18:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:18:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:18:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:18:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:18:25 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:18:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:18:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:18:25 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:18:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:18:25 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:18:25 --> Session Class Initialized
DEBUG - 2016-05-22 03:18:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:18:25 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:18:25 --> Session routines successfully run
DEBUG - 2016-05-22 03:18:25 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:18:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:18:25 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:18:25 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:18:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:18:25 --> Controller Class Initialized
DEBUG - 2016-05-22 03:18:25 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:18:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:18:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:18:25 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:18:25 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:18:25 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:18:25 --> Model Class Initialized
DEBUG - 2016-05-22 03:18:25 --> Model Class Initialized
DEBUG - 2016-05-22 03:18:25 --> Model Class Initialized
DEBUG - 2016-05-22 03:18:25 --> Model Class Initialized
DEBUG - 2016-05-22 03:18:25 --> Model Class Initialized
ERROR - 2016-05-22 03:18:25 --> Severity: Warning  --> mkdir(): File exists E:\www\lwscodeigniterwrapper\helpers\LWS_common_helper.php 854
DEBUG - 2016-05-22 03:19:29 --> Config Class Initialized
DEBUG - 2016-05-22 03:19:29 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:19:29 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:19:29 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:19:29 --> URI Class Initialized
DEBUG - 2016-05-22 03:19:29 --> Router Class Initialized
DEBUG - 2016-05-22 03:19:30 --> Output Class Initialized
DEBUG - 2016-05-22 03:19:30 --> Security Class Initialized
DEBUG - 2016-05-22 03:19:30 --> Input Class Initialized
DEBUG - 2016-05-22 03:19:30 --> XSS Filtering completed
DEBUG - 2016-05-22 03:19:30 --> XSS Filtering completed
DEBUG - 2016-05-22 03:19:30 --> XSS Filtering completed
DEBUG - 2016-05-22 03:19:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:19:30 --> Language Class Initialized
DEBUG - 2016-05-22 03:19:30 --> Loader Class Initialized
DEBUG - 2016-05-22 03:19:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:19:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:19:30 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:19:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:19:30 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:19:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:19:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:19:30 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:19:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:19:30 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:19:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:19:30 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:19:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:19:30 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:19:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:19:30 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:19:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:19:30 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:19:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:19:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:19:30 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:19:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:19:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:19:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:19:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:19:30 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:19:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:19:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:19:30 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:19:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:19:30 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:19:30 --> Session Class Initialized
DEBUG - 2016-05-22 03:19:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:19:30 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:19:30 --> Session routines successfully run
DEBUG - 2016-05-22 03:19:30 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:19:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:19:30 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:19:30 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:19:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:19:30 --> Controller Class Initialized
DEBUG - 2016-05-22 03:19:30 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:19:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:19:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:19:30 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:19:30 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:19:30 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:19:30 --> Model Class Initialized
DEBUG - 2016-05-22 03:19:30 --> Model Class Initialized
DEBUG - 2016-05-22 03:19:30 --> Model Class Initialized
DEBUG - 2016-05-22 03:19:30 --> Model Class Initialized
DEBUG - 2016-05-22 03:19:30 --> Model Class Initialized
ERROR - 2016-05-22 03:19:30 --> Severity: Warning  --> mkdir(): File exists E:\www\lwscodeigniterwrapper\helpers\LWS_common_helper.php 858
DEBUG - 2016-05-22 03:20:01 --> Config Class Initialized
DEBUG - 2016-05-22 03:20:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:20:01 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:20:01 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:20:01 --> URI Class Initialized
DEBUG - 2016-05-22 03:20:01 --> Router Class Initialized
DEBUG - 2016-05-22 03:20:01 --> Output Class Initialized
DEBUG - 2016-05-22 03:20:01 --> Security Class Initialized
DEBUG - 2016-05-22 03:20:01 --> Input Class Initialized
DEBUG - 2016-05-22 03:20:01 --> XSS Filtering completed
DEBUG - 2016-05-22 03:20:01 --> XSS Filtering completed
DEBUG - 2016-05-22 03:20:01 --> XSS Filtering completed
DEBUG - 2016-05-22 03:20:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:20:01 --> Language Class Initialized
DEBUG - 2016-05-22 03:20:01 --> Loader Class Initialized
DEBUG - 2016-05-22 03:20:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:20:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:20:01 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:20:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:20:01 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:20:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:20:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:20:01 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:20:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:20:01 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:20:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:20:01 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:20:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:20:02 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:20:02 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:20:02 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:20:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:20:02 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:20:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:20:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:20:02 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:20:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:20:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:20:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:20:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:20:02 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:20:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:20:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:20:02 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:20:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:20:02 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:20:02 --> Session Class Initialized
DEBUG - 2016-05-22 03:20:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:20:02 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:20:02 --> Session routines successfully run
DEBUG - 2016-05-22 03:20:02 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:20:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:20:02 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:20:02 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:20:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:20:02 --> Controller Class Initialized
DEBUG - 2016-05-22 03:20:02 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:20:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:20:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:20:02 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:20:02 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:20:02 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:20:02 --> Model Class Initialized
DEBUG - 2016-05-22 03:20:02 --> Model Class Initialized
DEBUG - 2016-05-22 03:20:02 --> Model Class Initialized
DEBUG - 2016-05-22 03:20:02 --> Model Class Initialized
DEBUG - 2016-05-22 03:20:02 --> Model Class Initialized
DEBUG - 2016-05-22 03:20:41 --> Config Class Initialized
DEBUG - 2016-05-22 03:20:41 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:20:41 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:20:41 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:20:41 --> URI Class Initialized
DEBUG - 2016-05-22 03:20:41 --> Router Class Initialized
DEBUG - 2016-05-22 03:20:41 --> Output Class Initialized
DEBUG - 2016-05-22 03:20:41 --> Security Class Initialized
DEBUG - 2016-05-22 03:20:41 --> Input Class Initialized
DEBUG - 2016-05-22 03:20:41 --> XSS Filtering completed
DEBUG - 2016-05-22 03:20:41 --> XSS Filtering completed
DEBUG - 2016-05-22 03:20:41 --> XSS Filtering completed
DEBUG - 2016-05-22 03:20:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:20:41 --> Language Class Initialized
DEBUG - 2016-05-22 03:20:41 --> Loader Class Initialized
DEBUG - 2016-05-22 03:20:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:20:41 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:20:41 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:20:41 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:20:41 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:20:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:20:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:20:41 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:20:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:20:41 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:20:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:20:41 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:20:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:20:41 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:20:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:20:41 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:20:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:20:41 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:20:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:20:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:20:41 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:20:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:20:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:20:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:20:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:20:41 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:20:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:20:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:20:41 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:20:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:20:41 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:20:41 --> Session Class Initialized
DEBUG - 2016-05-22 03:20:41 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:20:41 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:20:42 --> Session routines successfully run
DEBUG - 2016-05-22 03:20:42 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:20:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:20:42 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:20:42 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:20:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:20:42 --> Controller Class Initialized
DEBUG - 2016-05-22 03:20:42 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:20:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:20:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:20:42 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:20:42 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:20:42 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:20:42 --> Model Class Initialized
DEBUG - 2016-05-22 03:20:42 --> Model Class Initialized
DEBUG - 2016-05-22 03:20:42 --> Model Class Initialized
DEBUG - 2016-05-22 03:20:42 --> Model Class Initialized
DEBUG - 2016-05-22 03:20:42 --> Model Class Initialized
DEBUG - 2016-05-22 03:20:53 --> Config Class Initialized
DEBUG - 2016-05-22 03:20:54 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:20:54 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:20:54 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:20:54 --> URI Class Initialized
DEBUG - 2016-05-22 03:20:54 --> Router Class Initialized
DEBUG - 2016-05-22 03:20:54 --> Output Class Initialized
DEBUG - 2016-05-22 03:20:54 --> Security Class Initialized
DEBUG - 2016-05-22 03:20:54 --> Input Class Initialized
DEBUG - 2016-05-22 03:20:54 --> XSS Filtering completed
DEBUG - 2016-05-22 03:20:54 --> XSS Filtering completed
DEBUG - 2016-05-22 03:20:54 --> XSS Filtering completed
DEBUG - 2016-05-22 03:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:20:54 --> Language Class Initialized
DEBUG - 2016-05-22 03:20:54 --> Loader Class Initialized
DEBUG - 2016-05-22 03:20:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:20:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:20:54 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:20:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:20:54 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:20:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:20:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:20:54 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:20:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:20:54 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:20:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:20:54 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:20:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:20:54 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:20:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:20:54 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:20:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:20:54 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:20:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:20:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:20:54 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:20:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:20:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:20:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:20:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:20:54 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:20:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:20:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:20:54 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:20:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:20:54 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:20:54 --> Session Class Initialized
DEBUG - 2016-05-22 03:20:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:20:54 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:20:54 --> Session routines successfully run
DEBUG - 2016-05-22 03:20:54 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:20:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:20:54 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:20:54 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:20:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:20:54 --> Controller Class Initialized
DEBUG - 2016-05-22 03:20:54 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:20:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:20:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:20:54 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:20:54 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:20:54 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:20:54 --> Model Class Initialized
DEBUG - 2016-05-22 03:20:54 --> Model Class Initialized
DEBUG - 2016-05-22 03:20:54 --> Model Class Initialized
DEBUG - 2016-05-22 03:20:54 --> Model Class Initialized
DEBUG - 2016-05-22 03:20:54 --> Model Class Initialized
DEBUG - 2016-05-22 03:21:15 --> Config Class Initialized
DEBUG - 2016-05-22 03:21:15 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:21:15 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:21:15 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:21:15 --> URI Class Initialized
DEBUG - 2016-05-22 03:21:15 --> Router Class Initialized
DEBUG - 2016-05-22 03:21:15 --> Output Class Initialized
DEBUG - 2016-05-22 03:21:15 --> Security Class Initialized
DEBUG - 2016-05-22 03:21:15 --> Input Class Initialized
DEBUG - 2016-05-22 03:21:15 --> XSS Filtering completed
DEBUG - 2016-05-22 03:21:15 --> XSS Filtering completed
DEBUG - 2016-05-22 03:21:15 --> XSS Filtering completed
DEBUG - 2016-05-22 03:21:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:21:15 --> Language Class Initialized
DEBUG - 2016-05-22 03:21:15 --> Loader Class Initialized
DEBUG - 2016-05-22 03:21:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:21:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:21:15 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:21:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:21:15 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:21:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:21:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:21:15 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:21:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:21:15 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:21:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:21:15 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:21:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:21:15 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:21:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:21:15 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:21:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:21:16 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:21:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:21:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:21:16 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:21:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:21:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:21:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:21:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:21:16 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:21:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:21:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:21:16 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:21:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:21:16 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:21:16 --> Session Class Initialized
DEBUG - 2016-05-22 03:21:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:21:16 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:21:16 --> Session routines successfully run
DEBUG - 2016-05-22 03:21:16 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:21:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:21:16 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:21:16 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:21:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:21:16 --> Controller Class Initialized
DEBUG - 2016-05-22 03:21:16 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:21:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:21:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:21:16 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:21:16 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:21:16 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:21:16 --> Model Class Initialized
DEBUG - 2016-05-22 03:21:16 --> Model Class Initialized
DEBUG - 2016-05-22 03:21:16 --> Model Class Initialized
DEBUG - 2016-05-22 03:21:16 --> Model Class Initialized
DEBUG - 2016-05-22 03:21:16 --> Model Class Initialized
DEBUG - 2016-05-22 03:25:21 --> Config Class Initialized
DEBUG - 2016-05-22 03:25:21 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:25:21 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:25:21 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:25:21 --> URI Class Initialized
DEBUG - 2016-05-22 03:25:21 --> Router Class Initialized
DEBUG - 2016-05-22 03:25:21 --> Output Class Initialized
DEBUG - 2016-05-22 03:25:21 --> Security Class Initialized
DEBUG - 2016-05-22 03:25:21 --> Input Class Initialized
DEBUG - 2016-05-22 03:25:21 --> XSS Filtering completed
DEBUG - 2016-05-22 03:25:21 --> XSS Filtering completed
DEBUG - 2016-05-22 03:25:21 --> XSS Filtering completed
DEBUG - 2016-05-22 03:25:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:25:21 --> Language Class Initialized
DEBUG - 2016-05-22 03:25:21 --> Loader Class Initialized
DEBUG - 2016-05-22 03:25:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:25:21 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:25:21 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:25:21 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:25:21 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:25:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:25:21 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:25:21 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:25:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:25:21 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:25:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:25:21 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:25:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:25:21 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:25:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:25:21 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:25:21 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:25:21 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:25:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:25:21 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:25:21 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:25:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:25:21 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:25:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:25:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:25:21 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:25:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:25:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:25:21 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:25:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:25:21 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:25:21 --> Session Class Initialized
DEBUG - 2016-05-22 03:25:21 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:25:22 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:25:22 --> Session routines successfully run
DEBUG - 2016-05-22 03:25:22 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:25:22 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:25:22 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:25:22 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:25:22 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:25:22 --> Controller Class Initialized
DEBUG - 2016-05-22 03:25:22 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:25:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:25:22 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:25:22 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:25:22 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:25:22 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:25:22 --> Model Class Initialized
DEBUG - 2016-05-22 03:25:22 --> Model Class Initialized
DEBUG - 2016-05-22 03:25:22 --> Model Class Initialized
DEBUG - 2016-05-22 03:25:22 --> Model Class Initialized
DEBUG - 2016-05-22 03:25:22 --> Model Class Initialized
DEBUG - 2016-05-22 03:26:41 --> Config Class Initialized
DEBUG - 2016-05-22 03:26:41 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:26:41 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:26:41 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:26:41 --> URI Class Initialized
DEBUG - 2016-05-22 03:26:41 --> Router Class Initialized
DEBUG - 2016-05-22 03:26:41 --> Output Class Initialized
DEBUG - 2016-05-22 03:26:41 --> Security Class Initialized
DEBUG - 2016-05-22 03:26:41 --> Input Class Initialized
DEBUG - 2016-05-22 03:26:41 --> XSS Filtering completed
DEBUG - 2016-05-22 03:26:41 --> XSS Filtering completed
DEBUG - 2016-05-22 03:26:41 --> XSS Filtering completed
DEBUG - 2016-05-22 03:26:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:26:41 --> Language Class Initialized
DEBUG - 2016-05-22 03:26:41 --> Loader Class Initialized
DEBUG - 2016-05-22 03:26:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:26:41 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:26:41 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:26:41 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:26:41 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:26:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:26:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:26:41 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:26:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:26:41 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:26:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:26:41 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:26:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:26:41 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:26:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:26:41 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:26:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:26:41 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:26:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:26:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:26:41 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:26:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:26:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:26:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:26:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:26:41 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:26:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:26:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:26:41 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:26:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:26:41 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:26:41 --> Session Class Initialized
DEBUG - 2016-05-22 03:26:41 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:26:41 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:26:41 --> Session routines successfully run
DEBUG - 2016-05-22 03:26:41 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:26:41 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:26:41 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:26:41 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:26:41 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:26:41 --> Controller Class Initialized
DEBUG - 2016-05-22 03:26:41 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:26:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:26:41 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:26:41 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:26:41 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:26:41 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:26:41 --> Model Class Initialized
DEBUG - 2016-05-22 03:26:41 --> Model Class Initialized
DEBUG - 2016-05-22 03:26:41 --> Model Class Initialized
DEBUG - 2016-05-22 03:26:41 --> Model Class Initialized
DEBUG - 2016-05-22 03:26:42 --> Model Class Initialized
DEBUG - 2016-05-22 03:27:45 --> Config Class Initialized
DEBUG - 2016-05-22 03:27:45 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:27:45 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:27:45 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:27:45 --> URI Class Initialized
DEBUG - 2016-05-22 03:27:45 --> Router Class Initialized
DEBUG - 2016-05-22 03:27:45 --> Output Class Initialized
DEBUG - 2016-05-22 03:27:45 --> Security Class Initialized
DEBUG - 2016-05-22 03:27:45 --> Input Class Initialized
DEBUG - 2016-05-22 03:27:45 --> XSS Filtering completed
DEBUG - 2016-05-22 03:27:45 --> XSS Filtering completed
DEBUG - 2016-05-22 03:27:45 --> XSS Filtering completed
DEBUG - 2016-05-22 03:27:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:27:45 --> Language Class Initialized
DEBUG - 2016-05-22 03:27:46 --> Loader Class Initialized
DEBUG - 2016-05-22 03:27:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:27:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:27:46 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:27:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:27:46 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:27:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:27:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:27:46 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:27:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:27:46 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:27:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:27:46 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:27:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:27:46 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:27:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:27:46 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:27:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:27:46 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:27:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:27:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:27:46 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:27:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:27:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:27:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:27:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:27:46 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:27:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:27:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:27:46 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:27:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:27:46 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:27:46 --> Session Class Initialized
DEBUG - 2016-05-22 03:27:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:27:46 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:27:46 --> Session routines successfully run
DEBUG - 2016-05-22 03:27:46 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:27:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:27:46 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:27:46 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:27:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:27:46 --> Controller Class Initialized
DEBUG - 2016-05-22 03:27:46 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:27:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:27:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:27:46 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:27:46 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:27:46 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:27:46 --> Model Class Initialized
DEBUG - 2016-05-22 03:27:46 --> Model Class Initialized
DEBUG - 2016-05-22 03:27:46 --> Model Class Initialized
DEBUG - 2016-05-22 03:27:46 --> Model Class Initialized
DEBUG - 2016-05-22 03:27:46 --> Model Class Initialized
DEBUG - 2016-05-22 03:30:14 --> Config Class Initialized
DEBUG - 2016-05-22 03:30:14 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:30:14 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:30:14 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:30:14 --> URI Class Initialized
DEBUG - 2016-05-22 03:30:14 --> Router Class Initialized
DEBUG - 2016-05-22 03:30:14 --> Output Class Initialized
DEBUG - 2016-05-22 03:30:14 --> Security Class Initialized
DEBUG - 2016-05-22 03:30:14 --> Input Class Initialized
DEBUG - 2016-05-22 03:30:14 --> XSS Filtering completed
DEBUG - 2016-05-22 03:30:14 --> XSS Filtering completed
DEBUG - 2016-05-22 03:30:14 --> XSS Filtering completed
DEBUG - 2016-05-22 03:30:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:30:14 --> Language Class Initialized
DEBUG - 2016-05-22 03:30:14 --> Loader Class Initialized
DEBUG - 2016-05-22 03:30:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:30:14 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:30:14 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:30:14 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:30:14 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:30:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:30:14 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:30:14 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:30:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:30:14 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:30:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:30:14 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:30:14 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:30:14 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:30:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:30:14 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:30:14 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:30:14 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:30:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:30:14 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:30:14 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:30:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:30:14 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:30:14 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:30:14 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:30:14 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:30:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:30:14 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:30:14 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:30:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:30:15 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:30:15 --> Session Class Initialized
DEBUG - 2016-05-22 03:30:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:30:15 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:30:15 --> Session routines successfully run
DEBUG - 2016-05-22 03:30:15 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:30:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:30:15 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:30:15 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:30:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:30:15 --> Controller Class Initialized
DEBUG - 2016-05-22 03:30:15 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:30:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:30:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:30:15 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:30:15 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:30:15 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:30:15 --> Model Class Initialized
DEBUG - 2016-05-22 03:30:15 --> Model Class Initialized
DEBUG - 2016-05-22 03:30:15 --> Model Class Initialized
DEBUG - 2016-05-22 03:30:15 --> Model Class Initialized
DEBUG - 2016-05-22 03:30:15 --> Model Class Initialized
ERROR - 2016-05-22 03:30:15 --> Severity: Notice  --> Undefined variable: root_path E:\www\lwscodeigniterwrapper\helpers\LWS_common_helper.php 857
DEBUG - 2016-05-22 03:30:15 --> Upload Class Initialized
DEBUG - 2016-05-22 03:30:15 --> Upload Class Initialized
DEBUG - 2016-05-22 03:30:15 --> Class Library loaded: LWS_Upload on upload
DEBUG - 2016-05-22 03:30:15 --> Language file loaded: language/indonesia/upload_lang.php
ERROR - 2016-05-22 03:30:15 --> Path unggah tampaknya tidak sah.
ERROR - 2016-05-22 03:30:15 --> Path unggah tampaknya tidak sah.
DEBUG - 2016-05-22 03:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 03:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-22 03:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 03:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 03:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 03:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 03:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 03:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 03:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 03:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 03:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 03:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 03:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 03:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 03:30:16 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-05-22 03:30:16 --> Final output sent to browser
DEBUG - 2016-05-22 03:30:16 --> Total execution time: 1.2175
DEBUG - 2016-05-22 03:30:51 --> Config Class Initialized
DEBUG - 2016-05-22 03:30:51 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:30:51 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:30:51 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:30:51 --> URI Class Initialized
DEBUG - 2016-05-22 03:30:51 --> Router Class Initialized
DEBUG - 2016-05-22 03:30:51 --> Output Class Initialized
DEBUG - 2016-05-22 03:30:51 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 03:30:51 --> Security Class Initialized
DEBUG - 2016-05-22 03:30:51 --> Input Class Initialized
DEBUG - 2016-05-22 03:30:51 --> XSS Filtering completed
DEBUG - 2016-05-22 03:30:51 --> XSS Filtering completed
DEBUG - 2016-05-22 03:30:51 --> XSS Filtering completed
DEBUG - 2016-05-22 03:30:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:30:51 --> Language Class Initialized
DEBUG - 2016-05-22 03:30:51 --> Loader Class Initialized
DEBUG - 2016-05-22 03:30:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:30:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:30:51 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:30:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:30:51 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:30:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:30:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:30:51 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:30:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:30:51 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:30:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:30:51 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:30:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:30:51 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:30:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:30:51 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:30:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:30:51 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:30:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:30:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:30:51 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:30:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:30:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:30:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:30:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:30:52 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:30:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:30:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:30:52 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:30:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:30:52 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:30:52 --> Session Class Initialized
DEBUG - 2016-05-22 03:30:52 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:30:52 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:30:52 --> Session routines successfully run
DEBUG - 2016-05-22 03:30:52 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:30:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:30:52 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:30:52 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:30:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:30:52 --> Controller Class Initialized
DEBUG - 2016-05-22 03:30:52 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:30:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:30:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:30:52 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:30:52 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:30:52 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:30:52 --> Model Class Initialized
DEBUG - 2016-05-22 03:30:52 --> Model Class Initialized
DEBUG - 2016-05-22 03:30:52 --> Model Class Initialized
DEBUG - 2016-05-22 03:30:52 --> Model Class Initialized
DEBUG - 2016-05-22 03:30:52 --> Model Class Initialized
DEBUG - 2016-05-22 03:30:52 --> Upload Class Initialized
DEBUG - 2016-05-22 03:30:52 --> Upload Class Initialized
DEBUG - 2016-05-22 03:30:52 --> Class Library loaded: LWS_Upload on upload
DEBUG - 2016-05-22 03:30:52 --> Language file loaded: language/indonesia/upload_lang.php
ERROR - 2016-05-22 03:30:52 --> Path unggah tampaknya tidak sah.
ERROR - 2016-05-22 03:30:52 --> Path unggah tampaknya tidak sah.
DEBUG - 2016-05-22 03:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 03:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-22 03:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 03:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 03:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 03:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 03:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 03:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 03:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 03:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 03:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 03:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 03:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 03:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 03:30:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-05-22 03:30:52 --> Final output sent to browser
DEBUG - 2016-05-22 03:30:52 --> Total execution time: 1.1437
DEBUG - 2016-05-22 03:31:04 --> Config Class Initialized
DEBUG - 2016-05-22 03:31:04 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:31:04 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:31:04 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:31:05 --> URI Class Initialized
DEBUG - 2016-05-22 03:31:05 --> Router Class Initialized
DEBUG - 2016-05-22 03:31:05 --> Output Class Initialized
DEBUG - 2016-05-22 03:31:05 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 03:31:05 --> Security Class Initialized
DEBUG - 2016-05-22 03:31:05 --> Input Class Initialized
DEBUG - 2016-05-22 03:31:05 --> XSS Filtering completed
DEBUG - 2016-05-22 03:31:05 --> XSS Filtering completed
DEBUG - 2016-05-22 03:31:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:31:05 --> Language Class Initialized
DEBUG - 2016-05-22 03:31:05 --> Loader Class Initialized
DEBUG - 2016-05-22 03:31:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:31:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:31:05 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:31:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:31:05 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:31:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:31:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:31:05 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:31:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:31:05 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:31:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:31:05 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:31:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:31:05 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:31:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:31:05 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:31:05 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:31:05 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:31:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:31:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:31:05 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:31:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:31:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:31:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:31:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:31:05 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:31:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:31:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:31:05 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:31:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:31:05 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:31:05 --> Session Class Initialized
DEBUG - 2016-05-22 03:31:05 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:31:05 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:31:05 --> Session routines successfully run
DEBUG - 2016-05-22 03:31:05 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:31:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:31:05 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:31:05 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:31:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:31:05 --> Controller Class Initialized
DEBUG - 2016-05-22 03:31:05 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:31:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:31:05 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:31:05 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:31:05 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:31:05 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:31:05 --> Model Class Initialized
DEBUG - 2016-05-22 03:31:05 --> Model Class Initialized
DEBUG - 2016-05-22 03:31:05 --> Model Class Initialized
DEBUG - 2016-05-22 03:31:05 --> Model Class Initialized
DEBUG - 2016-05-22 03:31:05 --> Model Class Initialized
ERROR - 2016-05-22 03:31:05 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-05-22 03:31:06 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-05-22 03:31:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 03:31:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-22 03:31:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 03:31:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 03:31:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 03:31:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 03:31:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 03:31:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 03:31:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 03:31:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 03:31:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 03:31:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 03:31:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 03:31:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 03:31:06 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-05-22 03:31:06 --> Final output sent to browser
DEBUG - 2016-05-22 03:31:06 --> Total execution time: 1.0360
DEBUG - 2016-05-22 03:31:35 --> Config Class Initialized
DEBUG - 2016-05-22 03:31:35 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:31:35 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:31:35 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:31:35 --> URI Class Initialized
DEBUG - 2016-05-22 03:31:35 --> Router Class Initialized
DEBUG - 2016-05-22 03:31:35 --> Output Class Initialized
DEBUG - 2016-05-22 03:31:35 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 03:31:35 --> Security Class Initialized
DEBUG - 2016-05-22 03:31:35 --> Input Class Initialized
DEBUG - 2016-05-22 03:31:35 --> XSS Filtering completed
DEBUG - 2016-05-22 03:31:35 --> XSS Filtering completed
DEBUG - 2016-05-22 03:31:35 --> XSS Filtering completed
DEBUG - 2016-05-22 03:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:31:35 --> Language Class Initialized
DEBUG - 2016-05-22 03:31:35 --> Loader Class Initialized
DEBUG - 2016-05-22 03:31:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:31:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:31:35 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:31:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:31:35 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:31:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:31:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:31:35 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:31:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:31:35 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:31:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:31:35 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:31:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:31:35 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:31:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:31:35 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:31:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:31:35 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:31:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:31:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:31:35 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:31:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:31:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:31:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:31:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:31:35 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:31:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:31:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:31:35 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:31:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:31:35 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:31:35 --> Session Class Initialized
DEBUG - 2016-05-22 03:31:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:31:35 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:31:35 --> Session routines successfully run
DEBUG - 2016-05-22 03:31:35 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:31:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:31:35 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:31:35 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:31:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:31:35 --> Controller Class Initialized
DEBUG - 2016-05-22 03:31:35 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:31:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:31:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:31:35 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:31:35 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:31:35 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:31:35 --> Model Class Initialized
DEBUG - 2016-05-22 03:31:35 --> Model Class Initialized
DEBUG - 2016-05-22 03:31:35 --> Model Class Initialized
DEBUG - 2016-05-22 03:31:36 --> Model Class Initialized
DEBUG - 2016-05-22 03:31:36 --> Model Class Initialized
DEBUG - 2016-05-22 03:33:13 --> Config Class Initialized
DEBUG - 2016-05-22 03:33:13 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:33:13 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:33:13 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:33:13 --> URI Class Initialized
DEBUG - 2016-05-22 03:33:13 --> Router Class Initialized
DEBUG - 2016-05-22 03:33:13 --> Output Class Initialized
DEBUG - 2016-05-22 03:33:13 --> Security Class Initialized
DEBUG - 2016-05-22 03:33:13 --> Input Class Initialized
DEBUG - 2016-05-22 03:33:13 --> XSS Filtering completed
DEBUG - 2016-05-22 03:33:13 --> XSS Filtering completed
DEBUG - 2016-05-22 03:33:13 --> XSS Filtering completed
DEBUG - 2016-05-22 03:33:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:33:13 --> Language Class Initialized
DEBUG - 2016-05-22 03:33:13 --> Loader Class Initialized
DEBUG - 2016-05-22 03:33:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:33:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:33:13 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:33:13 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:33:13 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:33:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:33:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:33:13 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:33:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:33:13 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:33:13 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:33:13 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:33:13 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:33:13 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:33:13 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:33:13 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:33:13 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:33:13 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:33:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:33:13 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:33:13 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:33:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:33:13 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:33:13 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:33:13 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:33:13 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:33:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:33:13 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:33:13 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:33:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:33:13 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:33:13 --> Session Class Initialized
DEBUG - 2016-05-22 03:33:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:33:13 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:33:13 --> Session routines successfully run
DEBUG - 2016-05-22 03:33:13 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:33:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:33:13 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:33:13 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:33:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:33:13 --> Controller Class Initialized
DEBUG - 2016-05-22 03:33:13 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:33:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:33:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:33:13 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:33:13 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:33:13 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:33:13 --> Model Class Initialized
DEBUG - 2016-05-22 03:33:13 --> Model Class Initialized
DEBUG - 2016-05-22 03:33:13 --> Model Class Initialized
DEBUG - 2016-05-22 03:33:13 --> Model Class Initialized
DEBUG - 2016-05-22 03:33:13 --> Model Class Initialized
DEBUG - 2016-05-22 03:33:45 --> Config Class Initialized
DEBUG - 2016-05-22 03:33:45 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:33:45 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:33:45 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:33:45 --> URI Class Initialized
DEBUG - 2016-05-22 03:33:45 --> Router Class Initialized
DEBUG - 2016-05-22 03:33:45 --> Output Class Initialized
DEBUG - 2016-05-22 03:33:45 --> Security Class Initialized
DEBUG - 2016-05-22 03:33:45 --> Input Class Initialized
DEBUG - 2016-05-22 03:33:45 --> XSS Filtering completed
DEBUG - 2016-05-22 03:33:45 --> XSS Filtering completed
DEBUG - 2016-05-22 03:33:45 --> XSS Filtering completed
DEBUG - 2016-05-22 03:33:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:33:45 --> Language Class Initialized
DEBUG - 2016-05-22 03:33:45 --> Loader Class Initialized
DEBUG - 2016-05-22 03:33:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:33:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:33:45 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:33:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:33:45 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:33:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:33:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:33:45 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:33:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:33:45 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:33:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:33:46 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:33:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:33:46 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:33:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:33:46 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:33:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:33:46 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:33:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:33:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:33:46 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:33:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:33:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:33:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:33:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:33:46 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:33:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:33:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:33:46 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:33:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:33:46 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:33:46 --> Session Class Initialized
DEBUG - 2016-05-22 03:33:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:33:46 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:33:46 --> Session routines successfully run
DEBUG - 2016-05-22 03:33:46 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:33:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:33:46 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:33:46 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:33:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:33:46 --> Controller Class Initialized
DEBUG - 2016-05-22 03:33:46 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:33:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:33:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:33:46 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:33:46 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:33:46 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:33:46 --> Model Class Initialized
DEBUG - 2016-05-22 03:33:46 --> Model Class Initialized
DEBUG - 2016-05-22 03:33:46 --> Model Class Initialized
DEBUG - 2016-05-22 03:33:46 --> Model Class Initialized
DEBUG - 2016-05-22 03:33:46 --> Model Class Initialized
DEBUG - 2016-05-22 03:35:31 --> Config Class Initialized
DEBUG - 2016-05-22 03:35:31 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:35:31 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:35:31 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:35:31 --> URI Class Initialized
DEBUG - 2016-05-22 03:35:31 --> Router Class Initialized
DEBUG - 2016-05-22 03:35:31 --> Output Class Initialized
DEBUG - 2016-05-22 03:35:31 --> Security Class Initialized
DEBUG - 2016-05-22 03:35:31 --> Input Class Initialized
DEBUG - 2016-05-22 03:35:31 --> XSS Filtering completed
DEBUG - 2016-05-22 03:35:31 --> XSS Filtering completed
DEBUG - 2016-05-22 03:35:31 --> XSS Filtering completed
DEBUG - 2016-05-22 03:35:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:35:31 --> Language Class Initialized
DEBUG - 2016-05-22 03:35:31 --> Loader Class Initialized
DEBUG - 2016-05-22 03:35:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:35:31 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:35:31 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:35:31 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:35:31 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:35:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:35:31 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:35:31 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:35:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:35:31 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:35:31 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:35:31 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:35:31 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:35:31 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:35:31 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:35:31 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:35:31 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:35:31 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:35:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:35:31 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:35:31 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:35:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:35:31 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:35:31 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:35:31 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:35:32 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:35:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:35:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:35:32 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:35:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:35:32 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:35:32 --> Session Class Initialized
DEBUG - 2016-05-22 03:35:32 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:35:32 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:35:32 --> Session routines successfully run
DEBUG - 2016-05-22 03:35:32 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:35:32 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:35:32 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:35:32 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:35:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:35:32 --> Controller Class Initialized
DEBUG - 2016-05-22 03:35:32 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:35:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:35:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:35:32 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:35:32 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:35:32 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:35:32 --> Model Class Initialized
DEBUG - 2016-05-22 03:35:32 --> Model Class Initialized
DEBUG - 2016-05-22 03:35:32 --> Model Class Initialized
DEBUG - 2016-05-22 03:35:32 --> Model Class Initialized
DEBUG - 2016-05-22 03:35:32 --> Model Class Initialized
DEBUG - 2016-05-22 03:35:51 --> Config Class Initialized
DEBUG - 2016-05-22 03:35:51 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:35:51 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:35:51 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:35:51 --> URI Class Initialized
DEBUG - 2016-05-22 03:35:51 --> Router Class Initialized
DEBUG - 2016-05-22 03:35:51 --> Output Class Initialized
DEBUG - 2016-05-22 03:35:51 --> Security Class Initialized
DEBUG - 2016-05-22 03:35:51 --> Input Class Initialized
DEBUG - 2016-05-22 03:35:51 --> XSS Filtering completed
DEBUG - 2016-05-22 03:35:51 --> XSS Filtering completed
DEBUG - 2016-05-22 03:35:51 --> XSS Filtering completed
DEBUG - 2016-05-22 03:35:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:35:51 --> Language Class Initialized
DEBUG - 2016-05-22 03:35:51 --> Loader Class Initialized
DEBUG - 2016-05-22 03:35:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:35:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:35:51 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:35:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:35:51 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:35:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:35:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:35:51 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:35:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:35:51 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:35:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:35:51 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:35:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:35:51 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:35:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:35:51 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:35:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:35:51 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:35:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:35:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:35:51 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:35:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:35:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:35:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:35:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:35:51 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:35:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:35:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:35:51 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:35:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:35:51 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:35:51 --> Session Class Initialized
DEBUG - 2016-05-22 03:35:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:35:51 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:35:51 --> Session routines successfully run
DEBUG - 2016-05-22 03:35:51 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:35:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:35:51 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:35:52 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:35:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:35:52 --> Controller Class Initialized
DEBUG - 2016-05-22 03:35:52 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:35:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:35:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:35:52 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:35:52 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:35:52 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:35:52 --> Model Class Initialized
DEBUG - 2016-05-22 03:35:52 --> Model Class Initialized
DEBUG - 2016-05-22 03:35:52 --> Model Class Initialized
DEBUG - 2016-05-22 03:35:52 --> Model Class Initialized
DEBUG - 2016-05-22 03:35:52 --> Model Class Initialized
DEBUG - 2016-05-22 03:36:10 --> Config Class Initialized
DEBUG - 2016-05-22 03:36:10 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:36:10 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:36:10 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:36:10 --> URI Class Initialized
DEBUG - 2016-05-22 03:36:10 --> Router Class Initialized
DEBUG - 2016-05-22 03:36:10 --> Output Class Initialized
DEBUG - 2016-05-22 03:36:10 --> Security Class Initialized
DEBUG - 2016-05-22 03:36:10 --> Input Class Initialized
DEBUG - 2016-05-22 03:36:10 --> XSS Filtering completed
DEBUG - 2016-05-22 03:36:10 --> XSS Filtering completed
DEBUG - 2016-05-22 03:36:10 --> XSS Filtering completed
DEBUG - 2016-05-22 03:36:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:36:10 --> Language Class Initialized
DEBUG - 2016-05-22 03:36:10 --> Loader Class Initialized
DEBUG - 2016-05-22 03:36:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:36:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:36:10 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:36:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:36:11 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:36:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:36:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:36:11 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:36:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:36:11 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:36:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:36:11 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:36:11 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:36:11 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:36:11 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:36:11 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:36:11 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:36:11 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:36:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:36:11 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:36:11 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:36:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:36:11 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:36:11 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:36:11 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:36:11 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:36:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:36:11 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:36:11 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:36:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:36:11 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:36:11 --> Session Class Initialized
DEBUG - 2016-05-22 03:36:11 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:36:11 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:36:11 --> Session routines successfully run
DEBUG - 2016-05-22 03:36:11 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:36:11 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:36:11 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:36:11 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:36:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:36:11 --> Controller Class Initialized
DEBUG - 2016-05-22 03:36:11 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:36:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:36:11 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:36:11 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:36:11 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:36:11 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:36:11 --> Model Class Initialized
DEBUG - 2016-05-22 03:36:11 --> Model Class Initialized
DEBUG - 2016-05-22 03:36:11 --> Model Class Initialized
DEBUG - 2016-05-22 03:36:11 --> Model Class Initialized
DEBUG - 2016-05-22 03:36:11 --> Model Class Initialized
DEBUG - 2016-05-22 03:36:48 --> Config Class Initialized
DEBUG - 2016-05-22 03:36:48 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:36:48 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:36:48 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:36:48 --> URI Class Initialized
DEBUG - 2016-05-22 03:36:48 --> Router Class Initialized
DEBUG - 2016-05-22 03:36:48 --> Output Class Initialized
DEBUG - 2016-05-22 03:36:48 --> Security Class Initialized
DEBUG - 2016-05-22 03:36:48 --> Input Class Initialized
DEBUG - 2016-05-22 03:36:48 --> XSS Filtering completed
DEBUG - 2016-05-22 03:36:48 --> XSS Filtering completed
DEBUG - 2016-05-22 03:36:48 --> XSS Filtering completed
DEBUG - 2016-05-22 03:36:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:36:48 --> Language Class Initialized
DEBUG - 2016-05-22 03:36:48 --> Loader Class Initialized
DEBUG - 2016-05-22 03:36:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:36:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:36:48 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:36:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:36:48 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:36:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:36:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:36:48 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:36:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:36:49 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:36:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:36:49 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:36:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:36:49 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:36:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:36:49 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:36:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:36:49 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:36:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:36:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:36:49 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:36:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:36:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:36:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:36:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:36:49 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:36:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:36:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:36:49 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:36:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:36:49 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:36:49 --> Session Class Initialized
DEBUG - 2016-05-22 03:36:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:36:49 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:36:49 --> Session routines successfully run
DEBUG - 2016-05-22 03:36:49 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:36:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:36:49 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:36:49 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:36:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:36:49 --> Controller Class Initialized
DEBUG - 2016-05-22 03:36:49 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:36:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:36:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:36:49 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:36:49 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:36:49 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:36:49 --> Model Class Initialized
DEBUG - 2016-05-22 03:36:49 --> Model Class Initialized
DEBUG - 2016-05-22 03:36:49 --> Model Class Initialized
DEBUG - 2016-05-22 03:36:49 --> Model Class Initialized
DEBUG - 2016-05-22 03:36:49 --> Model Class Initialized
DEBUG - 2016-05-22 03:36:57 --> Config Class Initialized
DEBUG - 2016-05-22 03:36:57 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:36:57 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:36:57 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:36:57 --> URI Class Initialized
DEBUG - 2016-05-22 03:36:57 --> Router Class Initialized
DEBUG - 2016-05-22 03:36:57 --> Output Class Initialized
DEBUG - 2016-05-22 03:36:57 --> Security Class Initialized
DEBUG - 2016-05-22 03:36:57 --> Input Class Initialized
DEBUG - 2016-05-22 03:36:57 --> XSS Filtering completed
DEBUG - 2016-05-22 03:36:57 --> XSS Filtering completed
DEBUG - 2016-05-22 03:36:57 --> XSS Filtering completed
DEBUG - 2016-05-22 03:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:36:57 --> Language Class Initialized
DEBUG - 2016-05-22 03:36:58 --> Loader Class Initialized
DEBUG - 2016-05-22 03:36:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:36:58 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:36:58 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:36:58 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:36:58 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:36:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:36:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:36:58 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:36:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:36:58 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:36:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:36:58 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:36:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:36:58 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:36:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:36:58 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:36:58 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:36:58 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:36:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:36:58 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:36:58 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:36:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:36:58 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:36:58 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:36:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:36:58 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:36:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:36:58 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:36:58 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:36:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:36:58 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:36:58 --> Session Class Initialized
DEBUG - 2016-05-22 03:36:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:36:58 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:36:58 --> Session routines successfully run
DEBUG - 2016-05-22 03:36:58 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:36:58 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:36:58 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:36:58 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:36:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:36:58 --> Controller Class Initialized
DEBUG - 2016-05-22 03:36:58 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:36:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:36:58 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:36:58 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:36:58 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:36:58 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:36:58 --> Model Class Initialized
DEBUG - 2016-05-22 03:36:58 --> Model Class Initialized
DEBUG - 2016-05-22 03:36:58 --> Model Class Initialized
DEBUG - 2016-05-22 03:36:58 --> Model Class Initialized
DEBUG - 2016-05-22 03:36:58 --> Model Class Initialized
DEBUG - 2016-05-22 03:37:15 --> Config Class Initialized
DEBUG - 2016-05-22 03:37:15 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:37:15 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:37:15 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:37:15 --> URI Class Initialized
DEBUG - 2016-05-22 03:37:15 --> Router Class Initialized
DEBUG - 2016-05-22 03:37:15 --> Output Class Initialized
DEBUG - 2016-05-22 03:37:15 --> Security Class Initialized
DEBUG - 2016-05-22 03:37:15 --> Input Class Initialized
DEBUG - 2016-05-22 03:37:15 --> XSS Filtering completed
DEBUG - 2016-05-22 03:37:15 --> XSS Filtering completed
DEBUG - 2016-05-22 03:37:15 --> XSS Filtering completed
DEBUG - 2016-05-22 03:37:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:37:15 --> Language Class Initialized
DEBUG - 2016-05-22 03:37:15 --> Loader Class Initialized
DEBUG - 2016-05-22 03:37:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:37:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:37:15 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:37:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:37:15 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:37:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:37:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:37:15 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:37:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:37:15 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:37:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:37:15 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:37:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:37:15 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:37:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:37:15 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:37:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:37:15 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:37:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:37:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:37:15 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:37:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:37:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:37:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:37:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:37:15 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:37:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:37:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:37:15 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:37:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:37:16 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:37:16 --> Session Class Initialized
DEBUG - 2016-05-22 03:37:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:37:16 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:37:16 --> Session routines successfully run
DEBUG - 2016-05-22 03:37:16 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:37:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:37:16 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:37:16 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:37:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:37:16 --> Controller Class Initialized
DEBUG - 2016-05-22 03:37:16 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:37:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:37:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:37:16 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:37:16 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:37:16 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:37:16 --> Model Class Initialized
DEBUG - 2016-05-22 03:37:16 --> Model Class Initialized
DEBUG - 2016-05-22 03:37:16 --> Model Class Initialized
DEBUG - 2016-05-22 03:37:16 --> Model Class Initialized
DEBUG - 2016-05-22 03:37:16 --> Model Class Initialized
DEBUG - 2016-05-22 03:37:28 --> Config Class Initialized
DEBUG - 2016-05-22 03:37:28 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:37:28 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:37:28 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:37:28 --> URI Class Initialized
DEBUG - 2016-05-22 03:37:28 --> Router Class Initialized
DEBUG - 2016-05-22 03:37:28 --> Output Class Initialized
DEBUG - 2016-05-22 03:37:28 --> Security Class Initialized
DEBUG - 2016-05-22 03:37:28 --> Input Class Initialized
DEBUG - 2016-05-22 03:37:28 --> XSS Filtering completed
DEBUG - 2016-05-22 03:37:28 --> XSS Filtering completed
DEBUG - 2016-05-22 03:37:28 --> XSS Filtering completed
DEBUG - 2016-05-22 03:37:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:37:28 --> Language Class Initialized
DEBUG - 2016-05-22 03:37:28 --> Loader Class Initialized
DEBUG - 2016-05-22 03:37:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:37:28 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:37:28 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:37:28 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:37:28 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:37:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:37:28 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:37:28 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:37:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:37:28 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:37:28 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:37:28 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:37:28 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:37:28 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:37:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:37:28 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:37:28 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:37:28 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:37:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:37:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:37:28 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:37:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:37:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:37:28 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:37:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:37:28 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:37:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:37:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:37:28 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:37:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:37:28 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:37:28 --> Session Class Initialized
DEBUG - 2016-05-22 03:37:28 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:37:28 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:37:28 --> Session routines successfully run
DEBUG - 2016-05-22 03:37:28 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:37:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:37:28 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:37:28 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:37:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:37:29 --> Controller Class Initialized
DEBUG - 2016-05-22 03:37:29 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:37:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:37:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:37:29 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:37:29 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:37:29 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:37:29 --> Model Class Initialized
DEBUG - 2016-05-22 03:37:29 --> Model Class Initialized
DEBUG - 2016-05-22 03:37:29 --> Model Class Initialized
DEBUG - 2016-05-22 03:37:29 --> Model Class Initialized
DEBUG - 2016-05-22 03:37:29 --> Model Class Initialized
DEBUG - 2016-05-22 03:37:29 --> Upload Class Initialized
DEBUG - 2016-05-22 03:37:29 --> Upload Class Initialized
DEBUG - 2016-05-22 03:37:29 --> Class Library loaded: LWS_Upload on upload
ERROR - 2016-05-22 03:37:29 --> Severity: Warning  --> Illegal string offset 'short_user_path_berkas_peserta_diklat' E:\www\GitHub\2016APSIDIKA\application\models\model_tr_peserta_diklat.php 168
ERROR - 2016-05-22 03:37:29 --> Severity: Warning  --> Creating default object from empty value E:\www\GitHub\2016APSIDIKA\application\controllers\back_end\cpeserta_diklat.php 106
DEBUG - 2016-05-22 03:39:16 --> Config Class Initialized
DEBUG - 2016-05-22 03:39:16 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:39:16 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:39:16 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:39:16 --> URI Class Initialized
DEBUG - 2016-05-22 03:39:16 --> Router Class Initialized
DEBUG - 2016-05-22 03:39:16 --> Output Class Initialized
DEBUG - 2016-05-22 03:39:16 --> Security Class Initialized
DEBUG - 2016-05-22 03:39:17 --> Input Class Initialized
DEBUG - 2016-05-22 03:39:17 --> XSS Filtering completed
DEBUG - 2016-05-22 03:39:17 --> XSS Filtering completed
DEBUG - 2016-05-22 03:39:17 --> XSS Filtering completed
DEBUG - 2016-05-22 03:39:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:39:17 --> Language Class Initialized
DEBUG - 2016-05-22 03:39:17 --> Loader Class Initialized
DEBUG - 2016-05-22 03:39:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:39:17 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:39:17 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:39:17 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:39:17 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:39:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:39:17 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:39:17 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:39:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:39:17 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:39:17 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:39:17 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:39:17 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:39:17 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:39:17 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:39:17 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:39:17 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:39:17 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:39:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:39:17 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:39:17 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:39:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:39:17 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:39:17 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:39:17 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:39:17 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:39:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:39:17 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:39:17 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:39:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:39:17 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:39:17 --> Session Class Initialized
DEBUG - 2016-05-22 03:39:17 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:39:17 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:39:17 --> Session routines successfully run
DEBUG - 2016-05-22 03:39:17 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:39:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:39:17 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:39:17 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:39:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:39:17 --> Controller Class Initialized
DEBUG - 2016-05-22 03:39:17 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:39:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:39:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:39:17 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:39:17 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:39:17 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:39:17 --> Model Class Initialized
DEBUG - 2016-05-22 03:39:17 --> Model Class Initialized
DEBUG - 2016-05-22 03:39:17 --> Model Class Initialized
DEBUG - 2016-05-22 03:39:17 --> Model Class Initialized
DEBUG - 2016-05-22 03:39:17 --> Model Class Initialized
DEBUG - 2016-05-22 03:39:17 --> Upload Class Initialized
DEBUG - 2016-05-22 03:39:17 --> Upload Class Initialized
DEBUG - 2016-05-22 03:39:17 --> Class Library loaded: LWS_Upload on upload
DEBUG - 2016-05-22 03:39:36 --> Config Class Initialized
DEBUG - 2016-05-22 03:39:36 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:39:36 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:39:36 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:39:36 --> URI Class Initialized
DEBUG - 2016-05-22 03:39:36 --> Router Class Initialized
DEBUG - 2016-05-22 03:39:36 --> Output Class Initialized
DEBUG - 2016-05-22 03:39:36 --> Security Class Initialized
DEBUG - 2016-05-22 03:39:36 --> Input Class Initialized
DEBUG - 2016-05-22 03:39:36 --> XSS Filtering completed
DEBUG - 2016-05-22 03:39:36 --> XSS Filtering completed
DEBUG - 2016-05-22 03:39:36 --> XSS Filtering completed
DEBUG - 2016-05-22 03:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:39:36 --> Language Class Initialized
DEBUG - 2016-05-22 03:39:36 --> Loader Class Initialized
DEBUG - 2016-05-22 03:39:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:39:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:39:36 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:39:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:39:36 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:39:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:39:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:39:36 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:39:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:39:36 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:39:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:39:36 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:39:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:39:36 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:39:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:39:36 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:39:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:39:36 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:39:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:39:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:39:37 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:39:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:39:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:39:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:39:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:39:37 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:39:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:39:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:39:37 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:39:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:39:37 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:39:37 --> Session Class Initialized
DEBUG - 2016-05-22 03:39:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:39:37 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:39:37 --> Session routines successfully run
DEBUG - 2016-05-22 03:39:37 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:39:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:39:37 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:39:37 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:39:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:39:37 --> Controller Class Initialized
DEBUG - 2016-05-22 03:39:37 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:39:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:39:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:39:37 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:39:37 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:39:37 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:39:37 --> Model Class Initialized
DEBUG - 2016-05-22 03:39:37 --> Model Class Initialized
DEBUG - 2016-05-22 03:39:37 --> Model Class Initialized
DEBUG - 2016-05-22 03:39:37 --> Model Class Initialized
DEBUG - 2016-05-22 03:39:37 --> Model Class Initialized
DEBUG - 2016-05-22 03:39:37 --> Upload Class Initialized
DEBUG - 2016-05-22 03:39:37 --> Upload Class Initialized
DEBUG - 2016-05-22 03:39:37 --> Class Library loaded: LWS_Upload on upload
ERROR - 2016-05-22 03:39:37 --> Severity: Warning  --> Creating default object from empty value E:\www\GitHub\2016APSIDIKA\application\controllers\back_end\cpeserta_diklat.php 106
DEBUG - 2016-05-22 03:40:16 --> Config Class Initialized
DEBUG - 2016-05-22 03:40:16 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:40:16 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:40:17 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:40:17 --> URI Class Initialized
DEBUG - 2016-05-22 03:40:17 --> Router Class Initialized
DEBUG - 2016-05-22 03:40:17 --> Output Class Initialized
DEBUG - 2016-05-22 03:40:17 --> Security Class Initialized
DEBUG - 2016-05-22 03:40:17 --> Input Class Initialized
DEBUG - 2016-05-22 03:40:17 --> XSS Filtering completed
DEBUG - 2016-05-22 03:40:17 --> XSS Filtering completed
DEBUG - 2016-05-22 03:40:17 --> XSS Filtering completed
DEBUG - 2016-05-22 03:40:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:40:17 --> Language Class Initialized
DEBUG - 2016-05-22 03:40:17 --> Loader Class Initialized
DEBUG - 2016-05-22 03:40:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:40:17 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:40:17 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:40:17 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:40:17 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:40:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:40:17 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:40:17 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:40:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:40:17 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:40:17 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:40:17 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:40:17 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:40:17 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:40:17 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:40:17 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:40:17 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:40:17 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:40:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:40:17 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:40:17 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:40:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:40:17 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:40:17 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:40:17 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:40:17 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:40:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:40:17 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:40:17 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:40:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:40:17 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:40:17 --> Session Class Initialized
DEBUG - 2016-05-22 03:40:17 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:40:17 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:40:17 --> Session routines successfully run
DEBUG - 2016-05-22 03:40:17 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:40:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:40:17 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:40:17 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:40:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:40:17 --> Controller Class Initialized
DEBUG - 2016-05-22 03:40:17 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:40:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:40:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:40:17 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:40:17 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:40:17 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:40:17 --> Model Class Initialized
DEBUG - 2016-05-22 03:40:17 --> Model Class Initialized
DEBUG - 2016-05-22 03:40:17 --> Model Class Initialized
DEBUG - 2016-05-22 03:40:24 --> Config Class Initialized
DEBUG - 2016-05-22 03:40:24 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:40:24 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:40:24 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:40:24 --> URI Class Initialized
DEBUG - 2016-05-22 03:40:24 --> Router Class Initialized
DEBUG - 2016-05-22 03:40:24 --> Output Class Initialized
DEBUG - 2016-05-22 03:40:24 --> Security Class Initialized
DEBUG - 2016-05-22 03:40:24 --> Input Class Initialized
DEBUG - 2016-05-22 03:40:24 --> XSS Filtering completed
DEBUG - 2016-05-22 03:40:24 --> XSS Filtering completed
DEBUG - 2016-05-22 03:40:24 --> XSS Filtering completed
DEBUG - 2016-05-22 03:40:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:40:24 --> Language Class Initialized
DEBUG - 2016-05-22 03:40:24 --> Loader Class Initialized
DEBUG - 2016-05-22 03:40:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:40:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:40:24 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:40:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:40:24 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:40:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:40:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:40:24 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:40:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:40:24 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:40:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:40:24 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:40:24 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:40:24 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:40:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:40:24 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:40:24 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:40:24 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:40:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:40:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:40:24 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:40:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:40:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:40:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:40:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:40:25 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:40:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:40:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:40:25 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:40:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:40:25 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:40:25 --> Session Class Initialized
DEBUG - 2016-05-22 03:40:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:40:25 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:40:25 --> Session routines successfully run
DEBUG - 2016-05-22 03:40:25 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:40:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:40:25 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:40:25 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:40:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:40:25 --> Controller Class Initialized
DEBUG - 2016-05-22 03:40:25 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:40:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:40:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:40:25 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:40:25 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:40:25 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:40:25 --> Model Class Initialized
DEBUG - 2016-05-22 03:40:25 --> Model Class Initialized
DEBUG - 2016-05-22 03:40:25 --> Model Class Initialized
DEBUG - 2016-05-22 03:40:25 --> Model Class Initialized
DEBUG - 2016-05-22 03:40:25 --> Model Class Initialized
DEBUG - 2016-05-22 03:40:25 --> Upload Class Initialized
DEBUG - 2016-05-22 03:40:25 --> Upload Class Initialized
DEBUG - 2016-05-22 03:40:25 --> Class Library loaded: LWS_Upload on upload
DEBUG - 2016-05-22 03:40:29 --> Config Class Initialized
DEBUG - 2016-05-22 03:40:29 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:40:29 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:40:29 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:40:29 --> URI Class Initialized
DEBUG - 2016-05-22 03:40:29 --> Router Class Initialized
DEBUG - 2016-05-22 03:40:29 --> Output Class Initialized
DEBUG - 2016-05-22 03:40:29 --> Security Class Initialized
DEBUG - 2016-05-22 03:40:29 --> Input Class Initialized
DEBUG - 2016-05-22 03:40:29 --> XSS Filtering completed
DEBUG - 2016-05-22 03:40:29 --> XSS Filtering completed
DEBUG - 2016-05-22 03:40:29 --> XSS Filtering completed
DEBUG - 2016-05-22 03:40:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:40:29 --> Language Class Initialized
DEBUG - 2016-05-22 03:40:30 --> Loader Class Initialized
DEBUG - 2016-05-22 03:40:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:40:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:40:30 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:40:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:40:30 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:40:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:40:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:40:30 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:40:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:40:30 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:40:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:40:30 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:40:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:40:30 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:40:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:40:30 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:40:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:40:30 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:40:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:40:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:40:30 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:40:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:40:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:40:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:40:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:40:30 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:40:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:40:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:40:30 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:40:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:40:30 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:40:30 --> Session Class Initialized
DEBUG - 2016-05-22 03:40:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:40:30 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:40:30 --> Session routines successfully run
DEBUG - 2016-05-22 03:40:30 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:40:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:40:30 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:40:30 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:40:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:40:30 --> Controller Class Initialized
DEBUG - 2016-05-22 03:40:30 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:40:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:40:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:40:30 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:40:30 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:40:30 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:40:30 --> Model Class Initialized
DEBUG - 2016-05-22 03:40:30 --> Model Class Initialized
DEBUG - 2016-05-22 03:40:30 --> Model Class Initialized
DEBUG - 2016-05-22 03:40:30 --> Model Class Initialized
DEBUG - 2016-05-22 03:40:30 --> Model Class Initialized
DEBUG - 2016-05-22 03:40:30 --> Upload Class Initialized
DEBUG - 2016-05-22 03:40:30 --> Upload Class Initialized
DEBUG - 2016-05-22 03:40:30 --> Class Library loaded: LWS_Upload on upload
DEBUG - 2016-05-22 03:40:30 --> Language file loaded: language/indonesia/upload_lang.php
ERROR - 2016-05-22 03:40:30 --> Tipe berkas yang anda coba unggah tidak diperbolehkan.
DEBUG - 2016-05-22 03:43:52 --> Config Class Initialized
DEBUG - 2016-05-22 03:43:52 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:43:52 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:43:52 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:43:52 --> URI Class Initialized
DEBUG - 2016-05-22 03:43:52 --> Router Class Initialized
DEBUG - 2016-05-22 03:43:52 --> Output Class Initialized
DEBUG - 2016-05-22 03:43:52 --> Security Class Initialized
DEBUG - 2016-05-22 03:43:52 --> Input Class Initialized
DEBUG - 2016-05-22 03:43:52 --> XSS Filtering completed
DEBUG - 2016-05-22 03:43:52 --> XSS Filtering completed
DEBUG - 2016-05-22 03:43:52 --> XSS Filtering completed
DEBUG - 2016-05-22 03:43:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:43:52 --> Language Class Initialized
DEBUG - 2016-05-22 03:43:53 --> Loader Class Initialized
DEBUG - 2016-05-22 03:43:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:43:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:43:53 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:43:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:43:53 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:43:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:43:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:43:53 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:43:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:43:53 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:43:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:43:53 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:43:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:43:53 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:43:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:43:53 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:43:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:43:53 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:43:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:43:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:43:53 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:43:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:43:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:43:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:43:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:43:54 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:43:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:43:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:43:54 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:43:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:43:54 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:43:54 --> Session Class Initialized
DEBUG - 2016-05-22 03:43:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:43:54 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:43:54 --> Session routines successfully run
DEBUG - 2016-05-22 03:43:54 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:43:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:43:54 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:43:54 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:43:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:43:55 --> Controller Class Initialized
DEBUG - 2016-05-22 03:43:55 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:43:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:43:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:43:55 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:43:55 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:43:55 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:43:55 --> Model Class Initialized
DEBUG - 2016-05-22 03:43:55 --> Model Class Initialized
DEBUG - 2016-05-22 03:43:55 --> Model Class Initialized
DEBUG - 2016-05-22 03:43:55 --> Model Class Initialized
DEBUG - 2016-05-22 03:43:56 --> Model Class Initialized
DEBUG - 2016-05-22 03:43:56 --> Upload Class Initialized
DEBUG - 2016-05-22 03:43:56 --> Upload Class Initialized
DEBUG - 2016-05-22 03:43:56 --> Class Library loaded: LWS_Upload on upload
DEBUG - 2016-05-22 03:43:56 --> Language file loaded: language/indonesia/upload_lang.php
ERROR - 2016-05-22 03:43:56 --> Tipe berkas yang anda coba unggah tidak diperbolehkan.
DEBUG - 2016-05-22 03:44:07 --> Config Class Initialized
DEBUG - 2016-05-22 03:44:07 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:44:07 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:44:07 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:44:07 --> URI Class Initialized
DEBUG - 2016-05-22 03:44:07 --> Router Class Initialized
DEBUG - 2016-05-22 03:44:07 --> Output Class Initialized
DEBUG - 2016-05-22 03:44:07 --> Security Class Initialized
DEBUG - 2016-05-22 03:44:07 --> Input Class Initialized
DEBUG - 2016-05-22 03:44:07 --> XSS Filtering completed
DEBUG - 2016-05-22 03:44:07 --> XSS Filtering completed
DEBUG - 2016-05-22 03:44:07 --> XSS Filtering completed
DEBUG - 2016-05-22 03:44:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:44:07 --> Language Class Initialized
DEBUG - 2016-05-22 03:44:07 --> Loader Class Initialized
DEBUG - 2016-05-22 03:44:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:44:07 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:44:07 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:44:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:44:07 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:44:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:44:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:44:07 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:44:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:44:07 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:44:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:44:07 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:44:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:44:07 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:44:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:44:07 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:44:07 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:44:07 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:44:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:44:07 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:44:07 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:44:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:44:07 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:44:07 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:44:07 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:44:07 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:44:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:44:07 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:44:07 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:44:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:44:07 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:44:08 --> Session Class Initialized
DEBUG - 2016-05-22 03:44:08 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:44:08 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:44:08 --> Session routines successfully run
DEBUG - 2016-05-22 03:44:08 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:44:08 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:44:08 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:44:08 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:44:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:44:08 --> Controller Class Initialized
DEBUG - 2016-05-22 03:44:08 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:44:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:44:08 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:44:08 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:44:08 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:44:08 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:44:08 --> Model Class Initialized
DEBUG - 2016-05-22 03:44:08 --> Model Class Initialized
DEBUG - 2016-05-22 03:44:08 --> Model Class Initialized
DEBUG - 2016-05-22 03:44:08 --> Model Class Initialized
DEBUG - 2016-05-22 03:44:08 --> Model Class Initialized
DEBUG - 2016-05-22 03:44:08 --> Upload Class Initialized
DEBUG - 2016-05-22 03:44:08 --> Upload Class Initialized
DEBUG - 2016-05-22 03:44:08 --> Class Library loaded: LWS_Upload on upload
DEBUG - 2016-05-22 03:44:08 --> Language file loaded: language/indonesia/upload_lang.php
ERROR - 2016-05-22 03:44:08 --> Tipe berkas yang anda coba unggah tidak diperbolehkan.
DEBUG - 2016-05-22 03:44:18 --> Config Class Initialized
DEBUG - 2016-05-22 03:44:18 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:44:18 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:44:18 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:44:19 --> URI Class Initialized
DEBUG - 2016-05-22 03:44:19 --> Router Class Initialized
DEBUG - 2016-05-22 03:44:19 --> Output Class Initialized
DEBUG - 2016-05-22 03:44:19 --> Security Class Initialized
DEBUG - 2016-05-22 03:44:19 --> Input Class Initialized
DEBUG - 2016-05-22 03:44:19 --> XSS Filtering completed
DEBUG - 2016-05-22 03:44:19 --> XSS Filtering completed
DEBUG - 2016-05-22 03:44:19 --> XSS Filtering completed
DEBUG - 2016-05-22 03:44:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:44:19 --> Language Class Initialized
DEBUG - 2016-05-22 03:44:19 --> Loader Class Initialized
DEBUG - 2016-05-22 03:44:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:44:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:44:19 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:44:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:44:19 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:44:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:44:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:44:19 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:44:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:44:19 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:44:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:44:19 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:44:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:44:19 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:44:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:44:19 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:44:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:44:19 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:44:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:44:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:44:19 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:44:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:44:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:44:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:44:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:44:19 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:44:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:44:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:44:19 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:44:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:44:19 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:44:19 --> Session Class Initialized
DEBUG - 2016-05-22 03:44:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:44:19 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:44:19 --> Session routines successfully run
DEBUG - 2016-05-22 03:44:19 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:44:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:44:19 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:44:19 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:44:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:44:19 --> Controller Class Initialized
DEBUG - 2016-05-22 03:44:19 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:44:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:44:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:44:19 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:44:19 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:44:19 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:44:19 --> Model Class Initialized
DEBUG - 2016-05-22 03:44:19 --> Model Class Initialized
DEBUG - 2016-05-22 03:44:19 --> Model Class Initialized
DEBUG - 2016-05-22 03:44:20 --> Model Class Initialized
DEBUG - 2016-05-22 03:44:20 --> Model Class Initialized
DEBUG - 2016-05-22 03:44:20 --> Upload Class Initialized
DEBUG - 2016-05-22 03:44:20 --> Upload Class Initialized
DEBUG - 2016-05-22 03:44:20 --> Class Library loaded: LWS_Upload on upload
DEBUG - 2016-05-22 03:44:31 --> Config Class Initialized
DEBUG - 2016-05-22 03:44:31 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:44:31 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:44:31 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:44:31 --> URI Class Initialized
DEBUG - 2016-05-22 03:44:31 --> Router Class Initialized
DEBUG - 2016-05-22 03:44:31 --> Output Class Initialized
DEBUG - 2016-05-22 03:44:31 --> Security Class Initialized
DEBUG - 2016-05-22 03:44:31 --> Input Class Initialized
DEBUG - 2016-05-22 03:44:31 --> XSS Filtering completed
DEBUG - 2016-05-22 03:44:31 --> XSS Filtering completed
DEBUG - 2016-05-22 03:44:31 --> XSS Filtering completed
DEBUG - 2016-05-22 03:44:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:44:31 --> Language Class Initialized
DEBUG - 2016-05-22 03:44:31 --> Loader Class Initialized
DEBUG - 2016-05-22 03:44:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:44:31 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:44:31 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:44:31 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:44:31 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:44:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:44:31 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:44:31 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:44:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:44:31 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:44:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:44:32 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:44:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:44:32 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:44:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:44:32 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:44:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:44:32 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:44:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:44:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:44:32 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:44:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:44:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:44:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:44:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:44:32 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:44:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:44:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:44:32 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:44:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:44:32 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:44:32 --> Session Class Initialized
DEBUG - 2016-05-22 03:44:32 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:44:32 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:44:32 --> Session routines successfully run
DEBUG - 2016-05-22 03:44:32 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:44:32 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:44:32 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:44:32 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:44:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:44:32 --> Controller Class Initialized
DEBUG - 2016-05-22 03:44:32 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:44:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:44:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:44:32 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:44:32 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:44:32 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:44:32 --> Model Class Initialized
DEBUG - 2016-05-22 03:44:32 --> Model Class Initialized
DEBUG - 2016-05-22 03:44:32 --> Model Class Initialized
DEBUG - 2016-05-22 03:44:32 --> Model Class Initialized
DEBUG - 2016-05-22 03:44:32 --> Model Class Initialized
DEBUG - 2016-05-22 03:44:32 --> Upload Class Initialized
DEBUG - 2016-05-22 03:44:32 --> Upload Class Initialized
DEBUG - 2016-05-22 03:44:32 --> Class Library loaded: LWS_Upload on upload
DEBUG - 2016-05-22 03:44:52 --> Config Class Initialized
DEBUG - 2016-05-22 03:44:52 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:44:52 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:44:52 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:44:52 --> URI Class Initialized
DEBUG - 2016-05-22 03:44:52 --> Router Class Initialized
DEBUG - 2016-05-22 03:44:52 --> Output Class Initialized
DEBUG - 2016-05-22 03:44:52 --> Security Class Initialized
DEBUG - 2016-05-22 03:44:52 --> Input Class Initialized
DEBUG - 2016-05-22 03:44:52 --> XSS Filtering completed
DEBUG - 2016-05-22 03:44:52 --> XSS Filtering completed
DEBUG - 2016-05-22 03:44:52 --> XSS Filtering completed
DEBUG - 2016-05-22 03:44:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:44:52 --> Language Class Initialized
DEBUG - 2016-05-22 03:44:52 --> Loader Class Initialized
DEBUG - 2016-05-22 03:44:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:44:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:44:52 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:44:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:44:52 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:44:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:44:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:44:53 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:44:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:44:53 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:44:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:44:53 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:44:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:44:53 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:44:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:44:53 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:44:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:44:53 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:44:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:44:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:44:53 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:44:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:44:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:44:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:44:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:44:53 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:44:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:44:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:44:53 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:44:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:44:53 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:44:53 --> Session Class Initialized
DEBUG - 2016-05-22 03:44:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:44:53 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:44:53 --> Session routines successfully run
DEBUG - 2016-05-22 03:44:53 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:44:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:44:53 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:44:53 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:44:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:44:53 --> Controller Class Initialized
DEBUG - 2016-05-22 03:44:53 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:44:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:44:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:44:53 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:44:53 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:44:53 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:44:53 --> Model Class Initialized
DEBUG - 2016-05-22 03:44:53 --> Model Class Initialized
DEBUG - 2016-05-22 03:44:53 --> Model Class Initialized
DEBUG - 2016-05-22 03:44:53 --> Model Class Initialized
DEBUG - 2016-05-22 03:44:53 --> Model Class Initialized
DEBUG - 2016-05-22 03:44:53 --> Upload Class Initialized
DEBUG - 2016-05-22 03:44:53 --> Upload Class Initialized
DEBUG - 2016-05-22 03:44:53 --> Class Library loaded: LWS_Upload on upload
DEBUG - 2016-05-22 03:44:53 --> Language file loaded: language/indonesia/upload_lang.php
ERROR - 2016-05-22 03:44:53 --> Tipe berkas yang anda coba unggah tidak diperbolehkan.
DEBUG - 2016-05-22 03:47:32 --> Config Class Initialized
DEBUG - 2016-05-22 03:47:32 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:47:32 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:47:32 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:47:32 --> URI Class Initialized
DEBUG - 2016-05-22 03:47:32 --> Router Class Initialized
DEBUG - 2016-05-22 03:47:32 --> Output Class Initialized
DEBUG - 2016-05-22 03:47:32 --> Security Class Initialized
DEBUG - 2016-05-22 03:47:32 --> Input Class Initialized
DEBUG - 2016-05-22 03:47:32 --> XSS Filtering completed
DEBUG - 2016-05-22 03:47:32 --> XSS Filtering completed
DEBUG - 2016-05-22 03:47:32 --> XSS Filtering completed
DEBUG - 2016-05-22 03:47:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:47:32 --> Language Class Initialized
DEBUG - 2016-05-22 03:47:33 --> Loader Class Initialized
DEBUG - 2016-05-22 03:47:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:47:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:47:33 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:47:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:47:33 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:47:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:47:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:47:33 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:47:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:47:33 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:47:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:47:33 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:47:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:47:33 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:47:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:47:33 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:47:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:47:33 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:47:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:47:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:47:33 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:47:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:47:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:47:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:47:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:47:33 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:47:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:47:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:47:33 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:47:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:47:33 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:47:33 --> Session Class Initialized
DEBUG - 2016-05-22 03:47:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:47:33 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:47:33 --> Session routines successfully run
DEBUG - 2016-05-22 03:47:33 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:47:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:47:33 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:47:33 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:47:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:47:33 --> Controller Class Initialized
DEBUG - 2016-05-22 03:47:33 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:47:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:47:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:47:33 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:47:33 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:47:33 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:47:33 --> Model Class Initialized
DEBUG - 2016-05-22 03:47:33 --> Model Class Initialized
DEBUG - 2016-05-22 03:47:33 --> Model Class Initialized
DEBUG - 2016-05-22 03:47:33 --> Model Class Initialized
DEBUG - 2016-05-22 03:47:33 --> Model Class Initialized
DEBUG - 2016-05-22 03:47:33 --> Upload Class Initialized
DEBUG - 2016-05-22 03:47:33 --> Upload Class Initialized
DEBUG - 2016-05-22 03:47:33 --> Class Library loaded: LWS_Upload on upload
DEBUG - 2016-05-22 03:47:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 03:47:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-22 03:47:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 03:47:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 03:47:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 03:47:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 03:47:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 03:47:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 03:47:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 03:47:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 03:47:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 03:47:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 03:47:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 03:47:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 03:47:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-05-22 03:47:34 --> Final output sent to browser
DEBUG - 2016-05-22 03:47:34 --> Total execution time: 1.2512
DEBUG - 2016-05-22 03:47:47 --> Config Class Initialized
DEBUG - 2016-05-22 03:47:47 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:47:47 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:47:47 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:47:47 --> URI Class Initialized
DEBUG - 2016-05-22 03:47:47 --> Router Class Initialized
DEBUG - 2016-05-22 03:47:47 --> Output Class Initialized
DEBUG - 2016-05-22 03:47:48 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 03:47:48 --> Security Class Initialized
DEBUG - 2016-05-22 03:47:48 --> Input Class Initialized
DEBUG - 2016-05-22 03:47:48 --> XSS Filtering completed
DEBUG - 2016-05-22 03:47:48 --> XSS Filtering completed
DEBUG - 2016-05-22 03:47:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:47:48 --> Language Class Initialized
DEBUG - 2016-05-22 03:47:48 --> Loader Class Initialized
DEBUG - 2016-05-22 03:47:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:47:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:47:48 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:47:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:47:48 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:47:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:47:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:47:48 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:47:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:47:48 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:47:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:47:48 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:47:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:47:48 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:47:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:47:48 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:47:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:47:48 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:47:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:47:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:47:48 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:47:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:47:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:47:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:47:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:47:48 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:47:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:47:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:47:48 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:47:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:47:48 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:47:48 --> Session Class Initialized
DEBUG - 2016-05-22 03:47:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:47:48 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:47:48 --> Session routines successfully run
DEBUG - 2016-05-22 03:47:48 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:47:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:47:48 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:47:48 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:47:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:47:48 --> Controller Class Initialized
DEBUG - 2016-05-22 03:47:48 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:47:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:47:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:47:49 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:47:49 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:47:49 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:47:49 --> Model Class Initialized
DEBUG - 2016-05-22 03:47:49 --> Model Class Initialized
DEBUG - 2016-05-22 03:47:49 --> Model Class Initialized
DEBUG - 2016-05-22 03:47:49 --> Model Class Initialized
DEBUG - 2016-05-22 03:47:49 --> Model Class Initialized
ERROR - 2016-05-22 03:47:49 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-05-22 03:47:49 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-05-22 03:47:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 03:47:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-22 03:47:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 03:47:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 03:47:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 03:47:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 03:47:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 03:47:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 03:47:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 03:47:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 03:47:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 03:47:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 03:47:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 03:47:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 03:47:49 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-05-22 03:47:49 --> Final output sent to browser
DEBUG - 2016-05-22 03:47:49 --> Total execution time: 1.3982
DEBUG - 2016-05-22 03:58:09 --> Config Class Initialized
DEBUG - 2016-05-22 03:58:09 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:58:09 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:58:09 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:58:09 --> URI Class Initialized
DEBUG - 2016-05-22 03:58:09 --> Router Class Initialized
DEBUG - 2016-05-22 03:58:09 --> Output Class Initialized
DEBUG - 2016-05-22 03:58:10 --> Security Class Initialized
DEBUG - 2016-05-22 03:58:10 --> Input Class Initialized
DEBUG - 2016-05-22 03:58:10 --> XSS Filtering completed
DEBUG - 2016-05-22 03:58:10 --> XSS Filtering completed
DEBUG - 2016-05-22 03:58:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:58:10 --> Language Class Initialized
DEBUG - 2016-05-22 03:58:10 --> Loader Class Initialized
DEBUG - 2016-05-22 03:58:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:58:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:58:10 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:58:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:58:10 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:58:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:58:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:58:10 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:58:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:58:10 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:58:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:58:10 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:58:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:58:11 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:58:11 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:58:11 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:58:11 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:58:11 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:58:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:58:11 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:58:11 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:58:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:58:11 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:58:11 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:58:11 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:58:11 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:58:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:58:11 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:58:11 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:58:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:58:11 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:58:12 --> Session Class Initialized
DEBUG - 2016-05-22 03:58:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:58:12 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:58:12 --> Session routines successfully run
DEBUG - 2016-05-22 03:58:12 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:58:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:58:12 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:58:12 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:58:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:58:12 --> Controller Class Initialized
DEBUG - 2016-05-22 03:58:12 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:58:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:58:12 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:58:12 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:58:12 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:58:12 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:58:12 --> Model Class Initialized
DEBUG - 2016-05-22 03:58:12 --> Model Class Initialized
DEBUG - 2016-05-22 03:58:12 --> Model Class Initialized
DEBUG - 2016-05-22 03:58:13 --> Model Class Initialized
DEBUG - 2016-05-22 03:58:13 --> Model Class Initialized
DEBUG - 2016-05-22 03:58:13 --> Config Class Initialized
DEBUG - 2016-05-22 03:58:13 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:58:13 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:58:13 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:58:13 --> URI Class Initialized
DEBUG - 2016-05-22 03:58:13 --> Router Class Initialized
DEBUG - 2016-05-22 03:58:13 --> Output Class Initialized
DEBUG - 2016-05-22 03:58:13 --> Security Class Initialized
DEBUG - 2016-05-22 03:58:13 --> Input Class Initialized
DEBUG - 2016-05-22 03:58:13 --> XSS Filtering completed
DEBUG - 2016-05-22 03:58:13 --> XSS Filtering completed
DEBUG - 2016-05-22 03:58:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:58:13 --> Language Class Initialized
DEBUG - 2016-05-22 03:58:13 --> Loader Class Initialized
DEBUG - 2016-05-22 03:58:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:58:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:58:13 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:58:13 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:58:13 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:58:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:58:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:58:13 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:58:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:58:13 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:58:13 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:58:13 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:58:13 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:58:14 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:58:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:58:14 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:58:14 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:58:14 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:58:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:58:14 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:58:14 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:58:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:58:14 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:58:14 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:58:14 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:58:14 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:58:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:58:14 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:58:14 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:58:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:58:14 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:58:14 --> Session Class Initialized
DEBUG - 2016-05-22 03:58:14 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:58:14 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:58:14 --> Session routines successfully run
DEBUG - 2016-05-22 03:58:14 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:58:14 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:58:14 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:58:14 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:58:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:58:14 --> Controller Class Initialized
DEBUG - 2016-05-22 03:58:14 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:58:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:58:14 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:58:14 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:58:14 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:58:14 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:58:14 --> Model Class Initialized
DEBUG - 2016-05-22 03:58:14 --> Model Class Initialized
DEBUG - 2016-05-22 03:58:14 --> Model Class Initialized
DEBUG - 2016-05-22 03:58:14 --> Model Class Initialized
DEBUG - 2016-05-22 03:58:15 --> Model Class Initialized
DEBUG - 2016-05-22 03:58:15 --> Model Class Initialized
DEBUG - 2016-05-22 03:58:15 --> Model Class Initialized
DEBUG - 2016-05-22 03:58:15 --> Model Class Initialized
DEBUG - 2016-05-22 03:58:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-22 03:58:16 --> Pagination Class Initialized
DEBUG - 2016-05-22 03:58:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 03:58:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-05-22 03:58:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 03:58:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 03:58:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 03:58:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 03:58:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-22 03:58:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 03:58:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 03:58:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 03:58:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 03:58:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 03:58:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 03:58:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-22 03:58:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 03:58:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 03:58:16 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-05-22 03:58:16 --> Final output sent to browser
DEBUG - 2016-05-22 03:58:16 --> Total execution time: 2.8129
DEBUG - 2016-05-22 03:59:09 --> Config Class Initialized
DEBUG - 2016-05-22 03:59:09 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:59:09 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:59:09 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:59:09 --> URI Class Initialized
DEBUG - 2016-05-22 03:59:09 --> Router Class Initialized
DEBUG - 2016-05-22 03:59:09 --> Output Class Initialized
DEBUG - 2016-05-22 03:59:09 --> Security Class Initialized
DEBUG - 2016-05-22 03:59:09 --> Input Class Initialized
DEBUG - 2016-05-22 03:59:09 --> XSS Filtering completed
DEBUG - 2016-05-22 03:59:09 --> XSS Filtering completed
DEBUG - 2016-05-22 03:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:59:09 --> Language Class Initialized
DEBUG - 2016-05-22 03:59:09 --> Loader Class Initialized
DEBUG - 2016-05-22 03:59:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:59:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:59:09 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:59:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:59:09 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:59:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:59:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:59:09 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:59:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:59:09 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:59:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:59:09 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:59:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:59:09 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:59:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:59:09 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:59:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:59:10 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:59:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:59:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:59:10 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:59:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:59:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:59:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:59:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:59:10 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:59:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:59:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:59:10 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:59:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:59:10 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:59:10 --> Session Class Initialized
DEBUG - 2016-05-22 03:59:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:59:10 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:59:10 --> Session routines successfully run
DEBUG - 2016-05-22 03:59:10 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:59:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:59:10 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:59:10 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:59:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:59:10 --> Controller Class Initialized
DEBUG - 2016-05-22 03:59:10 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:59:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:59:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:59:10 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:59:10 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:59:10 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:59:10 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:10 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:10 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:10 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:10 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-22 03:59:10 --> Pagination Class Initialized
DEBUG - 2016-05-22 03:59:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 03:59:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-05-22 03:59:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 03:59:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 03:59:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 03:59:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 03:59:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-05-22 03:59:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 03:59:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 03:59:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 03:59:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 03:59:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 03:59:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 03:59:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-05-22 03:59:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 03:59:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 03:59:11 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5cf2ac055215a66f98ba4d6c33c8329d
DEBUG - 2016-05-22 03:59:11 --> Final output sent to browser
DEBUG - 2016-05-22 03:59:11 --> Total execution time: 1.3663
DEBUG - 2016-05-22 03:59:23 --> Config Class Initialized
DEBUG - 2016-05-22 03:59:23 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:59:23 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:59:23 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:59:23 --> URI Class Initialized
DEBUG - 2016-05-22 03:59:23 --> Router Class Initialized
DEBUG - 2016-05-22 03:59:23 --> Output Class Initialized
DEBUG - 2016-05-22 03:59:23 --> Security Class Initialized
DEBUG - 2016-05-22 03:59:23 --> Input Class Initialized
DEBUG - 2016-05-22 03:59:23 --> XSS Filtering completed
DEBUG - 2016-05-22 03:59:23 --> XSS Filtering completed
DEBUG - 2016-05-22 03:59:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:59:23 --> Language Class Initialized
DEBUG - 2016-05-22 03:59:23 --> Loader Class Initialized
DEBUG - 2016-05-22 03:59:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:59:23 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:59:23 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:59:23 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:59:23 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:59:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:59:23 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:59:23 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:59:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:59:23 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:59:23 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:59:23 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:59:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:59:23 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:59:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:59:23 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:59:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:59:23 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:59:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:59:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:59:24 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:59:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:59:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:59:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:59:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:59:24 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:59:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:59:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:59:24 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:59:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:59:24 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:59:24 --> Session Class Initialized
DEBUG - 2016-05-22 03:59:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:59:24 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:59:24 --> Session routines successfully run
DEBUG - 2016-05-22 03:59:24 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:59:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:59:24 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:59:24 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:59:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:59:24 --> Controller Class Initialized
DEBUG - 2016-05-22 03:59:24 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:59:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:59:24 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:59:24 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:59:24 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:59:24 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:59:24 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:24 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:24 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:24 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:24 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:24 --> Config Class Initialized
DEBUG - 2016-05-22 03:59:24 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:59:24 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:59:24 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:59:24 --> URI Class Initialized
DEBUG - 2016-05-22 03:59:24 --> Router Class Initialized
DEBUG - 2016-05-22 03:59:24 --> Output Class Initialized
DEBUG - 2016-05-22 03:59:24 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 03:59:24 --> Security Class Initialized
DEBUG - 2016-05-22 03:59:24 --> Input Class Initialized
DEBUG - 2016-05-22 03:59:24 --> XSS Filtering completed
DEBUG - 2016-05-22 03:59:24 --> XSS Filtering completed
DEBUG - 2016-05-22 03:59:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:59:24 --> Language Class Initialized
DEBUG - 2016-05-22 03:59:24 --> Loader Class Initialized
DEBUG - 2016-05-22 03:59:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:59:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:59:24 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:59:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:59:24 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:59:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:59:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:59:25 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:59:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:59:25 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:59:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:59:25 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:59:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:59:25 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:59:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:59:25 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:59:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:59:25 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:59:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:59:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:59:25 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:59:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:59:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:59:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:59:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:59:25 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:59:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:59:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:59:25 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:59:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:59:25 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:59:25 --> Session Class Initialized
DEBUG - 2016-05-22 03:59:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:59:25 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:59:25 --> Session routines successfully run
DEBUG - 2016-05-22 03:59:25 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:59:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:59:25 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:59:25 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:59:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:59:25 --> Controller Class Initialized
DEBUG - 2016-05-22 03:59:25 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:59:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:59:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:59:25 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:59:25 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:59:25 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:59:25 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:25 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:25 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:25 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:25 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:25 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:25 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:25 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-22 03:59:26 --> Pagination Class Initialized
DEBUG - 2016-05-22 03:59:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 03:59:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-05-22 03:59:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 03:59:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 03:59:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 03:59:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 03:59:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-22 03:59:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 03:59:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 03:59:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 03:59:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 03:59:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 03:59:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 03:59:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-22 03:59:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 03:59:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 03:59:26 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-05-22 03:59:26 --> Final output sent to browser
DEBUG - 2016-05-22 03:59:26 --> Total execution time: 1.4006
DEBUG - 2016-05-22 03:59:29 --> Config Class Initialized
DEBUG - 2016-05-22 03:59:29 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:59:29 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:59:29 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:59:29 --> URI Class Initialized
DEBUG - 2016-05-22 03:59:29 --> Router Class Initialized
DEBUG - 2016-05-22 03:59:29 --> Output Class Initialized
DEBUG - 2016-05-22 03:59:29 --> Security Class Initialized
DEBUG - 2016-05-22 03:59:30 --> Input Class Initialized
DEBUG - 2016-05-22 03:59:30 --> XSS Filtering completed
DEBUG - 2016-05-22 03:59:30 --> XSS Filtering completed
DEBUG - 2016-05-22 03:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:59:30 --> Language Class Initialized
DEBUG - 2016-05-22 03:59:30 --> Loader Class Initialized
DEBUG - 2016-05-22 03:59:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:59:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:59:30 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:59:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:59:30 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:59:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:59:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:59:30 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:59:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:59:30 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:59:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:59:30 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:59:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:59:30 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:59:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:59:30 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:59:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:59:30 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:59:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:59:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:59:30 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:59:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:59:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:59:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:59:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:59:30 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:59:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:59:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:59:30 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:59:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:59:30 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:59:30 --> Session Class Initialized
DEBUG - 2016-05-22 03:59:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:59:30 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:59:30 --> Session routines successfully run
DEBUG - 2016-05-22 03:59:30 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:59:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:59:30 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:59:30 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:59:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:59:30 --> Controller Class Initialized
DEBUG - 2016-05-22 03:59:30 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:59:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:59:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:59:30 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:59:30 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:59:30 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:59:31 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:31 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:31 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:31 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:31 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 03:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-22 03:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 03:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 03:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 03:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 03:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 03:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 03:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 03:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 03:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 03:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 03:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 03:59:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 03:59:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-05-22 03:59:31 --> Final output sent to browser
DEBUG - 2016-05-22 03:59:31 --> Total execution time: 1.2533
DEBUG - 2016-05-22 03:59:43 --> Config Class Initialized
DEBUG - 2016-05-22 03:59:43 --> Hooks Class Initialized
DEBUG - 2016-05-22 03:59:43 --> Utf8 Class Initialized
DEBUG - 2016-05-22 03:59:43 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 03:59:43 --> URI Class Initialized
DEBUG - 2016-05-22 03:59:43 --> Router Class Initialized
DEBUG - 2016-05-22 03:59:43 --> Output Class Initialized
DEBUG - 2016-05-22 03:59:43 --> Security Class Initialized
DEBUG - 2016-05-22 03:59:43 --> Input Class Initialized
DEBUG - 2016-05-22 03:59:43 --> XSS Filtering completed
DEBUG - 2016-05-22 03:59:43 --> XSS Filtering completed
DEBUG - 2016-05-22 03:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 03:59:43 --> Language Class Initialized
DEBUG - 2016-05-22 03:59:44 --> Loader Class Initialized
DEBUG - 2016-05-22 03:59:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 03:59:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 03:59:44 --> Helper loaded: url_helper
DEBUG - 2016-05-22 03:59:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 03:59:44 --> Helper loaded: file_helper
DEBUG - 2016-05-22 03:59:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:59:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 03:59:44 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 03:59:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 03:59:44 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 03:59:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 03:59:44 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:59:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 03:59:44 --> Helper loaded: common_helper
DEBUG - 2016-05-22 03:59:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 03:59:44 --> Helper loaded: form_helper
DEBUG - 2016-05-22 03:59:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 03:59:44 --> Helper loaded: security_helper
DEBUG - 2016-05-22 03:59:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:59:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 03:59:44 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 03:59:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 03:59:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 03:59:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 03:59:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 03:59:44 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 03:59:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:59:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 03:59:44 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 03:59:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 03:59:44 --> Database Driver Class Initialized
DEBUG - 2016-05-22 03:59:44 --> Session Class Initialized
DEBUG - 2016-05-22 03:59:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 03:59:44 --> Helper loaded: string_helper
DEBUG - 2016-05-22 03:59:44 --> Session routines successfully run
DEBUG - 2016-05-22 03:59:44 --> Native_session Class Initialized
DEBUG - 2016-05-22 03:59:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 03:59:44 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:59:44 --> Form Validation Class Initialized
DEBUG - 2016-05-22 03:59:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 03:59:44 --> Controller Class Initialized
DEBUG - 2016-05-22 03:59:44 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 03:59:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 03:59:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 03:59:44 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:59:44 --> Carabiner: library configured.
DEBUG - 2016-05-22 03:59:44 --> User Agent Class Initialized
DEBUG - 2016-05-22 03:59:44 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:44 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:44 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:44 --> Model Class Initialized
DEBUG - 2016-05-22 03:59:45 --> Model Class Initialized
ERROR - 2016-05-22 03:59:45 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-05-22 03:59:45 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-05-22 03:59:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 03:59:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-22 03:59:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 03:59:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 03:59:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 03:59:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 03:59:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 03:59:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 03:59:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 03:59:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 03:59:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 03:59:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 03:59:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 03:59:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 03:59:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-05-22 03:59:45 --> Final output sent to browser
DEBUG - 2016-05-22 03:59:45 --> Total execution time: 1.2820
DEBUG - 2016-05-22 04:01:03 --> Config Class Initialized
DEBUG - 2016-05-22 04:01:03 --> Hooks Class Initialized
DEBUG - 2016-05-22 04:01:03 --> Utf8 Class Initialized
DEBUG - 2016-05-22 04:01:03 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 04:01:03 --> URI Class Initialized
DEBUG - 2016-05-22 04:01:03 --> Router Class Initialized
DEBUG - 2016-05-22 04:01:03 --> Output Class Initialized
DEBUG - 2016-05-22 04:01:03 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 04:01:03 --> Security Class Initialized
DEBUG - 2016-05-22 04:01:03 --> Input Class Initialized
DEBUG - 2016-05-22 04:01:03 --> XSS Filtering completed
DEBUG - 2016-05-22 04:01:03 --> XSS Filtering completed
DEBUG - 2016-05-22 04:01:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 04:01:03 --> Language Class Initialized
DEBUG - 2016-05-22 04:01:03 --> Loader Class Initialized
DEBUG - 2016-05-22 04:01:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 04:01:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 04:01:03 --> Helper loaded: url_helper
DEBUG - 2016-05-22 04:01:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 04:01:03 --> Helper loaded: file_helper
DEBUG - 2016-05-22 04:01:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:01:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 04:01:04 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 04:01:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:01:04 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 04:01:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 04:01:04 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:01:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 04:01:04 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:01:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 04:01:04 --> Helper loaded: form_helper
DEBUG - 2016-05-22 04:01:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 04:01:04 --> Helper loaded: security_helper
DEBUG - 2016-05-22 04:01:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:01:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 04:01:04 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 04:01:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:01:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 04:01:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 04:01:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 04:01:04 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 04:01:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:01:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 04:01:04 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 04:01:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:01:04 --> Database Driver Class Initialized
DEBUG - 2016-05-22 04:01:04 --> Session Class Initialized
DEBUG - 2016-05-22 04:01:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 04:01:04 --> Helper loaded: string_helper
DEBUG - 2016-05-22 04:01:04 --> Session routines successfully run
DEBUG - 2016-05-22 04:01:04 --> Native_session Class Initialized
DEBUG - 2016-05-22 04:01:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 04:01:04 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:01:04 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:01:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 04:01:04 --> Controller Class Initialized
DEBUG - 2016-05-22 04:01:04 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 04:01:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 04:01:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 04:01:04 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:01:04 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:01:04 --> User Agent Class Initialized
DEBUG - 2016-05-22 04:01:04 --> Model Class Initialized
DEBUG - 2016-05-22 04:01:04 --> Model Class Initialized
DEBUG - 2016-05-22 04:01:04 --> Model Class Initialized
DEBUG - 2016-05-22 04:01:04 --> Model Class Initialized
DEBUG - 2016-05-22 04:01:04 --> Model Class Initialized
DEBUG - 2016-05-22 04:01:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 04:01:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-22 04:01:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:01:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:01:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:01:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:01:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:01:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:01:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:01:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:01:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:01:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:01:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:01:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:01:05 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-05-22 04:01:05 --> Final output sent to browser
DEBUG - 2016-05-22 04:01:05 --> Total execution time: 1.3371
DEBUG - 2016-05-22 04:01:17 --> Config Class Initialized
DEBUG - 2016-05-22 04:01:17 --> Hooks Class Initialized
DEBUG - 2016-05-22 04:01:17 --> Utf8 Class Initialized
DEBUG - 2016-05-22 04:01:17 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 04:01:17 --> URI Class Initialized
DEBUG - 2016-05-22 04:01:17 --> Router Class Initialized
DEBUG - 2016-05-22 04:01:17 --> Output Class Initialized
DEBUG - 2016-05-22 04:01:17 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 04:01:17 --> Security Class Initialized
DEBUG - 2016-05-22 04:01:17 --> Input Class Initialized
DEBUG - 2016-05-22 04:01:17 --> XSS Filtering completed
DEBUG - 2016-05-22 04:01:17 --> XSS Filtering completed
DEBUG - 2016-05-22 04:01:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 04:01:17 --> Language Class Initialized
DEBUG - 2016-05-22 04:01:17 --> Loader Class Initialized
DEBUG - 2016-05-22 04:01:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 04:01:17 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 04:01:17 --> Helper loaded: url_helper
DEBUG - 2016-05-22 04:01:17 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 04:01:17 --> Helper loaded: file_helper
DEBUG - 2016-05-22 04:01:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:01:17 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 04:01:17 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 04:01:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:01:17 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 04:01:17 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 04:01:17 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:01:17 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 04:01:17 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:01:18 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 04:01:18 --> Helper loaded: form_helper
DEBUG - 2016-05-22 04:01:18 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 04:01:18 --> Helper loaded: security_helper
DEBUG - 2016-05-22 04:01:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:01:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 04:01:18 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 04:01:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:01:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 04:01:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 04:01:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 04:01:18 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 04:01:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:01:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 04:01:18 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 04:01:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:01:18 --> Database Driver Class Initialized
DEBUG - 2016-05-22 04:01:18 --> Session Class Initialized
DEBUG - 2016-05-22 04:01:18 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 04:01:18 --> Helper loaded: string_helper
DEBUG - 2016-05-22 04:01:18 --> Session routines successfully run
DEBUG - 2016-05-22 04:01:18 --> Native_session Class Initialized
DEBUG - 2016-05-22 04:01:18 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 04:01:18 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:01:18 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:01:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 04:01:18 --> Controller Class Initialized
DEBUG - 2016-05-22 04:01:18 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 04:01:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 04:01:18 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 04:01:18 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:01:18 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:01:18 --> User Agent Class Initialized
DEBUG - 2016-05-22 04:01:18 --> Model Class Initialized
DEBUG - 2016-05-22 04:01:18 --> Model Class Initialized
DEBUG - 2016-05-22 04:01:18 --> Model Class Initialized
DEBUG - 2016-05-22 04:01:18 --> Model Class Initialized
DEBUG - 2016-05-22 04:01:18 --> Model Class Initialized
ERROR - 2016-05-22 04:01:18 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-05-22 04:01:18 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-05-22 04:01:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 04:01:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-22 04:01:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:01:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:01:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:01:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:01:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:01:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:01:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:01:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:01:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:01:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:01:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:01:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:01:19 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-05-22 04:01:19 --> Final output sent to browser
DEBUG - 2016-05-22 04:01:19 --> Total execution time: 1.3656
DEBUG - 2016-05-22 04:01:46 --> Config Class Initialized
DEBUG - 2016-05-22 04:01:46 --> Hooks Class Initialized
DEBUG - 2016-05-22 04:01:46 --> Utf8 Class Initialized
DEBUG - 2016-05-22 04:01:46 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 04:01:46 --> URI Class Initialized
DEBUG - 2016-05-22 04:01:46 --> Router Class Initialized
DEBUG - 2016-05-22 04:01:46 --> Output Class Initialized
DEBUG - 2016-05-22 04:01:46 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 04:01:46 --> Security Class Initialized
DEBUG - 2016-05-22 04:01:46 --> Input Class Initialized
DEBUG - 2016-05-22 04:01:46 --> XSS Filtering completed
DEBUG - 2016-05-22 04:01:46 --> XSS Filtering completed
DEBUG - 2016-05-22 04:01:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 04:01:46 --> Language Class Initialized
DEBUG - 2016-05-22 04:01:46 --> Loader Class Initialized
DEBUG - 2016-05-22 04:01:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 04:01:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 04:01:46 --> Helper loaded: url_helper
DEBUG - 2016-05-22 04:01:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 04:01:46 --> Helper loaded: file_helper
DEBUG - 2016-05-22 04:01:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:01:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 04:01:46 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 04:01:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:01:46 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 04:01:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 04:01:46 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:01:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 04:01:46 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:01:47 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 04:01:47 --> Helper loaded: form_helper
DEBUG - 2016-05-22 04:01:47 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 04:01:47 --> Helper loaded: security_helper
DEBUG - 2016-05-22 04:01:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:01:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 04:01:47 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 04:01:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:01:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 04:01:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 04:01:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 04:01:47 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 04:01:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:01:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 04:01:47 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 04:01:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:01:47 --> Database Driver Class Initialized
DEBUG - 2016-05-22 04:01:47 --> Session Class Initialized
DEBUG - 2016-05-22 04:01:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 04:01:47 --> Helper loaded: string_helper
DEBUG - 2016-05-22 04:01:47 --> Session routines successfully run
DEBUG - 2016-05-22 04:01:47 --> Native_session Class Initialized
DEBUG - 2016-05-22 04:01:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 04:01:47 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:01:47 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:01:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 04:01:47 --> Controller Class Initialized
DEBUG - 2016-05-22 04:01:47 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 04:01:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 04:01:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 04:01:47 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:01:47 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:01:47 --> User Agent Class Initialized
DEBUG - 2016-05-22 04:01:47 --> Model Class Initialized
DEBUG - 2016-05-22 04:01:47 --> Model Class Initialized
DEBUG - 2016-05-22 04:01:47 --> Model Class Initialized
DEBUG - 2016-05-22 04:01:47 --> Model Class Initialized
DEBUG - 2016-05-22 04:01:47 --> Model Class Initialized
DEBUG - 2016-05-22 04:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 04:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-22 04:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:01:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:01:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:01:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:01:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-05-22 04:01:48 --> Final output sent to browser
DEBUG - 2016-05-22 04:01:48 --> Total execution time: 1.3739
DEBUG - 2016-05-22 04:02:00 --> Config Class Initialized
DEBUG - 2016-05-22 04:02:00 --> Hooks Class Initialized
DEBUG - 2016-05-22 04:02:00 --> Utf8 Class Initialized
DEBUG - 2016-05-22 04:02:00 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 04:02:00 --> URI Class Initialized
DEBUG - 2016-05-22 04:02:00 --> Router Class Initialized
DEBUG - 2016-05-22 04:02:00 --> Output Class Initialized
DEBUG - 2016-05-22 04:02:00 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 04:02:00 --> Security Class Initialized
DEBUG - 2016-05-22 04:02:00 --> Input Class Initialized
DEBUG - 2016-05-22 04:02:00 --> XSS Filtering completed
DEBUG - 2016-05-22 04:02:00 --> XSS Filtering completed
DEBUG - 2016-05-22 04:02:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 04:02:00 --> Language Class Initialized
DEBUG - 2016-05-22 04:02:00 --> Loader Class Initialized
DEBUG - 2016-05-22 04:02:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 04:02:00 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 04:02:00 --> Helper loaded: url_helper
DEBUG - 2016-05-22 04:02:00 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 04:02:00 --> Helper loaded: file_helper
DEBUG - 2016-05-22 04:02:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:02:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 04:02:00 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 04:02:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:02:00 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 04:02:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 04:02:00 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:02:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 04:02:01 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:02:01 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 04:02:01 --> Helper loaded: form_helper
DEBUG - 2016-05-22 04:02:01 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 04:02:01 --> Helper loaded: security_helper
DEBUG - 2016-05-22 04:02:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:02:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 04:02:01 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 04:02:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:02:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 04:02:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 04:02:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 04:02:01 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 04:02:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:02:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 04:02:01 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 04:02:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:02:01 --> Database Driver Class Initialized
DEBUG - 2016-05-22 04:02:01 --> Session Class Initialized
DEBUG - 2016-05-22 04:02:01 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 04:02:01 --> Helper loaded: string_helper
DEBUG - 2016-05-22 04:02:01 --> Session routines successfully run
DEBUG - 2016-05-22 04:02:01 --> Native_session Class Initialized
DEBUG - 2016-05-22 04:02:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 04:02:01 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:02:01 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:02:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 04:02:01 --> Controller Class Initialized
DEBUG - 2016-05-22 04:02:01 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 04:02:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 04:02:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 04:02:02 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:02:02 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:02:02 --> User Agent Class Initialized
DEBUG - 2016-05-22 04:02:02 --> Model Class Initialized
DEBUG - 2016-05-22 04:02:02 --> Model Class Initialized
DEBUG - 2016-05-22 04:02:02 --> Model Class Initialized
DEBUG - 2016-05-22 04:02:02 --> Model Class Initialized
DEBUG - 2016-05-22 04:02:02 --> Model Class Initialized
ERROR - 2016-05-22 04:02:02 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-05-22 04:02:02 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-05-22 04:02:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 04:02:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-22 04:02:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:02:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:02:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:02:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:02:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:02:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:02:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:02:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:02:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:02:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:02:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:02:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:02:02 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-05-22 04:02:02 --> Final output sent to browser
DEBUG - 2016-05-22 04:02:02 --> Total execution time: 1.8072
DEBUG - 2016-05-22 04:02:15 --> Config Class Initialized
DEBUG - 2016-05-22 04:02:15 --> Hooks Class Initialized
DEBUG - 2016-05-22 04:02:15 --> Utf8 Class Initialized
DEBUG - 2016-05-22 04:02:15 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 04:02:15 --> URI Class Initialized
DEBUG - 2016-05-22 04:02:15 --> Router Class Initialized
DEBUG - 2016-05-22 04:02:15 --> Output Class Initialized
DEBUG - 2016-05-22 04:02:15 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 04:02:15 --> Security Class Initialized
DEBUG - 2016-05-22 04:02:15 --> Input Class Initialized
DEBUG - 2016-05-22 04:02:15 --> XSS Filtering completed
DEBUG - 2016-05-22 04:02:15 --> XSS Filtering completed
DEBUG - 2016-05-22 04:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 04:02:15 --> Language Class Initialized
DEBUG - 2016-05-22 04:02:15 --> Loader Class Initialized
DEBUG - 2016-05-22 04:02:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 04:02:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 04:02:15 --> Helper loaded: url_helper
DEBUG - 2016-05-22 04:02:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 04:02:16 --> Helper loaded: file_helper
DEBUG - 2016-05-22 04:02:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:02:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 04:02:16 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 04:02:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:02:16 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 04:02:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 04:02:16 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:02:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 04:02:16 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:02:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 04:02:16 --> Helper loaded: form_helper
DEBUG - 2016-05-22 04:02:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 04:02:16 --> Helper loaded: security_helper
DEBUG - 2016-05-22 04:02:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:02:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 04:02:16 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 04:02:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:02:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 04:02:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 04:02:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 04:02:16 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 04:02:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:02:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 04:02:16 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 04:02:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:02:16 --> Database Driver Class Initialized
DEBUG - 2016-05-22 04:02:16 --> Session Class Initialized
DEBUG - 2016-05-22 04:02:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 04:02:16 --> Helper loaded: string_helper
DEBUG - 2016-05-22 04:02:16 --> Session routines successfully run
DEBUG - 2016-05-22 04:02:16 --> Native_session Class Initialized
DEBUG - 2016-05-22 04:02:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 04:02:16 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:02:16 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:02:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 04:02:16 --> Controller Class Initialized
DEBUG - 2016-05-22 04:02:16 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 04:02:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 04:02:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 04:02:16 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:02:16 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:02:16 --> User Agent Class Initialized
DEBUG - 2016-05-22 04:02:16 --> Model Class Initialized
DEBUG - 2016-05-22 04:02:16 --> Model Class Initialized
DEBUG - 2016-05-22 04:02:16 --> Model Class Initialized
DEBUG - 2016-05-22 04:02:16 --> Model Class Initialized
DEBUG - 2016-05-22 04:02:16 --> Model Class Initialized
DEBUG - 2016-05-22 04:02:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 04:02:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-22 04:02:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:02:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:02:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:02:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:02:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:02:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:02:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:02:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:02:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:02:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:02:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:02:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:02:17 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-05-22 04:02:17 --> Final output sent to browser
DEBUG - 2016-05-22 04:02:17 --> Total execution time: 1.4045
DEBUG - 2016-05-22 04:02:29 --> Config Class Initialized
DEBUG - 2016-05-22 04:02:29 --> Hooks Class Initialized
DEBUG - 2016-05-22 04:02:29 --> Utf8 Class Initialized
DEBUG - 2016-05-22 04:02:29 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 04:02:29 --> URI Class Initialized
DEBUG - 2016-05-22 04:02:29 --> Router Class Initialized
DEBUG - 2016-05-22 04:02:29 --> Output Class Initialized
DEBUG - 2016-05-22 04:02:29 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 04:02:29 --> Security Class Initialized
DEBUG - 2016-05-22 04:02:29 --> Input Class Initialized
DEBUG - 2016-05-22 04:02:29 --> XSS Filtering completed
DEBUG - 2016-05-22 04:02:29 --> XSS Filtering completed
DEBUG - 2016-05-22 04:02:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 04:02:29 --> Language Class Initialized
DEBUG - 2016-05-22 04:02:29 --> Loader Class Initialized
DEBUG - 2016-05-22 04:02:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 04:02:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 04:02:30 --> Helper loaded: url_helper
DEBUG - 2016-05-22 04:02:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 04:02:30 --> Helper loaded: file_helper
DEBUG - 2016-05-22 04:02:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:02:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 04:02:30 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 04:02:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:02:30 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 04:02:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 04:02:30 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:02:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 04:02:30 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:02:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 04:02:30 --> Helper loaded: form_helper
DEBUG - 2016-05-22 04:02:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 04:02:30 --> Helper loaded: security_helper
DEBUG - 2016-05-22 04:02:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:02:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 04:02:30 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 04:02:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:02:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 04:02:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 04:02:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 04:02:30 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 04:02:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:02:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 04:02:30 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 04:02:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:02:30 --> Database Driver Class Initialized
DEBUG - 2016-05-22 04:02:30 --> Session Class Initialized
DEBUG - 2016-05-22 04:02:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 04:02:30 --> Helper loaded: string_helper
DEBUG - 2016-05-22 04:02:30 --> Session routines successfully run
DEBUG - 2016-05-22 04:02:30 --> Native_session Class Initialized
DEBUG - 2016-05-22 04:02:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 04:02:30 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:02:30 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:02:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 04:02:30 --> Controller Class Initialized
DEBUG - 2016-05-22 04:02:30 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 04:02:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 04:02:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 04:02:30 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:02:30 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:02:30 --> User Agent Class Initialized
DEBUG - 2016-05-22 04:02:30 --> Model Class Initialized
DEBUG - 2016-05-22 04:02:31 --> Model Class Initialized
DEBUG - 2016-05-22 04:02:31 --> Model Class Initialized
DEBUG - 2016-05-22 04:02:31 --> Model Class Initialized
DEBUG - 2016-05-22 04:02:31 --> Model Class Initialized
ERROR - 2016-05-22 04:02:31 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-05-22 04:02:31 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-05-22 04:02:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 04:02:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-22 04:02:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:02:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:02:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:02:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:02:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:02:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:02:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:02:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:02:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:02:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:02:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:02:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:02:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-05-22 04:02:31 --> Final output sent to browser
DEBUG - 2016-05-22 04:02:31 --> Total execution time: 1.4072
DEBUG - 2016-05-22 04:02:41 --> Config Class Initialized
DEBUG - 2016-05-22 04:02:41 --> Hooks Class Initialized
DEBUG - 2016-05-22 04:02:41 --> Utf8 Class Initialized
DEBUG - 2016-05-22 04:02:41 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 04:02:41 --> URI Class Initialized
DEBUG - 2016-05-22 04:02:41 --> Router Class Initialized
DEBUG - 2016-05-22 04:02:42 --> Output Class Initialized
DEBUG - 2016-05-22 04:02:42 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 04:02:42 --> Security Class Initialized
DEBUG - 2016-05-22 04:02:42 --> Input Class Initialized
DEBUG - 2016-05-22 04:02:42 --> XSS Filtering completed
DEBUG - 2016-05-22 04:02:42 --> XSS Filtering completed
DEBUG - 2016-05-22 04:02:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 04:02:42 --> Language Class Initialized
DEBUG - 2016-05-22 04:02:42 --> Loader Class Initialized
DEBUG - 2016-05-22 04:02:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 04:02:42 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 04:02:42 --> Helper loaded: url_helper
DEBUG - 2016-05-22 04:02:42 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 04:02:42 --> Helper loaded: file_helper
DEBUG - 2016-05-22 04:02:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:02:42 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 04:02:42 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 04:02:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:02:42 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 04:02:42 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 04:02:42 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:02:42 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 04:02:42 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:02:42 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 04:02:42 --> Helper loaded: form_helper
DEBUG - 2016-05-22 04:02:42 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 04:02:42 --> Helper loaded: security_helper
DEBUG - 2016-05-22 04:02:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:02:42 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 04:02:42 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 04:02:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:02:42 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 04:02:42 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 04:02:42 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 04:02:42 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 04:02:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:02:42 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 04:02:42 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 04:02:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:02:42 --> Database Driver Class Initialized
DEBUG - 2016-05-22 04:02:42 --> Session Class Initialized
DEBUG - 2016-05-22 04:02:42 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 04:02:42 --> Helper loaded: string_helper
DEBUG - 2016-05-22 04:02:42 --> Session routines successfully run
DEBUG - 2016-05-22 04:02:42 --> Native_session Class Initialized
DEBUG - 2016-05-22 04:02:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 04:02:42 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:02:42 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:02:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 04:02:43 --> Controller Class Initialized
DEBUG - 2016-05-22 04:02:43 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 04:02:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 04:02:43 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 04:02:43 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:02:43 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:02:43 --> User Agent Class Initialized
DEBUG - 2016-05-22 04:02:43 --> Model Class Initialized
DEBUG - 2016-05-22 04:02:43 --> Model Class Initialized
DEBUG - 2016-05-22 04:02:43 --> Model Class Initialized
DEBUG - 2016-05-22 04:02:43 --> Model Class Initialized
DEBUG - 2016-05-22 04:02:43 --> Model Class Initialized
DEBUG - 2016-05-22 04:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 04:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-22 04:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:02:43 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-05-22 04:02:43 --> Final output sent to browser
DEBUG - 2016-05-22 04:02:43 --> Total execution time: 1.4208
DEBUG - 2016-05-22 04:02:55 --> Config Class Initialized
DEBUG - 2016-05-22 04:02:55 --> Hooks Class Initialized
DEBUG - 2016-05-22 04:02:55 --> Utf8 Class Initialized
DEBUG - 2016-05-22 04:02:55 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 04:02:55 --> URI Class Initialized
DEBUG - 2016-05-22 04:02:55 --> Router Class Initialized
DEBUG - 2016-05-22 04:02:55 --> Output Class Initialized
DEBUG - 2016-05-22 04:02:56 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 04:02:56 --> Security Class Initialized
DEBUG - 2016-05-22 04:02:56 --> Input Class Initialized
DEBUG - 2016-05-22 04:02:56 --> XSS Filtering completed
DEBUG - 2016-05-22 04:02:56 --> XSS Filtering completed
DEBUG - 2016-05-22 04:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 04:02:56 --> Language Class Initialized
DEBUG - 2016-05-22 04:02:56 --> Loader Class Initialized
DEBUG - 2016-05-22 04:02:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 04:02:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 04:02:56 --> Helper loaded: url_helper
DEBUG - 2016-05-22 04:02:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 04:02:56 --> Helper loaded: file_helper
DEBUG - 2016-05-22 04:02:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:02:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 04:02:56 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 04:02:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:02:56 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 04:02:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 04:02:56 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:02:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 04:02:56 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:02:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 04:02:56 --> Helper loaded: form_helper
DEBUG - 2016-05-22 04:02:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 04:02:56 --> Helper loaded: security_helper
DEBUG - 2016-05-22 04:02:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:02:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 04:02:56 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 04:02:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:02:56 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 04:02:56 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 04:02:56 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 04:02:56 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 04:02:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:02:56 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 04:02:56 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 04:02:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:02:56 --> Database Driver Class Initialized
DEBUG - 2016-05-22 04:02:56 --> Session Class Initialized
DEBUG - 2016-05-22 04:02:56 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 04:02:56 --> Helper loaded: string_helper
DEBUG - 2016-05-22 04:02:56 --> Session routines successfully run
DEBUG - 2016-05-22 04:02:56 --> Native_session Class Initialized
DEBUG - 2016-05-22 04:02:56 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 04:02:56 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:02:56 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:02:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 04:02:57 --> Controller Class Initialized
DEBUG - 2016-05-22 04:02:57 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 04:02:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 04:02:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 04:02:57 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:02:57 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:02:57 --> User Agent Class Initialized
DEBUG - 2016-05-22 04:02:57 --> Model Class Initialized
DEBUG - 2016-05-22 04:02:57 --> Model Class Initialized
DEBUG - 2016-05-22 04:02:57 --> Model Class Initialized
DEBUG - 2016-05-22 04:02:57 --> Model Class Initialized
DEBUG - 2016-05-22 04:02:57 --> Model Class Initialized
ERROR - 2016-05-22 04:02:57 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-05-22 04:02:57 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-05-22 04:02:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 04:02:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-22 04:02:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:02:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:02:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:02:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:02:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:02:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:02:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:02:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:02:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:02:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:02:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:02:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:02:57 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-05-22 04:02:57 --> Final output sent to browser
DEBUG - 2016-05-22 04:02:57 --> Total execution time: 1.4652
DEBUG - 2016-05-22 04:03:04 --> Config Class Initialized
DEBUG - 2016-05-22 04:03:04 --> Hooks Class Initialized
DEBUG - 2016-05-22 04:03:04 --> Utf8 Class Initialized
DEBUG - 2016-05-22 04:03:04 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 04:03:04 --> URI Class Initialized
DEBUG - 2016-05-22 04:03:04 --> Router Class Initialized
DEBUG - 2016-05-22 04:03:04 --> Output Class Initialized
DEBUG - 2016-05-22 04:03:05 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 04:03:05 --> Security Class Initialized
DEBUG - 2016-05-22 04:03:05 --> Input Class Initialized
DEBUG - 2016-05-22 04:03:05 --> XSS Filtering completed
DEBUG - 2016-05-22 04:03:05 --> XSS Filtering completed
DEBUG - 2016-05-22 04:03:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 04:03:05 --> Language Class Initialized
DEBUG - 2016-05-22 04:03:05 --> Loader Class Initialized
DEBUG - 2016-05-22 04:03:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 04:03:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 04:03:05 --> Helper loaded: url_helper
DEBUG - 2016-05-22 04:03:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 04:03:05 --> Helper loaded: file_helper
DEBUG - 2016-05-22 04:03:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:03:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 04:03:05 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 04:03:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:03:05 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 04:03:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 04:03:05 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:03:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 04:03:05 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:03:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 04:03:05 --> Helper loaded: form_helper
DEBUG - 2016-05-22 04:03:05 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 04:03:05 --> Helper loaded: security_helper
DEBUG - 2016-05-22 04:03:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:03:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 04:03:05 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 04:03:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:03:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 04:03:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 04:03:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 04:03:05 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 04:03:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:03:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 04:03:05 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 04:03:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:03:05 --> Database Driver Class Initialized
DEBUG - 2016-05-22 04:03:05 --> Session Class Initialized
DEBUG - 2016-05-22 04:03:05 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 04:03:05 --> Helper loaded: string_helper
DEBUG - 2016-05-22 04:03:05 --> Session routines successfully run
DEBUG - 2016-05-22 04:03:05 --> Native_session Class Initialized
DEBUG - 2016-05-22 04:03:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 04:03:05 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:03:05 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:03:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 04:03:06 --> Controller Class Initialized
DEBUG - 2016-05-22 04:03:06 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 04:03:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 04:03:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 04:03:06 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:03:06 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:03:06 --> User Agent Class Initialized
DEBUG - 2016-05-22 04:03:06 --> Model Class Initialized
DEBUG - 2016-05-22 04:03:06 --> Model Class Initialized
DEBUG - 2016-05-22 04:03:06 --> Model Class Initialized
DEBUG - 2016-05-22 04:03:06 --> Model Class Initialized
DEBUG - 2016-05-22 04:03:06 --> Model Class Initialized
DEBUG - 2016-05-22 04:03:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-22 04:03:06 --> Pagination Class Initialized
DEBUG - 2016-05-22 04:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 04:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-05-22 04:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-05-22 04:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-05-22 04:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:03:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:03:06 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5cf2ac055215a66f98ba4d6c33c8329d
DEBUG - 2016-05-22 04:03:06 --> Final output sent to browser
DEBUG - 2016-05-22 04:03:06 --> Total execution time: 1.4863
DEBUG - 2016-05-22 04:03:18 --> Config Class Initialized
DEBUG - 2016-05-22 04:03:18 --> Hooks Class Initialized
DEBUG - 2016-05-22 04:03:18 --> Utf8 Class Initialized
DEBUG - 2016-05-22 04:03:19 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 04:03:19 --> URI Class Initialized
DEBUG - 2016-05-22 04:03:19 --> Router Class Initialized
DEBUG - 2016-05-22 04:03:19 --> Output Class Initialized
DEBUG - 2016-05-22 04:03:19 --> Security Class Initialized
DEBUG - 2016-05-22 04:03:19 --> Input Class Initialized
DEBUG - 2016-05-22 04:03:19 --> XSS Filtering completed
DEBUG - 2016-05-22 04:03:19 --> XSS Filtering completed
DEBUG - 2016-05-22 04:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 04:03:19 --> Language Class Initialized
DEBUG - 2016-05-22 04:03:19 --> Loader Class Initialized
DEBUG - 2016-05-22 04:03:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 04:03:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 04:03:19 --> Helper loaded: url_helper
DEBUG - 2016-05-22 04:03:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 04:03:19 --> Helper loaded: file_helper
DEBUG - 2016-05-22 04:03:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:03:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 04:03:19 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 04:03:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:03:19 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 04:03:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 04:03:19 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:03:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 04:03:19 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:03:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 04:03:19 --> Helper loaded: form_helper
DEBUG - 2016-05-22 04:03:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 04:03:19 --> Helper loaded: security_helper
DEBUG - 2016-05-22 04:03:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:03:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 04:03:19 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 04:03:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:03:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 04:03:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 04:03:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 04:03:19 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 04:03:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:03:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 04:03:19 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 04:03:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:03:19 --> Database Driver Class Initialized
DEBUG - 2016-05-22 04:03:19 --> Session Class Initialized
DEBUG - 2016-05-22 04:03:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 04:03:19 --> Helper loaded: string_helper
DEBUG - 2016-05-22 04:03:20 --> Session routines successfully run
DEBUG - 2016-05-22 04:03:20 --> Native_session Class Initialized
DEBUG - 2016-05-22 04:03:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 04:03:20 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:03:20 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:03:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 04:03:20 --> Controller Class Initialized
DEBUG - 2016-05-22 04:03:20 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 04:03:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 04:03:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 04:03:20 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:03:20 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:03:20 --> User Agent Class Initialized
DEBUG - 2016-05-22 04:03:20 --> Model Class Initialized
DEBUG - 2016-05-22 04:03:20 --> Model Class Initialized
DEBUG - 2016-05-22 04:03:20 --> Model Class Initialized
DEBUG - 2016-05-22 04:03:20 --> Model Class Initialized
DEBUG - 2016-05-22 04:03:20 --> Model Class Initialized
DEBUG - 2016-05-22 04:03:20 --> Config Class Initialized
DEBUG - 2016-05-22 04:03:20 --> Hooks Class Initialized
DEBUG - 2016-05-22 04:03:20 --> Utf8 Class Initialized
DEBUG - 2016-05-22 04:03:20 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 04:03:20 --> URI Class Initialized
DEBUG - 2016-05-22 04:03:20 --> Router Class Initialized
DEBUG - 2016-05-22 04:03:20 --> Output Class Initialized
DEBUG - 2016-05-22 04:03:20 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 04:03:20 --> Security Class Initialized
DEBUG - 2016-05-22 04:03:20 --> Input Class Initialized
DEBUG - 2016-05-22 04:03:20 --> XSS Filtering completed
DEBUG - 2016-05-22 04:03:20 --> XSS Filtering completed
DEBUG - 2016-05-22 04:03:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 04:03:20 --> Language Class Initialized
DEBUG - 2016-05-22 04:03:20 --> Loader Class Initialized
DEBUG - 2016-05-22 04:03:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 04:03:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 04:03:20 --> Helper loaded: url_helper
DEBUG - 2016-05-22 04:03:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 04:03:20 --> Helper loaded: file_helper
DEBUG - 2016-05-22 04:03:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:03:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 04:03:20 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 04:03:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:03:20 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 04:03:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 04:03:20 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:03:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 04:03:21 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:03:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 04:03:21 --> Helper loaded: form_helper
DEBUG - 2016-05-22 04:03:21 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 04:03:21 --> Helper loaded: security_helper
DEBUG - 2016-05-22 04:03:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:03:21 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 04:03:21 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 04:03:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:03:21 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 04:03:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 04:03:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 04:03:21 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 04:03:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:03:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 04:03:21 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 04:03:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:03:21 --> Database Driver Class Initialized
DEBUG - 2016-05-22 04:03:21 --> Session Class Initialized
DEBUG - 2016-05-22 04:03:21 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 04:03:21 --> Helper loaded: string_helper
DEBUG - 2016-05-22 04:03:21 --> Session routines successfully run
DEBUG - 2016-05-22 04:03:21 --> Native_session Class Initialized
DEBUG - 2016-05-22 04:03:21 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 04:03:21 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:03:21 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:03:21 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 04:03:21 --> Controller Class Initialized
DEBUG - 2016-05-22 04:03:21 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 04:03:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 04:03:21 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 04:03:21 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:03:21 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:03:21 --> User Agent Class Initialized
DEBUG - 2016-05-22 04:03:21 --> Model Class Initialized
DEBUG - 2016-05-22 04:03:21 --> Model Class Initialized
DEBUG - 2016-05-22 04:03:21 --> Model Class Initialized
DEBUG - 2016-05-22 04:03:21 --> Model Class Initialized
DEBUG - 2016-05-22 04:03:21 --> Model Class Initialized
DEBUG - 2016-05-22 04:03:21 --> Model Class Initialized
DEBUG - 2016-05-22 04:03:21 --> Model Class Initialized
DEBUG - 2016-05-22 04:03:21 --> Model Class Initialized
DEBUG - 2016-05-22 04:03:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-22 04:03:21 --> Pagination Class Initialized
DEBUG - 2016-05-22 04:03:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 04:03:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-05-22 04:03:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:03:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:03:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:03:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:03:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-22 04:03:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:03:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:03:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:03:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:03:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:03:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:03:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-22 04:03:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:03:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:03:22 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-05-22 04:03:22 --> Final output sent to browser
DEBUG - 2016-05-22 04:03:22 --> Total execution time: 1.5969
DEBUG - 2016-05-22 04:04:59 --> Config Class Initialized
DEBUG - 2016-05-22 04:04:59 --> Hooks Class Initialized
DEBUG - 2016-05-22 04:04:59 --> Utf8 Class Initialized
DEBUG - 2016-05-22 04:04:59 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 04:04:59 --> URI Class Initialized
DEBUG - 2016-05-22 04:04:59 --> Router Class Initialized
DEBUG - 2016-05-22 04:04:59 --> Output Class Initialized
DEBUG - 2016-05-22 04:04:59 --> Security Class Initialized
DEBUG - 2016-05-22 04:04:59 --> Input Class Initialized
DEBUG - 2016-05-22 04:04:59 --> XSS Filtering completed
DEBUG - 2016-05-22 04:04:59 --> XSS Filtering completed
DEBUG - 2016-05-22 04:04:59 --> Config Class Initialized
DEBUG - 2016-05-22 04:04:59 --> Hooks Class Initialized
DEBUG - 2016-05-22 04:04:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 04:04:59 --> Language Class Initialized
DEBUG - 2016-05-22 04:04:59 --> Utf8 Class Initialized
DEBUG - 2016-05-22 04:04:59 --> Loader Class Initialized
DEBUG - 2016-05-22 04:04:59 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 04:04:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 04:04:59 --> URI Class Initialized
DEBUG - 2016-05-22 04:04:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 04:04:59 --> Router Class Initialized
DEBUG - 2016-05-22 04:04:59 --> Helper loaded: url_helper
DEBUG - 2016-05-22 04:04:59 --> Output Class Initialized
DEBUG - 2016-05-22 04:04:59 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 04:04:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 04:04:59 --> Helper loaded: file_helper
DEBUG - 2016-05-22 04:04:59 --> Security Class Initialized
DEBUG - 2016-05-22 04:04:59 --> Input Class Initialized
DEBUG - 2016-05-22 04:04:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:04:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 04:04:59 --> XSS Filtering completed
DEBUG - 2016-05-22 04:04:59 --> XSS Filtering completed
DEBUG - 2016-05-22 04:04:59 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 04:04:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 04:04:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:04:59 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 04:04:59 --> Language Class Initialized
DEBUG - 2016-05-22 04:04:59 --> Loader Class Initialized
DEBUG - 2016-05-22 04:04:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 04:04:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 04:04:59 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:04:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 04:04:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 04:04:59 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:04:59 --> Helper loaded: url_helper
DEBUG - 2016-05-22 04:04:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 04:04:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 04:04:59 --> Helper loaded: form_helper
DEBUG - 2016-05-22 04:04:59 --> Helper loaded: file_helper
DEBUG - 2016-05-22 04:04:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:04:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 04:04:59 --> Helper loaded: security_helper
DEBUG - 2016-05-22 04:04:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 04:04:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:04:59 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 04:04:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:04:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 04:04:59 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 04:04:59 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 04:04:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:04:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 04:04:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 04:04:59 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:04:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 04:04:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 04:04:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 04:04:59 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:04:59 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 04:04:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 04:04:59 --> Helper loaded: form_helper
DEBUG - 2016-05-22 04:04:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:04:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 04:04:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 04:04:59 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 04:04:59 --> Helper loaded: security_helper
DEBUG - 2016-05-22 04:05:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:05:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:05:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 04:05:00 --> Database Driver Class Initialized
DEBUG - 2016-05-22 04:05:00 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 04:05:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:05:00 --> Session Class Initialized
DEBUG - 2016-05-22 04:05:00 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 04:05:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 04:05:00 --> Helper loaded: string_helper
DEBUG - 2016-05-22 04:05:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 04:05:00 --> Session routines successfully run
DEBUG - 2016-05-22 04:05:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 04:05:00 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 04:05:00 --> Native_session Class Initialized
DEBUG - 2016-05-22 04:05:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 04:05:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:05:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 04:05:00 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 04:05:00 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:05:00 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:05:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:05:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 04:05:00 --> Database Driver Class Initialized
DEBUG - 2016-05-22 04:05:00 --> Controller Class Initialized
DEBUG - 2016-05-22 04:05:00 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 04:05:00 --> Session Class Initialized
DEBUG - 2016-05-22 04:05:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 04:05:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 04:05:00 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 04:05:00 --> Helper loaded: string_helper
DEBUG - 2016-05-22 04:05:00 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:05:00 --> Session routines successfully run
DEBUG - 2016-05-22 04:05:00 --> Native_session Class Initialized
DEBUG - 2016-05-22 04:05:00 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:05:00 --> User Agent Class Initialized
DEBUG - 2016-05-22 04:05:00 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:00 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:00 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:00 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:00 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 04:05:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/detail.php
DEBUG - 2016-05-22 04:05:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:05:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:05:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:05:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:05:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_js.php
DEBUG - 2016-05-22 04:05:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_isian_js.php
DEBUG - 2016-05-22 04:05:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:05:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:05:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_js.php
DEBUG - 2016-05-22 04:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_isian_js.php
DEBUG - 2016-05-22 04:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:05:01 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/69a0bddb6cf23277c5f8caeb26e810f0
DEBUG - 2016-05-22 04:05:01 --> Final output sent to browser
DEBUG - 2016-05-22 04:05:01 --> Total execution time: 1.6181
DEBUG - 2016-05-22 04:05:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 04:05:01 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:05:01 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:05:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 04:05:01 --> Controller Class Initialized
DEBUG - 2016-05-22 04:05:01 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 04:05:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 04:05:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 04:05:01 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:05:01 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:05:01 --> User Agent Class Initialized
DEBUG - 2016-05-22 04:05:01 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:01 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:01 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:01 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:01 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-22 04:05:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 04:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 04:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-05-22 04:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-05-22 04:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:05:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:05:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:05:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:05:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:05:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:05:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-05-22 04:05:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:05:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:05:02 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5cf2ac055215a66f98ba4d6c33c8329d
DEBUG - 2016-05-22 04:05:02 --> Final output sent to browser
DEBUG - 2016-05-22 04:05:02 --> Total execution time: 2.5261
DEBUG - 2016-05-22 04:05:14 --> Config Class Initialized
DEBUG - 2016-05-22 04:05:14 --> Hooks Class Initialized
DEBUG - 2016-05-22 04:05:14 --> Utf8 Class Initialized
DEBUG - 2016-05-22 04:05:14 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 04:05:14 --> URI Class Initialized
DEBUG - 2016-05-22 04:05:14 --> Router Class Initialized
DEBUG - 2016-05-22 04:05:15 --> Output Class Initialized
DEBUG - 2016-05-22 04:05:15 --> Security Class Initialized
DEBUG - 2016-05-22 04:05:15 --> Input Class Initialized
DEBUG - 2016-05-22 04:05:15 --> XSS Filtering completed
DEBUG - 2016-05-22 04:05:15 --> XSS Filtering completed
DEBUG - 2016-05-22 04:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 04:05:15 --> Language Class Initialized
DEBUG - 2016-05-22 04:05:15 --> Loader Class Initialized
DEBUG - 2016-05-22 04:05:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 04:05:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 04:05:15 --> Helper loaded: url_helper
DEBUG - 2016-05-22 04:05:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 04:05:15 --> Helper loaded: file_helper
DEBUG - 2016-05-22 04:05:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:05:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 04:05:15 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 04:05:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:05:15 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 04:05:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 04:05:15 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:05:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 04:05:15 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:05:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 04:05:15 --> Helper loaded: form_helper
DEBUG - 2016-05-22 04:05:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 04:05:15 --> Helper loaded: security_helper
DEBUG - 2016-05-22 04:05:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:05:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 04:05:15 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 04:05:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:05:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 04:05:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 04:05:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 04:05:15 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 04:05:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:05:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 04:05:15 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 04:05:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:05:15 --> Database Driver Class Initialized
DEBUG - 2016-05-22 04:05:15 --> Session Class Initialized
DEBUG - 2016-05-22 04:05:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 04:05:15 --> Helper loaded: string_helper
DEBUG - 2016-05-22 04:05:15 --> Session routines successfully run
DEBUG - 2016-05-22 04:05:16 --> Native_session Class Initialized
DEBUG - 2016-05-22 04:05:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 04:05:16 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:05:16 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:05:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 04:05:16 --> Controller Class Initialized
DEBUG - 2016-05-22 04:05:16 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 04:05:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 04:05:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 04:05:16 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:05:16 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:05:16 --> User Agent Class Initialized
DEBUG - 2016-05-22 04:05:16 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:16 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:16 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:16 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:16 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:16 --> Config Class Initialized
DEBUG - 2016-05-22 04:05:16 --> Hooks Class Initialized
DEBUG - 2016-05-22 04:05:16 --> Utf8 Class Initialized
DEBUG - 2016-05-22 04:05:16 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 04:05:16 --> URI Class Initialized
DEBUG - 2016-05-22 04:05:16 --> Router Class Initialized
DEBUG - 2016-05-22 04:05:16 --> Output Class Initialized
DEBUG - 2016-05-22 04:05:16 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 04:05:16 --> Security Class Initialized
DEBUG - 2016-05-22 04:05:16 --> Input Class Initialized
DEBUG - 2016-05-22 04:05:16 --> XSS Filtering completed
DEBUG - 2016-05-22 04:05:16 --> XSS Filtering completed
DEBUG - 2016-05-22 04:05:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 04:05:16 --> Language Class Initialized
DEBUG - 2016-05-22 04:05:16 --> Loader Class Initialized
DEBUG - 2016-05-22 04:05:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 04:05:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 04:05:16 --> Helper loaded: url_helper
DEBUG - 2016-05-22 04:05:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 04:05:16 --> Helper loaded: file_helper
DEBUG - 2016-05-22 04:05:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:05:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 04:05:16 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 04:05:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:05:16 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 04:05:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 04:05:16 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:05:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 04:05:17 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:05:17 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 04:05:17 --> Helper loaded: form_helper
DEBUG - 2016-05-22 04:05:17 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 04:05:17 --> Helper loaded: security_helper
DEBUG - 2016-05-22 04:05:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:05:17 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 04:05:17 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 04:05:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:05:17 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 04:05:17 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 04:05:17 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 04:05:17 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 04:05:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:05:17 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 04:05:17 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 04:05:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:05:17 --> Database Driver Class Initialized
DEBUG - 2016-05-22 04:05:17 --> Session Class Initialized
DEBUG - 2016-05-22 04:05:17 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 04:05:17 --> Helper loaded: string_helper
DEBUG - 2016-05-22 04:05:17 --> Session routines successfully run
DEBUG - 2016-05-22 04:05:17 --> Native_session Class Initialized
DEBUG - 2016-05-22 04:05:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 04:05:17 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:05:17 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:05:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 04:05:17 --> Controller Class Initialized
DEBUG - 2016-05-22 04:05:17 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 04:05:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 04:05:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 04:05:17 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:05:17 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:05:17 --> User Agent Class Initialized
DEBUG - 2016-05-22 04:05:17 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:17 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:17 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:17 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:17 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:17 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:17 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:17 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-22 04:05:17 --> Pagination Class Initialized
DEBUG - 2016-05-22 04:05:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 04:05:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-05-22 04:05:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:05:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:05:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:05:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:05:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-22 04:05:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:05:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:05:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:05:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:05:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:05:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:05:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-22 04:05:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:05:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:05:18 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-05-22 04:05:18 --> Final output sent to browser
DEBUG - 2016-05-22 04:05:18 --> Total execution time: 1.6119
DEBUG - 2016-05-22 04:05:57 --> Config Class Initialized
DEBUG - 2016-05-22 04:05:57 --> Hooks Class Initialized
DEBUG - 2016-05-22 04:05:57 --> Utf8 Class Initialized
DEBUG - 2016-05-22 04:05:57 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 04:05:57 --> URI Class Initialized
DEBUG - 2016-05-22 04:05:57 --> Router Class Initialized
DEBUG - 2016-05-22 04:05:57 --> Output Class Initialized
DEBUG - 2016-05-22 04:05:57 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 04:05:57 --> Security Class Initialized
DEBUG - 2016-05-22 04:05:57 --> Input Class Initialized
DEBUG - 2016-05-22 04:05:57 --> XSS Filtering completed
DEBUG - 2016-05-22 04:05:57 --> XSS Filtering completed
DEBUG - 2016-05-22 04:05:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 04:05:57 --> Language Class Initialized
DEBUG - 2016-05-22 04:05:57 --> Loader Class Initialized
DEBUG - 2016-05-22 04:05:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 04:05:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 04:05:57 --> Helper loaded: url_helper
DEBUG - 2016-05-22 04:05:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 04:05:57 --> Helper loaded: file_helper
DEBUG - 2016-05-22 04:05:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:05:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 04:05:57 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 04:05:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:05:57 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 04:05:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 04:05:57 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:05:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 04:05:57 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:05:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 04:05:57 --> Helper loaded: form_helper
DEBUG - 2016-05-22 04:05:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 04:05:57 --> Helper loaded: security_helper
DEBUG - 2016-05-22 04:05:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:05:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 04:05:57 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 04:05:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:05:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 04:05:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 04:05:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 04:05:57 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 04:05:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:05:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 04:05:58 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 04:05:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:05:58 --> Database Driver Class Initialized
DEBUG - 2016-05-22 04:05:58 --> Session Class Initialized
DEBUG - 2016-05-22 04:05:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 04:05:58 --> Helper loaded: string_helper
DEBUG - 2016-05-22 04:05:58 --> Session routines successfully run
DEBUG - 2016-05-22 04:05:58 --> Native_session Class Initialized
DEBUG - 2016-05-22 04:05:58 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 04:05:58 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:05:58 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:05:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 04:05:58 --> Controller Class Initialized
DEBUG - 2016-05-22 04:05:58 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 04:05:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 04:05:58 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 04:05:58 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:05:58 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:05:58 --> User Agent Class Initialized
DEBUG - 2016-05-22 04:05:58 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:58 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:58 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:58 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:58 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:58 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:58 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:58 --> Model Class Initialized
DEBUG - 2016-05-22 04:05:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-22 04:05:58 --> Pagination Class Initialized
DEBUG - 2016-05-22 04:05:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 04:05:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-05-22 04:05:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:05:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:05:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:05:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:05:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-22 04:05:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:05:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:05:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:05:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:05:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:05:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:05:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-22 04:05:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:05:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:05:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-05-22 04:05:59 --> Final output sent to browser
DEBUG - 2016-05-22 04:05:59 --> Total execution time: 1.7464
DEBUG - 2016-05-22 04:08:28 --> Config Class Initialized
DEBUG - 2016-05-22 04:08:28 --> Hooks Class Initialized
DEBUG - 2016-05-22 04:08:28 --> Utf8 Class Initialized
DEBUG - 2016-05-22 04:08:28 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 04:08:28 --> URI Class Initialized
DEBUG - 2016-05-22 04:08:28 --> Router Class Initialized
DEBUG - 2016-05-22 04:08:28 --> Output Class Initialized
DEBUG - 2016-05-22 04:08:28 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 04:08:28 --> Security Class Initialized
DEBUG - 2016-05-22 04:08:28 --> Input Class Initialized
DEBUG - 2016-05-22 04:08:28 --> XSS Filtering completed
DEBUG - 2016-05-22 04:08:28 --> XSS Filtering completed
DEBUG - 2016-05-22 04:08:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 04:08:28 --> Language Class Initialized
DEBUG - 2016-05-22 04:08:28 --> Loader Class Initialized
DEBUG - 2016-05-22 04:08:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 04:08:28 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 04:08:28 --> Helper loaded: url_helper
DEBUG - 2016-05-22 04:08:28 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 04:08:28 --> Helper loaded: file_helper
DEBUG - 2016-05-22 04:08:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:08:28 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 04:08:28 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 04:08:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:08:28 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 04:08:28 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 04:08:28 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:08:28 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 04:08:28 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:08:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 04:08:28 --> Helper loaded: form_helper
DEBUG - 2016-05-22 04:08:28 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 04:08:28 --> Helper loaded: security_helper
DEBUG - 2016-05-22 04:08:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:08:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 04:08:29 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 04:08:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:08:29 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 04:08:29 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 04:08:29 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 04:08:29 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 04:08:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:08:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 04:08:29 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 04:08:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:08:29 --> Database Driver Class Initialized
DEBUG - 2016-05-22 04:08:29 --> Session Class Initialized
DEBUG - 2016-05-22 04:08:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 04:08:29 --> Helper loaded: string_helper
DEBUG - 2016-05-22 04:08:29 --> Session routines successfully run
DEBUG - 2016-05-22 04:08:29 --> Native_session Class Initialized
DEBUG - 2016-05-22 04:08:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 04:08:29 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:08:29 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:08:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 04:08:29 --> Controller Class Initialized
DEBUG - 2016-05-22 04:08:29 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 04:08:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 04:08:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 04:08:29 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:08:29 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:08:29 --> User Agent Class Initialized
DEBUG - 2016-05-22 04:08:29 --> Model Class Initialized
DEBUG - 2016-05-22 04:08:29 --> Model Class Initialized
DEBUG - 2016-05-22 04:08:29 --> Model Class Initialized
DEBUG - 2016-05-22 04:08:29 --> Model Class Initialized
DEBUG - 2016-05-22 04:08:29 --> Model Class Initialized
DEBUG - 2016-05-22 04:08:29 --> Model Class Initialized
DEBUG - 2016-05-22 04:08:29 --> Model Class Initialized
DEBUG - 2016-05-22 04:08:29 --> Model Class Initialized
DEBUG - 2016-05-22 04:08:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-22 04:08:29 --> Pagination Class Initialized
DEBUG - 2016-05-22 04:08:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 04:08:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-05-22 04:08:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:08:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:08:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:08:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:08:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-22 04:08:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:08:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:08:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:08:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:08:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:08:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:08:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-22 04:08:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:08:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:08:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-05-22 04:08:30 --> Final output sent to browser
DEBUG - 2016-05-22 04:08:30 --> Total execution time: 1.7487
DEBUG - 2016-05-22 04:08:45 --> Config Class Initialized
DEBUG - 2016-05-22 04:08:45 --> Hooks Class Initialized
DEBUG - 2016-05-22 04:08:45 --> Utf8 Class Initialized
DEBUG - 2016-05-22 04:08:45 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 04:08:45 --> URI Class Initialized
DEBUG - 2016-05-22 04:08:45 --> Router Class Initialized
DEBUG - 2016-05-22 04:08:45 --> Output Class Initialized
DEBUG - 2016-05-22 04:08:45 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 04:08:45 --> Security Class Initialized
DEBUG - 2016-05-22 04:08:45 --> Input Class Initialized
DEBUG - 2016-05-22 04:08:45 --> XSS Filtering completed
DEBUG - 2016-05-22 04:08:45 --> XSS Filtering completed
DEBUG - 2016-05-22 04:08:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 04:08:45 --> Language Class Initialized
DEBUG - 2016-05-22 04:08:45 --> Loader Class Initialized
DEBUG - 2016-05-22 04:08:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 04:08:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 04:08:45 --> Helper loaded: url_helper
DEBUG - 2016-05-22 04:08:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 04:08:45 --> Helper loaded: file_helper
DEBUG - 2016-05-22 04:08:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:08:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 04:08:45 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 04:08:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:08:45 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 04:08:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 04:08:45 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:08:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 04:08:45 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:08:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 04:08:46 --> Helper loaded: form_helper
DEBUG - 2016-05-22 04:08:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 04:08:46 --> Helper loaded: security_helper
DEBUG - 2016-05-22 04:08:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:08:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 04:08:46 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 04:08:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:08:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 04:08:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 04:08:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 04:08:46 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 04:08:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:08:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 04:08:46 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 04:08:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:08:46 --> Database Driver Class Initialized
DEBUG - 2016-05-22 04:08:46 --> Session Class Initialized
DEBUG - 2016-05-22 04:08:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 04:08:46 --> Helper loaded: string_helper
DEBUG - 2016-05-22 04:08:46 --> Session routines successfully run
DEBUG - 2016-05-22 04:08:46 --> Native_session Class Initialized
DEBUG - 2016-05-22 04:08:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 04:08:46 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:08:46 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:08:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 04:08:46 --> Controller Class Initialized
DEBUG - 2016-05-22 04:08:46 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 04:08:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 04:08:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 04:08:46 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:08:46 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:08:46 --> User Agent Class Initialized
DEBUG - 2016-05-22 04:08:46 --> Model Class Initialized
DEBUG - 2016-05-22 04:08:46 --> Model Class Initialized
DEBUG - 2016-05-22 04:08:46 --> Model Class Initialized
DEBUG - 2016-05-22 04:08:46 --> Model Class Initialized
DEBUG - 2016-05-22 04:08:46 --> Model Class Initialized
DEBUG - 2016-05-22 04:09:00 --> Config Class Initialized
DEBUG - 2016-05-22 04:09:00 --> Hooks Class Initialized
DEBUG - 2016-05-22 04:09:00 --> Utf8 Class Initialized
DEBUG - 2016-05-22 04:09:00 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 04:09:00 --> URI Class Initialized
DEBUG - 2016-05-22 04:09:00 --> Router Class Initialized
DEBUG - 2016-05-22 04:09:00 --> Output Class Initialized
DEBUG - 2016-05-22 04:09:00 --> Security Class Initialized
DEBUG - 2016-05-22 04:09:00 --> Input Class Initialized
DEBUG - 2016-05-22 04:09:00 --> XSS Filtering completed
DEBUG - 2016-05-22 04:09:00 --> XSS Filtering completed
DEBUG - 2016-05-22 04:09:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 04:09:00 --> Language Class Initialized
DEBUG - 2016-05-22 04:09:00 --> Loader Class Initialized
DEBUG - 2016-05-22 04:09:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 04:09:00 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 04:09:00 --> Helper loaded: url_helper
DEBUG - 2016-05-22 04:09:00 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 04:09:00 --> Helper loaded: file_helper
DEBUG - 2016-05-22 04:09:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:09:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 04:09:01 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 04:09:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:09:01 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 04:09:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 04:09:01 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:09:01 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 04:09:01 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:09:01 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 04:09:01 --> Helper loaded: form_helper
DEBUG - 2016-05-22 04:09:01 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 04:09:01 --> Helper loaded: security_helper
DEBUG - 2016-05-22 04:09:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:09:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 04:09:01 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 04:09:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:09:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 04:09:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 04:09:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 04:09:01 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 04:09:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:09:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 04:09:01 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 04:09:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:09:01 --> Database Driver Class Initialized
DEBUG - 2016-05-22 04:09:01 --> Session Class Initialized
DEBUG - 2016-05-22 04:09:01 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 04:09:01 --> Helper loaded: string_helper
DEBUG - 2016-05-22 04:09:01 --> Session routines successfully run
DEBUG - 2016-05-22 04:09:01 --> Native_session Class Initialized
DEBUG - 2016-05-22 04:09:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 04:09:01 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:09:01 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:09:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 04:09:01 --> Controller Class Initialized
DEBUG - 2016-05-22 04:09:01 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 04:09:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 04:09:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 04:09:02 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:09:02 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:09:02 --> User Agent Class Initialized
DEBUG - 2016-05-22 04:09:02 --> Model Class Initialized
DEBUG - 2016-05-22 04:09:02 --> Model Class Initialized
DEBUG - 2016-05-22 04:09:02 --> Model Class Initialized
DEBUG - 2016-05-22 04:09:02 --> Model Class Initialized
DEBUG - 2016-05-22 04:09:02 --> Model Class Initialized
DEBUG - 2016-05-22 04:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 04:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-22 04:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:09:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:09:02 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-05-22 04:09:02 --> Final output sent to browser
DEBUG - 2016-05-22 04:09:02 --> Total execution time: 1.9325
DEBUG - 2016-05-22 04:09:19 --> Config Class Initialized
DEBUG - 2016-05-22 04:09:19 --> Hooks Class Initialized
DEBUG - 2016-05-22 04:09:19 --> Utf8 Class Initialized
DEBUG - 2016-05-22 04:09:19 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 04:09:19 --> URI Class Initialized
DEBUG - 2016-05-22 04:09:19 --> Router Class Initialized
DEBUG - 2016-05-22 04:09:19 --> Output Class Initialized
DEBUG - 2016-05-22 04:09:19 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 04:09:19 --> Security Class Initialized
DEBUG - 2016-05-22 04:09:19 --> Input Class Initialized
DEBUG - 2016-05-22 04:09:19 --> XSS Filtering completed
DEBUG - 2016-05-22 04:09:19 --> XSS Filtering completed
DEBUG - 2016-05-22 04:09:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 04:09:19 --> Language Class Initialized
DEBUG - 2016-05-22 04:09:19 --> Loader Class Initialized
DEBUG - 2016-05-22 04:09:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 04:09:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 04:09:19 --> Helper loaded: url_helper
DEBUG - 2016-05-22 04:09:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 04:09:19 --> Helper loaded: file_helper
DEBUG - 2016-05-22 04:09:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:09:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 04:09:19 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 04:09:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:09:19 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 04:09:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 04:09:19 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:09:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 04:09:19 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:09:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 04:09:19 --> Helper loaded: form_helper
DEBUG - 2016-05-22 04:09:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 04:09:19 --> Helper loaded: security_helper
DEBUG - 2016-05-22 04:09:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:09:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 04:09:20 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 04:09:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:09:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 04:09:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 04:09:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 04:09:20 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 04:09:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:09:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 04:09:20 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 04:09:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:09:20 --> Database Driver Class Initialized
DEBUG - 2016-05-22 04:09:20 --> Session Class Initialized
DEBUG - 2016-05-22 04:09:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 04:09:20 --> Helper loaded: string_helper
DEBUG - 2016-05-22 04:09:20 --> Session routines successfully run
DEBUG - 2016-05-22 04:09:20 --> Native_session Class Initialized
DEBUG - 2016-05-22 04:09:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 04:09:20 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:09:20 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:09:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 04:09:20 --> Controller Class Initialized
DEBUG - 2016-05-22 04:09:20 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 04:09:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 04:09:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 04:09:20 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:09:20 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:09:20 --> User Agent Class Initialized
DEBUG - 2016-05-22 04:09:20 --> Model Class Initialized
DEBUG - 2016-05-22 04:09:20 --> Model Class Initialized
DEBUG - 2016-05-22 04:09:20 --> Model Class Initialized
DEBUG - 2016-05-22 04:09:20 --> Model Class Initialized
DEBUG - 2016-05-22 04:09:20 --> Model Class Initialized
ERROR - 2016-05-22 04:09:20 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-05-22 04:09:20 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-05-22 04:09:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 04:09:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-22 04:09:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:09:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:09:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:09:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:09:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:09:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:09:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:09:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:09:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:09:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:09:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:09:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:09:21 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-05-22 04:09:21 --> Final output sent to browser
DEBUG - 2016-05-22 04:09:21 --> Total execution time: 1.7310
DEBUG - 2016-05-22 04:09:36 --> Config Class Initialized
DEBUG - 2016-05-22 04:09:36 --> Hooks Class Initialized
DEBUG - 2016-05-22 04:09:36 --> Utf8 Class Initialized
DEBUG - 2016-05-22 04:09:36 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 04:09:36 --> URI Class Initialized
DEBUG - 2016-05-22 04:09:37 --> Router Class Initialized
DEBUG - 2016-05-22 04:09:37 --> Output Class Initialized
DEBUG - 2016-05-22 04:09:37 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 04:09:37 --> Security Class Initialized
DEBUG - 2016-05-22 04:09:37 --> Input Class Initialized
DEBUG - 2016-05-22 04:09:37 --> XSS Filtering completed
DEBUG - 2016-05-22 04:09:37 --> XSS Filtering completed
DEBUG - 2016-05-22 04:09:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 04:09:37 --> Language Class Initialized
DEBUG - 2016-05-22 04:09:37 --> Loader Class Initialized
DEBUG - 2016-05-22 04:09:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 04:09:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 04:09:37 --> Helper loaded: url_helper
DEBUG - 2016-05-22 04:09:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 04:09:37 --> Helper loaded: file_helper
DEBUG - 2016-05-22 04:09:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:09:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 04:09:37 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 04:09:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:09:37 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 04:09:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 04:09:37 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:09:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 04:09:37 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:09:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 04:09:37 --> Helper loaded: form_helper
DEBUG - 2016-05-22 04:09:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 04:09:37 --> Helper loaded: security_helper
DEBUG - 2016-05-22 04:09:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:09:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 04:09:37 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 04:09:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:09:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 04:09:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 04:09:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 04:09:37 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 04:09:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:09:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 04:09:37 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 04:09:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:09:37 --> Database Driver Class Initialized
DEBUG - 2016-05-22 04:09:38 --> Session Class Initialized
DEBUG - 2016-05-22 04:09:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 04:09:38 --> Helper loaded: string_helper
DEBUG - 2016-05-22 04:09:38 --> Session routines successfully run
DEBUG - 2016-05-22 04:09:38 --> Native_session Class Initialized
DEBUG - 2016-05-22 04:09:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 04:09:38 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:09:38 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:09:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 04:09:38 --> Controller Class Initialized
DEBUG - 2016-05-22 04:09:38 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 04:09:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 04:09:38 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 04:09:38 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:09:38 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:09:38 --> User Agent Class Initialized
DEBUG - 2016-05-22 04:09:38 --> Model Class Initialized
DEBUG - 2016-05-22 04:09:38 --> Model Class Initialized
DEBUG - 2016-05-22 04:09:38 --> Model Class Initialized
DEBUG - 2016-05-22 04:09:38 --> Model Class Initialized
DEBUG - 2016-05-22 04:09:38 --> Model Class Initialized
DEBUG - 2016-05-22 04:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 04:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-22 04:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:09:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:09:38 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-05-22 04:09:38 --> Final output sent to browser
DEBUG - 2016-05-22 04:09:38 --> Total execution time: 1.6840
DEBUG - 2016-05-22 04:09:53 --> Config Class Initialized
DEBUG - 2016-05-22 04:09:53 --> Hooks Class Initialized
DEBUG - 2016-05-22 04:09:53 --> Utf8 Class Initialized
DEBUG - 2016-05-22 04:09:53 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 04:09:53 --> URI Class Initialized
DEBUG - 2016-05-22 04:09:53 --> Router Class Initialized
DEBUG - 2016-05-22 04:09:53 --> Output Class Initialized
DEBUG - 2016-05-22 04:09:53 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 04:09:53 --> Security Class Initialized
DEBUG - 2016-05-22 04:09:53 --> Input Class Initialized
DEBUG - 2016-05-22 04:09:53 --> XSS Filtering completed
DEBUG - 2016-05-22 04:09:53 --> XSS Filtering completed
DEBUG - 2016-05-22 04:09:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 04:09:53 --> Language Class Initialized
DEBUG - 2016-05-22 04:09:53 --> Loader Class Initialized
DEBUG - 2016-05-22 04:09:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 04:09:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 04:09:53 --> Helper loaded: url_helper
DEBUG - 2016-05-22 04:09:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 04:09:53 --> Helper loaded: file_helper
DEBUG - 2016-05-22 04:09:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:09:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 04:09:53 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 04:09:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:09:53 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 04:09:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 04:09:53 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:09:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 04:09:53 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:09:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 04:09:54 --> Helper loaded: form_helper
DEBUG - 2016-05-22 04:09:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 04:09:54 --> Helper loaded: security_helper
DEBUG - 2016-05-22 04:09:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:09:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 04:09:54 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 04:09:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:09:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 04:09:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 04:09:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 04:09:54 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 04:09:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:09:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 04:09:54 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 04:09:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:09:54 --> Database Driver Class Initialized
DEBUG - 2016-05-22 04:09:54 --> Session Class Initialized
DEBUG - 2016-05-22 04:09:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 04:09:54 --> Helper loaded: string_helper
DEBUG - 2016-05-22 04:09:54 --> Session routines successfully run
DEBUG - 2016-05-22 04:09:54 --> Native_session Class Initialized
DEBUG - 2016-05-22 04:09:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 04:09:54 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:09:54 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:09:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 04:09:54 --> Controller Class Initialized
DEBUG - 2016-05-22 04:09:54 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 04:09:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 04:09:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 04:09:54 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:09:54 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:09:54 --> User Agent Class Initialized
DEBUG - 2016-05-22 04:09:54 --> Model Class Initialized
DEBUG - 2016-05-22 04:09:54 --> Model Class Initialized
DEBUG - 2016-05-22 04:09:54 --> Model Class Initialized
DEBUG - 2016-05-22 04:09:54 --> Model Class Initialized
DEBUG - 2016-05-22 04:09:54 --> Model Class Initialized
DEBUG - 2016-05-22 04:09:55 --> Config Class Initialized
DEBUG - 2016-05-22 04:09:55 --> Hooks Class Initialized
DEBUG - 2016-05-22 04:09:55 --> Utf8 Class Initialized
DEBUG - 2016-05-22 04:09:55 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 04:09:55 --> URI Class Initialized
DEBUG - 2016-05-22 04:09:55 --> Router Class Initialized
DEBUG - 2016-05-22 04:09:55 --> Output Class Initialized
DEBUG - 2016-05-22 04:09:55 --> Cache file has expired. File deleted
DEBUG - 2016-05-22 04:09:55 --> Security Class Initialized
DEBUG - 2016-05-22 04:09:55 --> Input Class Initialized
DEBUG - 2016-05-22 04:09:55 --> XSS Filtering completed
DEBUG - 2016-05-22 04:09:55 --> XSS Filtering completed
DEBUG - 2016-05-22 04:09:55 --> XSS Filtering completed
DEBUG - 2016-05-22 04:09:55 --> XSS Filtering completed
DEBUG - 2016-05-22 04:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 04:09:55 --> Language Class Initialized
DEBUG - 2016-05-22 04:09:55 --> Loader Class Initialized
DEBUG - 2016-05-22 04:09:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 04:09:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 04:09:55 --> Helper loaded: url_helper
DEBUG - 2016-05-22 04:09:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 04:09:55 --> Helper loaded: file_helper
DEBUG - 2016-05-22 04:09:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:09:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 04:09:55 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 04:09:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:09:55 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 04:09:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 04:09:55 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:09:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 04:09:56 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:09:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 04:09:56 --> Helper loaded: form_helper
DEBUG - 2016-05-22 04:09:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 04:09:56 --> Helper loaded: security_helper
DEBUG - 2016-05-22 04:09:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:09:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 04:09:56 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 04:09:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:09:56 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 04:09:56 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 04:09:56 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 04:09:56 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 04:09:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:09:56 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 04:09:56 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 04:09:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:09:56 --> Database Driver Class Initialized
DEBUG - 2016-05-22 04:09:56 --> Session Class Initialized
DEBUG - 2016-05-22 04:09:56 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 04:09:56 --> Helper loaded: string_helper
DEBUG - 2016-05-22 04:09:56 --> Session routines successfully run
DEBUG - 2016-05-22 04:09:56 --> Native_session Class Initialized
DEBUG - 2016-05-22 04:09:56 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 04:09:56 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:09:56 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:09:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 04:09:56 --> Controller Class Initialized
DEBUG - 2016-05-22 04:09:56 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 04:09:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 04:09:56 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 04:09:56 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:09:56 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:09:56 --> User Agent Class Initialized
DEBUG - 2016-05-22 04:09:56 --> Model Class Initialized
DEBUG - 2016-05-22 04:09:56 --> Model Class Initialized
DEBUG - 2016-05-22 04:09:56 --> Model Class Initialized
DEBUG - 2016-05-22 04:09:56 --> Model Class Initialized
DEBUG - 2016-05-22 04:09:56 --> Model Class Initialized
DEBUG - 2016-05-22 04:10:02 --> Config Class Initialized
DEBUG - 2016-05-22 04:10:02 --> Hooks Class Initialized
DEBUG - 2016-05-22 04:10:02 --> Utf8 Class Initialized
DEBUG - 2016-05-22 04:10:02 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 04:10:02 --> URI Class Initialized
DEBUG - 2016-05-22 04:10:02 --> Router Class Initialized
DEBUG - 2016-05-22 04:10:02 --> Output Class Initialized
DEBUG - 2016-05-22 04:10:02 --> Security Class Initialized
DEBUG - 2016-05-22 04:10:02 --> Input Class Initialized
DEBUG - 2016-05-22 04:10:02 --> XSS Filtering completed
DEBUG - 2016-05-22 04:10:02 --> XSS Filtering completed
DEBUG - 2016-05-22 04:10:02 --> XSS Filtering completed
DEBUG - 2016-05-22 04:10:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 04:10:02 --> Language Class Initialized
DEBUG - 2016-05-22 04:10:02 --> Loader Class Initialized
DEBUG - 2016-05-22 04:10:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 04:10:02 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 04:10:02 --> Helper loaded: url_helper
DEBUG - 2016-05-22 04:10:02 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 04:10:02 --> Helper loaded: file_helper
DEBUG - 2016-05-22 04:10:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:10:02 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 04:10:02 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 04:10:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:10:02 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 04:10:02 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 04:10:02 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:10:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 04:10:02 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:10:02 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 04:10:02 --> Helper loaded: form_helper
DEBUG - 2016-05-22 04:10:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 04:10:02 --> Helper loaded: security_helper
DEBUG - 2016-05-22 04:10:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:10:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 04:10:02 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 04:10:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:10:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 04:10:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 04:10:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 04:10:03 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 04:10:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:10:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 04:10:03 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 04:10:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:10:03 --> Database Driver Class Initialized
DEBUG - 2016-05-22 04:10:03 --> Session Class Initialized
DEBUG - 2016-05-22 04:10:03 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 04:10:03 --> Helper loaded: string_helper
DEBUG - 2016-05-22 04:10:03 --> Session routines successfully run
DEBUG - 2016-05-22 04:10:03 --> Native_session Class Initialized
DEBUG - 2016-05-22 04:10:03 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 04:10:03 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:10:03 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:10:03 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 04:10:03 --> Controller Class Initialized
DEBUG - 2016-05-22 04:10:03 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 04:10:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 04:10:03 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 04:10:03 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:10:03 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:10:03 --> User Agent Class Initialized
DEBUG - 2016-05-22 04:10:03 --> Model Class Initialized
DEBUG - 2016-05-22 04:10:03 --> Model Class Initialized
DEBUG - 2016-05-22 04:10:03 --> Model Class Initialized
DEBUG - 2016-05-22 04:10:03 --> Model Class Initialized
DEBUG - 2016-05-22 04:10:03 --> Model Class Initialized
DEBUG - 2016-05-22 04:11:49 --> Config Class Initialized
DEBUG - 2016-05-22 04:11:49 --> Hooks Class Initialized
DEBUG - 2016-05-22 04:11:49 --> Utf8 Class Initialized
DEBUG - 2016-05-22 04:11:49 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 04:11:49 --> URI Class Initialized
DEBUG - 2016-05-22 04:11:49 --> Router Class Initialized
DEBUG - 2016-05-22 04:11:49 --> Output Class Initialized
DEBUG - 2016-05-22 04:11:49 --> Security Class Initialized
DEBUG - 2016-05-22 04:11:49 --> Input Class Initialized
DEBUG - 2016-05-22 04:11:49 --> XSS Filtering completed
DEBUG - 2016-05-22 04:11:49 --> XSS Filtering completed
DEBUG - 2016-05-22 04:11:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 04:11:49 --> Language Class Initialized
DEBUG - 2016-05-22 04:11:49 --> Loader Class Initialized
DEBUG - 2016-05-22 04:11:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 04:11:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 04:11:49 --> Helper loaded: url_helper
DEBUG - 2016-05-22 04:11:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 04:11:49 --> Helper loaded: file_helper
DEBUG - 2016-05-22 04:11:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:11:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 04:11:49 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 04:11:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:11:49 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 04:11:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 04:11:49 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:11:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 04:11:49 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:11:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 04:11:49 --> Helper loaded: form_helper
DEBUG - 2016-05-22 04:11:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 04:11:49 --> Helper loaded: security_helper
DEBUG - 2016-05-22 04:11:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:11:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 04:11:50 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 04:11:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:11:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 04:11:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 04:11:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 04:11:50 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 04:11:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:11:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 04:11:50 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 04:11:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:11:50 --> Database Driver Class Initialized
DEBUG - 2016-05-22 04:11:50 --> Session Class Initialized
DEBUG - 2016-05-22 04:11:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 04:11:50 --> Helper loaded: string_helper
DEBUG - 2016-05-22 04:11:50 --> Session routines successfully run
DEBUG - 2016-05-22 04:11:50 --> Native_session Class Initialized
DEBUG - 2016-05-22 04:11:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 04:11:50 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:11:50 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:11:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 04:11:50 --> Controller Class Initialized
DEBUG - 2016-05-22 04:11:50 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 04:11:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 04:11:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 04:11:50 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:11:50 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:11:50 --> User Agent Class Initialized
DEBUG - 2016-05-22 04:11:50 --> Model Class Initialized
DEBUG - 2016-05-22 04:11:50 --> Model Class Initialized
DEBUG - 2016-05-22 04:11:50 --> Model Class Initialized
DEBUG - 2016-05-22 04:11:50 --> Model Class Initialized
DEBUG - 2016-05-22 04:11:50 --> Model Class Initialized
DEBUG - 2016-05-22 04:11:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 04:11:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-22 04:11:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:11:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:11:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:11:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:11:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:11:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:11:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:11:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:11:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:11:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:11:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:11:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:11:51 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-05-22 04:11:51 --> Final output sent to browser
DEBUG - 2016-05-22 04:11:51 --> Total execution time: 1.6893
DEBUG - 2016-05-22 04:12:03 --> Config Class Initialized
DEBUG - 2016-05-22 04:12:03 --> Hooks Class Initialized
DEBUG - 2016-05-22 04:12:03 --> Utf8 Class Initialized
DEBUG - 2016-05-22 04:12:03 --> UTF-8 Support Enabled
DEBUG - 2016-05-22 04:12:03 --> URI Class Initialized
DEBUG - 2016-05-22 04:12:03 --> Router Class Initialized
DEBUG - 2016-05-22 04:12:03 --> Output Class Initialized
DEBUG - 2016-05-22 04:12:03 --> Security Class Initialized
DEBUG - 2016-05-22 04:12:03 --> Input Class Initialized
DEBUG - 2016-05-22 04:12:03 --> XSS Filtering completed
DEBUG - 2016-05-22 04:12:03 --> XSS Filtering completed
DEBUG - 2016-05-22 04:12:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-22 04:12:03 --> Language Class Initialized
DEBUG - 2016-05-22 04:12:03 --> Loader Class Initialized
DEBUG - 2016-05-22 04:12:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-22 04:12:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-22 04:12:03 --> Helper loaded: url_helper
DEBUG - 2016-05-22 04:12:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-22 04:12:04 --> Helper loaded: file_helper
DEBUG - 2016-05-22 04:12:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:12:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-22 04:12:04 --> Helper loaded: conf_helper
DEBUG - 2016-05-22 04:12:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-22 04:12:04 --> Check Exists common_helper.php: No
DEBUG - 2016-05-22 04:12:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-22 04:12:04 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:12:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-22 04:12:04 --> Helper loaded: common_helper
DEBUG - 2016-05-22 04:12:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-22 04:12:04 --> Helper loaded: form_helper
DEBUG - 2016-05-22 04:12:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-22 04:12:04 --> Helper loaded: security_helper
DEBUG - 2016-05-22 04:12:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:12:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-22 04:12:04 --> Helper loaded: lang_helper
DEBUG - 2016-05-22 04:12:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-22 04:12:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-22 04:12:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-22 04:12:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-22 04:12:04 --> Helper loaded: atlant_helper
DEBUG - 2016-05-22 04:12:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:12:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-22 04:12:04 --> Helper loaded: crypto_helper
DEBUG - 2016-05-22 04:12:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-22 04:12:04 --> Database Driver Class Initialized
DEBUG - 2016-05-22 04:12:04 --> Session Class Initialized
DEBUG - 2016-05-22 04:12:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-22 04:12:04 --> Helper loaded: string_helper
DEBUG - 2016-05-22 04:12:04 --> Session routines successfully run
DEBUG - 2016-05-22 04:12:04 --> Native_session Class Initialized
DEBUG - 2016-05-22 04:12:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-22 04:12:04 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:12:04 --> Form Validation Class Initialized
DEBUG - 2016-05-22 04:12:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-22 04:12:04 --> Controller Class Initialized
DEBUG - 2016-05-22 04:12:04 --> Carabiner: Library initialized.
DEBUG - 2016-05-22 04:12:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-22 04:12:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-22 04:12:05 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:12:05 --> Carabiner: library configured.
DEBUG - 2016-05-22 04:12:05 --> User Agent Class Initialized
DEBUG - 2016-05-22 04:12:05 --> Model Class Initialized
DEBUG - 2016-05-22 04:12:05 --> Model Class Initialized
DEBUG - 2016-05-22 04:12:05 --> Model Class Initialized
DEBUG - 2016-05-22 04:12:05 --> Model Class Initialized
DEBUG - 2016-05-22 04:12:05 --> Model Class Initialized
ERROR - 2016-05-22 04:12:05 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-05-22 04:12:05 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-05-22 04:12:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-22 04:12:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-22 04:12:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:12:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:12:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:12:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:12:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:12:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:12:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-22 04:12:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-22 04:12:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-22 04:12:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-22 04:12:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-22 04:12:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-22 04:12:05 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-05-22 04:12:05 --> Final output sent to browser
DEBUG - 2016-05-22 04:12:05 --> Total execution time: 1.6693
