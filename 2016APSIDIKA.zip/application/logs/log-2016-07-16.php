<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-07-16 19:26:43 --> Config Class Initialized
DEBUG - 2016-07-16 19:26:43 --> Hooks Class Initialized
DEBUG - 2016-07-16 19:26:43 --> Utf8 Class Initialized
DEBUG - 2016-07-16 19:26:43 --> UTF-8 Support Enabled
DEBUG - 2016-07-16 19:26:43 --> URI Class Initialized
DEBUG - 2016-07-16 19:26:43 --> Router Class Initialized
DEBUG - 2016-07-16 19:26:43 --> Output Class Initialized
DEBUG - 2016-07-16 19:26:43 --> Cache file has expired. File deleted
DEBUG - 2016-07-16 19:26:43 --> Security Class Initialized
DEBUG - 2016-07-16 19:26:43 --> Input Class Initialized
DEBUG - 2016-07-16 19:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-16 19:26:43 --> Language Class Initialized
DEBUG - 2016-07-16 19:26:44 --> Loader Class Initialized
DEBUG - 2016-07-16 19:26:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-07-16 19:26:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-07-16 19:26:44 --> Helper loaded: url_helper
DEBUG - 2016-07-16 19:26:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-07-16 19:26:44 --> Helper loaded: file_helper
DEBUG - 2016-07-16 19:26:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-07-16 19:26:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-07-16 19:26:44 --> Helper loaded: conf_helper
DEBUG - 2016-07-16 19:26:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-07-16 19:26:44 --> Check Exists common_helper.php: No
DEBUG - 2016-07-16 19:26:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-07-16 19:26:44 --> Helper loaded: common_helper
DEBUG - 2016-07-16 19:26:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-07-16 19:26:44 --> Helper loaded: common_helper
DEBUG - 2016-07-16 19:26:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-07-16 19:26:44 --> Helper loaded: form_helper
DEBUG - 2016-07-16 19:26:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-07-16 19:26:44 --> Helper loaded: security_helper
DEBUG - 2016-07-16 19:26:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-07-16 19:26:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-07-16 19:26:44 --> Helper loaded: lang_helper
DEBUG - 2016-07-16 19:26:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-07-16 19:26:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-07-16 19:26:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-07-16 19:26:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-07-16 19:26:44 --> Helper loaded: atlant_helper
DEBUG - 2016-07-16 19:26:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-07-16 19:26:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-07-16 19:26:44 --> Helper loaded: crypto_helper
DEBUG - 2016-07-16 19:26:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-07-16 19:26:44 --> Database Driver Class Initialized
ERROR - 2016-07-16 19:26:46 --> Severity: Warning  --> pg_connect(): Unable to connect to PostgreSQL server: could not connect to server: Connection refused (0x0000274D/10061)
	Is the server running on host &quot;127.0.0.1&quot; and accepting
	TCP/IP connections on port 5432? E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 87
ERROR - 2016-07-16 19:26:46 --> Unable to connect to the database
DEBUG - 2016-07-16 19:26:46 --> Language file loaded: language/indonesia/db_lang.php
