<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-05-23 22:24:38 --> Config Class Initialized
DEBUG - 2016-05-23 22:24:38 --> Hooks Class Initialized
DEBUG - 2016-05-23 22:24:38 --> Utf8 Class Initialized
DEBUG - 2016-05-23 22:24:38 --> UTF-8 Support Enabled
DEBUG - 2016-05-23 22:24:38 --> URI Class Initialized
DEBUG - 2016-05-23 22:24:39 --> Router Class Initialized
DEBUG - 2016-05-23 22:24:39 --> Output Class Initialized
DEBUG - 2016-05-23 22:24:39 --> Security Class Initialized
DEBUG - 2016-05-23 22:24:39 --> Input Class Initialized
DEBUG - 2016-05-23 22:24:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-23 22:24:39 --> Language Class Initialized
DEBUG - 2016-05-23 22:24:39 --> Loader Class Initialized
DEBUG - 2016-05-23 22:24:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-23 22:24:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-23 22:24:40 --> Helper loaded: url_helper
DEBUG - 2016-05-23 22:24:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-23 22:24:40 --> Helper loaded: file_helper
DEBUG - 2016-05-23 22:24:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-23 22:24:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-23 22:24:40 --> Helper loaded: conf_helper
DEBUG - 2016-05-23 22:24:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-23 22:24:40 --> Check Exists common_helper.php: No
DEBUG - 2016-05-23 22:24:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-23 22:24:40 --> Helper loaded: common_helper
DEBUG - 2016-05-23 22:24:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-23 22:24:40 --> Helper loaded: common_helper
DEBUG - 2016-05-23 22:24:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-23 22:24:40 --> Helper loaded: form_helper
DEBUG - 2016-05-23 22:24:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-23 22:24:40 --> Helper loaded: security_helper
DEBUG - 2016-05-23 22:24:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-23 22:24:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-23 22:24:40 --> Helper loaded: lang_helper
DEBUG - 2016-05-23 22:24:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-23 22:24:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-23 22:24:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-23 22:24:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-23 22:24:40 --> Helper loaded: atlant_helper
DEBUG - 2016-05-23 22:24:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-23 22:24:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-23 22:24:40 --> Helper loaded: crypto_helper
DEBUG - 2016-05-23 22:24:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-23 22:24:41 --> Database Driver Class Initialized
DEBUG - 2016-05-23 22:24:41 --> Session Class Initialized
DEBUG - 2016-05-23 22:24:41 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-23 22:24:41 --> Helper loaded: string_helper
DEBUG - 2016-05-23 22:24:41 --> A session cookie was not found.
DEBUG - 2016-05-23 22:24:42 --> Session routines successfully run
DEBUG - 2016-05-23 22:24:42 --> Native_session Class Initialized
DEBUG - 2016-05-23 22:24:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-23 22:24:42 --> Form Validation Class Initialized
DEBUG - 2016-05-23 22:24:42 --> Form Validation Class Initialized
DEBUG - 2016-05-23 22:24:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-23 22:24:42 --> Controller Class Initialized
DEBUG - 2016-05-23 22:24:42 --> Carabiner: Library initialized.
DEBUG - 2016-05-23 22:24:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-23 22:24:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-23 22:24:42 --> Carabiner: library configured.
DEBUG - 2016-05-23 22:24:42 --> Carabiner: library configured.
DEBUG - 2016-05-23 22:24:42 --> User Agent Class Initialized
DEBUG - 2016-05-23 22:24:43 --> Model Class Initialized
DEBUG - 2016-05-23 22:24:43 --> Model Class Initialized
DEBUG - 2016-05-23 22:24:43 --> Model Class Initialized
DEBUG - 2016-05-23 22:24:45 --> Model Class Initialized
DEBUG - 2016-05-23 22:24:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-23 22:24:46 --> Pagination Class Initialized
DEBUG - 2016-05-23 22:24:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-23 22:24:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/index.php
DEBUG - 2016-05-23 22:24:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-23 22:24:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-23 22:24:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-23 22:24:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-23 22:24:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-05-23 22:24:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-23 22:24:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-23 22:24:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-23 22:24:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-23 22:24:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-23 22:24:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-23 22:24:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-05-23 22:24:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-23 22:24:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-23 22:24:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0afc8ae14bdb2df5b4e2fbf4366db4fc
DEBUG - 2016-05-23 22:24:46 --> Final output sent to browser
DEBUG - 2016-05-23 22:24:46 --> Total execution time: 7.8719
DEBUG - 2016-05-23 22:25:01 --> Config Class Initialized
DEBUG - 2016-05-23 22:25:01 --> Hooks Class Initialized
DEBUG - 2016-05-23 22:25:01 --> Utf8 Class Initialized
DEBUG - 2016-05-23 22:25:01 --> UTF-8 Support Enabled
DEBUG - 2016-05-23 22:25:01 --> URI Class Initialized
DEBUG - 2016-05-23 22:25:01 --> Router Class Initialized
ERROR - 2016-05-23 22:25:01 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-05-23 22:25:06 --> Config Class Initialized
DEBUG - 2016-05-23 22:25:06 --> Hooks Class Initialized
DEBUG - 2016-05-23 22:25:06 --> Utf8 Class Initialized
DEBUG - 2016-05-23 22:25:06 --> UTF-8 Support Enabled
DEBUG - 2016-05-23 22:25:06 --> URI Class Initialized
DEBUG - 2016-05-23 22:25:06 --> Router Class Initialized
DEBUG - 2016-05-23 22:25:06 --> Output Class Initialized
DEBUG - 2016-05-23 22:25:06 --> Cache file has expired. File deleted
DEBUG - 2016-05-23 22:25:06 --> Security Class Initialized
DEBUG - 2016-05-23 22:25:06 --> Input Class Initialized
DEBUG - 2016-05-23 22:25:06 --> XSS Filtering completed
DEBUG - 2016-05-23 22:25:06 --> XSS Filtering completed
DEBUG - 2016-05-23 22:25:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-23 22:25:06 --> Language Class Initialized
DEBUG - 2016-05-23 22:25:06 --> Loader Class Initialized
DEBUG - 2016-05-23 22:25:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-23 22:25:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-23 22:25:06 --> Helper loaded: url_helper
DEBUG - 2016-05-23 22:25:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-23 22:25:06 --> Helper loaded: file_helper
DEBUG - 2016-05-23 22:25:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-23 22:25:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-23 22:25:06 --> Helper loaded: conf_helper
DEBUG - 2016-05-23 22:25:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-23 22:25:06 --> Check Exists common_helper.php: No
DEBUG - 2016-05-23 22:25:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-23 22:25:06 --> Helper loaded: common_helper
DEBUG - 2016-05-23 22:25:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-23 22:25:06 --> Helper loaded: common_helper
DEBUG - 2016-05-23 22:25:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-23 22:25:06 --> Helper loaded: form_helper
DEBUG - 2016-05-23 22:25:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-23 22:25:06 --> Helper loaded: security_helper
DEBUG - 2016-05-23 22:25:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-23 22:25:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-23 22:25:06 --> Helper loaded: lang_helper
DEBUG - 2016-05-23 22:25:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-23 22:25:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-23 22:25:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-23 22:25:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-23 22:25:06 --> Helper loaded: atlant_helper
DEBUG - 2016-05-23 22:25:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-23 22:25:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-23 22:25:06 --> Helper loaded: crypto_helper
DEBUG - 2016-05-23 22:25:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-23 22:25:06 --> Database Driver Class Initialized
DEBUG - 2016-05-23 22:25:06 --> Session Class Initialized
DEBUG - 2016-05-23 22:25:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-23 22:25:06 --> Helper loaded: string_helper
DEBUG - 2016-05-23 22:25:06 --> Session routines successfully run
DEBUG - 2016-05-23 22:25:06 --> Native_session Class Initialized
DEBUG - 2016-05-23 22:25:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-23 22:25:06 --> Form Validation Class Initialized
DEBUG - 2016-05-23 22:25:06 --> Form Validation Class Initialized
DEBUG - 2016-05-23 22:25:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-23 22:25:06 --> Controller Class Initialized
DEBUG - 2016-05-23 22:25:06 --> Carabiner: Library initialized.
DEBUG - 2016-05-23 22:25:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-23 22:25:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-23 22:25:06 --> Carabiner: library configured.
DEBUG - 2016-05-23 22:25:06 --> Carabiner: library configured.
DEBUG - 2016-05-23 22:25:06 --> User Agent Class Initialized
DEBUG - 2016-05-23 22:25:06 --> Model Class Initialized
DEBUG - 2016-05-23 22:25:06 --> Model Class Initialized
DEBUG - 2016-05-23 22:25:06 --> Model Class Initialized
DEBUG - 2016-05-23 22:25:06 --> Model Class Initialized
DEBUG - 2016-05-23 22:25:06 --> Model Class Initialized
DEBUG - 2016-05-23 22:25:06 --> Model Class Initialized
DEBUG - 2016-05-23 22:25:06 --> Model Class Initialized
DEBUG - 2016-05-23 22:25:06 --> Model Class Initialized
DEBUG - 2016-05-23 22:25:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-23 22:25:09 --> Pagination Class Initialized
DEBUG - 2016-05-23 22:25:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-23 22:25:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-05-23 22:25:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-23 22:25:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-23 22:25:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-23 22:25:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-23 22:25:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-23 22:25:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-23 22:25:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-23 22:25:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-23 22:25:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-23 22:25:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-23 22:25:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-23 22:25:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-05-23 22:25:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-23 22:25:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-23 22:25:09 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-05-23 22:25:09 --> Final output sent to browser
DEBUG - 2016-05-23 22:25:09 --> Total execution time: 3.2323
DEBUG - 2016-05-23 22:25:21 --> Config Class Initialized
DEBUG - 2016-05-23 22:25:21 --> Hooks Class Initialized
DEBUG - 2016-05-23 22:25:21 --> Utf8 Class Initialized
DEBUG - 2016-05-23 22:25:21 --> UTF-8 Support Enabled
DEBUG - 2016-05-23 22:25:21 --> URI Class Initialized
DEBUG - 2016-05-23 22:25:21 --> Router Class Initialized
ERROR - 2016-05-23 22:25:21 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-05-23 22:25:26 --> Config Class Initialized
DEBUG - 2016-05-23 22:25:26 --> Hooks Class Initialized
DEBUG - 2016-05-23 22:25:26 --> Utf8 Class Initialized
DEBUG - 2016-05-23 22:25:26 --> UTF-8 Support Enabled
DEBUG - 2016-05-23 22:25:26 --> URI Class Initialized
DEBUG - 2016-05-23 22:25:26 --> Router Class Initialized
DEBUG - 2016-05-23 22:25:26 --> Output Class Initialized
DEBUG - 2016-05-23 22:25:26 --> Cache file has expired. File deleted
DEBUG - 2016-05-23 22:25:26 --> Security Class Initialized
DEBUG - 2016-05-23 22:25:26 --> Input Class Initialized
DEBUG - 2016-05-23 22:25:26 --> XSS Filtering completed
DEBUG - 2016-05-23 22:25:26 --> XSS Filtering completed
DEBUG - 2016-05-23 22:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-23 22:25:26 --> Language Class Initialized
DEBUG - 2016-05-23 22:25:26 --> Loader Class Initialized
DEBUG - 2016-05-23 22:25:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-23 22:25:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-23 22:25:26 --> Helper loaded: url_helper
DEBUG - 2016-05-23 22:25:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-23 22:25:26 --> Helper loaded: file_helper
DEBUG - 2016-05-23 22:25:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-23 22:25:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-23 22:25:26 --> Helper loaded: conf_helper
DEBUG - 2016-05-23 22:25:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-23 22:25:26 --> Check Exists common_helper.php: No
DEBUG - 2016-05-23 22:25:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-23 22:25:26 --> Helper loaded: common_helper
DEBUG - 2016-05-23 22:25:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-23 22:25:26 --> Helper loaded: common_helper
DEBUG - 2016-05-23 22:25:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-23 22:25:26 --> Helper loaded: form_helper
DEBUG - 2016-05-23 22:25:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-23 22:25:26 --> Helper loaded: security_helper
DEBUG - 2016-05-23 22:25:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-23 22:25:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-23 22:25:26 --> Helper loaded: lang_helper
DEBUG - 2016-05-23 22:25:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-23 22:25:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-23 22:25:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-23 22:25:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-23 22:25:26 --> Helper loaded: atlant_helper
DEBUG - 2016-05-23 22:25:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-23 22:25:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-23 22:25:26 --> Helper loaded: crypto_helper
DEBUG - 2016-05-23 22:25:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-23 22:25:26 --> Database Driver Class Initialized
DEBUG - 2016-05-23 22:25:26 --> Session Class Initialized
DEBUG - 2016-05-23 22:25:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-23 22:25:26 --> Helper loaded: string_helper
DEBUG - 2016-05-23 22:25:26 --> Session routines successfully run
DEBUG - 2016-05-23 22:25:26 --> Native_session Class Initialized
DEBUG - 2016-05-23 22:25:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-23 22:25:26 --> Form Validation Class Initialized
DEBUG - 2016-05-23 22:25:26 --> Form Validation Class Initialized
DEBUG - 2016-05-23 22:25:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-23 22:25:26 --> Controller Class Initialized
DEBUG - 2016-05-23 22:25:26 --> Carabiner: Library initialized.
DEBUG - 2016-05-23 22:25:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-23 22:25:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-23 22:25:26 --> Carabiner: library configured.
DEBUG - 2016-05-23 22:25:26 --> Carabiner: library configured.
DEBUG - 2016-05-23 22:25:26 --> User Agent Class Initialized
DEBUG - 2016-05-23 22:25:26 --> Model Class Initialized
DEBUG - 2016-05-23 22:25:26 --> Model Class Initialized
DEBUG - 2016-05-23 22:25:26 --> Model Class Initialized
DEBUG - 2016-05-23 22:25:26 --> Model Class Initialized
DEBUG - 2016-05-23 22:25:26 --> Model Class Initialized
DEBUG - 2016-05-23 22:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-23 22:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-23 22:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-23 22:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-23 22:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-23 22:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-23 22:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-23 22:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-23 22:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-23 22:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-23 22:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-23 22:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-23 22:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-23 22:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-23 22:25:26 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-05-23 22:25:26 --> Final output sent to browser
DEBUG - 2016-05-23 22:25:26 --> Total execution time: 0.4401
DEBUG - 2016-05-23 22:25:39 --> Config Class Initialized
DEBUG - 2016-05-23 22:25:39 --> Hooks Class Initialized
DEBUG - 2016-05-23 22:25:39 --> Utf8 Class Initialized
DEBUG - 2016-05-23 22:25:39 --> UTF-8 Support Enabled
DEBUG - 2016-05-23 22:25:39 --> URI Class Initialized
DEBUG - 2016-05-23 22:25:39 --> Router Class Initialized
DEBUG - 2016-05-23 22:25:39 --> Output Class Initialized
DEBUG - 2016-05-23 22:25:39 --> Cache file has expired. File deleted
DEBUG - 2016-05-23 22:25:39 --> Security Class Initialized
DEBUG - 2016-05-23 22:25:39 --> Input Class Initialized
DEBUG - 2016-05-23 22:25:39 --> XSS Filtering completed
DEBUG - 2016-05-23 22:25:39 --> XSS Filtering completed
DEBUG - 2016-05-23 22:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-23 22:25:39 --> Language Class Initialized
DEBUG - 2016-05-23 22:25:39 --> Loader Class Initialized
DEBUG - 2016-05-23 22:25:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-23 22:25:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-23 22:25:39 --> Helper loaded: url_helper
DEBUG - 2016-05-23 22:25:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-23 22:25:39 --> Helper loaded: file_helper
DEBUG - 2016-05-23 22:25:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-23 22:25:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-23 22:25:39 --> Helper loaded: conf_helper
DEBUG - 2016-05-23 22:25:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-23 22:25:39 --> Check Exists common_helper.php: No
DEBUG - 2016-05-23 22:25:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-23 22:25:39 --> Helper loaded: common_helper
DEBUG - 2016-05-23 22:25:39 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-23 22:25:39 --> Helper loaded: common_helper
DEBUG - 2016-05-23 22:25:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-23 22:25:39 --> Helper loaded: form_helper
DEBUG - 2016-05-23 22:25:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-23 22:25:39 --> Helper loaded: security_helper
DEBUG - 2016-05-23 22:25:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-23 22:25:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-23 22:25:39 --> Helper loaded: lang_helper
DEBUG - 2016-05-23 22:25:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-23 22:25:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-23 22:25:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-23 22:25:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-23 22:25:39 --> Helper loaded: atlant_helper
DEBUG - 2016-05-23 22:25:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-23 22:25:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-23 22:25:39 --> Helper loaded: crypto_helper
DEBUG - 2016-05-23 22:25:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-23 22:25:39 --> Database Driver Class Initialized
DEBUG - 2016-05-23 22:25:39 --> Session Class Initialized
DEBUG - 2016-05-23 22:25:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-23 22:25:39 --> Helper loaded: string_helper
DEBUG - 2016-05-23 22:25:39 --> Session routines successfully run
DEBUG - 2016-05-23 22:25:39 --> Native_session Class Initialized
DEBUG - 2016-05-23 22:25:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-23 22:25:39 --> Form Validation Class Initialized
DEBUG - 2016-05-23 22:25:39 --> Form Validation Class Initialized
DEBUG - 2016-05-23 22:25:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-23 22:25:39 --> Controller Class Initialized
DEBUG - 2016-05-23 22:25:39 --> Carabiner: Library initialized.
DEBUG - 2016-05-23 22:25:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-23 22:25:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-23 22:25:39 --> Carabiner: library configured.
DEBUG - 2016-05-23 22:25:39 --> Carabiner: library configured.
DEBUG - 2016-05-23 22:25:39 --> User Agent Class Initialized
DEBUG - 2016-05-23 22:25:39 --> Model Class Initialized
DEBUG - 2016-05-23 22:25:39 --> Model Class Initialized
DEBUG - 2016-05-23 22:25:39 --> Model Class Initialized
DEBUG - 2016-05-23 22:25:39 --> Model Class Initialized
DEBUG - 2016-05-23 22:25:39 --> Model Class Initialized
ERROR - 2016-05-23 22:25:39 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-05-23 22:25:39 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-05-23 22:25:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-23 22:25:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-23 22:25:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-23 22:25:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-23 22:25:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-23 22:25:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-23 22:25:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-23 22:25:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-23 22:25:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-23 22:25:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-23 22:25:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-23 22:25:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-23 22:25:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-23 22:25:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-23 22:25:39 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-05-23 22:25:39 --> Final output sent to browser
DEBUG - 2016-05-23 22:25:39 --> Total execution time: 0.3476
