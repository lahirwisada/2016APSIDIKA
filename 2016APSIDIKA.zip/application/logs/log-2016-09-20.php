<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-09-20 11:09:23 --> Config Class Initialized
DEBUG - 2016-09-20 11:09:23 --> Hooks Class Initialized
DEBUG - 2016-09-20 11:09:23 --> Utf8 Class Initialized
DEBUG - 2016-09-20 11:09:23 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 11:09:23 --> URI Class Initialized
DEBUG - 2016-09-20 11:09:23 --> Router Class Initialized
DEBUG - 2016-09-20 11:09:23 --> No URI present. Default controller set.
DEBUG - 2016-09-20 11:09:23 --> Output Class Initialized
DEBUG - 2016-09-20 11:09:23 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 11:09:23 --> Security Class Initialized
DEBUG - 2016-09-20 11:09:23 --> Input Class Initialized
DEBUG - 2016-09-20 11:09:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 11:09:23 --> Language Class Initialized
DEBUG - 2016-09-20 11:09:23 --> Loader Class Initialized
DEBUG - 2016-09-20 11:09:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 11:09:23 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 11:09:23 --> Helper loaded: url_helper
DEBUG - 2016-09-20 11:09:23 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 11:09:23 --> Helper loaded: file_helper
DEBUG - 2016-09-20 11:09:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 11:09:23 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 11:09:23 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 11:09:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 11:09:23 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 11:09:23 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 11:09:23 --> Helper loaded: common_helper
DEBUG - 2016-09-20 11:09:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 11:09:23 --> Helper loaded: common_helper
DEBUG - 2016-09-20 11:09:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 11:09:23 --> Helper loaded: form_helper
DEBUG - 2016-09-20 11:09:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 11:09:23 --> Helper loaded: security_helper
DEBUG - 2016-09-20 11:09:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 11:09:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 11:09:23 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 11:09:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 11:09:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 11:09:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 11:09:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 11:09:23 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 11:09:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 11:09:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 11:09:23 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 11:09:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 11:09:23 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 11:09:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 11:09:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 11:09:23 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 11:09:23 --> Database Driver Class Initialized
DEBUG - 2016-09-20 11:09:23 --> Session Class Initialized
DEBUG - 2016-09-20 11:09:23 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 11:09:23 --> Helper loaded: string_helper
DEBUG - 2016-09-20 11:09:23 --> A session cookie was not found.
DEBUG - 2016-09-20 11:09:23 --> Session routines successfully run
DEBUG - 2016-09-20 11:09:23 --> Native_session Class Initialized
DEBUG - 2016-09-20 11:09:23 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 11:09:23 --> Form Validation Class Initialized
DEBUG - 2016-09-20 11:09:23 --> Form Validation Class Initialized
DEBUG - 2016-09-20 11:09:23 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 11:09:23 --> Controller Class Initialized
DEBUG - 2016-09-20 11:09:23 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 11:09:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 11:09:23 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 11:09:23 --> Carabiner: library configured.
DEBUG - 2016-09-20 11:09:23 --> Carabiner: library configured.
DEBUG - 2016-09-20 11:09:23 --> User Agent Class Initialized
DEBUG - 2016-09-20 11:09:23 --> Model Class Initialized
DEBUG - 2016-09-20 11:09:23 --> Model Class Initialized
DEBUG - 2016-09-20 11:09:23 --> Model Class Initialized
ERROR - 2016-09-20 11:09:23 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 11:09:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-20 11:09:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-20 11:09:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 11:09:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 11:09:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 11:09:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 11:09:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 11:09:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-20 11:09:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-20 11:09:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 11:09:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 11:09:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 11:09:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 11:09:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 11:09:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 11:09:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 11:09:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-20 11:09:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-20 11:09:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 11:09:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 11:09:23 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-20 11:09:23 --> Final output sent to browser
DEBUG - 2016-09-20 11:09:23 --> Total execution time: 0.3068
DEBUG - 2016-09-20 11:09:24 --> Config Class Initialized
DEBUG - 2016-09-20 11:09:24 --> Hooks Class Initialized
DEBUG - 2016-09-20 11:09:24 --> Utf8 Class Initialized
DEBUG - 2016-09-20 11:09:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 11:09:24 --> URI Class Initialized
DEBUG - 2016-09-20 11:09:24 --> Router Class Initialized
DEBUG - 2016-09-20 11:09:24 --> Output Class Initialized
DEBUG - 2016-09-20 11:09:24 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 11:09:24 --> Security Class Initialized
DEBUG - 2016-09-20 11:09:24 --> Input Class Initialized
DEBUG - 2016-09-20 11:09:24 --> XSS Filtering completed
DEBUG - 2016-09-20 11:09:24 --> XSS Filtering completed
DEBUG - 2016-09-20 11:09:24 --> XSS Filtering completed
DEBUG - 2016-09-20 11:09:24 --> XSS Filtering completed
DEBUG - 2016-09-20 11:09:24 --> XSS Filtering completed
DEBUG - 2016-09-20 11:09:24 --> XSS Filtering completed
DEBUG - 2016-09-20 11:09:24 --> XSS Filtering completed
DEBUG - 2016-09-20 11:09:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 11:09:24 --> Language Class Initialized
DEBUG - 2016-09-20 11:09:24 --> Loader Class Initialized
DEBUG - 2016-09-20 11:09:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 11:09:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 11:09:24 --> Helper loaded: url_helper
DEBUG - 2016-09-20 11:09:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 11:09:24 --> Helper loaded: file_helper
DEBUG - 2016-09-20 11:09:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 11:09:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 11:09:24 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 11:09:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 11:09:24 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 11:09:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 11:09:24 --> Helper loaded: common_helper
DEBUG - 2016-09-20 11:09:24 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 11:09:24 --> Helper loaded: common_helper
DEBUG - 2016-09-20 11:09:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 11:09:24 --> Helper loaded: form_helper
DEBUG - 2016-09-20 11:09:24 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 11:09:24 --> Helper loaded: security_helper
DEBUG - 2016-09-20 11:09:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 11:09:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 11:09:24 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 11:09:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 11:09:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 11:09:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 11:09:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 11:09:24 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 11:09:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 11:09:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 11:09:24 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 11:09:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 11:09:24 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 11:09:24 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 11:09:24 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 11:09:24 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 11:09:24 --> Database Driver Class Initialized
DEBUG - 2016-09-20 11:09:24 --> Session Class Initialized
DEBUG - 2016-09-20 11:09:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 11:09:24 --> Helper loaded: string_helper
DEBUG - 2016-09-20 11:09:24 --> Session routines successfully run
DEBUG - 2016-09-20 11:09:24 --> Native_session Class Initialized
DEBUG - 2016-09-20 11:09:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 11:09:24 --> Form Validation Class Initialized
DEBUG - 2016-09-20 11:09:24 --> Form Validation Class Initialized
DEBUG - 2016-09-20 11:09:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 11:09:24 --> Controller Class Initialized
DEBUG - 2016-09-20 11:09:24 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 11:09:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 11:09:24 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 11:09:24 --> Carabiner: library configured.
DEBUG - 2016-09-20 11:09:24 --> Carabiner: library configured.
DEBUG - 2016-09-20 11:09:24 --> User Agent Class Initialized
DEBUG - 2016-09-20 11:09:24 --> Model Class Initialized
DEBUG - 2016-09-20 11:09:24 --> Model Class Initialized
DEBUG - 2016-09-20 11:09:24 --> Model Class Initialized
DEBUG - 2016-09-20 11:09:24 --> Model Class Initialized
DEBUG - 2016-09-20 11:09:24 --> Model Class Initialized
DEBUG - 2016-09-20 11:09:24 --> Model Class Initialized
DEBUG - 2016-09-20 11:09:24 --> Model Class Initialized
DEBUG - 2016-09-20 11:09:24 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-20 11:09:24 --> Final output sent to browser
DEBUG - 2016-09-20 11:09:24 --> Total execution time: 0.2758
DEBUG - 2016-09-20 11:09:27 --> Config Class Initialized
DEBUG - 2016-09-20 11:09:27 --> Hooks Class Initialized
DEBUG - 2016-09-20 11:09:27 --> Utf8 Class Initialized
DEBUG - 2016-09-20 11:09:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 11:09:27 --> URI Class Initialized
DEBUG - 2016-09-20 11:09:27 --> Router Class Initialized
DEBUG - 2016-09-20 11:09:27 --> Output Class Initialized
DEBUG - 2016-09-20 11:09:27 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 11:09:27 --> Security Class Initialized
DEBUG - 2016-09-20 11:09:27 --> Input Class Initialized
DEBUG - 2016-09-20 11:09:27 --> XSS Filtering completed
DEBUG - 2016-09-20 11:09:27 --> XSS Filtering completed
DEBUG - 2016-09-20 11:09:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 11:09:27 --> Language Class Initialized
DEBUG - 2016-09-20 11:09:27 --> Loader Class Initialized
DEBUG - 2016-09-20 11:09:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 11:09:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 11:09:27 --> Helper loaded: url_helper
DEBUG - 2016-09-20 11:09:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 11:09:27 --> Helper loaded: file_helper
DEBUG - 2016-09-20 11:09:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 11:09:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 11:09:27 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 11:09:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 11:09:27 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 11:09:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 11:09:27 --> Helper loaded: common_helper
DEBUG - 2016-09-20 11:09:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 11:09:27 --> Helper loaded: common_helper
DEBUG - 2016-09-20 11:09:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 11:09:27 --> Helper loaded: form_helper
DEBUG - 2016-09-20 11:09:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 11:09:27 --> Helper loaded: security_helper
DEBUG - 2016-09-20 11:09:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 11:09:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 11:09:27 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 11:09:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 11:09:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 11:09:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 11:09:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 11:09:27 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 11:09:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 11:09:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 11:09:27 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 11:09:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 11:09:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 11:09:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 11:09:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 11:09:27 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 11:09:27 --> Database Driver Class Initialized
DEBUG - 2016-09-20 11:09:27 --> Session Class Initialized
DEBUG - 2016-09-20 11:09:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 11:09:27 --> Helper loaded: string_helper
DEBUG - 2016-09-20 11:09:27 --> Session routines successfully run
DEBUG - 2016-09-20 11:09:27 --> Native_session Class Initialized
DEBUG - 2016-09-20 11:09:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 11:09:27 --> Form Validation Class Initialized
DEBUG - 2016-09-20 11:09:27 --> Form Validation Class Initialized
DEBUG - 2016-09-20 11:09:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 11:09:27 --> Controller Class Initialized
DEBUG - 2016-09-20 11:09:27 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 11:09:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 11:09:27 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 11:09:27 --> Carabiner: library configured.
DEBUG - 2016-09-20 11:09:27 --> Carabiner: library configured.
DEBUG - 2016-09-20 11:09:27 --> User Agent Class Initialized
DEBUG - 2016-09-20 11:09:27 --> Model Class Initialized
DEBUG - 2016-09-20 11:09:27 --> Model Class Initialized
DEBUG - 2016-09-20 11:09:27 --> Model Class Initialized
ERROR - 2016-09-20 11:09:27 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 11:09:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-20 11:09:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 11:09:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 11:09:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 11:09:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 11:09:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 11:09:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 11:09:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 11:09:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 11:09:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 11:09:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 11:09:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 11:09:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 11:09:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 11:09:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 11:09:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-20 11:09:27 --> Final output sent to browser
DEBUG - 2016-09-20 11:09:27 --> Total execution time: 0.2145
DEBUG - 2016-09-20 12:35:03 --> Config Class Initialized
DEBUG - 2016-09-20 12:35:03 --> Hooks Class Initialized
DEBUG - 2016-09-20 12:35:03 --> Utf8 Class Initialized
DEBUG - 2016-09-20 12:35:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 12:35:03 --> URI Class Initialized
DEBUG - 2016-09-20 12:35:03 --> Router Class Initialized
DEBUG - 2016-09-20 12:35:03 --> Output Class Initialized
DEBUG - 2016-09-20 12:35:03 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 12:35:03 --> Security Class Initialized
DEBUG - 2016-09-20 12:35:03 --> Input Class Initialized
DEBUG - 2016-09-20 12:35:03 --> XSS Filtering completed
DEBUG - 2016-09-20 12:35:03 --> XSS Filtering completed
DEBUG - 2016-09-20 12:35:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 12:35:03 --> Language Class Initialized
DEBUG - 2016-09-20 12:35:03 --> Loader Class Initialized
DEBUG - 2016-09-20 12:35:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 12:35:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 12:35:03 --> Helper loaded: url_helper
DEBUG - 2016-09-20 12:35:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 12:35:03 --> Helper loaded: file_helper
DEBUG - 2016-09-20 12:35:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 12:35:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 12:35:03 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 12:35:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 12:35:03 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 12:35:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 12:35:03 --> Helper loaded: common_helper
DEBUG - 2016-09-20 12:35:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 12:35:03 --> Helper loaded: common_helper
DEBUG - 2016-09-20 12:35:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 12:35:03 --> Helper loaded: form_helper
DEBUG - 2016-09-20 12:35:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 12:35:03 --> Helper loaded: security_helper
DEBUG - 2016-09-20 12:35:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 12:35:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 12:35:03 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 12:35:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 12:35:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 12:35:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 12:35:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 12:35:03 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 12:35:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 12:35:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 12:35:03 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 12:35:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 12:35:03 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 12:35:03 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 12:35:03 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 12:35:03 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 12:35:03 --> Database Driver Class Initialized
DEBUG - 2016-09-20 12:35:03 --> Session Class Initialized
DEBUG - 2016-09-20 12:35:03 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 12:35:03 --> Helper loaded: string_helper
DEBUG - 2016-09-20 12:35:03 --> Session routines successfully run
DEBUG - 2016-09-20 12:35:03 --> Native_session Class Initialized
DEBUG - 2016-09-20 12:35:03 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 12:35:03 --> Form Validation Class Initialized
DEBUG - 2016-09-20 12:35:03 --> Form Validation Class Initialized
DEBUG - 2016-09-20 12:35:03 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 12:35:03 --> Controller Class Initialized
DEBUG - 2016-09-20 12:35:03 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 12:35:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 12:35:03 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 12:35:03 --> Carabiner: library configured.
DEBUG - 2016-09-20 12:35:03 --> Carabiner: library configured.
DEBUG - 2016-09-20 12:35:03 --> User Agent Class Initialized
DEBUG - 2016-09-20 12:35:03 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:03 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:03 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-20 12:35:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-20 12:35:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-20 12:35:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 12:35:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-20 12:35:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 12:35:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-20 12:35:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-20 12:35:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-20 12:35:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 12:35:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-20 12:35:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 12:35:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-20 12:35:03 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-09-20 12:35:03 --> Final output sent to browser
DEBUG - 2016-09-20 12:35:03 --> Total execution time: 0.2366
DEBUG - 2016-09-20 12:35:06 --> Config Class Initialized
DEBUG - 2016-09-20 12:35:06 --> Hooks Class Initialized
DEBUG - 2016-09-20 12:35:06 --> Utf8 Class Initialized
DEBUG - 2016-09-20 12:35:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 12:35:06 --> URI Class Initialized
DEBUG - 2016-09-20 12:35:06 --> Router Class Initialized
DEBUG - 2016-09-20 12:35:06 --> Output Class Initialized
DEBUG - 2016-09-20 12:35:06 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 12:35:06 --> Security Class Initialized
DEBUG - 2016-09-20 12:35:06 --> Input Class Initialized
DEBUG - 2016-09-20 12:35:06 --> XSS Filtering completed
DEBUG - 2016-09-20 12:35:06 --> XSS Filtering completed
DEBUG - 2016-09-20 12:35:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 12:35:06 --> Language Class Initialized
DEBUG - 2016-09-20 12:35:06 --> Loader Class Initialized
DEBUG - 2016-09-20 12:35:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 12:35:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 12:35:06 --> Helper loaded: url_helper
DEBUG - 2016-09-20 12:35:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 12:35:07 --> Helper loaded: file_helper
DEBUG - 2016-09-20 12:35:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 12:35:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 12:35:07 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 12:35:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 12:35:07 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 12:35:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 12:35:07 --> Helper loaded: common_helper
DEBUG - 2016-09-20 12:35:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 12:35:07 --> Helper loaded: common_helper
DEBUG - 2016-09-20 12:35:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 12:35:07 --> Helper loaded: form_helper
DEBUG - 2016-09-20 12:35:07 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 12:35:07 --> Helper loaded: security_helper
DEBUG - 2016-09-20 12:35:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 12:35:07 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 12:35:07 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 12:35:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 12:35:07 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 12:35:07 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 12:35:07 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 12:35:07 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 12:35:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 12:35:07 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 12:35:07 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 12:35:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 12:35:07 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 12:35:07 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 12:35:07 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 12:35:07 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 12:35:07 --> Database Driver Class Initialized
DEBUG - 2016-09-20 12:35:07 --> Session Class Initialized
DEBUG - 2016-09-20 12:35:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 12:35:07 --> Helper loaded: string_helper
DEBUG - 2016-09-20 12:35:07 --> Session routines successfully run
DEBUG - 2016-09-20 12:35:07 --> Native_session Class Initialized
DEBUG - 2016-09-20 12:35:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 12:35:07 --> Form Validation Class Initialized
DEBUG - 2016-09-20 12:35:07 --> Form Validation Class Initialized
DEBUG - 2016-09-20 12:35:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 12:35:07 --> Controller Class Initialized
DEBUG - 2016-09-20 12:35:07 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 12:35:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 12:35:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 12:35:07 --> Carabiner: library configured.
DEBUG - 2016-09-20 12:35:07 --> Carabiner: library configured.
DEBUG - 2016-09-20 12:35:07 --> User Agent Class Initialized
DEBUG - 2016-09-20 12:35:07 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:07 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:07 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-20 12:35:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-20 12:35:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-20 12:35:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 12:35:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-20 12:35:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 12:35:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-20 12:35:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-20 12:35:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-20 12:35:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 12:35:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-20 12:35:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 12:35:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-20 12:35:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-09-20 12:35:07 --> Final output sent to browser
DEBUG - 2016-09-20 12:35:07 --> Total execution time: 0.2271
DEBUG - 2016-09-20 12:35:09 --> Config Class Initialized
DEBUG - 2016-09-20 12:35:09 --> Hooks Class Initialized
DEBUG - 2016-09-20 12:35:09 --> Utf8 Class Initialized
DEBUG - 2016-09-20 12:35:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 12:35:09 --> URI Class Initialized
DEBUG - 2016-09-20 12:35:09 --> Router Class Initialized
DEBUG - 2016-09-20 12:35:09 --> Output Class Initialized
DEBUG - 2016-09-20 12:35:09 --> Security Class Initialized
DEBUG - 2016-09-20 12:35:09 --> Input Class Initialized
DEBUG - 2016-09-20 12:35:09 --> XSS Filtering completed
DEBUG - 2016-09-20 12:35:09 --> XSS Filtering completed
DEBUG - 2016-09-20 12:35:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 12:35:09 --> Language Class Initialized
DEBUG - 2016-09-20 12:35:09 --> Loader Class Initialized
DEBUG - 2016-09-20 12:35:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 12:35:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 12:35:09 --> Helper loaded: url_helper
DEBUG - 2016-09-20 12:35:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 12:35:09 --> Helper loaded: file_helper
DEBUG - 2016-09-20 12:35:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 12:35:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 12:35:09 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 12:35:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 12:35:09 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 12:35:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 12:35:09 --> Helper loaded: common_helper
DEBUG - 2016-09-20 12:35:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 12:35:09 --> Helper loaded: common_helper
DEBUG - 2016-09-20 12:35:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 12:35:09 --> Helper loaded: form_helper
DEBUG - 2016-09-20 12:35:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 12:35:09 --> Helper loaded: security_helper
DEBUG - 2016-09-20 12:35:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 12:35:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 12:35:09 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 12:35:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 12:35:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 12:35:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 12:35:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 12:35:09 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 12:35:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 12:35:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 12:35:09 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 12:35:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 12:35:09 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 12:35:09 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 12:35:09 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 12:35:09 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 12:35:09 --> Database Driver Class Initialized
DEBUG - 2016-09-20 12:35:09 --> Session Class Initialized
DEBUG - 2016-09-20 12:35:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 12:35:09 --> Helper loaded: string_helper
DEBUG - 2016-09-20 12:35:09 --> Session routines successfully run
DEBUG - 2016-09-20 12:35:09 --> Native_session Class Initialized
DEBUG - 2016-09-20 12:35:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 12:35:09 --> Form Validation Class Initialized
DEBUG - 2016-09-20 12:35:09 --> Form Validation Class Initialized
DEBUG - 2016-09-20 12:35:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 12:35:09 --> Controller Class Initialized
DEBUG - 2016-09-20 12:35:09 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 12:35:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 12:35:09 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 12:35:09 --> Carabiner: library configured.
DEBUG - 2016-09-20 12:35:09 --> Carabiner: library configured.
DEBUG - 2016-09-20 12:35:09 --> User Agent Class Initialized
DEBUG - 2016-09-20 12:35:09 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:09 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:09 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:09 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:09 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:09 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:09 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:09 --> Model Class Initialized
ERROR - 2016-09-20 12:35:09 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 12:35:09 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-20 12:35:09 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-09-20 12:35:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-20 12:35:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-20 12:35:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-20 12:35:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-20 12:35:09 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-09-20 12:35:09 --> Final output sent to browser
DEBUG - 2016-09-20 12:35:09 --> Total execution time: 0.2666
DEBUG - 2016-09-20 12:35:09 --> Config Class Initialized
DEBUG - 2016-09-20 12:35:09 --> Hooks Class Initialized
DEBUG - 2016-09-20 12:35:09 --> Utf8 Class Initialized
DEBUG - 2016-09-20 12:35:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 12:35:09 --> URI Class Initialized
DEBUG - 2016-09-20 12:35:09 --> Router Class Initialized
ERROR - 2016-09-20 12:35:09 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-09-20 12:35:18 --> Config Class Initialized
DEBUG - 2016-09-20 12:35:18 --> Hooks Class Initialized
DEBUG - 2016-09-20 12:35:18 --> Utf8 Class Initialized
DEBUG - 2016-09-20 12:35:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 12:35:18 --> URI Class Initialized
DEBUG - 2016-09-20 12:35:18 --> Router Class Initialized
DEBUG - 2016-09-20 12:35:18 --> Output Class Initialized
DEBUG - 2016-09-20 12:35:18 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 12:35:18 --> Security Class Initialized
DEBUG - 2016-09-20 12:35:18 --> Input Class Initialized
DEBUG - 2016-09-20 12:35:18 --> XSS Filtering completed
DEBUG - 2016-09-20 12:35:18 --> XSS Filtering completed
DEBUG - 2016-09-20 12:35:18 --> XSS Filtering completed
DEBUG - 2016-09-20 12:35:18 --> XSS Filtering completed
DEBUG - 2016-09-20 12:35:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 12:35:18 --> Language Class Initialized
DEBUG - 2016-09-20 12:35:18 --> Loader Class Initialized
DEBUG - 2016-09-20 12:35:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 12:35:18 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 12:35:18 --> Helper loaded: url_helper
DEBUG - 2016-09-20 12:35:18 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 12:35:18 --> Helper loaded: file_helper
DEBUG - 2016-09-20 12:35:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 12:35:18 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 12:35:18 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 12:35:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 12:35:19 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 12:35:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 12:35:19 --> Helper loaded: common_helper
DEBUG - 2016-09-20 12:35:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 12:35:19 --> Helper loaded: common_helper
DEBUG - 2016-09-20 12:35:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 12:35:19 --> Helper loaded: form_helper
DEBUG - 2016-09-20 12:35:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 12:35:19 --> Helper loaded: security_helper
DEBUG - 2016-09-20 12:35:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 12:35:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 12:35:19 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 12:35:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 12:35:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 12:35:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 12:35:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 12:35:19 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 12:35:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 12:35:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 12:35:19 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 12:35:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 12:35:19 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 12:35:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 12:35:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 12:35:19 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 12:35:19 --> Database Driver Class Initialized
DEBUG - 2016-09-20 12:35:19 --> Session Class Initialized
DEBUG - 2016-09-20 12:35:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 12:35:19 --> Helper loaded: string_helper
DEBUG - 2016-09-20 12:35:19 --> Session routines successfully run
DEBUG - 2016-09-20 12:35:19 --> Native_session Class Initialized
DEBUG - 2016-09-20 12:35:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 12:35:19 --> Form Validation Class Initialized
DEBUG - 2016-09-20 12:35:19 --> Form Validation Class Initialized
DEBUG - 2016-09-20 12:35:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 12:35:19 --> Controller Class Initialized
DEBUG - 2016-09-20 12:35:19 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 12:35:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 12:35:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 12:35:19 --> Carabiner: library configured.
DEBUG - 2016-09-20 12:35:19 --> Carabiner: library configured.
DEBUG - 2016-09-20 12:35:19 --> User Agent Class Initialized
DEBUG - 2016-09-20 12:35:19 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:19 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:19 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:19 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:19 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:19 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:19 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:19 --> Model Class Initialized
ERROR - 2016-09-20 12:35:19 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 12:35:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-20 12:35:19 --> Form Validation Class Initialized
DEBUG - 2016-09-20 12:35:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 12:35:19 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-20 12:35:25 --> Config Class Initialized
DEBUG - 2016-09-20 12:35:25 --> Hooks Class Initialized
DEBUG - 2016-09-20 12:35:25 --> Utf8 Class Initialized
DEBUG - 2016-09-20 12:35:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 12:35:25 --> URI Class Initialized
DEBUG - 2016-09-20 12:35:25 --> Router Class Initialized
DEBUG - 2016-09-20 12:35:25 --> Output Class Initialized
DEBUG - 2016-09-20 12:35:25 --> Security Class Initialized
DEBUG - 2016-09-20 12:35:25 --> Input Class Initialized
DEBUG - 2016-09-20 12:35:25 --> XSS Filtering completed
DEBUG - 2016-09-20 12:35:25 --> XSS Filtering completed
DEBUG - 2016-09-20 12:35:25 --> XSS Filtering completed
DEBUG - 2016-09-20 12:35:25 --> XSS Filtering completed
DEBUG - 2016-09-20 12:35:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 12:35:25 --> Language Class Initialized
DEBUG - 2016-09-20 12:35:25 --> Loader Class Initialized
DEBUG - 2016-09-20 12:35:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 12:35:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 12:35:25 --> Helper loaded: url_helper
DEBUG - 2016-09-20 12:35:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 12:35:25 --> Helper loaded: file_helper
DEBUG - 2016-09-20 12:35:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 12:35:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 12:35:25 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 12:35:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 12:35:25 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 12:35:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 12:35:25 --> Helper loaded: common_helper
DEBUG - 2016-09-20 12:35:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 12:35:25 --> Helper loaded: common_helper
DEBUG - 2016-09-20 12:35:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 12:35:25 --> Helper loaded: form_helper
DEBUG - 2016-09-20 12:35:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 12:35:25 --> Helper loaded: security_helper
DEBUG - 2016-09-20 12:35:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 12:35:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 12:35:26 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 12:35:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 12:35:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 12:35:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 12:35:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 12:35:26 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 12:35:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 12:35:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 12:35:26 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 12:35:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 12:35:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 12:35:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 12:35:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 12:35:26 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 12:35:26 --> Database Driver Class Initialized
DEBUG - 2016-09-20 12:35:26 --> Session Class Initialized
DEBUG - 2016-09-20 12:35:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 12:35:26 --> Helper loaded: string_helper
DEBUG - 2016-09-20 12:35:26 --> Session routines successfully run
DEBUG - 2016-09-20 12:35:26 --> Native_session Class Initialized
DEBUG - 2016-09-20 12:35:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 12:35:26 --> Form Validation Class Initialized
DEBUG - 2016-09-20 12:35:26 --> Form Validation Class Initialized
DEBUG - 2016-09-20 12:35:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 12:35:26 --> Controller Class Initialized
DEBUG - 2016-09-20 12:35:26 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 12:35:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 12:35:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 12:35:26 --> Carabiner: library configured.
DEBUG - 2016-09-20 12:35:26 --> Carabiner: library configured.
DEBUG - 2016-09-20 12:35:26 --> User Agent Class Initialized
DEBUG - 2016-09-20 12:35:26 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:26 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:26 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:26 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:26 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:26 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:26 --> Model Class Initialized
DEBUG - 2016-09-20 12:35:26 --> Model Class Initialized
ERROR - 2016-09-20 12:35:26 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 12:35:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-20 12:35:26 --> Form Validation Class Initialized
DEBUG - 2016-09-20 12:35:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 12:35:26 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-20 14:25:54 --> Config Class Initialized
DEBUG - 2016-09-20 14:25:54 --> Hooks Class Initialized
DEBUG - 2016-09-20 14:25:54 --> Utf8 Class Initialized
DEBUG - 2016-09-20 14:25:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 14:25:54 --> URI Class Initialized
DEBUG - 2016-09-20 14:25:54 --> Router Class Initialized
DEBUG - 2016-09-20 14:25:54 --> Output Class Initialized
DEBUG - 2016-09-20 14:25:54 --> Security Class Initialized
DEBUG - 2016-09-20 14:25:54 --> Input Class Initialized
DEBUG - 2016-09-20 14:25:54 --> XSS Filtering completed
DEBUG - 2016-09-20 14:25:54 --> XSS Filtering completed
DEBUG - 2016-09-20 14:25:54 --> XSS Filtering completed
DEBUG - 2016-09-20 14:25:54 --> XSS Filtering completed
DEBUG - 2016-09-20 14:25:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 14:25:54 --> Language Class Initialized
DEBUG - 2016-09-20 14:25:54 --> Loader Class Initialized
DEBUG - 2016-09-20 14:25:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 14:25:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 14:25:54 --> Helper loaded: url_helper
DEBUG - 2016-09-20 14:25:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 14:25:54 --> Helper loaded: file_helper
DEBUG - 2016-09-20 14:25:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:25:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 14:25:54 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 14:25:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:25:54 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 14:25:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 14:25:54 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:25:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 14:25:54 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:25:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 14:25:54 --> Helper loaded: form_helper
DEBUG - 2016-09-20 14:25:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 14:25:54 --> Helper loaded: security_helper
DEBUG - 2016-09-20 14:25:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:25:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 14:25:54 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 14:25:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:25:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 14:25:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 14:25:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 14:25:54 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 14:25:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:25:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 14:25:54 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 14:25:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:25:54 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 14:25:54 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 14:25:54 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 14:25:54 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 14:25:54 --> Database Driver Class Initialized
DEBUG - 2016-09-20 14:25:54 --> Session Class Initialized
DEBUG - 2016-09-20 14:25:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 14:25:54 --> Helper loaded: string_helper
DEBUG - 2016-09-20 14:25:54 --> Session routines successfully run
DEBUG - 2016-09-20 14:25:54 --> Native_session Class Initialized
DEBUG - 2016-09-20 14:25:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 14:25:54 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:25:54 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:25:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:25:54 --> Controller Class Initialized
DEBUG - 2016-09-20 14:25:54 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 14:25:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 14:25:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 14:25:54 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:25:54 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:25:54 --> User Agent Class Initialized
DEBUG - 2016-09-20 14:25:54 --> Model Class Initialized
DEBUG - 2016-09-20 14:25:54 --> Model Class Initialized
DEBUG - 2016-09-20 14:25:54 --> Model Class Initialized
DEBUG - 2016-09-20 14:25:54 --> Model Class Initialized
DEBUG - 2016-09-20 14:25:54 --> Model Class Initialized
DEBUG - 2016-09-20 14:25:54 --> Model Class Initialized
DEBUG - 2016-09-20 14:25:54 --> Model Class Initialized
DEBUG - 2016-09-20 14:25:54 --> Model Class Initialized
ERROR - 2016-09-20 14:25:54 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 14:25:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-20 14:25:54 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:25:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:25:54 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2016-09-20 14:25:54 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  relation &quot;ref_status_perkawinan&quot; does not exist
LINE 5: LEFT JOIN &quot;ref_status_perkawinan&quot; ON &quot;ref_status_perkawinan&quot;...
                  ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-09-20 14:25:54 --> DB Transaction Failure
ERROR - 2016-09-20 14:25:54 --> Query error: ERROR:  relation "ref_status_perkawinan" does not exist
LINE 5: LEFT JOIN "ref_status_perkawinan" ON "ref_status_perkawinan"...
                  ^
DEBUG - 2016-09-20 14:25:54 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-09-20 14:27:39 --> Config Class Initialized
DEBUG - 2016-09-20 14:27:39 --> Hooks Class Initialized
DEBUG - 2016-09-20 14:27:39 --> Utf8 Class Initialized
DEBUG - 2016-09-20 14:27:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 14:27:39 --> URI Class Initialized
DEBUG - 2016-09-20 14:27:39 --> Router Class Initialized
DEBUG - 2016-09-20 14:27:39 --> Output Class Initialized
DEBUG - 2016-09-20 14:27:39 --> Security Class Initialized
DEBUG - 2016-09-20 14:27:39 --> Input Class Initialized
DEBUG - 2016-09-20 14:27:39 --> XSS Filtering completed
DEBUG - 2016-09-20 14:27:39 --> XSS Filtering completed
DEBUG - 2016-09-20 14:27:39 --> XSS Filtering completed
DEBUG - 2016-09-20 14:27:39 --> XSS Filtering completed
DEBUG - 2016-09-20 14:27:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 14:27:39 --> Language Class Initialized
DEBUG - 2016-09-20 14:27:39 --> Loader Class Initialized
DEBUG - 2016-09-20 14:27:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 14:27:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 14:27:39 --> Helper loaded: url_helper
DEBUG - 2016-09-20 14:27:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 14:27:39 --> Helper loaded: file_helper
DEBUG - 2016-09-20 14:27:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:27:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 14:27:39 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 14:27:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:27:39 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 14:27:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 14:27:39 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:27:39 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 14:27:39 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:27:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 14:27:39 --> Helper loaded: form_helper
DEBUG - 2016-09-20 14:27:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 14:27:39 --> Helper loaded: security_helper
DEBUG - 2016-09-20 14:27:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:27:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 14:27:39 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 14:27:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:27:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 14:27:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 14:27:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 14:27:39 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 14:27:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:27:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 14:27:39 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 14:27:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:27:39 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 14:27:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 14:27:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 14:27:39 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 14:27:39 --> Database Driver Class Initialized
DEBUG - 2016-09-20 14:27:39 --> Session Class Initialized
DEBUG - 2016-09-20 14:27:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 14:27:39 --> Helper loaded: string_helper
DEBUG - 2016-09-20 14:27:39 --> Session routines successfully run
DEBUG - 2016-09-20 14:27:39 --> Native_session Class Initialized
DEBUG - 2016-09-20 14:27:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 14:27:39 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:27:39 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:27:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:27:39 --> Controller Class Initialized
DEBUG - 2016-09-20 14:27:39 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 14:27:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 14:27:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 14:27:39 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:27:39 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:27:39 --> User Agent Class Initialized
DEBUG - 2016-09-20 14:27:39 --> Model Class Initialized
DEBUG - 2016-09-20 14:27:39 --> Model Class Initialized
DEBUG - 2016-09-20 14:27:39 --> Model Class Initialized
DEBUG - 2016-09-20 14:27:39 --> Model Class Initialized
DEBUG - 2016-09-20 14:27:39 --> Model Class Initialized
DEBUG - 2016-09-20 14:27:39 --> Model Class Initialized
DEBUG - 2016-09-20 14:27:39 --> Model Class Initialized
DEBUG - 2016-09-20 14:27:39 --> Model Class Initialized
ERROR - 2016-09-20 14:27:39 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 14:27:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-20 14:27:39 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:27:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:27:39 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-20 14:27:48 --> Config Class Initialized
DEBUG - 2016-09-20 14:27:48 --> Hooks Class Initialized
DEBUG - 2016-09-20 14:27:48 --> Utf8 Class Initialized
DEBUG - 2016-09-20 14:27:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 14:27:48 --> URI Class Initialized
DEBUG - 2016-09-20 14:27:48 --> Router Class Initialized
DEBUG - 2016-09-20 14:27:48 --> Output Class Initialized
DEBUG - 2016-09-20 14:27:48 --> Security Class Initialized
DEBUG - 2016-09-20 14:27:48 --> Input Class Initialized
DEBUG - 2016-09-20 14:27:48 --> XSS Filtering completed
DEBUG - 2016-09-20 14:27:48 --> XSS Filtering completed
DEBUG - 2016-09-20 14:27:48 --> XSS Filtering completed
DEBUG - 2016-09-20 14:27:48 --> XSS Filtering completed
DEBUG - 2016-09-20 14:27:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 14:27:48 --> Language Class Initialized
DEBUG - 2016-09-20 14:27:48 --> Loader Class Initialized
DEBUG - 2016-09-20 14:27:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 14:27:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 14:27:48 --> Helper loaded: url_helper
DEBUG - 2016-09-20 14:27:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 14:27:48 --> Helper loaded: file_helper
DEBUG - 2016-09-20 14:27:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:27:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 14:27:48 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 14:27:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:27:48 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 14:27:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 14:27:48 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:27:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 14:27:48 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:27:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 14:27:48 --> Helper loaded: form_helper
DEBUG - 2016-09-20 14:27:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 14:27:48 --> Helper loaded: security_helper
DEBUG - 2016-09-20 14:27:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:27:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 14:27:48 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 14:27:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:27:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 14:27:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 14:27:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 14:27:48 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 14:27:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:27:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 14:27:48 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 14:27:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:27:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 14:27:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 14:27:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 14:27:48 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 14:27:48 --> Database Driver Class Initialized
DEBUG - 2016-09-20 14:27:48 --> Session Class Initialized
DEBUG - 2016-09-20 14:27:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 14:27:48 --> Helper loaded: string_helper
DEBUG - 2016-09-20 14:27:48 --> Session routines successfully run
DEBUG - 2016-09-20 14:27:48 --> Native_session Class Initialized
DEBUG - 2016-09-20 14:27:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 14:27:48 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:27:48 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:27:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:27:48 --> Controller Class Initialized
DEBUG - 2016-09-20 14:27:48 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 14:27:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 14:27:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 14:27:48 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:27:48 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:27:48 --> User Agent Class Initialized
DEBUG - 2016-09-20 14:27:48 --> Model Class Initialized
DEBUG - 2016-09-20 14:27:48 --> Model Class Initialized
DEBUG - 2016-09-20 14:27:48 --> Model Class Initialized
DEBUG - 2016-09-20 14:27:48 --> Model Class Initialized
DEBUG - 2016-09-20 14:27:48 --> Model Class Initialized
DEBUG - 2016-09-20 14:27:48 --> Model Class Initialized
DEBUG - 2016-09-20 14:27:48 --> Model Class Initialized
DEBUG - 2016-09-20 14:27:48 --> Model Class Initialized
ERROR - 2016-09-20 14:27:48 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 14:27:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-20 14:27:48 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:27:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:27:48 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-20 14:28:24 --> Config Class Initialized
DEBUG - 2016-09-20 14:28:24 --> Hooks Class Initialized
DEBUG - 2016-09-20 14:28:24 --> Utf8 Class Initialized
DEBUG - 2016-09-20 14:28:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 14:28:24 --> URI Class Initialized
DEBUG - 2016-09-20 14:28:24 --> Router Class Initialized
DEBUG - 2016-09-20 14:28:24 --> Output Class Initialized
DEBUG - 2016-09-20 14:28:24 --> Security Class Initialized
DEBUG - 2016-09-20 14:28:24 --> Input Class Initialized
DEBUG - 2016-09-20 14:28:24 --> XSS Filtering completed
DEBUG - 2016-09-20 14:28:24 --> XSS Filtering completed
DEBUG - 2016-09-20 14:28:24 --> XSS Filtering completed
DEBUG - 2016-09-20 14:28:24 --> XSS Filtering completed
DEBUG - 2016-09-20 14:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 14:28:24 --> Language Class Initialized
DEBUG - 2016-09-20 14:28:24 --> Loader Class Initialized
DEBUG - 2016-09-20 14:28:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 14:28:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 14:28:24 --> Helper loaded: url_helper
DEBUG - 2016-09-20 14:28:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 14:28:24 --> Helper loaded: file_helper
DEBUG - 2016-09-20 14:28:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:28:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 14:28:24 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 14:28:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:28:24 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 14:28:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 14:28:24 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:28:24 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 14:28:24 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:28:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 14:28:24 --> Helper loaded: form_helper
DEBUG - 2016-09-20 14:28:24 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 14:28:24 --> Helper loaded: security_helper
DEBUG - 2016-09-20 14:28:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:28:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 14:28:24 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 14:28:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:28:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 14:28:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 14:28:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 14:28:24 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 14:28:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:28:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 14:28:24 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 14:28:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:28:24 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 14:28:24 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 14:28:24 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 14:28:24 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 14:28:24 --> Database Driver Class Initialized
DEBUG - 2016-09-20 14:28:24 --> Session Class Initialized
DEBUG - 2016-09-20 14:28:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 14:28:24 --> Helper loaded: string_helper
DEBUG - 2016-09-20 14:28:24 --> Session routines successfully run
DEBUG - 2016-09-20 14:28:24 --> Native_session Class Initialized
DEBUG - 2016-09-20 14:28:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 14:28:24 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:28:24 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:28:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:28:24 --> Controller Class Initialized
DEBUG - 2016-09-20 14:28:24 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 14:28:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 14:28:24 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 14:28:24 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:28:24 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:28:24 --> User Agent Class Initialized
DEBUG - 2016-09-20 14:28:24 --> Model Class Initialized
DEBUG - 2016-09-20 14:28:24 --> Model Class Initialized
DEBUG - 2016-09-20 14:28:24 --> Model Class Initialized
DEBUG - 2016-09-20 14:28:24 --> Model Class Initialized
DEBUG - 2016-09-20 14:28:24 --> Model Class Initialized
DEBUG - 2016-09-20 14:28:24 --> Model Class Initialized
DEBUG - 2016-09-20 14:28:24 --> Model Class Initialized
DEBUG - 2016-09-20 14:28:24 --> Model Class Initialized
ERROR - 2016-09-20 14:28:24 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 14:28:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-20 14:28:24 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:28:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:28:24 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-20 14:28:34 --> Config Class Initialized
DEBUG - 2016-09-20 14:28:34 --> Hooks Class Initialized
DEBUG - 2016-09-20 14:28:34 --> Utf8 Class Initialized
DEBUG - 2016-09-20 14:28:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 14:28:34 --> URI Class Initialized
DEBUG - 2016-09-20 14:28:34 --> Router Class Initialized
DEBUG - 2016-09-20 14:28:34 --> Output Class Initialized
DEBUG - 2016-09-20 14:28:34 --> Security Class Initialized
DEBUG - 2016-09-20 14:28:34 --> Input Class Initialized
DEBUG - 2016-09-20 14:28:34 --> XSS Filtering completed
DEBUG - 2016-09-20 14:28:34 --> XSS Filtering completed
DEBUG - 2016-09-20 14:28:34 --> XSS Filtering completed
DEBUG - 2016-09-20 14:28:34 --> XSS Filtering completed
DEBUG - 2016-09-20 14:28:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 14:28:34 --> Language Class Initialized
DEBUG - 2016-09-20 14:28:34 --> Loader Class Initialized
DEBUG - 2016-09-20 14:28:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 14:28:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 14:28:34 --> Helper loaded: url_helper
DEBUG - 2016-09-20 14:28:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 14:28:34 --> Helper loaded: file_helper
DEBUG - 2016-09-20 14:28:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:28:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 14:28:34 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 14:28:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:28:34 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 14:28:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 14:28:34 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:28:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 14:28:34 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:28:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 14:28:34 --> Helper loaded: form_helper
DEBUG - 2016-09-20 14:28:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 14:28:34 --> Helper loaded: security_helper
DEBUG - 2016-09-20 14:28:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:28:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 14:28:34 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 14:28:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:28:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 14:28:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 14:28:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 14:28:34 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 14:28:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:28:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 14:28:34 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 14:28:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:28:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 14:28:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 14:28:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 14:28:34 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 14:28:34 --> Database Driver Class Initialized
DEBUG - 2016-09-20 14:28:34 --> Session Class Initialized
DEBUG - 2016-09-20 14:28:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 14:28:34 --> Helper loaded: string_helper
DEBUG - 2016-09-20 14:28:34 --> Session routines successfully run
DEBUG - 2016-09-20 14:28:34 --> Native_session Class Initialized
DEBUG - 2016-09-20 14:28:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 14:28:34 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:28:34 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:28:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:28:34 --> Controller Class Initialized
DEBUG - 2016-09-20 14:28:34 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 14:28:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 14:28:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 14:28:34 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:28:34 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:28:34 --> User Agent Class Initialized
DEBUG - 2016-09-20 14:28:34 --> Model Class Initialized
DEBUG - 2016-09-20 14:28:34 --> Model Class Initialized
DEBUG - 2016-09-20 14:28:34 --> Model Class Initialized
DEBUG - 2016-09-20 14:28:34 --> Model Class Initialized
DEBUG - 2016-09-20 14:28:34 --> Model Class Initialized
DEBUG - 2016-09-20 14:28:34 --> Model Class Initialized
DEBUG - 2016-09-20 14:28:34 --> Model Class Initialized
DEBUG - 2016-09-20 14:28:34 --> Model Class Initialized
ERROR - 2016-09-20 14:28:34 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 14:28:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-20 14:28:34 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:28:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:28:34 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2016-09-20 14:28:34 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  relation &quot;ref_pegawai&quot; does not exist
LINE 5: LEFT JOIN &quot;ref_pegawai&quot; ON &quot;ref_pegawai&quot;.&quot;id_pegawai&quot; = &quot;sc_...
                  ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-09-20 14:28:34 --> DB Transaction Failure
ERROR - 2016-09-20 14:28:34 --> Query error: ERROR:  relation "ref_pegawai" does not exist
LINE 5: LEFT JOIN "ref_pegawai" ON "ref_pegawai"."id_pegawai" = "sc_...
                  ^
DEBUG - 2016-09-20 14:28:34 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-09-20 14:29:16 --> Config Class Initialized
DEBUG - 2016-09-20 14:29:16 --> Hooks Class Initialized
DEBUG - 2016-09-20 14:29:16 --> Utf8 Class Initialized
DEBUG - 2016-09-20 14:29:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 14:29:16 --> URI Class Initialized
DEBUG - 2016-09-20 14:29:16 --> Router Class Initialized
DEBUG - 2016-09-20 14:29:16 --> Output Class Initialized
DEBUG - 2016-09-20 14:29:16 --> Security Class Initialized
DEBUG - 2016-09-20 14:29:16 --> Input Class Initialized
DEBUG - 2016-09-20 14:29:16 --> XSS Filtering completed
DEBUG - 2016-09-20 14:29:16 --> XSS Filtering completed
DEBUG - 2016-09-20 14:29:16 --> XSS Filtering completed
DEBUG - 2016-09-20 14:29:16 --> XSS Filtering completed
DEBUG - 2016-09-20 14:29:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 14:29:16 --> Language Class Initialized
DEBUG - 2016-09-20 14:29:16 --> Loader Class Initialized
DEBUG - 2016-09-20 14:29:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 14:29:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 14:29:16 --> Helper loaded: url_helper
DEBUG - 2016-09-20 14:29:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 14:29:16 --> Helper loaded: file_helper
DEBUG - 2016-09-20 14:29:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:29:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 14:29:16 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 14:29:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:29:16 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 14:29:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 14:29:16 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:29:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 14:29:16 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:29:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 14:29:16 --> Helper loaded: form_helper
DEBUG - 2016-09-20 14:29:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 14:29:16 --> Helper loaded: security_helper
DEBUG - 2016-09-20 14:29:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:29:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 14:29:16 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 14:29:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:29:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 14:29:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 14:29:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 14:29:16 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 14:29:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:29:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 14:29:16 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 14:29:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:29:16 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 14:29:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 14:29:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 14:29:16 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 14:29:16 --> Database Driver Class Initialized
DEBUG - 2016-09-20 14:29:16 --> Session Class Initialized
DEBUG - 2016-09-20 14:29:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 14:29:16 --> Helper loaded: string_helper
DEBUG - 2016-09-20 14:29:16 --> Session routines successfully run
DEBUG - 2016-09-20 14:29:16 --> Native_session Class Initialized
DEBUG - 2016-09-20 14:29:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 14:29:16 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:29:16 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:29:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:29:16 --> Controller Class Initialized
DEBUG - 2016-09-20 14:29:16 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 14:29:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 14:29:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 14:29:16 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:29:16 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:29:16 --> User Agent Class Initialized
DEBUG - 2016-09-20 14:29:16 --> Model Class Initialized
DEBUG - 2016-09-20 14:29:16 --> Model Class Initialized
DEBUG - 2016-09-20 14:29:16 --> Model Class Initialized
DEBUG - 2016-09-20 14:29:16 --> Model Class Initialized
DEBUG - 2016-09-20 14:29:16 --> Model Class Initialized
DEBUG - 2016-09-20 14:29:16 --> Model Class Initialized
DEBUG - 2016-09-20 14:29:16 --> Model Class Initialized
DEBUG - 2016-09-20 14:29:16 --> Model Class Initialized
ERROR - 2016-09-20 14:29:16 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 14:29:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-20 14:29:16 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:29:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:29:16 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2016-09-20 14:29:16 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  relation &quot;ref_pegawai&quot; does not exist
LINE 5: LEFT JOIN &quot;ref_pegawai&quot; ON &quot;ref_pegawai&quot;.&quot;id_pegawai&quot; = &quot;tr_...
                  ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-09-20 14:29:16 --> DB Transaction Failure
ERROR - 2016-09-20 14:29:16 --> Query error: ERROR:  relation "ref_pegawai" does not exist
LINE 5: LEFT JOIN "ref_pegawai" ON "ref_pegawai"."id_pegawai" = "tr_...
                  ^
DEBUG - 2016-09-20 14:29:16 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-09-20 14:30:11 --> Config Class Initialized
DEBUG - 2016-09-20 14:30:11 --> Hooks Class Initialized
DEBUG - 2016-09-20 14:30:11 --> Utf8 Class Initialized
DEBUG - 2016-09-20 14:30:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 14:30:12 --> URI Class Initialized
DEBUG - 2016-09-20 14:30:12 --> Router Class Initialized
DEBUG - 2016-09-20 14:30:12 --> Output Class Initialized
DEBUG - 2016-09-20 14:30:12 --> Security Class Initialized
DEBUG - 2016-09-20 14:30:12 --> Input Class Initialized
DEBUG - 2016-09-20 14:30:12 --> XSS Filtering completed
DEBUG - 2016-09-20 14:30:12 --> XSS Filtering completed
DEBUG - 2016-09-20 14:30:12 --> XSS Filtering completed
DEBUG - 2016-09-20 14:30:12 --> XSS Filtering completed
DEBUG - 2016-09-20 14:30:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 14:30:12 --> Language Class Initialized
DEBUG - 2016-09-20 14:30:12 --> Loader Class Initialized
DEBUG - 2016-09-20 14:30:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 14:30:12 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 14:30:12 --> Helper loaded: url_helper
DEBUG - 2016-09-20 14:30:12 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 14:30:12 --> Helper loaded: file_helper
DEBUG - 2016-09-20 14:30:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:30:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 14:30:12 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 14:30:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:30:12 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 14:30:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 14:30:12 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:30:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 14:30:12 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:30:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 14:30:12 --> Helper loaded: form_helper
DEBUG - 2016-09-20 14:30:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 14:30:12 --> Helper loaded: security_helper
DEBUG - 2016-09-20 14:30:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:30:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 14:30:12 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 14:30:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:30:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 14:30:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 14:30:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 14:30:12 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 14:30:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:30:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 14:30:12 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 14:30:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:30:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 14:30:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 14:30:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 14:30:12 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 14:30:12 --> Database Driver Class Initialized
DEBUG - 2016-09-20 14:30:12 --> Session Class Initialized
DEBUG - 2016-09-20 14:30:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 14:30:12 --> Helper loaded: string_helper
DEBUG - 2016-09-20 14:30:12 --> Session routines successfully run
DEBUG - 2016-09-20 14:30:12 --> Native_session Class Initialized
DEBUG - 2016-09-20 14:30:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 14:30:12 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:30:12 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:30:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:30:12 --> Controller Class Initialized
DEBUG - 2016-09-20 14:30:12 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 14:30:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 14:30:12 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 14:30:12 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:30:12 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:30:12 --> User Agent Class Initialized
DEBUG - 2016-09-20 14:30:12 --> Model Class Initialized
DEBUG - 2016-09-20 14:30:12 --> Model Class Initialized
DEBUG - 2016-09-20 14:30:12 --> Model Class Initialized
DEBUG - 2016-09-20 14:30:12 --> Model Class Initialized
DEBUG - 2016-09-20 14:30:12 --> Model Class Initialized
DEBUG - 2016-09-20 14:30:12 --> Model Class Initialized
DEBUG - 2016-09-20 14:30:12 --> Model Class Initialized
DEBUG - 2016-09-20 14:30:12 --> Model Class Initialized
ERROR - 2016-09-20 14:30:12 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 14:30:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-20 14:30:12 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:30:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:30:12 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2016-09-20 14:30:12 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  relation &quot;ref_pegawai&quot; does not exist
LINE 5: LEFT JOIN &quot;ref_pegawai&quot; ON &quot;ref_pegawai&quot;.&quot;id_pegawai&quot; = &quot;tr_...
                  ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-09-20 14:30:12 --> DB Transaction Failure
ERROR - 2016-09-20 14:30:12 --> Query error: ERROR:  relation "ref_pegawai" does not exist
LINE 5: LEFT JOIN "ref_pegawai" ON "ref_pegawai"."id_pegawai" = "tr_...
                  ^
DEBUG - 2016-09-20 14:30:12 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-09-20 14:31:59 --> Config Class Initialized
DEBUG - 2016-09-20 14:31:59 --> Hooks Class Initialized
DEBUG - 2016-09-20 14:31:59 --> Utf8 Class Initialized
DEBUG - 2016-09-20 14:31:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 14:31:59 --> URI Class Initialized
DEBUG - 2016-09-20 14:31:59 --> Router Class Initialized
DEBUG - 2016-09-20 14:31:59 --> Output Class Initialized
DEBUG - 2016-09-20 14:31:59 --> Security Class Initialized
DEBUG - 2016-09-20 14:31:59 --> Input Class Initialized
DEBUG - 2016-09-20 14:31:59 --> XSS Filtering completed
DEBUG - 2016-09-20 14:31:59 --> XSS Filtering completed
DEBUG - 2016-09-20 14:31:59 --> XSS Filtering completed
DEBUG - 2016-09-20 14:31:59 --> XSS Filtering completed
DEBUG - 2016-09-20 14:31:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 14:31:59 --> Language Class Initialized
DEBUG - 2016-09-20 14:31:59 --> Loader Class Initialized
DEBUG - 2016-09-20 14:31:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 14:31:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 14:31:59 --> Helper loaded: url_helper
DEBUG - 2016-09-20 14:31:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 14:31:59 --> Helper loaded: file_helper
DEBUG - 2016-09-20 14:31:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:31:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 14:31:59 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 14:31:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:31:59 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 14:31:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 14:31:59 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:31:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 14:31:59 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:31:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 14:31:59 --> Helper loaded: form_helper
DEBUG - 2016-09-20 14:31:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 14:31:59 --> Helper loaded: security_helper
DEBUG - 2016-09-20 14:31:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:31:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 14:31:59 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 14:31:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:31:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 14:31:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 14:31:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 14:31:59 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 14:31:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:31:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 14:31:59 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 14:31:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:31:59 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 14:31:59 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 14:31:59 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 14:31:59 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 14:31:59 --> Database Driver Class Initialized
DEBUG - 2016-09-20 14:31:59 --> Session Class Initialized
DEBUG - 2016-09-20 14:31:59 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 14:31:59 --> Helper loaded: string_helper
DEBUG - 2016-09-20 14:31:59 --> Session routines successfully run
DEBUG - 2016-09-20 14:31:59 --> Native_session Class Initialized
DEBUG - 2016-09-20 14:31:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 14:31:59 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:31:59 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:31:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:31:59 --> Controller Class Initialized
DEBUG - 2016-09-20 14:31:59 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 14:31:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 14:31:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 14:31:59 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:31:59 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:31:59 --> User Agent Class Initialized
DEBUG - 2016-09-20 14:31:59 --> Model Class Initialized
DEBUG - 2016-09-20 14:31:59 --> Model Class Initialized
DEBUG - 2016-09-20 14:31:59 --> Model Class Initialized
DEBUG - 2016-09-20 14:31:59 --> Model Class Initialized
DEBUG - 2016-09-20 14:31:59 --> Model Class Initialized
DEBUG - 2016-09-20 14:31:59 --> Model Class Initialized
DEBUG - 2016-09-20 14:31:59 --> Model Class Initialized
DEBUG - 2016-09-20 14:31:59 --> Model Class Initialized
ERROR - 2016-09-20 14:31:59 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 14:31:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-20 14:31:59 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:31:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:31:59 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2016-09-20 14:31:59 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  relation &quot;ref_pegawai&quot; does not exist
LINE 5: LEFT JOIN &quot;ref_pegawai&quot; ON &quot;ref_pegawai&quot;.&quot;id_pegawai&quot; = &quot;tr_...
                  ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-09-20 14:31:59 --> DB Transaction Failure
ERROR - 2016-09-20 14:31:59 --> Query error: ERROR:  relation "ref_pegawai" does not exist
LINE 5: LEFT JOIN "ref_pegawai" ON "ref_pegawai"."id_pegawai" = "tr_...
                  ^
DEBUG - 2016-09-20 14:31:59 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-09-20 14:35:12 --> Config Class Initialized
DEBUG - 2016-09-20 14:35:12 --> Hooks Class Initialized
DEBUG - 2016-09-20 14:35:12 --> Utf8 Class Initialized
DEBUG - 2016-09-20 14:35:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 14:35:12 --> URI Class Initialized
DEBUG - 2016-09-20 14:35:12 --> Router Class Initialized
DEBUG - 2016-09-20 14:35:12 --> Output Class Initialized
DEBUG - 2016-09-20 14:35:12 --> Security Class Initialized
DEBUG - 2016-09-20 14:35:12 --> Input Class Initialized
DEBUG - 2016-09-20 14:35:12 --> XSS Filtering completed
DEBUG - 2016-09-20 14:35:12 --> XSS Filtering completed
DEBUG - 2016-09-20 14:35:12 --> XSS Filtering completed
DEBUG - 2016-09-20 14:35:12 --> XSS Filtering completed
DEBUG - 2016-09-20 14:35:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 14:35:12 --> Language Class Initialized
DEBUG - 2016-09-20 14:35:12 --> Loader Class Initialized
DEBUG - 2016-09-20 14:35:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 14:35:12 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 14:35:12 --> Helper loaded: url_helper
DEBUG - 2016-09-20 14:35:12 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 14:35:12 --> Helper loaded: file_helper
DEBUG - 2016-09-20 14:35:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:35:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 14:35:12 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 14:35:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:35:12 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 14:35:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 14:35:12 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:35:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 14:35:12 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:35:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 14:35:12 --> Helper loaded: form_helper
DEBUG - 2016-09-20 14:35:13 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 14:35:13 --> Helper loaded: security_helper
DEBUG - 2016-09-20 14:35:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:35:13 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 14:35:13 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 14:35:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:35:13 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 14:35:13 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 14:35:13 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 14:35:13 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 14:35:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:35:13 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 14:35:13 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 14:35:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:35:13 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 14:35:13 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 14:35:13 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 14:35:13 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 14:35:13 --> Database Driver Class Initialized
DEBUG - 2016-09-20 14:35:13 --> Session Class Initialized
DEBUG - 2016-09-20 14:35:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 14:35:13 --> Helper loaded: string_helper
DEBUG - 2016-09-20 14:35:13 --> Session routines successfully run
DEBUG - 2016-09-20 14:35:13 --> Native_session Class Initialized
DEBUG - 2016-09-20 14:35:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 14:35:13 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:35:13 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:35:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:35:13 --> Controller Class Initialized
DEBUG - 2016-09-20 14:35:13 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 14:35:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 14:35:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 14:35:13 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:35:13 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:35:13 --> User Agent Class Initialized
DEBUG - 2016-09-20 14:35:13 --> Model Class Initialized
DEBUG - 2016-09-20 14:35:13 --> Model Class Initialized
DEBUG - 2016-09-20 14:35:13 --> Model Class Initialized
DEBUG - 2016-09-20 14:35:13 --> Model Class Initialized
DEBUG - 2016-09-20 14:35:13 --> Model Class Initialized
DEBUG - 2016-09-20 14:35:13 --> Model Class Initialized
DEBUG - 2016-09-20 14:35:13 --> Model Class Initialized
DEBUG - 2016-09-20 14:35:13 --> Model Class Initialized
ERROR - 2016-09-20 14:35:13 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 14:35:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-20 14:35:13 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:35:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:35:13 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2016-09-20 14:35:13 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  relation &quot;ref_pegawai&quot; does not exist
LINE 5: LEFT JOIN &quot;ref_pegawai&quot; ON &quot;ref_pegawai&quot;.&quot;id_pegawai&quot; = &quot;tr_...
                  ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-09-20 14:35:13 --> DB Transaction Failure
ERROR - 2016-09-20 14:35:13 --> Query error: ERROR:  relation "ref_pegawai" does not exist
LINE 5: LEFT JOIN "ref_pegawai" ON "ref_pegawai"."id_pegawai" = "tr_...
                  ^
DEBUG - 2016-09-20 14:35:13 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-09-20 14:36:10 --> Config Class Initialized
DEBUG - 2016-09-20 14:36:10 --> Hooks Class Initialized
DEBUG - 2016-09-20 14:36:10 --> Utf8 Class Initialized
DEBUG - 2016-09-20 14:36:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 14:36:10 --> URI Class Initialized
DEBUG - 2016-09-20 14:36:10 --> Router Class Initialized
DEBUG - 2016-09-20 14:36:10 --> Output Class Initialized
DEBUG - 2016-09-20 14:36:10 --> Security Class Initialized
DEBUG - 2016-09-20 14:36:10 --> Input Class Initialized
DEBUG - 2016-09-20 14:36:10 --> XSS Filtering completed
DEBUG - 2016-09-20 14:36:10 --> XSS Filtering completed
DEBUG - 2016-09-20 14:36:10 --> XSS Filtering completed
DEBUG - 2016-09-20 14:36:10 --> XSS Filtering completed
DEBUG - 2016-09-20 14:36:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 14:36:10 --> Language Class Initialized
DEBUG - 2016-09-20 14:36:10 --> Loader Class Initialized
DEBUG - 2016-09-20 14:36:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 14:36:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 14:36:10 --> Helper loaded: url_helper
DEBUG - 2016-09-20 14:36:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 14:36:10 --> Helper loaded: file_helper
DEBUG - 2016-09-20 14:36:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:36:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 14:36:10 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 14:36:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:36:10 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 14:36:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 14:36:10 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:36:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 14:36:10 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:36:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 14:36:10 --> Helper loaded: form_helper
DEBUG - 2016-09-20 14:36:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 14:36:10 --> Helper loaded: security_helper
DEBUG - 2016-09-20 14:36:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:36:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 14:36:10 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 14:36:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:36:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 14:36:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 14:36:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 14:36:10 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 14:36:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:36:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 14:36:10 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 14:36:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:36:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 14:36:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 14:36:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 14:36:10 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 14:36:10 --> Database Driver Class Initialized
DEBUG - 2016-09-20 14:36:10 --> Session Class Initialized
DEBUG - 2016-09-20 14:36:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 14:36:10 --> Helper loaded: string_helper
DEBUG - 2016-09-20 14:36:10 --> Session routines successfully run
DEBUG - 2016-09-20 14:36:10 --> Native_session Class Initialized
DEBUG - 2016-09-20 14:36:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 14:36:10 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:36:10 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:36:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:36:10 --> Controller Class Initialized
DEBUG - 2016-09-20 14:36:10 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 14:36:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 14:36:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 14:36:10 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:36:10 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:36:10 --> User Agent Class Initialized
DEBUG - 2016-09-20 14:36:10 --> Model Class Initialized
DEBUG - 2016-09-20 14:36:10 --> Model Class Initialized
DEBUG - 2016-09-20 14:36:10 --> Model Class Initialized
DEBUG - 2016-09-20 14:36:10 --> Model Class Initialized
DEBUG - 2016-09-20 14:36:10 --> Model Class Initialized
DEBUG - 2016-09-20 14:36:10 --> Model Class Initialized
DEBUG - 2016-09-20 14:36:10 --> Model Class Initialized
DEBUG - 2016-09-20 14:36:10 --> Model Class Initialized
ERROR - 2016-09-20 14:36:10 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 14:36:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-20 14:36:10 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:36:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:36:10 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2016-09-20 14:36:10 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  relation &quot;ref_pegawai&quot; does not exist
LINE 5: LEFT JOIN &quot;ref_pegawai&quot; ON &quot;ref_pegawai&quot;.&quot;id_pegawai&quot; = &quot;tr_...
                  ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-09-20 14:36:10 --> DB Transaction Failure
ERROR - 2016-09-20 14:36:10 --> Query error: ERROR:  relation "ref_pegawai" does not exist
LINE 5: LEFT JOIN "ref_pegawai" ON "ref_pegawai"."id_pegawai" = "tr_...
                  ^
DEBUG - 2016-09-20 14:36:10 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-09-20 14:39:19 --> Config Class Initialized
DEBUG - 2016-09-20 14:39:19 --> Hooks Class Initialized
DEBUG - 2016-09-20 14:39:19 --> Utf8 Class Initialized
DEBUG - 2016-09-20 14:39:19 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 14:39:19 --> URI Class Initialized
DEBUG - 2016-09-20 14:39:19 --> Router Class Initialized
DEBUG - 2016-09-20 14:39:19 --> Output Class Initialized
DEBUG - 2016-09-20 14:39:19 --> Security Class Initialized
DEBUG - 2016-09-20 14:39:19 --> Input Class Initialized
DEBUG - 2016-09-20 14:39:19 --> XSS Filtering completed
DEBUG - 2016-09-20 14:39:19 --> XSS Filtering completed
DEBUG - 2016-09-20 14:39:19 --> XSS Filtering completed
DEBUG - 2016-09-20 14:39:19 --> XSS Filtering completed
DEBUG - 2016-09-20 14:39:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 14:39:19 --> Language Class Initialized
DEBUG - 2016-09-20 14:39:19 --> Loader Class Initialized
DEBUG - 2016-09-20 14:39:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 14:39:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 14:39:19 --> Helper loaded: url_helper
DEBUG - 2016-09-20 14:39:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 14:39:19 --> Helper loaded: file_helper
DEBUG - 2016-09-20 14:39:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:39:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 14:39:19 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 14:39:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:39:19 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 14:39:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 14:39:19 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:39:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 14:39:19 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:39:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 14:39:19 --> Helper loaded: form_helper
DEBUG - 2016-09-20 14:39:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 14:39:19 --> Helper loaded: security_helper
DEBUG - 2016-09-20 14:39:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:39:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 14:39:19 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 14:39:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:39:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 14:39:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 14:39:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 14:39:20 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 14:39:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:39:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 14:39:20 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 14:39:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:39:20 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 14:39:20 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 14:39:20 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 14:39:20 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 14:39:20 --> Database Driver Class Initialized
DEBUG - 2016-09-20 14:39:20 --> Session Class Initialized
DEBUG - 2016-09-20 14:39:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 14:39:20 --> Helper loaded: string_helper
DEBUG - 2016-09-20 14:39:20 --> Session routines successfully run
DEBUG - 2016-09-20 14:39:20 --> Native_session Class Initialized
DEBUG - 2016-09-20 14:39:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 14:39:20 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:39:20 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:39:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:39:20 --> Controller Class Initialized
DEBUG - 2016-09-20 14:39:20 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 14:39:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 14:39:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 14:39:20 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:39:20 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:39:20 --> User Agent Class Initialized
DEBUG - 2016-09-20 14:39:20 --> Model Class Initialized
DEBUG - 2016-09-20 14:39:20 --> Model Class Initialized
DEBUG - 2016-09-20 14:39:20 --> Model Class Initialized
DEBUG - 2016-09-20 14:39:20 --> Model Class Initialized
DEBUG - 2016-09-20 14:39:20 --> Model Class Initialized
DEBUG - 2016-09-20 14:39:20 --> Model Class Initialized
DEBUG - 2016-09-20 14:39:20 --> Model Class Initialized
DEBUG - 2016-09-20 14:39:20 --> Model Class Initialized
ERROR - 2016-09-20 14:39:20 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 14:39:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-20 14:39:20 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:39:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:39:20 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-20 14:41:21 --> Config Class Initialized
DEBUG - 2016-09-20 14:41:21 --> Hooks Class Initialized
DEBUG - 2016-09-20 14:41:21 --> Utf8 Class Initialized
DEBUG - 2016-09-20 14:41:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 14:41:21 --> URI Class Initialized
DEBUG - 2016-09-20 14:41:21 --> Router Class Initialized
DEBUG - 2016-09-20 14:41:21 --> Output Class Initialized
DEBUG - 2016-09-20 14:41:21 --> Security Class Initialized
DEBUG - 2016-09-20 14:41:21 --> Input Class Initialized
DEBUG - 2016-09-20 14:41:21 --> XSS Filtering completed
DEBUG - 2016-09-20 14:41:21 --> XSS Filtering completed
DEBUG - 2016-09-20 14:41:21 --> XSS Filtering completed
DEBUG - 2016-09-20 14:41:21 --> XSS Filtering completed
DEBUG - 2016-09-20 14:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 14:41:21 --> Language Class Initialized
DEBUG - 2016-09-20 14:41:21 --> Loader Class Initialized
DEBUG - 2016-09-20 14:41:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 14:41:21 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 14:41:21 --> Helper loaded: url_helper
DEBUG - 2016-09-20 14:41:21 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 14:41:21 --> Helper loaded: file_helper
DEBUG - 2016-09-20 14:41:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:41:21 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 14:41:21 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 14:41:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:41:21 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 14:41:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 14:41:21 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:41:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 14:41:21 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:41:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 14:41:21 --> Helper loaded: form_helper
DEBUG - 2016-09-20 14:41:21 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 14:41:21 --> Helper loaded: security_helper
DEBUG - 2016-09-20 14:41:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:41:21 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 14:41:21 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 14:41:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:41:21 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 14:41:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 14:41:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 14:41:21 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 14:41:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:41:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 14:41:21 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 14:41:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:41:21 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 14:41:21 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 14:41:21 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 14:41:21 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 14:41:21 --> Database Driver Class Initialized
DEBUG - 2016-09-20 14:41:21 --> Session Class Initialized
DEBUG - 2016-09-20 14:41:21 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 14:41:21 --> Helper loaded: string_helper
DEBUG - 2016-09-20 14:41:21 --> Session routines successfully run
DEBUG - 2016-09-20 14:41:21 --> Native_session Class Initialized
DEBUG - 2016-09-20 14:41:21 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 14:41:21 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:41:21 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:41:21 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:41:21 --> Controller Class Initialized
DEBUG - 2016-09-20 14:41:21 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 14:41:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 14:41:21 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 14:41:21 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:41:21 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:41:21 --> User Agent Class Initialized
DEBUG - 2016-09-20 14:41:21 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:21 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:21 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:22 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:22 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:22 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:22 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:22 --> Model Class Initialized
ERROR - 2016-09-20 14:41:22 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 14:41:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-20 14:41:22 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:41:22 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:41:22 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-20 14:41:22 --> Config Class Initialized
DEBUG - 2016-09-20 14:41:22 --> Hooks Class Initialized
DEBUG - 2016-09-20 14:41:22 --> Utf8 Class Initialized
DEBUG - 2016-09-20 14:41:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 14:41:22 --> URI Class Initialized
DEBUG - 2016-09-20 14:41:22 --> Router Class Initialized
DEBUG - 2016-09-20 14:41:22 --> No URI present. Default controller set.
DEBUG - 2016-09-20 14:41:22 --> Output Class Initialized
DEBUG - 2016-09-20 14:41:22 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 14:41:22 --> Security Class Initialized
DEBUG - 2016-09-20 14:41:22 --> Input Class Initialized
DEBUG - 2016-09-20 14:41:22 --> XSS Filtering completed
DEBUG - 2016-09-20 14:41:22 --> XSS Filtering completed
DEBUG - 2016-09-20 14:41:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 14:41:22 --> Language Class Initialized
DEBUG - 2016-09-20 14:41:22 --> Loader Class Initialized
DEBUG - 2016-09-20 14:41:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 14:41:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 14:41:22 --> Helper loaded: url_helper
DEBUG - 2016-09-20 14:41:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 14:41:22 --> Helper loaded: file_helper
DEBUG - 2016-09-20 14:41:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:41:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 14:41:22 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 14:41:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:41:22 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 14:41:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 14:41:22 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:41:22 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 14:41:22 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:41:22 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 14:41:22 --> Helper loaded: form_helper
DEBUG - 2016-09-20 14:41:22 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 14:41:22 --> Helper loaded: security_helper
DEBUG - 2016-09-20 14:41:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:41:22 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 14:41:22 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 14:41:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:41:22 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 14:41:22 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 14:41:22 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 14:41:22 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 14:41:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:41:22 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 14:41:22 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 14:41:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:41:22 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 14:41:22 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 14:41:22 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 14:41:22 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 14:41:22 --> Database Driver Class Initialized
DEBUG - 2016-09-20 14:41:22 --> Session Class Initialized
DEBUG - 2016-09-20 14:41:22 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 14:41:22 --> Helper loaded: string_helper
DEBUG - 2016-09-20 14:41:22 --> Session routines successfully run
DEBUG - 2016-09-20 14:41:22 --> Native_session Class Initialized
DEBUG - 2016-09-20 14:41:22 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 14:41:22 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:41:22 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:41:22 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:41:22 --> Controller Class Initialized
DEBUG - 2016-09-20 14:41:22 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 14:41:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 14:41:22 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 14:41:22 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:41:22 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:41:22 --> User Agent Class Initialized
DEBUG - 2016-09-20 14:41:22 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:22 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:22 --> Model Class Initialized
ERROR - 2016-09-20 14:41:22 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 14:41:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-20 14:41:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-20 14:41:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 14:41:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 14:41:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 14:41:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 14:41:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 14:41:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-20 14:41:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-20 14:41:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 14:41:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 14:41:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 14:41:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 14:41:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 14:41:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 14:41:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 14:41:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-20 14:41:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-20 14:41:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 14:41:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 14:41:22 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-20 14:41:22 --> Final output sent to browser
DEBUG - 2016-09-20 14:41:22 --> Total execution time: 0.4892
DEBUG - 2016-09-20 14:41:25 --> Config Class Initialized
DEBUG - 2016-09-20 14:41:25 --> Hooks Class Initialized
DEBUG - 2016-09-20 14:41:25 --> Utf8 Class Initialized
DEBUG - 2016-09-20 14:41:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 14:41:25 --> URI Class Initialized
DEBUG - 2016-09-20 14:41:25 --> Router Class Initialized
DEBUG - 2016-09-20 14:41:25 --> Output Class Initialized
DEBUG - 2016-09-20 14:41:25 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 14:41:25 --> Security Class Initialized
DEBUG - 2016-09-20 14:41:25 --> Input Class Initialized
DEBUG - 2016-09-20 14:41:25 --> XSS Filtering completed
DEBUG - 2016-09-20 14:41:25 --> XSS Filtering completed
DEBUG - 2016-09-20 14:41:25 --> XSS Filtering completed
DEBUG - 2016-09-20 14:41:25 --> XSS Filtering completed
DEBUG - 2016-09-20 14:41:25 --> XSS Filtering completed
DEBUG - 2016-09-20 14:41:25 --> XSS Filtering completed
DEBUG - 2016-09-20 14:41:25 --> XSS Filtering completed
DEBUG - 2016-09-20 14:41:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 14:41:25 --> Language Class Initialized
DEBUG - 2016-09-20 14:41:25 --> Loader Class Initialized
DEBUG - 2016-09-20 14:41:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 14:41:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 14:41:25 --> Helper loaded: url_helper
DEBUG - 2016-09-20 14:41:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 14:41:25 --> Helper loaded: file_helper
DEBUG - 2016-09-20 14:41:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:41:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 14:41:25 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 14:41:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:41:25 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 14:41:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 14:41:25 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:41:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 14:41:25 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:41:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 14:41:25 --> Helper loaded: form_helper
DEBUG - 2016-09-20 14:41:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 14:41:25 --> Helper loaded: security_helper
DEBUG - 2016-09-20 14:41:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:41:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 14:41:25 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 14:41:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:41:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 14:41:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 14:41:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 14:41:25 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 14:41:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:41:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 14:41:25 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 14:41:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:41:25 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 14:41:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 14:41:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 14:41:25 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 14:41:25 --> Database Driver Class Initialized
DEBUG - 2016-09-20 14:41:25 --> Session Class Initialized
DEBUG - 2016-09-20 14:41:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 14:41:25 --> Helper loaded: string_helper
DEBUG - 2016-09-20 14:41:25 --> Session routines successfully run
DEBUG - 2016-09-20 14:41:25 --> Native_session Class Initialized
DEBUG - 2016-09-20 14:41:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 14:41:25 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:41:25 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:41:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:41:25 --> Controller Class Initialized
DEBUG - 2016-09-20 14:41:25 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 14:41:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 14:41:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 14:41:25 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:41:25 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:41:25 --> User Agent Class Initialized
DEBUG - 2016-09-20 14:41:25 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:25 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:25 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:25 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:25 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:25 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:25 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:25 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-20 14:41:25 --> Final output sent to browser
DEBUG - 2016-09-20 14:41:25 --> Total execution time: 0.5776
DEBUG - 2016-09-20 14:41:27 --> Config Class Initialized
DEBUG - 2016-09-20 14:41:27 --> Hooks Class Initialized
DEBUG - 2016-09-20 14:41:27 --> Utf8 Class Initialized
DEBUG - 2016-09-20 14:41:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 14:41:27 --> URI Class Initialized
DEBUG - 2016-09-20 14:41:27 --> Router Class Initialized
DEBUG - 2016-09-20 14:41:27 --> Output Class Initialized
DEBUG - 2016-09-20 14:41:27 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 14:41:27 --> Security Class Initialized
DEBUG - 2016-09-20 14:41:27 --> Input Class Initialized
DEBUG - 2016-09-20 14:41:27 --> XSS Filtering completed
DEBUG - 2016-09-20 14:41:27 --> XSS Filtering completed
DEBUG - 2016-09-20 14:41:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 14:41:27 --> Language Class Initialized
DEBUG - 2016-09-20 14:41:27 --> Loader Class Initialized
DEBUG - 2016-09-20 14:41:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 14:41:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 14:41:27 --> Helper loaded: url_helper
DEBUG - 2016-09-20 14:41:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 14:41:27 --> Helper loaded: file_helper
DEBUG - 2016-09-20 14:41:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:41:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 14:41:27 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 14:41:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:41:27 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 14:41:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 14:41:27 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:41:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 14:41:27 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:41:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 14:41:27 --> Helper loaded: form_helper
DEBUG - 2016-09-20 14:41:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 14:41:27 --> Helper loaded: security_helper
DEBUG - 2016-09-20 14:41:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:41:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 14:41:27 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 14:41:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:41:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 14:41:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 14:41:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 14:41:28 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 14:41:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:41:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 14:41:28 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 14:41:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:41:28 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 14:41:28 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 14:41:28 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 14:41:28 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 14:41:28 --> Database Driver Class Initialized
DEBUG - 2016-09-20 14:41:28 --> Session Class Initialized
DEBUG - 2016-09-20 14:41:28 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 14:41:28 --> Helper loaded: string_helper
DEBUG - 2016-09-20 14:41:28 --> Session routines successfully run
DEBUG - 2016-09-20 14:41:28 --> Native_session Class Initialized
DEBUG - 2016-09-20 14:41:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 14:41:28 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:41:28 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:41:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:41:28 --> Controller Class Initialized
DEBUG - 2016-09-20 14:41:28 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 14:41:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 14:41:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 14:41:28 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:41:28 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:41:28 --> User Agent Class Initialized
DEBUG - 2016-09-20 14:41:28 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:28 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:28 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-20 14:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-20 14:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-20 14:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 14:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-20 14:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 14:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-20 14:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-20 14:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-20 14:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 14:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-20 14:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 14:41:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-20 14:41:28 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-09-20 14:41:28 --> Final output sent to browser
DEBUG - 2016-09-20 14:41:28 --> Total execution time: 0.5043
DEBUG - 2016-09-20 14:41:50 --> Config Class Initialized
DEBUG - 2016-09-20 14:41:50 --> Hooks Class Initialized
DEBUG - 2016-09-20 14:41:50 --> Utf8 Class Initialized
DEBUG - 2016-09-20 14:41:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 14:41:50 --> URI Class Initialized
DEBUG - 2016-09-20 14:41:50 --> Router Class Initialized
DEBUG - 2016-09-20 14:41:50 --> No URI present. Default controller set.
DEBUG - 2016-09-20 14:41:50 --> Output Class Initialized
DEBUG - 2016-09-20 14:41:50 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 14:41:50 --> Security Class Initialized
DEBUG - 2016-09-20 14:41:50 --> Input Class Initialized
DEBUG - 2016-09-20 14:41:50 --> XSS Filtering completed
DEBUG - 2016-09-20 14:41:50 --> XSS Filtering completed
DEBUG - 2016-09-20 14:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 14:41:50 --> Language Class Initialized
DEBUG - 2016-09-20 14:41:50 --> Loader Class Initialized
DEBUG - 2016-09-20 14:41:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 14:41:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 14:41:50 --> Helper loaded: url_helper
DEBUG - 2016-09-20 14:41:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 14:41:50 --> Helper loaded: file_helper
DEBUG - 2016-09-20 14:41:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:41:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 14:41:50 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 14:41:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:41:50 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 14:41:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 14:41:50 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:41:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 14:41:50 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:41:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 14:41:50 --> Helper loaded: form_helper
DEBUG - 2016-09-20 14:41:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 14:41:50 --> Helper loaded: security_helper
DEBUG - 2016-09-20 14:41:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:41:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 14:41:50 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 14:41:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:41:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 14:41:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 14:41:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 14:41:50 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 14:41:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:41:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 14:41:50 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 14:41:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:41:51 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 14:41:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 14:41:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 14:41:51 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 14:41:51 --> Database Driver Class Initialized
DEBUG - 2016-09-20 14:41:51 --> Session Class Initialized
DEBUG - 2016-09-20 14:41:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 14:41:51 --> Helper loaded: string_helper
DEBUG - 2016-09-20 14:41:51 --> Session routines successfully run
DEBUG - 2016-09-20 14:41:51 --> Native_session Class Initialized
DEBUG - 2016-09-20 14:41:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 14:41:51 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:41:51 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:41:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:41:51 --> Controller Class Initialized
DEBUG - 2016-09-20 14:41:51 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 14:41:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 14:41:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 14:41:51 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:41:51 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:41:51 --> User Agent Class Initialized
DEBUG - 2016-09-20 14:41:51 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:51 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:51 --> Model Class Initialized
ERROR - 2016-09-20 14:41:51 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 14:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-20 14:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-20 14:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 14:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 14:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 14:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 14:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 14:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-20 14:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-20 14:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 14:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 14:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 14:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 14:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 14:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 14:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 14:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-20 14:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-20 14:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 14:41:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 14:41:51 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-20 14:41:51 --> Final output sent to browser
DEBUG - 2016-09-20 14:41:51 --> Total execution time: 0.5414
DEBUG - 2016-09-20 14:41:51 --> Config Class Initialized
DEBUG - 2016-09-20 14:41:51 --> Hooks Class Initialized
DEBUG - 2016-09-20 14:41:51 --> Utf8 Class Initialized
DEBUG - 2016-09-20 14:41:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 14:41:51 --> URI Class Initialized
DEBUG - 2016-09-20 14:41:51 --> Router Class Initialized
DEBUG - 2016-09-20 14:41:51 --> Output Class Initialized
DEBUG - 2016-09-20 14:41:51 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 14:41:51 --> Security Class Initialized
DEBUG - 2016-09-20 14:41:51 --> Input Class Initialized
DEBUG - 2016-09-20 14:41:51 --> XSS Filtering completed
DEBUG - 2016-09-20 14:41:51 --> XSS Filtering completed
DEBUG - 2016-09-20 14:41:51 --> XSS Filtering completed
DEBUG - 2016-09-20 14:41:51 --> XSS Filtering completed
DEBUG - 2016-09-20 14:41:51 --> XSS Filtering completed
DEBUG - 2016-09-20 14:41:51 --> XSS Filtering completed
DEBUG - 2016-09-20 14:41:51 --> XSS Filtering completed
DEBUG - 2016-09-20 14:41:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 14:41:51 --> Language Class Initialized
DEBUG - 2016-09-20 14:41:51 --> Loader Class Initialized
DEBUG - 2016-09-20 14:41:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 14:41:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 14:41:51 --> Helper loaded: url_helper
DEBUG - 2016-09-20 14:41:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 14:41:51 --> Helper loaded: file_helper
DEBUG - 2016-09-20 14:41:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:41:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 14:41:51 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 14:41:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 14:41:51 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 14:41:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 14:41:51 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:41:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 14:41:51 --> Helper loaded: common_helper
DEBUG - 2016-09-20 14:41:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 14:41:51 --> Helper loaded: form_helper
DEBUG - 2016-09-20 14:41:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 14:41:51 --> Helper loaded: security_helper
DEBUG - 2016-09-20 14:41:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:41:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 14:41:51 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 14:41:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 14:41:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 14:41:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 14:41:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 14:41:51 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 14:41:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:41:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 14:41:51 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 14:41:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 14:41:51 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 14:41:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 14:41:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 14:41:51 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 14:41:51 --> Database Driver Class Initialized
DEBUG - 2016-09-20 14:41:52 --> Session Class Initialized
DEBUG - 2016-09-20 14:41:52 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 14:41:52 --> Helper loaded: string_helper
DEBUG - 2016-09-20 14:41:52 --> Session routines successfully run
DEBUG - 2016-09-20 14:41:52 --> Native_session Class Initialized
DEBUG - 2016-09-20 14:41:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 14:41:52 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:41:52 --> Form Validation Class Initialized
DEBUG - 2016-09-20 14:41:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 14:41:52 --> Controller Class Initialized
DEBUG - 2016-09-20 14:41:52 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 14:41:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 14:41:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 14:41:52 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:41:52 --> Carabiner: library configured.
DEBUG - 2016-09-20 14:41:52 --> User Agent Class Initialized
DEBUG - 2016-09-20 14:41:52 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:52 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:52 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:52 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:52 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:52 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:52 --> Model Class Initialized
DEBUG - 2016-09-20 14:41:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-20 14:41:52 --> Final output sent to browser
DEBUG - 2016-09-20 14:41:52 --> Total execution time: 0.6284
DEBUG - 2016-09-20 16:00:02 --> Config Class Initialized
DEBUG - 2016-09-20 16:00:02 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:00:02 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:00:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:00:02 --> URI Class Initialized
DEBUG - 2016-09-20 16:00:02 --> Router Class Initialized
DEBUG - 2016-09-20 16:00:02 --> Output Class Initialized
DEBUG - 2016-09-20 16:00:02 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:00:02 --> Security Class Initialized
DEBUG - 2016-09-20 16:00:02 --> Input Class Initialized
DEBUG - 2016-09-20 16:00:02 --> XSS Filtering completed
DEBUG - 2016-09-20 16:00:02 --> XSS Filtering completed
DEBUG - 2016-09-20 16:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:00:02 --> Language Class Initialized
DEBUG - 2016-09-20 16:00:02 --> Loader Class Initialized
DEBUG - 2016-09-20 16:00:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:00:02 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:00:02 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:00:02 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:00:02 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:00:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:00:02 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:00:02 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:00:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:00:02 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:00:02 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:00:02 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:00:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:00:02 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:00:02 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:00:02 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:00:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:00:02 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:00:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:00:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:00:02 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:00:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:00:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:00:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:00:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:00:02 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:00:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:00:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:00:02 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:00:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:00:02 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:00:02 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:00:02 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:00:02 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:00:02 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:00:02 --> Session Class Initialized
DEBUG - 2016-09-20 16:00:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:00:02 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:00:02 --> Session routines successfully run
DEBUG - 2016-09-20 16:00:02 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:00:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:00:02 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:00:02 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:00:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:00:02 --> Controller Class Initialized
DEBUG - 2016-09-20 16:00:02 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:00:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:00:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:00:02 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:00:02 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:00:02 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:00:02 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:02 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:02 --> Model Class Initialized
ERROR - 2016-09-20 16:00:02 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:00:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-20 16:00:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:00:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:00:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:00:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:00:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:00:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:00:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:00:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:00:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:00:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:00:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:00:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:00:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:00:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:00:03 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-20 16:00:03 --> Final output sent to browser
DEBUG - 2016-09-20 16:00:03 --> Total execution time: 0.5829
DEBUG - 2016-09-20 16:00:23 --> Config Class Initialized
DEBUG - 2016-09-20 16:00:23 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:00:23 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:00:23 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:00:23 --> URI Class Initialized
DEBUG - 2016-09-20 16:00:23 --> Router Class Initialized
DEBUG - 2016-09-20 16:00:23 --> Output Class Initialized
DEBUG - 2016-09-20 16:00:23 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:00:23 --> Security Class Initialized
DEBUG - 2016-09-20 16:00:23 --> Input Class Initialized
DEBUG - 2016-09-20 16:00:23 --> XSS Filtering completed
DEBUG - 2016-09-20 16:00:23 --> XSS Filtering completed
DEBUG - 2016-09-20 16:00:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:00:23 --> Language Class Initialized
DEBUG - 2016-09-20 16:00:23 --> Loader Class Initialized
DEBUG - 2016-09-20 16:00:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:00:23 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:00:23 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:00:23 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:00:23 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:00:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:00:23 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:00:23 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:00:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:00:23 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:00:23 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:00:23 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:00:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:00:23 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:00:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:00:23 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:00:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:00:23 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:00:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:00:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:00:23 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:00:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:00:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:00:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:00:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:00:23 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:00:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:00:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:00:23 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:00:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:00:23 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:00:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:00:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:00:23 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:00:23 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:00:24 --> Session Class Initialized
DEBUG - 2016-09-20 16:00:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:00:24 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:00:24 --> Session routines successfully run
DEBUG - 2016-09-20 16:00:24 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:00:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:00:24 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:00:24 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:00:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:00:24 --> Controller Class Initialized
DEBUG - 2016-09-20 16:00:24 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:00:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:00:24 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:00:24 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:00:24 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:00:24 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:00:24 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:24 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:24 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-20 16:00:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-20 16:00:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-20 16:00:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:00:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-20 16:00:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:00:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-20 16:00:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-20 16:00:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-20 16:00:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:00:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-20 16:00:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:00:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-20 16:00:24 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-09-20 16:00:24 --> Final output sent to browser
DEBUG - 2016-09-20 16:00:24 --> Total execution time: 0.5786
DEBUG - 2016-09-20 16:00:26 --> Config Class Initialized
DEBUG - 2016-09-20 16:00:26 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:00:26 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:00:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:00:26 --> URI Class Initialized
DEBUG - 2016-09-20 16:00:26 --> Router Class Initialized
DEBUG - 2016-09-20 16:00:26 --> Output Class Initialized
DEBUG - 2016-09-20 16:00:26 --> Security Class Initialized
DEBUG - 2016-09-20 16:00:26 --> Input Class Initialized
DEBUG - 2016-09-20 16:00:26 --> XSS Filtering completed
DEBUG - 2016-09-20 16:00:26 --> XSS Filtering completed
DEBUG - 2016-09-20 16:00:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:00:26 --> Language Class Initialized
DEBUG - 2016-09-20 16:00:26 --> Loader Class Initialized
DEBUG - 2016-09-20 16:00:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:00:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:00:26 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:00:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:00:26 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:00:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:00:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:00:26 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:00:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:00:27 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:00:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:00:27 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:00:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:00:27 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:00:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:00:27 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:00:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:00:27 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:00:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:00:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:00:27 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:00:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:00:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:00:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:00:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:00:27 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:00:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:00:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:00:27 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:00:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:00:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:00:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:00:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:00:27 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:00:27 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Session Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:00:27 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:00:27 --> Session routines successfully run
DEBUG - 2016-09-20 16:00:27 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:00:27 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:00:27 --> Controller Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:00:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:00:27 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:00:27 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:00:27 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:00:27 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Config Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:00:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:00:27 --> URI Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Router Class Initialized
DEBUG - 2016-09-20 16:00:27 --> No URI present. Default controller set.
DEBUG - 2016-09-20 16:00:27 --> Output Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:00:27 --> Security Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Input Class Initialized
DEBUG - 2016-09-20 16:00:27 --> XSS Filtering completed
DEBUG - 2016-09-20 16:00:27 --> XSS Filtering completed
DEBUG - 2016-09-20 16:00:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:00:27 --> Language Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Loader Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:00:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:00:27 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:00:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:00:27 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:00:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:00:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:00:27 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:00:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:00:27 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:00:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:00:27 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:00:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:00:27 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:00:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:00:27 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:00:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:00:27 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:00:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:00:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:00:27 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:00:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:00:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:00:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:00:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:00:27 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:00:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:00:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:00:27 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:00:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:00:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:00:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:00:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:00:27 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:00:27 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Session Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:00:27 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:00:27 --> Session routines successfully run
DEBUG - 2016-09-20 16:00:27 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:00:27 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:00:27 --> Controller Class Initialized
DEBUG - 2016-09-20 16:00:27 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:00:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:00:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:00:28 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:00:28 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:00:28 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:00:28 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:28 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:28 --> Model Class Initialized
ERROR - 2016-09-20 16:00:28 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:00:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-20 16:00:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-20 16:00:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:00:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:00:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:00:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:00:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:00:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-20 16:00:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-20 16:00:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:00:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:00:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:00:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:00:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:00:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:00:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:00:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-20 16:00:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-20 16:00:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:00:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:00:28 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-20 16:00:28 --> Final output sent to browser
DEBUG - 2016-09-20 16:00:28 --> Total execution time: 0.6278
DEBUG - 2016-09-20 16:00:28 --> Config Class Initialized
DEBUG - 2016-09-20 16:00:28 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:00:28 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:00:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:00:28 --> URI Class Initialized
DEBUG - 2016-09-20 16:00:28 --> Router Class Initialized
DEBUG - 2016-09-20 16:00:28 --> Output Class Initialized
DEBUG - 2016-09-20 16:00:28 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:00:28 --> Security Class Initialized
DEBUG - 2016-09-20 16:00:28 --> Input Class Initialized
DEBUG - 2016-09-20 16:00:28 --> XSS Filtering completed
DEBUG - 2016-09-20 16:00:28 --> XSS Filtering completed
DEBUG - 2016-09-20 16:00:28 --> XSS Filtering completed
DEBUG - 2016-09-20 16:00:28 --> XSS Filtering completed
DEBUG - 2016-09-20 16:00:28 --> XSS Filtering completed
DEBUG - 2016-09-20 16:00:28 --> XSS Filtering completed
DEBUG - 2016-09-20 16:00:28 --> XSS Filtering completed
DEBUG - 2016-09-20 16:00:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:00:28 --> Language Class Initialized
DEBUG - 2016-09-20 16:00:28 --> Loader Class Initialized
DEBUG - 2016-09-20 16:00:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:00:28 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:00:28 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:00:28 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:00:28 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:00:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:00:28 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:00:28 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:00:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:00:28 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:00:28 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:00:28 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:00:28 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:00:28 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:00:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:00:28 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:00:28 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:00:28 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:00:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:00:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:00:28 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:00:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:00:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:00:28 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:00:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:00:28 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:00:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:00:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:00:28 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:00:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:00:28 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:00:28 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:00:28 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:00:28 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:00:28 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:00:28 --> Session Class Initialized
DEBUG - 2016-09-20 16:00:28 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:00:28 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:00:28 --> Session routines successfully run
DEBUG - 2016-09-20 16:00:28 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:00:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:00:28 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:00:28 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:00:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:00:29 --> Controller Class Initialized
DEBUG - 2016-09-20 16:00:29 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:00:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:00:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:00:29 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:00:29 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:00:29 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:00:29 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:29 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:29 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:29 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:29 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:29 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:29 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:29 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-20 16:00:29 --> Final output sent to browser
DEBUG - 2016-09-20 16:00:29 --> Total execution time: 0.7133
DEBUG - 2016-09-20 16:00:30 --> Config Class Initialized
DEBUG - 2016-09-20 16:00:30 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:00:30 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:00:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:00:30 --> URI Class Initialized
DEBUG - 2016-09-20 16:00:30 --> Router Class Initialized
DEBUG - 2016-09-20 16:00:30 --> Output Class Initialized
DEBUG - 2016-09-20 16:00:30 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:00:30 --> Security Class Initialized
DEBUG - 2016-09-20 16:00:30 --> Input Class Initialized
DEBUG - 2016-09-20 16:00:30 --> XSS Filtering completed
DEBUG - 2016-09-20 16:00:30 --> XSS Filtering completed
DEBUG - 2016-09-20 16:00:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:00:30 --> Language Class Initialized
DEBUG - 2016-09-20 16:00:30 --> Loader Class Initialized
DEBUG - 2016-09-20 16:00:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:00:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:00:30 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:00:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:00:30 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:00:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:00:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:00:30 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:00:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:00:30 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:00:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:00:30 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:00:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:00:30 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:00:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:00:30 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:00:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:00:30 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:00:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:00:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:00:30 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:00:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:00:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:00:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:00:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:00:30 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:00:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:00:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:00:30 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:00:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:00:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:00:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:00:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:00:30 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:00:30 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:00:30 --> Session Class Initialized
DEBUG - 2016-09-20 16:00:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:00:30 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:00:30 --> Session routines successfully run
DEBUG - 2016-09-20 16:00:30 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:00:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:00:30 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:00:30 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:00:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:00:30 --> Controller Class Initialized
DEBUG - 2016-09-20 16:00:30 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:00:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:00:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:00:30 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:00:30 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:00:30 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:00:30 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:30 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:30 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-20 16:00:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-20 16:00:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-20 16:00:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:00:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-20 16:00:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:00:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-20 16:00:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-20 16:00:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-20 16:00:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:00:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-20 16:00:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:00:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-20 16:00:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-09-20 16:00:30 --> Final output sent to browser
DEBUG - 2016-09-20 16:00:30 --> Total execution time: 0.6237
DEBUG - 2016-09-20 16:00:33 --> Config Class Initialized
DEBUG - 2016-09-20 16:00:33 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:00:33 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:00:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:00:34 --> URI Class Initialized
DEBUG - 2016-09-20 16:00:34 --> Router Class Initialized
DEBUG - 2016-09-20 16:00:34 --> Output Class Initialized
DEBUG - 2016-09-20 16:00:34 --> Security Class Initialized
DEBUG - 2016-09-20 16:00:34 --> Input Class Initialized
DEBUG - 2016-09-20 16:00:34 --> XSS Filtering completed
DEBUG - 2016-09-20 16:00:34 --> XSS Filtering completed
DEBUG - 2016-09-20 16:00:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:00:34 --> Language Class Initialized
DEBUG - 2016-09-20 16:00:34 --> Loader Class Initialized
DEBUG - 2016-09-20 16:00:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:00:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:00:34 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:00:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:00:34 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:00:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:00:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:00:34 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:00:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:00:34 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:00:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:00:34 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:00:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:00:34 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:00:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:00:34 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:00:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:00:34 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:00:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:00:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:00:34 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:00:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:00:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:00:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:00:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:00:34 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:00:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:00:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:00:34 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:00:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:00:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:00:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:00:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:00:34 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:00:34 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:00:34 --> Session Class Initialized
DEBUG - 2016-09-20 16:00:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:00:34 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:00:34 --> Session routines successfully run
DEBUG - 2016-09-20 16:00:34 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:00:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:00:34 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:00:34 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:00:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:00:34 --> Controller Class Initialized
DEBUG - 2016-09-20 16:00:34 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:00:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:00:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:00:34 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:00:34 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:00:34 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:00:34 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:34 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:34 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:34 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:34 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:34 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:34 --> Model Class Initialized
DEBUG - 2016-09-20 16:00:34 --> Model Class Initialized
ERROR - 2016-09-20 16:00:34 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:00:34 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-20 16:00:34 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-09-20 16:00:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-20 16:00:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-20 16:00:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-20 16:00:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-20 16:00:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-09-20 16:00:34 --> Final output sent to browser
DEBUG - 2016-09-20 16:00:34 --> Total execution time: 0.6984
DEBUG - 2016-09-20 16:00:34 --> Config Class Initialized
DEBUG - 2016-09-20 16:00:34 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:00:34 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:00:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:00:34 --> URI Class Initialized
DEBUG - 2016-09-20 16:00:34 --> Router Class Initialized
ERROR - 2016-09-20 16:00:34 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-09-20 16:01:15 --> Config Class Initialized
DEBUG - 2016-09-20 16:01:15 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:01:15 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:01:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:01:15 --> URI Class Initialized
DEBUG - 2016-09-20 16:01:15 --> Router Class Initialized
DEBUG - 2016-09-20 16:01:15 --> Output Class Initialized
DEBUG - 2016-09-20 16:01:15 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:01:15 --> Security Class Initialized
DEBUG - 2016-09-20 16:01:15 --> Input Class Initialized
DEBUG - 2016-09-20 16:01:15 --> XSS Filtering completed
DEBUG - 2016-09-20 16:01:15 --> XSS Filtering completed
DEBUG - 2016-09-20 16:01:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:01:15 --> Language Class Initialized
DEBUG - 2016-09-20 16:01:15 --> Loader Class Initialized
DEBUG - 2016-09-20 16:01:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:01:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:01:15 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:01:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:01:15 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:01:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:01:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:01:15 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:01:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:01:15 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:01:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:01:15 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:01:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:01:15 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:01:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:01:15 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:01:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:01:15 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:01:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:01:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:01:15 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:01:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:01:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:01:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:01:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:01:15 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:01:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:01:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:01:15 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:01:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:01:15 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:01:15 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:01:15 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:01:15 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:01:15 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:01:15 --> Session Class Initialized
DEBUG - 2016-09-20 16:01:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:01:15 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:01:15 --> Session routines successfully run
DEBUG - 2016-09-20 16:01:15 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:01:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:01:15 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:01:15 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:01:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:01:15 --> Controller Class Initialized
DEBUG - 2016-09-20 16:01:15 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:01:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:01:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:01:15 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:01:15 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:01:15 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:01:15 --> Model Class Initialized
DEBUG - 2016-09-20 16:01:15 --> Model Class Initialized
DEBUG - 2016-09-20 16:01:15 --> Model Class Initialized
ERROR - 2016-09-20 16:01:15 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:01:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-20 16:01:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:01:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:01:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:01:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:01:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:01:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:01:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:01:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:01:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:01:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:01:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:01:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:01:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:01:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:01:15 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-20 16:01:15 --> Final output sent to browser
DEBUG - 2016-09-20 16:01:15 --> Total execution time: 0.6782
DEBUG - 2016-09-20 16:01:29 --> Config Class Initialized
DEBUG - 2016-09-20 16:01:29 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:01:29 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:01:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:01:29 --> URI Class Initialized
DEBUG - 2016-09-20 16:01:29 --> Router Class Initialized
DEBUG - 2016-09-20 16:01:29 --> Output Class Initialized
DEBUG - 2016-09-20 16:01:29 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:01:29 --> Security Class Initialized
DEBUG - 2016-09-20 16:01:29 --> Input Class Initialized
DEBUG - 2016-09-20 16:01:29 --> XSS Filtering completed
DEBUG - 2016-09-20 16:01:29 --> XSS Filtering completed
DEBUG - 2016-09-20 16:01:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:01:29 --> Language Class Initialized
DEBUG - 2016-09-20 16:01:29 --> Loader Class Initialized
DEBUG - 2016-09-20 16:01:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:01:29 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:01:29 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:01:29 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:01:29 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:01:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:01:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:01:29 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:01:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:01:29 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:01:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:01:29 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:01:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:01:29 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:01:29 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:01:29 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:01:29 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:01:29 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:01:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:01:29 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:01:29 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:01:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:01:29 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:01:29 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:01:29 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:01:29 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:01:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:01:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:01:29 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:01:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:01:29 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:01:29 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:01:29 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:01:29 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:01:29 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:01:29 --> Session Class Initialized
DEBUG - 2016-09-20 16:01:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:01:29 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:01:29 --> Session routines successfully run
DEBUG - 2016-09-20 16:01:29 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:01:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:01:29 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:01:29 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:01:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:01:29 --> Controller Class Initialized
DEBUG - 2016-09-20 16:01:29 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:01:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:01:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:01:29 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:01:29 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:01:29 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:01:29 --> Model Class Initialized
DEBUG - 2016-09-20 16:01:29 --> Model Class Initialized
DEBUG - 2016-09-20 16:01:29 --> Model Class Initialized
ERROR - 2016-09-20 16:01:29 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:01:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-20 16:01:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:01:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:01:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:01:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:01:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:01:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:01:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:01:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:01:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:01:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:01:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:01:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:01:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:01:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:01:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-20 16:01:30 --> Final output sent to browser
DEBUG - 2016-09-20 16:01:30 --> Total execution time: 0.7031
DEBUG - 2016-09-20 16:16:06 --> Config Class Initialized
DEBUG - 2016-09-20 16:16:06 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:16:06 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:16:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:16:06 --> URI Class Initialized
DEBUG - 2016-09-20 16:16:06 --> Router Class Initialized
DEBUG - 2016-09-20 16:16:06 --> Output Class Initialized
DEBUG - 2016-09-20 16:16:06 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:16:06 --> Security Class Initialized
DEBUG - 2016-09-20 16:16:06 --> Input Class Initialized
DEBUG - 2016-09-20 16:16:06 --> XSS Filtering completed
DEBUG - 2016-09-20 16:16:06 --> XSS Filtering completed
DEBUG - 2016-09-20 16:16:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:16:06 --> Language Class Initialized
DEBUG - 2016-09-20 16:16:06 --> Loader Class Initialized
DEBUG - 2016-09-20 16:16:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:16:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:16:06 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:16:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:16:06 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:16:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:16:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:16:06 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:16:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:16:06 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:16:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:16:06 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:16:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:16:06 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:16:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:16:06 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:16:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:16:06 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:16:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:16:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:16:06 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:16:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:16:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:16:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:16:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:16:06 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:16:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:16:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:16:06 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:16:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:16:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:16:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:16:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:16:06 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:16:06 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:16:06 --> Session Class Initialized
DEBUG - 2016-09-20 16:16:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:16:06 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:16:06 --> Session routines successfully run
DEBUG - 2016-09-20 16:16:06 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:16:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:16:06 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:16:06 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:16:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:16:06 --> Controller Class Initialized
DEBUG - 2016-09-20 16:16:06 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:16:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:16:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:16:07 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:16:07 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:16:07 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:16:07 --> Model Class Initialized
DEBUG - 2016-09-20 16:16:07 --> Model Class Initialized
DEBUG - 2016-09-20 16:16:07 --> Model Class Initialized
ERROR - 2016-09-20 16:16:07 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-20 16:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:16:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:16:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-20 16:16:07 --> Final output sent to browser
DEBUG - 2016-09-20 16:16:07 --> Total execution time: 0.7178
DEBUG - 2016-09-20 16:16:29 --> Config Class Initialized
DEBUG - 2016-09-20 16:16:29 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:16:29 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:16:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:16:29 --> URI Class Initialized
DEBUG - 2016-09-20 16:16:29 --> Router Class Initialized
DEBUG - 2016-09-20 16:16:29 --> Output Class Initialized
DEBUG - 2016-09-20 16:16:30 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:16:30 --> Security Class Initialized
DEBUG - 2016-09-20 16:16:30 --> Input Class Initialized
DEBUG - 2016-09-20 16:16:30 --> XSS Filtering completed
DEBUG - 2016-09-20 16:16:30 --> XSS Filtering completed
DEBUG - 2016-09-20 16:16:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:16:30 --> Language Class Initialized
DEBUG - 2016-09-20 16:16:30 --> Loader Class Initialized
DEBUG - 2016-09-20 16:16:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:16:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:16:30 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:16:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:16:30 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:16:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:16:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:16:30 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:16:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:16:30 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:16:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:16:30 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:16:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:16:30 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:16:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:16:30 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:16:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:16:30 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:16:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:16:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:16:30 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:16:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:16:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:16:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:16:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:16:30 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:16:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:16:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:16:30 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:16:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:16:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:16:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:16:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:16:30 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:16:30 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:16:30 --> Session Class Initialized
DEBUG - 2016-09-20 16:16:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:16:30 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:16:30 --> Session routines successfully run
DEBUG - 2016-09-20 16:16:30 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:16:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:16:30 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:16:30 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:16:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:16:30 --> Controller Class Initialized
DEBUG - 2016-09-20 16:16:30 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:16:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:16:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:16:30 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:16:30 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:16:30 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:16:30 --> Model Class Initialized
DEBUG - 2016-09-20 16:16:30 --> Model Class Initialized
DEBUG - 2016-09-20 16:16:30 --> Model Class Initialized
ERROR - 2016-09-20 16:16:30 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:16:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-20 16:16:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:16:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:16:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:16:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:16:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:16:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:16:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:16:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:16:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:16:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:16:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:16:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:16:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:16:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:16:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-20 16:16:30 --> Final output sent to browser
DEBUG - 2016-09-20 16:16:30 --> Total execution time: 0.7340
DEBUG - 2016-09-20 16:16:49 --> Config Class Initialized
DEBUG - 2016-09-20 16:16:49 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:16:49 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:16:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:16:49 --> URI Class Initialized
DEBUG - 2016-09-20 16:16:49 --> Router Class Initialized
DEBUG - 2016-09-20 16:16:49 --> Output Class Initialized
DEBUG - 2016-09-20 16:16:49 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:16:49 --> Security Class Initialized
DEBUG - 2016-09-20 16:16:49 --> Input Class Initialized
DEBUG - 2016-09-20 16:16:49 --> XSS Filtering completed
DEBUG - 2016-09-20 16:16:49 --> XSS Filtering completed
DEBUG - 2016-09-20 16:16:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:16:49 --> Language Class Initialized
DEBUG - 2016-09-20 16:16:49 --> Loader Class Initialized
DEBUG - 2016-09-20 16:16:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:16:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:16:49 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:16:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:16:49 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:16:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:16:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:16:49 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:16:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:16:49 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:16:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:16:49 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:16:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:16:49 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:16:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:16:49 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:16:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:16:49 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:16:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:16:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:16:49 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:16:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:16:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:16:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:16:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:16:49 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:16:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:16:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:16:49 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:16:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:16:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:16:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:16:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:16:49 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:16:49 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:16:49 --> Session Class Initialized
DEBUG - 2016-09-20 16:16:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:16:49 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:16:49 --> Session routines successfully run
DEBUG - 2016-09-20 16:16:49 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:16:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:16:49 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:16:49 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:16:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:16:49 --> Controller Class Initialized
DEBUG - 2016-09-20 16:16:49 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:16:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:16:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:16:50 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:16:50 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:16:50 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:16:50 --> Model Class Initialized
DEBUG - 2016-09-20 16:16:50 --> Model Class Initialized
DEBUG - 2016-09-20 16:16:50 --> Model Class Initialized
ERROR - 2016-09-20 16:16:50 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:16:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-20 16:16:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:16:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:16:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:16:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:16:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:16:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:16:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:16:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:16:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:16:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:16:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:16:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:16:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:16:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:16:50 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-20 16:16:50 --> Final output sent to browser
DEBUG - 2016-09-20 16:16:50 --> Total execution time: 0.7774
DEBUG - 2016-09-20 16:17:36 --> Config Class Initialized
DEBUG - 2016-09-20 16:17:36 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:17:36 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:17:36 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:17:36 --> URI Class Initialized
DEBUG - 2016-09-20 16:17:37 --> Router Class Initialized
DEBUG - 2016-09-20 16:17:37 --> Output Class Initialized
DEBUG - 2016-09-20 16:17:37 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:17:37 --> Security Class Initialized
DEBUG - 2016-09-20 16:17:37 --> Input Class Initialized
DEBUG - 2016-09-20 16:17:37 --> XSS Filtering completed
DEBUG - 2016-09-20 16:17:37 --> XSS Filtering completed
DEBUG - 2016-09-20 16:17:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:17:37 --> Language Class Initialized
DEBUG - 2016-09-20 16:17:37 --> Loader Class Initialized
DEBUG - 2016-09-20 16:17:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:17:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:17:37 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:17:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:17:37 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:17:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:17:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:17:37 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:17:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:17:37 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:17:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:17:37 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:17:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:17:37 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:17:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:17:37 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:17:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:17:37 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:17:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:17:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:17:37 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:17:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:17:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:17:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:17:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:17:37 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:17:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:17:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:17:37 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:17:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:17:37 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:17:37 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:17:37 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:17:37 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:17:37 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:17:37 --> Session Class Initialized
DEBUG - 2016-09-20 16:17:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:17:37 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:17:37 --> Session routines successfully run
DEBUG - 2016-09-20 16:17:37 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:17:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:17:37 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:17:37 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:17:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:17:37 --> Controller Class Initialized
DEBUG - 2016-09-20 16:17:37 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:17:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:17:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:17:37 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:17:37 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:17:37 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:17:37 --> Model Class Initialized
DEBUG - 2016-09-20 16:17:37 --> Model Class Initialized
DEBUG - 2016-09-20 16:17:37 --> Model Class Initialized
ERROR - 2016-09-20 16:17:37 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:18:03 --> Config Class Initialized
DEBUG - 2016-09-20 16:18:03 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:18:03 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:18:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:18:03 --> URI Class Initialized
DEBUG - 2016-09-20 16:18:03 --> Router Class Initialized
DEBUG - 2016-09-20 16:18:03 --> Output Class Initialized
DEBUG - 2016-09-20 16:18:03 --> Security Class Initialized
DEBUG - 2016-09-20 16:18:03 --> Input Class Initialized
DEBUG - 2016-09-20 16:18:03 --> XSS Filtering completed
DEBUG - 2016-09-20 16:18:03 --> XSS Filtering completed
DEBUG - 2016-09-20 16:18:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:18:03 --> Language Class Initialized
DEBUG - 2016-09-20 16:18:03 --> Loader Class Initialized
DEBUG - 2016-09-20 16:18:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:18:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:18:03 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:18:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:18:03 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:18:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:18:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:18:03 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:18:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:18:03 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:18:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:18:03 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:18:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:18:03 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:18:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:18:03 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:18:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:18:03 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:18:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:18:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:18:03 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:18:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:18:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:18:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:18:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:18:03 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:18:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:18:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:18:03 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:18:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:18:03 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:18:03 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:18:03 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:18:03 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:18:03 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:18:03 --> Session Class Initialized
DEBUG - 2016-09-20 16:18:03 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:18:03 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:18:03 --> Session routines successfully run
DEBUG - 2016-09-20 16:18:03 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:18:03 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:18:03 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:18:03 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:18:03 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:18:03 --> Controller Class Initialized
DEBUG - 2016-09-20 16:18:03 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:18:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:18:03 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:18:03 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:18:03 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:18:03 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:18:03 --> Model Class Initialized
DEBUG - 2016-09-20 16:18:03 --> Model Class Initialized
DEBUG - 2016-09-20 16:18:03 --> Model Class Initialized
ERROR - 2016-09-20 16:18:03 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:18:35 --> Config Class Initialized
DEBUG - 2016-09-20 16:18:35 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:18:35 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:18:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:18:35 --> URI Class Initialized
DEBUG - 2016-09-20 16:18:35 --> Router Class Initialized
DEBUG - 2016-09-20 16:18:35 --> Output Class Initialized
DEBUG - 2016-09-20 16:18:35 --> Security Class Initialized
DEBUG - 2016-09-20 16:18:35 --> Input Class Initialized
DEBUG - 2016-09-20 16:18:35 --> XSS Filtering completed
DEBUG - 2016-09-20 16:18:35 --> XSS Filtering completed
DEBUG - 2016-09-20 16:18:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:18:35 --> Language Class Initialized
DEBUG - 2016-09-20 16:18:35 --> Loader Class Initialized
DEBUG - 2016-09-20 16:18:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:18:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:18:35 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:18:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:18:35 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:18:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:18:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:18:35 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:18:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:18:35 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:18:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:18:35 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:18:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:18:35 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:18:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:18:35 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:18:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:18:35 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:18:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:18:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:18:35 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:18:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:18:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:18:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:18:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:18:35 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:18:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:18:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:18:35 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:18:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:18:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:18:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:18:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:18:35 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:18:35 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:18:35 --> Session Class Initialized
DEBUG - 2016-09-20 16:18:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:18:35 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:18:35 --> Session routines successfully run
DEBUG - 2016-09-20 16:18:35 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:18:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:18:35 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:18:35 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:18:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:18:35 --> Controller Class Initialized
DEBUG - 2016-09-20 16:18:35 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:18:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:18:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:18:35 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:18:35 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:18:35 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:18:35 --> Model Class Initialized
DEBUG - 2016-09-20 16:18:35 --> Model Class Initialized
DEBUG - 2016-09-20 16:18:35 --> Model Class Initialized
ERROR - 2016-09-20 16:18:35 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:19:14 --> Config Class Initialized
DEBUG - 2016-09-20 16:19:14 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:19:14 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:19:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:19:14 --> URI Class Initialized
DEBUG - 2016-09-20 16:19:14 --> Router Class Initialized
DEBUG - 2016-09-20 16:19:14 --> Output Class Initialized
DEBUG - 2016-09-20 16:19:14 --> Security Class Initialized
DEBUG - 2016-09-20 16:19:14 --> Input Class Initialized
DEBUG - 2016-09-20 16:19:14 --> XSS Filtering completed
DEBUG - 2016-09-20 16:19:14 --> XSS Filtering completed
DEBUG - 2016-09-20 16:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:19:14 --> Language Class Initialized
DEBUG - 2016-09-20 16:19:15 --> Loader Class Initialized
DEBUG - 2016-09-20 16:19:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:19:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:19:15 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:19:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:19:15 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:19:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:19:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:19:15 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:19:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:19:15 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:19:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:19:15 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:19:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:19:15 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:19:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:19:15 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:19:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:19:15 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:19:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:19:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:19:15 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:19:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:19:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:19:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:19:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:19:15 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:19:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:19:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:19:15 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:19:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:19:15 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:19:15 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:19:15 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:19:15 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:19:15 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:19:15 --> Session Class Initialized
DEBUG - 2016-09-20 16:19:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:19:15 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:19:15 --> Session routines successfully run
DEBUG - 2016-09-20 16:19:15 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:19:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:19:15 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:19:15 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:19:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:19:15 --> Controller Class Initialized
DEBUG - 2016-09-20 16:19:15 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:19:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:19:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:19:15 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:19:15 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:19:15 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:19:15 --> Model Class Initialized
DEBUG - 2016-09-20 16:19:15 --> Model Class Initialized
DEBUG - 2016-09-20 16:19:15 --> Model Class Initialized
ERROR - 2016-09-20 16:19:15 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-20 16:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:19:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:19:15 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-20 16:19:15 --> Final output sent to browser
DEBUG - 2016-09-20 16:19:15 --> Total execution time: 0.7928
DEBUG - 2016-09-20 16:19:29 --> Config Class Initialized
DEBUG - 2016-09-20 16:19:29 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:19:29 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:19:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:19:29 --> URI Class Initialized
DEBUG - 2016-09-20 16:19:29 --> Router Class Initialized
DEBUG - 2016-09-20 16:19:29 --> Output Class Initialized
DEBUG - 2016-09-20 16:19:29 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:19:29 --> Security Class Initialized
DEBUG - 2016-09-20 16:19:29 --> Input Class Initialized
DEBUG - 2016-09-20 16:19:29 --> XSS Filtering completed
DEBUG - 2016-09-20 16:19:29 --> XSS Filtering completed
DEBUG - 2016-09-20 16:19:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:19:29 --> Language Class Initialized
DEBUG - 2016-09-20 16:19:29 --> Loader Class Initialized
DEBUG - 2016-09-20 16:19:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:19:29 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:19:29 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:19:29 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:19:29 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:19:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:19:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:19:29 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:19:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:19:29 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:19:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:19:29 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:19:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:19:29 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:19:29 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:19:30 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:19:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:19:30 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:19:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:19:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:19:30 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:19:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:19:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:19:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:19:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:19:30 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:19:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:19:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:19:30 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:19:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:19:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:19:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:19:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:19:30 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:19:30 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:19:30 --> Session Class Initialized
DEBUG - 2016-09-20 16:19:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:19:30 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:19:30 --> Session routines successfully run
DEBUG - 2016-09-20 16:19:30 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:19:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:19:30 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:19:30 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:19:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:19:30 --> Controller Class Initialized
DEBUG - 2016-09-20 16:19:30 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:19:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:19:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:19:30 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:19:30 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:19:30 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:19:30 --> Model Class Initialized
DEBUG - 2016-09-20 16:19:30 --> Model Class Initialized
DEBUG - 2016-09-20 16:19:30 --> Model Class Initialized
ERROR - 2016-09-20 16:19:30 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-20 16:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:19:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:19:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-20 16:19:30 --> Final output sent to browser
DEBUG - 2016-09-20 16:19:30 --> Total execution time: 0.8235
DEBUG - 2016-09-20 16:19:32 --> Config Class Initialized
DEBUG - 2016-09-20 16:19:32 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:19:32 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:19:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:19:32 --> URI Class Initialized
DEBUG - 2016-09-20 16:19:32 --> Router Class Initialized
DEBUG - 2016-09-20 16:19:32 --> Output Class Initialized
DEBUG - 2016-09-20 16:19:32 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:19:32 --> Security Class Initialized
DEBUG - 2016-09-20 16:19:32 --> Input Class Initialized
DEBUG - 2016-09-20 16:19:32 --> XSS Filtering completed
DEBUG - 2016-09-20 16:19:32 --> XSS Filtering completed
DEBUG - 2016-09-20 16:19:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:19:32 --> Language Class Initialized
DEBUG - 2016-09-20 16:19:32 --> Loader Class Initialized
DEBUG - 2016-09-20 16:19:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:19:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:19:32 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:19:32 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:19:32 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:19:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:19:32 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:19:32 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:19:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:19:32 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:19:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:19:32 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:19:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:19:32 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:19:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:19:32 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:19:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:19:32 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:19:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:19:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:19:32 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:19:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:19:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:19:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:19:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:19:32 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:19:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:19:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:19:32 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:19:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:19:32 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:19:32 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:19:32 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:19:32 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:19:32 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:19:33 --> Session Class Initialized
DEBUG - 2016-09-20 16:19:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:19:33 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:19:33 --> Session routines successfully run
DEBUG - 2016-09-20 16:19:33 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:19:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:19:33 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:19:33 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:19:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:19:33 --> Controller Class Initialized
DEBUG - 2016-09-20 16:19:33 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:19:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:19:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:19:33 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:19:33 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:19:33 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:19:33 --> Model Class Initialized
DEBUG - 2016-09-20 16:19:33 --> Model Class Initialized
DEBUG - 2016-09-20 16:19:33 --> Model Class Initialized
ERROR - 2016-09-20 16:19:33 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:19:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-20 16:19:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:19:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:19:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:19:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:19:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:19:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:19:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:19:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:19:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:19:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:19:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:19:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:19:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:19:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:19:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-20 16:19:33 --> Final output sent to browser
DEBUG - 2016-09-20 16:19:33 --> Total execution time: 0.8321
DEBUG - 2016-09-20 16:21:09 --> Config Class Initialized
DEBUG - 2016-09-20 16:21:09 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:21:09 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:21:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:21:09 --> URI Class Initialized
DEBUG - 2016-09-20 16:21:09 --> Router Class Initialized
DEBUG - 2016-09-20 16:21:09 --> Output Class Initialized
DEBUG - 2016-09-20 16:21:09 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:21:09 --> Security Class Initialized
DEBUG - 2016-09-20 16:21:09 --> Input Class Initialized
DEBUG - 2016-09-20 16:21:09 --> XSS Filtering completed
DEBUG - 2016-09-20 16:21:09 --> XSS Filtering completed
DEBUG - 2016-09-20 16:21:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:21:09 --> Language Class Initialized
DEBUG - 2016-09-20 16:21:09 --> Loader Class Initialized
DEBUG - 2016-09-20 16:21:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:21:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:21:09 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:21:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:21:09 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:21:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:21:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:21:09 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:21:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:21:09 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:21:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:21:09 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:21:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:21:09 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:21:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:21:09 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:21:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:21:09 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:21:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:21:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:21:09 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:21:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:21:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:21:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:21:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:21:09 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:21:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:21:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:21:09 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:21:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:21:09 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:21:09 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:21:09 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:21:09 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:21:09 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:21:09 --> Session Class Initialized
DEBUG - 2016-09-20 16:21:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:21:09 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:21:09 --> Session routines successfully run
DEBUG - 2016-09-20 16:21:09 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:21:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:21:09 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:21:09 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:21:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:21:09 --> Controller Class Initialized
DEBUG - 2016-09-20 16:21:09 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:21:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:21:09 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:21:09 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:21:09 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:21:09 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:21:09 --> Model Class Initialized
DEBUG - 2016-09-20 16:21:09 --> Model Class Initialized
DEBUG - 2016-09-20 16:21:09 --> Model Class Initialized
ERROR - 2016-09-20 16:21:09 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:21:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-20 16:21:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:21:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:21:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:21:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:21:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:21:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:21:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:21:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:21:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:21:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:21:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:21:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:21:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:21:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:21:10 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-20 16:21:10 --> Final output sent to browser
DEBUG - 2016-09-20 16:21:10 --> Total execution time: 0.8521
DEBUG - 2016-09-20 16:21:13 --> Config Class Initialized
DEBUG - 2016-09-20 16:21:13 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:21:13 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:21:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:21:13 --> URI Class Initialized
DEBUG - 2016-09-20 16:21:13 --> Router Class Initialized
DEBUG - 2016-09-20 16:21:13 --> Output Class Initialized
DEBUG - 2016-09-20 16:21:13 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:21:13 --> Security Class Initialized
DEBUG - 2016-09-20 16:21:13 --> Input Class Initialized
DEBUG - 2016-09-20 16:21:13 --> XSS Filtering completed
DEBUG - 2016-09-20 16:21:13 --> XSS Filtering completed
DEBUG - 2016-09-20 16:21:13 --> XSS Filtering completed
DEBUG - 2016-09-20 16:21:13 --> XSS Filtering completed
DEBUG - 2016-09-20 16:21:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:21:13 --> Language Class Initialized
DEBUG - 2016-09-20 16:21:13 --> Loader Class Initialized
DEBUG - 2016-09-20 16:21:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:21:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:21:13 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:21:13 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:21:13 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:21:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:21:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:21:13 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:21:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:21:13 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:21:13 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:21:13 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:21:13 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:21:13 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:21:13 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:21:13 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:21:13 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:21:13 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:21:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:21:13 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:21:13 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:21:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:21:13 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:21:13 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:21:13 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:21:13 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:21:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:21:13 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:21:13 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:21:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:21:13 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:21:13 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:21:13 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:21:13 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:21:13 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:21:13 --> Session Class Initialized
DEBUG - 2016-09-20 16:21:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:21:13 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:21:13 --> Session routines successfully run
DEBUG - 2016-09-20 16:21:13 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:21:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:21:13 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:21:13 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:21:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:21:13 --> Controller Class Initialized
DEBUG - 2016-09-20 16:21:13 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:21:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:21:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:21:13 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:21:13 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:21:13 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:21:13 --> Model Class Initialized
DEBUG - 2016-09-20 16:21:13 --> Model Class Initialized
DEBUG - 2016-09-20 16:21:13 --> Model Class Initialized
ERROR - 2016-09-20 16:21:13 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:21:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-20 16:21:14 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:21:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:21:14 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-20 16:21:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-20 16:21:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:21:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:21:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:21:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:21:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:21:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:21:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:21:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:21:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:21:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:21:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:21:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:21:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:21:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:21:14 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-20 16:21:14 --> Final output sent to browser
DEBUG - 2016-09-20 16:21:14 --> Total execution time: 0.9597
DEBUG - 2016-09-20 16:24:30 --> Config Class Initialized
DEBUG - 2016-09-20 16:24:30 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:24:30 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:24:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:24:30 --> URI Class Initialized
DEBUG - 2016-09-20 16:24:30 --> Router Class Initialized
DEBUG - 2016-09-20 16:24:30 --> Output Class Initialized
DEBUG - 2016-09-20 16:24:30 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:24:30 --> Security Class Initialized
DEBUG - 2016-09-20 16:24:30 --> Input Class Initialized
DEBUG - 2016-09-20 16:24:30 --> XSS Filtering completed
DEBUG - 2016-09-20 16:24:30 --> XSS Filtering completed
DEBUG - 2016-09-20 16:24:30 --> XSS Filtering completed
DEBUG - 2016-09-20 16:24:30 --> XSS Filtering completed
DEBUG - 2016-09-20 16:24:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:24:30 --> Language Class Initialized
DEBUG - 2016-09-20 16:24:30 --> Loader Class Initialized
DEBUG - 2016-09-20 16:24:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:24:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:24:30 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:24:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:24:30 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:24:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:24:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:24:30 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:24:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:24:30 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:24:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:24:30 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:24:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:24:30 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:24:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:24:30 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:24:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:24:30 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:24:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:24:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:24:30 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:24:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:24:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:24:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:24:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:24:30 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:24:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:24:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:24:30 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:24:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:24:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:24:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:24:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:24:30 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:24:30 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:24:30 --> Session Class Initialized
DEBUG - 2016-09-20 16:24:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:24:30 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:24:30 --> Session routines successfully run
DEBUG - 2016-09-20 16:24:30 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:24:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:24:30 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:24:30 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:24:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:24:30 --> Controller Class Initialized
DEBUG - 2016-09-20 16:24:30 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:24:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:24:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:24:30 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:24:30 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:24:30 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:24:30 --> Model Class Initialized
DEBUG - 2016-09-20 16:24:30 --> Model Class Initialized
DEBUG - 2016-09-20 16:24:30 --> Model Class Initialized
ERROR - 2016-09-20 16:24:30 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:24:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-20 16:24:30 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:24:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:24:30 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-20 16:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-20 16:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:24:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:24:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-20 16:24:31 --> Final output sent to browser
DEBUG - 2016-09-20 16:24:31 --> Total execution time: 0.9931
DEBUG - 2016-09-20 16:24:54 --> Config Class Initialized
DEBUG - 2016-09-20 16:24:54 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:24:54 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:24:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:24:54 --> URI Class Initialized
DEBUG - 2016-09-20 16:24:54 --> Router Class Initialized
DEBUG - 2016-09-20 16:24:54 --> Output Class Initialized
DEBUG - 2016-09-20 16:24:54 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:24:55 --> Security Class Initialized
DEBUG - 2016-09-20 16:24:55 --> Input Class Initialized
DEBUG - 2016-09-20 16:24:55 --> XSS Filtering completed
DEBUG - 2016-09-20 16:24:55 --> XSS Filtering completed
DEBUG - 2016-09-20 16:24:55 --> XSS Filtering completed
DEBUG - 2016-09-20 16:24:55 --> XSS Filtering completed
DEBUG - 2016-09-20 16:24:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:24:55 --> Language Class Initialized
DEBUG - 2016-09-20 16:24:55 --> Loader Class Initialized
DEBUG - 2016-09-20 16:24:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:24:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:24:55 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:24:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:24:55 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:24:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:24:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:24:55 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:24:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:24:55 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:24:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:24:55 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:24:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:24:55 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:24:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:24:55 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:24:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:24:55 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:24:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:24:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:24:55 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:24:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:24:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:24:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:24:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:24:55 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:24:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:24:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:24:55 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:24:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:24:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:24:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:24:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:24:55 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:24:55 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:24:55 --> Session Class Initialized
DEBUG - 2016-09-20 16:24:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:24:55 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:24:55 --> Session routines successfully run
DEBUG - 2016-09-20 16:24:55 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:24:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:24:55 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:24:55 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:24:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:24:55 --> Controller Class Initialized
DEBUG - 2016-09-20 16:24:55 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:24:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:24:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:24:55 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:24:55 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:24:55 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:24:55 --> Model Class Initialized
DEBUG - 2016-09-20 16:24:55 --> Model Class Initialized
DEBUG - 2016-09-20 16:24:55 --> Model Class Initialized
ERROR - 2016-09-20 16:24:55 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:24:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-20 16:24:55 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:24:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:24:55 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-20 16:24:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-20 16:24:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:24:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:24:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:24:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:24:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:24:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:24:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:24:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:24:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:24:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:24:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:24:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:24:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:24:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:24:56 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-20 16:24:56 --> Final output sent to browser
DEBUG - 2016-09-20 16:24:56 --> Total execution time: 1.0029
DEBUG - 2016-09-20 16:25:25 --> Config Class Initialized
DEBUG - 2016-09-20 16:25:25 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:25:25 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:25:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:25:25 --> URI Class Initialized
DEBUG - 2016-09-20 16:25:25 --> Router Class Initialized
DEBUG - 2016-09-20 16:25:25 --> Output Class Initialized
DEBUG - 2016-09-20 16:25:25 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:25:25 --> Security Class Initialized
DEBUG - 2016-09-20 16:25:25 --> Input Class Initialized
DEBUG - 2016-09-20 16:25:25 --> XSS Filtering completed
DEBUG - 2016-09-20 16:25:25 --> XSS Filtering completed
DEBUG - 2016-09-20 16:25:25 --> XSS Filtering completed
DEBUG - 2016-09-20 16:25:25 --> XSS Filtering completed
DEBUG - 2016-09-20 16:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:25:25 --> Language Class Initialized
DEBUG - 2016-09-20 16:25:25 --> Loader Class Initialized
DEBUG - 2016-09-20 16:25:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:25:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:25:26 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:25:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:25:26 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:25:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:25:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:25:26 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:25:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:25:26 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:25:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:25:26 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:25:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:25:26 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:25:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:25:26 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:25:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:25:26 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:25:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:25:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:25:26 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:25:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:25:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:25:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:25:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:25:26 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:25:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:25:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:25:26 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:25:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:25:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:25:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:25:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:25:26 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:25:26 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:25:26 --> Session Class Initialized
DEBUG - 2016-09-20 16:25:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:25:26 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:25:26 --> Session routines successfully run
DEBUG - 2016-09-20 16:25:26 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:25:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:25:26 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:25:26 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:25:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:25:26 --> Controller Class Initialized
DEBUG - 2016-09-20 16:25:26 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:25:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:25:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:25:26 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:25:26 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:25:26 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:25:26 --> Model Class Initialized
DEBUG - 2016-09-20 16:25:26 --> Model Class Initialized
DEBUG - 2016-09-20 16:25:26 --> Model Class Initialized
ERROR - 2016-09-20 16:25:26 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:25:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-20 16:25:26 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:25:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:25:26 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-20 16:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-20 16:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:25:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:25:26 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-20 16:25:27 --> Final output sent to browser
DEBUG - 2016-09-20 16:25:27 --> Total execution time: 1.0382
DEBUG - 2016-09-20 16:30:14 --> Config Class Initialized
DEBUG - 2016-09-20 16:30:14 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:30:14 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:30:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:30:14 --> URI Class Initialized
DEBUG - 2016-09-20 16:30:14 --> Router Class Initialized
DEBUG - 2016-09-20 16:30:14 --> Output Class Initialized
DEBUG - 2016-09-20 16:30:14 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:30:14 --> Security Class Initialized
DEBUG - 2016-09-20 16:30:14 --> Input Class Initialized
DEBUG - 2016-09-20 16:30:14 --> XSS Filtering completed
DEBUG - 2016-09-20 16:30:14 --> XSS Filtering completed
DEBUG - 2016-09-20 16:30:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:30:14 --> Language Class Initialized
DEBUG - 2016-09-20 16:30:14 --> Loader Class Initialized
DEBUG - 2016-09-20 16:30:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:30:14 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:30:14 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:30:14 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:30:14 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:30:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:30:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:30:15 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:30:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:30:15 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:30:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:30:15 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:30:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:30:15 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:30:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:30:15 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:30:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:30:15 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:30:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:30:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:30:15 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:30:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:30:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:30:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:30:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:30:15 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:30:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:30:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:30:15 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:30:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:30:15 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:30:15 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:30:15 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:30:15 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:30:15 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:30:15 --> Session Class Initialized
DEBUG - 2016-09-20 16:30:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:30:15 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:30:15 --> Session routines successfully run
DEBUG - 2016-09-20 16:30:15 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:30:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:30:15 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:30:15 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:30:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:30:15 --> Controller Class Initialized
DEBUG - 2016-09-20 16:30:15 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:30:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:30:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:30:15 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:30:15 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:30:15 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:30:15 --> Model Class Initialized
DEBUG - 2016-09-20 16:30:15 --> Model Class Initialized
DEBUG - 2016-09-20 16:30:15 --> Model Class Initialized
ERROR - 2016-09-20 16:30:15 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-20 16:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:30:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:30:15 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-20 16:30:15 --> Final output sent to browser
DEBUG - 2016-09-20 16:30:15 --> Total execution time: 0.9669
DEBUG - 2016-09-20 16:30:47 --> Config Class Initialized
DEBUG - 2016-09-20 16:30:47 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:30:47 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:30:47 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:30:47 --> URI Class Initialized
DEBUG - 2016-09-20 16:30:47 --> Router Class Initialized
DEBUG - 2016-09-20 16:30:47 --> Output Class Initialized
DEBUG - 2016-09-20 16:30:47 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:30:47 --> Security Class Initialized
DEBUG - 2016-09-20 16:30:47 --> Input Class Initialized
DEBUG - 2016-09-20 16:30:47 --> XSS Filtering completed
DEBUG - 2016-09-20 16:30:47 --> XSS Filtering completed
DEBUG - 2016-09-20 16:30:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:30:47 --> Language Class Initialized
DEBUG - 2016-09-20 16:30:47 --> Loader Class Initialized
DEBUG - 2016-09-20 16:30:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:30:47 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:30:47 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:30:47 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:30:47 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:30:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:30:47 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:30:47 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:30:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:30:47 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:30:47 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:30:47 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:30:47 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:30:47 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:30:47 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:30:47 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:30:47 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:30:47 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:30:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:30:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:30:47 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:30:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:30:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:30:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:30:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:30:47 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:30:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:30:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:30:47 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:30:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:30:47 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:30:47 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:30:47 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:30:47 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:30:47 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:30:48 --> Session Class Initialized
DEBUG - 2016-09-20 16:30:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:30:48 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:30:48 --> Session routines successfully run
DEBUG - 2016-09-20 16:30:48 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:30:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:30:48 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:30:48 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:30:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:30:48 --> Controller Class Initialized
DEBUG - 2016-09-20 16:30:48 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:30:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:30:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:30:48 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:30:48 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:30:48 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:30:48 --> Model Class Initialized
DEBUG - 2016-09-20 16:30:48 --> Model Class Initialized
DEBUG - 2016-09-20 16:30:48 --> Model Class Initialized
ERROR - 2016-09-20 16:30:48 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:30:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-20 16:30:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:30:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:30:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:30:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:30:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:30:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:30:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:30:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:30:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:30:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:30:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:30:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:30:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:30:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:30:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-20 16:30:48 --> Final output sent to browser
DEBUG - 2016-09-20 16:30:48 --> Total execution time: 0.9611
DEBUG - 2016-09-20 16:30:59 --> Config Class Initialized
DEBUG - 2016-09-20 16:30:59 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:30:59 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:30:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:30:59 --> URI Class Initialized
DEBUG - 2016-09-20 16:30:59 --> Router Class Initialized
DEBUG - 2016-09-20 16:30:59 --> Output Class Initialized
DEBUG - 2016-09-20 16:31:00 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:31:00 --> Security Class Initialized
DEBUG - 2016-09-20 16:31:00 --> Input Class Initialized
DEBUG - 2016-09-20 16:31:00 --> XSS Filtering completed
DEBUG - 2016-09-20 16:31:00 --> XSS Filtering completed
DEBUG - 2016-09-20 16:31:00 --> XSS Filtering completed
DEBUG - 2016-09-20 16:31:00 --> XSS Filtering completed
DEBUG - 2016-09-20 16:31:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:31:00 --> Language Class Initialized
DEBUG - 2016-09-20 16:31:00 --> Loader Class Initialized
DEBUG - 2016-09-20 16:31:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:31:00 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:31:00 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:31:00 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:31:00 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:31:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:31:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:31:00 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:31:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:31:00 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:31:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:31:00 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:31:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:31:00 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:31:00 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:31:00 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:31:00 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:31:00 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:31:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:31:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:31:00 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:31:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:31:00 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:31:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:31:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:31:00 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:31:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:31:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:31:00 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:31:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:31:00 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:31:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:31:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:31:00 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:31:00 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:31:00 --> Session Class Initialized
DEBUG - 2016-09-20 16:31:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:31:00 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:31:00 --> Session routines successfully run
DEBUG - 2016-09-20 16:31:00 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:31:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:31:00 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:31:00 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:31:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:31:00 --> Controller Class Initialized
DEBUG - 2016-09-20 16:31:00 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:31:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:31:00 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:31:00 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:31:00 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:31:00 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:31:00 --> Model Class Initialized
DEBUG - 2016-09-20 16:31:00 --> Model Class Initialized
DEBUG - 2016-09-20 16:31:00 --> Model Class Initialized
ERROR - 2016-09-20 16:31:00 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:31:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-20 16:31:00 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:31:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:31:00 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-20 16:31:01 --> Config Class Initialized
DEBUG - 2016-09-20 16:31:01 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:31:01 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:31:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:31:01 --> URI Class Initialized
DEBUG - 2016-09-20 16:31:01 --> Router Class Initialized
DEBUG - 2016-09-20 16:31:01 --> No URI present. Default controller set.
DEBUG - 2016-09-20 16:31:01 --> Output Class Initialized
DEBUG - 2016-09-20 16:31:01 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:31:01 --> Security Class Initialized
DEBUG - 2016-09-20 16:31:01 --> Input Class Initialized
DEBUG - 2016-09-20 16:31:01 --> XSS Filtering completed
DEBUG - 2016-09-20 16:31:01 --> XSS Filtering completed
DEBUG - 2016-09-20 16:31:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:31:01 --> Language Class Initialized
DEBUG - 2016-09-20 16:31:01 --> Loader Class Initialized
DEBUG - 2016-09-20 16:31:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:31:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:31:01 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:31:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:31:01 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:31:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:31:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:31:01 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:31:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:31:01 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:31:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:31:01 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:31:01 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:31:01 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:31:01 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:31:01 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:31:01 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:31:01 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:31:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:31:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:31:01 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:31:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:31:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:31:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:31:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:31:01 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:31:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:31:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:31:01 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:31:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:31:01 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:31:01 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:31:01 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:31:01 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:31:01 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:31:01 --> Session Class Initialized
DEBUG - 2016-09-20 16:31:01 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:31:01 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:31:01 --> Session routines successfully run
DEBUG - 2016-09-20 16:31:01 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:31:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:31:01 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:31:01 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:31:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:31:01 --> Controller Class Initialized
DEBUG - 2016-09-20 16:31:01 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:31:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:31:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:31:01 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:31:01 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:31:01 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:31:01 --> Model Class Initialized
DEBUG - 2016-09-20 16:31:01 --> Model Class Initialized
DEBUG - 2016-09-20 16:31:02 --> Model Class Initialized
ERROR - 2016-09-20 16:31:02 --> Hak Akses modul/kontroller 'home' untuk role 'administrator' belum di set.
DEBUG - 2016-09-20 16:31:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-20 16:31:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-20 16:31:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:31:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:31:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:31:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:31:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:31:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-20 16:31:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-20 16:31:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:31:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:31:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:31:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:31:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:31:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:31:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:31:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-20 16:31:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-20 16:31:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:31:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:31:02 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-20 16:31:02 --> Final output sent to browser
DEBUG - 2016-09-20 16:31:02 --> Total execution time: 1.0286
DEBUG - 2016-09-20 16:31:02 --> Config Class Initialized
DEBUG - 2016-09-20 16:31:02 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:31:02 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:31:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:31:02 --> URI Class Initialized
DEBUG - 2016-09-20 16:31:02 --> Router Class Initialized
DEBUG - 2016-09-20 16:31:02 --> Output Class Initialized
DEBUG - 2016-09-20 16:31:02 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:31:02 --> Security Class Initialized
DEBUG - 2016-09-20 16:31:02 --> Input Class Initialized
DEBUG - 2016-09-20 16:31:02 --> XSS Filtering completed
DEBUG - 2016-09-20 16:31:02 --> XSS Filtering completed
DEBUG - 2016-09-20 16:31:02 --> XSS Filtering completed
DEBUG - 2016-09-20 16:31:02 --> XSS Filtering completed
DEBUG - 2016-09-20 16:31:02 --> XSS Filtering completed
DEBUG - 2016-09-20 16:31:02 --> XSS Filtering completed
DEBUG - 2016-09-20 16:31:02 --> XSS Filtering completed
DEBUG - 2016-09-20 16:31:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:31:02 --> Language Class Initialized
DEBUG - 2016-09-20 16:31:02 --> Loader Class Initialized
DEBUG - 2016-09-20 16:31:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:31:02 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:31:02 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:31:02 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:31:02 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:31:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:31:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:31:03 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:31:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:31:03 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:31:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:31:03 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:31:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:31:03 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:31:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:31:03 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:31:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:31:03 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:31:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:31:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:31:03 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:31:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:31:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:31:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:31:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:31:03 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:31:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:31:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:31:03 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:31:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:31:03 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:31:03 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:31:03 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:31:03 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:31:03 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:31:03 --> Session Class Initialized
DEBUG - 2016-09-20 16:31:03 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:31:03 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:31:03 --> Session routines successfully run
DEBUG - 2016-09-20 16:31:03 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:31:03 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:31:03 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:31:03 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:31:03 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:31:03 --> Controller Class Initialized
DEBUG - 2016-09-20 16:31:03 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:31:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:31:03 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:31:03 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:31:03 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:31:03 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:31:03 --> Model Class Initialized
DEBUG - 2016-09-20 16:31:03 --> Model Class Initialized
DEBUG - 2016-09-20 16:31:03 --> Model Class Initialized
DEBUG - 2016-09-20 16:31:03 --> Model Class Initialized
DEBUG - 2016-09-20 16:31:03 --> Model Class Initialized
DEBUG - 2016-09-20 16:31:03 --> Model Class Initialized
DEBUG - 2016-09-20 16:31:03 --> Model Class Initialized
DEBUG - 2016-09-20 16:31:03 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-20 16:31:03 --> Final output sent to browser
DEBUG - 2016-09-20 16:31:03 --> Total execution time: 1.1506
DEBUG - 2016-09-20 16:31:30 --> Config Class Initialized
DEBUG - 2016-09-20 16:31:30 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:31:30 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:31:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:31:30 --> URI Class Initialized
DEBUG - 2016-09-20 16:31:30 --> Router Class Initialized
DEBUG - 2016-09-20 16:31:30 --> Output Class Initialized
DEBUG - 2016-09-20 16:31:30 --> Security Class Initialized
DEBUG - 2016-09-20 16:31:30 --> Input Class Initialized
DEBUG - 2016-09-20 16:31:30 --> XSS Filtering completed
DEBUG - 2016-09-20 16:31:30 --> XSS Filtering completed
DEBUG - 2016-09-20 16:31:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:31:30 --> Language Class Initialized
DEBUG - 2016-09-20 16:31:30 --> Loader Class Initialized
DEBUG - 2016-09-20 16:31:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:31:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:31:30 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:31:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:31:30 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:31:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:31:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:31:30 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:31:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:31:30 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:31:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:31:30 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:31:31 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:31:31 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:31:31 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:31:31 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:31:31 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:31:31 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:31:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:31:31 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:31:31 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:31:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:31:31 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:31:31 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:31:31 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:31:31 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:31:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:31:31 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:31:31 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:31:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:31:31 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:31:31 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:31:31 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:31:31 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:31:31 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:31:31 --> Session Class Initialized
DEBUG - 2016-09-20 16:31:31 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:31:31 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:31:31 --> Session routines successfully run
DEBUG - 2016-09-20 16:31:31 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:31:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:31:31 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:31:31 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:31:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:31:31 --> Controller Class Initialized
DEBUG - 2016-09-20 16:31:31 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:31:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:31:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:31:31 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:31:31 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:31:31 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:31:31 --> Model Class Initialized
DEBUG - 2016-09-20 16:31:31 --> Model Class Initialized
DEBUG - 2016-09-20 16:31:31 --> Model Class Initialized
ERROR - 2016-09-20 16:31:31 --> Hak Akses modul/kontroller 'cfpns' untuk role 'administrator' belum di set.
DEBUG - 2016-09-20 16:31:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/logout.php
DEBUG - 2016-09-20 16:31:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:31:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:31:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:31:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:31:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:31:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:31:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:31:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:31:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:31:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:31:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:31:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:31:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:31:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:31:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/35181423a69d222d84fb89a420689cb6
DEBUG - 2016-09-20 16:31:31 --> Final output sent to browser
DEBUG - 2016-09-20 16:31:31 --> Total execution time: 1.0074
DEBUG - 2016-09-20 16:31:55 --> Config Class Initialized
DEBUG - 2016-09-20 16:31:55 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:31:55 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:31:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:31:55 --> URI Class Initialized
DEBUG - 2016-09-20 16:31:55 --> Router Class Initialized
DEBUG - 2016-09-20 16:31:55 --> No URI present. Default controller set.
DEBUG - 2016-09-20 16:31:55 --> Output Class Initialized
DEBUG - 2016-09-20 16:31:55 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:31:55 --> Security Class Initialized
DEBUG - 2016-09-20 16:31:55 --> Input Class Initialized
DEBUG - 2016-09-20 16:31:55 --> XSS Filtering completed
DEBUG - 2016-09-20 16:31:55 --> XSS Filtering completed
DEBUG - 2016-09-20 16:31:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:31:55 --> Language Class Initialized
DEBUG - 2016-09-20 16:31:55 --> Loader Class Initialized
DEBUG - 2016-09-20 16:31:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:31:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:31:55 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:31:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:31:55 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:31:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:31:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:31:55 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:31:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:31:55 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:31:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:31:55 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:31:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:31:55 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:31:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:31:55 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:31:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:31:55 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:31:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:31:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:31:55 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:31:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:31:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:31:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:31:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:31:55 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:31:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:31:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:31:55 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:31:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:31:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:31:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:31:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:31:56 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:31:56 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:31:56 --> Session Class Initialized
DEBUG - 2016-09-20 16:31:56 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:31:56 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:31:56 --> Session routines successfully run
DEBUG - 2016-09-20 16:31:56 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:31:56 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:31:56 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:31:56 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:31:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:31:56 --> Controller Class Initialized
DEBUG - 2016-09-20 16:31:56 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:31:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:31:56 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:31:56 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:31:56 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:31:56 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:31:56 --> Model Class Initialized
DEBUG - 2016-09-20 16:31:56 --> Model Class Initialized
DEBUG - 2016-09-20 16:31:56 --> Model Class Initialized
ERROR - 2016-09-20 16:31:56 --> Hak Akses modul/kontroller 'home' untuk role 'administrator' belum di set.
DEBUG - 2016-09-20 16:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-20 16:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-20 16:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-20 16:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-20 16:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-20 16:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-20 16:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:31:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:31:56 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-20 16:31:56 --> Final output sent to browser
DEBUG - 2016-09-20 16:31:56 --> Total execution time: 1.0549
DEBUG - 2016-09-20 16:31:56 --> Config Class Initialized
DEBUG - 2016-09-20 16:31:56 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:31:57 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:31:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:31:57 --> URI Class Initialized
DEBUG - 2016-09-20 16:31:57 --> Router Class Initialized
DEBUG - 2016-09-20 16:31:57 --> Output Class Initialized
DEBUG - 2016-09-20 16:31:57 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:31:57 --> Security Class Initialized
DEBUG - 2016-09-20 16:31:57 --> Input Class Initialized
DEBUG - 2016-09-20 16:31:57 --> XSS Filtering completed
DEBUG - 2016-09-20 16:31:57 --> XSS Filtering completed
DEBUG - 2016-09-20 16:31:57 --> XSS Filtering completed
DEBUG - 2016-09-20 16:31:57 --> XSS Filtering completed
DEBUG - 2016-09-20 16:31:57 --> XSS Filtering completed
DEBUG - 2016-09-20 16:31:57 --> XSS Filtering completed
DEBUG - 2016-09-20 16:31:57 --> XSS Filtering completed
DEBUG - 2016-09-20 16:31:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:31:57 --> Language Class Initialized
DEBUG - 2016-09-20 16:31:57 --> Loader Class Initialized
DEBUG - 2016-09-20 16:31:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:31:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:31:57 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:31:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:31:57 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:31:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:31:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:31:57 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:31:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:31:57 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:31:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:31:57 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:31:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:31:57 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:31:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:31:57 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:31:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:31:57 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:31:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:31:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:31:57 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:31:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:31:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:31:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:31:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:31:57 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:31:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:31:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:31:57 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:31:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:31:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:31:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:31:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:31:57 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:31:57 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:31:57 --> Session Class Initialized
DEBUG - 2016-09-20 16:31:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:31:57 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:31:57 --> Session routines successfully run
DEBUG - 2016-09-20 16:31:57 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:31:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:31:57 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:31:57 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:31:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:31:57 --> Controller Class Initialized
DEBUG - 2016-09-20 16:31:57 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:31:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:31:58 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:31:58 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:31:58 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:31:58 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:31:58 --> Model Class Initialized
DEBUG - 2016-09-20 16:31:58 --> Model Class Initialized
DEBUG - 2016-09-20 16:31:58 --> Model Class Initialized
DEBUG - 2016-09-20 16:31:58 --> Model Class Initialized
DEBUG - 2016-09-20 16:31:58 --> Model Class Initialized
DEBUG - 2016-09-20 16:31:58 --> Model Class Initialized
DEBUG - 2016-09-20 16:31:58 --> Model Class Initialized
DEBUG - 2016-09-20 16:31:58 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-20 16:31:58 --> Final output sent to browser
DEBUG - 2016-09-20 16:31:58 --> Total execution time: 1.1954
DEBUG - 2016-09-20 16:32:06 --> Config Class Initialized
DEBUG - 2016-09-20 16:32:06 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:32:06 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:32:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:32:06 --> URI Class Initialized
DEBUG - 2016-09-20 16:32:06 --> Router Class Initialized
DEBUG - 2016-09-20 16:32:06 --> No URI present. Default controller set.
DEBUG - 2016-09-20 16:32:06 --> Output Class Initialized
DEBUG - 2016-09-20 16:32:06 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:32:06 --> Security Class Initialized
DEBUG - 2016-09-20 16:32:06 --> Input Class Initialized
DEBUG - 2016-09-20 16:32:06 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:06 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:32:06 --> Language Class Initialized
DEBUG - 2016-09-20 16:32:06 --> Loader Class Initialized
DEBUG - 2016-09-20 16:32:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:32:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:32:06 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:32:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:32:06 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:32:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:32:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:32:06 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:32:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:32:06 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:32:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:32:06 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:32:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:32:06 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:32:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:32:07 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:32:07 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:32:07 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:32:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:32:07 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:32:07 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:32:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:32:07 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:32:07 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:32:07 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:32:07 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:32:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:32:07 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:32:07 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:32:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:32:07 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:32:07 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:32:07 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:32:07 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:32:07 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:32:07 --> Session Class Initialized
DEBUG - 2016-09-20 16:32:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:32:07 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:32:07 --> Session routines successfully run
DEBUG - 2016-09-20 16:32:07 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:32:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:32:07 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:32:07 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:32:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:32:07 --> Controller Class Initialized
DEBUG - 2016-09-20 16:32:07 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:32:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:32:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:32:07 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:32:07 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:32:07 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:32:07 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:07 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:07 --> Model Class Initialized
ERROR - 2016-09-20 16:32:07 --> Hak Akses modul/kontroller 'home' untuk role 'administrator' belum di set.
DEBUG - 2016-09-20 16:32:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-20 16:32:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-20 16:32:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:32:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:32:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:32:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:32:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:32:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-20 16:32:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-20 16:32:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:32:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:32:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:32:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:32:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:32:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:32:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:32:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-20 16:32:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-20 16:32:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:32:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:32:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-20 16:32:07 --> Final output sent to browser
DEBUG - 2016-09-20 16:32:07 --> Total execution time: 1.0965
DEBUG - 2016-09-20 16:32:08 --> Config Class Initialized
DEBUG - 2016-09-20 16:32:08 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:32:08 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:32:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:32:08 --> URI Class Initialized
DEBUG - 2016-09-20 16:32:08 --> Router Class Initialized
DEBUG - 2016-09-20 16:32:08 --> Output Class Initialized
DEBUG - 2016-09-20 16:32:08 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:32:08 --> Security Class Initialized
DEBUG - 2016-09-20 16:32:08 --> Input Class Initialized
DEBUG - 2016-09-20 16:32:08 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:08 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:08 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:08 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:08 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:08 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:08 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:32:08 --> Language Class Initialized
DEBUG - 2016-09-20 16:32:08 --> Loader Class Initialized
DEBUG - 2016-09-20 16:32:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:32:08 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:32:08 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:32:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:32:09 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:32:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:32:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:32:09 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:32:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:32:09 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:32:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:32:09 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:32:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:32:09 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:32:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:32:09 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:32:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:32:09 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:32:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:32:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:32:09 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:32:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:32:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:32:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:32:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:32:09 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:32:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:32:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:32:09 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:32:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:32:09 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:32:09 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:32:09 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:32:09 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:32:09 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:32:09 --> Session Class Initialized
DEBUG - 2016-09-20 16:32:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:32:09 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:32:09 --> Session routines successfully run
DEBUG - 2016-09-20 16:32:09 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:32:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:32:09 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:32:09 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:32:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:32:09 --> Controller Class Initialized
DEBUG - 2016-09-20 16:32:09 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:32:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:32:09 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:32:09 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:32:09 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:32:09 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:32:09 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:09 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:09 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:09 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:09 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:09 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:09 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:09 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-20 16:32:09 --> Final output sent to browser
DEBUG - 2016-09-20 16:32:09 --> Total execution time: 1.2350
DEBUG - 2016-09-20 16:32:10 --> Config Class Initialized
DEBUG - 2016-09-20 16:32:10 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:32:10 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:32:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:32:10 --> URI Class Initialized
DEBUG - 2016-09-20 16:32:10 --> Router Class Initialized
DEBUG - 2016-09-20 16:32:10 --> Output Class Initialized
DEBUG - 2016-09-20 16:32:10 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:32:10 --> Security Class Initialized
DEBUG - 2016-09-20 16:32:10 --> Input Class Initialized
DEBUG - 2016-09-20 16:32:10 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:10 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:32:10 --> Language Class Initialized
DEBUG - 2016-09-20 16:32:10 --> Loader Class Initialized
DEBUG - 2016-09-20 16:32:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:32:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:32:10 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:32:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:32:10 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:32:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:32:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:32:10 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:32:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:32:10 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:32:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:32:10 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:32:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:32:10 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:32:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:32:10 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:32:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:32:10 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:32:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:32:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:32:10 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:32:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:32:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:32:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:32:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:32:10 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:32:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:32:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:32:10 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:32:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:32:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:32:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:32:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:32:11 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:32:11 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:32:11 --> Session Class Initialized
DEBUG - 2016-09-20 16:32:11 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:32:11 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:32:11 --> Session routines successfully run
DEBUG - 2016-09-20 16:32:11 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:32:11 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:32:11 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:32:11 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:32:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:32:11 --> Controller Class Initialized
DEBUG - 2016-09-20 16:32:11 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:32:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:32:11 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:32:11 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:32:11 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:32:11 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:32:11 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:11 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:11 --> Model Class Initialized
ERROR - 2016-09-20 16:32:11 --> Hak Akses modul/kontroller 'cfpns' untuk role 'administrator' belum di set.
DEBUG - 2016-09-20 16:32:11 --> Config Class Initialized
DEBUG - 2016-09-20 16:32:11 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:32:11 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:32:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:32:11 --> URI Class Initialized
DEBUG - 2016-09-20 16:32:11 --> Router Class Initialized
DEBUG - 2016-09-20 16:32:11 --> No URI present. Default controller set.
DEBUG - 2016-09-20 16:32:11 --> Output Class Initialized
DEBUG - 2016-09-20 16:32:11 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:32:11 --> Security Class Initialized
DEBUG - 2016-09-20 16:32:11 --> Input Class Initialized
DEBUG - 2016-09-20 16:32:11 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:11 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:32:11 --> Language Class Initialized
DEBUG - 2016-09-20 16:32:11 --> Loader Class Initialized
DEBUG - 2016-09-20 16:32:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:32:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:32:11 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:32:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:32:11 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:32:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:32:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:32:11 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:32:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:32:11 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:32:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:32:11 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:32:11 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:32:11 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:32:11 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:32:11 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:32:11 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:32:11 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:32:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:32:11 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:32:11 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:32:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:32:11 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:32:11 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:32:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:32:12 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:32:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:32:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:32:12 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:32:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:32:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:32:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:32:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:32:12 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:32:12 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:32:12 --> Session Class Initialized
DEBUG - 2016-09-20 16:32:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:32:12 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:32:12 --> Session routines successfully run
DEBUG - 2016-09-20 16:32:12 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:32:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:32:12 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:32:12 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:32:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:32:12 --> Controller Class Initialized
DEBUG - 2016-09-20 16:32:12 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:32:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:32:12 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:32:12 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:32:12 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:32:12 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:32:12 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:12 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:12 --> Model Class Initialized
ERROR - 2016-09-20 16:32:12 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:32:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-20 16:32:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-20 16:32:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:32:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:32:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:32:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:32:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:32:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-20 16:32:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-20 16:32:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:32:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:32:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:32:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:32:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:32:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:32:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:32:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-20 16:32:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-20 16:32:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:32:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:32:12 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-20 16:32:12 --> Final output sent to browser
DEBUG - 2016-09-20 16:32:12 --> Total execution time: 1.1255
DEBUG - 2016-09-20 16:32:13 --> Config Class Initialized
DEBUG - 2016-09-20 16:32:13 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:32:13 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:32:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:32:13 --> URI Class Initialized
DEBUG - 2016-09-20 16:32:13 --> Router Class Initialized
DEBUG - 2016-09-20 16:32:13 --> Output Class Initialized
DEBUG - 2016-09-20 16:32:13 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:32:13 --> Security Class Initialized
DEBUG - 2016-09-20 16:32:13 --> Input Class Initialized
DEBUG - 2016-09-20 16:32:13 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:13 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:13 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:13 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:13 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:13 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:13 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:32:13 --> Language Class Initialized
DEBUG - 2016-09-20 16:32:13 --> Loader Class Initialized
DEBUG - 2016-09-20 16:32:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:32:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:32:13 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:32:13 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:32:13 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:32:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:32:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:32:13 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:32:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:32:13 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:32:13 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:32:13 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:32:13 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:32:13 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:32:13 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:32:13 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:32:13 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:32:13 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:32:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:32:13 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:32:13 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:32:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:32:13 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:32:13 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:32:13 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:32:13 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:32:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:32:13 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:32:13 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:32:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:32:13 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:32:13 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:32:13 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:32:13 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:32:13 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:32:14 --> Session Class Initialized
DEBUG - 2016-09-20 16:32:14 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:32:14 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:32:14 --> Session routines successfully run
DEBUG - 2016-09-20 16:32:14 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:32:14 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:32:14 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:32:14 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:32:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:32:14 --> Controller Class Initialized
DEBUG - 2016-09-20 16:32:14 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:32:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:32:14 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:32:14 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:32:14 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:32:14 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:32:14 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:14 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:14 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:14 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:14 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:14 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:14 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:14 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-20 16:32:14 --> Final output sent to browser
DEBUG - 2016-09-20 16:32:14 --> Total execution time: 1.2745
DEBUG - 2016-09-20 16:32:30 --> Config Class Initialized
DEBUG - 2016-09-20 16:32:30 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:32:30 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:32:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:32:30 --> URI Class Initialized
DEBUG - 2016-09-20 16:32:30 --> Router Class Initialized
DEBUG - 2016-09-20 16:32:30 --> Output Class Initialized
DEBUG - 2016-09-20 16:32:30 --> Security Class Initialized
DEBUG - 2016-09-20 16:32:30 --> Input Class Initialized
DEBUG - 2016-09-20 16:32:30 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:30 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:32:30 --> Language Class Initialized
DEBUG - 2016-09-20 16:32:30 --> Loader Class Initialized
DEBUG - 2016-09-20 16:32:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:32:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:32:30 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:32:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:32:30 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:32:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:32:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:32:30 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:32:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:32:30 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:32:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:32:30 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:32:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:32:30 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:32:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:32:30 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:32:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:32:30 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:32:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:32:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:32:30 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:32:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:32:31 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:32:31 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:32:31 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:32:31 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:32:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:32:31 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:32:31 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:32:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:32:31 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:32:31 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:32:31 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:32:31 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:32:31 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:32:31 --> Session Class Initialized
DEBUG - 2016-09-20 16:32:31 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:32:31 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:32:31 --> Session routines successfully run
DEBUG - 2016-09-20 16:32:31 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:32:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:32:31 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:32:31 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:32:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:32:31 --> Controller Class Initialized
DEBUG - 2016-09-20 16:32:31 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:32:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:32:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:32:31 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:32:31 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:32:31 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:32:31 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:31 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:31 --> Model Class Initialized
ERROR - 2016-09-20 16:32:31 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:32:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-20 16:32:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:32:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:32:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:32:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:32:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:32:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:32:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:32:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:32:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:32:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:32:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:32:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:32:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:32:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:32:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-20 16:32:31 --> Final output sent to browser
DEBUG - 2016-09-20 16:32:31 --> Total execution time: 1.1320
DEBUG - 2016-09-20 16:32:44 --> Config Class Initialized
DEBUG - 2016-09-20 16:32:44 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:32:44 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:32:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:32:44 --> URI Class Initialized
DEBUG - 2016-09-20 16:32:44 --> Router Class Initialized
DEBUG - 2016-09-20 16:32:44 --> Output Class Initialized
DEBUG - 2016-09-20 16:32:44 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:32:44 --> Security Class Initialized
DEBUG - 2016-09-20 16:32:44 --> Input Class Initialized
DEBUG - 2016-09-20 16:32:44 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:44 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:32:44 --> Language Class Initialized
DEBUG - 2016-09-20 16:32:44 --> Loader Class Initialized
DEBUG - 2016-09-20 16:32:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:32:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:32:44 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:32:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:32:44 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:32:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:32:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:32:44 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:32:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:32:44 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:32:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:32:44 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:32:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:32:44 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:32:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:32:44 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:32:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:32:44 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:32:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:32:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:32:44 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:32:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:32:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:32:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:32:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:32:44 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:32:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:32:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:32:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:32:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:32:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:32:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:32:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:32:44 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:32:44 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:32:44 --> Session Class Initialized
DEBUG - 2016-09-20 16:32:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:32:45 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:32:45 --> Session routines successfully run
DEBUG - 2016-09-20 16:32:45 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:32:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:32:45 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:32:45 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:32:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:32:45 --> Controller Class Initialized
DEBUG - 2016-09-20 16:32:45 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:32:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:32:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:32:45 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:32:45 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:32:45 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:32:45 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:45 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:45 --> Model Class Initialized
ERROR - 2016-09-20 16:32:45 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-20 16:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:32:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:32:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-20 16:32:45 --> Final output sent to browser
DEBUG - 2016-09-20 16:32:45 --> Total execution time: 1.2134
DEBUG - 2016-09-20 16:32:47 --> Config Class Initialized
DEBUG - 2016-09-20 16:32:47 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:32:47 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:32:47 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:32:47 --> URI Class Initialized
DEBUG - 2016-09-20 16:32:47 --> Router Class Initialized
DEBUG - 2016-09-20 16:32:47 --> Output Class Initialized
DEBUG - 2016-09-20 16:32:47 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:32:47 --> Security Class Initialized
DEBUG - 2016-09-20 16:32:47 --> Input Class Initialized
DEBUG - 2016-09-20 16:32:47 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:47 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:32:47 --> Language Class Initialized
DEBUG - 2016-09-20 16:32:47 --> Loader Class Initialized
DEBUG - 2016-09-20 16:32:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:32:47 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:32:47 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:32:47 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:32:47 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:32:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:32:47 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:32:47 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:32:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:32:47 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:32:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:32:48 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:32:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:32:48 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:32:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:32:48 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:32:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:32:48 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:32:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:32:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:32:48 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:32:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:32:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:32:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:32:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:32:48 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:32:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:32:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:32:48 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:32:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:32:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:32:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:32:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:32:48 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:32:48 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:32:48 --> Session Class Initialized
DEBUG - 2016-09-20 16:32:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:32:48 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:32:48 --> Session routines successfully run
DEBUG - 2016-09-20 16:32:48 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:32:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:32:48 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:32:48 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:32:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:32:48 --> Controller Class Initialized
DEBUG - 2016-09-20 16:32:48 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:32:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:32:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:32:48 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:32:48 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:32:48 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:32:48 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:48 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:48 --> Model Class Initialized
ERROR - 2016-09-20 16:32:48 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:32:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-09-20 16:32:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:32:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:32:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:32:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:32:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:32:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:32:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:32:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:32:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:32:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:32:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:32:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:32:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:32:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:32:49 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-09-20 16:32:49 --> Final output sent to browser
DEBUG - 2016-09-20 16:32:49 --> Total execution time: 1.1741
DEBUG - 2016-09-20 16:32:55 --> Config Class Initialized
DEBUG - 2016-09-20 16:32:55 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:32:55 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:32:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:32:55 --> URI Class Initialized
DEBUG - 2016-09-20 16:32:55 --> Router Class Initialized
DEBUG - 2016-09-20 16:32:55 --> Output Class Initialized
DEBUG - 2016-09-20 16:32:55 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:32:55 --> Security Class Initialized
DEBUG - 2016-09-20 16:32:55 --> Input Class Initialized
DEBUG - 2016-09-20 16:32:55 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:55 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:55 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:55 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:32:55 --> Language Class Initialized
DEBUG - 2016-09-20 16:32:55 --> Loader Class Initialized
DEBUG - 2016-09-20 16:32:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:32:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:32:55 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:32:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:32:55 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:32:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:32:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:32:55 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:32:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:32:55 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:32:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:32:55 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:32:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:32:55 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:32:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:32:55 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:32:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:32:55 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:32:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:32:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:32:55 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:32:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:32:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:32:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:32:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:32:55 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:32:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:32:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:32:55 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:32:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:32:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:32:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:32:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:32:55 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:32:55 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:32:56 --> Session Class Initialized
DEBUG - 2016-09-20 16:32:56 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:32:56 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:32:56 --> Session routines successfully run
DEBUG - 2016-09-20 16:32:56 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:32:56 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:32:56 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:32:56 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:32:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:32:56 --> Controller Class Initialized
DEBUG - 2016-09-20 16:32:56 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:32:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:32:56 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:32:56 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:32:56 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:32:56 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:32:56 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:56 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:56 --> Model Class Initialized
ERROR - 2016-09-20 16:32:56 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 16:32:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-20 16:32:56 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:32:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:32:56 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-20 16:32:56 --> Config Class Initialized
DEBUG - 2016-09-20 16:32:56 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:32:56 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:32:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:32:56 --> URI Class Initialized
DEBUG - 2016-09-20 16:32:56 --> Router Class Initialized
DEBUG - 2016-09-20 16:32:56 --> No URI present. Default controller set.
DEBUG - 2016-09-20 16:32:56 --> Output Class Initialized
DEBUG - 2016-09-20 16:32:56 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:32:56 --> Security Class Initialized
DEBUG - 2016-09-20 16:32:56 --> Input Class Initialized
DEBUG - 2016-09-20 16:32:56 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:56 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:32:56 --> Language Class Initialized
DEBUG - 2016-09-20 16:32:56 --> Loader Class Initialized
DEBUG - 2016-09-20 16:32:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:32:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:32:56 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:32:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:32:56 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:32:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:32:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:32:56 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:32:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:32:56 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:32:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:32:56 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:32:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:32:56 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:32:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:32:57 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:32:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:32:57 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:32:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:32:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:32:57 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:32:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:32:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:32:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:32:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:32:57 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:32:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:32:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:32:57 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:32:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:32:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:32:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:32:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:32:57 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:32:57 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:32:57 --> Session Class Initialized
DEBUG - 2016-09-20 16:32:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:32:57 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:32:57 --> Session routines successfully run
DEBUG - 2016-09-20 16:32:57 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:32:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:32:57 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:32:57 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:32:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:32:57 --> Controller Class Initialized
DEBUG - 2016-09-20 16:32:57 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:32:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:32:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:32:57 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:32:57 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:32:57 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:32:57 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:57 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:57 --> Model Class Initialized
ERROR - 2016-09-20 16:32:57 --> Hak Akses modul/kontroller 'home' untuk role 'administrator' belum di set.
DEBUG - 2016-09-20 16:32:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-20 16:32:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-20 16:32:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:32:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:32:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:32:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:32:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:32:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-20 16:32:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-20 16:32:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:32:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:32:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:32:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:32:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:32:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:32:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:32:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-20 16:32:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-20 16:32:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:32:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:32:58 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-20 16:32:58 --> Final output sent to browser
DEBUG - 2016-09-20 16:32:58 --> Total execution time: 1.2258
DEBUG - 2016-09-20 16:32:58 --> Config Class Initialized
DEBUG - 2016-09-20 16:32:58 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:32:58 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:32:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:32:58 --> URI Class Initialized
DEBUG - 2016-09-20 16:32:58 --> Router Class Initialized
DEBUG - 2016-09-20 16:32:58 --> Output Class Initialized
DEBUG - 2016-09-20 16:32:58 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:32:58 --> Security Class Initialized
DEBUG - 2016-09-20 16:32:58 --> Input Class Initialized
DEBUG - 2016-09-20 16:32:58 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:58 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:58 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:58 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:58 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:58 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:58 --> XSS Filtering completed
DEBUG - 2016-09-20 16:32:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:32:58 --> Language Class Initialized
DEBUG - 2016-09-20 16:32:58 --> Loader Class Initialized
DEBUG - 2016-09-20 16:32:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:32:58 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:32:58 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:32:58 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:32:58 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:32:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:32:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:32:58 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:32:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:32:58 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:32:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:32:58 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:32:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:32:58 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:32:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:32:58 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:32:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:32:59 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:32:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:32:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:32:59 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:32:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:32:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:32:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:32:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:32:59 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:32:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:32:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:32:59 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:32:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:32:59 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:32:59 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:32:59 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:32:59 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:32:59 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:32:59 --> Session Class Initialized
DEBUG - 2016-09-20 16:32:59 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:32:59 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:32:59 --> Session routines successfully run
DEBUG - 2016-09-20 16:32:59 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:32:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:32:59 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:32:59 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:32:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:32:59 --> Controller Class Initialized
DEBUG - 2016-09-20 16:32:59 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:32:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:32:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:32:59 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:32:59 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:32:59 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:32:59 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:59 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:59 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:59 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:59 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:59 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:59 --> Model Class Initialized
DEBUG - 2016-09-20 16:32:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-20 16:32:59 --> Final output sent to browser
DEBUG - 2016-09-20 16:32:59 --> Total execution time: 1.3856
DEBUG - 2016-09-20 16:33:01 --> Config Class Initialized
DEBUG - 2016-09-20 16:33:01 --> Hooks Class Initialized
DEBUG - 2016-09-20 16:33:01 --> Utf8 Class Initialized
DEBUG - 2016-09-20 16:33:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 16:33:01 --> URI Class Initialized
DEBUG - 2016-09-20 16:33:01 --> Router Class Initialized
DEBUG - 2016-09-20 16:33:01 --> Output Class Initialized
DEBUG - 2016-09-20 16:33:01 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 16:33:01 --> Security Class Initialized
DEBUG - 2016-09-20 16:33:01 --> Input Class Initialized
DEBUG - 2016-09-20 16:33:01 --> XSS Filtering completed
DEBUG - 2016-09-20 16:33:01 --> XSS Filtering completed
DEBUG - 2016-09-20 16:33:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 16:33:01 --> Language Class Initialized
DEBUG - 2016-09-20 16:33:01 --> Loader Class Initialized
DEBUG - 2016-09-20 16:33:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 16:33:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 16:33:01 --> Helper loaded: url_helper
DEBUG - 2016-09-20 16:33:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 16:33:01 --> Helper loaded: file_helper
DEBUG - 2016-09-20 16:33:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:33:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 16:33:01 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 16:33:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 16:33:01 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 16:33:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 16:33:01 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:33:01 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 16:33:01 --> Helper loaded: common_helper
DEBUG - 2016-09-20 16:33:01 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 16:33:01 --> Helper loaded: form_helper
DEBUG - 2016-09-20 16:33:01 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 16:33:01 --> Helper loaded: security_helper
DEBUG - 2016-09-20 16:33:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:33:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 16:33:01 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 16:33:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 16:33:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 16:33:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 16:33:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 16:33:02 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 16:33:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:33:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 16:33:02 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 16:33:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 16:33:02 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 16:33:02 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 16:33:02 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 16:33:02 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 16:33:02 --> Database Driver Class Initialized
DEBUG - 2016-09-20 16:33:02 --> Session Class Initialized
DEBUG - 2016-09-20 16:33:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 16:33:02 --> Helper loaded: string_helper
DEBUG - 2016-09-20 16:33:02 --> Session routines successfully run
DEBUG - 2016-09-20 16:33:02 --> Native_session Class Initialized
DEBUG - 2016-09-20 16:33:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 16:33:02 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:33:02 --> Form Validation Class Initialized
DEBUG - 2016-09-20 16:33:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 16:33:02 --> Controller Class Initialized
DEBUG - 2016-09-20 16:33:02 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 16:33:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 16:33:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 16:33:02 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:33:02 --> Carabiner: library configured.
DEBUG - 2016-09-20 16:33:02 --> User Agent Class Initialized
DEBUG - 2016-09-20 16:33:02 --> Model Class Initialized
DEBUG - 2016-09-20 16:33:02 --> Model Class Initialized
DEBUG - 2016-09-20 16:33:02 --> Model Class Initialized
DEBUG - 2016-09-20 16:33:02 --> Model Class Initialized
DEBUG - 2016-09-20 16:33:02 --> Model Class Initialized
DEBUG - 2016-09-20 16:33:02 --> Model Class Initialized
DEBUG - 2016-09-20 16:33:02 --> Model Class Initialized
DEBUG - 2016-09-20 16:33:02 --> Model Class Initialized
ERROR - 2016-09-20 16:33:02 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'administrator' belum di set.
DEBUG - 2016-09-20 16:33:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-09-20 16:33:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:33:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:33:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:33:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:33:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:33:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:33:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:33:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 16:33:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 16:33:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 16:33:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 16:33:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 16:33:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 16:33:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 16:33:02 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/73f5e075ee35be5f6c1c98a57562112a
DEBUG - 2016-09-20 16:33:03 --> Final output sent to browser
DEBUG - 2016-09-20 16:33:03 --> Total execution time: 1.3524
DEBUG - 2016-09-20 18:28:11 --> Config Class Initialized
DEBUG - 2016-09-20 18:28:11 --> Hooks Class Initialized
DEBUG - 2016-09-20 18:28:11 --> Utf8 Class Initialized
DEBUG - 2016-09-20 18:28:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 18:28:11 --> URI Class Initialized
DEBUG - 2016-09-20 18:28:11 --> Router Class Initialized
DEBUG - 2016-09-20 18:28:11 --> Output Class Initialized
DEBUG - 2016-09-20 18:28:11 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 18:28:11 --> Security Class Initialized
DEBUG - 2016-09-20 18:28:11 --> Input Class Initialized
DEBUG - 2016-09-20 18:28:11 --> XSS Filtering completed
DEBUG - 2016-09-20 18:28:11 --> XSS Filtering completed
DEBUG - 2016-09-20 18:28:11 --> XSS Filtering completed
DEBUG - 2016-09-20 18:28:11 --> XSS Filtering completed
DEBUG - 2016-09-20 18:28:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 18:28:11 --> Language Class Initialized
DEBUG - 2016-09-20 18:28:11 --> Loader Class Initialized
DEBUG - 2016-09-20 18:28:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 18:28:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 18:28:11 --> Helper loaded: url_helper
DEBUG - 2016-09-20 18:28:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 18:28:11 --> Helper loaded: file_helper
DEBUG - 2016-09-20 18:28:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 18:28:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 18:28:11 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 18:28:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 18:28:11 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 18:28:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 18:28:11 --> Helper loaded: common_helper
DEBUG - 2016-09-20 18:28:11 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 18:28:11 --> Helper loaded: common_helper
DEBUG - 2016-09-20 18:28:11 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 18:28:11 --> Helper loaded: form_helper
DEBUG - 2016-09-20 18:28:11 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 18:28:11 --> Helper loaded: security_helper
DEBUG - 2016-09-20 18:28:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 18:28:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 18:28:12 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 18:28:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 18:28:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 18:28:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 18:28:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 18:28:12 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 18:28:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 18:28:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 18:28:12 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 18:28:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 18:28:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 18:28:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 18:28:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 18:28:12 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 18:28:12 --> Database Driver Class Initialized
DEBUG - 2016-09-20 18:28:12 --> Session Class Initialized
DEBUG - 2016-09-20 18:28:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 18:28:12 --> Helper loaded: string_helper
DEBUG - 2016-09-20 18:28:12 --> Session routines successfully run
DEBUG - 2016-09-20 18:28:12 --> Native_session Class Initialized
DEBUG - 2016-09-20 18:28:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 18:28:12 --> Form Validation Class Initialized
DEBUG - 2016-09-20 18:28:12 --> Form Validation Class Initialized
DEBUG - 2016-09-20 18:28:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 18:28:12 --> Controller Class Initialized
DEBUG - 2016-09-20 18:28:12 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 18:28:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 18:28:12 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 18:28:12 --> Carabiner: library configured.
DEBUG - 2016-09-20 18:28:12 --> Carabiner: library configured.
DEBUG - 2016-09-20 18:28:12 --> User Agent Class Initialized
DEBUG - 2016-09-20 18:28:12 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:12 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:12 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:12 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:12 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:12 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:12 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:12 --> Model Class Initialized
ERROR - 2016-09-20 18:28:12 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-20 18:28:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-20 18:28:12 --> Form Validation Class Initialized
DEBUG - 2016-09-20 18:28:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 18:28:12 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-20 18:28:12 --> Config Class Initialized
DEBUG - 2016-09-20 18:28:12 --> Hooks Class Initialized
DEBUG - 2016-09-20 18:28:12 --> Utf8 Class Initialized
DEBUG - 2016-09-20 18:28:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 18:28:12 --> URI Class Initialized
DEBUG - 2016-09-20 18:28:12 --> Router Class Initialized
DEBUG - 2016-09-20 18:28:12 --> No URI present. Default controller set.
DEBUG - 2016-09-20 18:28:13 --> Output Class Initialized
DEBUG - 2016-09-20 18:28:13 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 18:28:13 --> Security Class Initialized
DEBUG - 2016-09-20 18:28:13 --> Input Class Initialized
DEBUG - 2016-09-20 18:28:13 --> XSS Filtering completed
DEBUG - 2016-09-20 18:28:13 --> XSS Filtering completed
DEBUG - 2016-09-20 18:28:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 18:28:13 --> Language Class Initialized
DEBUG - 2016-09-20 18:28:13 --> Loader Class Initialized
DEBUG - 2016-09-20 18:28:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 18:28:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 18:28:13 --> Helper loaded: url_helper
DEBUG - 2016-09-20 18:28:13 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 18:28:13 --> Helper loaded: file_helper
DEBUG - 2016-09-20 18:28:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 18:28:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 18:28:13 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 18:28:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 18:28:13 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 18:28:13 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 18:28:13 --> Helper loaded: common_helper
DEBUG - 2016-09-20 18:28:13 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 18:28:13 --> Helper loaded: common_helper
DEBUG - 2016-09-20 18:28:13 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 18:28:13 --> Helper loaded: form_helper
DEBUG - 2016-09-20 18:28:13 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 18:28:13 --> Helper loaded: security_helper
DEBUG - 2016-09-20 18:28:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 18:28:13 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 18:28:13 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 18:28:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 18:28:13 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 18:28:13 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 18:28:13 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 18:28:13 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 18:28:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 18:28:13 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 18:28:13 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 18:28:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 18:28:13 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 18:28:13 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 18:28:13 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 18:28:13 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 18:28:13 --> Database Driver Class Initialized
DEBUG - 2016-09-20 18:28:13 --> Session Class Initialized
DEBUG - 2016-09-20 18:28:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 18:28:13 --> Helper loaded: string_helper
DEBUG - 2016-09-20 18:28:13 --> Session routines successfully run
DEBUG - 2016-09-20 18:28:13 --> Native_session Class Initialized
DEBUG - 2016-09-20 18:28:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 18:28:13 --> Form Validation Class Initialized
DEBUG - 2016-09-20 18:28:13 --> Form Validation Class Initialized
DEBUG - 2016-09-20 18:28:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 18:28:13 --> Controller Class Initialized
DEBUG - 2016-09-20 18:28:13 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 18:28:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 18:28:14 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 18:28:14 --> Carabiner: library configured.
DEBUG - 2016-09-20 18:28:14 --> Carabiner: library configured.
DEBUG - 2016-09-20 18:28:14 --> User Agent Class Initialized
DEBUG - 2016-09-20 18:28:14 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:14 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:14 --> Model Class Initialized
ERROR - 2016-09-20 18:28:14 --> Hak Akses modul/kontroller 'home' untuk role 'administrator' belum di set.
DEBUG - 2016-09-20 18:28:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-20 18:28:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-20 18:28:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 18:28:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 18:28:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 18:28:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 18:28:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 18:28:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-20 18:28:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-20 18:28:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 18:28:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 18:28:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-20 18:28:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 18:28:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-20 18:28:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-20 18:28:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-20 18:28:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-20 18:28:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-20 18:28:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 18:28:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-20 18:28:14 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-20 18:28:14 --> Final output sent to browser
DEBUG - 2016-09-20 18:28:14 --> Total execution time: 1.2990
DEBUG - 2016-09-20 18:28:14 --> Config Class Initialized
DEBUG - 2016-09-20 18:28:14 --> Hooks Class Initialized
DEBUG - 2016-09-20 18:28:14 --> Utf8 Class Initialized
DEBUG - 2016-09-20 18:28:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 18:28:14 --> URI Class Initialized
DEBUG - 2016-09-20 18:28:14 --> Router Class Initialized
DEBUG - 2016-09-20 18:28:14 --> Output Class Initialized
DEBUG - 2016-09-20 18:28:14 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 18:28:14 --> Security Class Initialized
DEBUG - 2016-09-20 18:28:14 --> Input Class Initialized
DEBUG - 2016-09-20 18:28:14 --> XSS Filtering completed
DEBUG - 2016-09-20 18:28:14 --> XSS Filtering completed
DEBUG - 2016-09-20 18:28:14 --> XSS Filtering completed
DEBUG - 2016-09-20 18:28:14 --> XSS Filtering completed
DEBUG - 2016-09-20 18:28:15 --> XSS Filtering completed
DEBUG - 2016-09-20 18:28:15 --> XSS Filtering completed
DEBUG - 2016-09-20 18:28:15 --> XSS Filtering completed
DEBUG - 2016-09-20 18:28:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 18:28:15 --> Language Class Initialized
DEBUG - 2016-09-20 18:28:15 --> Loader Class Initialized
DEBUG - 2016-09-20 18:28:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 18:28:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 18:28:15 --> Helper loaded: url_helper
DEBUG - 2016-09-20 18:28:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 18:28:15 --> Helper loaded: file_helper
DEBUG - 2016-09-20 18:28:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 18:28:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 18:28:15 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 18:28:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 18:28:15 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 18:28:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 18:28:15 --> Helper loaded: common_helper
DEBUG - 2016-09-20 18:28:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 18:28:15 --> Helper loaded: common_helper
DEBUG - 2016-09-20 18:28:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 18:28:15 --> Helper loaded: form_helper
DEBUG - 2016-09-20 18:28:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 18:28:15 --> Helper loaded: security_helper
DEBUG - 2016-09-20 18:28:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 18:28:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 18:28:15 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 18:28:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 18:28:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 18:28:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 18:28:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 18:28:15 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 18:28:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 18:28:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 18:28:15 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 18:28:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 18:28:15 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 18:28:15 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 18:28:15 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 18:28:15 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 18:28:15 --> Database Driver Class Initialized
DEBUG - 2016-09-20 18:28:15 --> Session Class Initialized
DEBUG - 2016-09-20 18:28:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 18:28:15 --> Helper loaded: string_helper
DEBUG - 2016-09-20 18:28:15 --> Session routines successfully run
DEBUG - 2016-09-20 18:28:15 --> Native_session Class Initialized
DEBUG - 2016-09-20 18:28:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 18:28:15 --> Form Validation Class Initialized
DEBUG - 2016-09-20 18:28:15 --> Form Validation Class Initialized
DEBUG - 2016-09-20 18:28:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 18:28:15 --> Controller Class Initialized
DEBUG - 2016-09-20 18:28:15 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 18:28:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 18:28:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 18:28:15 --> Carabiner: library configured.
DEBUG - 2016-09-20 18:28:16 --> Carabiner: library configured.
DEBUG - 2016-09-20 18:28:16 --> User Agent Class Initialized
DEBUG - 2016-09-20 18:28:16 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:16 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:16 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:16 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:16 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:16 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:16 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:16 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-09-20 18:28:16 --> Final output sent to browser
DEBUG - 2016-09-20 18:28:16 --> Total execution time: 1.4408
DEBUG - 2016-09-20 18:28:16 --> Config Class Initialized
DEBUG - 2016-09-20 18:28:16 --> Hooks Class Initialized
DEBUG - 2016-09-20 18:28:16 --> Utf8 Class Initialized
DEBUG - 2016-09-20 18:28:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 18:28:17 --> URI Class Initialized
DEBUG - 2016-09-20 18:28:17 --> Router Class Initialized
DEBUG - 2016-09-20 18:28:17 --> Output Class Initialized
DEBUG - 2016-09-20 18:28:17 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 18:28:17 --> Security Class Initialized
DEBUG - 2016-09-20 18:28:17 --> Input Class Initialized
DEBUG - 2016-09-20 18:28:17 --> XSS Filtering completed
DEBUG - 2016-09-20 18:28:17 --> XSS Filtering completed
DEBUG - 2016-09-20 18:28:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 18:28:17 --> Language Class Initialized
DEBUG - 2016-09-20 18:28:17 --> Loader Class Initialized
DEBUG - 2016-09-20 18:28:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 18:28:17 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 18:28:17 --> Helper loaded: url_helper
DEBUG - 2016-09-20 18:28:17 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 18:28:17 --> Helper loaded: file_helper
DEBUG - 2016-09-20 18:28:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 18:28:17 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 18:28:17 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 18:28:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 18:28:17 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 18:28:17 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 18:28:17 --> Helper loaded: common_helper
DEBUG - 2016-09-20 18:28:17 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 18:28:17 --> Helper loaded: common_helper
DEBUG - 2016-09-20 18:28:17 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 18:28:17 --> Helper loaded: form_helper
DEBUG - 2016-09-20 18:28:17 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 18:28:17 --> Helper loaded: security_helper
DEBUG - 2016-09-20 18:28:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 18:28:17 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 18:28:17 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 18:28:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 18:28:17 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 18:28:17 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 18:28:17 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 18:28:17 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 18:28:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 18:28:17 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 18:28:17 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 18:28:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 18:28:17 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 18:28:17 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 18:28:17 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 18:28:17 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 18:28:17 --> Database Driver Class Initialized
DEBUG - 2016-09-20 18:28:17 --> Session Class Initialized
DEBUG - 2016-09-20 18:28:17 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 18:28:17 --> Helper loaded: string_helper
DEBUG - 2016-09-20 18:28:17 --> Session routines successfully run
DEBUG - 2016-09-20 18:28:17 --> Native_session Class Initialized
DEBUG - 2016-09-20 18:28:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 18:28:18 --> Form Validation Class Initialized
DEBUG - 2016-09-20 18:28:18 --> Form Validation Class Initialized
DEBUG - 2016-09-20 18:28:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 18:28:18 --> Controller Class Initialized
DEBUG - 2016-09-20 18:28:18 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 18:28:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 18:28:18 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 18:28:18 --> Carabiner: library configured.
DEBUG - 2016-09-20 18:28:18 --> Carabiner: library configured.
DEBUG - 2016-09-20 18:28:18 --> User Agent Class Initialized
DEBUG - 2016-09-20 18:28:18 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:18 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:18 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-20 18:28:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-20 18:28:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-20 18:28:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 18:28:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-20 18:28:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 18:28:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-20 18:28:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-20 18:28:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-20 18:28:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 18:28:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-20 18:28:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 18:28:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-20 18:28:18 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-09-20 18:28:18 --> Final output sent to browser
DEBUG - 2016-09-20 18:28:18 --> Total execution time: 1.2992
DEBUG - 2016-09-20 18:28:20 --> Config Class Initialized
DEBUG - 2016-09-20 18:28:20 --> Hooks Class Initialized
DEBUG - 2016-09-20 18:28:20 --> Utf8 Class Initialized
DEBUG - 2016-09-20 18:28:20 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 18:28:20 --> URI Class Initialized
DEBUG - 2016-09-20 18:28:20 --> Router Class Initialized
DEBUG - 2016-09-20 18:28:20 --> Output Class Initialized
DEBUG - 2016-09-20 18:28:20 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 18:28:20 --> Security Class Initialized
DEBUG - 2016-09-20 18:28:20 --> Input Class Initialized
DEBUG - 2016-09-20 18:28:20 --> XSS Filtering completed
DEBUG - 2016-09-20 18:28:20 --> XSS Filtering completed
DEBUG - 2016-09-20 18:28:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 18:28:20 --> Language Class Initialized
DEBUG - 2016-09-20 18:28:20 --> Loader Class Initialized
DEBUG - 2016-09-20 18:28:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 18:28:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 18:28:20 --> Helper loaded: url_helper
DEBUG - 2016-09-20 18:28:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 18:28:20 --> Helper loaded: file_helper
DEBUG - 2016-09-20 18:28:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 18:28:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 18:28:20 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 18:28:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 18:28:21 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 18:28:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 18:28:21 --> Helper loaded: common_helper
DEBUG - 2016-09-20 18:28:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 18:28:21 --> Helper loaded: common_helper
DEBUG - 2016-09-20 18:28:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 18:28:21 --> Helper loaded: form_helper
DEBUG - 2016-09-20 18:28:21 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 18:28:21 --> Helper loaded: security_helper
DEBUG - 2016-09-20 18:28:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 18:28:21 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 18:28:21 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 18:28:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 18:28:21 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 18:28:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 18:28:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 18:28:21 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 18:28:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 18:28:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 18:28:21 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 18:28:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 18:28:21 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 18:28:21 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 18:28:21 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 18:28:21 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 18:28:21 --> Database Driver Class Initialized
DEBUG - 2016-09-20 18:28:21 --> Session Class Initialized
DEBUG - 2016-09-20 18:28:21 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 18:28:21 --> Helper loaded: string_helper
DEBUG - 2016-09-20 18:28:21 --> Session routines successfully run
DEBUG - 2016-09-20 18:28:21 --> Native_session Class Initialized
DEBUG - 2016-09-20 18:28:21 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 18:28:21 --> Form Validation Class Initialized
DEBUG - 2016-09-20 18:28:21 --> Form Validation Class Initialized
DEBUG - 2016-09-20 18:28:21 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 18:28:21 --> Controller Class Initialized
DEBUG - 2016-09-20 18:28:21 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 18:28:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 18:28:21 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 18:28:21 --> Carabiner: library configured.
DEBUG - 2016-09-20 18:28:21 --> Carabiner: library configured.
DEBUG - 2016-09-20 18:28:21 --> User Agent Class Initialized
DEBUG - 2016-09-20 18:28:21 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:21 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:21 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:21 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:21 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:21 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:21 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:21 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:21 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-20 18:28:22 --> Pagination Class Initialized
DEBUG - 2016-09-20 18:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-20 18:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-20 18:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-20 18:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-20 18:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 18:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-20 18:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-20 18:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 18:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-20 18:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-20 18:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-20 18:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 18:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-20 18:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-20 18:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 18:28:22 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-20 18:28:22 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-20 18:28:22 --> Final output sent to browser
DEBUG - 2016-09-20 18:28:22 --> Total execution time: 1.4927
DEBUG - 2016-09-20 18:28:23 --> Config Class Initialized
DEBUG - 2016-09-20 18:28:23 --> Hooks Class Initialized
DEBUG - 2016-09-20 18:28:23 --> Utf8 Class Initialized
DEBUG - 2016-09-20 18:28:23 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 18:28:23 --> URI Class Initialized
DEBUG - 2016-09-20 18:28:24 --> Router Class Initialized
DEBUG - 2016-09-20 18:28:24 --> Output Class Initialized
DEBUG - 2016-09-20 18:28:24 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 18:28:24 --> Security Class Initialized
DEBUG - 2016-09-20 18:28:24 --> Input Class Initialized
DEBUG - 2016-09-20 18:28:24 --> XSS Filtering completed
DEBUG - 2016-09-20 18:28:24 --> XSS Filtering completed
DEBUG - 2016-09-20 18:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 18:28:24 --> Language Class Initialized
DEBUG - 2016-09-20 18:28:24 --> Loader Class Initialized
DEBUG - 2016-09-20 18:28:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 18:28:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 18:28:24 --> Helper loaded: url_helper
DEBUG - 2016-09-20 18:28:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 18:28:24 --> Helper loaded: file_helper
DEBUG - 2016-09-20 18:28:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 18:28:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 18:28:24 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 18:28:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 18:28:24 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 18:28:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 18:28:24 --> Helper loaded: common_helper
DEBUG - 2016-09-20 18:28:24 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 18:28:24 --> Helper loaded: common_helper
DEBUG - 2016-09-20 18:28:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 18:28:24 --> Helper loaded: form_helper
DEBUG - 2016-09-20 18:28:24 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 18:28:24 --> Helper loaded: security_helper
DEBUG - 2016-09-20 18:28:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 18:28:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 18:28:24 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 18:28:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 18:28:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 18:28:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 18:28:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 18:28:24 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 18:28:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 18:28:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 18:28:24 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 18:28:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 18:28:24 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 18:28:24 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 18:28:24 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 18:28:24 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 18:28:24 --> Database Driver Class Initialized
DEBUG - 2016-09-20 18:28:24 --> Session Class Initialized
DEBUG - 2016-09-20 18:28:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 18:28:24 --> Helper loaded: string_helper
DEBUG - 2016-09-20 18:28:24 --> Session routines successfully run
DEBUG - 2016-09-20 18:28:24 --> Native_session Class Initialized
DEBUG - 2016-09-20 18:28:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 18:28:25 --> Form Validation Class Initialized
DEBUG - 2016-09-20 18:28:25 --> Form Validation Class Initialized
DEBUG - 2016-09-20 18:28:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 18:28:25 --> Controller Class Initialized
DEBUG - 2016-09-20 18:28:25 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 18:28:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 18:28:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 18:28:25 --> Carabiner: library configured.
DEBUG - 2016-09-20 18:28:25 --> Carabiner: library configured.
DEBUG - 2016-09-20 18:28:25 --> User Agent Class Initialized
DEBUG - 2016-09-20 18:28:25 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:25 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:25 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:25 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:25 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:25 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:25 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:25 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:25 --> Model Class Initialized
DEBUG - 2016-09-20 18:28:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-20 18:28:25 --> Form Validation Class Initialized
DEBUG - 2016-09-20 18:28:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 18:28:25 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-20 18:28:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-20 18:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-20 18:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 18:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-20 18:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-09-20 18:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-09-20 18:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-09-20 18:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-09-20 18:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-09-20 18:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-09-20 18:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 18:28:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-20 18:28:26 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8f8e2926e3f1cbfc3aa536b43cdd0626
DEBUG - 2016-09-20 18:28:26 --> Final output sent to browser
DEBUG - 2016-09-20 18:28:26 --> Total execution time: 1.5598
DEBUG - 2016-09-20 18:29:13 --> Config Class Initialized
DEBUG - 2016-09-20 18:29:13 --> Hooks Class Initialized
DEBUG - 2016-09-20 18:29:13 --> Utf8 Class Initialized
DEBUG - 2016-09-20 18:29:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-20 18:29:13 --> URI Class Initialized
DEBUG - 2016-09-20 18:29:13 --> Router Class Initialized
DEBUG - 2016-09-20 18:29:13 --> Output Class Initialized
DEBUG - 2016-09-20 18:29:13 --> Cache file has expired. File deleted
DEBUG - 2016-09-20 18:29:13 --> Security Class Initialized
DEBUG - 2016-09-20 18:29:13 --> Input Class Initialized
DEBUG - 2016-09-20 18:29:13 --> XSS Filtering completed
DEBUG - 2016-09-20 18:29:13 --> XSS Filtering completed
DEBUG - 2016-09-20 18:29:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-20 18:29:13 --> Language Class Initialized
DEBUG - 2016-09-20 18:29:13 --> Loader Class Initialized
DEBUG - 2016-09-20 18:29:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-20 18:29:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-20 18:29:14 --> Helper loaded: url_helper
DEBUG - 2016-09-20 18:29:14 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-20 18:29:14 --> Helper loaded: file_helper
DEBUG - 2016-09-20 18:29:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 18:29:14 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-20 18:29:14 --> Helper loaded: conf_helper
DEBUG - 2016-09-20 18:29:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-20 18:29:14 --> Check Exists common_helper.php: No
DEBUG - 2016-09-20 18:29:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-20 18:29:14 --> Helper loaded: common_helper
DEBUG - 2016-09-20 18:29:14 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-20 18:29:14 --> Helper loaded: common_helper
DEBUG - 2016-09-20 18:29:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-20 18:29:14 --> Helper loaded: form_helper
DEBUG - 2016-09-20 18:29:14 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-20 18:29:14 --> Helper loaded: security_helper
DEBUG - 2016-09-20 18:29:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 18:29:14 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-20 18:29:14 --> Helper loaded: lang_helper
DEBUG - 2016-09-20 18:29:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-20 18:29:14 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-20 18:29:14 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-20 18:29:14 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-20 18:29:14 --> Helper loaded: atlant_helper
DEBUG - 2016-09-20 18:29:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 18:29:14 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-20 18:29:14 --> Helper loaded: crypto_helper
DEBUG - 2016-09-20 18:29:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-20 18:29:14 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-20 18:29:14 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-20 18:29:14 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-20 18:29:14 --> Helper loaded: sidika_helper
DEBUG - 2016-09-20 18:29:14 --> Database Driver Class Initialized
DEBUG - 2016-09-20 18:29:14 --> Session Class Initialized
DEBUG - 2016-09-20 18:29:14 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-20 18:29:14 --> Helper loaded: string_helper
DEBUG - 2016-09-20 18:29:14 --> Session routines successfully run
DEBUG - 2016-09-20 18:29:14 --> Native_session Class Initialized
DEBUG - 2016-09-20 18:29:14 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-20 18:29:14 --> Form Validation Class Initialized
DEBUG - 2016-09-20 18:29:14 --> Form Validation Class Initialized
DEBUG - 2016-09-20 18:29:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-20 18:29:14 --> Controller Class Initialized
DEBUG - 2016-09-20 18:29:14 --> Carabiner: Library initialized.
DEBUG - 2016-09-20 18:29:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-20 18:29:14 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-20 18:29:14 --> Carabiner: library configured.
DEBUG - 2016-09-20 18:29:14 --> Carabiner: library configured.
DEBUG - 2016-09-20 18:29:14 --> User Agent Class Initialized
DEBUG - 2016-09-20 18:29:14 --> Model Class Initialized
DEBUG - 2016-09-20 18:29:14 --> Model Class Initialized
DEBUG - 2016-09-20 18:29:14 --> Model Class Initialized
DEBUG - 2016-09-20 18:29:15 --> Model Class Initialized
DEBUG - 2016-09-20 18:29:15 --> Model Class Initialized
DEBUG - 2016-09-20 18:29:15 --> Model Class Initialized
DEBUG - 2016-09-20 18:29:15 --> Model Class Initialized
DEBUG - 2016-09-20 18:29:15 --> Model Class Initialized
DEBUG - 2016-09-20 18:29:15 --> Model Class Initialized
DEBUG - 2016-09-20 18:29:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-20 18:29:15 --> Pagination Class Initialized
DEBUG - 2016-09-20 18:29:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-20 18:29:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-20 18:29:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-20 18:29:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-20 18:29:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 18:29:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-20 18:29:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-20 18:29:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 18:29:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-20 18:29:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-20 18:29:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-20 18:29:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-20 18:29:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-20 18:29:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-20 18:29:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-20 18:29:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-20 18:29:15 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-20 18:29:15 --> Final output sent to browser
DEBUG - 2016-09-20 18:29:15 --> Total execution time: 1.5419
