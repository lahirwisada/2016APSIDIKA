<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-09-06 09:03:48 --> Config Class Initialized
DEBUG - 2016-09-06 09:03:48 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:03:48 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:03:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:03:48 --> URI Class Initialized
DEBUG - 2016-09-06 09:03:48 --> Router Class Initialized
DEBUG - 2016-09-06 09:03:48 --> No URI present. Default controller set.
DEBUG - 2016-09-06 09:03:48 --> Output Class Initialized
DEBUG - 2016-09-06 09:03:48 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 09:03:48 --> Security Class Initialized
DEBUG - 2016-09-06 09:03:48 --> Input Class Initialized
DEBUG - 2016-09-06 09:03:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:03:48 --> Language Class Initialized
DEBUG - 2016-09-06 09:03:48 --> Loader Class Initialized
DEBUG - 2016-09-06 09:03:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:03:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:03:48 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:03:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:03:48 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:03:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:03:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:03:48 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:03:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:03:48 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:03:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:03:48 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:03:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:03:48 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:03:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:03:48 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:03:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:03:48 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:03:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:03:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:03:48 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:03:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:03:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:03:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:03:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:03:48 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:03:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:03:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:03:48 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:03:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:03:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:03:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:03:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:03:48 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:03:48 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:03:49 --> Session Class Initialized
DEBUG - 2016-09-06 09:03:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:03:49 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:03:49 --> A session cookie was not found.
DEBUG - 2016-09-06 09:03:49 --> Session routines successfully run
DEBUG - 2016-09-06 09:03:49 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:03:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:03:49 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:03:49 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:03:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:03:49 --> Controller Class Initialized
DEBUG - 2016-09-06 09:03:49 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:03:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:03:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:03:49 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:03:49 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:03:49 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:03:49 --> Model Class Initialized
DEBUG - 2016-09-06 09:03:49 --> Model Class Initialized
DEBUG - 2016-09-06 09:03:49 --> Model Class Initialized
DEBUG - 2016-09-06 09:03:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-06 09:03:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 09:03:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 09:03:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:03:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 09:03:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 09:03:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 09:03:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 09:03:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 09:03:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:03:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 09:03:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 09:03:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 09:03:50 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-06 09:03:50 --> Final output sent to browser
DEBUG - 2016-09-06 09:03:50 --> Total execution time: 1.7963
DEBUG - 2016-09-06 09:03:53 --> Config Class Initialized
DEBUG - 2016-09-06 09:03:53 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:03:53 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:03:53 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:03:53 --> URI Class Initialized
DEBUG - 2016-09-06 09:03:53 --> Router Class Initialized
DEBUG - 2016-09-06 09:03:53 --> Output Class Initialized
DEBUG - 2016-09-06 09:03:53 --> Security Class Initialized
DEBUG - 2016-09-06 09:03:53 --> Input Class Initialized
DEBUG - 2016-09-06 09:03:53 --> XSS Filtering completed
DEBUG - 2016-09-06 09:03:53 --> XSS Filtering completed
DEBUG - 2016-09-06 09:03:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:03:53 --> Language Class Initialized
DEBUG - 2016-09-06 09:03:53 --> Loader Class Initialized
DEBUG - 2016-09-06 09:03:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:03:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:03:53 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:03:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:03:53 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:03:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:03:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:03:53 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:03:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:03:53 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:03:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:03:53 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:03:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:03:54 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:03:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:03:54 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:03:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:03:54 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:03:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:03:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:03:54 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:03:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:03:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:03:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:03:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:03:54 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:03:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:03:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:03:54 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:03:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:03:54 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:03:54 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:03:54 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:03:54 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:03:54 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:03:54 --> Session Class Initialized
DEBUG - 2016-09-06 09:03:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:03:54 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:03:54 --> Session routines successfully run
DEBUG - 2016-09-06 09:03:54 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:03:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:03:54 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:03:54 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:03:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:03:54 --> Controller Class Initialized
DEBUG - 2016-09-06 09:03:54 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:03:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:03:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:03:54 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:03:54 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:03:54 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:03:54 --> Model Class Initialized
DEBUG - 2016-09-06 09:03:54 --> Model Class Initialized
DEBUG - 2016-09-06 09:03:54 --> Model Class Initialized
DEBUG - 2016-09-06 09:03:54 --> Model Class Initialized
DEBUG - 2016-09-06 09:03:54 --> Model Class Initialized
DEBUG - 2016-09-06 09:03:54 --> Model Class Initialized
DEBUG - 2016-09-06 09:03:54 --> Model Class Initialized
DEBUG - 2016-09-06 09:03:54 --> Model Class Initialized
ERROR - 2016-09-06 09:03:54 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 09:03:54 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 09:03:54 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-09-06 09:03:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-06 09:03:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-06 09:03:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-06 09:03:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-06 09:03:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-09-06 09:03:54 --> Final output sent to browser
DEBUG - 2016-09-06 09:03:54 --> Total execution time: 0.9904
DEBUG - 2016-09-06 09:03:55 --> Config Class Initialized
DEBUG - 2016-09-06 09:03:55 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:03:55 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:03:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:03:55 --> URI Class Initialized
DEBUG - 2016-09-06 09:03:55 --> Router Class Initialized
ERROR - 2016-09-06 09:03:55 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-09-06 09:04:00 --> Config Class Initialized
DEBUG - 2016-09-06 09:04:00 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:04:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:04:01 --> URI Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Router Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Output Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 09:04:01 --> Security Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Input Class Initialized
DEBUG - 2016-09-06 09:04:01 --> XSS Filtering completed
DEBUG - 2016-09-06 09:04:01 --> XSS Filtering completed
DEBUG - 2016-09-06 09:04:01 --> XSS Filtering completed
DEBUG - 2016-09-06 09:04:01 --> XSS Filtering completed
DEBUG - 2016-09-06 09:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:04:01 --> Language Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Loader Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:04:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:04:01 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:04:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:04:01 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:04:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:04:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:04:01 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:04:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:04:01 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:04:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:04:01 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:04:01 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:04:01 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:04:01 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:04:01 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:04:01 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:04:01 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:04:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:04:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:04:01 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:04:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:04:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:04:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:04:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:04:01 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:04:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:04:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:04:01 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:04:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:04:01 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:04:01 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:04:01 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:04:01 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:04:01 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Session Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:04:01 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:04:01 --> Session routines successfully run
DEBUG - 2016-09-06 09:04:01 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:04:01 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:04:01 --> Controller Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:04:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:04:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:04:01 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:04:01 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:04:01 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Model Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Model Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Model Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Model Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Model Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Model Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Model Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Model Class Initialized
ERROR - 2016-09-06 09:04:01 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 09:04:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-06 09:04:01 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:04:01 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-06 09:04:01 --> Config Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:04:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:04:01 --> URI Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Router Class Initialized
DEBUG - 2016-09-06 09:04:01 --> No URI present. Default controller set.
DEBUG - 2016-09-06 09:04:01 --> Output Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 09:04:01 --> Security Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Input Class Initialized
DEBUG - 2016-09-06 09:04:01 --> XSS Filtering completed
DEBUG - 2016-09-06 09:04:01 --> XSS Filtering completed
DEBUG - 2016-09-06 09:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:04:01 --> Language Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Loader Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:04:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:04:01 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:04:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:04:01 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:04:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:04:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:04:01 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:04:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:04:01 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:04:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:04:01 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:04:01 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:04:01 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:04:01 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:04:01 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:04:01 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:04:01 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:04:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:04:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:04:01 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:04:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:04:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:04:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:04:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:04:01 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:04:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:04:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:04:01 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:04:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:04:01 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:04:01 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:04:01 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:04:01 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:04:01 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Session Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:04:01 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:04:01 --> Session routines successfully run
DEBUG - 2016-09-06 09:04:01 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:04:01 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:04:01 --> Controller Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:04:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:04:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:04:01 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:04:01 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:04:01 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Model Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Model Class Initialized
DEBUG - 2016-09-06 09:04:01 --> Model Class Initialized
DEBUG - 2016-09-06 09:04:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-06 09:04:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 09:04:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 09:04:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:04:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 09:04:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 09:04:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 09:04:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 09:04:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 09:04:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:04:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 09:04:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 09:04:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 09:04:01 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-06 09:04:01 --> Final output sent to browser
DEBUG - 2016-09-06 09:04:01 --> Total execution time: 0.2524
DEBUG - 2016-09-06 09:04:19 --> Config Class Initialized
DEBUG - 2016-09-06 09:04:19 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:04:19 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:04:19 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:04:19 --> URI Class Initialized
DEBUG - 2016-09-06 09:04:19 --> Router Class Initialized
DEBUG - 2016-09-06 09:04:19 --> Output Class Initialized
DEBUG - 2016-09-06 09:04:19 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 09:04:19 --> Security Class Initialized
DEBUG - 2016-09-06 09:04:19 --> Input Class Initialized
DEBUG - 2016-09-06 09:04:19 --> XSS Filtering completed
DEBUG - 2016-09-06 09:04:19 --> XSS Filtering completed
DEBUG - 2016-09-06 09:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:04:19 --> Language Class Initialized
DEBUG - 2016-09-06 09:04:19 --> Loader Class Initialized
DEBUG - 2016-09-06 09:04:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:04:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:04:19 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:04:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:04:19 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:04:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:04:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:04:19 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:04:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:04:19 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:04:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:04:19 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:04:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:04:19 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:04:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:04:19 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:04:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:04:19 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:04:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:04:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:04:19 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:04:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:04:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:04:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:04:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:04:19 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:04:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:04:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:04:19 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:04:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:04:19 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:04:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:04:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:04:19 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:04:19 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:04:19 --> Session Class Initialized
DEBUG - 2016-09-06 09:04:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:04:19 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:04:19 --> Session routines successfully run
DEBUG - 2016-09-06 09:04:19 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:04:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:04:19 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:04:19 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:04:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:04:19 --> Controller Class Initialized
DEBUG - 2016-09-06 09:04:19 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:04:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:04:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:04:19 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:04:19 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:04:19 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:04:19 --> Model Class Initialized
DEBUG - 2016-09-06 09:04:19 --> Model Class Initialized
DEBUG - 2016-09-06 09:04:19 --> Model Class Initialized
DEBUG - 2016-09-06 09:04:19 --> Model Class Initialized
DEBUG - 2016-09-06 09:04:19 --> Model Class Initialized
DEBUG - 2016-09-06 09:04:19 --> Model Class Initialized
DEBUG - 2016-09-06 09:04:19 --> Model Class Initialized
DEBUG - 2016-09-06 09:04:19 --> Model Class Initialized
DEBUG - 2016-09-06 09:04:19 --> Model Class Initialized
DEBUG - 2016-09-06 09:04:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-06 09:04:20 --> Pagination Class Initialized
DEBUG - 2016-09-06 09:04:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-06 09:04:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-06 09:04:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 09:04:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 09:04:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:04:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 09:04:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-06 09:04:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 09:04:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 09:04:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 09:04:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 09:04:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:04:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 09:04:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-06 09:04:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 09:04:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 09:04:20 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-06 09:04:20 --> Final output sent to browser
DEBUG - 2016-09-06 09:04:20 --> Total execution time: 1.1029
DEBUG - 2016-09-06 09:05:50 --> Config Class Initialized
DEBUG - 2016-09-06 09:05:50 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:05:50 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:05:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:05:50 --> URI Class Initialized
DEBUG - 2016-09-06 09:05:50 --> Router Class Initialized
DEBUG - 2016-09-06 09:05:50 --> Output Class Initialized
DEBUG - 2016-09-06 09:05:50 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 09:05:50 --> Security Class Initialized
DEBUG - 2016-09-06 09:05:50 --> Input Class Initialized
DEBUG - 2016-09-06 09:05:50 --> XSS Filtering completed
DEBUG - 2016-09-06 09:05:50 --> XSS Filtering completed
DEBUG - 2016-09-06 09:05:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:05:50 --> Language Class Initialized
DEBUG - 2016-09-06 09:05:50 --> Loader Class Initialized
DEBUG - 2016-09-06 09:05:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:05:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:05:50 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:05:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:05:50 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:05:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:05:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:05:50 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:05:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:05:50 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:05:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:05:50 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:05:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:05:50 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:05:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:05:50 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:05:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:05:50 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:05:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:05:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:05:50 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:05:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:05:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:05:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:05:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:05:50 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:05:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:05:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:05:50 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:05:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:05:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:05:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:05:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:05:50 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:05:50 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:05:50 --> Session Class Initialized
DEBUG - 2016-09-06 09:05:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:05:50 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:05:50 --> Session routines successfully run
DEBUG - 2016-09-06 09:05:50 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:05:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:05:50 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:05:50 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:05:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:05:50 --> Controller Class Initialized
DEBUG - 2016-09-06 09:05:50 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:05:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:05:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:05:50 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:05:50 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:05:50 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:05:50 --> Model Class Initialized
DEBUG - 2016-09-06 09:05:50 --> Model Class Initialized
DEBUG - 2016-09-06 09:05:50 --> Model Class Initialized
DEBUG - 2016-09-06 09:05:50 --> Model Class Initialized
DEBUG - 2016-09-06 09:05:50 --> Model Class Initialized
DEBUG - 2016-09-06 09:05:50 --> Model Class Initialized
DEBUG - 2016-09-06 09:05:50 --> Model Class Initialized
DEBUG - 2016-09-06 09:05:50 --> Model Class Initialized
DEBUG - 2016-09-06 09:05:50 --> Model Class Initialized
DEBUG - 2016-09-06 09:05:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-06 09:05:50 --> Pagination Class Initialized
DEBUG - 2016-09-06 09:05:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-06 09:05:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-06 09:05:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 09:05:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 09:05:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:05:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 09:05:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-06 09:05:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 09:05:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 09:05:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 09:05:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 09:05:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:05:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 09:05:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-06 09:05:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 09:05:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 09:05:50 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-06 09:05:50 --> Final output sent to browser
DEBUG - 2016-09-06 09:05:50 --> Total execution time: 0.3925
DEBUG - 2016-09-06 09:05:57 --> Config Class Initialized
DEBUG - 2016-09-06 09:05:57 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:05:57 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:05:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:05:57 --> URI Class Initialized
DEBUG - 2016-09-06 09:05:57 --> Router Class Initialized
DEBUG - 2016-09-06 09:05:57 --> Output Class Initialized
DEBUG - 2016-09-06 09:05:57 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 09:05:57 --> Security Class Initialized
DEBUG - 2016-09-06 09:05:57 --> Input Class Initialized
DEBUG - 2016-09-06 09:05:57 --> XSS Filtering completed
DEBUG - 2016-09-06 09:05:57 --> XSS Filtering completed
DEBUG - 2016-09-06 09:05:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:05:57 --> Language Class Initialized
DEBUG - 2016-09-06 09:05:57 --> Loader Class Initialized
DEBUG - 2016-09-06 09:05:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:05:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:05:57 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:05:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:05:57 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:05:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:05:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:05:57 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:05:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:05:57 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:05:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:05:57 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:05:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:05:57 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:05:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:05:57 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:05:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:05:57 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:05:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:05:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:05:57 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:05:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:05:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:05:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:05:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:05:57 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:05:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:05:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:05:57 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:05:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:05:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:05:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:05:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:05:57 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:05:57 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:05:57 --> Session Class Initialized
DEBUG - 2016-09-06 09:05:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:05:57 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:05:57 --> Session routines successfully run
DEBUG - 2016-09-06 09:05:57 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:05:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:05:57 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:05:57 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:05:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:05:57 --> Controller Class Initialized
DEBUG - 2016-09-06 09:05:57 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:05:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:05:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:05:57 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:05:57 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:05:57 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:05:57 --> Model Class Initialized
DEBUG - 2016-09-06 09:05:57 --> Model Class Initialized
DEBUG - 2016-09-06 09:05:57 --> Model Class Initialized
ERROR - 2016-09-06 09:05:57 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 09:05:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-06 09:05:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:05:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 09:05:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 09:05:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 09:05:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:05:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 09:05:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 09:05:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 09:05:57 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-06 09:05:57 --> Final output sent to browser
DEBUG - 2016-09-06 09:05:57 --> Total execution time: 0.3710
DEBUG - 2016-09-06 09:09:57 --> Config Class Initialized
DEBUG - 2016-09-06 09:09:57 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:09:57 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:09:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:09:57 --> URI Class Initialized
DEBUG - 2016-09-06 09:09:57 --> Router Class Initialized
DEBUG - 2016-09-06 09:09:57 --> Output Class Initialized
DEBUG - 2016-09-06 09:09:57 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 09:09:57 --> Security Class Initialized
DEBUG - 2016-09-06 09:09:57 --> Input Class Initialized
DEBUG - 2016-09-06 09:09:57 --> XSS Filtering completed
DEBUG - 2016-09-06 09:09:57 --> XSS Filtering completed
DEBUG - 2016-09-06 09:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:09:57 --> Language Class Initialized
DEBUG - 2016-09-06 09:09:57 --> Loader Class Initialized
DEBUG - 2016-09-06 09:09:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:09:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:09:57 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:09:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:09:57 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:09:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:09:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:09:57 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:09:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:09:57 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:09:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:09:57 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:09:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:09:57 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:09:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:09:57 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:09:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:09:57 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:09:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:09:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:09:57 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:09:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:09:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:09:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:09:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:09:58 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:09:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:09:58 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:09:58 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:09:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:09:58 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:09:58 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:09:58 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:09:58 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:09:58 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:09:58 --> Session Class Initialized
DEBUG - 2016-09-06 09:09:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:09:58 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:09:58 --> Session routines successfully run
DEBUG - 2016-09-06 09:09:58 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:09:58 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:09:58 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:09:58 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:09:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:09:58 --> Controller Class Initialized
DEBUG - 2016-09-06 09:09:58 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:09:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:09:58 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:09:58 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:09:58 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:09:58 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:09:58 --> Model Class Initialized
DEBUG - 2016-09-06 09:09:58 --> Model Class Initialized
DEBUG - 2016-09-06 09:09:58 --> Model Class Initialized
ERROR - 2016-09-06 09:09:58 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 09:09:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-06 09:09:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 09:09:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:09:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 09:09:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 09:09:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 09:09:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 09:09:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:09:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 09:09:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 09:09:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 09:09:58 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-06 09:09:58 --> Final output sent to browser
DEBUG - 2016-09-06 09:09:58 --> Total execution time: 0.3551
DEBUG - 2016-09-06 09:10:01 --> Config Class Initialized
DEBUG - 2016-09-06 09:10:01 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:10:01 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:10:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:10:01 --> URI Class Initialized
DEBUG - 2016-09-06 09:10:01 --> Router Class Initialized
ERROR - 2016-09-06 09:10:01 --> 404 Page Not Found --> cdaftar_diklat
DEBUG - 2016-09-06 09:10:15 --> Config Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:10:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:10:15 --> URI Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Router Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Output Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Security Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Input Class Initialized
DEBUG - 2016-09-06 09:10:15 --> XSS Filtering completed
DEBUG - 2016-09-06 09:10:15 --> XSS Filtering completed
DEBUG - 2016-09-06 09:10:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:10:15 --> Language Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Loader Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:10:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:10:15 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:10:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:10:15 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:10:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:10:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:10:15 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:10:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:10:15 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:10:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:10:15 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:10:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:10:15 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:10:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:10:15 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:10:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:10:15 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:10:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:10:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:10:15 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:10:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:10:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:10:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:10:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:10:15 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:10:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:10:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:10:15 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:10:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:10:15 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:10:15 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:10:15 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:10:15 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:10:15 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Session Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:10:15 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:10:15 --> Session routines successfully run
DEBUG - 2016-09-06 09:10:15 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:10:15 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:10:15 --> Controller Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:10:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:10:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:10:15 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:10:15 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:10:15 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Config Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:10:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:10:15 --> URI Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Router Class Initialized
DEBUG - 2016-09-06 09:10:15 --> No URI present. Default controller set.
DEBUG - 2016-09-06 09:10:15 --> Output Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 09:10:15 --> Security Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Input Class Initialized
DEBUG - 2016-09-06 09:10:15 --> XSS Filtering completed
DEBUG - 2016-09-06 09:10:15 --> XSS Filtering completed
DEBUG - 2016-09-06 09:10:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:10:15 --> Language Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Loader Class Initialized
DEBUG - 2016-09-06 09:10:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:10:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:10:15 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:10:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:10:15 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:10:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:10:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:10:15 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:10:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:10:15 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:10:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:10:15 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:10:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:10:15 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:10:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:10:15 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:10:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:10:15 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:10:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:10:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:10:15 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:10:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:10:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:10:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:10:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:10:15 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:10:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:10:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:10:15 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:10:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:10:15 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:10:15 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:10:15 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:10:15 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:10:15 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:10:16 --> Session Class Initialized
DEBUG - 2016-09-06 09:10:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:10:16 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:10:16 --> Session routines successfully run
DEBUG - 2016-09-06 09:10:16 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:10:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:10:16 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:10:16 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:10:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:10:16 --> Controller Class Initialized
DEBUG - 2016-09-06 09:10:16 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:10:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:10:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:10:16 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:10:16 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:10:16 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:10:16 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:16 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:16 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-06 09:10:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 09:10:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 09:10:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:10:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 09:10:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 09:10:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 09:10:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 09:10:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 09:10:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:10:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 09:10:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 09:10:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 09:10:16 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-06 09:10:16 --> Final output sent to browser
DEBUG - 2016-09-06 09:10:16 --> Total execution time: 0.3674
DEBUG - 2016-09-06 09:10:17 --> Config Class Initialized
DEBUG - 2016-09-06 09:10:17 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:10:17 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:10:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:10:17 --> URI Class Initialized
DEBUG - 2016-09-06 09:10:17 --> Router Class Initialized
DEBUG - 2016-09-06 09:10:17 --> Output Class Initialized
DEBUG - 2016-09-06 09:10:17 --> Security Class Initialized
DEBUG - 2016-09-06 09:10:17 --> Input Class Initialized
DEBUG - 2016-09-06 09:10:17 --> XSS Filtering completed
DEBUG - 2016-09-06 09:10:17 --> XSS Filtering completed
DEBUG - 2016-09-06 09:10:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:10:17 --> Language Class Initialized
DEBUG - 2016-09-06 09:10:17 --> Loader Class Initialized
DEBUG - 2016-09-06 09:10:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:10:17 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:10:17 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:10:17 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:10:17 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:10:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:10:17 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:10:17 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:10:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:10:17 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:10:17 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:10:17 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:10:17 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:10:17 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:10:17 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:10:17 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:10:17 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:10:17 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:10:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:10:17 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:10:18 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:10:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:10:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:10:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:10:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:10:18 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:10:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:10:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:10:18 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:10:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:10:18 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:10:18 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:10:18 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:10:18 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:10:18 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:10:18 --> Session Class Initialized
DEBUG - 2016-09-06 09:10:18 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:10:18 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:10:18 --> Session routines successfully run
DEBUG - 2016-09-06 09:10:18 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:10:18 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:10:18 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:10:18 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:10:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:10:18 --> Controller Class Initialized
DEBUG - 2016-09-06 09:10:18 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:10:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:10:18 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:10:18 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:10:18 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:10:18 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:10:18 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:18 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:18 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:18 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:18 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:18 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:18 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:18 --> Model Class Initialized
ERROR - 2016-09-06 09:10:18 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 09:10:18 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 09:10:18 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-09-06 09:10:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-06 09:10:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-06 09:10:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-06 09:10:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-06 09:10:18 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-09-06 09:10:18 --> Final output sent to browser
DEBUG - 2016-09-06 09:10:18 --> Total execution time: 0.4367
DEBUG - 2016-09-06 09:10:18 --> Config Class Initialized
DEBUG - 2016-09-06 09:10:18 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:10:18 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:10:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:10:18 --> URI Class Initialized
DEBUG - 2016-09-06 09:10:18 --> Router Class Initialized
ERROR - 2016-09-06 09:10:18 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-09-06 09:10:34 --> Config Class Initialized
DEBUG - 2016-09-06 09:10:34 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:10:34 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:10:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:10:34 --> URI Class Initialized
DEBUG - 2016-09-06 09:10:34 --> Router Class Initialized
DEBUG - 2016-09-06 09:10:34 --> Output Class Initialized
DEBUG - 2016-09-06 09:10:34 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 09:10:34 --> Security Class Initialized
DEBUG - 2016-09-06 09:10:34 --> Input Class Initialized
DEBUG - 2016-09-06 09:10:34 --> XSS Filtering completed
DEBUG - 2016-09-06 09:10:34 --> XSS Filtering completed
DEBUG - 2016-09-06 09:10:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:10:34 --> Language Class Initialized
DEBUG - 2016-09-06 09:10:34 --> Loader Class Initialized
DEBUG - 2016-09-06 09:10:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:10:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:10:34 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:10:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:10:34 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:10:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:10:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:10:34 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:10:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:10:34 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:10:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:10:34 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:10:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:10:34 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:10:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:10:34 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:10:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:10:34 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:10:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:10:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:10:34 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:10:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:10:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:10:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:10:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:10:34 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:10:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:10:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:10:34 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:10:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:10:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:10:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:10:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:10:34 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:10:34 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:10:34 --> Session Class Initialized
DEBUG - 2016-09-06 09:10:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:10:34 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:10:34 --> Session routines successfully run
DEBUG - 2016-09-06 09:10:34 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:10:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:10:34 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:10:34 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:10:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:10:34 --> Controller Class Initialized
DEBUG - 2016-09-06 09:10:34 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:10:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:10:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:10:34 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:10:34 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:10:34 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:10:34 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:34 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:34 --> Model Class Initialized
ERROR - 2016-09-06 09:10:34 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 09:10:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-06 09:10:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 09:10:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:10:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 09:10:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 09:10:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 09:10:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 09:10:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:10:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 09:10:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 09:10:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 09:10:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-06 09:10:34 --> Final output sent to browser
DEBUG - 2016-09-06 09:10:34 --> Total execution time: 0.4329
DEBUG - 2016-09-06 09:10:36 --> Config Class Initialized
DEBUG - 2016-09-06 09:10:36 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:10:36 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:10:36 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:10:36 --> URI Class Initialized
DEBUG - 2016-09-06 09:10:36 --> Router Class Initialized
DEBUG - 2016-09-06 09:10:36 --> Output Class Initialized
DEBUG - 2016-09-06 09:10:36 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 09:10:36 --> Security Class Initialized
DEBUG - 2016-09-06 09:10:36 --> Input Class Initialized
DEBUG - 2016-09-06 09:10:36 --> XSS Filtering completed
DEBUG - 2016-09-06 09:10:36 --> XSS Filtering completed
DEBUG - 2016-09-06 09:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:10:36 --> Language Class Initialized
DEBUG - 2016-09-06 09:10:36 --> Loader Class Initialized
DEBUG - 2016-09-06 09:10:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:10:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:10:36 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:10:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:10:36 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:10:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:10:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:10:36 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:10:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:10:36 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:10:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:10:36 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:10:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:10:36 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:10:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:10:36 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:10:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:10:36 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:10:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:10:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:10:36 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:10:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:10:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:10:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:10:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:10:36 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:10:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:10:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:10:36 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:10:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:10:37 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:10:37 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:10:37 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:10:37 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:10:37 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:10:37 --> Session Class Initialized
DEBUG - 2016-09-06 09:10:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:10:37 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:10:37 --> Session routines successfully run
DEBUG - 2016-09-06 09:10:37 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:10:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:10:37 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:10:37 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:10:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:10:37 --> Controller Class Initialized
DEBUG - 2016-09-06 09:10:37 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:10:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:10:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:10:37 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:10:37 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:10:37 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:10:37 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:37 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:37 --> Model Class Initialized
ERROR - 2016-09-06 09:10:37 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 09:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-06 09:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 09:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 09:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 09:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 09:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 09:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 09:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 09:10:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 09:10:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-06 09:10:37 --> Final output sent to browser
DEBUG - 2016-09-06 09:10:37 --> Total execution time: 0.4512
DEBUG - 2016-09-06 09:10:39 --> Config Class Initialized
DEBUG - 2016-09-06 09:10:39 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:10:39 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:10:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:10:39 --> URI Class Initialized
DEBUG - 2016-09-06 09:10:39 --> Router Class Initialized
DEBUG - 2016-09-06 09:10:39 --> Output Class Initialized
DEBUG - 2016-09-06 09:10:39 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 09:10:39 --> Security Class Initialized
DEBUG - 2016-09-06 09:10:39 --> Input Class Initialized
DEBUG - 2016-09-06 09:10:39 --> XSS Filtering completed
DEBUG - 2016-09-06 09:10:39 --> XSS Filtering completed
DEBUG - 2016-09-06 09:10:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:10:39 --> Language Class Initialized
DEBUG - 2016-09-06 09:10:39 --> Loader Class Initialized
DEBUG - 2016-09-06 09:10:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:10:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:10:39 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:10:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:10:40 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:10:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:10:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:10:40 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:10:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:10:40 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:10:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:10:40 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:10:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:10:40 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:10:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:10:40 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:10:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:10:40 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:10:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:10:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:10:40 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:10:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:10:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:10:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:10:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:10:40 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:10:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:10:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:10:40 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:10:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:10:40 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:10:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:10:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:10:40 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:10:40 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:10:40 --> Session Class Initialized
DEBUG - 2016-09-06 09:10:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:10:40 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:10:40 --> Session routines successfully run
DEBUG - 2016-09-06 09:10:40 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:10:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:10:40 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:10:40 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:10:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:10:40 --> Controller Class Initialized
DEBUG - 2016-09-06 09:10:40 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:10:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:10:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:10:40 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:10:40 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:10:40 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:10:40 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:40 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:40 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:40 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:40 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:40 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:40 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:40 --> Model Class Initialized
ERROR - 2016-09-06 09:10:40 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 09:10:40 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 09:10:40 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-09-06 09:10:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-06 09:10:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-06 09:10:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-06 09:10:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-06 09:10:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-09-06 09:10:40 --> Final output sent to browser
DEBUG - 2016-09-06 09:10:40 --> Total execution time: 0.5126
DEBUG - 2016-09-06 09:10:40 --> Config Class Initialized
DEBUG - 2016-09-06 09:10:40 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:10:40 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:10:40 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:10:40 --> URI Class Initialized
DEBUG - 2016-09-06 09:10:40 --> Router Class Initialized
ERROR - 2016-09-06 09:10:40 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-09-06 09:10:48 --> Config Class Initialized
DEBUG - 2016-09-06 09:10:48 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:10:48 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:10:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:10:48 --> URI Class Initialized
DEBUG - 2016-09-06 09:10:48 --> Router Class Initialized
DEBUG - 2016-09-06 09:10:48 --> Output Class Initialized
DEBUG - 2016-09-06 09:10:48 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 09:10:48 --> Security Class Initialized
DEBUG - 2016-09-06 09:10:48 --> Input Class Initialized
DEBUG - 2016-09-06 09:10:48 --> XSS Filtering completed
DEBUG - 2016-09-06 09:10:48 --> XSS Filtering completed
DEBUG - 2016-09-06 09:10:48 --> XSS Filtering completed
DEBUG - 2016-09-06 09:10:48 --> XSS Filtering completed
DEBUG - 2016-09-06 09:10:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:10:48 --> Language Class Initialized
DEBUG - 2016-09-06 09:10:48 --> Loader Class Initialized
DEBUG - 2016-09-06 09:10:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:10:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:10:48 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:10:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:10:48 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:10:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:10:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:10:48 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:10:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:10:48 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:10:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:10:48 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:10:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:10:48 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:10:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:10:49 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:10:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:10:49 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:10:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:10:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:10:49 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:10:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:10:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:10:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:10:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:10:49 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:10:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:10:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:10:49 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:10:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:10:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:10:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:10:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:10:49 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:10:49 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:10:49 --> Session Class Initialized
DEBUG - 2016-09-06 09:10:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:10:49 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:10:49 --> Session routines successfully run
DEBUG - 2016-09-06 09:10:49 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:10:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:10:49 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:10:49 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:10:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:10:49 --> Controller Class Initialized
DEBUG - 2016-09-06 09:10:49 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:10:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:10:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:10:49 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:10:49 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:10:49 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:10:49 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:49 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:49 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:49 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:49 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:49 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:49 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:49 --> Model Class Initialized
ERROR - 2016-09-06 09:10:49 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 09:10:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-06 09:10:49 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:10:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:10:49 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-06 09:10:49 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 09:10:49 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-09-06 09:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-06 09:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-06 09:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-06 09:10:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-06 09:10:49 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-09-06 09:10:49 --> Final output sent to browser
DEBUG - 2016-09-06 09:10:49 --> Total execution time: 0.6413
DEBUG - 2016-09-06 09:10:54 --> Config Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:10:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:10:54 --> URI Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Router Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Output Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 09:10:54 --> Security Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Input Class Initialized
DEBUG - 2016-09-06 09:10:54 --> XSS Filtering completed
DEBUG - 2016-09-06 09:10:54 --> XSS Filtering completed
DEBUG - 2016-09-06 09:10:54 --> XSS Filtering completed
DEBUG - 2016-09-06 09:10:54 --> XSS Filtering completed
DEBUG - 2016-09-06 09:10:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:10:54 --> Language Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Loader Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:10:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:10:54 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:10:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:10:54 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:10:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:10:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:10:54 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:10:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:10:54 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:10:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:10:54 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:10:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:10:54 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:10:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:10:54 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:10:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:10:54 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:10:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:10:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:10:54 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:10:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:10:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:10:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:10:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:10:54 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:10:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:10:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:10:54 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:10:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:10:54 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:10:54 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:10:54 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:10:54 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:10:54 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Session Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:10:54 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:10:54 --> Session routines successfully run
DEBUG - 2016-09-06 09:10:54 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:10:54 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:10:54 --> Controller Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:10:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:10:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:10:54 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:10:54 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:10:54 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Model Class Initialized
ERROR - 2016-09-06 09:10:54 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 09:10:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-06 09:10:54 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:10:54 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-06 09:10:54 --> Config Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:10:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:10:54 --> URI Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Router Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Output Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 09:10:54 --> Security Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Input Class Initialized
DEBUG - 2016-09-06 09:10:54 --> XSS Filtering completed
DEBUG - 2016-09-06 09:10:54 --> XSS Filtering completed
DEBUG - 2016-09-06 09:10:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:10:54 --> Language Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Loader Class Initialized
DEBUG - 2016-09-06 09:10:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:10:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:10:54 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:10:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:10:54 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:10:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:10:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:10:54 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:10:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:10:55 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:10:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:10:55 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:10:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:10:55 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:10:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:10:55 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:10:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:10:55 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:10:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:10:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:10:55 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:10:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:10:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:10:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:10:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:10:55 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:10:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:10:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:10:55 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:10:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:10:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:10:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:10:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:10:55 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:10:55 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:10:55 --> Session Class Initialized
DEBUG - 2016-09-06 09:10:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:10:55 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:10:55 --> Session routines successfully run
DEBUG - 2016-09-06 09:10:55 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:10:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:10:55 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:10:55 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:10:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:10:55 --> Controller Class Initialized
DEBUG - 2016-09-06 09:10:55 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:10:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:10:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:10:55 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:10:55 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:10:55 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:10:55 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:55 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:55 --> Model Class Initialized
ERROR - 2016-09-06 09:10:55 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 09:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-06 09:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 09:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 09:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 09:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 09:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 09:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 09:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 09:10:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 09:10:55 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-06 09:10:55 --> Final output sent to browser
DEBUG - 2016-09-06 09:10:55 --> Total execution time: 0.4683
DEBUG - 2016-09-06 09:10:59 --> Config Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:10:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:10:59 --> URI Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Router Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Output Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Security Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Input Class Initialized
DEBUG - 2016-09-06 09:10:59 --> XSS Filtering completed
DEBUG - 2016-09-06 09:10:59 --> XSS Filtering completed
DEBUG - 2016-09-06 09:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:10:59 --> Language Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Loader Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:10:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:10:59 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:10:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:10:59 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:10:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:10:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:10:59 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:10:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:10:59 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:10:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:10:59 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:10:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:10:59 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:10:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:10:59 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:10:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:10:59 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:10:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:10:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:10:59 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:10:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:10:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:10:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:10:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:10:59 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:10:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:10:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:10:59 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:10:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:10:59 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:10:59 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:10:59 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:10:59 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:10:59 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Session Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:10:59 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:10:59 --> Session routines successfully run
DEBUG - 2016-09-06 09:10:59 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:10:59 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:10:59 --> Controller Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:10:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:10:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:10:59 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:10:59 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:10:59 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Model Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Config Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:10:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:10:59 --> URI Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Router Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Output Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Security Class Initialized
DEBUG - 2016-09-06 09:10:59 --> Input Class Initialized
DEBUG - 2016-09-06 09:10:59 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:00 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:00 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:00 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:00 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:00 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:00 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:00 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:00 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:00 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:00 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:00 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:00 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:00 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:00 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:00 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:00 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:00 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:00 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:00 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:00 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:00 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:00 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:00 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:00 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:00 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:00 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:00 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:00 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:00 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:00 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:00 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:00 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:00 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:00 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:00 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:00 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:00 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:00 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:00 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:00 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:00 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:00 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:00 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:00 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:00 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:00 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:00 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:00 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:00 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:00 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:00 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:00 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:00 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:00 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:00 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:00 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:00 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:00 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:00 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:00 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:00 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:00 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:00 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:00 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:00 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:00 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:01 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:01 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:01 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:01 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:01 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:01 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:01 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:01 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:01 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:01 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:01 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:01 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:01 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:01 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:01 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:01 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:01 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:01 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:01 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:01 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:01 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:01 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:01 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:01 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:01 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:01 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:01 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:01 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:01 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:01 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:01 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:01 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:01 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:01 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:01 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:01 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:01 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:01 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:01 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:01 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:01 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:01 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:01 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:01 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:01 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:01 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:01 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:01 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:01 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:01 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:01 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:01 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:01 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:01 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:01 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:01 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:01 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:01 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:01 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:01 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:01 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:01 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:02 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:02 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:02 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:02 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:02 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:02 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:02 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:02 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:02 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:02 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:02 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:02 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:02 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:02 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:02 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:02 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:02 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:02 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:02 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:02 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:02 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:02 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:02 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:02 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:02 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:02 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:02 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:02 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:02 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:02 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:02 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:02 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:02 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:02 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:02 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:02 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:02 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:02 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:02 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:02 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:02 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:02 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:02 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:02 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:02 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:02 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:02 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:02 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:02 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:02 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:02 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:02 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:02 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:02 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:02 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:02 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:02 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:02 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:02 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:02 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:02 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:02 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:02 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:02 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:02 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:02 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:03 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:03 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:03 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:03 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:03 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:03 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:03 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:03 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:03 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:03 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:03 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:03 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:03 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:03 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:03 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:03 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:03 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:03 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:03 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:03 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:03 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:03 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:03 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:03 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:03 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:03 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:03 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:03 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:03 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:03 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:03 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:03 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:03 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:03 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:03 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:03 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:03 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:03 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:03 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:03 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:03 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:03 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:03 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:03 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:03 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:03 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:03 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:03 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:03 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:03 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:03 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:04 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:04 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:04 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:04 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:04 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:04 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:04 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:04 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:04 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:04 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:04 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:04 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:04 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:04 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:04 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:04 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:04 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:04 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:04 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:04 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:04 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:04 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:04 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:04 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:04 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:04 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:04 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:04 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:04 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:04 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:04 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:04 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:04 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:04 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:04 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:04 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:04 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:04 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:04 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:04 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:04 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:04 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:04 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:04 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:04 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:04 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:04 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:04 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:04 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:04 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:04 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:04 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:05 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:05 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:05 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:05 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:05 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:05 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:05 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:05 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:05 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:05 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:05 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:05 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:05 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:05 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:05 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:05 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:05 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:05 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:05 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:05 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:05 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:05 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:05 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:05 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:05 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:05 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:05 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:05 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:05 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:05 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:05 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:05 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:05 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:05 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:05 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:05 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:05 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:05 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:05 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:05 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:05 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:05 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:05 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:05 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:05 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:05 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:05 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:05 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:05 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:05 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:06 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:06 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:06 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:06 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:06 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:06 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:06 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:06 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:06 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:06 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:06 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:06 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:06 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:06 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:06 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:06 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:06 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:06 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:06 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:06 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:06 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:06 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:06 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:06 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:06 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:06 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:06 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:06 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:06 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:06 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:06 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:06 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:06 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:06 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:06 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:06 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:06 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:06 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:06 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:06 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:06 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:07 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:07 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:07 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:07 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:07 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:07 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:07 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:07 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:07 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:07 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:07 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:07 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:07 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:07 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:07 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:07 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:07 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:07 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:07 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:07 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:07 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:07 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:07 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:07 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:07 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:07 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:07 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:07 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:07 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:07 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:07 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:07 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:07 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:07 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:07 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:07 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:07 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:07 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:07 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:07 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:07 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:07 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:07 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:07 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:07 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:07 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:07 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:07 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:07 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:08 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:08 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:08 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:08 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:08 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:08 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:08 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:08 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:08 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:08 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:08 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:08 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:08 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:08 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:08 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:08 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:08 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:08 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:08 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:08 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:08 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:08 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:08 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:08 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:08 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:08 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:08 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:08 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:08 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:08 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:08 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:08 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:08 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:08 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:08 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:08 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:08 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:08 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:08 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:08 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:08 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:08 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:08 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:08 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:08 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:08 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:08 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:08 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:08 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:08 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:08 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:08 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:08 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:08 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:08 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:08 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:08 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:08 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:08 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:08 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:08 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:08 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:08 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:08 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:08 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:08 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:08 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:08 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:08 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:08 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:08 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:08 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:08 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:08 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:08 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:08 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:08 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:08 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:08 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:08 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:08 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:08 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:08 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:08 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:08 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:08 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:08 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:08 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:08 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:08 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:08 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:08 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:08 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:09 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:09 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:09 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:09 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:09 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:09 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:09 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:09 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:09 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:09 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:09 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:09 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:09 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:09 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:09 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:09 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:09 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:09 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:09 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:09 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:09 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:09 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:09 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:09 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:09 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:09 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:09 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:09 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:09 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:09 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:09 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:09 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:09 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:09 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:09 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:09 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:09 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:09 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:09 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:09 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:09 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:09 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:10 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:10 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:10 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:10 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:10 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:10 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:10 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:10 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:10 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:10 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:10 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:10 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:10 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:10 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:10 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:10 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:10 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:10 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:10 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:10 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:10 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:10 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:10 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:10 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:10 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:10 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:10 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:10 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:10 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:10 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:10 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:10 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:10 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:10 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:10 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:10 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:10 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:10 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:10 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:10 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:10 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:10 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:10 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:10 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:10 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:10 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:10 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:10 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:10 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:10 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:10 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:10 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:10 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:10 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:10 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:10 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:10 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:10 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:11 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:11 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:11 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:11 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:11 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:11 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:11 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:11 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:11 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:11 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:11 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:11 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:11 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:11 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:11 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:11 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:11 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:11 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:11 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:11 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:11 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:11 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:11 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:11 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:11 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:11 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:11 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:11 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:11 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:11 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:11 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:11 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:11 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:11 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:11 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:11 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:11 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:11 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:11 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:11 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:11 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:11 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:11 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:11 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:11 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:11 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:11 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:12 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:12 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:12 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:12 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:12 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:12 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:12 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:12 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:12 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:12 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:12 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:12 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:12 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:12 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:12 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:12 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:12 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:12 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:12 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:12 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:12 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:12 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:12 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:12 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:12 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:12 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:12 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:12 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:12 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:12 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:12 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:12 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:12 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:12 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:12 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:13 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:13 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:13 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:13 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:13 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:13 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:13 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:13 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:13 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:13 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:13 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:13 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:13 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:13 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:13 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:13 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:13 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:13 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:13 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:13 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:13 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:13 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:13 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:13 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:13 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:13 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:13 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:13 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:13 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:13 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:13 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:13 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:13 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:13 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:13 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:13 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:13 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:13 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:13 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:13 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:13 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:13 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:13 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:13 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:13 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:13 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:13 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:13 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:13 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:13 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:13 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:13 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:13 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:13 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:13 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:13 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:13 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:13 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:13 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:13 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:13 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:13 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:13 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:13 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:13 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:13 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:13 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:13 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:13 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:13 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:13 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:13 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:13 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:13 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:14 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:14 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:14 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:14 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:14 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:14 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:14 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:14 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:14 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:14 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:14 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:14 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:14 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:14 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:14 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:14 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:14 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:14 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:14 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:14 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:14 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:14 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:14 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:14 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:14 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:14 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:14 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:14 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:14 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:14 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:14 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:14 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:14 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:14 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:14 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:14 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:14 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:14 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:14 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:14 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:14 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:14 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:14 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:14 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:14 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:14 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:14 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:14 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:14 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:14 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:14 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:14 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:14 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:15 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:15 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:15 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:15 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:15 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:15 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:15 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:15 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:15 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:15 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:15 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:15 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:15 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:15 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:15 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:15 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:15 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:15 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:15 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:15 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:15 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:15 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:15 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:15 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:15 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:15 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:15 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:15 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:15 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:15 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:15 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:15 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:15 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:15 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:16 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:16 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:16 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:16 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:16 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:16 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:16 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:16 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:16 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:16 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:16 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:16 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:16 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:16 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:16 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:16 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:16 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:16 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:16 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:16 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:16 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:16 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:16 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:16 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:16 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:16 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:16 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:16 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:16 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:16 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:16 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:16 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:16 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:16 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:16 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:16 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:16 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:16 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:16 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:16 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:16 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:16 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:16 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:16 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:16 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:16 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:16 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:16 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:16 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:16 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:16 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:16 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:16 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:16 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:16 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:17 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:17 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:17 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:17 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:17 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:17 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:17 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:17 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:17 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:17 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:17 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:17 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:17 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:17 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:17 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:17 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:17 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:17 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:17 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:17 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:17 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:17 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:17 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:17 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:17 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:17 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:17 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:17 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:17 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:17 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:17 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:17 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:17 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:17 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:17 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:17 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:17 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:17 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:17 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:17 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:17 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:17 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:17 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:17 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:17 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:17 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:17 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:17 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:17 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:17 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:17 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:17 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:17 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:17 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:17 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:17 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:17 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:17 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:17 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:17 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:17 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:17 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:17 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:17 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:17 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:17 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:17 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:17 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:17 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:17 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:17 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:17 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:17 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:18 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:18 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:18 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:18 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:18 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:18 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:18 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:18 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:18 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:18 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:18 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:18 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:18 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:18 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:18 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:18 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:18 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:18 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:18 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:18 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:18 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:18 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:18 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:18 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:18 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:18 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:18 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:18 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:18 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:18 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:18 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:18 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:18 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:18 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:18 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:18 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:18 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:18 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:18 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:18 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:18 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:18 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:18 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:18 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:19 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:19 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:19 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:19 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:19 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:19 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:19 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:19 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:19 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:19 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:19 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:24 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:24 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:24 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:24 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:24 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:24 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:24 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:25 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:25 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:25 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:25 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:25 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:25 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:25 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:25 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:25 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:25 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:25 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:25 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:25 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:25 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:25 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:25 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:25 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:25 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:25 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:25 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:25 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:25 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:25 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:25 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:25 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:25 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:25 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:25 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:25 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:25 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:25 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:25 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:25 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:25 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:25 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:25 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:25 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:25 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:25 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:25 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:25 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:25 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:25 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:25 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:25 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:25 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:25 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:25 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:26 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:26 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:26 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:26 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:26 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:26 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:26 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:26 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:26 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:26 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:26 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:26 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:26 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:26 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:26 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:26 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:26 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:26 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:26 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:26 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:26 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:26 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:26 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:26 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:26 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:26 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:26 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:26 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:26 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:26 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:26 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:26 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:26 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:26 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:26 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:26 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:26 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:26 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:26 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:26 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:26 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:26 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:26 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:26 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:26 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:26 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:26 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:26 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:26 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:26 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:27 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:27 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:27 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:27 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:27 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:27 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:27 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:27 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:27 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:27 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:27 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:27 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:27 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:27 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:27 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:27 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:27 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:27 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:27 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:27 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:27 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:27 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:27 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:27 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:27 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:27 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:27 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:27 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:27 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:27 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:27 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:27 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:27 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:27 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:27 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:27 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:27 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:27 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:27 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:27 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:27 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:27 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:27 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:27 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:27 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:27 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:27 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:27 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:27 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:27 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:28 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:28 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:28 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:28 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:28 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:28 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:28 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:28 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:28 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:28 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:28 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:28 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:28 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:28 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:28 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:28 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:28 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:28 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:28 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:28 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:28 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:28 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:28 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:28 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:28 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:28 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:28 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:28 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:28 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:28 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:28 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:28 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:28 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:28 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:28 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:28 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:28 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:28 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:28 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:28 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:28 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:28 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:28 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:28 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:28 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:28 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:28 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:28 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:28 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:28 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:28 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:28 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:28 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:28 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:28 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:28 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:28 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:28 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:28 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:28 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:28 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:29 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:29 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:29 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:29 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:29 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:29 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:29 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:29 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:29 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:29 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:29 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:29 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:29 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:29 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:29 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:29 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:29 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:29 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:29 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:29 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:29 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:29 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:29 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:29 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:29 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:29 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:29 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:29 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:29 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:29 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:29 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:29 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:29 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:29 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:29 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:29 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:29 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:29 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:29 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:29 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:29 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:29 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:29 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:29 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:29 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:29 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:29 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:29 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:29 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:29 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:29 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:29 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:29 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:29 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:29 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:30 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:30 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:30 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:30 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:30 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:30 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:30 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:30 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:30 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:30 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:30 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:30 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:30 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:30 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:30 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:30 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:30 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:30 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:30 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:30 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:30 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:30 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:30 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:30 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:30 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:30 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:30 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:30 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:30 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:30 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:30 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:30 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:30 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:30 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:30 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:30 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:30 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:30 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:30 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:30 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:30 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:30 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:30 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:30 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:30 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:30 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:30 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:30 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:30 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:31 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:31 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:31 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:31 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:31 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:31 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:31 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:31 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:31 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:31 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:31 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:31 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:31 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:31 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:31 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:31 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:31 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:31 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:31 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:31 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:31 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:31 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:31 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:31 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:31 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:31 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:31 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:31 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:31 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:31 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:31 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:31 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:31 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:31 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:31 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:31 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:31 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:31 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:31 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:31 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:31 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:31 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:31 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:31 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:31 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:31 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:31 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:31 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:31 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:31 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:31 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:31 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:31 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:31 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:31 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:31 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:31 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:31 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:31 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:31 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:31 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:31 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:31 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:31 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:31 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:32 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:32 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:32 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:32 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:32 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:32 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:32 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:32 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:32 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:32 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:32 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:32 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:32 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:32 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:32 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:32 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:32 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:32 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:32 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:32 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:32 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:32 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:32 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:32 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:32 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:32 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:32 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:32 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:32 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:32 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:32 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:32 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:32 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:32 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:32 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:32 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:32 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:32 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:32 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:32 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:32 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:32 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:32 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:32 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:32 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:32 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:32 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:32 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:32 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:32 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:32 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:32 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:32 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:32 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:33 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:33 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:33 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:33 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:33 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:33 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:33 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:33 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:33 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:33 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:33 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:33 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:33 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:33 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:33 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:33 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:33 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:33 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:33 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:33 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:33 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:33 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:33 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:33 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:33 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:33 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:33 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:33 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:33 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:34 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:34 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:34 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:34 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:34 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:34 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:34 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:34 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:34 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:34 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:34 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:34 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:34 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:34 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:34 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:34 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:34 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:34 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:34 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:34 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:34 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:34 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:34 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:34 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:34 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:34 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:34 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:34 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:34 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:34 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:34 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:34 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:34 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:34 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:34 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:34 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:34 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:34 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:34 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:34 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:34 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:34 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:34 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:34 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:34 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:35 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:35 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:35 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:35 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:35 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:35 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:35 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:35 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:35 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:35 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:35 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:35 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:35 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:35 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:35 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:35 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:35 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:35 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:35 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:35 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:35 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:35 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:35 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:35 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:35 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:35 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:35 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:35 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:35 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:35 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:35 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:35 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:35 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:35 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:35 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:35 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:35 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:35 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:35 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:35 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:35 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:35 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:35 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:35 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:36 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:36 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:36 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:36 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:36 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:36 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:36 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:36 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:36 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:36 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:36 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:36 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:36 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:36 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:36 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:36 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:36 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:36 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:36 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:36 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:36 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:36 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:36 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:36 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:36 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:36 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:36 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:36 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:36 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:36 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:36 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:36 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:36 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:36 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:36 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:36 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:36 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:36 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:36 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:36 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:36 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:36 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:36 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:36 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:36 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:36 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:36 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:36 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:37 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:37 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:37 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:37 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:37 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:37 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:37 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:37 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:37 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:37 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:37 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:37 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:37 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:37 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:37 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:37 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:37 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:37 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:37 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:37 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:37 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:37 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:37 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:37 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:37 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:37 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:37 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:37 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:37 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:37 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:37 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:37 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:37 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:37 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:37 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:37 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:37 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:37 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:37 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:37 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:37 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:37 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:37 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:37 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:37 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:37 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:37 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:37 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:38 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:38 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:38 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:38 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:38 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:38 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:38 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:38 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:38 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:38 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:38 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:38 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:38 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:38 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:38 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:38 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:38 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:38 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:38 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:38 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:38 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:38 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:38 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:38 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:38 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:38 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:38 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:38 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:38 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:38 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:38 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:38 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:38 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:38 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:38 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:38 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:38 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:38 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:38 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:38 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:38 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:38 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:38 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:38 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:38 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:39 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:39 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:39 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:39 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:39 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:39 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:39 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:39 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:39 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:39 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:39 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:39 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:39 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:39 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:39 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:39 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:39 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:39 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:39 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:39 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:39 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:39 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:39 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:39 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:39 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:39 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:39 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:39 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:39 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:39 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:39 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:39 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:39 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:39 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:39 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:39 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:39 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:39 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:39 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:39 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:39 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:39 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:39 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:39 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:39 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:40 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:40 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:40 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:40 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:40 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:40 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:40 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:40 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:40 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:40 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:40 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:40 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:40 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:40 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:40 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:40 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:40 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:40 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:40 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:40 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:40 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:40 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:40 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:40 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:40 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:40 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:40 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:40 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:40 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:40 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:40 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:40 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:40 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:40 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:40 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:40 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:40 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:40 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:40 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:40 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:40 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:40 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:40 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:40 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:41 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:41 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:41 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:41 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:41 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:41 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:41 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:41 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:41 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:41 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:41 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:41 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:41 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:41 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:41 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:41 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:41 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:41 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:41 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:41 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:41 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:41 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:41 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:41 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:41 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:41 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:41 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:41 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:41 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:41 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:41 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:41 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:41 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:41 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:41 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:41 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:41 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:41 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:41 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:41 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:41 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:41 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:41 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:41 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:41 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:41 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:41 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:41 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:41 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:41 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:42 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:42 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:42 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:42 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:42 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:42 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:42 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:42 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:42 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:42 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:42 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:42 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:42 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:42 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:42 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:42 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:42 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:42 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:42 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:42 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:42 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:42 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:42 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:42 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:42 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:42 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:42 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:42 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:42 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:42 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:42 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:42 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:42 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:42 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:42 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:42 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:42 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:42 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:42 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:42 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:42 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:42 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:42 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:42 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:42 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:42 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:42 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:42 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:42 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:42 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:42 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:42 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:42 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:42 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:42 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:42 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:42 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:42 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:43 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:43 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:43 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:43 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:43 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:43 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:43 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:43 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:43 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:43 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:43 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:43 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:43 --> No URI present. Default controller set.
DEBUG - 2016-09-06 09:11:43 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:43 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 09:11:43 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:43 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:43 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:43 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:43 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:43 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:43 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:43 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:43 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:43 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:43 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:43 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:43 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:43 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:43 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:43 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:43 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:43 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:43 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:43 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:43 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:43 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:43 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:43 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:43 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:43 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:43 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:43 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:43 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:43 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:43 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:43 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:43 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:43 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:44 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:44 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:44 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:44 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:44 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-06 09:11:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 09:11:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 09:11:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:11:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 09:11:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 09:11:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 09:11:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 09:11:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 09:11:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:11:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 09:11:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 09:11:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 09:11:44 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-06 09:11:44 --> Final output sent to browser
DEBUG - 2016-09-06 09:11:44 --> Total execution time: 0.9912
DEBUG - 2016-09-06 09:11:49 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:49 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:49 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:49 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:49 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:49 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:49 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 09:11:49 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:49 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:49 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:49 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:49 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:49 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:49 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:49 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:49 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:49 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:49 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:49 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:50 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:50 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:50 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:50 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:50 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:50 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:50 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:50 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:50 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:50 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:50 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:50 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:50 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:50 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:50 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:50 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:50 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:50 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:50 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:50 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:50 --> Model Class Initialized
ERROR - 2016-09-06 09:11:50 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 09:11:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-06 09:11:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 09:11:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:11:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 09:11:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 09:11:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 09:11:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 09:11:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:11:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 09:11:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 09:11:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 09:11:50 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-06 09:11:50 --> Final output sent to browser
DEBUG - 2016-09-06 09:11:50 --> Total execution time: 1.1404
DEBUG - 2016-09-06 09:11:53 --> Config Class Initialized
DEBUG - 2016-09-06 09:11:53 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:11:53 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:11:53 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:11:53 --> URI Class Initialized
DEBUG - 2016-09-06 09:11:53 --> Router Class Initialized
DEBUG - 2016-09-06 09:11:53 --> Output Class Initialized
DEBUG - 2016-09-06 09:11:53 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 09:11:53 --> Security Class Initialized
DEBUG - 2016-09-06 09:11:53 --> Input Class Initialized
DEBUG - 2016-09-06 09:11:53 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:53 --> XSS Filtering completed
DEBUG - 2016-09-06 09:11:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:11:53 --> Language Class Initialized
DEBUG - 2016-09-06 09:11:53 --> Loader Class Initialized
DEBUG - 2016-09-06 09:11:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:11:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:11:53 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:11:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:11:53 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:11:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:11:53 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:11:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:11:53 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:11:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:11:53 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:11:53 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:11:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:11:53 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:11:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:11:53 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:11:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:11:53 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:11:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:11:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:11:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:11:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:11:53 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:11:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:11:53 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:11:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:11:53 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:11:53 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:11:53 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:11:53 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:11:53 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:11:53 --> Session Class Initialized
DEBUG - 2016-09-06 09:11:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:11:53 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:11:53 --> Session routines successfully run
DEBUG - 2016-09-06 09:11:53 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:11:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:11:53 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:53 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:11:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:11:54 --> Controller Class Initialized
DEBUG - 2016-09-06 09:11:54 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:11:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:11:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:11:54 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:54 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:11:54 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:11:54 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:54 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:54 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:54 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:54 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:54 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:54 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:54 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:54 --> Model Class Initialized
DEBUG - 2016-09-06 09:11:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-06 09:11:54 --> Pagination Class Initialized
DEBUG - 2016-09-06 09:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-06 09:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-06 09:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 09:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 09:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 09:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-06 09:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 09:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 09:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 09:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 09:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 09:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-06 09:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 09:11:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 09:11:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-06 09:11:54 --> Final output sent to browser
DEBUG - 2016-09-06 09:11:54 --> Total execution time: 1.2706
DEBUG - 2016-09-06 09:12:10 --> Config Class Initialized
DEBUG - 2016-09-06 09:12:10 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:12:10 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:12:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:12:10 --> URI Class Initialized
DEBUG - 2016-09-06 09:12:10 --> Router Class Initialized
DEBUG - 2016-09-06 09:12:10 --> Output Class Initialized
DEBUG - 2016-09-06 09:12:10 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 09:12:10 --> Security Class Initialized
DEBUG - 2016-09-06 09:12:10 --> Input Class Initialized
DEBUG - 2016-09-06 09:12:10 --> XSS Filtering completed
DEBUG - 2016-09-06 09:12:10 --> XSS Filtering completed
DEBUG - 2016-09-06 09:12:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:12:10 --> Language Class Initialized
DEBUG - 2016-09-06 09:12:10 --> Loader Class Initialized
DEBUG - 2016-09-06 09:12:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:12:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:12:10 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:12:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:12:10 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:12:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:12:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:12:11 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:12:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:12:11 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:12:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:12:11 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:12:11 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:12:11 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:12:11 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:12:11 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:12:11 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:12:11 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:12:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:12:11 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:12:11 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:12:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:12:11 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:12:11 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:12:11 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:12:11 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:12:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:12:11 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:12:11 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:12:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:12:11 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:12:11 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:12:11 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:12:11 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:12:11 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:12:11 --> Session Class Initialized
DEBUG - 2016-09-06 09:12:11 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:12:11 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:12:11 --> Session routines successfully run
DEBUG - 2016-09-06 09:12:11 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:12:11 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:12:11 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:12:11 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:12:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:12:11 --> Controller Class Initialized
DEBUG - 2016-09-06 09:12:11 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:12:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:12:11 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:12:11 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:12:11 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:12:11 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:12:11 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:11 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:11 --> Model Class Initialized
ERROR - 2016-09-06 09:12:11 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 09:12:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-06 09:12:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 09:12:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:12:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 09:12:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 09:12:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 09:12:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 09:12:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:12:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 09:12:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 09:12:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 09:12:11 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-06 09:12:11 --> Final output sent to browser
DEBUG - 2016-09-06 09:12:11 --> Total execution time: 1.1619
DEBUG - 2016-09-06 09:12:14 --> Config Class Initialized
DEBUG - 2016-09-06 09:12:14 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:12:14 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:12:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:12:14 --> URI Class Initialized
DEBUG - 2016-09-06 09:12:14 --> Router Class Initialized
DEBUG - 2016-09-06 09:12:14 --> Output Class Initialized
DEBUG - 2016-09-06 09:12:14 --> Security Class Initialized
DEBUG - 2016-09-06 09:12:14 --> Input Class Initialized
DEBUG - 2016-09-06 09:12:14 --> XSS Filtering completed
DEBUG - 2016-09-06 09:12:14 --> XSS Filtering completed
DEBUG - 2016-09-06 09:12:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:12:14 --> Language Class Initialized
DEBUG - 2016-09-06 09:12:14 --> Loader Class Initialized
DEBUG - 2016-09-06 09:12:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:12:14 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:12:14 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:12:14 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:12:14 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:12:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:12:14 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:12:14 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:12:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:12:14 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:12:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:12:14 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:12:14 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:12:14 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:12:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:12:14 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:12:14 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:12:14 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:12:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:12:14 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:12:14 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:12:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:12:14 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:12:14 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:12:14 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:12:14 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:12:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:12:14 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:12:14 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:12:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:12:14 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:12:14 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:12:15 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:12:15 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:12:15 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:12:15 --> Session Class Initialized
DEBUG - 2016-09-06 09:12:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:12:15 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:12:15 --> Session routines successfully run
DEBUG - 2016-09-06 09:12:15 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:12:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:12:15 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:12:15 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:12:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:12:15 --> Controller Class Initialized
DEBUG - 2016-09-06 09:12:15 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:12:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:12:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:12:15 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:12:15 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:12:15 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:12:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:15 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-06 09:12:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 09:12:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 09:12:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:12:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 09:12:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 09:12:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 09:12:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 09:12:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 09:12:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:12:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 09:12:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 09:12:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 09:12:15 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-09-06 09:12:15 --> Final output sent to browser
DEBUG - 2016-09-06 09:12:15 --> Total execution time: 1.2396
DEBUG - 2016-09-06 09:12:21 --> Config Class Initialized
DEBUG - 2016-09-06 09:12:21 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:12:21 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:12:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:12:21 --> URI Class Initialized
DEBUG - 2016-09-06 09:12:21 --> Router Class Initialized
DEBUG - 2016-09-06 09:12:21 --> Output Class Initialized
DEBUG - 2016-09-06 09:12:21 --> Security Class Initialized
DEBUG - 2016-09-06 09:12:21 --> Input Class Initialized
DEBUG - 2016-09-06 09:12:21 --> XSS Filtering completed
DEBUG - 2016-09-06 09:12:21 --> XSS Filtering completed
DEBUG - 2016-09-06 09:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:12:21 --> Language Class Initialized
DEBUG - 2016-09-06 09:12:21 --> Loader Class Initialized
DEBUG - 2016-09-06 09:12:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:12:21 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:12:21 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:12:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:12:22 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:12:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:12:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:12:22 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:12:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:12:22 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:12:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:12:22 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:12:22 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:12:22 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:12:22 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:12:22 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:12:22 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:12:22 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:12:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:12:22 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:12:22 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:12:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:12:22 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:12:22 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:12:22 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:12:22 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:12:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:12:22 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:12:22 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:12:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:12:22 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:12:22 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:12:22 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:12:22 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:12:22 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:12:22 --> Session Class Initialized
DEBUG - 2016-09-06 09:12:22 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:12:22 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:12:22 --> Session routines successfully run
DEBUG - 2016-09-06 09:12:22 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:12:22 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:12:22 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:12:22 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:12:22 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:12:22 --> Controller Class Initialized
DEBUG - 2016-09-06 09:12:22 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:12:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:12:22 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:12:22 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:12:22 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:12:22 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:12:22 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:22 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:22 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:22 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:22 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:22 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:23 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:23 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:23 --> Config Class Initialized
DEBUG - 2016-09-06 09:12:23 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:12:23 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:12:23 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:12:23 --> URI Class Initialized
DEBUG - 2016-09-06 09:12:23 --> Router Class Initialized
DEBUG - 2016-09-06 09:12:23 --> No URI present. Default controller set.
DEBUG - 2016-09-06 09:12:23 --> Output Class Initialized
DEBUG - 2016-09-06 09:12:23 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 09:12:23 --> Security Class Initialized
DEBUG - 2016-09-06 09:12:23 --> Input Class Initialized
DEBUG - 2016-09-06 09:12:23 --> XSS Filtering completed
DEBUG - 2016-09-06 09:12:23 --> XSS Filtering completed
DEBUG - 2016-09-06 09:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:12:23 --> Language Class Initialized
DEBUG - 2016-09-06 09:12:23 --> Loader Class Initialized
DEBUG - 2016-09-06 09:12:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:12:23 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:12:23 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:12:23 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:12:23 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:12:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:12:23 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:12:23 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:12:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:12:23 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:12:23 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:12:23 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:12:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:12:23 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:12:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:12:23 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:12:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:12:23 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:12:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:12:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:12:23 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:12:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:12:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:12:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:12:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:12:23 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:12:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:12:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:12:23 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:12:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:12:23 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:12:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:12:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:12:23 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:12:23 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:12:23 --> Session Class Initialized
DEBUG - 2016-09-06 09:12:23 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:12:23 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:12:23 --> Session routines successfully run
DEBUG - 2016-09-06 09:12:23 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:12:23 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:12:23 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:12:23 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:12:23 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:12:23 --> Controller Class Initialized
DEBUG - 2016-09-06 09:12:24 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:12:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:12:24 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:12:24 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:12:24 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:12:24 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:12:24 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:24 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:24 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-06 09:12:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 09:12:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 09:12:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:12:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 09:12:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 09:12:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 09:12:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 09:12:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 09:12:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:12:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 09:12:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 09:12:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 09:12:24 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-06 09:12:24 --> Final output sent to browser
DEBUG - 2016-09-06 09:12:24 --> Total execution time: 1.1020
DEBUG - 2016-09-06 09:12:38 --> Config Class Initialized
DEBUG - 2016-09-06 09:12:38 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:12:38 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:12:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:12:38 --> URI Class Initialized
DEBUG - 2016-09-06 09:12:38 --> Router Class Initialized
DEBUG - 2016-09-06 09:12:38 --> Output Class Initialized
DEBUG - 2016-09-06 09:12:38 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 09:12:38 --> Security Class Initialized
DEBUG - 2016-09-06 09:12:38 --> Input Class Initialized
DEBUG - 2016-09-06 09:12:38 --> XSS Filtering completed
DEBUG - 2016-09-06 09:12:38 --> XSS Filtering completed
DEBUG - 2016-09-06 09:12:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:12:38 --> Language Class Initialized
DEBUG - 2016-09-06 09:12:39 --> Loader Class Initialized
DEBUG - 2016-09-06 09:12:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:12:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:12:39 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:12:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:12:39 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:12:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:12:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:12:39 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:12:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:12:39 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:12:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:12:39 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:12:39 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:12:39 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:12:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:12:39 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:12:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:12:39 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:12:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:12:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:12:39 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:12:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:12:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:12:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:12:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:12:39 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:12:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:12:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:12:39 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:12:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:12:39 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:12:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:12:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:12:39 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:12:39 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:12:39 --> Session Class Initialized
DEBUG - 2016-09-06 09:12:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:12:39 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:12:39 --> Session routines successfully run
DEBUG - 2016-09-06 09:12:39 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:12:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:12:39 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:12:39 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:12:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:12:39 --> Controller Class Initialized
DEBUG - 2016-09-06 09:12:39 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:12:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:12:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:12:39 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:12:39 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:12:39 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:12:39 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:39 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:39 --> Model Class Initialized
ERROR - 2016-09-06 09:12:39 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 09:12:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-06 09:12:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 09:12:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:12:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 09:12:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 09:12:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 09:12:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 09:12:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:12:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 09:12:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 09:12:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 09:12:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/009d86c91412abf86ca602e385b0310f
DEBUG - 2016-09-06 09:12:40 --> Final output sent to browser
DEBUG - 2016-09-06 09:12:40 --> Total execution time: 1.3031
DEBUG - 2016-09-06 09:12:42 --> Config Class Initialized
DEBUG - 2016-09-06 09:12:42 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:12:42 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:12:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:12:42 --> URI Class Initialized
DEBUG - 2016-09-06 09:12:42 --> Router Class Initialized
DEBUG - 2016-09-06 09:12:42 --> Output Class Initialized
DEBUG - 2016-09-06 09:12:42 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 09:12:42 --> Security Class Initialized
DEBUG - 2016-09-06 09:12:42 --> Input Class Initialized
DEBUG - 2016-09-06 09:12:42 --> XSS Filtering completed
DEBUG - 2016-09-06 09:12:42 --> XSS Filtering completed
DEBUG - 2016-09-06 09:12:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:12:42 --> Language Class Initialized
DEBUG - 2016-09-06 09:12:42 --> Loader Class Initialized
DEBUG - 2016-09-06 09:12:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:12:42 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:12:42 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:12:42 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:12:42 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:12:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:12:42 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:12:42 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:12:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:12:42 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:12:42 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:12:42 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:12:42 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:12:42 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:12:42 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:12:42 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:12:42 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:12:42 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:12:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:12:42 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:12:42 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:12:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:12:42 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:12:42 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:12:42 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:12:42 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:12:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:12:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:12:43 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:12:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:12:43 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:12:43 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:12:43 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:12:43 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:12:43 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:12:43 --> Session Class Initialized
DEBUG - 2016-09-06 09:12:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:12:43 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:12:43 --> Session routines successfully run
DEBUG - 2016-09-06 09:12:43 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:12:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:12:43 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:12:43 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:12:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:12:43 --> Controller Class Initialized
DEBUG - 2016-09-06 09:12:43 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:12:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:12:43 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:12:43 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:12:43 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:12:43 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:12:43 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:43 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:43 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-06 09:12:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 09:12:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 09:12:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:12:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 09:12:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 09:12:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 09:12:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 09:12:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 09:12:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:12:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 09:12:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 09:12:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 09:12:43 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-09-06 09:12:43 --> Final output sent to browser
DEBUG - 2016-09-06 09:12:43 --> Total execution time: 1.2985
DEBUG - 2016-09-06 09:12:48 --> Config Class Initialized
DEBUG - 2016-09-06 09:12:48 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:12:48 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:12:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:12:48 --> URI Class Initialized
DEBUG - 2016-09-06 09:12:48 --> Router Class Initialized
DEBUG - 2016-09-06 09:12:48 --> Output Class Initialized
DEBUG - 2016-09-06 09:12:48 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 09:12:48 --> Security Class Initialized
DEBUG - 2016-09-06 09:12:48 --> Input Class Initialized
DEBUG - 2016-09-06 09:12:48 --> XSS Filtering completed
DEBUG - 2016-09-06 09:12:48 --> XSS Filtering completed
DEBUG - 2016-09-06 09:12:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:12:48 --> Language Class Initialized
DEBUG - 2016-09-06 09:12:48 --> Loader Class Initialized
DEBUG - 2016-09-06 09:12:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:12:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:12:48 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:12:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:12:48 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:12:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:12:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:12:48 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:12:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:12:49 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:12:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:12:49 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:12:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:12:49 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:12:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:12:49 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:12:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:12:49 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:12:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:12:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:12:49 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:12:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:12:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:12:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:12:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:12:49 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:12:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:12:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:12:49 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:12:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:12:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:12:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:12:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:12:49 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:12:49 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:12:49 --> Session Class Initialized
DEBUG - 2016-09-06 09:12:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:12:49 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:12:49 --> Session routines successfully run
DEBUG - 2016-09-06 09:12:49 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:12:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:12:49 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:12:49 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:12:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:12:49 --> Controller Class Initialized
DEBUG - 2016-09-06 09:12:49 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:12:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:12:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:12:49 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:12:49 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:12:49 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:12:49 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:49 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:49 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:49 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:49 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:49 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:49 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:49 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:49 --> Model Class Initialized
ERROR - 2016-09-06 09:12:49 --> Hak Akses modul/kontroller 'cdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 09:12:49 --> Config Class Initialized
DEBUG - 2016-09-06 09:12:49 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:12:49 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:12:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:12:49 --> URI Class Initialized
DEBUG - 2016-09-06 09:12:49 --> Router Class Initialized
DEBUG - 2016-09-06 09:12:49 --> Output Class Initialized
DEBUG - 2016-09-06 09:12:50 --> Security Class Initialized
DEBUG - 2016-09-06 09:12:50 --> Input Class Initialized
DEBUG - 2016-09-06 09:12:50 --> XSS Filtering completed
DEBUG - 2016-09-06 09:12:50 --> XSS Filtering completed
DEBUG - 2016-09-06 09:12:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:12:50 --> Language Class Initialized
DEBUG - 2016-09-06 09:12:50 --> Loader Class Initialized
DEBUG - 2016-09-06 09:12:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:12:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:12:50 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:12:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:12:50 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:12:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:12:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:12:50 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:12:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:12:50 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:12:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:12:50 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:12:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:12:50 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:12:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:12:50 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:12:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:12:50 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:12:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:12:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:12:50 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:12:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:12:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:12:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:12:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:12:50 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:12:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:12:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:12:50 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:12:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:12:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:12:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:12:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:12:50 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:12:50 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:12:50 --> Session Class Initialized
DEBUG - 2016-09-06 09:12:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:12:50 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:12:50 --> Session routines successfully run
DEBUG - 2016-09-06 09:12:50 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:12:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:12:50 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:12:50 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:12:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:12:50 --> Controller Class Initialized
DEBUG - 2016-09-06 09:12:50 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:12:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:12:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:12:50 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:12:50 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:12:50 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:12:50 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:51 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:51 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:51 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:51 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:51 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:51 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:51 --> Model Class Initialized
ERROR - 2016-09-06 09:12:51 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 09:12:51 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 09:12:51 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-09-06 09:12:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-06 09:12:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-06 09:12:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-06 09:12:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-06 09:12:51 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-09-06 09:12:51 --> Final output sent to browser
DEBUG - 2016-09-06 09:12:51 --> Total execution time: 1.2520
DEBUG - 2016-09-06 09:12:58 --> Config Class Initialized
DEBUG - 2016-09-06 09:12:58 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:12:58 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:12:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:12:58 --> URI Class Initialized
DEBUG - 2016-09-06 09:12:58 --> Router Class Initialized
DEBUG - 2016-09-06 09:12:58 --> Output Class Initialized
DEBUG - 2016-09-06 09:12:58 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 09:12:58 --> Security Class Initialized
DEBUG - 2016-09-06 09:12:58 --> Input Class Initialized
DEBUG - 2016-09-06 09:12:58 --> XSS Filtering completed
DEBUG - 2016-09-06 09:12:58 --> XSS Filtering completed
DEBUG - 2016-09-06 09:12:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:12:58 --> Language Class Initialized
DEBUG - 2016-09-06 09:12:58 --> Loader Class Initialized
DEBUG - 2016-09-06 09:12:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:12:58 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:12:58 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:12:58 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:12:58 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:12:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:12:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:12:58 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:12:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:12:58 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:12:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:12:58 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:12:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:12:58 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:12:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:12:59 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:12:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:12:59 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:12:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:12:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:12:59 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:12:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:12:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:12:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:12:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:12:59 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:12:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:12:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:12:59 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:12:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:12:59 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:12:59 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:12:59 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:12:59 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:12:59 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:12:59 --> Session Class Initialized
DEBUG - 2016-09-06 09:12:59 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:12:59 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:12:59 --> Session routines successfully run
DEBUG - 2016-09-06 09:12:59 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:12:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:12:59 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:12:59 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:12:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:12:59 --> Controller Class Initialized
DEBUG - 2016-09-06 09:12:59 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:12:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:12:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:12:59 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:12:59 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:12:59 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:12:59 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:59 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:59 --> Model Class Initialized
DEBUG - 2016-09-06 09:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-06 09:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 09:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 09:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 09:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 09:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 09:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 09:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 09:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 09:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 09:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 09:12:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 09:12:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-09-06 09:12:59 --> Final output sent to browser
DEBUG - 2016-09-06 09:12:59 --> Total execution time: 1.3120
DEBUG - 2016-09-06 09:47:28 --> Config Class Initialized
DEBUG - 2016-09-06 09:47:28 --> Hooks Class Initialized
DEBUG - 2016-09-06 09:47:28 --> Utf8 Class Initialized
DEBUG - 2016-09-06 09:47:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 09:47:28 --> URI Class Initialized
DEBUG - 2016-09-06 09:47:28 --> Router Class Initialized
DEBUG - 2016-09-06 09:47:28 --> Output Class Initialized
DEBUG - 2016-09-06 09:47:28 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 09:47:28 --> Security Class Initialized
DEBUG - 2016-09-06 09:47:28 --> Input Class Initialized
DEBUG - 2016-09-06 09:47:28 --> XSS Filtering completed
DEBUG - 2016-09-06 09:47:28 --> XSS Filtering completed
DEBUG - 2016-09-06 09:47:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 09:47:29 --> Language Class Initialized
DEBUG - 2016-09-06 09:47:29 --> Loader Class Initialized
DEBUG - 2016-09-06 09:47:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 09:47:29 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 09:47:29 --> Helper loaded: url_helper
DEBUG - 2016-09-06 09:47:29 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 09:47:29 --> Helper loaded: file_helper
DEBUG - 2016-09-06 09:47:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:47:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 09:47:29 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 09:47:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 09:47:29 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 09:47:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 09:47:29 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:47:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 09:47:29 --> Helper loaded: common_helper
DEBUG - 2016-09-06 09:47:29 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 09:47:29 --> Helper loaded: form_helper
DEBUG - 2016-09-06 09:47:29 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 09:47:29 --> Helper loaded: security_helper
DEBUG - 2016-09-06 09:47:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:47:29 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 09:47:29 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 09:47:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 09:47:29 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 09:47:29 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 09:47:29 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 09:47:29 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 09:47:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:47:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 09:47:29 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 09:47:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 09:47:29 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 09:47:29 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 09:47:29 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 09:47:29 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 09:47:29 --> Database Driver Class Initialized
DEBUG - 2016-09-06 09:47:29 --> Session Class Initialized
DEBUG - 2016-09-06 09:47:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 09:47:29 --> Helper loaded: string_helper
DEBUG - 2016-09-06 09:47:29 --> Session routines successfully run
DEBUG - 2016-09-06 09:47:29 --> Native_session Class Initialized
DEBUG - 2016-09-06 09:47:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 09:47:29 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:47:29 --> Form Validation Class Initialized
DEBUG - 2016-09-06 09:47:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 09:47:29 --> Controller Class Initialized
DEBUG - 2016-09-06 09:47:29 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 09:47:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 09:47:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 09:47:30 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:47:30 --> Carabiner: library configured.
DEBUG - 2016-09-06 09:47:30 --> User Agent Class Initialized
DEBUG - 2016-09-06 09:47:30 --> Model Class Initialized
DEBUG - 2016-09-06 09:47:30 --> Model Class Initialized
DEBUG - 2016-09-06 09:47:30 --> Model Class Initialized
DEBUG - 2016-09-06 09:47:30 --> Model Class Initialized
DEBUG - 2016-09-06 09:47:30 --> Model Class Initialized
DEBUG - 2016-09-06 09:47:30 --> Model Class Initialized
DEBUG - 2016-09-06 09:47:30 --> Model Class Initialized
DEBUG - 2016-09-06 09:47:30 --> Model Class Initialized
ERROR - 2016-09-06 09:47:30 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 09:47:30 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 09:47:30 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-09-06 09:47:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-06 09:47:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-06 09:47:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-06 09:47:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-06 09:47:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-09-06 09:47:30 --> Final output sent to browser
DEBUG - 2016-09-06 09:47:30 --> Total execution time: 1.5354
DEBUG - 2016-09-06 12:41:14 --> Config Class Initialized
DEBUG - 2016-09-06 12:41:14 --> Hooks Class Initialized
DEBUG - 2016-09-06 12:41:14 --> Utf8 Class Initialized
DEBUG - 2016-09-06 12:41:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 12:41:14 --> URI Class Initialized
DEBUG - 2016-09-06 12:41:14 --> Router Class Initialized
DEBUG - 2016-09-06 12:41:14 --> No URI present. Default controller set.
DEBUG - 2016-09-06 12:41:14 --> Output Class Initialized
DEBUG - 2016-09-06 12:41:14 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 12:41:14 --> Security Class Initialized
DEBUG - 2016-09-06 12:41:14 --> Input Class Initialized
DEBUG - 2016-09-06 12:41:14 --> XSS Filtering completed
DEBUG - 2016-09-06 12:41:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 12:41:14 --> Language Class Initialized
DEBUG - 2016-09-06 12:41:14 --> Loader Class Initialized
DEBUG - 2016-09-06 12:41:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 12:41:14 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 12:41:14 --> Helper loaded: url_helper
DEBUG - 2016-09-06 12:41:14 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 12:41:14 --> Helper loaded: file_helper
DEBUG - 2016-09-06 12:41:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 12:41:14 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 12:41:14 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 12:41:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 12:41:14 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 12:41:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 12:41:14 --> Helper loaded: common_helper
DEBUG - 2016-09-06 12:41:14 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 12:41:14 --> Helper loaded: common_helper
DEBUG - 2016-09-06 12:41:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 12:41:14 --> Helper loaded: form_helper
DEBUG - 2016-09-06 12:41:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 12:41:15 --> Helper loaded: security_helper
DEBUG - 2016-09-06 12:41:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 12:41:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 12:41:15 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 12:41:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 12:41:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 12:41:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 12:41:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 12:41:15 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 12:41:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 12:41:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 12:41:15 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 12:41:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 12:41:15 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 12:41:15 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 12:41:15 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 12:41:15 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 12:41:15 --> Database Driver Class Initialized
DEBUG - 2016-09-06 12:41:15 --> Session Class Initialized
DEBUG - 2016-09-06 12:41:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 12:41:15 --> Helper loaded: string_helper
DEBUG - 2016-09-06 12:41:15 --> A session cookie was not found.
DEBUG - 2016-09-06 12:41:15 --> Session routines successfully run
DEBUG - 2016-09-06 12:41:15 --> Native_session Class Initialized
DEBUG - 2016-09-06 12:41:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 12:41:15 --> Form Validation Class Initialized
DEBUG - 2016-09-06 12:41:15 --> Form Validation Class Initialized
DEBUG - 2016-09-06 12:41:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 12:41:15 --> Controller Class Initialized
DEBUG - 2016-09-06 12:41:15 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 12:41:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 12:41:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 12:41:15 --> Carabiner: library configured.
DEBUG - 2016-09-06 12:41:15 --> Carabiner: library configured.
DEBUG - 2016-09-06 12:41:15 --> User Agent Class Initialized
DEBUG - 2016-09-06 12:41:15 --> Model Class Initialized
DEBUG - 2016-09-06 12:41:15 --> Model Class Initialized
DEBUG - 2016-09-06 12:41:15 --> Model Class Initialized
ERROR - 2016-09-06 12:41:15 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 12:41:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-06 12:41:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 12:41:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 12:41:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 12:41:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 12:41:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 12:41:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 12:41:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 12:41:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 12:41:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 12:41:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 12:41:15 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-06 12:41:15 --> Final output sent to browser
DEBUG - 2016-09-06 12:41:15 --> Total execution time: 1.2709
DEBUG - 2016-09-06 13:46:06 --> Config Class Initialized
DEBUG - 2016-09-06 13:46:06 --> Hooks Class Initialized
DEBUG - 2016-09-06 13:46:06 --> Utf8 Class Initialized
DEBUG - 2016-09-06 13:46:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 13:46:06 --> URI Class Initialized
DEBUG - 2016-09-06 13:46:06 --> Router Class Initialized
DEBUG - 2016-09-06 13:46:06 --> No URI present. Default controller set.
DEBUG - 2016-09-06 13:46:06 --> Output Class Initialized
DEBUG - 2016-09-06 13:46:06 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 13:46:06 --> Security Class Initialized
DEBUG - 2016-09-06 13:46:06 --> Input Class Initialized
DEBUG - 2016-09-06 13:46:06 --> XSS Filtering completed
DEBUG - 2016-09-06 13:46:06 --> XSS Filtering completed
DEBUG - 2016-09-06 13:46:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 13:46:06 --> Language Class Initialized
DEBUG - 2016-09-06 13:46:06 --> Loader Class Initialized
DEBUG - 2016-09-06 13:46:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 13:46:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 13:46:06 --> Helper loaded: url_helper
DEBUG - 2016-09-06 13:46:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 13:46:06 --> Helper loaded: file_helper
DEBUG - 2016-09-06 13:46:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 13:46:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 13:46:06 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 13:46:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 13:46:06 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 13:46:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 13:46:06 --> Helper loaded: common_helper
DEBUG - 2016-09-06 13:46:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 13:46:06 --> Helper loaded: common_helper
DEBUG - 2016-09-06 13:46:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 13:46:06 --> Helper loaded: form_helper
DEBUG - 2016-09-06 13:46:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 13:46:06 --> Helper loaded: security_helper
DEBUG - 2016-09-06 13:46:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 13:46:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 13:46:06 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 13:46:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 13:46:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 13:46:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 13:46:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 13:46:06 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 13:46:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 13:46:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 13:46:06 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 13:46:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 13:46:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 13:46:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 13:46:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 13:46:06 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 13:46:06 --> Database Driver Class Initialized
DEBUG - 2016-09-06 13:46:07 --> Session Class Initialized
DEBUG - 2016-09-06 13:46:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 13:46:07 --> Helper loaded: string_helper
DEBUG - 2016-09-06 13:46:07 --> Session routines successfully run
DEBUG - 2016-09-06 13:46:07 --> Native_session Class Initialized
DEBUG - 2016-09-06 13:46:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 13:46:07 --> Form Validation Class Initialized
DEBUG - 2016-09-06 13:46:07 --> Form Validation Class Initialized
DEBUG - 2016-09-06 13:46:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 13:46:07 --> Controller Class Initialized
DEBUG - 2016-09-06 13:46:07 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 13:46:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 13:46:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 13:46:07 --> Carabiner: library configured.
DEBUG - 2016-09-06 13:46:07 --> Carabiner: library configured.
DEBUG - 2016-09-06 13:46:07 --> User Agent Class Initialized
DEBUG - 2016-09-06 13:46:07 --> Model Class Initialized
DEBUG - 2016-09-06 13:46:07 --> Model Class Initialized
DEBUG - 2016-09-06 13:46:07 --> Model Class Initialized
ERROR - 2016-09-06 13:46:07 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 13:46:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-06 13:46:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 13:46:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 13:46:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 13:46:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 13:46:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 13:46:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 13:46:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 13:46:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 13:46:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 13:46:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 13:46:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-06 13:46:07 --> Final output sent to browser
DEBUG - 2016-09-06 13:46:07 --> Total execution time: 1.2886
DEBUG - 2016-09-06 13:48:25 --> Config Class Initialized
DEBUG - 2016-09-06 13:48:25 --> Hooks Class Initialized
DEBUG - 2016-09-06 13:48:26 --> Utf8 Class Initialized
DEBUG - 2016-09-06 13:48:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 13:48:26 --> URI Class Initialized
DEBUG - 2016-09-06 13:48:26 --> Router Class Initialized
DEBUG - 2016-09-06 13:48:26 --> No URI present. Default controller set.
DEBUG - 2016-09-06 13:48:26 --> Output Class Initialized
DEBUG - 2016-09-06 13:48:26 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 13:48:26 --> Security Class Initialized
DEBUG - 2016-09-06 13:48:26 --> Input Class Initialized
DEBUG - 2016-09-06 13:48:26 --> XSS Filtering completed
DEBUG - 2016-09-06 13:48:26 --> XSS Filtering completed
DEBUG - 2016-09-06 13:48:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 13:48:26 --> Language Class Initialized
DEBUG - 2016-09-06 13:48:26 --> Loader Class Initialized
DEBUG - 2016-09-06 13:48:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 13:48:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 13:48:26 --> Helper loaded: url_helper
DEBUG - 2016-09-06 13:48:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 13:48:26 --> Helper loaded: file_helper
DEBUG - 2016-09-06 13:48:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 13:48:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 13:48:26 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 13:48:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 13:48:26 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 13:48:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 13:48:26 --> Helper loaded: common_helper
DEBUG - 2016-09-06 13:48:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 13:48:26 --> Helper loaded: common_helper
DEBUG - 2016-09-06 13:48:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 13:48:26 --> Helper loaded: form_helper
DEBUG - 2016-09-06 13:48:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 13:48:26 --> Helper loaded: security_helper
DEBUG - 2016-09-06 13:48:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 13:48:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 13:48:26 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 13:48:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 13:48:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 13:48:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 13:48:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 13:48:26 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 13:48:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 13:48:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 13:48:26 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 13:48:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 13:48:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 13:48:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 13:48:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 13:48:26 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 13:48:26 --> Database Driver Class Initialized
DEBUG - 2016-09-06 13:48:26 --> Session Class Initialized
DEBUG - 2016-09-06 13:48:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 13:48:26 --> Helper loaded: string_helper
DEBUG - 2016-09-06 13:48:26 --> Session routines successfully run
DEBUG - 2016-09-06 13:48:26 --> Native_session Class Initialized
DEBUG - 2016-09-06 13:48:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 13:48:26 --> Form Validation Class Initialized
DEBUG - 2016-09-06 13:48:27 --> Form Validation Class Initialized
DEBUG - 2016-09-06 13:48:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 13:48:27 --> Controller Class Initialized
DEBUG - 2016-09-06 13:48:27 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 13:48:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 13:48:27 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 13:48:27 --> Carabiner: library configured.
DEBUG - 2016-09-06 13:48:27 --> Carabiner: library configured.
DEBUG - 2016-09-06 13:48:27 --> User Agent Class Initialized
DEBUG - 2016-09-06 13:48:27 --> Model Class Initialized
DEBUG - 2016-09-06 13:48:27 --> Model Class Initialized
DEBUG - 2016-09-06 13:48:27 --> Model Class Initialized
ERROR - 2016-09-06 13:48:27 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 13:48:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-06 13:48:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 13:48:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 13:48:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 13:48:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 13:48:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 13:48:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 13:48:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 13:48:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 13:48:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 13:48:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 13:48:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-06 13:48:27 --> Final output sent to browser
DEBUG - 2016-09-06 13:48:27 --> Total execution time: 1.2791
DEBUG - 2016-09-06 14:32:09 --> Config Class Initialized
DEBUG - 2016-09-06 14:32:09 --> Hooks Class Initialized
DEBUG - 2016-09-06 14:32:09 --> Utf8 Class Initialized
DEBUG - 2016-09-06 14:32:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 14:32:09 --> URI Class Initialized
DEBUG - 2016-09-06 14:32:09 --> Router Class Initialized
DEBUG - 2016-09-06 14:32:09 --> No URI present. Default controller set.
DEBUG - 2016-09-06 14:32:09 --> Output Class Initialized
DEBUG - 2016-09-06 14:32:09 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 14:32:09 --> Security Class Initialized
DEBUG - 2016-09-06 14:32:09 --> Input Class Initialized
DEBUG - 2016-09-06 14:32:09 --> XSS Filtering completed
DEBUG - 2016-09-06 14:32:09 --> XSS Filtering completed
DEBUG - 2016-09-06 14:32:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 14:32:09 --> Language Class Initialized
DEBUG - 2016-09-06 14:32:09 --> Loader Class Initialized
DEBUG - 2016-09-06 14:32:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 14:32:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 14:32:10 --> Helper loaded: url_helper
DEBUG - 2016-09-06 14:32:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 14:32:10 --> Helper loaded: file_helper
DEBUG - 2016-09-06 14:32:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:32:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 14:32:10 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 14:32:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:32:10 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 14:32:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 14:32:10 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:32:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 14:32:10 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:32:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 14:32:10 --> Helper loaded: form_helper
DEBUG - 2016-09-06 14:32:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 14:32:10 --> Helper loaded: security_helper
DEBUG - 2016-09-06 14:32:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:32:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 14:32:10 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 14:32:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:32:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 14:32:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 14:32:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 14:32:10 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 14:32:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:32:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 14:32:10 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 14:32:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:32:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 14:32:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 14:32:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 14:32:10 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 14:32:10 --> Database Driver Class Initialized
DEBUG - 2016-09-06 14:32:10 --> Session Class Initialized
DEBUG - 2016-09-06 14:32:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 14:32:10 --> Helper loaded: string_helper
DEBUG - 2016-09-06 14:32:10 --> Session routines successfully run
DEBUG - 2016-09-06 14:32:10 --> Native_session Class Initialized
DEBUG - 2016-09-06 14:32:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 14:32:10 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:32:10 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:32:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 14:32:10 --> Controller Class Initialized
DEBUG - 2016-09-06 14:32:10 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 14:32:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 14:32:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 14:32:10 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:32:10 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:32:10 --> User Agent Class Initialized
DEBUG - 2016-09-06 14:32:10 --> Model Class Initialized
DEBUG - 2016-09-06 14:32:10 --> Model Class Initialized
DEBUG - 2016-09-06 14:32:10 --> Model Class Initialized
ERROR - 2016-09-06 14:32:10 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 14:32:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-06 14:32:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 14:32:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 14:32:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 14:32:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 14:32:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 14:32:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 14:32:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 14:32:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 14:32:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 14:32:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 14:32:11 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-06 14:32:11 --> Final output sent to browser
DEBUG - 2016-09-06 14:32:11 --> Total execution time: 1.3469
DEBUG - 2016-09-06 14:32:34 --> Config Class Initialized
DEBUG - 2016-09-06 14:32:34 --> Hooks Class Initialized
DEBUG - 2016-09-06 14:32:34 --> Utf8 Class Initialized
DEBUG - 2016-09-06 14:32:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 14:32:34 --> URI Class Initialized
DEBUG - 2016-09-06 14:32:34 --> Router Class Initialized
DEBUG - 2016-09-06 14:32:34 --> Output Class Initialized
DEBUG - 2016-09-06 14:32:34 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 14:32:34 --> Security Class Initialized
DEBUG - 2016-09-06 14:32:34 --> Input Class Initialized
DEBUG - 2016-09-06 14:32:34 --> XSS Filtering completed
DEBUG - 2016-09-06 14:32:34 --> XSS Filtering completed
DEBUG - 2016-09-06 14:32:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 14:32:34 --> Language Class Initialized
DEBUG - 2016-09-06 14:32:34 --> Loader Class Initialized
DEBUG - 2016-09-06 14:32:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 14:32:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 14:32:34 --> Helper loaded: url_helper
DEBUG - 2016-09-06 14:32:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 14:32:35 --> Helper loaded: file_helper
DEBUG - 2016-09-06 14:32:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:32:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 14:32:35 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 14:32:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:32:35 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 14:32:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 14:32:35 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:32:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 14:32:35 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:32:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 14:32:35 --> Helper loaded: form_helper
DEBUG - 2016-09-06 14:32:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 14:32:35 --> Helper loaded: security_helper
DEBUG - 2016-09-06 14:32:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:32:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 14:32:35 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 14:32:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:32:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 14:32:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 14:32:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 14:32:35 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 14:32:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:32:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 14:32:35 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 14:32:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:32:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 14:32:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 14:32:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 14:32:35 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 14:32:35 --> Database Driver Class Initialized
DEBUG - 2016-09-06 14:32:35 --> Session Class Initialized
DEBUG - 2016-09-06 14:32:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 14:32:35 --> Helper loaded: string_helper
DEBUG - 2016-09-06 14:32:35 --> Session routines successfully run
DEBUG - 2016-09-06 14:32:35 --> Native_session Class Initialized
DEBUG - 2016-09-06 14:32:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 14:32:35 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:32:35 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:32:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 14:32:35 --> Controller Class Initialized
DEBUG - 2016-09-06 14:32:35 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 14:32:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 14:32:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 14:32:35 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:32:35 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:32:35 --> User Agent Class Initialized
DEBUG - 2016-09-06 14:32:35 --> Model Class Initialized
DEBUG - 2016-09-06 14:32:35 --> Model Class Initialized
DEBUG - 2016-09-06 14:32:35 --> Model Class Initialized
DEBUG - 2016-09-06 14:32:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-06 14:32:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 14:32:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 14:32:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 14:32:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 14:32:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 14:32:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 14:32:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 14:32:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 14:32:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 14:32:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 14:32:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 14:32:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 14:32:36 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-09-06 14:32:36 --> Final output sent to browser
DEBUG - 2016-09-06 14:32:36 --> Total execution time: 1.2913
DEBUG - 2016-09-06 14:32:38 --> Config Class Initialized
DEBUG - 2016-09-06 14:32:38 --> Hooks Class Initialized
DEBUG - 2016-09-06 14:32:38 --> Utf8 Class Initialized
DEBUG - 2016-09-06 14:32:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 14:32:38 --> URI Class Initialized
DEBUG - 2016-09-06 14:32:38 --> Router Class Initialized
DEBUG - 2016-09-06 14:32:38 --> Output Class Initialized
DEBUG - 2016-09-06 14:32:38 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 14:32:38 --> Security Class Initialized
DEBUG - 2016-09-06 14:32:38 --> Input Class Initialized
DEBUG - 2016-09-06 14:32:38 --> XSS Filtering completed
DEBUG - 2016-09-06 14:32:38 --> XSS Filtering completed
DEBUG - 2016-09-06 14:32:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 14:32:38 --> Language Class Initialized
DEBUG - 2016-09-06 14:32:38 --> Loader Class Initialized
DEBUG - 2016-09-06 14:32:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 14:32:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 14:32:38 --> Helper loaded: url_helper
DEBUG - 2016-09-06 14:32:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 14:32:38 --> Helper loaded: file_helper
DEBUG - 2016-09-06 14:32:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:32:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 14:32:38 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 14:32:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:32:38 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 14:32:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 14:32:38 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:32:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 14:32:38 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:32:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 14:32:38 --> Helper loaded: form_helper
DEBUG - 2016-09-06 14:32:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 14:32:38 --> Helper loaded: security_helper
DEBUG - 2016-09-06 14:32:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:32:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 14:32:38 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 14:32:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:32:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 14:32:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 14:32:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 14:32:39 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 14:32:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:32:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 14:32:39 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 14:32:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:32:39 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 14:32:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 14:32:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 14:32:39 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 14:32:39 --> Database Driver Class Initialized
DEBUG - 2016-09-06 14:32:39 --> Session Class Initialized
DEBUG - 2016-09-06 14:32:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 14:32:39 --> Helper loaded: string_helper
DEBUG - 2016-09-06 14:32:39 --> Session routines successfully run
DEBUG - 2016-09-06 14:32:39 --> Native_session Class Initialized
DEBUG - 2016-09-06 14:32:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 14:32:39 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:32:39 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:32:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 14:32:39 --> Controller Class Initialized
DEBUG - 2016-09-06 14:32:39 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 14:32:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 14:32:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 14:32:39 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:32:39 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:32:39 --> User Agent Class Initialized
DEBUG - 2016-09-06 14:32:39 --> Model Class Initialized
DEBUG - 2016-09-06 14:32:39 --> Model Class Initialized
DEBUG - 2016-09-06 14:32:39 --> Model Class Initialized
DEBUG - 2016-09-06 14:32:39 --> Model Class Initialized
DEBUG - 2016-09-06 14:32:39 --> Model Class Initialized
DEBUG - 2016-09-06 14:32:39 --> Model Class Initialized
DEBUG - 2016-09-06 14:32:39 --> Model Class Initialized
DEBUG - 2016-09-06 14:32:39 --> Model Class Initialized
ERROR - 2016-09-06 14:32:39 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 14:32:39 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 14:32:39 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-09-06 14:32:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-06 14:32:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-06 14:32:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-06 14:32:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-06 14:32:39 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-09-06 14:32:39 --> Final output sent to browser
DEBUG - 2016-09-06 14:32:39 --> Total execution time: 1.4617
DEBUG - 2016-09-06 14:32:40 --> Config Class Initialized
DEBUG - 2016-09-06 14:32:40 --> Hooks Class Initialized
DEBUG - 2016-09-06 14:32:40 --> Utf8 Class Initialized
DEBUG - 2016-09-06 14:32:40 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 14:32:40 --> URI Class Initialized
DEBUG - 2016-09-06 14:32:40 --> Router Class Initialized
ERROR - 2016-09-06 14:32:40 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-09-06 14:32:45 --> Config Class Initialized
DEBUG - 2016-09-06 14:32:45 --> Hooks Class Initialized
DEBUG - 2016-09-06 14:32:45 --> Utf8 Class Initialized
DEBUG - 2016-09-06 14:32:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 14:32:45 --> URI Class Initialized
DEBUG - 2016-09-06 14:32:45 --> Router Class Initialized
DEBUG - 2016-09-06 14:32:45 --> Output Class Initialized
DEBUG - 2016-09-06 14:32:45 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 14:32:45 --> Security Class Initialized
DEBUG - 2016-09-06 14:32:45 --> Input Class Initialized
DEBUG - 2016-09-06 14:32:45 --> XSS Filtering completed
DEBUG - 2016-09-06 14:32:45 --> XSS Filtering completed
DEBUG - 2016-09-06 14:32:45 --> XSS Filtering completed
DEBUG - 2016-09-06 14:32:45 --> XSS Filtering completed
DEBUG - 2016-09-06 14:32:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 14:32:45 --> Language Class Initialized
DEBUG - 2016-09-06 14:32:45 --> Loader Class Initialized
DEBUG - 2016-09-06 14:32:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 14:32:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 14:32:45 --> Helper loaded: url_helper
DEBUG - 2016-09-06 14:32:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 14:32:45 --> Helper loaded: file_helper
DEBUG - 2016-09-06 14:32:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:32:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 14:32:46 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 14:32:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:32:46 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 14:32:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 14:32:46 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:32:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 14:32:46 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:32:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 14:32:46 --> Helper loaded: form_helper
DEBUG - 2016-09-06 14:32:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 14:32:46 --> Helper loaded: security_helper
DEBUG - 2016-09-06 14:32:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:32:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 14:32:46 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 14:32:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:32:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 14:32:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 14:32:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 14:32:46 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 14:32:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:32:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 14:32:46 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 14:32:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:32:46 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 14:32:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 14:32:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 14:32:46 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 14:32:46 --> Database Driver Class Initialized
DEBUG - 2016-09-06 14:32:46 --> Session Class Initialized
DEBUG - 2016-09-06 14:32:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 14:32:46 --> Helper loaded: string_helper
DEBUG - 2016-09-06 14:32:46 --> Session routines successfully run
DEBUG - 2016-09-06 14:32:46 --> Native_session Class Initialized
DEBUG - 2016-09-06 14:32:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 14:32:46 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:32:46 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:32:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 14:32:46 --> Controller Class Initialized
DEBUG - 2016-09-06 14:32:46 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 14:32:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 14:32:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 14:32:46 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:32:46 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:32:46 --> User Agent Class Initialized
DEBUG - 2016-09-06 14:32:46 --> Model Class Initialized
DEBUG - 2016-09-06 14:32:46 --> Model Class Initialized
DEBUG - 2016-09-06 14:32:46 --> Model Class Initialized
DEBUG - 2016-09-06 14:32:46 --> Model Class Initialized
DEBUG - 2016-09-06 14:32:46 --> Model Class Initialized
DEBUG - 2016-09-06 14:32:46 --> Model Class Initialized
DEBUG - 2016-09-06 14:32:46 --> Model Class Initialized
DEBUG - 2016-09-06 14:32:47 --> Model Class Initialized
ERROR - 2016-09-06 14:32:47 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 14:32:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-06 14:32:47 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:32:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 14:32:47 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-06 14:32:47 --> Config Class Initialized
DEBUG - 2016-09-06 14:32:47 --> Hooks Class Initialized
DEBUG - 2016-09-06 14:32:47 --> Utf8 Class Initialized
DEBUG - 2016-09-06 14:32:47 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 14:32:47 --> URI Class Initialized
DEBUG - 2016-09-06 14:32:47 --> Router Class Initialized
DEBUG - 2016-09-06 14:32:47 --> No URI present. Default controller set.
DEBUG - 2016-09-06 14:32:47 --> Output Class Initialized
DEBUG - 2016-09-06 14:32:47 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 14:32:47 --> Security Class Initialized
DEBUG - 2016-09-06 14:32:47 --> Input Class Initialized
DEBUG - 2016-09-06 14:32:47 --> XSS Filtering completed
DEBUG - 2016-09-06 14:32:47 --> XSS Filtering completed
DEBUG - 2016-09-06 14:32:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 14:32:47 --> Language Class Initialized
DEBUG - 2016-09-06 14:32:47 --> Loader Class Initialized
DEBUG - 2016-09-06 14:32:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 14:32:47 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 14:32:47 --> Helper loaded: url_helper
DEBUG - 2016-09-06 14:32:47 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 14:32:47 --> Helper loaded: file_helper
DEBUG - 2016-09-06 14:32:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:32:47 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 14:32:47 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 14:32:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:32:47 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 14:32:47 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 14:32:47 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:32:47 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 14:32:47 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:32:47 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 14:32:47 --> Helper loaded: form_helper
DEBUG - 2016-09-06 14:32:47 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 14:32:47 --> Helper loaded: security_helper
DEBUG - 2016-09-06 14:32:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:32:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 14:32:47 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 14:32:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:32:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 14:32:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 14:32:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 14:32:47 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 14:32:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:32:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 14:32:47 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 14:32:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:32:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 14:32:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 14:32:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 14:32:48 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 14:32:48 --> Database Driver Class Initialized
DEBUG - 2016-09-06 14:32:48 --> Session Class Initialized
DEBUG - 2016-09-06 14:32:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 14:32:48 --> Helper loaded: string_helper
DEBUG - 2016-09-06 14:32:48 --> Session routines successfully run
DEBUG - 2016-09-06 14:32:48 --> Native_session Class Initialized
DEBUG - 2016-09-06 14:32:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 14:32:48 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:32:48 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:32:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 14:32:48 --> Controller Class Initialized
DEBUG - 2016-09-06 14:32:48 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 14:32:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 14:32:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 14:32:48 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:32:48 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:32:48 --> User Agent Class Initialized
DEBUG - 2016-09-06 14:32:48 --> Model Class Initialized
DEBUG - 2016-09-06 14:32:48 --> Model Class Initialized
DEBUG - 2016-09-06 14:32:48 --> Model Class Initialized
ERROR - 2016-09-06 14:32:48 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 14:32:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-06 14:32:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 14:32:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 14:32:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 14:32:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 14:32:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 14:32:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 14:32:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 14:32:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 14:32:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 14:32:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 14:32:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-06 14:32:48 --> Final output sent to browser
DEBUG - 2016-09-06 14:32:48 --> Total execution time: 1.3808
DEBUG - 2016-09-06 14:32:53 --> Config Class Initialized
DEBUG - 2016-09-06 14:32:53 --> Hooks Class Initialized
DEBUG - 2016-09-06 14:32:53 --> Utf8 Class Initialized
DEBUG - 2016-09-06 14:32:53 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 14:32:53 --> URI Class Initialized
DEBUG - 2016-09-06 14:32:53 --> Router Class Initialized
DEBUG - 2016-09-06 14:32:53 --> Output Class Initialized
DEBUG - 2016-09-06 14:32:53 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 14:32:53 --> Security Class Initialized
DEBUG - 2016-09-06 14:32:53 --> Input Class Initialized
DEBUG - 2016-09-06 14:32:53 --> XSS Filtering completed
DEBUG - 2016-09-06 14:32:53 --> XSS Filtering completed
DEBUG - 2016-09-06 14:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 14:32:53 --> Language Class Initialized
DEBUG - 2016-09-06 14:32:53 --> Loader Class Initialized
DEBUG - 2016-09-06 14:32:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 14:32:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 14:32:53 --> Helper loaded: url_helper
DEBUG - 2016-09-06 14:32:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 14:32:53 --> Helper loaded: file_helper
DEBUG - 2016-09-06 14:32:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:32:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 14:32:54 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 14:32:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:32:54 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 14:32:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 14:32:54 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:32:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 14:32:54 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:32:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 14:32:54 --> Helper loaded: form_helper
DEBUG - 2016-09-06 14:32:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 14:32:54 --> Helper loaded: security_helper
DEBUG - 2016-09-06 14:32:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:32:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 14:32:54 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 14:32:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:32:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 14:32:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 14:32:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 14:32:54 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 14:32:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:32:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 14:32:54 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 14:32:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:32:54 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 14:32:54 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 14:32:54 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 14:32:54 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 14:32:54 --> Database Driver Class Initialized
DEBUG - 2016-09-06 14:32:54 --> Session Class Initialized
DEBUG - 2016-09-06 14:32:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 14:32:54 --> Helper loaded: string_helper
DEBUG - 2016-09-06 14:32:54 --> Session routines successfully run
DEBUG - 2016-09-06 14:32:54 --> Native_session Class Initialized
DEBUG - 2016-09-06 14:32:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 14:32:54 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:32:54 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:32:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 14:32:54 --> Controller Class Initialized
DEBUG - 2016-09-06 14:32:54 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 14:32:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 14:32:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 14:32:54 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:32:54 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:32:54 --> User Agent Class Initialized
DEBUG - 2016-09-06 14:32:54 --> Model Class Initialized
DEBUG - 2016-09-06 14:32:54 --> Model Class Initialized
DEBUG - 2016-09-06 14:32:54 --> Model Class Initialized
DEBUG - 2016-09-06 14:32:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-09-06 14:32:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 14:32:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 14:32:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 14:32:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 14:32:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 14:32:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 14:32:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 14:32:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 14:32:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 14:32:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 14:32:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 14:32:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 14:32:55 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-09-06 14:32:55 --> Final output sent to browser
DEBUG - 2016-09-06 14:32:55 --> Total execution time: 1.3461
DEBUG - 2016-09-06 14:32:58 --> Config Class Initialized
DEBUG - 2016-09-06 14:32:59 --> Hooks Class Initialized
DEBUG - 2016-09-06 14:32:59 --> Utf8 Class Initialized
DEBUG - 2016-09-06 14:32:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 14:32:59 --> URI Class Initialized
DEBUG - 2016-09-06 14:32:59 --> Router Class Initialized
DEBUG - 2016-09-06 14:32:59 --> Output Class Initialized
DEBUG - 2016-09-06 14:32:59 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 14:32:59 --> Security Class Initialized
DEBUG - 2016-09-06 14:32:59 --> Input Class Initialized
DEBUG - 2016-09-06 14:32:59 --> XSS Filtering completed
DEBUG - 2016-09-06 14:32:59 --> XSS Filtering completed
DEBUG - 2016-09-06 14:32:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 14:32:59 --> Language Class Initialized
DEBUG - 2016-09-06 14:32:59 --> Loader Class Initialized
DEBUG - 2016-09-06 14:32:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 14:32:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 14:32:59 --> Helper loaded: url_helper
DEBUG - 2016-09-06 14:32:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 14:32:59 --> Helper loaded: file_helper
DEBUG - 2016-09-06 14:32:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:32:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 14:32:59 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 14:32:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:32:59 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 14:32:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 14:32:59 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:32:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 14:32:59 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:32:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 14:32:59 --> Helper loaded: form_helper
DEBUG - 2016-09-06 14:32:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 14:32:59 --> Helper loaded: security_helper
DEBUG - 2016-09-06 14:32:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:32:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 14:32:59 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 14:32:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:32:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 14:32:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 14:32:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 14:32:59 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 14:32:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:32:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 14:32:59 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 14:32:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:32:59 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 14:32:59 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 14:32:59 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 14:32:59 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 14:32:59 --> Database Driver Class Initialized
DEBUG - 2016-09-06 14:33:00 --> Session Class Initialized
DEBUG - 2016-09-06 14:33:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 14:33:00 --> Helper loaded: string_helper
DEBUG - 2016-09-06 14:33:00 --> Session routines successfully run
DEBUG - 2016-09-06 14:33:00 --> Native_session Class Initialized
DEBUG - 2016-09-06 14:33:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 14:33:00 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:33:00 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:33:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 14:33:00 --> Controller Class Initialized
DEBUG - 2016-09-06 14:33:00 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 14:33:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 14:33:00 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 14:33:00 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:33:00 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:33:00 --> User Agent Class Initialized
DEBUG - 2016-09-06 14:33:00 --> Model Class Initialized
DEBUG - 2016-09-06 14:33:00 --> Model Class Initialized
DEBUG - 2016-09-06 14:33:00 --> Model Class Initialized
DEBUG - 2016-09-06 14:33:00 --> Model Class Initialized
DEBUG - 2016-09-06 14:33:00 --> Model Class Initialized
DEBUG - 2016-09-06 14:33:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-06 14:33:01 --> Pagination Class Initialized
DEBUG - 2016-09-06 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-06 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/index.php
DEBUG - 2016-09-06 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-09-06 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-09-06 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 14:33:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 14:33:01 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c2a3e0401bd35d4fcac4bae5f9412231
DEBUG - 2016-09-06 14:33:01 --> Final output sent to browser
DEBUG - 2016-09-06 14:33:01 --> Total execution time: 2.2935
DEBUG - 2016-09-06 14:33:03 --> Config Class Initialized
DEBUG - 2016-09-06 14:33:03 --> Hooks Class Initialized
DEBUG - 2016-09-06 14:33:03 --> Utf8 Class Initialized
DEBUG - 2016-09-06 14:33:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 14:33:03 --> URI Class Initialized
DEBUG - 2016-09-06 14:33:03 --> Router Class Initialized
DEBUG - 2016-09-06 14:33:03 --> Output Class Initialized
DEBUG - 2016-09-06 14:33:03 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 14:33:03 --> Security Class Initialized
DEBUG - 2016-09-06 14:33:03 --> Input Class Initialized
DEBUG - 2016-09-06 14:33:03 --> XSS Filtering completed
DEBUG - 2016-09-06 14:33:03 --> XSS Filtering completed
DEBUG - 2016-09-06 14:33:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 14:33:03 --> Language Class Initialized
DEBUG - 2016-09-06 14:33:03 --> Loader Class Initialized
DEBUG - 2016-09-06 14:33:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 14:33:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 14:33:03 --> Helper loaded: url_helper
DEBUG - 2016-09-06 14:33:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 14:33:03 --> Helper loaded: file_helper
DEBUG - 2016-09-06 14:33:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:33:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 14:33:03 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 14:33:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:33:03 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 14:33:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 14:33:03 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:33:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 14:33:03 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:33:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 14:33:03 --> Helper loaded: form_helper
DEBUG - 2016-09-06 14:33:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 14:33:03 --> Helper loaded: security_helper
DEBUG - 2016-09-06 14:33:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:33:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 14:33:03 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 14:33:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:33:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 14:33:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 14:33:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 14:33:03 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 14:33:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:33:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 14:33:04 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 14:33:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:33:04 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 14:33:04 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 14:33:04 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 14:33:04 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 14:33:04 --> Database Driver Class Initialized
DEBUG - 2016-09-06 14:33:04 --> Session Class Initialized
DEBUG - 2016-09-06 14:33:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 14:33:04 --> Helper loaded: string_helper
DEBUG - 2016-09-06 14:33:04 --> Session routines successfully run
DEBUG - 2016-09-06 14:33:04 --> Native_session Class Initialized
DEBUG - 2016-09-06 14:33:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 14:33:04 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:33:04 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:33:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 14:33:04 --> Controller Class Initialized
DEBUG - 2016-09-06 14:33:04 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 14:33:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 14:33:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 14:33:04 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:33:04 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:33:04 --> User Agent Class Initialized
DEBUG - 2016-09-06 14:33:04 --> Model Class Initialized
DEBUG - 2016-09-06 14:33:04 --> Model Class Initialized
DEBUG - 2016-09-06 14:33:04 --> Model Class Initialized
DEBUG - 2016-09-06 14:33:04 --> Model Class Initialized
DEBUG - 2016-09-06 14:33:04 --> Model Class Initialized
DEBUG - 2016-09-06 14:33:04 --> Model Class Initialized
DEBUG - 2016-09-06 14:33:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-06 14:33:04 --> Pagination Class Initialized
DEBUG - 2016-09-06 14:33:04 --> Model Class Initialized
DEBUG - 2016-09-06 14:33:04 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-06 14:33:04 --> Model Class Initialized
DEBUG - 2016-09-06 14:33:05 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-06 14:33:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/golongan_pegawai.php
DEBUG - 2016-09-06 14:33:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/skpd_pegawai.php
DEBUG - 2016-09-06 14:33:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-09-06 14:33:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-09-06 14:33:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 14:33:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 14:33:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 14:33:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 14:33:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-09-06 14:33:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 14:33:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 14:33:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 14:33:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 14:33:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 14:33:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 14:33:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-09-06 14:33:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 14:33:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 14:33:05 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-09-06 14:33:05 --> Final output sent to browser
DEBUG - 2016-09-06 14:33:05 --> Total execution time: 2.0234
DEBUG - 2016-09-06 14:34:25 --> Config Class Initialized
DEBUG - 2016-09-06 14:34:25 --> Hooks Class Initialized
DEBUG - 2016-09-06 14:34:25 --> Utf8 Class Initialized
DEBUG - 2016-09-06 14:34:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 14:34:25 --> URI Class Initialized
DEBUG - 2016-09-06 14:34:25 --> Router Class Initialized
DEBUG - 2016-09-06 14:34:25 --> Output Class Initialized
DEBUG - 2016-09-06 14:34:25 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 14:34:25 --> Security Class Initialized
DEBUG - 2016-09-06 14:34:25 --> Input Class Initialized
DEBUG - 2016-09-06 14:34:25 --> XSS Filtering completed
DEBUG - 2016-09-06 14:34:25 --> XSS Filtering completed
DEBUG - 2016-09-06 14:34:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 14:34:25 --> Language Class Initialized
DEBUG - 2016-09-06 14:34:25 --> Loader Class Initialized
DEBUG - 2016-09-06 14:34:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 14:34:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 14:34:25 --> Helper loaded: url_helper
DEBUG - 2016-09-06 14:34:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 14:34:25 --> Helper loaded: file_helper
DEBUG - 2016-09-06 14:34:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:34:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 14:34:25 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 14:34:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:34:25 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 14:34:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 14:34:25 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:34:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 14:34:25 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:34:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 14:34:25 --> Helper loaded: form_helper
DEBUG - 2016-09-06 14:34:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 14:34:26 --> Helper loaded: security_helper
DEBUG - 2016-09-06 14:34:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:34:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 14:34:26 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 14:34:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:34:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 14:34:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 14:34:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 14:34:26 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 14:34:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:34:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 14:34:26 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 14:34:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:34:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 14:34:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 14:34:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 14:34:26 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 14:34:26 --> Database Driver Class Initialized
DEBUG - 2016-09-06 14:34:26 --> Session Class Initialized
DEBUG - 2016-09-06 14:34:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 14:34:26 --> Helper loaded: string_helper
DEBUG - 2016-09-06 14:34:26 --> Session routines successfully run
DEBUG - 2016-09-06 14:34:26 --> Native_session Class Initialized
DEBUG - 2016-09-06 14:34:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 14:34:26 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:34:26 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:34:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 14:34:26 --> Controller Class Initialized
DEBUG - 2016-09-06 14:34:26 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 14:34:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 14:34:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 14:34:26 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:34:26 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:34:26 --> User Agent Class Initialized
DEBUG - 2016-09-06 14:34:26 --> Model Class Initialized
DEBUG - 2016-09-06 14:34:26 --> Model Class Initialized
DEBUG - 2016-09-06 14:34:26 --> Model Class Initialized
DEBUG - 2016-09-06 14:34:26 --> Model Class Initialized
DEBUG - 2016-09-06 14:34:26 --> Model Class Initialized
DEBUG - 2016-09-06 14:34:26 --> Model Class Initialized
DEBUG - 2016-09-06 14:34:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-06 14:34:26 --> Pagination Class Initialized
DEBUG - 2016-09-06 14:34:26 --> Model Class Initialized
DEBUG - 2016-09-06 14:34:26 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-06 14:34:26 --> Model Class Initialized
DEBUG - 2016-09-06 14:34:26 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-06 14:34:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-09-06 14:34:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-09-06 14:34:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 14:34:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 14:34:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 14:34:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 14:34:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-09-06 14:34:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 14:34:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 14:34:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 14:34:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 14:34:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 14:34:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 14:34:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-09-06 14:34:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 14:34:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 14:34:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8831ce6c9d71df0982ba758fc243a3b8
DEBUG - 2016-09-06 14:34:27 --> Final output sent to browser
DEBUG - 2016-09-06 14:34:27 --> Total execution time: 1.6660
DEBUG - 2016-09-06 14:34:48 --> Config Class Initialized
DEBUG - 2016-09-06 14:34:48 --> Hooks Class Initialized
DEBUG - 2016-09-06 14:34:48 --> Utf8 Class Initialized
DEBUG - 2016-09-06 14:34:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 14:34:48 --> URI Class Initialized
DEBUG - 2016-09-06 14:34:48 --> Router Class Initialized
DEBUG - 2016-09-06 14:34:48 --> Output Class Initialized
DEBUG - 2016-09-06 14:34:48 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 14:34:48 --> Security Class Initialized
DEBUG - 2016-09-06 14:34:48 --> Input Class Initialized
DEBUG - 2016-09-06 14:34:48 --> XSS Filtering completed
DEBUG - 2016-09-06 14:34:48 --> XSS Filtering completed
DEBUG - 2016-09-06 14:34:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 14:34:48 --> Language Class Initialized
DEBUG - 2016-09-06 14:34:48 --> Loader Class Initialized
DEBUG - 2016-09-06 14:34:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 14:34:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 14:34:48 --> Helper loaded: url_helper
DEBUG - 2016-09-06 14:34:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 14:34:48 --> Helper loaded: file_helper
DEBUG - 2016-09-06 14:34:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:34:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 14:34:48 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 14:34:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:34:48 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 14:34:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 14:34:49 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:34:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 14:34:49 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:34:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 14:34:49 --> Helper loaded: form_helper
DEBUG - 2016-09-06 14:34:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 14:34:49 --> Helper loaded: security_helper
DEBUG - 2016-09-06 14:34:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:34:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 14:34:49 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 14:34:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:34:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 14:34:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 14:34:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 14:34:49 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 14:34:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:34:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 14:34:49 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 14:34:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:34:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 14:34:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 14:34:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 14:34:49 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 14:34:49 --> Database Driver Class Initialized
DEBUG - 2016-09-06 14:34:49 --> Session Class Initialized
DEBUG - 2016-09-06 14:34:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 14:34:49 --> Helper loaded: string_helper
DEBUG - 2016-09-06 14:34:49 --> Session routines successfully run
DEBUG - 2016-09-06 14:34:49 --> Native_session Class Initialized
DEBUG - 2016-09-06 14:34:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 14:34:49 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:34:49 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:34:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 14:34:49 --> Controller Class Initialized
DEBUG - 2016-09-06 14:34:49 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 14:34:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 14:34:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 14:34:49 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:34:49 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:34:49 --> User Agent Class Initialized
DEBUG - 2016-09-06 14:34:49 --> Model Class Initialized
DEBUG - 2016-09-06 14:34:49 --> Model Class Initialized
DEBUG - 2016-09-06 14:34:49 --> Model Class Initialized
DEBUG - 2016-09-06 14:34:49 --> Model Class Initialized
DEBUG - 2016-09-06 14:34:49 --> Model Class Initialized
DEBUG - 2016-09-06 14:34:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-06 14:34:50 --> Pagination Class Initialized
DEBUG - 2016-09-06 14:34:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-06 14:34:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_ttd/index.php
DEBUG - 2016-09-06 14:34:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 14:34:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 14:34:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 14:34:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 14:34:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_ttd/js/index_js.php
DEBUG - 2016-09-06 14:34:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 14:34:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 14:34:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 14:34:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 14:34:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 14:34:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 14:34:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_ttd/js/index_js.php
DEBUG - 2016-09-06 14:34:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 14:34:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 14:34:50 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/57d0db215062cedca2b4c7c8b724c691
DEBUG - 2016-09-06 14:34:50 --> Final output sent to browser
DEBUG - 2016-09-06 14:34:50 --> Total execution time: 1.6088
DEBUG - 2016-09-06 14:36:35 --> Config Class Initialized
DEBUG - 2016-09-06 14:36:35 --> Hooks Class Initialized
DEBUG - 2016-09-06 14:36:35 --> Utf8 Class Initialized
DEBUG - 2016-09-06 14:36:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 14:36:35 --> URI Class Initialized
DEBUG - 2016-09-06 14:36:35 --> Router Class Initialized
DEBUG - 2016-09-06 14:36:35 --> Output Class Initialized
DEBUG - 2016-09-06 14:36:35 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 14:36:35 --> Security Class Initialized
DEBUG - 2016-09-06 14:36:35 --> Input Class Initialized
DEBUG - 2016-09-06 14:36:35 --> XSS Filtering completed
DEBUG - 2016-09-06 14:36:35 --> XSS Filtering completed
DEBUG - 2016-09-06 14:36:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 14:36:35 --> Language Class Initialized
DEBUG - 2016-09-06 14:36:35 --> Loader Class Initialized
DEBUG - 2016-09-06 14:36:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 14:36:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 14:36:35 --> Helper loaded: url_helper
DEBUG - 2016-09-06 14:36:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 14:36:35 --> Helper loaded: file_helper
DEBUG - 2016-09-06 14:36:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:36:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 14:36:35 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 14:36:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:36:35 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 14:36:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 14:36:35 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:36:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 14:36:35 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:36:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 14:36:35 --> Helper loaded: form_helper
DEBUG - 2016-09-06 14:36:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 14:36:36 --> Helper loaded: security_helper
DEBUG - 2016-09-06 14:36:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:36:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 14:36:36 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 14:36:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:36:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 14:36:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 14:36:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 14:36:36 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 14:36:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:36:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 14:36:36 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 14:36:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:36:36 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 14:36:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 14:36:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 14:36:36 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 14:36:36 --> Database Driver Class Initialized
DEBUG - 2016-09-06 14:36:36 --> Session Class Initialized
DEBUG - 2016-09-06 14:36:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 14:36:36 --> Helper loaded: string_helper
DEBUG - 2016-09-06 14:36:36 --> Session routines successfully run
DEBUG - 2016-09-06 14:36:36 --> Native_session Class Initialized
DEBUG - 2016-09-06 14:36:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 14:36:36 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:36:36 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:36:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 14:36:36 --> Controller Class Initialized
DEBUG - 2016-09-06 14:36:36 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 14:36:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 14:36:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 14:36:36 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:36:36 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:36:36 --> User Agent Class Initialized
DEBUG - 2016-09-06 14:36:36 --> Model Class Initialized
DEBUG - 2016-09-06 14:36:36 --> Model Class Initialized
DEBUG - 2016-09-06 14:36:36 --> Model Class Initialized
DEBUG - 2016-09-06 14:36:36 --> Model Class Initialized
DEBUG - 2016-09-06 14:36:36 --> Model Class Initialized
DEBUG - 2016-09-06 14:36:36 --> Model Class Initialized
DEBUG - 2016-09-06 14:36:36 --> Model Class Initialized
ERROR - 2016-09-06 14:36:36 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 14:36:36 --> Model Class Initialized
DEBUG - 2016-09-06 14:36:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-06 14:36:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 14:36:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 14:36:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 14:36:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 14:36:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 14:36:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 14:36:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 14:36:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 14:36:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 14:36:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 14:36:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/cba4eb322824061885f5ce1834e9f5f7
DEBUG - 2016-09-06 14:36:37 --> Final output sent to browser
DEBUG - 2016-09-06 14:36:37 --> Total execution time: 1.7039
DEBUG - 2016-09-06 14:36:43 --> Config Class Initialized
DEBUG - 2016-09-06 14:36:43 --> Hooks Class Initialized
DEBUG - 2016-09-06 14:36:43 --> Utf8 Class Initialized
DEBUG - 2016-09-06 14:36:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 14:36:43 --> URI Class Initialized
DEBUG - 2016-09-06 14:36:43 --> Router Class Initialized
DEBUG - 2016-09-06 14:36:43 --> Output Class Initialized
DEBUG - 2016-09-06 14:36:43 --> Security Class Initialized
DEBUG - 2016-09-06 14:36:43 --> Input Class Initialized
DEBUG - 2016-09-06 14:36:43 --> XSS Filtering completed
DEBUG - 2016-09-06 14:36:43 --> XSS Filtering completed
DEBUG - 2016-09-06 14:36:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 14:36:43 --> Language Class Initialized
DEBUG - 2016-09-06 14:36:44 --> Loader Class Initialized
DEBUG - 2016-09-06 14:36:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 14:36:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 14:36:44 --> Helper loaded: url_helper
DEBUG - 2016-09-06 14:36:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 14:36:44 --> Helper loaded: file_helper
DEBUG - 2016-09-06 14:36:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:36:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 14:36:44 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 14:36:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:36:44 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 14:36:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 14:36:44 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:36:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 14:36:44 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:36:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 14:36:44 --> Helper loaded: form_helper
DEBUG - 2016-09-06 14:36:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 14:36:44 --> Helper loaded: security_helper
DEBUG - 2016-09-06 14:36:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:36:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 14:36:44 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 14:36:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:36:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 14:36:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 14:36:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 14:36:44 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 14:36:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:36:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 14:36:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 14:36:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:36:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 14:36:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 14:36:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 14:36:44 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 14:36:44 --> Database Driver Class Initialized
DEBUG - 2016-09-06 14:36:44 --> Session Class Initialized
DEBUG - 2016-09-06 14:36:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 14:36:44 --> Helper loaded: string_helper
DEBUG - 2016-09-06 14:36:44 --> Session routines successfully run
DEBUG - 2016-09-06 14:36:44 --> Native_session Class Initialized
DEBUG - 2016-09-06 14:36:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 14:36:44 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:36:44 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:36:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 14:36:44 --> Controller Class Initialized
DEBUG - 2016-09-06 14:36:44 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 14:36:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 14:36:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 14:36:45 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:36:45 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:36:45 --> User Agent Class Initialized
DEBUG - 2016-09-06 14:36:45 --> Model Class Initialized
DEBUG - 2016-09-06 14:36:45 --> Model Class Initialized
DEBUG - 2016-09-06 14:36:45 --> Model Class Initialized
DEBUG - 2016-09-06 14:36:45 --> Model Class Initialized
DEBUG - 2016-09-06 14:36:45 --> Model Class Initialized
DEBUG - 2016-09-06 14:36:45 --> Model Class Initialized
DEBUG - 2016-09-06 14:36:45 --> Model Class Initialized
ERROR - 2016-09-06 14:36:45 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 14:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-06 14:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 14:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 14:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 14:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 14:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 14:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 14:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 14:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 14:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 14:36:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 14:36:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d29529b40c93fb36eb50a0451f097038
DEBUG - 2016-09-06 14:36:45 --> Final output sent to browser
DEBUG - 2016-09-06 14:36:45 --> Total execution time: 1.5387
DEBUG - 2016-09-06 14:37:28 --> Config Class Initialized
DEBUG - 2016-09-06 14:37:28 --> Hooks Class Initialized
DEBUG - 2016-09-06 14:37:28 --> Utf8 Class Initialized
DEBUG - 2016-09-06 14:37:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 14:37:28 --> URI Class Initialized
DEBUG - 2016-09-06 14:37:28 --> Router Class Initialized
DEBUG - 2016-09-06 14:37:28 --> Output Class Initialized
DEBUG - 2016-09-06 14:37:28 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 14:37:28 --> Security Class Initialized
DEBUG - 2016-09-06 14:37:28 --> Input Class Initialized
DEBUG - 2016-09-06 14:37:28 --> XSS Filtering completed
DEBUG - 2016-09-06 14:37:28 --> XSS Filtering completed
DEBUG - 2016-09-06 14:37:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 14:37:28 --> Language Class Initialized
DEBUG - 2016-09-06 14:37:28 --> Loader Class Initialized
DEBUG - 2016-09-06 14:37:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 14:37:28 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 14:37:28 --> Helper loaded: url_helper
DEBUG - 2016-09-06 14:37:28 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 14:37:28 --> Helper loaded: file_helper
DEBUG - 2016-09-06 14:37:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:37:28 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 14:37:28 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 14:37:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:37:28 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 14:37:28 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 14:37:28 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:37:28 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 14:37:28 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:37:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 14:37:28 --> Helper loaded: form_helper
DEBUG - 2016-09-06 14:37:28 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 14:37:28 --> Helper loaded: security_helper
DEBUG - 2016-09-06 14:37:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:37:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 14:37:28 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 14:37:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:37:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 14:37:29 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 14:37:29 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 14:37:29 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 14:37:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:37:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 14:37:29 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 14:37:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:37:29 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 14:37:29 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 14:37:29 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 14:37:29 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 14:37:29 --> Database Driver Class Initialized
DEBUG - 2016-09-06 14:37:29 --> Session Class Initialized
DEBUG - 2016-09-06 14:37:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 14:37:29 --> Helper loaded: string_helper
DEBUG - 2016-09-06 14:37:29 --> Session routines successfully run
DEBUG - 2016-09-06 14:37:29 --> Native_session Class Initialized
DEBUG - 2016-09-06 14:37:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 14:37:29 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:37:29 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:37:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 14:37:29 --> Controller Class Initialized
DEBUG - 2016-09-06 14:37:29 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 14:37:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 14:37:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 14:37:29 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:37:29 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:37:29 --> User Agent Class Initialized
DEBUG - 2016-09-06 14:37:29 --> Model Class Initialized
DEBUG - 2016-09-06 14:37:29 --> Model Class Initialized
DEBUG - 2016-09-06 14:37:29 --> Model Class Initialized
DEBUG - 2016-09-06 14:37:29 --> Model Class Initialized
DEBUG - 2016-09-06 14:37:29 --> Model Class Initialized
DEBUG - 2016-09-06 14:37:29 --> Model Class Initialized
DEBUG - 2016-09-06 14:37:29 --> Model Class Initialized
ERROR - 2016-09-06 14:37:29 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 14:37:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-06 14:37:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 14:37:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 14:37:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 14:37:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 14:37:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 14:37:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 14:37:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 14:37:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 14:37:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 14:37:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 14:37:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d29529b40c93fb36eb50a0451f097038
DEBUG - 2016-09-06 14:37:30 --> Final output sent to browser
DEBUG - 2016-09-06 14:37:30 --> Total execution time: 1.5673
DEBUG - 2016-09-06 14:37:31 --> Config Class Initialized
DEBUG - 2016-09-06 14:37:31 --> Hooks Class Initialized
DEBUG - 2016-09-06 14:37:31 --> Utf8 Class Initialized
DEBUG - 2016-09-06 14:37:31 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 14:37:31 --> URI Class Initialized
DEBUG - 2016-09-06 14:37:31 --> Router Class Initialized
DEBUG - 2016-09-06 14:37:31 --> Output Class Initialized
DEBUG - 2016-09-06 14:37:31 --> Security Class Initialized
DEBUG - 2016-09-06 14:37:31 --> Input Class Initialized
DEBUG - 2016-09-06 14:37:31 --> XSS Filtering completed
DEBUG - 2016-09-06 14:37:32 --> XSS Filtering completed
DEBUG - 2016-09-06 14:37:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 14:37:32 --> Language Class Initialized
DEBUG - 2016-09-06 14:37:32 --> Loader Class Initialized
DEBUG - 2016-09-06 14:37:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 14:37:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 14:37:32 --> Helper loaded: url_helper
DEBUG - 2016-09-06 14:37:32 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 14:37:32 --> Helper loaded: file_helper
DEBUG - 2016-09-06 14:37:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:37:32 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 14:37:32 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 14:37:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:37:32 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 14:37:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 14:37:32 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:37:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 14:37:32 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:37:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 14:37:32 --> Helper loaded: form_helper
DEBUG - 2016-09-06 14:37:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 14:37:32 --> Helper loaded: security_helper
DEBUG - 2016-09-06 14:37:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:37:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 14:37:32 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 14:37:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:37:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 14:37:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 14:37:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 14:37:32 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 14:37:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:37:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 14:37:32 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 14:37:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:37:32 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 14:37:32 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 14:37:32 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 14:37:32 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 14:37:32 --> Database Driver Class Initialized
DEBUG - 2016-09-06 14:37:32 --> Session Class Initialized
DEBUG - 2016-09-06 14:37:32 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 14:37:32 --> Helper loaded: string_helper
DEBUG - 2016-09-06 14:37:32 --> Session routines successfully run
DEBUG - 2016-09-06 14:37:32 --> Native_session Class Initialized
DEBUG - 2016-09-06 14:37:32 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 14:37:33 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:37:33 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:37:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 14:37:33 --> Controller Class Initialized
DEBUG - 2016-09-06 14:37:33 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 14:37:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 14:37:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 14:37:33 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:37:33 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:37:33 --> User Agent Class Initialized
DEBUG - 2016-09-06 14:37:33 --> Model Class Initialized
DEBUG - 2016-09-06 14:37:33 --> Model Class Initialized
DEBUG - 2016-09-06 14:37:33 --> Model Class Initialized
DEBUG - 2016-09-06 14:37:33 --> Model Class Initialized
DEBUG - 2016-09-06 14:37:33 --> Model Class Initialized
DEBUG - 2016-09-06 14:37:33 --> Model Class Initialized
DEBUG - 2016-09-06 14:37:33 --> Model Class Initialized
ERROR - 2016-09-06 14:37:33 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 14:39:01 --> Config Class Initialized
DEBUG - 2016-09-06 14:39:01 --> Hooks Class Initialized
DEBUG - 2016-09-06 14:39:01 --> Utf8 Class Initialized
DEBUG - 2016-09-06 14:39:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 14:39:01 --> URI Class Initialized
DEBUG - 2016-09-06 14:39:01 --> Router Class Initialized
DEBUG - 2016-09-06 14:39:01 --> Output Class Initialized
DEBUG - 2016-09-06 14:39:01 --> Security Class Initialized
DEBUG - 2016-09-06 14:39:01 --> Input Class Initialized
DEBUG - 2016-09-06 14:39:01 --> XSS Filtering completed
DEBUG - 2016-09-06 14:39:01 --> XSS Filtering completed
DEBUG - 2016-09-06 14:39:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 14:39:01 --> Language Class Initialized
DEBUG - 2016-09-06 14:39:01 --> Loader Class Initialized
DEBUG - 2016-09-06 14:39:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 14:39:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 14:39:01 --> Helper loaded: url_helper
DEBUG - 2016-09-06 14:39:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 14:39:01 --> Helper loaded: file_helper
DEBUG - 2016-09-06 14:39:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:39:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 14:39:01 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 14:39:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:39:02 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 14:39:02 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 14:39:02 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:39:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 14:39:02 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:39:02 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 14:39:02 --> Helper loaded: form_helper
DEBUG - 2016-09-06 14:39:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 14:39:02 --> Helper loaded: security_helper
DEBUG - 2016-09-06 14:39:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:39:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 14:39:02 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 14:39:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:39:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 14:39:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 14:39:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 14:39:02 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 14:39:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:39:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 14:39:02 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 14:39:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:39:02 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 14:39:02 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 14:39:02 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 14:39:02 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 14:39:02 --> Database Driver Class Initialized
DEBUG - 2016-09-06 14:39:02 --> Session Class Initialized
DEBUG - 2016-09-06 14:39:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 14:39:02 --> Helper loaded: string_helper
DEBUG - 2016-09-06 14:39:02 --> Session routines successfully run
DEBUG - 2016-09-06 14:39:02 --> Native_session Class Initialized
DEBUG - 2016-09-06 14:39:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 14:39:02 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:39:02 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:39:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 14:39:02 --> Controller Class Initialized
DEBUG - 2016-09-06 14:39:02 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 14:39:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 14:39:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 14:39:02 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:39:02 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:39:02 --> User Agent Class Initialized
DEBUG - 2016-09-06 14:39:02 --> Model Class Initialized
DEBUG - 2016-09-06 14:39:02 --> Model Class Initialized
DEBUG - 2016-09-06 14:39:02 --> Model Class Initialized
DEBUG - 2016-09-06 14:39:03 --> Model Class Initialized
DEBUG - 2016-09-06 14:39:03 --> Model Class Initialized
DEBUG - 2016-09-06 14:39:03 --> Model Class Initialized
DEBUG - 2016-09-06 14:39:03 --> Model Class Initialized
ERROR - 2016-09-06 14:39:03 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 14:41:09 --> Config Class Initialized
DEBUG - 2016-09-06 14:41:09 --> Hooks Class Initialized
DEBUG - 2016-09-06 14:41:09 --> Utf8 Class Initialized
DEBUG - 2016-09-06 14:41:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 14:41:09 --> URI Class Initialized
DEBUG - 2016-09-06 14:41:09 --> Router Class Initialized
DEBUG - 2016-09-06 14:41:09 --> Output Class Initialized
DEBUG - 2016-09-06 14:41:09 --> Security Class Initialized
DEBUG - 2016-09-06 14:41:09 --> Input Class Initialized
DEBUG - 2016-09-06 14:41:09 --> XSS Filtering completed
DEBUG - 2016-09-06 14:41:09 --> XSS Filtering completed
DEBUG - 2016-09-06 14:41:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 14:41:10 --> Language Class Initialized
DEBUG - 2016-09-06 14:41:10 --> Loader Class Initialized
DEBUG - 2016-09-06 14:41:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 14:41:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 14:41:10 --> Helper loaded: url_helper
DEBUG - 2016-09-06 14:41:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 14:41:10 --> Helper loaded: file_helper
DEBUG - 2016-09-06 14:41:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:41:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 14:41:10 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 14:41:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:41:10 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 14:41:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 14:41:10 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:41:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 14:41:10 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:41:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 14:41:10 --> Helper loaded: form_helper
DEBUG - 2016-09-06 14:41:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 14:41:10 --> Helper loaded: security_helper
DEBUG - 2016-09-06 14:41:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:41:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 14:41:10 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 14:41:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:41:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 14:41:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 14:41:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 14:41:10 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 14:41:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:41:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 14:41:10 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 14:41:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:41:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 14:41:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 14:41:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 14:41:10 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 14:41:10 --> Database Driver Class Initialized
DEBUG - 2016-09-06 14:41:10 --> Session Class Initialized
DEBUG - 2016-09-06 14:41:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 14:41:10 --> Helper loaded: string_helper
DEBUG - 2016-09-06 14:41:10 --> Session routines successfully run
DEBUG - 2016-09-06 14:41:10 --> Native_session Class Initialized
DEBUG - 2016-09-06 14:41:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 14:41:10 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:41:10 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:41:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 14:41:11 --> Controller Class Initialized
DEBUG - 2016-09-06 14:41:11 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 14:41:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 14:41:11 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 14:41:11 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:41:11 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:41:11 --> User Agent Class Initialized
DEBUG - 2016-09-06 14:41:11 --> Model Class Initialized
DEBUG - 2016-09-06 14:41:11 --> Model Class Initialized
DEBUG - 2016-09-06 14:41:11 --> Model Class Initialized
DEBUG - 2016-09-06 14:41:11 --> Model Class Initialized
DEBUG - 2016-09-06 14:41:11 --> Model Class Initialized
DEBUG - 2016-09-06 14:41:11 --> Model Class Initialized
DEBUG - 2016-09-06 14:41:11 --> Model Class Initialized
ERROR - 2016-09-06 14:41:11 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 14:41:17 --> Config Class Initialized
DEBUG - 2016-09-06 14:41:17 --> Hooks Class Initialized
DEBUG - 2016-09-06 14:41:17 --> Utf8 Class Initialized
DEBUG - 2016-09-06 14:41:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 14:41:17 --> URI Class Initialized
DEBUG - 2016-09-06 14:41:17 --> Router Class Initialized
DEBUG - 2016-09-06 14:41:17 --> Output Class Initialized
DEBUG - 2016-09-06 14:41:17 --> Security Class Initialized
DEBUG - 2016-09-06 14:41:17 --> Input Class Initialized
DEBUG - 2016-09-06 14:41:17 --> XSS Filtering completed
DEBUG - 2016-09-06 14:41:17 --> XSS Filtering completed
DEBUG - 2016-09-06 14:41:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 14:41:17 --> Language Class Initialized
DEBUG - 2016-09-06 14:41:17 --> Loader Class Initialized
DEBUG - 2016-09-06 14:41:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 14:41:17 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 14:41:17 --> Helper loaded: url_helper
DEBUG - 2016-09-06 14:41:17 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 14:41:17 --> Helper loaded: file_helper
DEBUG - 2016-09-06 14:41:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:41:17 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 14:41:17 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 14:41:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:41:17 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 14:41:17 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 14:41:18 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:41:18 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 14:41:18 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:41:18 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 14:41:18 --> Helper loaded: form_helper
DEBUG - 2016-09-06 14:41:18 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 14:41:18 --> Helper loaded: security_helper
DEBUG - 2016-09-06 14:41:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:41:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 14:41:18 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 14:41:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:41:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 14:41:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 14:41:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 14:41:18 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 14:41:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:41:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 14:41:18 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 14:41:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:41:18 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 14:41:18 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 14:41:18 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 14:41:18 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 14:41:18 --> Database Driver Class Initialized
DEBUG - 2016-09-06 14:41:18 --> Session Class Initialized
DEBUG - 2016-09-06 14:41:18 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 14:41:18 --> Helper loaded: string_helper
DEBUG - 2016-09-06 14:41:18 --> Session routines successfully run
DEBUG - 2016-09-06 14:41:18 --> Native_session Class Initialized
DEBUG - 2016-09-06 14:41:18 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 14:41:18 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:41:18 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:41:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 14:41:18 --> Controller Class Initialized
DEBUG - 2016-09-06 14:41:18 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 14:41:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 14:41:18 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 14:41:18 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:41:18 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:41:18 --> User Agent Class Initialized
DEBUG - 2016-09-06 14:41:18 --> Model Class Initialized
DEBUG - 2016-09-06 14:41:18 --> Model Class Initialized
DEBUG - 2016-09-06 14:41:18 --> Model Class Initialized
DEBUG - 2016-09-06 14:41:18 --> Model Class Initialized
DEBUG - 2016-09-06 14:41:18 --> Model Class Initialized
DEBUG - 2016-09-06 14:41:19 --> Model Class Initialized
DEBUG - 2016-09-06 14:41:19 --> Model Class Initialized
ERROR - 2016-09-06 14:41:19 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
ERROR - 2016-09-06 14:41:19 --> Severity: Notice  --> Undefined offset: 1 E:\www\GitHub\2016APSIDIKA\application\controllers\front_end\fdaftar_diklat.php 47
DEBUG - 2016-09-06 14:42:23 --> Config Class Initialized
DEBUG - 2016-09-06 14:42:23 --> Hooks Class Initialized
DEBUG - 2016-09-06 14:42:23 --> Utf8 Class Initialized
DEBUG - 2016-09-06 14:42:23 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 14:42:23 --> URI Class Initialized
DEBUG - 2016-09-06 14:42:23 --> Router Class Initialized
DEBUG - 2016-09-06 14:42:23 --> Output Class Initialized
DEBUG - 2016-09-06 14:42:23 --> Security Class Initialized
DEBUG - 2016-09-06 14:42:23 --> Input Class Initialized
DEBUG - 2016-09-06 14:42:23 --> XSS Filtering completed
DEBUG - 2016-09-06 14:42:23 --> XSS Filtering completed
DEBUG - 2016-09-06 14:42:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 14:42:23 --> Language Class Initialized
DEBUG - 2016-09-06 14:42:23 --> Loader Class Initialized
DEBUG - 2016-09-06 14:42:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 14:42:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 14:42:24 --> Helper loaded: url_helper
DEBUG - 2016-09-06 14:42:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 14:42:24 --> Helper loaded: file_helper
DEBUG - 2016-09-06 14:42:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:42:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 14:42:24 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 14:42:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 14:42:24 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 14:42:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 14:42:24 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:42:24 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 14:42:24 --> Helper loaded: common_helper
DEBUG - 2016-09-06 14:42:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 14:42:24 --> Helper loaded: form_helper
DEBUG - 2016-09-06 14:42:24 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 14:42:24 --> Helper loaded: security_helper
DEBUG - 2016-09-06 14:42:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:42:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 14:42:24 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 14:42:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 14:42:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 14:42:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 14:42:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 14:42:24 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 14:42:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:42:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 14:42:24 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 14:42:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 14:42:24 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 14:42:24 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 14:42:24 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 14:42:24 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 14:42:24 --> Database Driver Class Initialized
DEBUG - 2016-09-06 14:42:24 --> Session Class Initialized
DEBUG - 2016-09-06 14:42:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 14:42:24 --> Helper loaded: string_helper
DEBUG - 2016-09-06 14:42:24 --> Session routines successfully run
DEBUG - 2016-09-06 14:42:24 --> Native_session Class Initialized
DEBUG - 2016-09-06 14:42:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 14:42:24 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:42:24 --> Form Validation Class Initialized
DEBUG - 2016-09-06 14:42:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 14:42:24 --> Controller Class Initialized
DEBUG - 2016-09-06 14:42:25 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 14:42:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 14:42:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 14:42:25 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:42:25 --> Carabiner: library configured.
DEBUG - 2016-09-06 14:42:25 --> User Agent Class Initialized
DEBUG - 2016-09-06 14:42:25 --> Model Class Initialized
DEBUG - 2016-09-06 14:42:25 --> Model Class Initialized
DEBUG - 2016-09-06 14:42:25 --> Model Class Initialized
DEBUG - 2016-09-06 14:42:25 --> Model Class Initialized
DEBUG - 2016-09-06 14:42:25 --> Model Class Initialized
DEBUG - 2016-09-06 14:42:25 --> Model Class Initialized
DEBUG - 2016-09-06 14:42:25 --> Model Class Initialized
ERROR - 2016-09-06 14:42:25 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 15:07:11 --> Config Class Initialized
DEBUG - 2016-09-06 15:07:11 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:07:11 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:07:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:07:11 --> URI Class Initialized
DEBUG - 2016-09-06 15:07:11 --> Router Class Initialized
DEBUG - 2016-09-06 15:07:11 --> Output Class Initialized
DEBUG - 2016-09-06 15:07:11 --> Security Class Initialized
DEBUG - 2016-09-06 15:07:11 --> Input Class Initialized
DEBUG - 2016-09-06 15:07:11 --> XSS Filtering completed
DEBUG - 2016-09-06 15:07:11 --> XSS Filtering completed
DEBUG - 2016-09-06 15:07:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:07:11 --> Language Class Initialized
DEBUG - 2016-09-06 15:07:11 --> Loader Class Initialized
DEBUG - 2016-09-06 15:07:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:07:12 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:07:12 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:07:12 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:07:12 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:07:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:07:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:07:12 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:07:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:07:12 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:07:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:07:12 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:07:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:07:12 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:07:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:07:12 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:07:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:07:12 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:07:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:07:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:07:12 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:07:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:07:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:07:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:07:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:07:12 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:07:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:07:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:07:12 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:07:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:07:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:07:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:07:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:07:12 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:07:12 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:07:12 --> Session Class Initialized
DEBUG - 2016-09-06 15:07:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:07:12 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:07:12 --> Session routines successfully run
DEBUG - 2016-09-06 15:07:12 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:07:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:07:12 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:07:12 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:07:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:07:13 --> Controller Class Initialized
DEBUG - 2016-09-06 15:07:13 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:07:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:07:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:07:13 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:07:13 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:07:13 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:07:13 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:13 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:13 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:13 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:13 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:13 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:13 --> Model Class Initialized
ERROR - 2016-09-06 15:07:13 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 15:07:19 --> Config Class Initialized
DEBUG - 2016-09-06 15:07:19 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:07:19 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:07:19 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:07:19 --> URI Class Initialized
DEBUG - 2016-09-06 15:07:19 --> Router Class Initialized
DEBUG - 2016-09-06 15:07:19 --> Output Class Initialized
DEBUG - 2016-09-06 15:07:19 --> Security Class Initialized
DEBUG - 2016-09-06 15:07:19 --> Input Class Initialized
DEBUG - 2016-09-06 15:07:19 --> XSS Filtering completed
DEBUG - 2016-09-06 15:07:19 --> XSS Filtering completed
DEBUG - 2016-09-06 15:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:07:19 --> Language Class Initialized
DEBUG - 2016-09-06 15:07:19 --> Loader Class Initialized
DEBUG - 2016-09-06 15:07:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:07:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:07:19 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:07:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:07:19 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:07:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:07:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:07:20 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:07:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:07:20 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:07:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:07:20 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:07:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:07:20 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:07:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:07:20 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:07:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:07:20 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:07:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:07:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:07:20 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:07:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:07:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:07:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:07:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:07:20 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:07:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:07:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:07:20 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:07:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:07:20 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:07:20 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:07:20 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:07:20 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:07:20 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:07:20 --> Session Class Initialized
DEBUG - 2016-09-06 15:07:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:07:20 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:07:20 --> Session routines successfully run
DEBUG - 2016-09-06 15:07:20 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:07:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:07:20 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:07:20 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:07:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:07:20 --> Controller Class Initialized
DEBUG - 2016-09-06 15:07:20 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:07:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:07:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:07:20 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:07:20 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:07:20 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:07:21 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:21 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:21 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:21 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:21 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:21 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:21 --> Model Class Initialized
ERROR - 2016-09-06 15:07:21 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 15:07:21 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:21 --> Config Class Initialized
DEBUG - 2016-09-06 15:07:22 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:07:22 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:07:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:07:22 --> URI Class Initialized
DEBUG - 2016-09-06 15:07:22 --> Router Class Initialized
DEBUG - 2016-09-06 15:07:22 --> Output Class Initialized
DEBUG - 2016-09-06 15:07:22 --> Security Class Initialized
DEBUG - 2016-09-06 15:07:22 --> Input Class Initialized
DEBUG - 2016-09-06 15:07:22 --> XSS Filtering completed
DEBUG - 2016-09-06 15:07:22 --> XSS Filtering completed
DEBUG - 2016-09-06 15:07:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:07:22 --> Language Class Initialized
DEBUG - 2016-09-06 15:07:22 --> Loader Class Initialized
DEBUG - 2016-09-06 15:07:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:07:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:07:22 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:07:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:07:22 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:07:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:07:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:07:22 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:07:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:07:22 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:07:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:07:22 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:07:22 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:07:22 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:07:22 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:07:22 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:07:22 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:07:22 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:07:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:07:22 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:07:22 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:07:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:07:22 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:07:22 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:07:22 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:07:22 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:07:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:07:22 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:07:22 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:07:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:07:22 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:07:22 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:07:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:07:23 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:07:23 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:07:23 --> Session Class Initialized
DEBUG - 2016-09-06 15:07:23 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:07:23 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:07:23 --> Session routines successfully run
DEBUG - 2016-09-06 15:07:23 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:07:23 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:07:23 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:07:23 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:07:23 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:07:23 --> Controller Class Initialized
DEBUG - 2016-09-06 15:07:23 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:07:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:07:23 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:07:23 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:07:23 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:07:23 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:07:23 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:23 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:23 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:23 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:23 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:23 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:23 --> Model Class Initialized
ERROR - 2016-09-06 15:07:23 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 15:07:24 --> Config Class Initialized
DEBUG - 2016-09-06 15:07:24 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:07:24 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:07:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:07:24 --> URI Class Initialized
DEBUG - 2016-09-06 15:07:24 --> Router Class Initialized
DEBUG - 2016-09-06 15:07:24 --> Output Class Initialized
DEBUG - 2016-09-06 15:07:24 --> Security Class Initialized
DEBUG - 2016-09-06 15:07:24 --> Input Class Initialized
DEBUG - 2016-09-06 15:07:24 --> XSS Filtering completed
DEBUG - 2016-09-06 15:07:24 --> XSS Filtering completed
DEBUG - 2016-09-06 15:07:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:07:24 --> Language Class Initialized
DEBUG - 2016-09-06 15:07:24 --> Loader Class Initialized
DEBUG - 2016-09-06 15:07:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:07:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:07:24 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:07:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:07:24 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:07:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:07:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:07:24 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:07:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:07:25 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:07:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:07:25 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:07:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:07:25 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:07:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:07:25 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:07:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:07:25 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:07:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:07:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:07:25 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:07:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:07:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:07:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:07:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:07:25 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:07:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:07:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:07:25 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:07:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:07:25 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:07:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:07:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:07:25 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:07:25 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:07:25 --> Session Class Initialized
DEBUG - 2016-09-06 15:07:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:07:25 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:07:25 --> Session routines successfully run
DEBUG - 2016-09-06 15:07:25 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:07:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:07:25 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:07:25 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:07:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:07:25 --> Controller Class Initialized
DEBUG - 2016-09-06 15:07:25 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:07:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:07:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:07:25 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:07:25 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:07:25 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:07:26 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:26 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:26 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:26 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:26 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:26 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:26 --> Model Class Initialized
ERROR - 2016-09-06 15:07:26 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 15:07:26 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:47 --> Config Class Initialized
DEBUG - 2016-09-06 15:07:47 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:07:47 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:07:47 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:07:47 --> URI Class Initialized
DEBUG - 2016-09-06 15:07:47 --> Router Class Initialized
DEBUG - 2016-09-06 15:07:47 --> Output Class Initialized
DEBUG - 2016-09-06 15:07:47 --> Security Class Initialized
DEBUG - 2016-09-06 15:07:47 --> Input Class Initialized
DEBUG - 2016-09-06 15:07:47 --> XSS Filtering completed
DEBUG - 2016-09-06 15:07:47 --> XSS Filtering completed
DEBUG - 2016-09-06 15:07:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:07:47 --> Language Class Initialized
DEBUG - 2016-09-06 15:07:47 --> Loader Class Initialized
DEBUG - 2016-09-06 15:07:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:07:47 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:07:47 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:07:47 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:07:47 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:07:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:07:47 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:07:47 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:07:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:07:47 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:07:47 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:07:47 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:07:47 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:07:47 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:07:47 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:07:47 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:07:47 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:07:47 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:07:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:07:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:07:47 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:07:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:07:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:07:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:07:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:07:47 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:07:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:07:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:07:48 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:07:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:07:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:07:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:07:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:07:48 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:07:48 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:07:48 --> Session Class Initialized
DEBUG - 2016-09-06 15:07:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:07:48 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:07:48 --> Session routines successfully run
DEBUG - 2016-09-06 15:07:48 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:07:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:07:48 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:07:48 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:07:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:07:48 --> Controller Class Initialized
DEBUG - 2016-09-06 15:07:48 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:07:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:07:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:07:48 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:07:48 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:07:48 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:07:48 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:48 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:48 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:48 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:48 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:48 --> Model Class Initialized
DEBUG - 2016-09-06 15:07:48 --> Model Class Initialized
ERROR - 2016-09-06 15:07:48 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 15:07:48 --> Model Class Initialized
DEBUG - 2016-09-06 15:12:40 --> Config Class Initialized
DEBUG - 2016-09-06 15:12:40 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:12:40 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:12:40 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:12:40 --> URI Class Initialized
DEBUG - 2016-09-06 15:12:40 --> Router Class Initialized
DEBUG - 2016-09-06 15:12:40 --> Output Class Initialized
DEBUG - 2016-09-06 15:12:40 --> Security Class Initialized
DEBUG - 2016-09-06 15:12:40 --> Input Class Initialized
DEBUG - 2016-09-06 15:12:40 --> XSS Filtering completed
DEBUG - 2016-09-06 15:12:40 --> XSS Filtering completed
DEBUG - 2016-09-06 15:12:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:12:40 --> Language Class Initialized
DEBUG - 2016-09-06 15:12:40 --> Loader Class Initialized
DEBUG - 2016-09-06 15:12:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:12:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:12:40 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:12:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:12:40 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:12:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:12:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:12:40 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:12:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:12:40 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:12:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:12:41 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:12:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:12:41 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:12:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:12:41 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:12:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:12:41 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:12:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:12:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:12:41 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:12:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:12:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:12:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:12:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:12:41 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:12:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:12:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:12:41 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:12:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:12:41 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:12:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:12:41 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:12:41 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:12:41 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:12:41 --> Session Class Initialized
DEBUG - 2016-09-06 15:12:41 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:12:41 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:12:41 --> Session routines successfully run
DEBUG - 2016-09-06 15:12:41 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:12:41 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:12:41 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:12:41 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:12:41 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:12:41 --> Controller Class Initialized
DEBUG - 2016-09-06 15:12:41 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:12:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:12:41 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:12:41 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:12:41 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:12:41 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:12:41 --> Model Class Initialized
DEBUG - 2016-09-06 15:12:41 --> Model Class Initialized
DEBUG - 2016-09-06 15:12:41 --> Model Class Initialized
DEBUG - 2016-09-06 15:12:42 --> Model Class Initialized
DEBUG - 2016-09-06 15:12:42 --> Model Class Initialized
DEBUG - 2016-09-06 15:12:42 --> Model Class Initialized
DEBUG - 2016-09-06 15:12:42 --> Model Class Initialized
DEBUG - 2016-09-06 15:12:42 --> Model Class Initialized
DEBUG - 2016-09-06 15:12:42 --> Model Class Initialized
DEBUG - 2016-09-06 15:12:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-06 15:12:42 --> Pagination Class Initialized
DEBUG - 2016-09-06 15:12:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-06 15:12:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-06 15:12:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 15:12:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 15:12:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:12:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 15:12:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-06 15:12:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 15:12:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 15:12:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 15:12:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 15:12:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:12:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 15:12:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-06 15:12:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 15:12:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 15:12:42 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-06 15:12:42 --> Final output sent to browser
DEBUG - 2016-09-06 15:12:42 --> Total execution time: 1.8008
DEBUG - 2016-09-06 15:12:47 --> Config Class Initialized
DEBUG - 2016-09-06 15:12:47 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:12:47 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:12:47 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:12:47 --> URI Class Initialized
DEBUG - 2016-09-06 15:12:47 --> Router Class Initialized
DEBUG - 2016-09-06 15:12:47 --> Output Class Initialized
DEBUG - 2016-09-06 15:12:47 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 15:12:47 --> Security Class Initialized
DEBUG - 2016-09-06 15:12:47 --> Input Class Initialized
DEBUG - 2016-09-06 15:12:47 --> XSS Filtering completed
DEBUG - 2016-09-06 15:12:47 --> XSS Filtering completed
DEBUG - 2016-09-06 15:12:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:12:47 --> Language Class Initialized
DEBUG - 2016-09-06 15:12:47 --> Loader Class Initialized
DEBUG - 2016-09-06 15:12:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:12:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:12:48 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:12:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:12:48 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:12:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:12:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:12:48 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:12:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:12:48 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:12:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:12:48 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:12:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:12:48 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:12:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:12:48 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:12:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:12:48 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:12:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:12:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:12:48 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:12:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:12:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:12:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:12:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:12:48 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:12:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:12:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:12:48 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:12:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:12:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:12:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:12:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:12:48 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:12:48 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:12:48 --> Session Class Initialized
DEBUG - 2016-09-06 15:12:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:12:48 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:12:48 --> Session routines successfully run
DEBUG - 2016-09-06 15:12:48 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:12:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:12:49 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:12:49 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:12:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:12:49 --> Controller Class Initialized
DEBUG - 2016-09-06 15:12:49 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:12:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:12:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:12:49 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:12:49 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:12:49 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:12:49 --> Model Class Initialized
DEBUG - 2016-09-06 15:12:49 --> Model Class Initialized
DEBUG - 2016-09-06 15:12:49 --> Model Class Initialized
DEBUG - 2016-09-06 15:12:49 --> Model Class Initialized
DEBUG - 2016-09-06 15:12:49 --> Model Class Initialized
DEBUG - 2016-09-06 15:12:49 --> Model Class Initialized
DEBUG - 2016-09-06 15:12:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-06 15:12:49 --> Pagination Class Initialized
DEBUG - 2016-09-06 15:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-06 15:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-09-06 15:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 15:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 15:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 15:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-06 15:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 15:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 15:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 15:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 15:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 15:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-06 15:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 15:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 15:12:49 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-09-06 15:12:49 --> Final output sent to browser
DEBUG - 2016-09-06 15:12:49 --> Total execution time: 1.8961
DEBUG - 2016-09-06 15:12:51 --> Config Class Initialized
DEBUG - 2016-09-06 15:12:51 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:12:51 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:12:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:12:51 --> URI Class Initialized
DEBUG - 2016-09-06 15:12:51 --> Router Class Initialized
DEBUG - 2016-09-06 15:12:51 --> Output Class Initialized
DEBUG - 2016-09-06 15:12:51 --> Security Class Initialized
DEBUG - 2016-09-06 15:12:51 --> Input Class Initialized
DEBUG - 2016-09-06 15:12:51 --> XSS Filtering completed
DEBUG - 2016-09-06 15:12:51 --> XSS Filtering completed
DEBUG - 2016-09-06 15:12:52 --> XSS Filtering completed
DEBUG - 2016-09-06 15:12:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:12:52 --> Language Class Initialized
DEBUG - 2016-09-06 15:12:52 --> Loader Class Initialized
DEBUG - 2016-09-06 15:12:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:12:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:12:52 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:12:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:12:52 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:12:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:12:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:12:52 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:12:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:12:52 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:12:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:12:52 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:12:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:12:52 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:12:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:12:52 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:12:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:12:52 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:12:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:12:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:12:52 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:12:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:12:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:12:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:12:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:12:52 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:12:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:12:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:12:52 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:12:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:12:52 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:12:52 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:12:52 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:12:52 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:12:52 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:12:52 --> Session Class Initialized
DEBUG - 2016-09-06 15:12:52 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:12:53 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:12:53 --> Session routines successfully run
DEBUG - 2016-09-06 15:12:53 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:12:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:12:53 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:12:53 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:12:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:12:53 --> Controller Class Initialized
DEBUG - 2016-09-06 15:12:53 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:12:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:12:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:12:53 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:12:53 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:12:53 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:12:53 --> Model Class Initialized
DEBUG - 2016-09-06 15:12:53 --> Model Class Initialized
DEBUG - 2016-09-06 15:12:53 --> Model Class Initialized
DEBUG - 2016-09-06 15:12:53 --> Model Class Initialized
DEBUG - 2016-09-06 15:12:53 --> Model Class Initialized
DEBUG - 2016-09-06 15:12:53 --> Model Class Initialized
DEBUG - 2016-09-06 15:12:53 --> Model Class Initialized
DEBUG - 2016-09-06 15:12:53 --> Model Class Initialized
DEBUG - 2016-09-06 15:12:53 --> Model Class Initialized
DEBUG - 2016-09-06 15:12:53 --> Model Class Initialized
ERROR - 2016-09-06 15:12:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:177) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-09-06 15:14:49 --> Config Class Initialized
DEBUG - 2016-09-06 15:14:49 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:14:49 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:14:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:14:49 --> URI Class Initialized
DEBUG - 2016-09-06 15:14:49 --> Router Class Initialized
DEBUG - 2016-09-06 15:14:49 --> Output Class Initialized
DEBUG - 2016-09-06 15:14:49 --> Security Class Initialized
DEBUG - 2016-09-06 15:14:49 --> Input Class Initialized
DEBUG - 2016-09-06 15:14:49 --> XSS Filtering completed
DEBUG - 2016-09-06 15:14:49 --> XSS Filtering completed
DEBUG - 2016-09-06 15:14:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:14:49 --> Language Class Initialized
DEBUG - 2016-09-06 15:14:49 --> Loader Class Initialized
DEBUG - 2016-09-06 15:14:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:14:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:14:50 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:14:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:14:50 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:14:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:14:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:14:50 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:14:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:14:50 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:14:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:14:50 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:14:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:14:50 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:14:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:14:50 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:14:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:14:50 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:14:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:14:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:14:50 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:14:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:14:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:14:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:14:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:14:50 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:14:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:14:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:14:50 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:14:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:14:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:14:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:14:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:14:50 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:14:50 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:14:50 --> Session Class Initialized
DEBUG - 2016-09-06 15:14:50 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:14:50 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:14:50 --> Session routines successfully run
DEBUG - 2016-09-06 15:14:50 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:14:50 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:14:50 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:14:51 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:14:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:14:51 --> Controller Class Initialized
DEBUG - 2016-09-06 15:14:51 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:14:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:14:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:14:51 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:14:51 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:14:51 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:14:51 --> Model Class Initialized
DEBUG - 2016-09-06 15:14:51 --> Model Class Initialized
DEBUG - 2016-09-06 15:14:51 --> Model Class Initialized
DEBUG - 2016-09-06 15:14:51 --> Model Class Initialized
DEBUG - 2016-09-06 15:14:51 --> Model Class Initialized
DEBUG - 2016-09-06 15:14:51 --> Model Class Initialized
DEBUG - 2016-09-06 15:14:51 --> Model Class Initialized
ERROR - 2016-09-06 15:14:51 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 15:14:51 --> Model Class Initialized
DEBUG - 2016-09-06 15:15:33 --> Config Class Initialized
DEBUG - 2016-09-06 15:15:33 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:15:33 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:15:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:15:33 --> URI Class Initialized
DEBUG - 2016-09-06 15:15:33 --> Router Class Initialized
DEBUG - 2016-09-06 15:15:33 --> Output Class Initialized
DEBUG - 2016-09-06 15:15:33 --> Security Class Initialized
DEBUG - 2016-09-06 15:15:33 --> Input Class Initialized
DEBUG - 2016-09-06 15:15:34 --> XSS Filtering completed
DEBUG - 2016-09-06 15:15:34 --> XSS Filtering completed
DEBUG - 2016-09-06 15:15:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:15:34 --> Language Class Initialized
DEBUG - 2016-09-06 15:15:34 --> Loader Class Initialized
DEBUG - 2016-09-06 15:15:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:15:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:15:34 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:15:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:15:34 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:15:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:15:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:15:34 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:15:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:15:34 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:15:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:15:34 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:15:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:15:34 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:15:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:15:34 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:15:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:15:34 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:15:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:15:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:15:34 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:15:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:15:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:15:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:15:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:15:34 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:15:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:15:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:15:34 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:15:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:15:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:15:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:15:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:15:34 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:15:34 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:15:34 --> Session Class Initialized
DEBUG - 2016-09-06 15:15:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:15:35 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:15:35 --> Session routines successfully run
DEBUG - 2016-09-06 15:15:35 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:15:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:15:35 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:15:35 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:15:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:15:35 --> Controller Class Initialized
DEBUG - 2016-09-06 15:15:35 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:15:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:15:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:15:35 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:15:35 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:15:35 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:15:35 --> Model Class Initialized
DEBUG - 2016-09-06 15:15:35 --> Model Class Initialized
DEBUG - 2016-09-06 15:15:35 --> Model Class Initialized
DEBUG - 2016-09-06 15:15:35 --> Model Class Initialized
DEBUG - 2016-09-06 15:15:35 --> Model Class Initialized
DEBUG - 2016-09-06 15:15:35 --> Model Class Initialized
DEBUG - 2016-09-06 15:15:35 --> Model Class Initialized
ERROR - 2016-09-06 15:15:35 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 15:15:35 --> Model Class Initialized
DEBUG - 2016-09-06 15:15:52 --> Config Class Initialized
DEBUG - 2016-09-06 15:15:52 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:15:52 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:15:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:15:52 --> URI Class Initialized
DEBUG - 2016-09-06 15:15:52 --> Router Class Initialized
DEBUG - 2016-09-06 15:15:52 --> Output Class Initialized
DEBUG - 2016-09-06 15:15:52 --> Security Class Initialized
DEBUG - 2016-09-06 15:15:52 --> Input Class Initialized
DEBUG - 2016-09-06 15:15:52 --> XSS Filtering completed
DEBUG - 2016-09-06 15:15:52 --> XSS Filtering completed
DEBUG - 2016-09-06 15:15:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:15:52 --> Language Class Initialized
DEBUG - 2016-09-06 15:15:52 --> Loader Class Initialized
DEBUG - 2016-09-06 15:15:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:15:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:15:53 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:15:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:15:53 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:15:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:15:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:15:53 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:15:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:15:53 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:15:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:15:53 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:15:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:15:53 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:15:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:15:53 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:15:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:15:53 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:15:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:15:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:15:53 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:15:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:15:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:15:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:15:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:15:53 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:15:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:15:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:15:53 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:15:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:15:53 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:15:53 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:15:53 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:15:53 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:15:53 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:15:53 --> Session Class Initialized
DEBUG - 2016-09-06 15:15:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:15:53 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:15:53 --> Session routines successfully run
DEBUG - 2016-09-06 15:15:53 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:15:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:15:54 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:15:54 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:15:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:15:54 --> Controller Class Initialized
DEBUG - 2016-09-06 15:15:54 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:15:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:15:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:15:54 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:15:54 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:15:54 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:15:54 --> Model Class Initialized
DEBUG - 2016-09-06 15:15:54 --> Model Class Initialized
DEBUG - 2016-09-06 15:15:54 --> Model Class Initialized
DEBUG - 2016-09-06 15:15:54 --> Model Class Initialized
DEBUG - 2016-09-06 15:15:54 --> Model Class Initialized
DEBUG - 2016-09-06 15:15:54 --> Model Class Initialized
DEBUG - 2016-09-06 15:15:54 --> Model Class Initialized
ERROR - 2016-09-06 15:15:54 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 15:15:54 --> Model Class Initialized
DEBUG - 2016-09-06 15:16:14 --> Config Class Initialized
DEBUG - 2016-09-06 15:16:14 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:16:14 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:16:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:16:14 --> URI Class Initialized
DEBUG - 2016-09-06 15:16:14 --> Router Class Initialized
DEBUG - 2016-09-06 15:16:14 --> Output Class Initialized
DEBUG - 2016-09-06 15:16:14 --> Security Class Initialized
DEBUG - 2016-09-06 15:16:14 --> Input Class Initialized
DEBUG - 2016-09-06 15:16:14 --> XSS Filtering completed
DEBUG - 2016-09-06 15:16:14 --> XSS Filtering completed
DEBUG - 2016-09-06 15:16:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:16:14 --> Language Class Initialized
DEBUG - 2016-09-06 15:16:14 --> Loader Class Initialized
DEBUG - 2016-09-06 15:16:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:16:14 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:16:14 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:16:14 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:16:14 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:16:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:16:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:16:15 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:16:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:16:15 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:16:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:16:15 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:16:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:16:15 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:16:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:16:15 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:16:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:16:15 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:16:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:16:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:16:15 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:16:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:16:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:16:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:16:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:16:15 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:16:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:16:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:16:15 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:16:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:16:15 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:16:15 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:16:15 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:16:15 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:16:15 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:16:15 --> Session Class Initialized
DEBUG - 2016-09-06 15:16:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:16:15 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:16:15 --> Session routines successfully run
DEBUG - 2016-09-06 15:16:15 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:16:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:16:15 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:16:15 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:16:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:16:15 --> Controller Class Initialized
DEBUG - 2016-09-06 15:16:15 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:16:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:16:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:16:16 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:16:16 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:16:16 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:16:16 --> Model Class Initialized
DEBUG - 2016-09-06 15:16:16 --> Model Class Initialized
DEBUG - 2016-09-06 15:16:16 --> Model Class Initialized
DEBUG - 2016-09-06 15:16:16 --> Model Class Initialized
DEBUG - 2016-09-06 15:16:16 --> Model Class Initialized
DEBUG - 2016-09-06 15:16:16 --> Model Class Initialized
DEBUG - 2016-09-06 15:16:16 --> Model Class Initialized
ERROR - 2016-09-06 15:16:16 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 15:16:16 --> Model Class Initialized
DEBUG - 2016-09-06 15:17:26 --> Config Class Initialized
DEBUG - 2016-09-06 15:17:26 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:17:26 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:17:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:17:26 --> URI Class Initialized
DEBUG - 2016-09-06 15:17:26 --> Router Class Initialized
DEBUG - 2016-09-06 15:17:26 --> Output Class Initialized
DEBUG - 2016-09-06 15:17:26 --> Security Class Initialized
DEBUG - 2016-09-06 15:17:26 --> Input Class Initialized
DEBUG - 2016-09-06 15:17:26 --> XSS Filtering completed
DEBUG - 2016-09-06 15:17:26 --> XSS Filtering completed
DEBUG - 2016-09-06 15:17:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:17:26 --> Language Class Initialized
DEBUG - 2016-09-06 15:17:26 --> Loader Class Initialized
DEBUG - 2016-09-06 15:17:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:17:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:17:26 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:17:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:17:26 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:17:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:17:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:17:26 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:17:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:17:26 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:17:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:17:26 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:17:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:17:26 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:17:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:17:26 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:17:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:17:27 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:17:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:17:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:17:27 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:17:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:17:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:17:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:17:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:17:27 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:17:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:17:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:17:27 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:17:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:17:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:17:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:17:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:17:27 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:17:27 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:17:27 --> Session Class Initialized
DEBUG - 2016-09-06 15:17:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:17:27 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:17:27 --> Session routines successfully run
DEBUG - 2016-09-06 15:17:27 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:17:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:17:27 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:17:27 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:17:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:17:27 --> Controller Class Initialized
DEBUG - 2016-09-06 15:17:27 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:17:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:17:27 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:17:27 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:17:27 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:17:27 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:17:27 --> Model Class Initialized
DEBUG - 2016-09-06 15:17:27 --> Model Class Initialized
DEBUG - 2016-09-06 15:17:27 --> Model Class Initialized
DEBUG - 2016-09-06 15:17:27 --> Model Class Initialized
DEBUG - 2016-09-06 15:17:27 --> Model Class Initialized
DEBUG - 2016-09-06 15:17:27 --> Model Class Initialized
DEBUG - 2016-09-06 15:17:28 --> Model Class Initialized
ERROR - 2016-09-06 15:17:28 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 15:17:28 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:14 --> Config Class Initialized
DEBUG - 2016-09-06 15:20:14 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:20:14 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:20:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:20:14 --> URI Class Initialized
DEBUG - 2016-09-06 15:20:14 --> Router Class Initialized
DEBUG - 2016-09-06 15:20:14 --> Output Class Initialized
DEBUG - 2016-09-06 15:20:14 --> Security Class Initialized
DEBUG - 2016-09-06 15:20:14 --> Input Class Initialized
DEBUG - 2016-09-06 15:20:14 --> XSS Filtering completed
DEBUG - 2016-09-06 15:20:14 --> XSS Filtering completed
DEBUG - 2016-09-06 15:20:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:20:14 --> Language Class Initialized
DEBUG - 2016-09-06 15:20:14 --> Loader Class Initialized
DEBUG - 2016-09-06 15:20:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:20:14 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:20:14 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:20:14 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:20:14 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:20:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:20:14 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:20:14 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:20:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:20:14 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:20:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:20:14 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:20:14 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:20:14 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:20:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:20:14 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:20:14 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:20:14 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:20:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:20:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:20:15 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:20:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:20:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:20:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:20:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:20:15 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:20:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:20:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:20:15 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:20:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:20:15 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:20:15 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:20:15 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:20:15 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:20:15 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:20:15 --> Session Class Initialized
DEBUG - 2016-09-06 15:20:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:20:15 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:20:15 --> Session routines successfully run
DEBUG - 2016-09-06 15:20:15 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:20:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:20:15 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:20:15 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:20:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:20:15 --> Controller Class Initialized
DEBUG - 2016-09-06 15:20:15 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:20:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:20:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:20:15 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:20:15 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:20:15 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:20:15 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:15 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:15 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:15 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:15 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:15 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:15 --> Model Class Initialized
ERROR - 2016-09-06 15:20:16 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 15:20:16 --> Model Class Initialized
ERROR - 2016-09-06 15:20:16 --> Severity: Notice  --> Undefined variable: force_limit E:\www\GitHub\2016APSIDIKA\application\models\model_tr_peserta_diklat.php 274
ERROR - 2016-09-06 15:20:16 --> Severity: Notice  --> Undefined variable: force_offset E:\www\GitHub\2016APSIDIKA\application\models\model_tr_peserta_diklat.php 274
DEBUG - 2016-09-06 15:20:37 --> Config Class Initialized
DEBUG - 2016-09-06 15:20:37 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:20:37 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:20:37 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:20:37 --> URI Class Initialized
DEBUG - 2016-09-06 15:20:37 --> Router Class Initialized
DEBUG - 2016-09-06 15:20:37 --> Output Class Initialized
DEBUG - 2016-09-06 15:20:37 --> Security Class Initialized
DEBUG - 2016-09-06 15:20:37 --> Input Class Initialized
DEBUG - 2016-09-06 15:20:37 --> XSS Filtering completed
DEBUG - 2016-09-06 15:20:37 --> XSS Filtering completed
DEBUG - 2016-09-06 15:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:20:37 --> Language Class Initialized
DEBUG - 2016-09-06 15:20:37 --> Loader Class Initialized
DEBUG - 2016-09-06 15:20:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:20:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:20:37 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:20:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:20:37 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:20:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:20:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:20:37 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:20:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:20:37 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:20:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:20:37 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:20:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:20:38 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:20:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:20:38 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:20:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:20:38 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:20:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:20:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:20:38 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:20:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:20:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:20:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:20:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:20:38 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:20:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:20:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:20:38 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:20:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:20:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:20:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:20:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:20:38 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:20:38 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:20:38 --> Session Class Initialized
DEBUG - 2016-09-06 15:20:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:20:38 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:20:38 --> Session routines successfully run
DEBUG - 2016-09-06 15:20:38 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:20:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:20:38 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:20:38 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:20:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:20:38 --> Controller Class Initialized
DEBUG - 2016-09-06 15:20:38 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:20:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:20:38 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:20:38 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:20:38 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:20:38 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:20:39 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:39 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:39 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:39 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:39 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:39 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:39 --> Model Class Initialized
ERROR - 2016-09-06 15:20:39 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 15:20:39 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:47 --> Config Class Initialized
DEBUG - 2016-09-06 15:20:47 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:20:47 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:20:47 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:20:47 --> URI Class Initialized
DEBUG - 2016-09-06 15:20:47 --> Router Class Initialized
DEBUG - 2016-09-06 15:20:47 --> Output Class Initialized
DEBUG - 2016-09-06 15:20:47 --> Security Class Initialized
DEBUG - 2016-09-06 15:20:47 --> Input Class Initialized
DEBUG - 2016-09-06 15:20:47 --> XSS Filtering completed
DEBUG - 2016-09-06 15:20:47 --> XSS Filtering completed
DEBUG - 2016-09-06 15:20:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:20:47 --> Language Class Initialized
DEBUG - 2016-09-06 15:20:47 --> Loader Class Initialized
DEBUG - 2016-09-06 15:20:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:20:47 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:20:47 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:20:47 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:20:47 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:20:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:20:47 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:20:47 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:20:47 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:20:47 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:20:47 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:20:47 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:20:47 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:20:47 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:20:47 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:20:47 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:20:47 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:20:47 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:20:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:20:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:20:47 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:20:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:20:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:20:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:20:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:20:48 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:20:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:20:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:20:48 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:20:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:20:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:20:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:20:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:20:48 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:20:48 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:20:48 --> Session Class Initialized
DEBUG - 2016-09-06 15:20:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:20:48 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:20:48 --> Session routines successfully run
DEBUG - 2016-09-06 15:20:48 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:20:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:20:48 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:20:48 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:20:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:20:48 --> Controller Class Initialized
DEBUG - 2016-09-06 15:20:48 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:20:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:20:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:20:48 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:20:48 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:20:48 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:20:48 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:48 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:48 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:48 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:48 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:48 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:48 --> Model Class Initialized
ERROR - 2016-09-06 15:20:48 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 15:20:48 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:55 --> Config Class Initialized
DEBUG - 2016-09-06 15:20:55 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:20:55 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:20:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:20:56 --> URI Class Initialized
DEBUG - 2016-09-06 15:20:56 --> Router Class Initialized
DEBUG - 2016-09-06 15:20:56 --> Output Class Initialized
DEBUG - 2016-09-06 15:20:56 --> Security Class Initialized
DEBUG - 2016-09-06 15:20:56 --> Input Class Initialized
DEBUG - 2016-09-06 15:20:56 --> XSS Filtering completed
DEBUG - 2016-09-06 15:20:56 --> XSS Filtering completed
DEBUG - 2016-09-06 15:20:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:20:56 --> Language Class Initialized
DEBUG - 2016-09-06 15:20:56 --> Loader Class Initialized
DEBUG - 2016-09-06 15:20:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:20:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:20:56 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:20:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:20:56 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:20:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:20:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:20:56 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:20:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:20:56 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:20:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:20:56 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:20:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:20:56 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:20:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:20:56 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:20:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:20:56 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:20:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:20:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:20:56 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:20:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:20:56 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:20:56 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:20:56 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:20:56 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:20:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:20:56 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:20:56 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:20:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:20:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:20:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:20:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:20:57 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:20:57 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:20:57 --> Session Class Initialized
DEBUG - 2016-09-06 15:20:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:20:57 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:20:57 --> Session routines successfully run
DEBUG - 2016-09-06 15:20:57 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:20:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:20:57 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:20:57 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:20:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:20:57 --> Controller Class Initialized
DEBUG - 2016-09-06 15:20:57 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:20:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:20:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:20:57 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:20:57 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:20:57 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:20:57 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:57 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:57 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:57 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:57 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:57 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:57 --> Model Class Initialized
ERROR - 2016-09-06 15:20:57 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 15:20:57 --> Model Class Initialized
DEBUG - 2016-09-06 15:20:59 --> Config Class Initialized
DEBUG - 2016-09-06 15:20:59 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:21:00 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:21:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:21:00 --> URI Class Initialized
DEBUG - 2016-09-06 15:21:00 --> Router Class Initialized
DEBUG - 2016-09-06 15:21:00 --> Output Class Initialized
DEBUG - 2016-09-06 15:21:00 --> Security Class Initialized
DEBUG - 2016-09-06 15:21:00 --> Input Class Initialized
DEBUG - 2016-09-06 15:21:00 --> XSS Filtering completed
DEBUG - 2016-09-06 15:21:00 --> XSS Filtering completed
DEBUG - 2016-09-06 15:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:21:00 --> Language Class Initialized
DEBUG - 2016-09-06 15:21:00 --> Loader Class Initialized
DEBUG - 2016-09-06 15:21:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:21:00 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:21:00 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:21:00 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:21:00 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:21:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:21:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:21:00 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:21:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:21:00 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:21:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:21:00 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:21:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:21:00 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:21:00 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:21:00 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:21:00 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:21:00 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:21:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:21:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:21:00 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:21:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:21:00 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:21:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:21:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:21:00 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:21:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:21:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:21:01 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:21:01 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:21:01 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:21:01 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:21:01 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:21:01 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:21:01 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:21:01 --> Session Class Initialized
DEBUG - 2016-09-06 15:21:01 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:21:01 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:21:01 --> Session routines successfully run
DEBUG - 2016-09-06 15:21:01 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:21:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:21:01 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:21:01 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:21:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:21:01 --> Controller Class Initialized
DEBUG - 2016-09-06 15:21:01 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:21:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:21:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:21:01 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:21:01 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:21:01 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:21:01 --> Model Class Initialized
DEBUG - 2016-09-06 15:21:01 --> Model Class Initialized
DEBUG - 2016-09-06 15:21:01 --> Model Class Initialized
DEBUG - 2016-09-06 15:21:01 --> Model Class Initialized
DEBUG - 2016-09-06 15:21:01 --> Model Class Initialized
DEBUG - 2016-09-06 15:21:01 --> Model Class Initialized
DEBUG - 2016-09-06 15:21:01 --> Model Class Initialized
ERROR - 2016-09-06 15:21:01 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 15:21:01 --> Model Class Initialized
DEBUG - 2016-09-06 15:22:01 --> Config Class Initialized
DEBUG - 2016-09-06 15:22:01 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:22:01 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:22:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:22:01 --> URI Class Initialized
DEBUG - 2016-09-06 15:22:01 --> Router Class Initialized
DEBUG - 2016-09-06 15:22:01 --> Output Class Initialized
DEBUG - 2016-09-06 15:22:01 --> Security Class Initialized
DEBUG - 2016-09-06 15:22:01 --> Input Class Initialized
DEBUG - 2016-09-06 15:22:01 --> XSS Filtering completed
DEBUG - 2016-09-06 15:22:01 --> XSS Filtering completed
DEBUG - 2016-09-06 15:22:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:22:01 --> Language Class Initialized
DEBUG - 2016-09-06 15:22:01 --> Loader Class Initialized
DEBUG - 2016-09-06 15:22:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:22:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:22:01 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:22:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:22:01 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:22:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:22:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:22:01 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:22:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:22:01 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:22:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:22:01 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:22:01 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:22:01 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:22:01 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:22:01 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:22:01 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:22:01 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:22:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:22:01 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:22:01 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:22:01 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:22:01 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:22:01 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:22:01 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:22:02 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:22:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:22:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:22:02 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:22:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:22:02 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:22:02 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:22:02 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:22:02 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:22:02 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:22:02 --> Session Class Initialized
DEBUG - 2016-09-06 15:22:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:22:02 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:22:02 --> Session routines successfully run
DEBUG - 2016-09-06 15:22:02 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:22:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:22:02 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:22:02 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:22:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:22:02 --> Controller Class Initialized
DEBUG - 2016-09-06 15:22:02 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:22:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:22:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:22:02 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:22:02 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:22:02 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:22:02 --> Model Class Initialized
DEBUG - 2016-09-06 15:22:02 --> Model Class Initialized
DEBUG - 2016-09-06 15:22:02 --> Model Class Initialized
DEBUG - 2016-09-06 15:22:02 --> Model Class Initialized
DEBUG - 2016-09-06 15:22:02 --> Model Class Initialized
DEBUG - 2016-09-06 15:22:02 --> Model Class Initialized
DEBUG - 2016-09-06 15:22:02 --> Model Class Initialized
ERROR - 2016-09-06 15:22:02 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 15:22:02 --> Model Class Initialized
DEBUG - 2016-09-06 15:23:10 --> Config Class Initialized
DEBUG - 2016-09-06 15:23:10 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:23:10 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:23:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:23:10 --> URI Class Initialized
DEBUG - 2016-09-06 15:23:10 --> Router Class Initialized
DEBUG - 2016-09-06 15:23:10 --> Output Class Initialized
DEBUG - 2016-09-06 15:23:10 --> Security Class Initialized
DEBUG - 2016-09-06 15:23:10 --> Input Class Initialized
DEBUG - 2016-09-06 15:23:10 --> XSS Filtering completed
DEBUG - 2016-09-06 15:23:10 --> XSS Filtering completed
DEBUG - 2016-09-06 15:23:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:23:10 --> Language Class Initialized
DEBUG - 2016-09-06 15:23:10 --> Loader Class Initialized
DEBUG - 2016-09-06 15:23:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:23:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:23:10 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:23:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:23:10 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:23:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:23:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:23:10 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:23:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:23:10 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:23:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:23:10 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:23:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:23:10 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:23:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:23:10 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:23:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:23:10 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:23:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:23:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:23:10 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:23:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:23:11 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:23:11 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:23:11 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:23:11 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:23:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:23:11 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:23:11 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:23:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:23:11 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:23:11 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:23:11 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:23:11 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:23:11 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:23:11 --> Session Class Initialized
DEBUG - 2016-09-06 15:23:11 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:23:11 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:23:11 --> Session routines successfully run
DEBUG - 2016-09-06 15:23:11 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:23:11 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:23:11 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:23:11 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:23:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:23:11 --> Controller Class Initialized
DEBUG - 2016-09-06 15:23:11 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:23:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:23:11 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:23:11 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:23:11 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:23:11 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:23:11 --> Model Class Initialized
DEBUG - 2016-09-06 15:23:11 --> Model Class Initialized
DEBUG - 2016-09-06 15:23:12 --> Model Class Initialized
DEBUG - 2016-09-06 15:23:12 --> Model Class Initialized
DEBUG - 2016-09-06 15:23:12 --> Model Class Initialized
DEBUG - 2016-09-06 15:23:12 --> Model Class Initialized
DEBUG - 2016-09-06 15:23:12 --> Model Class Initialized
ERROR - 2016-09-06 15:23:12 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 15:23:12 --> Model Class Initialized
DEBUG - 2016-09-06 15:39:24 --> Config Class Initialized
DEBUG - 2016-09-06 15:39:24 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:39:24 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:39:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:39:24 --> URI Class Initialized
DEBUG - 2016-09-06 15:39:24 --> Router Class Initialized
DEBUG - 2016-09-06 15:39:24 --> Output Class Initialized
DEBUG - 2016-09-06 15:39:24 --> Security Class Initialized
DEBUG - 2016-09-06 15:39:24 --> Input Class Initialized
DEBUG - 2016-09-06 15:39:24 --> XSS Filtering completed
DEBUG - 2016-09-06 15:39:24 --> XSS Filtering completed
DEBUG - 2016-09-06 15:39:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:39:24 --> Language Class Initialized
DEBUG - 2016-09-06 15:39:24 --> Loader Class Initialized
DEBUG - 2016-09-06 15:39:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:39:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:39:24 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:39:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:39:24 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:39:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:39:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:39:24 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:39:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:39:24 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:39:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:39:25 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:39:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:39:25 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:39:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:39:25 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:39:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:39:25 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:39:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:39:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:39:25 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:39:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:39:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:39:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:39:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:39:25 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:39:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:39:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:39:25 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:39:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:39:25 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:39:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:39:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:39:25 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:39:25 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:39:25 --> Session Class Initialized
DEBUG - 2016-09-06 15:39:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:39:25 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:39:25 --> Session routines successfully run
DEBUG - 2016-09-06 15:39:25 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:39:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:39:25 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:39:25 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:39:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:39:25 --> Controller Class Initialized
DEBUG - 2016-09-06 15:39:25 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:39:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:39:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:39:25 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:39:26 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:39:26 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:39:26 --> Model Class Initialized
DEBUG - 2016-09-06 15:39:26 --> Model Class Initialized
DEBUG - 2016-09-06 15:39:26 --> Model Class Initialized
DEBUG - 2016-09-06 15:39:26 --> Model Class Initialized
DEBUG - 2016-09-06 15:39:26 --> Model Class Initialized
DEBUG - 2016-09-06 15:39:26 --> Model Class Initialized
DEBUG - 2016-09-06 15:39:26 --> Model Class Initialized
ERROR - 2016-09-06 15:39:26 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 15:39:26 --> Model Class Initialized
DEBUG - 2016-09-06 15:39:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_peserta.php
DEBUG - 2016-09-06 15:39:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 15:39:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:39:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 15:39:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 15:39:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 15:39:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 15:39:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:39:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 15:39:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 15:39:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 15:39:26 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e783b68888ada49788a0492715ab7534
DEBUG - 2016-09-06 15:39:26 --> Final output sent to browser
DEBUG - 2016-09-06 15:39:26 --> Total execution time: 1.9898
DEBUG - 2016-09-06 15:40:07 --> Config Class Initialized
DEBUG - 2016-09-06 15:40:07 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:40:07 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:40:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:40:07 --> URI Class Initialized
DEBUG - 2016-09-06 15:40:07 --> Router Class Initialized
DEBUG - 2016-09-06 15:40:07 --> Output Class Initialized
DEBUG - 2016-09-06 15:40:07 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 15:40:07 --> Security Class Initialized
DEBUG - 2016-09-06 15:40:07 --> Input Class Initialized
DEBUG - 2016-09-06 15:40:07 --> XSS Filtering completed
DEBUG - 2016-09-06 15:40:07 --> XSS Filtering completed
DEBUG - 2016-09-06 15:40:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:40:07 --> Language Class Initialized
DEBUG - 2016-09-06 15:40:07 --> Loader Class Initialized
DEBUG - 2016-09-06 15:40:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:40:07 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:40:07 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:40:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:40:07 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:40:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:40:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:40:07 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:40:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:40:07 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:40:07 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:40:07 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:40:07 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:40:07 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:40:07 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:40:07 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:40:07 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:40:08 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:40:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:40:08 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:40:08 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:40:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:40:08 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:40:08 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:40:08 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:40:08 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:40:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:40:08 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:40:08 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:40:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:40:08 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:40:08 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:40:08 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:40:08 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:40:08 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:40:08 --> Session Class Initialized
DEBUG - 2016-09-06 15:40:08 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:40:08 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:40:08 --> Session routines successfully run
DEBUG - 2016-09-06 15:40:08 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:40:08 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:40:08 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:40:08 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:40:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:40:08 --> Controller Class Initialized
DEBUG - 2016-09-06 15:40:08 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:40:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:40:08 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:40:09 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:40:09 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:40:09 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:40:09 --> Model Class Initialized
DEBUG - 2016-09-06 15:40:09 --> Model Class Initialized
DEBUG - 2016-09-06 15:40:09 --> Model Class Initialized
DEBUG - 2016-09-06 15:40:09 --> Model Class Initialized
DEBUG - 2016-09-06 15:40:09 --> Model Class Initialized
DEBUG - 2016-09-06 15:40:09 --> Model Class Initialized
DEBUG - 2016-09-06 15:40:09 --> Model Class Initialized
ERROR - 2016-09-06 15:40:09 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 15:40:09 --> Model Class Initialized
DEBUG - 2016-09-06 15:40:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_peserta.php
DEBUG - 2016-09-06 15:40:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 15:40:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:40:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 15:40:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 15:40:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 15:40:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 15:40:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:40:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 15:40:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 15:40:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 15:40:09 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e783b68888ada49788a0492715ab7534
DEBUG - 2016-09-06 15:40:09 --> Final output sent to browser
DEBUG - 2016-09-06 15:40:09 --> Total execution time: 2.2052
DEBUG - 2016-09-06 15:41:12 --> Config Class Initialized
DEBUG - 2016-09-06 15:41:12 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:41:12 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:41:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:41:12 --> URI Class Initialized
DEBUG - 2016-09-06 15:41:12 --> Router Class Initialized
DEBUG - 2016-09-06 15:41:12 --> Output Class Initialized
DEBUG - 2016-09-06 15:41:12 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 15:41:12 --> Security Class Initialized
DEBUG - 2016-09-06 15:41:12 --> Input Class Initialized
DEBUG - 2016-09-06 15:41:12 --> XSS Filtering completed
DEBUG - 2016-09-06 15:41:12 --> XSS Filtering completed
DEBUG - 2016-09-06 15:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:41:12 --> Language Class Initialized
DEBUG - 2016-09-06 15:41:12 --> Loader Class Initialized
DEBUG - 2016-09-06 15:41:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:41:12 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:41:12 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:41:12 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:41:12 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:41:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:41:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:41:12 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:41:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:41:12 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:41:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:41:12 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:41:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:41:12 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:41:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:41:12 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:41:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:41:12 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:41:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:41:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:41:13 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:41:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:41:13 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:41:13 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:41:13 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:41:13 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:41:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:41:13 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:41:13 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:41:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:41:13 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:41:13 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:41:13 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:41:13 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:41:13 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:41:13 --> Session Class Initialized
DEBUG - 2016-09-06 15:41:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:41:13 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:41:13 --> Session routines successfully run
DEBUG - 2016-09-06 15:41:13 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:41:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:41:13 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:41:13 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:41:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:41:13 --> Controller Class Initialized
DEBUG - 2016-09-06 15:41:13 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:41:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:41:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:41:13 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:41:13 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:41:13 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:41:13 --> Model Class Initialized
DEBUG - 2016-09-06 15:41:13 --> Model Class Initialized
DEBUG - 2016-09-06 15:41:13 --> Model Class Initialized
DEBUG - 2016-09-06 15:41:13 --> Model Class Initialized
DEBUG - 2016-09-06 15:41:13 --> Model Class Initialized
DEBUG - 2016-09-06 15:41:13 --> Model Class Initialized
DEBUG - 2016-09-06 15:41:14 --> Model Class Initialized
ERROR - 2016-09-06 15:41:14 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-06 15:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/cek_spt.php
DEBUG - 2016-09-06 15:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 15:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 15:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 15:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 15:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-06 15:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-06 15:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-06 15:41:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-06 15:41:14 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d29529b40c93fb36eb50a0451f097038
DEBUG - 2016-09-06 15:41:14 --> Final output sent to browser
DEBUG - 2016-09-06 15:41:14 --> Total execution time: 2.0093
DEBUG - 2016-09-06 15:42:32 --> Config Class Initialized
DEBUG - 2016-09-06 15:42:32 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:42:32 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:42:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:42:32 --> URI Class Initialized
DEBUG - 2016-09-06 15:42:32 --> Router Class Initialized
DEBUG - 2016-09-06 15:42:32 --> Output Class Initialized
DEBUG - 2016-09-06 15:42:32 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 15:42:32 --> Security Class Initialized
DEBUG - 2016-09-06 15:42:32 --> Input Class Initialized
DEBUG - 2016-09-06 15:42:32 --> XSS Filtering completed
DEBUG - 2016-09-06 15:42:32 --> XSS Filtering completed
DEBUG - 2016-09-06 15:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:42:32 --> Language Class Initialized
DEBUG - 2016-09-06 15:42:32 --> Loader Class Initialized
DEBUG - 2016-09-06 15:42:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:42:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:42:32 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:42:32 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:42:32 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:42:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:42:32 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:42:32 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:42:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:42:32 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:42:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:42:32 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:42:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:42:32 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:42:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:42:32 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:42:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:42:33 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:42:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:42:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:42:33 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:42:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:42:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:42:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:42:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:42:33 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:42:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:42:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:42:33 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:42:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:42:33 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:42:33 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:42:33 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:42:33 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:42:33 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:42:33 --> Session Class Initialized
DEBUG - 2016-09-06 15:42:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:42:33 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:42:33 --> Session routines successfully run
DEBUG - 2016-09-06 15:42:33 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:42:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:42:33 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:42:33 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:42:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:42:33 --> Controller Class Initialized
DEBUG - 2016-09-06 15:42:33 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:42:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:42:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:42:33 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:42:33 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:42:33 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:42:33 --> Model Class Initialized
DEBUG - 2016-09-06 15:42:33 --> Model Class Initialized
DEBUG - 2016-09-06 15:42:34 --> Model Class Initialized
DEBUG - 2016-09-06 15:42:34 --> Model Class Initialized
DEBUG - 2016-09-06 15:42:34 --> Model Class Initialized
DEBUG - 2016-09-06 15:42:34 --> Model Class Initialized
DEBUG - 2016-09-06 15:42:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-06 15:42:34 --> Pagination Class Initialized
DEBUG - 2016-09-06 15:42:34 --> Model Class Initialized
DEBUG - 2016-09-06 15:42:34 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-06 15:42:34 --> Model Class Initialized
DEBUG - 2016-09-06 15:42:34 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-06 15:42:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-09-06 15:42:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-09-06 15:42:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 15:42:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 15:42:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:42:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 15:42:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-09-06 15:42:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 15:42:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 15:42:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 15:42:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 15:42:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:42:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 15:42:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-09-06 15:42:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 15:42:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 15:42:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/3b8a012aded2aa06b38d95457bf1daeb
DEBUG - 2016-09-06 15:42:34 --> Final output sent to browser
DEBUG - 2016-09-06 15:42:34 --> Total execution time: 2.2103
DEBUG - 2016-09-06 15:44:32 --> Config Class Initialized
DEBUG - 2016-09-06 15:44:32 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:44:32 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:44:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:44:32 --> URI Class Initialized
DEBUG - 2016-09-06 15:44:32 --> Router Class Initialized
DEBUG - 2016-09-06 15:44:32 --> Output Class Initialized
DEBUG - 2016-09-06 15:44:32 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 15:44:32 --> Security Class Initialized
DEBUG - 2016-09-06 15:44:32 --> Input Class Initialized
DEBUG - 2016-09-06 15:44:33 --> XSS Filtering completed
DEBUG - 2016-09-06 15:44:33 --> XSS Filtering completed
DEBUG - 2016-09-06 15:44:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:44:33 --> Language Class Initialized
DEBUG - 2016-09-06 15:44:33 --> Loader Class Initialized
DEBUG - 2016-09-06 15:44:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:44:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:44:33 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:44:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:44:33 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:44:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:44:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:44:33 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:44:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:44:33 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:44:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:44:33 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:44:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:44:33 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:44:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:44:33 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:44:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:44:33 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:44:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:44:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:44:33 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:44:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:44:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:44:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:44:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:44:33 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:44:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:44:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:44:33 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:44:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:44:33 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:44:33 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:44:33 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:44:34 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:44:34 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:44:34 --> Session Class Initialized
DEBUG - 2016-09-06 15:44:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:44:34 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:44:34 --> Session routines successfully run
DEBUG - 2016-09-06 15:44:34 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:44:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:44:34 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:44:34 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:44:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:44:34 --> Controller Class Initialized
DEBUG - 2016-09-06 15:44:34 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:44:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:44:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:44:34 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:44:34 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:44:34 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:44:34 --> Model Class Initialized
DEBUG - 2016-09-06 15:44:34 --> Model Class Initialized
DEBUG - 2016-09-06 15:44:34 --> Model Class Initialized
DEBUG - 2016-09-06 15:44:34 --> Model Class Initialized
DEBUG - 2016-09-06 15:44:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-06 15:44:34 --> Pagination Class Initialized
DEBUG - 2016-09-06 15:44:34 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 15:44:34 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/index.php
DEBUG - 2016-09-06 15:44:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 15:44:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 15:44:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:44:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 15:44:34 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2016-09-06 15:44:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 15:44:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 15:44:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 15:44:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 15:44:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:44:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 15:44:35 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2016-09-06 15:44:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 15:44:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 15:44:35 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8118d087c6d6c5bac3947ef2cf7a3513
DEBUG - 2016-09-06 15:44:35 --> Final output sent to browser
DEBUG - 2016-09-06 15:44:35 --> Total execution time: 2.0824
DEBUG - 2016-09-06 15:48:10 --> Config Class Initialized
DEBUG - 2016-09-06 15:48:10 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:48:10 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:48:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:48:10 --> URI Class Initialized
DEBUG - 2016-09-06 15:48:10 --> Router Class Initialized
DEBUG - 2016-09-06 15:48:10 --> Output Class Initialized
DEBUG - 2016-09-06 15:48:10 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 15:48:10 --> Security Class Initialized
DEBUG - 2016-09-06 15:48:10 --> Input Class Initialized
DEBUG - 2016-09-06 15:48:10 --> XSS Filtering completed
DEBUG - 2016-09-06 15:48:10 --> XSS Filtering completed
DEBUG - 2016-09-06 15:48:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:48:10 --> Language Class Initialized
DEBUG - 2016-09-06 15:48:10 --> Loader Class Initialized
DEBUG - 2016-09-06 15:48:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:48:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:48:10 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:48:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:48:10 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:48:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:48:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:48:10 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:48:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:48:10 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:48:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:48:10 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:48:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:48:10 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:48:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:48:10 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:48:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:48:10 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:48:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:48:11 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:48:11 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:48:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:48:11 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:48:11 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:48:11 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:48:11 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:48:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:48:11 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:48:11 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:48:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:48:11 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:48:11 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:48:11 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:48:11 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:48:11 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:48:11 --> Session Class Initialized
DEBUG - 2016-09-06 15:48:11 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:48:11 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:48:11 --> Session routines successfully run
DEBUG - 2016-09-06 15:48:11 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:48:11 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:48:11 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:48:11 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:48:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:48:11 --> Controller Class Initialized
DEBUG - 2016-09-06 15:48:11 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:48:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:48:11 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:48:11 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:48:11 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:48:11 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:48:11 --> Model Class Initialized
DEBUG - 2016-09-06 15:48:11 --> Model Class Initialized
DEBUG - 2016-09-06 15:48:11 --> Model Class Initialized
DEBUG - 2016-09-06 15:48:12 --> Model Class Initialized
DEBUG - 2016-09-06 15:48:12 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 15:48:12 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/detail.php
DEBUG - 2016-09-06 15:48:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 15:48:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 15:48:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:48:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 15:48:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 15:48:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 15:48:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 15:48:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 15:48:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:48:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 15:48:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 15:48:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 15:48:12 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d87737a5c20fb6761c0cdf4e0925e468
DEBUG - 2016-09-06 15:48:12 --> Final output sent to browser
DEBUG - 2016-09-06 15:48:12 --> Total execution time: 1.9967
DEBUG - 2016-09-06 15:54:30 --> Config Class Initialized
DEBUG - 2016-09-06 15:54:30 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:54:30 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:54:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:54:30 --> URI Class Initialized
DEBUG - 2016-09-06 15:54:30 --> Router Class Initialized
DEBUG - 2016-09-06 15:54:30 --> Output Class Initialized
DEBUG - 2016-09-06 15:54:30 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 15:54:30 --> Security Class Initialized
DEBUG - 2016-09-06 15:54:30 --> Input Class Initialized
DEBUG - 2016-09-06 15:54:30 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:30 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:30 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:30 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:30 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:30 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:30 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:54:30 --> Language Class Initialized
DEBUG - 2016-09-06 15:54:30 --> Loader Class Initialized
DEBUG - 2016-09-06 15:54:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:54:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:54:30 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:54:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:54:30 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:54:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:54:31 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:54:31 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:54:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:54:31 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:54:31 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:54:31 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:54:31 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:54:31 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:54:31 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:54:31 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:54:31 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:54:31 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:54:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:54:31 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:54:31 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:54:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:54:31 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:54:31 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:54:31 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:54:31 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:54:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:54:31 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:54:31 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:54:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:54:31 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:54:31 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:54:31 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:54:31 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:54:31 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:54:31 --> Session Class Initialized
DEBUG - 2016-09-06 15:54:31 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:54:31 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:54:31 --> Session routines successfully run
DEBUG - 2016-09-06 15:54:31 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:54:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:54:32 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:54:32 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:54:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:54:32 --> Controller Class Initialized
DEBUG - 2016-09-06 15:54:32 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:54:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:54:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:54:32 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:54:32 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:54:32 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:54:32 --> Model Class Initialized
DEBUG - 2016-09-06 15:54:32 --> Model Class Initialized
DEBUG - 2016-09-06 15:54:32 --> Model Class Initialized
DEBUG - 2016-09-06 15:54:32 --> Model Class Initialized
DEBUG - 2016-09-06 15:54:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-06 15:54:32 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:54:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:54:32 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-06 15:54:32 --> Config Class Initialized
DEBUG - 2016-09-06 15:54:32 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:54:32 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:54:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:54:32 --> URI Class Initialized
DEBUG - 2016-09-06 15:54:32 --> Router Class Initialized
DEBUG - 2016-09-06 15:54:32 --> Output Class Initialized
DEBUG - 2016-09-06 15:54:32 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 15:54:32 --> Security Class Initialized
DEBUG - 2016-09-06 15:54:32 --> Input Class Initialized
DEBUG - 2016-09-06 15:54:32 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:32 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:54:33 --> Language Class Initialized
DEBUG - 2016-09-06 15:54:33 --> Loader Class Initialized
DEBUG - 2016-09-06 15:54:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:54:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:54:33 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:54:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:54:33 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:54:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:54:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:54:33 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:54:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:54:33 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:54:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:54:33 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:54:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:54:33 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:54:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:54:33 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:54:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:54:33 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:54:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:54:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:54:33 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:54:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:54:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:54:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:54:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:54:33 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:54:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:54:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:54:33 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:54:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:54:33 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:54:33 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:54:33 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:54:33 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:54:34 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:54:34 --> Session Class Initialized
DEBUG - 2016-09-06 15:54:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:54:34 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:54:34 --> Session routines successfully run
DEBUG - 2016-09-06 15:54:34 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:54:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:54:34 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:54:34 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:54:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:54:34 --> Controller Class Initialized
DEBUG - 2016-09-06 15:54:34 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:54:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:54:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:54:34 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:54:34 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:54:34 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:54:34 --> Model Class Initialized
DEBUG - 2016-09-06 15:54:34 --> Model Class Initialized
DEBUG - 2016-09-06 15:54:34 --> Model Class Initialized
DEBUG - 2016-09-06 15:54:34 --> Model Class Initialized
DEBUG - 2016-09-06 15:54:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-06 15:54:34 --> Pagination Class Initialized
DEBUG - 2016-09-06 15:54:34 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 15:54:34 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/index.php
DEBUG - 2016-09-06 15:54:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 15:54:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 15:54:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:54:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 15:54:34 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2016-09-06 15:54:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 15:54:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 15:54:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 15:54:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 15:54:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:54:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 15:54:35 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2016-09-06 15:54:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 15:54:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 15:54:35 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8118d087c6d6c5bac3947ef2cf7a3513
DEBUG - 2016-09-06 15:54:35 --> Final output sent to browser
DEBUG - 2016-09-06 15:54:35 --> Total execution time: 2.0769
DEBUG - 2016-09-06 15:54:37 --> Config Class Initialized
DEBUG - 2016-09-06 15:54:37 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:54:37 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:54:37 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:54:37 --> URI Class Initialized
DEBUG - 2016-09-06 15:54:37 --> Router Class Initialized
DEBUG - 2016-09-06 15:54:37 --> Output Class Initialized
DEBUG - 2016-09-06 15:54:37 --> Security Class Initialized
DEBUG - 2016-09-06 15:54:37 --> Input Class Initialized
DEBUG - 2016-09-06 15:54:37 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:37 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:54:38 --> Language Class Initialized
DEBUG - 2016-09-06 15:54:38 --> Loader Class Initialized
DEBUG - 2016-09-06 15:54:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:54:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:54:38 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:54:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:54:38 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:54:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:54:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:54:38 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:54:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:54:38 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:54:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:54:38 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:54:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:54:38 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:54:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:54:38 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:54:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:54:38 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:54:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:54:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:54:38 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:54:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:54:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:54:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:54:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:54:38 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:54:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:54:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:54:38 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:54:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:54:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:54:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:54:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:54:39 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:54:39 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:54:39 --> Session Class Initialized
DEBUG - 2016-09-06 15:54:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:54:39 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:54:39 --> Session routines successfully run
DEBUG - 2016-09-06 15:54:39 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:54:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:54:39 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:54:39 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:54:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:54:39 --> Controller Class Initialized
DEBUG - 2016-09-06 15:54:39 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:54:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:54:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:54:39 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:54:39 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:54:39 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:54:39 --> Model Class Initialized
DEBUG - 2016-09-06 15:54:39 --> Model Class Initialized
DEBUG - 2016-09-06 15:54:39 --> Model Class Initialized
DEBUG - 2016-09-06 15:54:39 --> Model Class Initialized
DEBUG - 2016-09-06 15:54:39 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 15:54:39 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/detail.php
DEBUG - 2016-09-06 15:54:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 15:54:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 15:54:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:54:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 15:54:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 15:54:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 15:54:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 15:54:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 15:54:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:54:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 15:54:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 15:54:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 15:54:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/56d665b42a413f25509452c7a549ade2
DEBUG - 2016-09-06 15:54:40 --> Final output sent to browser
DEBUG - 2016-09-06 15:54:40 --> Total execution time: 2.0158
DEBUG - 2016-09-06 15:54:45 --> Config Class Initialized
DEBUG - 2016-09-06 15:54:45 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:54:45 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:54:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:54:45 --> URI Class Initialized
DEBUG - 2016-09-06 15:54:46 --> Router Class Initialized
DEBUG - 2016-09-06 15:54:46 --> Output Class Initialized
DEBUG - 2016-09-06 15:54:46 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 15:54:46 --> Security Class Initialized
DEBUG - 2016-09-06 15:54:46 --> Input Class Initialized
DEBUG - 2016-09-06 15:54:46 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:46 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:46 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:46 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:46 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:46 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:46 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:54:46 --> Language Class Initialized
DEBUG - 2016-09-06 15:54:46 --> Loader Class Initialized
DEBUG - 2016-09-06 15:54:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:54:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:54:46 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:54:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:54:46 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:54:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:54:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:54:46 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:54:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:54:46 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:54:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:54:46 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:54:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:54:46 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:54:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:54:46 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:54:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:54:46 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:54:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:54:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:54:46 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:54:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:54:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:54:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:54:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:54:47 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:54:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:54:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:54:47 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:54:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:54:47 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:54:47 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:54:47 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:54:47 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:54:47 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:54:47 --> Session Class Initialized
DEBUG - 2016-09-06 15:54:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:54:47 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:54:47 --> Session routines successfully run
DEBUG - 2016-09-06 15:54:47 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:54:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:54:47 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:54:47 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:54:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:54:47 --> Controller Class Initialized
DEBUG - 2016-09-06 15:54:47 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:54:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:54:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:54:47 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:54:47 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:54:47 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:54:47 --> Model Class Initialized
DEBUG - 2016-09-06 15:54:47 --> Model Class Initialized
DEBUG - 2016-09-06 15:54:47 --> Model Class Initialized
DEBUG - 2016-09-06 15:54:47 --> Model Class Initialized
DEBUG - 2016-09-06 15:54:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-06 15:54:48 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:54:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:54:48 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-06 15:54:48 --> Config Class Initialized
DEBUG - 2016-09-06 15:54:48 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:54:48 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:54:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:54:48 --> URI Class Initialized
DEBUG - 2016-09-06 15:54:48 --> Router Class Initialized
DEBUG - 2016-09-06 15:54:48 --> Output Class Initialized
DEBUG - 2016-09-06 15:54:48 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 15:54:48 --> Security Class Initialized
DEBUG - 2016-09-06 15:54:48 --> Input Class Initialized
DEBUG - 2016-09-06 15:54:48 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:48 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:54:48 --> Language Class Initialized
DEBUG - 2016-09-06 15:54:48 --> Loader Class Initialized
DEBUG - 2016-09-06 15:54:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:54:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:54:48 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:54:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:54:48 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:54:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:54:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:54:48 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:54:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:54:49 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:54:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:54:49 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:54:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:54:49 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:54:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:54:49 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:54:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:54:49 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:54:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:54:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:54:49 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:54:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:54:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:54:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:54:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:54:49 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:54:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:54:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:54:49 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:54:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:54:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:54:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:54:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:54:49 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:54:49 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:54:49 --> Session Class Initialized
DEBUG - 2016-09-06 15:54:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:54:49 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:54:49 --> Session routines successfully run
DEBUG - 2016-09-06 15:54:49 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:54:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:54:49 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:54:50 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:54:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:54:50 --> Controller Class Initialized
DEBUG - 2016-09-06 15:54:50 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:54:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:54:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:54:50 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:54:50 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:54:50 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:54:50 --> Model Class Initialized
DEBUG - 2016-09-06 15:54:50 --> Model Class Initialized
DEBUG - 2016-09-06 15:54:50 --> Model Class Initialized
DEBUG - 2016-09-06 15:54:50 --> Model Class Initialized
DEBUG - 2016-09-06 15:54:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-06 15:54:50 --> Pagination Class Initialized
DEBUG - 2016-09-06 15:54:50 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 15:54:50 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/index.php
DEBUG - 2016-09-06 15:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 15:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 15:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 15:54:50 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2016-09-06 15:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 15:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 15:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 15:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 15:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 15:54:50 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2016-09-06 15:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 15:54:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 15:54:50 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8118d087c6d6c5bac3947ef2cf7a3513
DEBUG - 2016-09-06 15:54:50 --> Final output sent to browser
DEBUG - 2016-09-06 15:54:51 --> Total execution time: 2.1376
DEBUG - 2016-09-06 15:54:53 --> Config Class Initialized
DEBUG - 2016-09-06 15:54:53 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:54:53 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:54:53 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:54:53 --> URI Class Initialized
DEBUG - 2016-09-06 15:54:53 --> Router Class Initialized
DEBUG - 2016-09-06 15:54:53 --> Output Class Initialized
DEBUG - 2016-09-06 15:54:53 --> Security Class Initialized
DEBUG - 2016-09-06 15:54:53 --> Input Class Initialized
DEBUG - 2016-09-06 15:54:53 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:53 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:54:53 --> Language Class Initialized
DEBUG - 2016-09-06 15:54:53 --> Loader Class Initialized
DEBUG - 2016-09-06 15:54:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:54:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:54:54 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:54:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:54:54 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:54:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:54:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:54:54 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:54:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:54:54 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:54:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:54:54 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:54:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:54:54 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:54:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:54:54 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:54:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:54:54 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:54:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:54:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:54:54 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:54:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:54:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:54:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:54:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:54:54 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:54:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:54:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:54:54 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:54:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:54:54 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:54:54 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:54:54 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:54:54 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:54:55 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:54:55 --> Session Class Initialized
DEBUG - 2016-09-06 15:54:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:54:55 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:54:55 --> Session routines successfully run
DEBUG - 2016-09-06 15:54:55 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:54:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:54:55 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:54:55 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:54:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:54:55 --> Controller Class Initialized
DEBUG - 2016-09-06 15:54:55 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:54:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:54:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:54:55 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:54:55 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:54:55 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:54:55 --> Model Class Initialized
DEBUG - 2016-09-06 15:54:55 --> Model Class Initialized
DEBUG - 2016-09-06 15:54:55 --> Model Class Initialized
DEBUG - 2016-09-06 15:54:55 --> Model Class Initialized
DEBUG - 2016-09-06 15:54:55 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 15:54:55 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/detail.php
DEBUG - 2016-09-06 15:54:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 15:54:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 15:54:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:54:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 15:54:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 15:54:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 15:54:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 15:54:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 15:54:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:54:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 15:54:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 15:54:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 15:54:56 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/56d665b42a413f25509452c7a549ade2
DEBUG - 2016-09-06 15:54:56 --> Final output sent to browser
DEBUG - 2016-09-06 15:54:56 --> Total execution time: 2.0409
DEBUG - 2016-09-06 15:54:59 --> Config Class Initialized
DEBUG - 2016-09-06 15:54:59 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:54:59 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:54:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:54:59 --> URI Class Initialized
DEBUG - 2016-09-06 15:54:59 --> Router Class Initialized
DEBUG - 2016-09-06 15:54:59 --> Output Class Initialized
DEBUG - 2016-09-06 15:54:59 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 15:54:59 --> Security Class Initialized
DEBUG - 2016-09-06 15:54:59 --> Input Class Initialized
DEBUG - 2016-09-06 15:54:59 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:59 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:59 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:59 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:59 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:59 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:59 --> XSS Filtering completed
DEBUG - 2016-09-06 15:54:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:54:59 --> Language Class Initialized
DEBUG - 2016-09-06 15:54:59 --> Loader Class Initialized
DEBUG - 2016-09-06 15:54:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:54:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:54:59 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:55:00 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:55:00 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:55:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:55:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:55:00 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:55:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:55:00 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:55:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:55:00 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:55:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:55:00 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:55:00 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:55:00 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:55:00 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:55:00 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:55:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:55:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:55:00 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:55:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:55:00 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:55:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:55:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:55:00 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:55:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:55:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:55:00 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:55:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:55:00 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:55:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:55:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:55:00 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:55:00 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:55:00 --> Session Class Initialized
DEBUG - 2016-09-06 15:55:01 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:55:01 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:55:01 --> Session routines successfully run
DEBUG - 2016-09-06 15:55:01 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:55:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:55:01 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:55:01 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:55:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:55:01 --> Controller Class Initialized
DEBUG - 2016-09-06 15:55:01 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:55:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:55:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:55:01 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:55:01 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:55:01 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:55:01 --> Model Class Initialized
DEBUG - 2016-09-06 15:55:01 --> Model Class Initialized
DEBUG - 2016-09-06 15:55:01 --> Model Class Initialized
DEBUG - 2016-09-06 15:55:01 --> Model Class Initialized
DEBUG - 2016-09-06 15:55:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-06 15:55:01 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:55:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:55:01 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2016-09-06 15:55:01 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;&quot;
LINE 1: ... = 'test Modul', &quot;turunan_dari&quot; = '', &quot;no_urut&quot; = '', &quot;show_...
                                                             ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-09-06 15:55:01 --> DB Transaction Failure
ERROR - 2016-09-06 15:55:01 --> Query error: ERROR:  invalid input syntax for integer: ""
LINE 1: ... = 'test Modul', "turunan_dari" = '', "no_urut" = '', "show_...
                                                             ^
DEBUG - 2016-09-06 15:55:01 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-09-06 15:56:27 --> Config Class Initialized
DEBUG - 2016-09-06 15:56:27 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:56:27 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:56:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:56:27 --> URI Class Initialized
DEBUG - 2016-09-06 15:56:27 --> Router Class Initialized
DEBUG - 2016-09-06 15:56:27 --> Output Class Initialized
DEBUG - 2016-09-06 15:56:27 --> Security Class Initialized
DEBUG - 2016-09-06 15:56:27 --> Input Class Initialized
DEBUG - 2016-09-06 15:56:27 --> XSS Filtering completed
DEBUG - 2016-09-06 15:56:27 --> XSS Filtering completed
DEBUG - 2016-09-06 15:56:27 --> XSS Filtering completed
DEBUG - 2016-09-06 15:56:27 --> XSS Filtering completed
DEBUG - 2016-09-06 15:56:27 --> XSS Filtering completed
DEBUG - 2016-09-06 15:56:27 --> XSS Filtering completed
DEBUG - 2016-09-06 15:56:27 --> XSS Filtering completed
DEBUG - 2016-09-06 15:56:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:56:27 --> Language Class Initialized
DEBUG - 2016-09-06 15:56:27 --> Loader Class Initialized
DEBUG - 2016-09-06 15:56:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:56:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:56:27 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:56:28 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:56:28 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:56:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:56:28 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:56:28 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:56:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:56:28 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:56:28 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:56:28 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:56:28 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:56:28 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:56:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:56:28 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:56:28 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:56:28 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:56:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:56:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:56:28 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:56:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:56:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:56:28 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:56:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:56:28 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:56:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:56:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:56:28 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:56:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:56:28 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:56:28 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:56:28 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:56:28 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:56:28 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:56:28 --> Session Class Initialized
DEBUG - 2016-09-06 15:56:28 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:56:28 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:56:29 --> Session routines successfully run
DEBUG - 2016-09-06 15:56:29 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:56:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:56:29 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:56:29 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:56:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:56:29 --> Controller Class Initialized
DEBUG - 2016-09-06 15:56:29 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:56:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:56:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:56:29 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:56:29 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:56:29 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:56:29 --> Model Class Initialized
DEBUG - 2016-09-06 15:56:29 --> Model Class Initialized
DEBUG - 2016-09-06 15:56:29 --> Model Class Initialized
DEBUG - 2016-09-06 15:56:29 --> Model Class Initialized
DEBUG - 2016-09-06 15:57:07 --> Config Class Initialized
DEBUG - 2016-09-06 15:57:07 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:57:07 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:57:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:57:07 --> URI Class Initialized
DEBUG - 2016-09-06 15:57:07 --> Router Class Initialized
DEBUG - 2016-09-06 15:57:07 --> Output Class Initialized
DEBUG - 2016-09-06 15:57:07 --> Security Class Initialized
DEBUG - 2016-09-06 15:57:07 --> Input Class Initialized
DEBUG - 2016-09-06 15:57:07 --> XSS Filtering completed
DEBUG - 2016-09-06 15:57:07 --> XSS Filtering completed
DEBUG - 2016-09-06 15:57:07 --> XSS Filtering completed
DEBUG - 2016-09-06 15:57:07 --> XSS Filtering completed
DEBUG - 2016-09-06 15:57:07 --> XSS Filtering completed
DEBUG - 2016-09-06 15:57:07 --> XSS Filtering completed
DEBUG - 2016-09-06 15:57:07 --> XSS Filtering completed
DEBUG - 2016-09-06 15:57:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:57:07 --> Language Class Initialized
DEBUG - 2016-09-06 15:57:07 --> Loader Class Initialized
DEBUG - 2016-09-06 15:57:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:57:07 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:57:07 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:57:07 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:57:07 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:57:07 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:57:07 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:57:07 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:57:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:57:08 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:57:08 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:57:08 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:57:08 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:57:08 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:57:08 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:57:08 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:57:08 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:57:08 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:57:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:57:08 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:57:08 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:57:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:57:08 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:57:08 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:57:08 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:57:08 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:57:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:57:08 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:57:08 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:57:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:57:08 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:57:08 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:57:08 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:57:08 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:57:08 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:57:08 --> Session Class Initialized
DEBUG - 2016-09-06 15:57:08 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:57:08 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:57:08 --> Session routines successfully run
DEBUG - 2016-09-06 15:57:08 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:57:08 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:57:09 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:57:09 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:57:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:57:09 --> Controller Class Initialized
DEBUG - 2016-09-06 15:57:09 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:57:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:57:09 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:57:09 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:57:09 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:57:09 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:57:09 --> Model Class Initialized
DEBUG - 2016-09-06 15:57:09 --> Model Class Initialized
DEBUG - 2016-09-06 15:57:09 --> Model Class Initialized
DEBUG - 2016-09-06 15:57:09 --> Model Class Initialized
DEBUG - 2016-09-06 15:57:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-06 15:57:09 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:57:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:57:09 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-06 15:57:09 --> Config Class Initialized
DEBUG - 2016-09-06 15:57:09 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:57:09 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:57:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:57:09 --> URI Class Initialized
DEBUG - 2016-09-06 15:57:09 --> Router Class Initialized
DEBUG - 2016-09-06 15:57:09 --> Output Class Initialized
DEBUG - 2016-09-06 15:57:09 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 15:57:09 --> Security Class Initialized
DEBUG - 2016-09-06 15:57:09 --> Input Class Initialized
DEBUG - 2016-09-06 15:57:09 --> XSS Filtering completed
DEBUG - 2016-09-06 15:57:09 --> XSS Filtering completed
DEBUG - 2016-09-06 15:57:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:57:10 --> Language Class Initialized
DEBUG - 2016-09-06 15:57:10 --> Loader Class Initialized
DEBUG - 2016-09-06 15:57:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:57:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:57:10 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:57:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:57:10 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:57:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:57:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:57:10 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:57:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:57:10 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:57:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:57:10 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:57:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:57:10 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:57:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:57:10 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:57:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:57:10 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:57:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:57:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:57:10 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:57:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:57:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:57:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:57:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:57:10 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:57:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:57:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:57:10 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:57:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:57:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:57:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:57:11 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:57:11 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:57:11 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:57:11 --> Session Class Initialized
DEBUG - 2016-09-06 15:57:11 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:57:11 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:57:11 --> Session routines successfully run
DEBUG - 2016-09-06 15:57:11 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:57:11 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:57:11 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:57:11 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:57:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:57:11 --> Controller Class Initialized
DEBUG - 2016-09-06 15:57:11 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:57:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:57:11 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:57:11 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:57:11 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:57:11 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:57:11 --> Model Class Initialized
DEBUG - 2016-09-06 15:57:11 --> Model Class Initialized
DEBUG - 2016-09-06 15:57:11 --> Model Class Initialized
DEBUG - 2016-09-06 15:57:11 --> Model Class Initialized
DEBUG - 2016-09-06 15:57:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-06 15:57:11 --> Pagination Class Initialized
DEBUG - 2016-09-06 15:57:11 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 15:57:11 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/index.php
DEBUG - 2016-09-06 15:57:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 15:57:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 15:57:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:57:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 15:57:12 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2016-09-06 15:57:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 15:57:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 15:57:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 15:57:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 15:57:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:57:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 15:57:12 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2016-09-06 15:57:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 15:57:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 15:57:12 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8118d087c6d6c5bac3947ef2cf7a3513
DEBUG - 2016-09-06 15:57:12 --> Final output sent to browser
DEBUG - 2016-09-06 15:57:12 --> Total execution time: 2.2101
DEBUG - 2016-09-06 15:57:14 --> Config Class Initialized
DEBUG - 2016-09-06 15:57:14 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:57:15 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:57:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:57:15 --> URI Class Initialized
DEBUG - 2016-09-06 15:57:15 --> Router Class Initialized
DEBUG - 2016-09-06 15:57:15 --> Output Class Initialized
DEBUG - 2016-09-06 15:57:15 --> Security Class Initialized
DEBUG - 2016-09-06 15:57:15 --> Input Class Initialized
DEBUG - 2016-09-06 15:57:15 --> XSS Filtering completed
DEBUG - 2016-09-06 15:57:15 --> XSS Filtering completed
DEBUG - 2016-09-06 15:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:57:15 --> Language Class Initialized
DEBUG - 2016-09-06 15:57:15 --> Loader Class Initialized
DEBUG - 2016-09-06 15:57:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:57:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:57:15 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:57:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:57:15 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:57:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:57:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:57:15 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:57:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:57:15 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:57:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:57:15 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:57:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:57:15 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:57:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:57:15 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:57:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:57:15 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:57:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:57:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:57:15 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:57:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:57:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:57:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:57:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:57:16 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:57:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:57:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:57:16 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:57:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:57:16 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:57:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:57:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:57:16 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:57:16 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:57:16 --> Session Class Initialized
DEBUG - 2016-09-06 15:57:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:57:16 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:57:16 --> Session routines successfully run
DEBUG - 2016-09-06 15:57:16 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:57:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:57:16 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:57:16 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:57:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:57:16 --> Controller Class Initialized
DEBUG - 2016-09-06 15:57:16 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:57:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:57:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:57:16 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:57:16 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:57:16 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:57:16 --> Model Class Initialized
DEBUG - 2016-09-06 15:57:16 --> Model Class Initialized
DEBUG - 2016-09-06 15:57:16 --> Model Class Initialized
DEBUG - 2016-09-06 15:57:17 --> Model Class Initialized
DEBUG - 2016-09-06 15:57:17 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 15:57:17 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/detail.php
DEBUG - 2016-09-06 15:57:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 15:57:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 15:57:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:57:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 15:57:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 15:57:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 15:57:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 15:57:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 15:57:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:57:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 15:57:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 15:57:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 15:57:17 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/56d665b42a413f25509452c7a549ade2
DEBUG - 2016-09-06 15:57:17 --> Final output sent to browser
DEBUG - 2016-09-06 15:57:17 --> Total execution time: 2.1026
DEBUG - 2016-09-06 15:57:26 --> Config Class Initialized
DEBUG - 2016-09-06 15:57:26 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:57:26 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:57:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:57:26 --> URI Class Initialized
DEBUG - 2016-09-06 15:57:26 --> Router Class Initialized
DEBUG - 2016-09-06 15:57:27 --> Output Class Initialized
DEBUG - 2016-09-06 15:57:27 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 15:57:27 --> Security Class Initialized
DEBUG - 2016-09-06 15:57:27 --> Input Class Initialized
DEBUG - 2016-09-06 15:57:27 --> XSS Filtering completed
DEBUG - 2016-09-06 15:57:27 --> XSS Filtering completed
DEBUG - 2016-09-06 15:57:27 --> XSS Filtering completed
DEBUG - 2016-09-06 15:57:27 --> XSS Filtering completed
DEBUG - 2016-09-06 15:57:27 --> XSS Filtering completed
DEBUG - 2016-09-06 15:57:27 --> XSS Filtering completed
DEBUG - 2016-09-06 15:57:27 --> XSS Filtering completed
DEBUG - 2016-09-06 15:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:57:27 --> Language Class Initialized
DEBUG - 2016-09-06 15:57:27 --> Loader Class Initialized
DEBUG - 2016-09-06 15:57:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:57:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:57:27 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:57:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:57:27 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:57:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:57:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:57:27 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:57:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:57:27 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:57:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:57:27 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:57:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:57:27 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:57:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:57:27 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:57:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:57:27 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:57:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:57:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:57:28 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:57:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:57:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:57:28 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:57:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:57:28 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:57:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:57:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:57:28 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:57:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:57:28 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:57:28 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:57:28 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:57:28 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:57:28 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:57:28 --> Session Class Initialized
DEBUG - 2016-09-06 15:57:28 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:57:28 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:57:28 --> Session routines successfully run
DEBUG - 2016-09-06 15:57:28 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:57:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:57:28 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:57:28 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:57:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:57:28 --> Controller Class Initialized
DEBUG - 2016-09-06 15:57:28 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:57:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:57:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:57:28 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:57:28 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:57:28 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:57:28 --> Model Class Initialized
DEBUG - 2016-09-06 15:57:29 --> Model Class Initialized
DEBUG - 2016-09-06 15:57:29 --> Model Class Initialized
DEBUG - 2016-09-06 15:57:29 --> Model Class Initialized
DEBUG - 2016-09-06 15:57:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-06 15:57:29 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:57:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:57:29 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-06 15:57:29 --> Config Class Initialized
DEBUG - 2016-09-06 15:57:29 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:57:29 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:57:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:57:29 --> URI Class Initialized
DEBUG - 2016-09-06 15:57:29 --> Router Class Initialized
DEBUG - 2016-09-06 15:57:29 --> Output Class Initialized
DEBUG - 2016-09-06 15:57:29 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 15:57:29 --> Security Class Initialized
DEBUG - 2016-09-06 15:57:29 --> Input Class Initialized
DEBUG - 2016-09-06 15:57:29 --> XSS Filtering completed
DEBUG - 2016-09-06 15:57:29 --> XSS Filtering completed
DEBUG - 2016-09-06 15:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:57:29 --> Language Class Initialized
DEBUG - 2016-09-06 15:57:29 --> Loader Class Initialized
DEBUG - 2016-09-06 15:57:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:57:29 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:57:29 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:57:29 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:57:29 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:57:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:57:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:57:30 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:57:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:57:30 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:57:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:57:30 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:57:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:57:30 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:57:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:57:30 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:57:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:57:30 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:57:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:57:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:57:30 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:57:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:57:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:57:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:57:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:57:30 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:57:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:57:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:57:30 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:57:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:57:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:57:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:57:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:57:30 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:57:30 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:57:30 --> Session Class Initialized
DEBUG - 2016-09-06 15:57:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:57:30 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:57:30 --> Session routines successfully run
DEBUG - 2016-09-06 15:57:31 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:57:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:57:31 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:57:31 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:57:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:57:31 --> Controller Class Initialized
DEBUG - 2016-09-06 15:57:31 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:57:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:57:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:57:31 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:57:31 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:57:31 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:57:31 --> Model Class Initialized
DEBUG - 2016-09-06 15:57:31 --> Model Class Initialized
DEBUG - 2016-09-06 15:57:31 --> Model Class Initialized
DEBUG - 2016-09-06 15:57:31 --> Model Class Initialized
DEBUG - 2016-09-06 15:57:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-06 15:57:31 --> Pagination Class Initialized
DEBUG - 2016-09-06 15:57:31 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 15:57:31 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/index.php
DEBUG - 2016-09-06 15:57:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 15:57:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 15:57:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:57:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 15:57:31 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2016-09-06 15:57:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 15:57:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 15:57:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 15:57:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 15:57:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 15:57:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 15:57:32 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2016-09-06 15:57:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 15:57:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 15:57:32 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8118d087c6d6c5bac3947ef2cf7a3513
DEBUG - 2016-09-06 15:57:32 --> Final output sent to browser
DEBUG - 2016-09-06 15:57:32 --> Total execution time: 2.2779
DEBUG - 2016-09-06 15:57:36 --> Config Class Initialized
DEBUG - 2016-09-06 15:57:36 --> Hooks Class Initialized
DEBUG - 2016-09-06 15:57:36 --> Utf8 Class Initialized
DEBUG - 2016-09-06 15:57:36 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 15:57:36 --> URI Class Initialized
DEBUG - 2016-09-06 15:57:36 --> Router Class Initialized
DEBUG - 2016-09-06 15:57:36 --> Output Class Initialized
DEBUG - 2016-09-06 15:57:36 --> Security Class Initialized
DEBUG - 2016-09-06 15:57:37 --> Input Class Initialized
DEBUG - 2016-09-06 15:57:37 --> XSS Filtering completed
DEBUG - 2016-09-06 15:57:37 --> XSS Filtering completed
DEBUG - 2016-09-06 15:57:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 15:57:37 --> Language Class Initialized
DEBUG - 2016-09-06 15:57:37 --> Loader Class Initialized
DEBUG - 2016-09-06 15:57:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 15:57:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 15:57:37 --> Helper loaded: url_helper
DEBUG - 2016-09-06 15:57:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 15:57:37 --> Helper loaded: file_helper
DEBUG - 2016-09-06 15:57:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:57:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 15:57:37 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 15:57:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 15:57:37 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 15:57:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 15:57:37 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:57:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 15:57:37 --> Helper loaded: common_helper
DEBUG - 2016-09-06 15:57:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 15:57:37 --> Helper loaded: form_helper
DEBUG - 2016-09-06 15:57:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 15:57:37 --> Helper loaded: security_helper
DEBUG - 2016-09-06 15:57:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:57:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 15:57:37 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 15:57:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 15:57:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 15:57:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 15:57:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 15:57:37 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 15:57:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:57:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 15:57:38 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 15:57:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 15:57:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 15:57:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 15:57:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 15:57:38 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 15:57:38 --> Database Driver Class Initialized
DEBUG - 2016-09-06 15:57:38 --> Session Class Initialized
DEBUG - 2016-09-06 15:57:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 15:57:38 --> Helper loaded: string_helper
DEBUG - 2016-09-06 15:57:38 --> Session routines successfully run
DEBUG - 2016-09-06 15:57:38 --> Native_session Class Initialized
DEBUG - 2016-09-06 15:57:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 15:57:38 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:57:38 --> Form Validation Class Initialized
DEBUG - 2016-09-06 15:57:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 15:57:38 --> Controller Class Initialized
DEBUG - 2016-09-06 15:57:38 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 15:57:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 15:57:38 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 15:57:38 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:57:38 --> Carabiner: library configured.
DEBUG - 2016-09-06 15:57:38 --> User Agent Class Initialized
DEBUG - 2016-09-06 15:57:38 --> Model Class Initialized
DEBUG - 2016-09-06 15:57:38 --> Model Class Initialized
DEBUG - 2016-09-06 15:57:38 --> Model Class Initialized
DEBUG - 2016-09-06 15:57:38 --> Model Class Initialized
ERROR - 2016-09-06 15:57:38 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;'0'&quot;
LINE 1: ...sc_sidika&quot;.&quot;backbone_modul&quot; SET &quot;record_active&quot; = '''0''' WH...
                                                             ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-09-06 15:57:38 --> DB Transaction Failure
ERROR - 2016-09-06 15:57:39 --> Query error: ERROR:  invalid input syntax for integer: "'0'"
LINE 1: ...sc_sidika"."backbone_modul" SET "record_active" = '''0''' WH...
                                                             ^
DEBUG - 2016-09-06 15:57:39 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-09-06 16:00:11 --> Config Class Initialized
DEBUG - 2016-09-06 16:00:11 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:00:11 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:00:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:00:11 --> URI Class Initialized
DEBUG - 2016-09-06 16:00:11 --> Router Class Initialized
DEBUG - 2016-09-06 16:00:11 --> Output Class Initialized
DEBUG - 2016-09-06 16:00:11 --> Security Class Initialized
DEBUG - 2016-09-06 16:00:11 --> Input Class Initialized
DEBUG - 2016-09-06 16:00:11 --> XSS Filtering completed
DEBUG - 2016-09-06 16:00:11 --> XSS Filtering completed
DEBUG - 2016-09-06 16:00:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:00:11 --> Language Class Initialized
DEBUG - 2016-09-06 16:00:11 --> Loader Class Initialized
DEBUG - 2016-09-06 16:00:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:00:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:00:11 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:00:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:00:11 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:00:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:00:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:00:11 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:00:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:00:11 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:00:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:00:12 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:00:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:00:12 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:00:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:00:12 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:00:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:00:12 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:00:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:00:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:00:12 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:00:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:00:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:00:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:00:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:00:12 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:00:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:00:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:00:12 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:00:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:00:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:00:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:00:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:00:12 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:00:12 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:00:12 --> Session Class Initialized
DEBUG - 2016-09-06 16:00:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:00:12 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:00:12 --> Session routines successfully run
DEBUG - 2016-09-06 16:00:12 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:00:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:00:12 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:00:13 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:00:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:00:13 --> Controller Class Initialized
DEBUG - 2016-09-06 16:00:13 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:00:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:00:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:00:13 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:00:13 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:00:13 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:00:13 --> Model Class Initialized
DEBUG - 2016-09-06 16:00:13 --> Model Class Initialized
DEBUG - 2016-09-06 16:00:13 --> Model Class Initialized
DEBUG - 2016-09-06 16:00:13 --> Model Class Initialized
DEBUG - 2016-09-06 16:01:01 --> Config Class Initialized
DEBUG - 2016-09-06 16:01:01 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:01:01 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:01:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:01:01 --> URI Class Initialized
DEBUG - 2016-09-06 16:01:01 --> Router Class Initialized
DEBUG - 2016-09-06 16:01:01 --> Output Class Initialized
DEBUG - 2016-09-06 16:01:01 --> Security Class Initialized
DEBUG - 2016-09-06 16:01:01 --> Input Class Initialized
DEBUG - 2016-09-06 16:01:01 --> XSS Filtering completed
DEBUG - 2016-09-06 16:01:01 --> XSS Filtering completed
DEBUG - 2016-09-06 16:01:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:01:01 --> Language Class Initialized
DEBUG - 2016-09-06 16:01:01 --> Loader Class Initialized
DEBUG - 2016-09-06 16:01:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:01:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:01:01 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:01:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:01:01 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:01:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:01:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:01:01 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:01:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:01:02 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:01:02 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:01:02 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:01:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:01:02 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:01:02 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:01:02 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:01:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:01:02 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:01:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:01:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:01:02 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:01:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:01:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:01:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:01:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:01:02 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:01:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:01:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:01:02 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:01:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:01:02 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:01:02 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:01:02 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:01:02 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:01:02 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:01:02 --> Session Class Initialized
DEBUG - 2016-09-06 16:01:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:01:02 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:01:02 --> Session routines successfully run
DEBUG - 2016-09-06 16:01:02 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:01:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:01:03 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:01:03 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:01:03 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:01:03 --> Controller Class Initialized
DEBUG - 2016-09-06 16:01:03 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:01:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:01:03 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:01:03 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:01:03 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:01:03 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:01:03 --> Model Class Initialized
DEBUG - 2016-09-06 16:01:03 --> Model Class Initialized
DEBUG - 2016-09-06 16:01:03 --> Model Class Initialized
DEBUG - 2016-09-06 16:01:03 --> Model Class Initialized
ERROR - 2016-09-06 16:01:03 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;'0'&quot;
LINE 1: ...sc_sidika&quot;.&quot;backbone_modul&quot; SET &quot;record_active&quot; = '''0''' WH...
                                                             ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-09-06 16:01:03 --> DB Transaction Failure
ERROR - 2016-09-06 16:01:03 --> Query error: ERROR:  invalid input syntax for integer: "'0'"
LINE 1: ...sc_sidika"."backbone_modul" SET "record_active" = '''0''' WH...
                                                             ^
DEBUG - 2016-09-06 16:01:03 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-09-06 16:01:04 --> Config Class Initialized
DEBUG - 2016-09-06 16:01:04 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:01:04 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:01:04 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:01:04 --> URI Class Initialized
DEBUG - 2016-09-06 16:01:04 --> Router Class Initialized
DEBUG - 2016-09-06 16:01:04 --> Output Class Initialized
DEBUG - 2016-09-06 16:01:04 --> Security Class Initialized
DEBUG - 2016-09-06 16:01:04 --> Input Class Initialized
DEBUG - 2016-09-06 16:01:04 --> XSS Filtering completed
DEBUG - 2016-09-06 16:01:04 --> XSS Filtering completed
DEBUG - 2016-09-06 16:01:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:01:04 --> Language Class Initialized
DEBUG - 2016-09-06 16:01:04 --> Loader Class Initialized
DEBUG - 2016-09-06 16:01:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:01:04 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:01:05 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:01:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:01:05 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:01:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:01:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:01:05 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:01:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:01:05 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:01:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:01:05 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:01:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:01:05 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:01:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:01:05 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:01:05 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:01:05 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:01:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:01:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:01:05 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:01:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:01:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:01:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:01:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:01:05 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:01:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:01:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:01:05 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:01:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:01:05 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:01:05 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:01:05 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:01:05 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:01:06 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:01:06 --> Session Class Initialized
DEBUG - 2016-09-06 16:01:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:01:06 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:01:06 --> Session routines successfully run
DEBUG - 2016-09-06 16:01:06 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:01:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:01:06 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:01:06 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:01:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:01:06 --> Controller Class Initialized
DEBUG - 2016-09-06 16:01:06 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:01:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:01:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:01:06 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:01:06 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:01:06 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:01:06 --> Model Class Initialized
DEBUG - 2016-09-06 16:01:06 --> Model Class Initialized
DEBUG - 2016-09-06 16:01:06 --> Model Class Initialized
DEBUG - 2016-09-06 16:01:06 --> Model Class Initialized
ERROR - 2016-09-06 16:01:06 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;'0'&quot;
LINE 1: ...sc_sidika&quot;.&quot;backbone_modul&quot; SET &quot;record_active&quot; = '''0''' WH...
                                                             ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-09-06 16:01:06 --> DB Transaction Failure
ERROR - 2016-09-06 16:01:06 --> Query error: ERROR:  invalid input syntax for integer: "'0'"
LINE 1: ...sc_sidika"."backbone_modul" SET "record_active" = '''0''' WH...
                                                             ^
DEBUG - 2016-09-06 16:01:06 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-09-06 16:01:21 --> Config Class Initialized
DEBUG - 2016-09-06 16:01:22 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:01:22 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:01:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:01:22 --> URI Class Initialized
DEBUG - 2016-09-06 16:01:22 --> Router Class Initialized
DEBUG - 2016-09-06 16:01:22 --> Output Class Initialized
DEBUG - 2016-09-06 16:01:22 --> Security Class Initialized
DEBUG - 2016-09-06 16:01:22 --> Input Class Initialized
DEBUG - 2016-09-06 16:01:22 --> XSS Filtering completed
DEBUG - 2016-09-06 16:01:22 --> XSS Filtering completed
DEBUG - 2016-09-06 16:01:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:01:22 --> Language Class Initialized
DEBUG - 2016-09-06 16:01:22 --> Loader Class Initialized
DEBUG - 2016-09-06 16:01:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:01:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:01:22 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:01:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:01:22 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:01:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:01:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:01:22 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:01:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:01:22 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:01:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:01:22 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:01:22 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:01:22 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:01:22 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:01:22 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:01:22 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:01:22 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:01:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:01:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:01:23 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:01:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:01:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:01:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:01:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:01:23 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:01:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:01:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:01:23 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:01:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:01:23 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:01:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:01:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:01:23 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:01:23 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:01:23 --> Session Class Initialized
DEBUG - 2016-09-06 16:01:23 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:01:23 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:01:23 --> Session routines successfully run
DEBUG - 2016-09-06 16:01:23 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:01:23 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:01:23 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:01:23 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:01:23 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:01:23 --> Controller Class Initialized
DEBUG - 2016-09-06 16:01:23 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:01:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:01:23 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:01:23 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:01:23 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:01:23 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:01:24 --> Model Class Initialized
DEBUG - 2016-09-06 16:01:24 --> Model Class Initialized
DEBUG - 2016-09-06 16:01:24 --> Model Class Initialized
DEBUG - 2016-09-06 16:01:24 --> Model Class Initialized
ERROR - 2016-09-06 16:01:24 --> Severity: Warning  --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;'0'&quot;
LINE 1: ...sc_sidika&quot;.&quot;backbone_modul&quot; SET &quot;record_active&quot; = '''0''' WH...
                                                             ^ E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 177
DEBUG - 2016-09-06 16:01:24 --> DB Transaction Failure
ERROR - 2016-09-06 16:01:24 --> Query error: ERROR:  invalid input syntax for integer: "'0'"
LINE 1: ...sc_sidika"."backbone_modul" SET "record_active" = '''0''' WH...
                                                             ^
DEBUG - 2016-09-06 16:01:24 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-09-06 16:01:39 --> Config Class Initialized
DEBUG - 2016-09-06 16:01:39 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:01:39 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:01:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:01:39 --> URI Class Initialized
DEBUG - 2016-09-06 16:01:39 --> Router Class Initialized
DEBUG - 2016-09-06 16:01:39 --> Output Class Initialized
DEBUG - 2016-09-06 16:01:39 --> Security Class Initialized
DEBUG - 2016-09-06 16:01:39 --> Input Class Initialized
DEBUG - 2016-09-06 16:01:39 --> XSS Filtering completed
DEBUG - 2016-09-06 16:01:39 --> XSS Filtering completed
DEBUG - 2016-09-06 16:01:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:01:39 --> Language Class Initialized
DEBUG - 2016-09-06 16:01:39 --> Loader Class Initialized
DEBUG - 2016-09-06 16:01:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:01:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:01:39 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:01:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:01:39 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:01:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:01:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:01:39 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:01:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:01:39 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:01:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:01:40 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:01:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:01:40 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:01:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:01:40 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:01:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:01:40 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:01:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:01:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:01:40 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:01:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:01:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:01:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:01:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:01:40 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:01:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:01:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:01:40 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:01:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:01:40 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:01:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:01:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:01:40 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:01:40 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:01:40 --> Session Class Initialized
DEBUG - 2016-09-06 16:01:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:01:40 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:01:40 --> Session routines successfully run
DEBUG - 2016-09-06 16:01:40 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:01:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:01:40 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:01:41 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:01:41 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:01:41 --> Controller Class Initialized
DEBUG - 2016-09-06 16:01:41 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:01:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:01:41 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:01:41 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:01:41 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:01:41 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:01:41 --> Model Class Initialized
DEBUG - 2016-09-06 16:01:41 --> Model Class Initialized
DEBUG - 2016-09-06 16:01:41 --> Model Class Initialized
DEBUG - 2016-09-06 16:01:41 --> Model Class Initialized
DEBUG - 2016-09-06 16:01:41 --> Config Class Initialized
DEBUG - 2016-09-06 16:01:41 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:01:41 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:01:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:01:41 --> URI Class Initialized
DEBUG - 2016-09-06 16:01:41 --> Router Class Initialized
DEBUG - 2016-09-06 16:01:41 --> Output Class Initialized
DEBUG - 2016-09-06 16:01:41 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 16:01:41 --> Security Class Initialized
DEBUG - 2016-09-06 16:01:41 --> Input Class Initialized
DEBUG - 2016-09-06 16:01:41 --> XSS Filtering completed
DEBUG - 2016-09-06 16:01:41 --> XSS Filtering completed
DEBUG - 2016-09-06 16:01:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:01:42 --> Language Class Initialized
DEBUG - 2016-09-06 16:01:42 --> Loader Class Initialized
DEBUG - 2016-09-06 16:01:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:01:42 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:01:42 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:01:42 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:01:42 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:01:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:01:42 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:01:42 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:01:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:01:42 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:01:42 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:01:42 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:01:42 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:01:42 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:01:42 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:01:42 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:01:42 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:01:42 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:01:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:01:42 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:01:42 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:01:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:01:42 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:01:42 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:01:42 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:01:42 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:01:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:01:42 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:01:42 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:01:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:01:43 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:01:43 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:01:43 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:01:43 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:01:43 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:01:43 --> Session Class Initialized
DEBUG - 2016-09-06 16:01:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:01:43 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:01:43 --> Session routines successfully run
DEBUG - 2016-09-06 16:01:43 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:01:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:01:43 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:01:43 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:01:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:01:43 --> Controller Class Initialized
DEBUG - 2016-09-06 16:01:43 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:01:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:01:43 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:01:43 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:01:43 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:01:43 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:01:43 --> Model Class Initialized
DEBUG - 2016-09-06 16:01:43 --> Model Class Initialized
DEBUG - 2016-09-06 16:01:43 --> Model Class Initialized
DEBUG - 2016-09-06 16:01:43 --> Model Class Initialized
DEBUG - 2016-09-06 16:01:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-06 16:01:43 --> Pagination Class Initialized
DEBUG - 2016-09-06 16:01:43 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 16:01:44 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/index.php
DEBUG - 2016-09-06 16:01:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:01:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:01:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:01:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:01:44 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2016-09-06 16:01:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:01:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:01:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:01:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:01:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:01:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:01:44 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2016-09-06 16:01:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:01:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:01:44 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/b786644f21b76d4817636e54616a2716
DEBUG - 2016-09-06 16:01:44 --> Final output sent to browser
DEBUG - 2016-09-06 16:01:44 --> Total execution time: 2.4553
DEBUG - 2016-09-06 16:02:40 --> Config Class Initialized
DEBUG - 2016-09-06 16:02:40 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:02:40 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:02:40 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:02:40 --> URI Class Initialized
DEBUG - 2016-09-06 16:02:40 --> Router Class Initialized
DEBUG - 2016-09-06 16:02:40 --> Output Class Initialized
DEBUG - 2016-09-06 16:02:40 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 16:02:40 --> Security Class Initialized
DEBUG - 2016-09-06 16:02:40 --> Input Class Initialized
DEBUG - 2016-09-06 16:02:40 --> XSS Filtering completed
DEBUG - 2016-09-06 16:02:40 --> XSS Filtering completed
DEBUG - 2016-09-06 16:02:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:02:40 --> Language Class Initialized
DEBUG - 2016-09-06 16:02:40 --> Loader Class Initialized
DEBUG - 2016-09-06 16:02:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:02:41 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:02:41 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:02:41 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:02:41 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:02:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:02:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:02:41 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:02:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:02:41 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:02:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:02:41 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:02:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:02:41 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:02:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:02:41 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:02:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:02:41 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:02:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:02:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:02:41 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:02:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:02:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:02:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:02:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:02:41 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:02:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:02:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:02:41 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:02:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:02:41 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:02:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:02:41 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:02:42 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:02:42 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:02:42 --> Session Class Initialized
DEBUG - 2016-09-06 16:02:42 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:02:42 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:02:42 --> Session routines successfully run
DEBUG - 2016-09-06 16:02:42 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:02:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:02:42 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:02:42 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:02:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:02:42 --> Controller Class Initialized
DEBUG - 2016-09-06 16:02:42 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:02:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:02:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:02:42 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:02:42 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:02:42 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:02:42 --> Model Class Initialized
DEBUG - 2016-09-06 16:02:42 --> Model Class Initialized
DEBUG - 2016-09-06 16:02:42 --> Model Class Initialized
DEBUG - 2016-09-06 16:02:42 --> Model Class Initialized
DEBUG - 2016-09-06 16:02:42 --> Model Class Initialized
DEBUG - 2016-09-06 16:02:42 --> Model Class Initialized
DEBUG - 2016-09-06 16:02:42 --> Model Class Initialized
DEBUG - 2016-09-06 16:02:42 --> Model Class Initialized
DEBUG - 2016-09-06 16:02:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-06 16:02:42 --> Pagination Class Initialized
DEBUG - 2016-09-06 16:02:43 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 16:02:43 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/index.php
DEBUG - 2016-09-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:02:43 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-09-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:02:43 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-09-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:02:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:02:43 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55961f1d1ca16fdfc4239ae1901a174e
DEBUG - 2016-09-06 16:02:43 --> Final output sent to browser
DEBUG - 2016-09-06 16:02:43 --> Total execution time: 2.5722
DEBUG - 2016-09-06 16:02:46 --> Config Class Initialized
DEBUG - 2016-09-06 16:02:46 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:02:46 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:02:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:02:46 --> URI Class Initialized
DEBUG - 2016-09-06 16:02:46 --> Router Class Initialized
DEBUG - 2016-09-06 16:02:46 --> Output Class Initialized
DEBUG - 2016-09-06 16:02:46 --> Security Class Initialized
DEBUG - 2016-09-06 16:02:46 --> Input Class Initialized
DEBUG - 2016-09-06 16:02:46 --> XSS Filtering completed
DEBUG - 2016-09-06 16:02:46 --> XSS Filtering completed
DEBUG - 2016-09-06 16:02:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:02:46 --> Language Class Initialized
DEBUG - 2016-09-06 16:02:46 --> Loader Class Initialized
DEBUG - 2016-09-06 16:02:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:02:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:02:46 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:02:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:02:46 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:02:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:02:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:02:46 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:02:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:02:47 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:02:47 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:02:47 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:02:47 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:02:47 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:02:47 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:02:47 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:02:47 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:02:47 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:02:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:02:47 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:02:47 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:02:47 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:02:47 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:02:47 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:02:47 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:02:47 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:02:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:02:47 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:02:47 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:02:47 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:02:47 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:02:47 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:02:47 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:02:47 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:02:47 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:02:47 --> Session Class Initialized
DEBUG - 2016-09-06 16:02:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:02:47 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:02:47 --> Session routines successfully run
DEBUG - 2016-09-06 16:02:47 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:02:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:02:48 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:02:48 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:02:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:02:48 --> Controller Class Initialized
DEBUG - 2016-09-06 16:02:48 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:02:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:02:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:02:48 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:02:48 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:02:48 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:02:48 --> Model Class Initialized
DEBUG - 2016-09-06 16:02:48 --> Model Class Initialized
DEBUG - 2016-09-06 16:02:48 --> Model Class Initialized
DEBUG - 2016-09-06 16:02:48 --> Model Class Initialized
DEBUG - 2016-09-06 16:02:48 --> Model Class Initialized
DEBUG - 2016-09-06 16:02:48 --> Model Class Initialized
DEBUG - 2016-09-06 16:02:48 --> Model Class Initialized
DEBUG - 2016-09-06 16:02:48 --> Model Class Initialized
DEBUG - 2016-09-06 16:02:48 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 16:02:48 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/detail.php
DEBUG - 2016-09-06 16:02:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:02:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:02:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:02:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:02:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:02:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:02:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:02:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:02:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:02:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:02:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:02:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:02:49 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-09-06 16:02:49 --> Final output sent to browser
DEBUG - 2016-09-06 16:02:49 --> Total execution time: 2.3531
DEBUG - 2016-09-06 16:03:09 --> Config Class Initialized
DEBUG - 2016-09-06 16:03:09 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:03:09 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:03:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:03:09 --> URI Class Initialized
DEBUG - 2016-09-06 16:03:09 --> Router Class Initialized
DEBUG - 2016-09-06 16:03:09 --> Output Class Initialized
DEBUG - 2016-09-06 16:03:09 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 16:03:09 --> Security Class Initialized
DEBUG - 2016-09-06 16:03:09 --> Input Class Initialized
DEBUG - 2016-09-06 16:03:09 --> XSS Filtering completed
DEBUG - 2016-09-06 16:03:09 --> XSS Filtering completed
DEBUG - 2016-09-06 16:03:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:03:09 --> Language Class Initialized
DEBUG - 2016-09-06 16:03:09 --> Loader Class Initialized
DEBUG - 2016-09-06 16:03:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:03:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:03:10 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:03:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:03:10 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:03:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:03:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:03:10 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:03:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:03:10 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:03:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:03:10 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:03:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:03:10 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:03:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:03:10 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:03:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:03:10 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:03:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:03:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:03:10 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:03:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:03:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:03:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:03:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:03:10 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:03:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:03:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:03:10 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:03:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:03:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:03:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:03:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:03:11 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:03:11 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:03:11 --> Session Class Initialized
DEBUG - 2016-09-06 16:03:11 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:03:11 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:03:11 --> Session routines successfully run
DEBUG - 2016-09-06 16:03:11 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:03:11 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:03:11 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:03:11 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:03:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:03:11 --> Controller Class Initialized
DEBUG - 2016-09-06 16:03:11 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:03:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:03:11 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:03:11 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:03:11 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:03:11 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:03:11 --> Model Class Initialized
DEBUG - 2016-09-06 16:03:11 --> Model Class Initialized
DEBUG - 2016-09-06 16:03:11 --> Model Class Initialized
DEBUG - 2016-09-06 16:03:11 --> Model Class Initialized
DEBUG - 2016-09-06 16:03:11 --> Model Class Initialized
DEBUG - 2016-09-06 16:03:11 --> Model Class Initialized
DEBUG - 2016-09-06 16:03:11 --> Model Class Initialized
DEBUG - 2016-09-06 16:03:11 --> Model Class Initialized
DEBUG - 2016-09-06 16:03:11 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 16:03:11 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/detail.php
DEBUG - 2016-09-06 16:03:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:03:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:03:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:03:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:03:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:03:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:03:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:03:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:03:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:03:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:03:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:03:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:03:12 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-09-06 16:03:12 --> Final output sent to browser
DEBUG - 2016-09-06 16:03:12 --> Total execution time: 2.4302
DEBUG - 2016-09-06 16:20:01 --> Config Class Initialized
DEBUG - 2016-09-06 16:20:01 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:20:01 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:20:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:20:01 --> URI Class Initialized
DEBUG - 2016-09-06 16:20:01 --> Router Class Initialized
ERROR - 2016-09-06 16:20:01 --> 404 Page Not Found --> back_end/member
DEBUG - 2016-09-06 16:20:01 --> Config Class Initialized
DEBUG - 2016-09-06 16:20:01 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:20:01 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:20:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:20:01 --> URI Class Initialized
DEBUG - 2016-09-06 16:20:01 --> Router Class Initialized
ERROR - 2016-09-06 16:20:01 --> 404 Page Not Found --> img
DEBUG - 2016-09-06 16:20:01 --> Config Class Initialized
DEBUG - 2016-09-06 16:20:01 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:20:01 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:20:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:20:01 --> URI Class Initialized
DEBUG - 2016-09-06 16:20:01 --> Router Class Initialized
ERROR - 2016-09-06 16:20:01 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-09-06 16:20:16 --> Config Class Initialized
DEBUG - 2016-09-06 16:20:17 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:20:17 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:20:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:20:17 --> URI Class Initialized
DEBUG - 2016-09-06 16:20:17 --> Router Class Initialized
DEBUG - 2016-09-06 16:20:17 --> Output Class Initialized
DEBUG - 2016-09-06 16:20:17 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 16:20:17 --> Security Class Initialized
DEBUG - 2016-09-06 16:20:17 --> Input Class Initialized
DEBUG - 2016-09-06 16:20:17 --> XSS Filtering completed
DEBUG - 2016-09-06 16:20:17 --> XSS Filtering completed
DEBUG - 2016-09-06 16:20:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:20:17 --> Language Class Initialized
DEBUG - 2016-09-06 16:20:17 --> Loader Class Initialized
DEBUG - 2016-09-06 16:20:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:20:17 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:20:17 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:20:17 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:20:17 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:20:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:20:17 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:20:17 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:20:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:20:17 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:20:17 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:20:17 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:20:17 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:20:17 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:20:17 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:20:17 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:20:18 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:20:18 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:20:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:20:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:20:18 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:20:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:20:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:20:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:20:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:20:18 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:20:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:20:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:20:18 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:20:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:20:18 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:20:18 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:20:18 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:20:18 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:20:18 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:20:18 --> Session Class Initialized
DEBUG - 2016-09-06 16:20:18 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:20:18 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:20:18 --> Session routines successfully run
DEBUG - 2016-09-06 16:20:18 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:20:18 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:20:18 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:20:18 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:20:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:20:18 --> Controller Class Initialized
DEBUG - 2016-09-06 16:20:18 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:20:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:20:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:20:19 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:20:19 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:20:19 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:20:19 --> Model Class Initialized
DEBUG - 2016-09-06 16:20:19 --> Model Class Initialized
DEBUG - 2016-09-06 16:20:19 --> Model Class Initialized
DEBUG - 2016-09-06 16:20:19 --> Model Class Initialized
DEBUG - 2016-09-06 16:20:19 --> Model Class Initialized
DEBUG - 2016-09-06 16:20:19 --> Model Class Initialized
DEBUG - 2016-09-06 16:20:19 --> Model Class Initialized
DEBUG - 2016-09-06 16:20:19 --> Model Class Initialized
DEBUG - 2016-09-06 16:20:19 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 16:20:19 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/detail.php
DEBUG - 2016-09-06 16:20:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:20:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:20:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:20:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:20:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:20:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:20:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:20:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:20:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:20:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:20:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:20:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:20:19 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-09-06 16:20:19 --> Final output sent to browser
DEBUG - 2016-09-06 16:20:19 --> Total execution time: 2.4307
DEBUG - 2016-09-06 16:21:31 --> Config Class Initialized
DEBUG - 2016-09-06 16:21:31 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:21:31 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:21:31 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:21:31 --> URI Class Initialized
DEBUG - 2016-09-06 16:21:31 --> Router Class Initialized
DEBUG - 2016-09-06 16:21:31 --> Output Class Initialized
DEBUG - 2016-09-06 16:21:31 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 16:21:31 --> Security Class Initialized
DEBUG - 2016-09-06 16:21:31 --> Input Class Initialized
DEBUG - 2016-09-06 16:21:31 --> XSS Filtering completed
DEBUG - 2016-09-06 16:21:31 --> XSS Filtering completed
DEBUG - 2016-09-06 16:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:21:31 --> Language Class Initialized
DEBUG - 2016-09-06 16:21:31 --> Loader Class Initialized
DEBUG - 2016-09-06 16:21:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:21:31 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:21:31 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:21:31 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:21:31 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:21:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:21:31 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:21:31 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:21:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:21:31 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:21:31 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:21:31 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:21:31 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:21:31 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:21:31 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:21:32 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:21:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:21:32 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:21:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:21:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:21:32 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:21:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:21:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:21:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:21:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:21:32 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:21:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:21:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:21:32 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:21:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:21:32 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:21:32 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:21:32 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:21:32 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:21:32 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:21:32 --> Session Class Initialized
DEBUG - 2016-09-06 16:21:32 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:21:32 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:21:32 --> Session routines successfully run
DEBUG - 2016-09-06 16:21:32 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:21:32 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:21:32 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:21:32 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:21:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:21:32 --> Controller Class Initialized
DEBUG - 2016-09-06 16:21:33 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:21:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:21:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:21:33 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:21:33 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:21:33 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:21:33 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:33 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:33 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:33 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:33 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:33 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:33 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:33 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:33 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 16:21:33 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/detail.php
DEBUG - 2016-09-06 16:21:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:21:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:21:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:21:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:21:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:21:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:21:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:21:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:21:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:21:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:21:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:21:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:21:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-09-06 16:21:34 --> Final output sent to browser
DEBUG - 2016-09-06 16:21:34 --> Total execution time: 2.4942
DEBUG - 2016-09-06 16:21:40 --> Config Class Initialized
DEBUG - 2016-09-06 16:21:40 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:21:40 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:21:40 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:21:40 --> URI Class Initialized
DEBUG - 2016-09-06 16:21:40 --> Router Class Initialized
ERROR - 2016-09-06 16:21:40 --> 404 Page Not Found --> back_end/member
DEBUG - 2016-09-06 16:21:40 --> Config Class Initialized
DEBUG - 2016-09-06 16:21:40 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:21:40 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:21:40 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:21:40 --> URI Class Initialized
DEBUG - 2016-09-06 16:21:40 --> Router Class Initialized
ERROR - 2016-09-06 16:21:40 --> 404 Page Not Found --> img
DEBUG - 2016-09-06 16:21:40 --> Config Class Initialized
DEBUG - 2016-09-06 16:21:40 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:21:40 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:21:40 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:21:40 --> URI Class Initialized
DEBUG - 2016-09-06 16:21:40 --> Router Class Initialized
ERROR - 2016-09-06 16:21:40 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-09-06 16:21:51 --> Config Class Initialized
DEBUG - 2016-09-06 16:21:51 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:21:51 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:21:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:21:51 --> URI Class Initialized
DEBUG - 2016-09-06 16:21:51 --> Router Class Initialized
DEBUG - 2016-09-06 16:21:51 --> Output Class Initialized
DEBUG - 2016-09-06 16:21:51 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 16:21:51 --> Security Class Initialized
DEBUG - 2016-09-06 16:21:51 --> Input Class Initialized
DEBUG - 2016-09-06 16:21:51 --> XSS Filtering completed
DEBUG - 2016-09-06 16:21:51 --> XSS Filtering completed
DEBUG - 2016-09-06 16:21:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:21:51 --> Language Class Initialized
DEBUG - 2016-09-06 16:21:51 --> Loader Class Initialized
DEBUG - 2016-09-06 16:21:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:21:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:21:51 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:21:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:21:51 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:21:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:21:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:21:52 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:21:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:21:52 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:21:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:21:52 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:21:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:21:52 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:21:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:21:52 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:21:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:21:52 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:21:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:21:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:21:52 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:21:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:21:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:21:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:21:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:21:52 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:21:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:21:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:21:52 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:21:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:21:52 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:21:52 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:21:52 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:21:52 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:21:52 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:21:52 --> Session Class Initialized
DEBUG - 2016-09-06 16:21:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:21:53 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:21:53 --> Session routines successfully run
DEBUG - 2016-09-06 16:21:53 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:21:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:21:53 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:21:53 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:21:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:21:53 --> Controller Class Initialized
DEBUG - 2016-09-06 16:21:53 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:21:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:21:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:21:53 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:21:53 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:21:53 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:21:53 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:53 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:53 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:53 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:53 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:53 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:53 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:53 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:53 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 16:21:53 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/detail.php
DEBUG - 2016-09-06 16:21:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:21:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:21:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:21:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:21:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:21:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:21:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:21:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:21:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:21:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:21:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:21:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:21:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-09-06 16:21:54 --> Final output sent to browser
DEBUG - 2016-09-06 16:21:54 --> Total execution time: 2.4688
DEBUG - 2016-09-06 16:21:56 --> Config Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:21:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:21:56 --> URI Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Router Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Output Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Config Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 16:21:56 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Security Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Input Class Initialized
DEBUG - 2016-09-06 16:21:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:21:56 --> XSS Filtering completed
DEBUG - 2016-09-06 16:21:56 --> XSS Filtering completed
DEBUG - 2016-09-06 16:21:56 --> URI Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:21:56 --> Router Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Config Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Language Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Output Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Security Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Loader Class Initialized
DEBUG - 2016-09-06 16:21:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:21:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:21:56 --> Input Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:21:56 --> URI Class Initialized
DEBUG - 2016-09-06 16:21:56 --> XSS Filtering completed
DEBUG - 2016-09-06 16:21:56 --> XSS Filtering completed
DEBUG - 2016-09-06 16:21:56 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:21:56 --> Config Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Router Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:21:56 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:21:56 --> Output Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Language Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:21:56 --> Security Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Input Class Initialized
DEBUG - 2016-09-06 16:21:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:21:56 --> Loader Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:21:56 --> XSS Filtering completed
DEBUG - 2016-09-06 16:21:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:21:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:21:56 --> URI Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Config Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:21:56 --> XSS Filtering completed
DEBUG - 2016-09-06 16:21:56 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:21:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:21:56 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:21:56 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:21:56 --> Router Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:21:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:21:56 --> Language Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Output Class Initialized
DEBUG - 2016-09-06 16:21:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:21:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:21:56 --> Security Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:21:56 --> Loader Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:21:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:21:56 --> URI Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Input Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:21:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:21:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:21:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:21:56 --> XSS Filtering completed
DEBUG - 2016-09-06 16:21:56 --> Router Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:21:56 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:21:56 --> XSS Filtering completed
DEBUG - 2016-09-06 16:21:56 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:21:56 --> Output Class Initialized
DEBUG - 2016-09-06 16:21:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:21:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:21:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:21:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:21:56 --> Security Class Initialized
DEBUG - 2016-09-06 16:21:57 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Language Class Initialized
DEBUG - 2016-09-06 16:21:57 --> Input Class Initialized
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:21:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> XSS Filtering completed
DEBUG - 2016-09-06 16:21:57 --> Loader Class Initialized
DEBUG - 2016-09-06 16:21:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:21:57 --> XSS Filtering completed
DEBUG - 2016-09-06 16:21:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:21:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:21:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:21:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:21:57 --> Language Class Initialized
DEBUG - 2016-09-06 16:21:57 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:21:57 --> Loader Class Initialized
DEBUG - 2016-09-06 16:21:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:21:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:21:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:21:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:21:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:21:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:21:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:21:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:21:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:21:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:21:57 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:21:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:21:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:21:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:21:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:21:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Session Class Initialized
DEBUG - 2016-09-06 16:21:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:21:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:21:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:21:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Session routines successfully run
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:21:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:21:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:21:57 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:21:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:21:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Session Class Initialized
DEBUG - 2016-09-06 16:21:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:21:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:21:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:21:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:21:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:21:57 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:21:57 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:21:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:21:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:21:58 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:21:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:21:58 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:21:58 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:21:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:21:58 --> Session routines successfully run
DEBUG - 2016-09-06 16:21:58 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:21:58 --> Controller Class Initialized
DEBUG - 2016-09-06 16:21:58 --> Session Class Initialized
DEBUG - 2016-09-06 16:21:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:21:58 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:21:58 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:21:58 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:21:58 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:21:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:21:58 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:21:58 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:21:58 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:21:58 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:21:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:21:58 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:21:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:21:58 --> Session routines successfully run
DEBUG - 2016-09-06 16:21:58 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:21:58 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:21:58 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:21:58 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:21:58 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:21:58 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:21:58 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:21:58 --> Session Class Initialized
DEBUG - 2016-09-06 16:21:58 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:21:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:21:58 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:21:58 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:21:58 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:21:58 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:58 --> Session routines successfully run
DEBUG - 2016-09-06 16:21:58 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:58 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:21:58 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:21:58 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:58 --> Session Class Initialized
DEBUG - 2016-09-06 16:21:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:21:58 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:58 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:21:58 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:58 --> Session routines successfully run
DEBUG - 2016-09-06 16:21:58 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:58 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:21:58 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:58 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:58 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 16:21:58 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/detail.php
DEBUG - 2016-09-06 16:21:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:21:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:21:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:21:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:21:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:21:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:21:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:21:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:21:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:21:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:21:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:21:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:21:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-09-06 16:21:59 --> Final output sent to browser
DEBUG - 2016-09-06 16:21:59 --> Total execution time: 2.5671
DEBUG - 2016-09-06 16:21:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:21:59 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:21:59 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:21:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:21:59 --> Controller Class Initialized
DEBUG - 2016-09-06 16:21:59 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:21:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:21:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:21:59 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:21:59 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:21:59 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:21:59 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:59 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:59 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:59 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:59 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:59 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:59 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:59 --> Model Class Initialized
DEBUG - 2016-09-06 16:21:59 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 16:21:59 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/detail.php
DEBUG - 2016-09-06 16:21:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:21:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:21:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:22:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:22:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:22:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:22:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:22:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:22:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:22:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:22:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:22:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:22:00 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-09-06 16:22:00 --> Final output sent to browser
DEBUG - 2016-09-06 16:22:00 --> Total execution time: 3.5927
DEBUG - 2016-09-06 16:22:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:22:00 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:22:00 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:22:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:22:00 --> Controller Class Initialized
DEBUG - 2016-09-06 16:22:00 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:22:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:22:00 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:22:00 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:22:00 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:22:00 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:22:00 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:00 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:00 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:00 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:00 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:01 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:01 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:01 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:01 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 16:22:01 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/detail.php
DEBUG - 2016-09-06 16:22:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:22:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:22:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:22:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:22:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:22:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:22:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:22:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:22:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:22:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:22:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:22:01 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:22:01 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-09-06 16:22:01 --> Final output sent to browser
DEBUG - 2016-09-06 16:22:01 --> Total execution time: 4.6933
DEBUG - 2016-09-06 16:22:01 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:22:01 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:22:01 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:22:01 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:22:01 --> Controller Class Initialized
DEBUG - 2016-09-06 16:22:01 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:22:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:22:01 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:22:01 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:22:02 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:22:02 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:22:02 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:02 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:02 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:02 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:02 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:02 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:02 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:02 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:02 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 16:22:02 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/detail.php
DEBUG - 2016-09-06 16:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:22:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:22:02 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-09-06 16:22:02 --> Final output sent to browser
DEBUG - 2016-09-06 16:22:02 --> Total execution time: 5.7936
DEBUG - 2016-09-06 16:22:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:22:03 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:22:03 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:22:03 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:22:03 --> Controller Class Initialized
DEBUG - 2016-09-06 16:22:03 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:22:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:22:03 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:22:03 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:22:03 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:22:03 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:22:03 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:03 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:03 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:03 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:03 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:03 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:03 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:03 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:03 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 16:22:03 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/detail.php
DEBUG - 2016-09-06 16:22:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:22:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:22:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:22:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:22:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:22:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:22:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:22:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:22:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:22:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:22:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:22:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:22:04 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-09-06 16:22:04 --> Final output sent to browser
DEBUG - 2016-09-06 16:22:04 --> Total execution time: 6.8926
DEBUG - 2016-09-06 16:22:28 --> Config Class Initialized
DEBUG - 2016-09-06 16:22:28 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:22:29 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:22:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:22:29 --> URI Class Initialized
DEBUG - 2016-09-06 16:22:29 --> Router Class Initialized
DEBUG - 2016-09-06 16:22:29 --> Output Class Initialized
DEBUG - 2016-09-06 16:22:29 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 16:22:29 --> Security Class Initialized
DEBUG - 2016-09-06 16:22:29 --> Input Class Initialized
DEBUG - 2016-09-06 16:22:29 --> XSS Filtering completed
DEBUG - 2016-09-06 16:22:29 --> XSS Filtering completed
DEBUG - 2016-09-06 16:22:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:22:29 --> Language Class Initialized
DEBUG - 2016-09-06 16:22:29 --> Loader Class Initialized
DEBUG - 2016-09-06 16:22:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:22:29 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:22:29 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:22:29 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:22:29 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:22:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:22:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:22:29 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:22:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:22:29 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:22:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:22:29 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:22:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:22:29 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:22:29 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:22:29 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:22:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:22:30 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:22:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:22:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:22:30 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:22:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:22:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:22:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:22:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:22:30 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:22:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:22:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:22:30 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:22:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:22:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:22:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:22:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:22:30 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:22:30 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:22:30 --> Session Class Initialized
DEBUG - 2016-09-06 16:22:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:22:30 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:22:30 --> Session routines successfully run
DEBUG - 2016-09-06 16:22:30 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:22:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:22:30 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:22:30 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:22:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:22:31 --> Controller Class Initialized
DEBUG - 2016-09-06 16:22:31 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:22:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:22:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:22:31 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:22:31 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:22:31 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:22:31 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:31 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:31 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:31 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:31 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:31 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:31 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:31 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:31 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 16:22:31 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/detail.php
DEBUG - 2016-09-06 16:22:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:22:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:22:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:22:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:22:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:22:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:22:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:22:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:22:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:22:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:22:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:22:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:22:32 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-09-06 16:22:32 --> Final output sent to browser
DEBUG - 2016-09-06 16:22:32 --> Total execution time: 2.6136
DEBUG - 2016-09-06 16:22:49 --> Config Class Initialized
DEBUG - 2016-09-06 16:22:49 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:22:49 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:22:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:22:49 --> URI Class Initialized
DEBUG - 2016-09-06 16:22:49 --> Router Class Initialized
DEBUG - 2016-09-06 16:22:49 --> Output Class Initialized
DEBUG - 2016-09-06 16:22:49 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 16:22:49 --> Security Class Initialized
DEBUG - 2016-09-06 16:22:49 --> Input Class Initialized
DEBUG - 2016-09-06 16:22:49 --> XSS Filtering completed
DEBUG - 2016-09-06 16:22:49 --> XSS Filtering completed
DEBUG - 2016-09-06 16:22:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:22:49 --> Language Class Initialized
DEBUG - 2016-09-06 16:22:49 --> Loader Class Initialized
DEBUG - 2016-09-06 16:22:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:22:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:22:49 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:22:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:22:49 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:22:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:22:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:22:50 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:22:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:22:50 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:22:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:22:50 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:22:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:22:50 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:22:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:22:50 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:22:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:22:50 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:22:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:22:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:22:50 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:22:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:22:50 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:22:50 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:22:50 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:22:50 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:22:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:22:50 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:22:50 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:22:50 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:22:50 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:22:50 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:22:50 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:22:50 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:22:51 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:22:51 --> Session Class Initialized
DEBUG - 2016-09-06 16:22:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:22:51 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:22:51 --> Session routines successfully run
DEBUG - 2016-09-06 16:22:51 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:22:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:22:51 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:22:51 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:22:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:22:51 --> Controller Class Initialized
DEBUG - 2016-09-06 16:22:51 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:22:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:22:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:22:51 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:22:51 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:22:51 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:22:51 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:51 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:51 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:51 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:51 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:51 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:51 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:51 --> Model Class Initialized
DEBUG - 2016-09-06 16:22:51 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 16:22:51 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/detail.php
DEBUG - 2016-09-06 16:22:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:22:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:22:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:22:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:22:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:22:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:22:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:22:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:22:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:22:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:22:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:22:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:22:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-09-06 16:22:52 --> Final output sent to browser
DEBUG - 2016-09-06 16:22:52 --> Total execution time: 2.6332
DEBUG - 2016-09-06 16:23:42 --> Config Class Initialized
DEBUG - 2016-09-06 16:23:42 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:23:42 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:23:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:23:42 --> URI Class Initialized
DEBUG - 2016-09-06 16:23:42 --> Router Class Initialized
DEBUG - 2016-09-06 16:23:42 --> Output Class Initialized
DEBUG - 2016-09-06 16:23:42 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 16:23:42 --> Security Class Initialized
DEBUG - 2016-09-06 16:23:42 --> Input Class Initialized
DEBUG - 2016-09-06 16:23:42 --> XSS Filtering completed
DEBUG - 2016-09-06 16:23:42 --> XSS Filtering completed
DEBUG - 2016-09-06 16:23:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:23:42 --> Language Class Initialized
DEBUG - 2016-09-06 16:23:42 --> Loader Class Initialized
DEBUG - 2016-09-06 16:23:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:23:42 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:23:42 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:23:42 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:23:42 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:23:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:23:42 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:23:42 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:23:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:23:43 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:23:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:23:43 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:23:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:23:43 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:23:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:23:43 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:23:43 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:23:43 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:23:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:23:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:23:43 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:23:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:23:43 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:23:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:23:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:23:43 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:23:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:23:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:23:43 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:23:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:23:43 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:23:43 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:23:43 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:23:43 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:23:43 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:23:43 --> Session Class Initialized
DEBUG - 2016-09-06 16:23:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:23:44 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:23:44 --> Session routines successfully run
DEBUG - 2016-09-06 16:23:44 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:23:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:23:44 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:23:44 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:23:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:23:44 --> Controller Class Initialized
DEBUG - 2016-09-06 16:23:44 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:23:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:23:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:23:44 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:23:44 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:23:44 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:23:44 --> Model Class Initialized
DEBUG - 2016-09-06 16:23:44 --> Model Class Initialized
DEBUG - 2016-09-06 16:23:44 --> Model Class Initialized
DEBUG - 2016-09-06 16:23:44 --> Model Class Initialized
DEBUG - 2016-09-06 16:23:44 --> Model Class Initialized
DEBUG - 2016-09-06 16:23:44 --> Model Class Initialized
DEBUG - 2016-09-06 16:23:44 --> Model Class Initialized
DEBUG - 2016-09-06 16:23:44 --> Model Class Initialized
DEBUG - 2016-09-06 16:23:44 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 16:23:44 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/detail.php
DEBUG - 2016-09-06 16:23:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:23:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:23:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:23:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:23:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:23:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:23:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:23:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:23:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:23:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:23:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:23:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:23:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-09-06 16:23:45 --> Final output sent to browser
DEBUG - 2016-09-06 16:23:45 --> Total execution time: 2.6667
DEBUG - 2016-09-06 16:23:47 --> Config Class Initialized
DEBUG - 2016-09-06 16:23:47 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:23:47 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:23:47 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:23:47 --> URI Class Initialized
DEBUG - 2016-09-06 16:23:48 --> Router Class Initialized
DEBUG - 2016-09-06 16:23:48 --> Output Class Initialized
DEBUG - 2016-09-06 16:23:48 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 16:23:48 --> Security Class Initialized
DEBUG - 2016-09-06 16:23:48 --> Input Class Initialized
DEBUG - 2016-09-06 16:23:48 --> XSS Filtering completed
DEBUG - 2016-09-06 16:23:48 --> XSS Filtering completed
DEBUG - 2016-09-06 16:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:23:48 --> Language Class Initialized
DEBUG - 2016-09-06 16:23:48 --> Loader Class Initialized
DEBUG - 2016-09-06 16:23:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:23:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:23:48 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:23:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:23:48 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:23:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:23:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:23:48 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:23:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:23:48 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:23:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:23:48 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:23:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:23:48 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:23:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:23:48 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:23:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:23:48 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:23:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:23:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:23:49 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:23:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:23:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:23:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:23:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:23:49 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:23:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:23:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:23:49 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:23:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:23:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:23:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:23:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:23:49 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:23:49 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:23:49 --> Session Class Initialized
DEBUG - 2016-09-06 16:23:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:23:49 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:23:49 --> Session routines successfully run
DEBUG - 2016-09-06 16:23:49 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:23:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:23:49 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:23:49 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:23:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:23:49 --> Controller Class Initialized
DEBUG - 2016-09-06 16:23:50 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:23:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:23:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:23:50 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:23:50 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:23:50 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:23:50 --> Model Class Initialized
DEBUG - 2016-09-06 16:23:50 --> Model Class Initialized
DEBUG - 2016-09-06 16:23:50 --> Model Class Initialized
DEBUG - 2016-09-06 16:23:50 --> Model Class Initialized
DEBUG - 2016-09-06 16:23:50 --> Model Class Initialized
DEBUG - 2016-09-06 16:23:50 --> Model Class Initialized
DEBUG - 2016-09-06 16:23:50 --> Model Class Initialized
DEBUG - 2016-09-06 16:23:50 --> Model Class Initialized
DEBUG - 2016-09-06 16:23:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-06 16:23:50 --> Pagination Class Initialized
DEBUG - 2016-09-06 16:23:50 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 16:23:50 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/index.php
DEBUG - 2016-09-06 16:23:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:23:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:23:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:23:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:23:50 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-09-06 16:23:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:23:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:23:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:23:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:23:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:23:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:23:51 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-09-06 16:23:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:23:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:23:51 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55961f1d1ca16fdfc4239ae1901a174e
DEBUG - 2016-09-06 16:23:51 --> Final output sent to browser
DEBUG - 2016-09-06 16:23:51 --> Total execution time: 2.7443
DEBUG - 2016-09-06 16:23:54 --> Config Class Initialized
DEBUG - 2016-09-06 16:23:54 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:23:54 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:23:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:23:54 --> URI Class Initialized
DEBUG - 2016-09-06 16:23:54 --> Router Class Initialized
DEBUG - 2016-09-06 16:23:54 --> Output Class Initialized
DEBUG - 2016-09-06 16:23:54 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 16:23:54 --> Security Class Initialized
DEBUG - 2016-09-06 16:23:54 --> Input Class Initialized
DEBUG - 2016-09-06 16:23:54 --> XSS Filtering completed
DEBUG - 2016-09-06 16:23:54 --> XSS Filtering completed
DEBUG - 2016-09-06 16:23:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:23:54 --> Language Class Initialized
DEBUG - 2016-09-06 16:23:54 --> Loader Class Initialized
DEBUG - 2016-09-06 16:23:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:23:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:23:54 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:23:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:23:55 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:23:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:23:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:23:55 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:23:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:23:55 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:23:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:23:55 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:23:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:23:55 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:23:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:23:55 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:23:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:23:55 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:23:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:23:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:23:55 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:23:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:23:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:23:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:23:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:23:55 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:23:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:23:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:23:55 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:23:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:23:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:23:56 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:23:56 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:23:56 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:23:56 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:23:56 --> Session Class Initialized
DEBUG - 2016-09-06 16:23:56 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:23:56 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:23:56 --> Session routines successfully run
DEBUG - 2016-09-06 16:23:56 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:23:56 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:23:56 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:23:56 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:23:56 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:23:56 --> Controller Class Initialized
DEBUG - 2016-09-06 16:23:56 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:23:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:23:56 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:23:56 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:23:56 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:23:56 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:23:56 --> Model Class Initialized
DEBUG - 2016-09-06 16:23:56 --> Model Class Initialized
DEBUG - 2016-09-06 16:23:56 --> Model Class Initialized
DEBUG - 2016-09-06 16:23:56 --> Model Class Initialized
DEBUG - 2016-09-06 16:23:56 --> Model Class Initialized
DEBUG - 2016-09-06 16:23:56 --> Model Class Initialized
DEBUG - 2016-09-06 16:23:56 --> Model Class Initialized
DEBUG - 2016-09-06 16:23:57 --> Model Class Initialized
DEBUG - 2016-09-06 16:23:57 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 16:23:57 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/detail.php
DEBUG - 2016-09-06 16:23:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:23:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:23:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:23:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:23:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:23:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:23:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:23:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:23:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:23:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:23:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:23:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:23:57 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-09-06 16:23:57 --> Final output sent to browser
DEBUG - 2016-09-06 16:23:57 --> Total execution time: 2.6587
DEBUG - 2016-09-06 16:26:22 --> Config Class Initialized
DEBUG - 2016-09-06 16:26:22 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:26:22 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:26:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:26:22 --> URI Class Initialized
DEBUG - 2016-09-06 16:26:22 --> Router Class Initialized
DEBUG - 2016-09-06 16:26:22 --> Output Class Initialized
DEBUG - 2016-09-06 16:26:22 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 16:26:22 --> Security Class Initialized
DEBUG - 2016-09-06 16:26:22 --> Input Class Initialized
DEBUG - 2016-09-06 16:26:22 --> XSS Filtering completed
DEBUG - 2016-09-06 16:26:23 --> XSS Filtering completed
DEBUG - 2016-09-06 16:26:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:26:23 --> Language Class Initialized
DEBUG - 2016-09-06 16:26:23 --> Loader Class Initialized
DEBUG - 2016-09-06 16:26:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:26:23 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:26:23 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:26:23 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:26:23 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:26:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:26:23 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:26:23 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:26:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:26:23 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:26:23 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:26:23 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:26:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:26:23 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:26:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:26:23 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:26:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:26:23 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:26:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:26:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:26:23 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:26:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:26:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:26:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:26:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:26:24 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:26:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:26:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:26:24 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:26:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:26:24 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:26:24 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:26:24 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:26:24 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:26:24 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:26:24 --> Session Class Initialized
DEBUG - 2016-09-06 16:26:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:26:24 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:26:24 --> Session routines successfully run
DEBUG - 2016-09-06 16:26:24 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:26:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:26:24 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:26:24 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:26:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:26:24 --> Controller Class Initialized
DEBUG - 2016-09-06 16:26:24 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:26:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:26:24 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:26:24 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:26:24 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:26:25 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:26:25 --> Model Class Initialized
DEBUG - 2016-09-06 16:26:25 --> Model Class Initialized
DEBUG - 2016-09-06 16:26:25 --> Model Class Initialized
DEBUG - 2016-09-06 16:26:25 --> Model Class Initialized
DEBUG - 2016-09-06 16:26:25 --> Model Class Initialized
DEBUG - 2016-09-06 16:26:25 --> Model Class Initialized
DEBUG - 2016-09-06 16:26:25 --> Model Class Initialized
DEBUG - 2016-09-06 16:26:25 --> Model Class Initialized
DEBUG - 2016-09-06 16:26:25 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 16:26:25 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/detail.php
DEBUG - 2016-09-06 16:26:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:26:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:26:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:26:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:26:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:26:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:26:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:26:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:26:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:26:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:26:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:26:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:26:25 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-09-06 16:26:25 --> Final output sent to browser
DEBUG - 2016-09-06 16:26:25 --> Total execution time: 2.7517
DEBUG - 2016-09-06 16:26:31 --> Config Class Initialized
DEBUG - 2016-09-06 16:26:31 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:26:31 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:26:31 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:26:31 --> URI Class Initialized
DEBUG - 2016-09-06 16:26:31 --> Router Class Initialized
DEBUG - 2016-09-06 16:26:31 --> Output Class Initialized
DEBUG - 2016-09-06 16:26:31 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 16:26:31 --> Security Class Initialized
DEBUG - 2016-09-06 16:26:31 --> Input Class Initialized
DEBUG - 2016-09-06 16:26:31 --> XSS Filtering completed
DEBUG - 2016-09-06 16:26:31 --> XSS Filtering completed
DEBUG - 2016-09-06 16:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:26:31 --> Language Class Initialized
DEBUG - 2016-09-06 16:26:31 --> Loader Class Initialized
DEBUG - 2016-09-06 16:26:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:26:31 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:26:31 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:26:31 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:26:31 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:26:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:26:32 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:26:32 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:26:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:26:32 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:26:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:26:32 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:26:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:26:32 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:26:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:26:32 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:26:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:26:32 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:26:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:26:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:26:32 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:26:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:26:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:26:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:26:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:26:32 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:26:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:26:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:26:32 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:26:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:26:32 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:26:32 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:26:32 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:26:33 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:26:33 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:26:33 --> Session Class Initialized
DEBUG - 2016-09-06 16:26:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:26:33 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:26:33 --> Session routines successfully run
DEBUG - 2016-09-06 16:26:33 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:26:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:26:33 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:26:33 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:26:33 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:26:33 --> Controller Class Initialized
DEBUG - 2016-09-06 16:26:33 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:26:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:26:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:26:33 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:26:33 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:26:33 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:26:33 --> Model Class Initialized
DEBUG - 2016-09-06 16:26:33 --> Model Class Initialized
DEBUG - 2016-09-06 16:26:33 --> Model Class Initialized
DEBUG - 2016-09-06 16:26:33 --> Model Class Initialized
DEBUG - 2016-09-06 16:26:33 --> Model Class Initialized
DEBUG - 2016-09-06 16:26:33 --> Model Class Initialized
DEBUG - 2016-09-06 16:26:33 --> Model Class Initialized
DEBUG - 2016-09-06 16:26:33 --> Model Class Initialized
DEBUG - 2016-09-06 16:26:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-06 16:26:34 --> Pagination Class Initialized
DEBUG - 2016-09-06 16:26:34 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-06 16:26:34 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/index.php
DEBUG - 2016-09-06 16:26:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:26:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:26:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:26:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:26:34 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-09-06 16:26:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:26:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:26:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:26:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:26:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:26:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:26:34 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-09-06 16:26:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:26:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:26:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55961f1d1ca16fdfc4239ae1901a174e
DEBUG - 2016-09-06 16:26:34 --> Final output sent to browser
DEBUG - 2016-09-06 16:26:34 --> Total execution time: 2.8108
DEBUG - 2016-09-06 16:28:01 --> Config Class Initialized
DEBUG - 2016-09-06 16:28:01 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:28:01 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:28:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:28:01 --> URI Class Initialized
DEBUG - 2016-09-06 16:28:01 --> Router Class Initialized
DEBUG - 2016-09-06 16:28:01 --> Output Class Initialized
DEBUG - 2016-09-06 16:28:01 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 16:28:01 --> Security Class Initialized
DEBUG - 2016-09-06 16:28:01 --> Input Class Initialized
DEBUG - 2016-09-06 16:28:01 --> XSS Filtering completed
DEBUG - 2016-09-06 16:28:01 --> XSS Filtering completed
DEBUG - 2016-09-06 16:28:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:28:01 --> Language Class Initialized
DEBUG - 2016-09-06 16:28:01 --> Loader Class Initialized
DEBUG - 2016-09-06 16:28:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:28:02 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:28:02 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:28:02 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:28:02 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:28:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:28:02 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:28:02 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:28:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:28:02 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:28:02 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:28:02 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:28:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:28:02 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:28:02 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:28:02 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:28:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:28:02 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:28:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:28:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:28:02 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:28:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:28:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:28:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:28:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:28:02 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:28:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:28:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:28:03 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:28:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:28:03 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:28:03 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:28:03 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:28:03 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:28:03 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:28:03 --> Session Class Initialized
DEBUG - 2016-09-06 16:28:03 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:28:03 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:28:03 --> Session routines successfully run
DEBUG - 2016-09-06 16:28:03 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:28:03 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:28:03 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:28:03 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:28:03 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:28:03 --> Controller Class Initialized
DEBUG - 2016-09-06 16:28:03 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:28:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:28:03 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:28:03 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:28:03 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:28:03 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:28:03 --> Model Class Initialized
DEBUG - 2016-09-06 16:28:03 --> Model Class Initialized
DEBUG - 2016-09-06 16:28:03 --> Model Class Initialized
DEBUG - 2016-09-06 16:28:04 --> Model Class Initialized
DEBUG - 2016-09-06 16:28:04 --> Model Class Initialized
DEBUG - 2016-09-06 16:28:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-06 16:28:04 --> Pagination Class Initialized
DEBUG - 2016-09-06 16:28:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-06 16:28:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/index.php
DEBUG - 2016-09-06 16:28:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:28:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:28:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:28:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:28:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-09-06 16:28:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:28:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:28:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:28:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:28:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:28:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:28:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-09-06 16:28:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:28:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:28:04 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c2a3e0401bd35d4fcac4bae5f9412231
DEBUG - 2016-09-06 16:28:04 --> Final output sent to browser
DEBUG - 2016-09-06 16:28:04 --> Total execution time: 2.7464
DEBUG - 2016-09-06 16:28:07 --> Config Class Initialized
DEBUG - 2016-09-06 16:28:07 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:28:07 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:28:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:28:07 --> URI Class Initialized
DEBUG - 2016-09-06 16:28:07 --> Router Class Initialized
DEBUG - 2016-09-06 16:28:07 --> Output Class Initialized
DEBUG - 2016-09-06 16:28:07 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 16:28:08 --> Security Class Initialized
DEBUG - 2016-09-06 16:28:08 --> Input Class Initialized
DEBUG - 2016-09-06 16:28:08 --> XSS Filtering completed
DEBUG - 2016-09-06 16:28:08 --> XSS Filtering completed
DEBUG - 2016-09-06 16:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:28:08 --> Language Class Initialized
DEBUG - 2016-09-06 16:28:08 --> Loader Class Initialized
DEBUG - 2016-09-06 16:28:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:28:08 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:28:08 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:28:08 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:28:08 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:28:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:28:08 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:28:08 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:28:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:28:08 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:28:08 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:28:08 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:28:08 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:28:08 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:28:08 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:28:08 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:28:08 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:28:08 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:28:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:28:08 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:28:09 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:28:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:28:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:28:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:28:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:28:09 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:28:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:28:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:28:09 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:28:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:28:09 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:28:09 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:28:09 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:28:09 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:28:09 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:28:09 --> Session Class Initialized
DEBUG - 2016-09-06 16:28:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:28:09 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:28:09 --> Session routines successfully run
DEBUG - 2016-09-06 16:28:09 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:28:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:28:09 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:28:09 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:28:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:28:09 --> Controller Class Initialized
DEBUG - 2016-09-06 16:28:09 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:28:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:28:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:28:10 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:28:10 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:28:10 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:28:10 --> Model Class Initialized
DEBUG - 2016-09-06 16:28:10 --> Model Class Initialized
DEBUG - 2016-09-06 16:28:10 --> Model Class Initialized
DEBUG - 2016-09-06 16:28:10 --> Model Class Initialized
DEBUG - 2016-09-06 16:28:10 --> Model Class Initialized
DEBUG - 2016-09-06 16:28:10 --> Model Class Initialized
DEBUG - 2016-09-06 16:28:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-06 16:28:10 --> Pagination Class Initialized
DEBUG - 2016-09-06 16:28:10 --> Model Class Initialized
DEBUG - 2016-09-06 16:28:10 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-06 16:28:10 --> Model Class Initialized
DEBUG - 2016-09-06 16:28:10 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-06 16:28:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-09-06 16:28:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-09-06 16:28:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:28:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:28:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:28:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:28:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-09-06 16:28:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:28:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:28:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:28:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:28:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:28:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:28:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-09-06 16:28:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:28:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:28:11 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/3b8a012aded2aa06b38d95457bf1daeb
DEBUG - 2016-09-06 16:28:11 --> Final output sent to browser
DEBUG - 2016-09-06 16:28:11 --> Total execution time: 2.9867
DEBUG - 2016-09-06 16:30:40 --> Config Class Initialized
DEBUG - 2016-09-06 16:30:40 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:30:40 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:30:40 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:30:40 --> URI Class Initialized
DEBUG - 2016-09-06 16:30:40 --> Router Class Initialized
DEBUG - 2016-09-06 16:30:40 --> Output Class Initialized
DEBUG - 2016-09-06 16:30:41 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 16:30:41 --> Security Class Initialized
DEBUG - 2016-09-06 16:30:41 --> Input Class Initialized
DEBUG - 2016-09-06 16:30:41 --> XSS Filtering completed
DEBUG - 2016-09-06 16:30:41 --> XSS Filtering completed
DEBUG - 2016-09-06 16:30:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:30:41 --> Language Class Initialized
DEBUG - 2016-09-06 16:30:41 --> Loader Class Initialized
DEBUG - 2016-09-06 16:30:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:30:41 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:30:41 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:30:41 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:30:41 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:30:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:30:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:30:41 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:30:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:30:41 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:30:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:30:41 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:30:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:30:41 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:30:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:30:41 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:30:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:30:41 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:30:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:30:42 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:30:42 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:30:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:30:42 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:30:42 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:30:42 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:30:42 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:30:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:30:42 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:30:42 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:30:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:30:42 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:30:42 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:30:42 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:30:42 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:30:42 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:30:42 --> Session Class Initialized
DEBUG - 2016-09-06 16:30:42 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:30:42 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:30:42 --> Session routines successfully run
DEBUG - 2016-09-06 16:30:42 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:30:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:30:42 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:30:42 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:30:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:30:42 --> Controller Class Initialized
DEBUG - 2016-09-06 16:30:42 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:30:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:30:43 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:30:43 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:30:43 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:30:43 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:30:43 --> Model Class Initialized
DEBUG - 2016-09-06 16:30:43 --> Model Class Initialized
DEBUG - 2016-09-06 16:30:43 --> Model Class Initialized
DEBUG - 2016-09-06 16:30:43 --> Model Class Initialized
DEBUG - 2016-09-06 16:30:43 --> Model Class Initialized
DEBUG - 2016-09-06 16:30:43 --> Model Class Initialized
DEBUG - 2016-09-06 16:30:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-06 16:30:43 --> Pagination Class Initialized
DEBUG - 2016-09-06 16:30:43 --> Model Class Initialized
DEBUG - 2016-09-06 16:30:43 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-06 16:30:43 --> Model Class Initialized
DEBUG - 2016-09-06 16:30:43 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-06 16:30:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-09-06 16:30:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-09-06 16:30:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:30:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:30:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:30:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:30:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-09-06 16:30:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-09-06 16:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:30:44 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/3b8a012aded2aa06b38d95457bf1daeb
DEBUG - 2016-09-06 16:30:44 --> Final output sent to browser
DEBUG - 2016-09-06 16:30:44 --> Total execution time: 2.9936
DEBUG - 2016-09-06 16:31:39 --> Config Class Initialized
DEBUG - 2016-09-06 16:31:39 --> Hooks Class Initialized
DEBUG - 2016-09-06 16:31:39 --> Utf8 Class Initialized
DEBUG - 2016-09-06 16:31:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-06 16:31:39 --> URI Class Initialized
DEBUG - 2016-09-06 16:31:39 --> Router Class Initialized
DEBUG - 2016-09-06 16:31:39 --> Output Class Initialized
DEBUG - 2016-09-06 16:31:39 --> Cache file has expired. File deleted
DEBUG - 2016-09-06 16:31:40 --> Security Class Initialized
DEBUG - 2016-09-06 16:31:40 --> Input Class Initialized
DEBUG - 2016-09-06 16:31:40 --> XSS Filtering completed
DEBUG - 2016-09-06 16:31:40 --> XSS Filtering completed
DEBUG - 2016-09-06 16:31:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-06 16:31:40 --> Language Class Initialized
DEBUG - 2016-09-06 16:31:40 --> Loader Class Initialized
DEBUG - 2016-09-06 16:31:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-06 16:31:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-06 16:31:40 --> Helper loaded: url_helper
DEBUG - 2016-09-06 16:31:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-06 16:31:40 --> Helper loaded: file_helper
DEBUG - 2016-09-06 16:31:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:31:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-06 16:31:40 --> Helper loaded: conf_helper
DEBUG - 2016-09-06 16:31:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-06 16:31:40 --> Check Exists common_helper.php: No
DEBUG - 2016-09-06 16:31:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-06 16:31:40 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:31:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-06 16:31:40 --> Helper loaded: common_helper
DEBUG - 2016-09-06 16:31:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-06 16:31:40 --> Helper loaded: form_helper
DEBUG - 2016-09-06 16:31:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-06 16:31:40 --> Helper loaded: security_helper
DEBUG - 2016-09-06 16:31:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:31:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-06 16:31:41 --> Helper loaded: lang_helper
DEBUG - 2016-09-06 16:31:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-06 16:31:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-06 16:31:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-06 16:31:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-06 16:31:41 --> Helper loaded: atlant_helper
DEBUG - 2016-09-06 16:31:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:31:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-06 16:31:41 --> Helper loaded: crypto_helper
DEBUG - 2016-09-06 16:31:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-06 16:31:41 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-06 16:31:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-06 16:31:41 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-06 16:31:41 --> Helper loaded: sidika_helper
DEBUG - 2016-09-06 16:31:41 --> Database Driver Class Initialized
DEBUG - 2016-09-06 16:31:41 --> Session Class Initialized
DEBUG - 2016-09-06 16:31:41 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-06 16:31:41 --> Helper loaded: string_helper
DEBUG - 2016-09-06 16:31:41 --> Session routines successfully run
DEBUG - 2016-09-06 16:31:41 --> Native_session Class Initialized
DEBUG - 2016-09-06 16:31:41 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-06 16:31:41 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:31:41 --> Form Validation Class Initialized
DEBUG - 2016-09-06 16:31:41 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-06 16:31:41 --> Controller Class Initialized
DEBUG - 2016-09-06 16:31:41 --> Carabiner: Library initialized.
DEBUG - 2016-09-06 16:31:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-06 16:31:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-06 16:31:42 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:31:42 --> Carabiner: library configured.
DEBUG - 2016-09-06 16:31:42 --> User Agent Class Initialized
DEBUG - 2016-09-06 16:31:42 --> Model Class Initialized
DEBUG - 2016-09-06 16:31:42 --> Model Class Initialized
DEBUG - 2016-09-06 16:31:42 --> Model Class Initialized
DEBUG - 2016-09-06 16:31:42 --> Model Class Initialized
DEBUG - 2016-09-06 16:31:42 --> Model Class Initialized
DEBUG - 2016-09-06 16:31:42 --> Model Class Initialized
DEBUG - 2016-09-06 16:31:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-06 16:31:42 --> Pagination Class Initialized
DEBUG - 2016-09-06 16:31:42 --> Model Class Initialized
DEBUG - 2016-09-06 16:31:42 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-06 16:31:42 --> Model Class Initialized
DEBUG - 2016-09-06 16:31:42 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-06 16:31:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history/diklat_pegawai.php
DEBUG - 2016-09-06 16:31:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/history.php
DEBUG - 2016-09-06 16:31:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:31:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:31:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:31:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:31:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-09-06 16:31:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:31:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:31:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-06 16:31:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-06 16:31:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-06 16:31:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-06 16:31:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/history_js.php
DEBUG - 2016-09-06 16:31:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-06 16:31:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-06 16:31:43 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/3b8a012aded2aa06b38d95457bf1daeb
DEBUG - 2016-09-06 16:31:43 --> Final output sent to browser
DEBUG - 2016-09-06 16:31:43 --> Total execution time: 3.0137
