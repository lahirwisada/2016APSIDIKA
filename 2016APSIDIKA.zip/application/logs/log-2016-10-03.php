<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-10-03 14:01:53 --> Config Class Initialized
DEBUG - 2016-10-03 14:01:53 --> Hooks Class Initialized
DEBUG - 2016-10-03 14:01:53 --> Utf8 Class Initialized
DEBUG - 2016-10-03 14:01:53 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 14:01:53 --> URI Class Initialized
DEBUG - 2016-10-03 14:01:53 --> Router Class Initialized
DEBUG - 2016-10-03 14:01:53 --> No URI present. Default controller set.
DEBUG - 2016-10-03 14:01:53 --> Output Class Initialized
DEBUG - 2016-10-03 14:01:54 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 14:01:54 --> Security Class Initialized
DEBUG - 2016-10-03 14:01:54 --> Input Class Initialized
DEBUG - 2016-10-03 14:01:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 14:01:54 --> Language Class Initialized
DEBUG - 2016-10-03 14:01:54 --> Loader Class Initialized
DEBUG - 2016-10-03 14:01:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 14:01:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 14:01:54 --> Helper loaded: url_helper
DEBUG - 2016-10-03 14:01:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 14:01:54 --> Helper loaded: file_helper
DEBUG - 2016-10-03 14:01:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 14:01:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 14:01:54 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 14:01:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 14:01:54 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 14:01:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 14:01:54 --> Helper loaded: common_helper
DEBUG - 2016-10-03 14:01:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 14:01:54 --> Helper loaded: common_helper
DEBUG - 2016-10-03 14:01:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 14:01:54 --> Helper loaded: form_helper
DEBUG - 2016-10-03 14:01:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 14:01:54 --> Helper loaded: security_helper
DEBUG - 2016-10-03 14:01:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 14:01:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 14:01:54 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 14:01:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 14:01:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 14:01:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 14:01:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 14:01:54 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 14:01:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 14:01:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 14:01:54 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 14:01:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 14:01:54 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 14:01:54 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 14:01:54 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 14:01:54 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 14:01:54 --> Database Driver Class Initialized
DEBUG - 2016-10-03 14:01:54 --> Session Class Initialized
DEBUG - 2016-10-03 14:01:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 14:01:54 --> Helper loaded: string_helper
DEBUG - 2016-10-03 14:01:54 --> A session cookie was not found.
DEBUG - 2016-10-03 14:01:54 --> Session routines successfully run
DEBUG - 2016-10-03 14:01:54 --> Native_session Class Initialized
DEBUG - 2016-10-03 14:01:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 14:01:54 --> Form Validation Class Initialized
DEBUG - 2016-10-03 14:01:54 --> Form Validation Class Initialized
DEBUG - 2016-10-03 14:01:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 14:01:54 --> Controller Class Initialized
DEBUG - 2016-10-03 14:01:54 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 14:01:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 14:01:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 14:01:54 --> Carabiner: library configured.
DEBUG - 2016-10-03 14:01:54 --> Carabiner: library configured.
DEBUG - 2016-10-03 14:01:54 --> User Agent Class Initialized
DEBUG - 2016-10-03 14:01:54 --> Model Class Initialized
DEBUG - 2016-10-03 14:01:54 --> Model Class Initialized
DEBUG - 2016-10-03 14:01:54 --> Model Class Initialized
ERROR - 2016-10-03 14:01:55 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-10-03 14:01:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-10-03 14:01:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-10-03 14:01:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-03 14:01:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 14:01:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-03 14:01:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-03 14:01:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-03 14:01:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-03 14:01:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-03 14:01:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 14:01:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-03 14:01:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-03 14:01:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 14:01:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-03 14:01:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-03 14:01:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-03 14:01:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-03 14:01:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-03 14:01:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 14:01:55 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-03 14:01:55 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-10-03 14:01:55 --> Final output sent to browser
DEBUG - 2016-10-03 14:01:55 --> Total execution time: 1.8829
DEBUG - 2016-10-03 14:01:58 --> Config Class Initialized
DEBUG - 2016-10-03 14:01:58 --> Hooks Class Initialized
DEBUG - 2016-10-03 14:01:58 --> Utf8 Class Initialized
DEBUG - 2016-10-03 14:01:58 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 14:01:58 --> URI Class Initialized
DEBUG - 2016-10-03 14:01:58 --> Router Class Initialized
DEBUG - 2016-10-03 14:01:58 --> Output Class Initialized
DEBUG - 2016-10-03 14:01:58 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 14:01:58 --> Security Class Initialized
DEBUG - 2016-10-03 14:01:58 --> Input Class Initialized
DEBUG - 2016-10-03 14:01:58 --> XSS Filtering completed
DEBUG - 2016-10-03 14:01:58 --> XSS Filtering completed
DEBUG - 2016-10-03 14:01:58 --> XSS Filtering completed
DEBUG - 2016-10-03 14:01:58 --> XSS Filtering completed
DEBUG - 2016-10-03 14:01:58 --> XSS Filtering completed
DEBUG - 2016-10-03 14:01:58 --> XSS Filtering completed
DEBUG - 2016-10-03 14:01:58 --> XSS Filtering completed
DEBUG - 2016-10-03 14:01:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 14:01:58 --> Language Class Initialized
DEBUG - 2016-10-03 14:01:58 --> Loader Class Initialized
DEBUG - 2016-10-03 14:01:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 14:01:58 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 14:01:58 --> Helper loaded: url_helper
DEBUG - 2016-10-03 14:01:58 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 14:01:58 --> Helper loaded: file_helper
DEBUG - 2016-10-03 14:01:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 14:01:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 14:01:58 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 14:01:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 14:01:58 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 14:01:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 14:01:58 --> Helper loaded: common_helper
DEBUG - 2016-10-03 14:01:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 14:01:58 --> Helper loaded: common_helper
DEBUG - 2016-10-03 14:01:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 14:01:58 --> Helper loaded: form_helper
DEBUG - 2016-10-03 14:01:58 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 14:01:58 --> Helper loaded: security_helper
DEBUG - 2016-10-03 14:01:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 14:01:58 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 14:01:58 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 14:01:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 14:01:58 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 14:01:58 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 14:01:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 14:01:58 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 14:01:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 14:01:58 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 14:01:58 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 14:01:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 14:01:58 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 14:01:58 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 14:01:58 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 14:01:58 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 14:01:58 --> Database Driver Class Initialized
DEBUG - 2016-10-03 14:01:58 --> Session Class Initialized
DEBUG - 2016-10-03 14:01:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 14:01:58 --> Helper loaded: string_helper
DEBUG - 2016-10-03 14:01:58 --> Session routines successfully run
DEBUG - 2016-10-03 14:01:58 --> Native_session Class Initialized
DEBUG - 2016-10-03 14:01:58 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 14:01:58 --> Form Validation Class Initialized
DEBUG - 2016-10-03 14:01:58 --> Form Validation Class Initialized
DEBUG - 2016-10-03 14:01:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 14:01:58 --> Controller Class Initialized
DEBUG - 2016-10-03 14:01:58 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 14:01:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 14:01:58 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 14:01:58 --> Carabiner: library configured.
DEBUG - 2016-10-03 14:01:58 --> Carabiner: library configured.
DEBUG - 2016-10-03 14:01:58 --> User Agent Class Initialized
DEBUG - 2016-10-03 14:01:58 --> Model Class Initialized
DEBUG - 2016-10-03 14:01:58 --> Model Class Initialized
DEBUG - 2016-10-03 14:01:58 --> Model Class Initialized
DEBUG - 2016-10-03 14:01:58 --> Model Class Initialized
DEBUG - 2016-10-03 14:01:58 --> Model Class Initialized
DEBUG - 2016-10-03 14:01:58 --> Model Class Initialized
DEBUG - 2016-10-03 14:01:58 --> Model Class Initialized
DEBUG - 2016-10-03 14:01:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-10-03 14:01:59 --> Final output sent to browser
DEBUG - 2016-10-03 14:01:59 --> Total execution time: 0.8144
DEBUG - 2016-10-03 14:02:50 --> Config Class Initialized
DEBUG - 2016-10-03 14:02:50 --> Hooks Class Initialized
DEBUG - 2016-10-03 14:02:50 --> Utf8 Class Initialized
DEBUG - 2016-10-03 14:02:50 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 14:02:50 --> URI Class Initialized
DEBUG - 2016-10-03 14:02:50 --> Router Class Initialized
DEBUG - 2016-10-03 14:02:50 --> Output Class Initialized
DEBUG - 2016-10-03 14:02:50 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 14:02:51 --> Security Class Initialized
DEBUG - 2016-10-03 14:02:51 --> Input Class Initialized
DEBUG - 2016-10-03 14:02:51 --> XSS Filtering completed
DEBUG - 2016-10-03 14:02:51 --> XSS Filtering completed
DEBUG - 2016-10-03 14:02:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 14:02:51 --> Language Class Initialized
DEBUG - 2016-10-03 14:02:51 --> Loader Class Initialized
DEBUG - 2016-10-03 14:02:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 14:02:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 14:02:51 --> Helper loaded: url_helper
DEBUG - 2016-10-03 14:02:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 14:02:51 --> Helper loaded: file_helper
DEBUG - 2016-10-03 14:02:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 14:02:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 14:02:51 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 14:02:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 14:02:51 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 14:02:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 14:02:51 --> Helper loaded: common_helper
DEBUG - 2016-10-03 14:02:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 14:02:51 --> Helper loaded: common_helper
DEBUG - 2016-10-03 14:02:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 14:02:51 --> Helper loaded: form_helper
DEBUG - 2016-10-03 14:02:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 14:02:51 --> Helper loaded: security_helper
DEBUG - 2016-10-03 14:02:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 14:02:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 14:02:51 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 14:02:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 14:02:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 14:02:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 14:02:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 14:02:51 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 14:02:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 14:02:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 14:02:51 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 14:02:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 14:02:51 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 14:02:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 14:02:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 14:02:51 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 14:02:51 --> Database Driver Class Initialized
DEBUG - 2016-10-03 14:02:51 --> Session Class Initialized
DEBUG - 2016-10-03 14:02:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 14:02:51 --> Helper loaded: string_helper
DEBUG - 2016-10-03 14:02:51 --> Session routines successfully run
DEBUG - 2016-10-03 14:02:51 --> Native_session Class Initialized
DEBUG - 2016-10-03 14:02:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 14:02:51 --> Form Validation Class Initialized
DEBUG - 2016-10-03 14:02:51 --> Form Validation Class Initialized
DEBUG - 2016-10-03 14:02:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 14:02:51 --> Controller Class Initialized
DEBUG - 2016-10-03 14:02:51 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 14:02:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 14:02:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 14:02:51 --> Carabiner: library configured.
DEBUG - 2016-10-03 14:02:51 --> Carabiner: library configured.
DEBUG - 2016-10-03 14:02:51 --> User Agent Class Initialized
DEBUG - 2016-10-03 14:02:51 --> Model Class Initialized
DEBUG - 2016-10-03 14:02:51 --> Model Class Initialized
DEBUG - 2016-10-03 14:02:51 --> Model Class Initialized
DEBUG - 2016-10-03 14:02:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-10-03 14:02:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 14:02:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 14:02:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 14:02:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 14:02:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 14:02:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 14:02:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 14:02:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 14:02:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 14:02:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 14:02:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 14:02:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 14:02:51 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-10-03 14:02:51 --> Final output sent to browser
DEBUG - 2016-10-03 14:02:51 --> Total execution time: 0.2433
DEBUG - 2016-10-03 14:03:15 --> Config Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Hooks Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Utf8 Class Initialized
DEBUG - 2016-10-03 14:03:15 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 14:03:15 --> URI Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Router Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Output Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 14:03:15 --> Security Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Input Class Initialized
DEBUG - 2016-10-03 14:03:15 --> XSS Filtering completed
DEBUG - 2016-10-03 14:03:15 --> XSS Filtering completed
DEBUG - 2016-10-03 14:03:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 14:03:15 --> Language Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Loader Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 14:03:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 14:03:15 --> Helper loaded: url_helper
DEBUG - 2016-10-03 14:03:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 14:03:15 --> Helper loaded: file_helper
DEBUG - 2016-10-03 14:03:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 14:03:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 14:03:15 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 14:03:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 14:03:15 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 14:03:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 14:03:15 --> Helper loaded: common_helper
DEBUG - 2016-10-03 14:03:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 14:03:15 --> Helper loaded: common_helper
DEBUG - 2016-10-03 14:03:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 14:03:15 --> Helper loaded: form_helper
DEBUG - 2016-10-03 14:03:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 14:03:15 --> Helper loaded: security_helper
DEBUG - 2016-10-03 14:03:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 14:03:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 14:03:15 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 14:03:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 14:03:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 14:03:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 14:03:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 14:03:15 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 14:03:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 14:03:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 14:03:15 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 14:03:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 14:03:15 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 14:03:15 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 14:03:15 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 14:03:15 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 14:03:15 --> Database Driver Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Session Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 14:03:15 --> Helper loaded: string_helper
DEBUG - 2016-10-03 14:03:15 --> Session routines successfully run
DEBUG - 2016-10-03 14:03:15 --> Native_session Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 14:03:15 --> Form Validation Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Form Validation Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 14:03:15 --> Controller Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 14:03:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 14:03:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 14:03:15 --> Carabiner: library configured.
DEBUG - 2016-10-03 14:03:15 --> Carabiner: library configured.
DEBUG - 2016-10-03 14:03:15 --> User Agent Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Model Class Initialized
ERROR - 2016-10-03 14:03:15 --> Hak Akses modul/kontroller 'cdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-10-03 14:03:15 --> Config Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Hooks Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Utf8 Class Initialized
DEBUG - 2016-10-03 14:03:15 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 14:03:15 --> URI Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Router Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Output Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Security Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Input Class Initialized
DEBUG - 2016-10-03 14:03:15 --> XSS Filtering completed
DEBUG - 2016-10-03 14:03:15 --> XSS Filtering completed
DEBUG - 2016-10-03 14:03:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 14:03:15 --> Language Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Loader Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 14:03:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 14:03:15 --> Helper loaded: url_helper
DEBUG - 2016-10-03 14:03:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 14:03:15 --> Helper loaded: file_helper
DEBUG - 2016-10-03 14:03:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 14:03:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 14:03:15 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 14:03:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 14:03:15 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 14:03:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 14:03:15 --> Helper loaded: common_helper
DEBUG - 2016-10-03 14:03:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 14:03:15 --> Helper loaded: common_helper
DEBUG - 2016-10-03 14:03:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 14:03:15 --> Helper loaded: form_helper
DEBUG - 2016-10-03 14:03:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 14:03:15 --> Helper loaded: security_helper
DEBUG - 2016-10-03 14:03:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 14:03:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 14:03:15 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 14:03:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 14:03:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 14:03:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 14:03:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 14:03:15 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 14:03:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 14:03:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 14:03:15 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 14:03:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 14:03:15 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 14:03:15 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 14:03:15 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 14:03:15 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 14:03:15 --> Database Driver Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Session Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 14:03:15 --> Helper loaded: string_helper
DEBUG - 2016-10-03 14:03:15 --> Session routines successfully run
DEBUG - 2016-10-03 14:03:15 --> Native_session Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 14:03:15 --> Form Validation Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Form Validation Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 14:03:15 --> Controller Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 14:03:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 14:03:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 14:03:15 --> Carabiner: library configured.
DEBUG - 2016-10-03 14:03:15 --> Carabiner: library configured.
DEBUG - 2016-10-03 14:03:15 --> User Agent Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Model Class Initialized
ERROR - 2016-10-03 14:03:15 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-10-03 14:03:15 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 14:03:15 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-10-03 14:03:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-10-03 14:03:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-10-03 14:03:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-10-03 14:03:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-10-03 14:03:15 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-10-03 14:03:15 --> Final output sent to browser
DEBUG - 2016-10-03 14:03:15 --> Total execution time: 0.2336
DEBUG - 2016-10-03 14:03:15 --> Config Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Hooks Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Utf8 Class Initialized
DEBUG - 2016-10-03 14:03:15 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 14:03:15 --> URI Class Initialized
DEBUG - 2016-10-03 14:03:15 --> Router Class Initialized
ERROR - 2016-10-03 14:03:16 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-10-03 14:03:25 --> Config Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Hooks Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Utf8 Class Initialized
DEBUG - 2016-10-03 14:03:25 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 14:03:25 --> URI Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Router Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Output Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 14:03:25 --> Security Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Input Class Initialized
DEBUG - 2016-10-03 14:03:25 --> XSS Filtering completed
DEBUG - 2016-10-03 14:03:25 --> XSS Filtering completed
DEBUG - 2016-10-03 14:03:25 --> XSS Filtering completed
DEBUG - 2016-10-03 14:03:25 --> XSS Filtering completed
DEBUG - 2016-10-03 14:03:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 14:03:25 --> Language Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Loader Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 14:03:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 14:03:25 --> Helper loaded: url_helper
DEBUG - 2016-10-03 14:03:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 14:03:25 --> Helper loaded: file_helper
DEBUG - 2016-10-03 14:03:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 14:03:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 14:03:25 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 14:03:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 14:03:25 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 14:03:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 14:03:25 --> Helper loaded: common_helper
DEBUG - 2016-10-03 14:03:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 14:03:25 --> Helper loaded: common_helper
DEBUG - 2016-10-03 14:03:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 14:03:25 --> Helper loaded: form_helper
DEBUG - 2016-10-03 14:03:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 14:03:25 --> Helper loaded: security_helper
DEBUG - 2016-10-03 14:03:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 14:03:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 14:03:25 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 14:03:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 14:03:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 14:03:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 14:03:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 14:03:25 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 14:03:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 14:03:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 14:03:25 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 14:03:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 14:03:25 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 14:03:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 14:03:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 14:03:25 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 14:03:25 --> Database Driver Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Session Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 14:03:25 --> Helper loaded: string_helper
DEBUG - 2016-10-03 14:03:25 --> Session routines successfully run
DEBUG - 2016-10-03 14:03:25 --> Native_session Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 14:03:25 --> Form Validation Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Form Validation Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 14:03:25 --> Controller Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 14:03:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 14:03:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 14:03:25 --> Carabiner: library configured.
DEBUG - 2016-10-03 14:03:25 --> Carabiner: library configured.
DEBUG - 2016-10-03 14:03:25 --> User Agent Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Model Class Initialized
ERROR - 2016-10-03 14:03:25 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-10-03 14:03:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-10-03 14:03:25 --> Form Validation Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 14:03:25 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-10-03 14:03:25 --> Config Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Hooks Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Utf8 Class Initialized
DEBUG - 2016-10-03 14:03:25 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 14:03:25 --> URI Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Router Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Output Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Security Class Initialized
DEBUG - 2016-10-03 14:03:25 --> Input Class Initialized
DEBUG - 2016-10-03 14:03:25 --> XSS Filtering completed
DEBUG - 2016-10-03 14:03:25 --> XSS Filtering completed
DEBUG - 2016-10-03 14:03:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 14:03:25 --> Language Class Initialized
DEBUG - 2016-10-03 14:03:26 --> Loader Class Initialized
DEBUG - 2016-10-03 14:03:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 14:03:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 14:03:26 --> Helper loaded: url_helper
DEBUG - 2016-10-03 14:03:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 14:03:26 --> Helper loaded: file_helper
DEBUG - 2016-10-03 14:03:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 14:03:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 14:03:26 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 14:03:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 14:03:26 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 14:03:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 14:03:26 --> Helper loaded: common_helper
DEBUG - 2016-10-03 14:03:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 14:03:26 --> Helper loaded: common_helper
DEBUG - 2016-10-03 14:03:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 14:03:26 --> Helper loaded: form_helper
DEBUG - 2016-10-03 14:03:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 14:03:26 --> Helper loaded: security_helper
DEBUG - 2016-10-03 14:03:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 14:03:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 14:03:26 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 14:03:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 14:03:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 14:03:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 14:03:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 14:03:26 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 14:03:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 14:03:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 14:03:26 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 14:03:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 14:03:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 14:03:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 14:03:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 14:03:26 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 14:03:26 --> Database Driver Class Initialized
DEBUG - 2016-10-03 14:03:26 --> Session Class Initialized
DEBUG - 2016-10-03 14:03:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 14:03:26 --> Helper loaded: string_helper
DEBUG - 2016-10-03 14:03:26 --> Session routines successfully run
DEBUG - 2016-10-03 14:03:26 --> Native_session Class Initialized
DEBUG - 2016-10-03 14:03:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 14:03:26 --> Form Validation Class Initialized
DEBUG - 2016-10-03 14:03:26 --> Form Validation Class Initialized
DEBUG - 2016-10-03 14:03:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 14:03:26 --> Controller Class Initialized
DEBUG - 2016-10-03 14:03:26 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 14:03:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 14:03:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 14:03:26 --> Carabiner: library configured.
DEBUG - 2016-10-03 14:03:26 --> Carabiner: library configured.
DEBUG - 2016-10-03 14:03:26 --> User Agent Class Initialized
DEBUG - 2016-10-03 14:03:26 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:26 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:26 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:26 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:26 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:26 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:26 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:26 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:26 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:26 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-03 14:03:26 --> Pagination Class Initialized
DEBUG - 2016-10-03 14:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-10-03 14:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-10-03 14:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 14:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 14:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 14:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 14:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-10-03 14:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 14:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 14:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 14:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 14:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 14:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 14:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-10-03 14:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 14:03:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 14:03:26 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-10-03 14:03:26 --> Final output sent to browser
DEBUG - 2016-10-03 14:03:26 --> Total execution time: 0.3958
DEBUG - 2016-10-03 14:03:30 --> Config Class Initialized
DEBUG - 2016-10-03 14:03:30 --> Hooks Class Initialized
DEBUG - 2016-10-03 14:03:30 --> Utf8 Class Initialized
DEBUG - 2016-10-03 14:03:30 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 14:03:30 --> URI Class Initialized
DEBUG - 2016-10-03 14:03:30 --> Router Class Initialized
DEBUG - 2016-10-03 14:03:30 --> Output Class Initialized
DEBUG - 2016-10-03 14:03:30 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 14:03:30 --> Security Class Initialized
DEBUG - 2016-10-03 14:03:30 --> Input Class Initialized
DEBUG - 2016-10-03 14:03:30 --> XSS Filtering completed
DEBUG - 2016-10-03 14:03:30 --> XSS Filtering completed
DEBUG - 2016-10-03 14:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 14:03:30 --> Language Class Initialized
DEBUG - 2016-10-03 14:03:30 --> Loader Class Initialized
DEBUG - 2016-10-03 14:03:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 14:03:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 14:03:30 --> Helper loaded: url_helper
DEBUG - 2016-10-03 14:03:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 14:03:30 --> Helper loaded: file_helper
DEBUG - 2016-10-03 14:03:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 14:03:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 14:03:30 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 14:03:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 14:03:30 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 14:03:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 14:03:30 --> Helper loaded: common_helper
DEBUG - 2016-10-03 14:03:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 14:03:30 --> Helper loaded: common_helper
DEBUG - 2016-10-03 14:03:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 14:03:30 --> Helper loaded: form_helper
DEBUG - 2016-10-03 14:03:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 14:03:30 --> Helper loaded: security_helper
DEBUG - 2016-10-03 14:03:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 14:03:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 14:03:30 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 14:03:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 14:03:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 14:03:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 14:03:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 14:03:30 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 14:03:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 14:03:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 14:03:30 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 14:03:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 14:03:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 14:03:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 14:03:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 14:03:30 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 14:03:30 --> Database Driver Class Initialized
DEBUG - 2016-10-03 14:03:30 --> Session Class Initialized
DEBUG - 2016-10-03 14:03:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 14:03:30 --> Helper loaded: string_helper
DEBUG - 2016-10-03 14:03:30 --> Session routines successfully run
DEBUG - 2016-10-03 14:03:30 --> Native_session Class Initialized
DEBUG - 2016-10-03 14:03:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 14:03:30 --> Form Validation Class Initialized
DEBUG - 2016-10-03 14:03:30 --> Form Validation Class Initialized
DEBUG - 2016-10-03 14:03:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 14:03:30 --> Controller Class Initialized
DEBUG - 2016-10-03 14:03:30 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 14:03:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 14:03:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 14:03:30 --> Carabiner: library configured.
DEBUG - 2016-10-03 14:03:30 --> Carabiner: library configured.
DEBUG - 2016-10-03 14:03:30 --> User Agent Class Initialized
DEBUG - 2016-10-03 14:03:30 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:30 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:30 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:30 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:30 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:30 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:30 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:30 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-03 14:03:30 --> Pagination Class Initialized
DEBUG - 2016-10-03 14:03:30 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 14:03:30 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/index.php
DEBUG - 2016-10-03 14:03:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 14:03:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 14:03:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 14:03:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 14:03:30 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-03 14:03:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 14:03:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 14:03:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 14:03:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 14:03:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 14:03:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 14:03:30 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-03 14:03:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 14:03:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 14:03:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55961f1d1ca16fdfc4239ae1901a174e
DEBUG - 2016-10-03 14:03:30 --> Final output sent to browser
DEBUG - 2016-10-03 14:03:30 --> Total execution time: 0.4789
DEBUG - 2016-10-03 14:03:34 --> Config Class Initialized
DEBUG - 2016-10-03 14:03:34 --> Hooks Class Initialized
DEBUG - 2016-10-03 14:03:34 --> Utf8 Class Initialized
DEBUG - 2016-10-03 14:03:34 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 14:03:34 --> URI Class Initialized
DEBUG - 2016-10-03 14:03:34 --> Router Class Initialized
DEBUG - 2016-10-03 14:03:34 --> Output Class Initialized
DEBUG - 2016-10-03 14:03:34 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 14:03:34 --> Security Class Initialized
DEBUG - 2016-10-03 14:03:34 --> Input Class Initialized
DEBUG - 2016-10-03 14:03:34 --> XSS Filtering completed
DEBUG - 2016-10-03 14:03:34 --> XSS Filtering completed
DEBUG - 2016-10-03 14:03:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 14:03:34 --> Language Class Initialized
DEBUG - 2016-10-03 14:03:34 --> Loader Class Initialized
DEBUG - 2016-10-03 14:03:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 14:03:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 14:03:34 --> Helper loaded: url_helper
DEBUG - 2016-10-03 14:03:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 14:03:34 --> Helper loaded: file_helper
DEBUG - 2016-10-03 14:03:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 14:03:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 14:03:34 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 14:03:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 14:03:34 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 14:03:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 14:03:34 --> Helper loaded: common_helper
DEBUG - 2016-10-03 14:03:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 14:03:34 --> Helper loaded: common_helper
DEBUG - 2016-10-03 14:03:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 14:03:34 --> Helper loaded: form_helper
DEBUG - 2016-10-03 14:03:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 14:03:34 --> Helper loaded: security_helper
DEBUG - 2016-10-03 14:03:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 14:03:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 14:03:34 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 14:03:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 14:03:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 14:03:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 14:03:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 14:03:35 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 14:03:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 14:03:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 14:03:35 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 14:03:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 14:03:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 14:03:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 14:03:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 14:03:35 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 14:03:35 --> Database Driver Class Initialized
DEBUG - 2016-10-03 14:03:35 --> Session Class Initialized
DEBUG - 2016-10-03 14:03:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 14:03:35 --> Helper loaded: string_helper
DEBUG - 2016-10-03 14:03:35 --> Session routines successfully run
DEBUG - 2016-10-03 14:03:35 --> Native_session Class Initialized
DEBUG - 2016-10-03 14:03:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 14:03:35 --> Form Validation Class Initialized
DEBUG - 2016-10-03 14:03:35 --> Form Validation Class Initialized
DEBUG - 2016-10-03 14:03:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 14:03:35 --> Controller Class Initialized
DEBUG - 2016-10-03 14:03:35 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 14:03:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 14:03:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 14:03:35 --> Carabiner: library configured.
DEBUG - 2016-10-03 14:03:35 --> Carabiner: library configured.
DEBUG - 2016-10-03 14:03:35 --> User Agent Class Initialized
DEBUG - 2016-10-03 14:03:35 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:35 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:35 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:35 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:35 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-03 14:03:35 --> Pagination Class Initialized
DEBUG - 2016-10-03 14:03:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-10-03 14:03:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/index.php
DEBUG - 2016-10-03 14:03:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 14:03:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 14:03:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 14:03:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 14:03:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-10-03 14:03:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 14:03:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 14:03:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 14:03:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 14:03:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 14:03:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 14:03:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-10-03 14:03:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 14:03:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 14:03:35 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c2a3e0401bd35d4fcac4bae5f9412231
DEBUG - 2016-10-03 14:03:35 --> Final output sent to browser
DEBUG - 2016-10-03 14:03:35 --> Total execution time: 0.4376
DEBUG - 2016-10-03 14:03:41 --> Config Class Initialized
DEBUG - 2016-10-03 14:03:41 --> Hooks Class Initialized
DEBUG - 2016-10-03 14:03:41 --> Utf8 Class Initialized
DEBUG - 2016-10-03 14:03:41 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 14:03:41 --> URI Class Initialized
DEBUG - 2016-10-03 14:03:41 --> Router Class Initialized
DEBUG - 2016-10-03 14:03:41 --> Output Class Initialized
DEBUG - 2016-10-03 14:03:41 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 14:03:41 --> Security Class Initialized
DEBUG - 2016-10-03 14:03:41 --> Input Class Initialized
DEBUG - 2016-10-03 14:03:41 --> XSS Filtering completed
DEBUG - 2016-10-03 14:03:41 --> XSS Filtering completed
DEBUG - 2016-10-03 14:03:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 14:03:41 --> Language Class Initialized
DEBUG - 2016-10-03 14:03:41 --> Loader Class Initialized
DEBUG - 2016-10-03 14:03:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 14:03:41 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 14:03:41 --> Helper loaded: url_helper
DEBUG - 2016-10-03 14:03:41 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 14:03:41 --> Helper loaded: file_helper
DEBUG - 2016-10-03 14:03:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 14:03:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 14:03:41 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 14:03:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 14:03:41 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 14:03:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 14:03:41 --> Helper loaded: common_helper
DEBUG - 2016-10-03 14:03:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 14:03:41 --> Helper loaded: common_helper
DEBUG - 2016-10-03 14:03:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 14:03:41 --> Helper loaded: form_helper
DEBUG - 2016-10-03 14:03:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 14:03:41 --> Helper loaded: security_helper
DEBUG - 2016-10-03 14:03:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 14:03:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 14:03:41 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 14:03:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 14:03:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 14:03:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 14:03:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 14:03:41 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 14:03:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 14:03:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 14:03:41 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 14:03:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 14:03:41 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 14:03:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 14:03:41 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 14:03:41 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 14:03:41 --> Database Driver Class Initialized
DEBUG - 2016-10-03 14:03:41 --> Session Class Initialized
DEBUG - 2016-10-03 14:03:41 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 14:03:41 --> Helper loaded: string_helper
DEBUG - 2016-10-03 14:03:41 --> Session routines successfully run
DEBUG - 2016-10-03 14:03:41 --> Native_session Class Initialized
DEBUG - 2016-10-03 14:03:41 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 14:03:41 --> Form Validation Class Initialized
DEBUG - 2016-10-03 14:03:41 --> Form Validation Class Initialized
DEBUG - 2016-10-03 14:03:41 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 14:03:41 --> Controller Class Initialized
DEBUG - 2016-10-03 14:03:41 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 14:03:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 14:03:41 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 14:03:41 --> Carabiner: library configured.
DEBUG - 2016-10-03 14:03:41 --> Carabiner: library configured.
DEBUG - 2016-10-03 14:03:41 --> User Agent Class Initialized
DEBUG - 2016-10-03 14:03:41 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:41 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:41 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:41 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:41 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:41 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:41 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:41 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-03 14:03:41 --> Pagination Class Initialized
DEBUG - 2016-10-03 14:03:41 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 14:03:41 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/index.php
DEBUG - 2016-10-03 14:03:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 14:03:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 14:03:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 14:03:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 14:03:41 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-03 14:03:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 14:03:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 14:03:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 14:03:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 14:03:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 14:03:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 14:03:41 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-03 14:03:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 14:03:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 14:03:41 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55961f1d1ca16fdfc4239ae1901a174e
DEBUG - 2016-10-03 14:03:41 --> Final output sent to browser
DEBUG - 2016-10-03 14:03:41 --> Total execution time: 0.3949
DEBUG - 2016-10-03 14:03:45 --> Config Class Initialized
DEBUG - 2016-10-03 14:03:45 --> Hooks Class Initialized
DEBUG - 2016-10-03 14:03:45 --> Utf8 Class Initialized
DEBUG - 2016-10-03 14:03:45 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 14:03:45 --> URI Class Initialized
DEBUG - 2016-10-03 14:03:45 --> Router Class Initialized
DEBUG - 2016-10-03 14:03:45 --> Output Class Initialized
DEBUG - 2016-10-03 14:03:45 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 14:03:45 --> Security Class Initialized
DEBUG - 2016-10-03 14:03:45 --> Input Class Initialized
DEBUG - 2016-10-03 14:03:45 --> XSS Filtering completed
DEBUG - 2016-10-03 14:03:45 --> XSS Filtering completed
DEBUG - 2016-10-03 14:03:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 14:03:45 --> Language Class Initialized
DEBUG - 2016-10-03 14:03:45 --> Loader Class Initialized
DEBUG - 2016-10-03 14:03:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 14:03:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 14:03:45 --> Helper loaded: url_helper
DEBUG - 2016-10-03 14:03:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 14:03:45 --> Helper loaded: file_helper
DEBUG - 2016-10-03 14:03:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 14:03:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 14:03:45 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 14:03:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 14:03:45 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 14:03:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 14:03:45 --> Helper loaded: common_helper
DEBUG - 2016-10-03 14:03:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 14:03:45 --> Helper loaded: common_helper
DEBUG - 2016-10-03 14:03:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 14:03:45 --> Helper loaded: form_helper
DEBUG - 2016-10-03 14:03:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 14:03:45 --> Helper loaded: security_helper
DEBUG - 2016-10-03 14:03:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 14:03:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 14:03:45 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 14:03:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 14:03:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 14:03:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 14:03:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 14:03:45 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 14:03:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 14:03:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 14:03:45 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 14:03:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 14:03:45 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 14:03:45 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 14:03:45 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 14:03:45 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 14:03:45 --> Database Driver Class Initialized
DEBUG - 2016-10-03 14:03:45 --> Session Class Initialized
DEBUG - 2016-10-03 14:03:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 14:03:45 --> Helper loaded: string_helper
DEBUG - 2016-10-03 14:03:45 --> Session routines successfully run
DEBUG - 2016-10-03 14:03:45 --> Native_session Class Initialized
DEBUG - 2016-10-03 14:03:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 14:03:45 --> Form Validation Class Initialized
DEBUG - 2016-10-03 14:03:45 --> Form Validation Class Initialized
DEBUG - 2016-10-03 14:03:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 14:03:45 --> Controller Class Initialized
DEBUG - 2016-10-03 14:03:45 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 14:03:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 14:03:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 14:03:45 --> Carabiner: library configured.
DEBUG - 2016-10-03 14:03:45 --> Carabiner: library configured.
DEBUG - 2016-10-03 14:03:45 --> User Agent Class Initialized
DEBUG - 2016-10-03 14:03:45 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:45 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:45 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:45 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:45 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:45 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:45 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:45 --> Model Class Initialized
DEBUG - 2016-10-03 14:03:45 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 14:03:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/tr_pegawai_profil.php
DEBUG - 2016-10-03 14:03:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/detail.php
DEBUG - 2016-10-03 14:03:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 14:03:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 14:03:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 14:03:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
ERROR - 2016-10-03 14:03:45 --> Severity: Notice  --> Undefined variable: detail E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 38
DEBUG - 2016-10-03 14:03:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 14:03:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 14:03:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 14:03:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 14:03:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 14:03:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 14:03:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
ERROR - 2016-10-03 14:03:45 --> Severity: Notice  --> Undefined variable: detail E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 38
DEBUG - 2016-10-03 14:03:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 14:03:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 14:03:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 14:03:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-10-03 14:03:45 --> Final output sent to browser
DEBUG - 2016-10-03 14:03:45 --> Total execution time: 0.3953
DEBUG - 2016-10-03 15:03:28 --> Config Class Initialized
DEBUG - 2016-10-03 15:03:29 --> Hooks Class Initialized
DEBUG - 2016-10-03 15:03:29 --> Utf8 Class Initialized
DEBUG - 2016-10-03 15:03:29 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 15:03:29 --> URI Class Initialized
DEBUG - 2016-10-03 15:03:29 --> Router Class Initialized
DEBUG - 2016-10-03 15:03:29 --> Output Class Initialized
DEBUG - 2016-10-03 15:03:29 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 15:03:29 --> Security Class Initialized
DEBUG - 2016-10-03 15:03:29 --> Input Class Initialized
DEBUG - 2016-10-03 15:03:29 --> XSS Filtering completed
DEBUG - 2016-10-03 15:03:29 --> XSS Filtering completed
DEBUG - 2016-10-03 15:03:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 15:03:29 --> Language Class Initialized
DEBUG - 2016-10-03 15:03:29 --> Loader Class Initialized
DEBUG - 2016-10-03 15:03:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 15:03:29 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 15:03:29 --> Helper loaded: url_helper
DEBUG - 2016-10-03 15:03:29 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 15:03:29 --> Helper loaded: file_helper
DEBUG - 2016-10-03 15:03:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 15:03:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 15:03:29 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 15:03:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 15:03:29 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 15:03:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 15:03:29 --> Helper loaded: common_helper
DEBUG - 2016-10-03 15:03:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 15:03:29 --> Helper loaded: common_helper
DEBUG - 2016-10-03 15:03:29 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 15:03:29 --> Helper loaded: form_helper
DEBUG - 2016-10-03 15:03:29 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 15:03:29 --> Helper loaded: security_helper
DEBUG - 2016-10-03 15:03:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 15:03:29 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 15:03:29 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 15:03:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 15:03:29 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 15:03:29 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 15:03:29 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 15:03:29 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 15:03:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 15:03:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 15:03:29 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 15:03:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 15:03:29 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 15:03:29 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 15:03:29 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 15:03:29 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 15:03:29 --> Database Driver Class Initialized
DEBUG - 2016-10-03 15:03:29 --> Session Class Initialized
DEBUG - 2016-10-03 15:03:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 15:03:29 --> Helper loaded: string_helper
DEBUG - 2016-10-03 15:03:29 --> Session routines successfully run
DEBUG - 2016-10-03 15:03:29 --> Native_session Class Initialized
DEBUG - 2016-10-03 15:03:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 15:03:29 --> Form Validation Class Initialized
DEBUG - 2016-10-03 15:03:29 --> Form Validation Class Initialized
DEBUG - 2016-10-03 15:03:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 15:03:29 --> Controller Class Initialized
DEBUG - 2016-10-03 15:03:29 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 15:03:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 15:03:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 15:03:29 --> Carabiner: library configured.
DEBUG - 2016-10-03 15:03:29 --> Carabiner: library configured.
DEBUG - 2016-10-03 15:03:29 --> User Agent Class Initialized
DEBUG - 2016-10-03 15:03:29 --> Model Class Initialized
DEBUG - 2016-10-03 15:03:29 --> Model Class Initialized
DEBUG - 2016-10-03 15:03:29 --> Model Class Initialized
DEBUG - 2016-10-03 15:03:29 --> Model Class Initialized
DEBUG - 2016-10-03 15:03:29 --> Model Class Initialized
DEBUG - 2016-10-03 15:03:29 --> Model Class Initialized
DEBUG - 2016-10-03 15:03:29 --> Model Class Initialized
DEBUG - 2016-10-03 15:03:29 --> Model Class Initialized
DEBUG - 2016-10-03 15:03:29 --> Model Class Initialized
DEBUG - 2016-10-03 15:03:29 --> Model Class Initialized
DEBUG - 2016-10-03 15:03:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-03 15:03:29 --> Pagination Class Initialized
DEBUG - 2016-10-03 15:03:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-10-03 15:03:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-10-03 15:03:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 15:03:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 15:03:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 15:03:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 15:03:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-10-03 15:03:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 15:03:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 15:03:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 15:03:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 15:03:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 15:03:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 15:03:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-10-03 15:03:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 15:03:29 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 15:03:29 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-10-03 15:03:29 --> Final output sent to browser
DEBUG - 2016-10-03 15:03:29 --> Total execution time: 0.4654
DEBUG - 2016-10-03 15:40:38 --> Config Class Initialized
DEBUG - 2016-10-03 15:40:38 --> Hooks Class Initialized
DEBUG - 2016-10-03 15:40:38 --> Utf8 Class Initialized
DEBUG - 2016-10-03 15:40:38 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 15:40:38 --> URI Class Initialized
DEBUG - 2016-10-03 15:40:38 --> Router Class Initialized
DEBUG - 2016-10-03 15:40:38 --> No URI present. Default controller set.
DEBUG - 2016-10-03 15:40:38 --> Output Class Initialized
DEBUG - 2016-10-03 15:40:38 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 15:40:38 --> Security Class Initialized
DEBUG - 2016-10-03 15:40:38 --> Input Class Initialized
DEBUG - 2016-10-03 15:40:38 --> XSS Filtering completed
DEBUG - 2016-10-03 15:40:38 --> XSS Filtering completed
DEBUG - 2016-10-03 15:40:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 15:40:38 --> Language Class Initialized
DEBUG - 2016-10-03 15:40:38 --> Loader Class Initialized
DEBUG - 2016-10-03 15:40:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 15:40:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 15:40:38 --> Helper loaded: url_helper
DEBUG - 2016-10-03 15:40:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 15:40:38 --> Helper loaded: file_helper
DEBUG - 2016-10-03 15:40:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 15:40:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 15:40:38 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 15:40:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 15:40:38 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 15:40:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 15:40:38 --> Helper loaded: common_helper
DEBUG - 2016-10-03 15:40:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 15:40:38 --> Helper loaded: common_helper
DEBUG - 2016-10-03 15:40:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 15:40:38 --> Helper loaded: form_helper
DEBUG - 2016-10-03 15:40:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 15:40:38 --> Helper loaded: security_helper
DEBUG - 2016-10-03 15:40:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 15:40:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 15:40:38 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 15:40:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 15:40:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 15:40:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 15:40:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 15:40:38 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 15:40:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 15:40:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 15:40:38 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 15:40:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 15:40:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 15:40:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 15:40:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 15:40:38 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 15:40:38 --> Database Driver Class Initialized
DEBUG - 2016-10-03 15:40:38 --> Session Class Initialized
DEBUG - 2016-10-03 15:40:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 15:40:38 --> Helper loaded: string_helper
DEBUG - 2016-10-03 15:40:38 --> Session routines successfully run
DEBUG - 2016-10-03 15:40:38 --> Native_session Class Initialized
DEBUG - 2016-10-03 15:40:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 15:40:38 --> Form Validation Class Initialized
DEBUG - 2016-10-03 15:40:38 --> Form Validation Class Initialized
DEBUG - 2016-10-03 15:40:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 15:40:38 --> Controller Class Initialized
DEBUG - 2016-10-03 15:40:38 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 15:40:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 15:40:38 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 15:40:38 --> Carabiner: library configured.
DEBUG - 2016-10-03 15:40:38 --> Carabiner: library configured.
DEBUG - 2016-10-03 15:40:38 --> User Agent Class Initialized
DEBUG - 2016-10-03 15:40:38 --> Model Class Initialized
DEBUG - 2016-10-03 15:40:38 --> Model Class Initialized
DEBUG - 2016-10-03 15:40:38 --> Model Class Initialized
ERROR - 2016-10-03 15:40:38 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-10-03 15:40:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-10-03 15:40:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-10-03 15:40:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-03 15:40:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 15:40:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-03 15:40:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-03 15:40:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-03 15:40:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-03 15:40:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-03 15:40:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 15:40:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-03 15:40:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-03 15:40:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 15:40:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-03 15:40:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-03 15:40:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-03 15:40:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-03 15:40:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-03 15:40:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 15:40:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-03 15:40:38 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-10-03 15:40:38 --> Final output sent to browser
DEBUG - 2016-10-03 15:40:38 --> Total execution time: 0.4092
DEBUG - 2016-10-03 15:40:39 --> Config Class Initialized
DEBUG - 2016-10-03 15:40:39 --> Hooks Class Initialized
DEBUG - 2016-10-03 15:40:39 --> Utf8 Class Initialized
DEBUG - 2016-10-03 15:40:39 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 15:40:39 --> URI Class Initialized
DEBUG - 2016-10-03 15:40:39 --> Router Class Initialized
DEBUG - 2016-10-03 15:40:39 --> Output Class Initialized
DEBUG - 2016-10-03 15:40:39 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 15:40:39 --> Security Class Initialized
DEBUG - 2016-10-03 15:40:39 --> Input Class Initialized
DEBUG - 2016-10-03 15:40:39 --> XSS Filtering completed
DEBUG - 2016-10-03 15:40:39 --> XSS Filtering completed
DEBUG - 2016-10-03 15:40:39 --> XSS Filtering completed
DEBUG - 2016-10-03 15:40:39 --> XSS Filtering completed
DEBUG - 2016-10-03 15:40:39 --> XSS Filtering completed
DEBUG - 2016-10-03 15:40:39 --> XSS Filtering completed
DEBUG - 2016-10-03 15:40:39 --> XSS Filtering completed
DEBUG - 2016-10-03 15:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 15:40:39 --> Language Class Initialized
DEBUG - 2016-10-03 15:40:39 --> Loader Class Initialized
DEBUG - 2016-10-03 15:40:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 15:40:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 15:40:39 --> Helper loaded: url_helper
DEBUG - 2016-10-03 15:40:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 15:40:39 --> Helper loaded: file_helper
DEBUG - 2016-10-03 15:40:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 15:40:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 15:40:39 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 15:40:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 15:40:39 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 15:40:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 15:40:39 --> Helper loaded: common_helper
DEBUG - 2016-10-03 15:40:39 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 15:40:39 --> Helper loaded: common_helper
DEBUG - 2016-10-03 15:40:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 15:40:39 --> Helper loaded: form_helper
DEBUG - 2016-10-03 15:40:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 15:40:39 --> Helper loaded: security_helper
DEBUG - 2016-10-03 15:40:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 15:40:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 15:40:39 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 15:40:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 15:40:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 15:40:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 15:40:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 15:40:39 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 15:40:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 15:40:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 15:40:39 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 15:40:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 15:40:39 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 15:40:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 15:40:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 15:40:39 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 15:40:39 --> Database Driver Class Initialized
DEBUG - 2016-10-03 15:40:39 --> Session Class Initialized
DEBUG - 2016-10-03 15:40:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 15:40:39 --> Helper loaded: string_helper
DEBUG - 2016-10-03 15:40:39 --> Session routines successfully run
DEBUG - 2016-10-03 15:40:39 --> Native_session Class Initialized
DEBUG - 2016-10-03 15:40:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 15:40:39 --> Form Validation Class Initialized
DEBUG - 2016-10-03 15:40:39 --> Form Validation Class Initialized
DEBUG - 2016-10-03 15:40:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 15:40:39 --> Controller Class Initialized
DEBUG - 2016-10-03 15:40:39 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 15:40:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 15:40:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 15:40:39 --> Carabiner: library configured.
DEBUG - 2016-10-03 15:40:39 --> Carabiner: library configured.
DEBUG - 2016-10-03 15:40:39 --> User Agent Class Initialized
DEBUG - 2016-10-03 15:40:39 --> Model Class Initialized
DEBUG - 2016-10-03 15:40:39 --> Model Class Initialized
DEBUG - 2016-10-03 15:40:39 --> Model Class Initialized
DEBUG - 2016-10-03 15:40:39 --> Model Class Initialized
DEBUG - 2016-10-03 15:40:39 --> Model Class Initialized
DEBUG - 2016-10-03 15:40:39 --> Model Class Initialized
DEBUG - 2016-10-03 15:40:39 --> Model Class Initialized
DEBUG - 2016-10-03 15:40:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-10-03 15:40:40 --> Final output sent to browser
DEBUG - 2016-10-03 15:40:40 --> Total execution time: 0.5528
DEBUG - 2016-10-03 17:02:18 --> Config Class Initialized
DEBUG - 2016-10-03 17:02:18 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:02:18 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:02:18 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:02:18 --> URI Class Initialized
DEBUG - 2016-10-03 17:02:18 --> Router Class Initialized
DEBUG - 2016-10-03 17:02:18 --> Output Class Initialized
DEBUG - 2016-10-03 17:02:18 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:02:18 --> Security Class Initialized
DEBUG - 2016-10-03 17:02:18 --> Input Class Initialized
DEBUG - 2016-10-03 17:02:18 --> XSS Filtering completed
DEBUG - 2016-10-03 17:02:18 --> XSS Filtering completed
DEBUG - 2016-10-03 17:02:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:02:18 --> Language Class Initialized
DEBUG - 2016-10-03 17:02:18 --> Loader Class Initialized
DEBUG - 2016-10-03 17:02:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:02:18 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:02:18 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:02:18 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:02:18 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:02:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:02:18 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:02:18 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:02:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:02:18 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:02:18 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:02:18 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:02:18 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:02:18 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:02:18 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:02:18 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:02:18 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:02:18 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:02:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:02:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:02:18 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:02:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:02:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:02:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:02:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:02:18 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:02:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:02:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:02:18 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:02:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:02:18 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:02:18 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:02:18 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:02:18 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:02:18 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:02:18 --> Session Class Initialized
DEBUG - 2016-10-03 17:02:18 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:02:18 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:02:18 --> Session routines successfully run
DEBUG - 2016-10-03 17:02:18 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:02:18 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:02:18 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:02:18 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:02:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:02:18 --> Controller Class Initialized
DEBUG - 2016-10-03 17:02:18 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:02:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:02:18 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:02:18 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:02:18 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:02:19 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:02:19 --> Model Class Initialized
DEBUG - 2016-10-03 17:02:19 --> Model Class Initialized
DEBUG - 2016-10-03 17:02:19 --> Model Class Initialized
DEBUG - 2016-10-03 17:02:19 --> Model Class Initialized
DEBUG - 2016-10-03 17:02:19 --> Model Class Initialized
DEBUG - 2016-10-03 17:02:19 --> Model Class Initialized
DEBUG - 2016-10-03 17:02:19 --> Model Class Initialized
DEBUG - 2016-10-03 17:02:19 --> Model Class Initialized
DEBUG - 2016-10-03 17:02:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-03 17:02:19 --> Pagination Class Initialized
DEBUG - 2016-10-03 17:02:19 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:02:19 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/index.php
DEBUG - 2016-10-03 17:02:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:02:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:02:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:02:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:02:19 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-03 17:02:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:02:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:02:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:02:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:02:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:02:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:02:19 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-03 17:02:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:02:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:02:19 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55961f1d1ca16fdfc4239ae1901a174e
DEBUG - 2016-10-03 17:02:19 --> Final output sent to browser
DEBUG - 2016-10-03 17:02:19 --> Total execution time: 0.5066
DEBUG - 2016-10-03 17:02:21 --> Config Class Initialized
DEBUG - 2016-10-03 17:02:21 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:02:21 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:02:21 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:02:21 --> URI Class Initialized
DEBUG - 2016-10-03 17:02:21 --> Router Class Initialized
DEBUG - 2016-10-03 17:02:21 --> Output Class Initialized
DEBUG - 2016-10-03 17:02:21 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:02:21 --> Security Class Initialized
DEBUG - 2016-10-03 17:02:21 --> Input Class Initialized
DEBUG - 2016-10-03 17:02:21 --> XSS Filtering completed
DEBUG - 2016-10-03 17:02:21 --> XSS Filtering completed
DEBUG - 2016-10-03 17:02:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:02:21 --> Language Class Initialized
DEBUG - 2016-10-03 17:02:21 --> Loader Class Initialized
DEBUG - 2016-10-03 17:02:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:02:21 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:02:21 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:02:21 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:02:21 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:02:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:02:21 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:02:21 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:02:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:02:21 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:02:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:02:21 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:02:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:02:21 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:02:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:02:21 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:02:21 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:02:21 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:02:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:02:21 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:02:21 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:02:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:02:21 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:02:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:02:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:02:21 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:02:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:02:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:02:21 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:02:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:02:21 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:02:21 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:02:21 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:02:21 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:02:21 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:02:21 --> Session Class Initialized
DEBUG - 2016-10-03 17:02:21 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:02:21 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:02:21 --> Session routines successfully run
DEBUG - 2016-10-03 17:02:21 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:02:21 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:02:21 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:02:21 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:02:21 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:02:21 --> Controller Class Initialized
DEBUG - 2016-10-03 17:02:21 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:02:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:02:21 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:02:21 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:02:21 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:02:21 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:02:21 --> Model Class Initialized
DEBUG - 2016-10-03 17:02:21 --> Model Class Initialized
DEBUG - 2016-10-03 17:02:21 --> Model Class Initialized
DEBUG - 2016-10-03 17:02:21 --> Model Class Initialized
DEBUG - 2016-10-03 17:02:21 --> Model Class Initialized
DEBUG - 2016-10-03 17:02:21 --> Model Class Initialized
DEBUG - 2016-10-03 17:02:21 --> Model Class Initialized
DEBUG - 2016-10-03 17:02:21 --> Model Class Initialized
DEBUG - 2016-10-03 17:02:21 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:02:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/tr_pegawai_profil.php
DEBUG - 2016-10-03 17:02:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/detail.php
DEBUG - 2016-10-03 17:02:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:02:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:02:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:02:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
ERROR - 2016-10-03 17:02:21 --> Severity: Notice  --> Undefined variable: detail E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 38
DEBUG - 2016-10-03 17:02:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:02:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:02:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:02:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:02:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:02:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:02:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
ERROR - 2016-10-03 17:02:21 --> Severity: Notice  --> Undefined variable: detail E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 38
DEBUG - 2016-10-03 17:02:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:02:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:02:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:02:21 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-10-03 17:02:21 --> Final output sent to browser
DEBUG - 2016-10-03 17:02:21 --> Total execution time: 0.4713
DEBUG - 2016-10-03 17:05:23 --> Config Class Initialized
DEBUG - 2016-10-03 17:05:23 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:05:23 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:05:23 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:05:23 --> URI Class Initialized
DEBUG - 2016-10-03 17:05:23 --> Router Class Initialized
DEBUG - 2016-10-03 17:05:23 --> Output Class Initialized
DEBUG - 2016-10-03 17:05:23 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:05:23 --> Security Class Initialized
DEBUG - 2016-10-03 17:05:23 --> Input Class Initialized
DEBUG - 2016-10-03 17:05:23 --> XSS Filtering completed
DEBUG - 2016-10-03 17:05:23 --> XSS Filtering completed
DEBUG - 2016-10-03 17:05:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:05:23 --> Language Class Initialized
DEBUG - 2016-10-03 17:05:23 --> Loader Class Initialized
DEBUG - 2016-10-03 17:05:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:05:23 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:05:23 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:05:23 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:05:23 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:05:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:05:23 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:05:23 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:05:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:05:23 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:05:23 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:05:23 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:05:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:05:23 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:05:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:05:23 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:05:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:05:23 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:05:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:05:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:05:23 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:05:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:05:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:05:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:05:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:05:23 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:05:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:05:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:05:23 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:05:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:05:23 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:05:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:05:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:05:23 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:05:23 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:05:23 --> Session Class Initialized
DEBUG - 2016-10-03 17:05:23 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:05:23 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:05:23 --> Session routines successfully run
DEBUG - 2016-10-03 17:05:23 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:05:23 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:05:23 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:05:23 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:05:23 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:05:23 --> Controller Class Initialized
DEBUG - 2016-10-03 17:05:23 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:05:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:05:23 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:05:23 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:05:23 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:05:23 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:05:23 --> Model Class Initialized
DEBUG - 2016-10-03 17:05:23 --> Model Class Initialized
DEBUG - 2016-10-03 17:05:23 --> Model Class Initialized
DEBUG - 2016-10-03 17:05:23 --> Model Class Initialized
DEBUG - 2016-10-03 17:05:23 --> Model Class Initialized
DEBUG - 2016-10-03 17:05:23 --> Model Class Initialized
DEBUG - 2016-10-03 17:05:23 --> Model Class Initialized
DEBUG - 2016-10-03 17:05:23 --> Model Class Initialized
DEBUG - 2016-10-03 17:05:23 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:05:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/tr_pegawai_profil.php
DEBUG - 2016-10-03 17:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/detail.php
DEBUG - 2016-10-03 17:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
ERROR - 2016-10-03 17:05:24 --> Severity: Notice  --> Undefined variable: detail E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 38
DEBUG - 2016-10-03 17:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
ERROR - 2016-10-03 17:05:24 --> Severity: Notice  --> Undefined variable: detail E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 38
DEBUG - 2016-10-03 17:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:05:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:05:24 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-10-03 17:05:24 --> Final output sent to browser
DEBUG - 2016-10-03 17:05:24 --> Total execution time: 0.5002
DEBUG - 2016-10-03 17:06:10 --> Config Class Initialized
DEBUG - 2016-10-03 17:06:10 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:06:10 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:06:10 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:06:10 --> URI Class Initialized
DEBUG - 2016-10-03 17:06:10 --> Router Class Initialized
DEBUG - 2016-10-03 17:06:10 --> Output Class Initialized
DEBUG - 2016-10-03 17:06:10 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:06:10 --> Security Class Initialized
DEBUG - 2016-10-03 17:06:10 --> Input Class Initialized
DEBUG - 2016-10-03 17:06:10 --> XSS Filtering completed
DEBUG - 2016-10-03 17:06:10 --> XSS Filtering completed
DEBUG - 2016-10-03 17:06:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:06:10 --> Language Class Initialized
DEBUG - 2016-10-03 17:06:10 --> Loader Class Initialized
DEBUG - 2016-10-03 17:06:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:06:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:06:10 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:06:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:06:10 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:06:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:06:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:06:10 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:06:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:06:10 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:06:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:06:10 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:06:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:06:10 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:06:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:06:10 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:06:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:06:10 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:06:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:06:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:06:10 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:06:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:06:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:06:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:06:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:06:10 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:06:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:06:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:06:10 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:06:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:06:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:06:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:06:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:06:10 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:06:10 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:06:10 --> Session Class Initialized
DEBUG - 2016-10-03 17:06:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:06:10 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:06:10 --> Session routines successfully run
DEBUG - 2016-10-03 17:06:10 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:06:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:06:10 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:06:10 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:06:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:06:10 --> Controller Class Initialized
DEBUG - 2016-10-03 17:06:10 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:06:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:06:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:06:10 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:06:10 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:06:10 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:06:10 --> Model Class Initialized
DEBUG - 2016-10-03 17:06:10 --> Model Class Initialized
DEBUG - 2016-10-03 17:06:10 --> Model Class Initialized
DEBUG - 2016-10-03 17:06:10 --> Model Class Initialized
DEBUG - 2016-10-03 17:06:10 --> Model Class Initialized
DEBUG - 2016-10-03 17:06:10 --> Model Class Initialized
DEBUG - 2016-10-03 17:06:10 --> Model Class Initialized
DEBUG - 2016-10-03 17:06:10 --> Model Class Initialized
DEBUG - 2016-10-03 17:06:10 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:06:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/tr_pegawai_profil.php
DEBUG - 2016-10-03 17:06:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/detail.php
DEBUG - 2016-10-03 17:06:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:06:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:06:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:06:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:06:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:06:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:06:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:06:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:06:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:06:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:06:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:06:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:06:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:06:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:06:10 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-10-03 17:06:10 --> Final output sent to browser
DEBUG - 2016-10-03 17:06:10 --> Total execution time: 0.5250
DEBUG - 2016-10-03 17:07:00 --> Config Class Initialized
DEBUG - 2016-10-03 17:07:00 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:07:00 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:07:00 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:07:00 --> URI Class Initialized
DEBUG - 2016-10-03 17:07:00 --> Router Class Initialized
DEBUG - 2016-10-03 17:07:00 --> Output Class Initialized
DEBUG - 2016-10-03 17:07:00 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:07:00 --> Security Class Initialized
DEBUG - 2016-10-03 17:07:00 --> Input Class Initialized
DEBUG - 2016-10-03 17:07:00 --> XSS Filtering completed
DEBUG - 2016-10-03 17:07:00 --> XSS Filtering completed
DEBUG - 2016-10-03 17:07:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:07:00 --> Language Class Initialized
DEBUG - 2016-10-03 17:07:00 --> Loader Class Initialized
DEBUG - 2016-10-03 17:07:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:07:00 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:07:00 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:07:00 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:07:00 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:07:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:07:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:07:00 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:07:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:07:00 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:07:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:07:00 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:07:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:07:00 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:07:00 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:07:00 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:07:00 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:07:00 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:07:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:07:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:07:00 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:07:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:07:00 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:07:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:07:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:07:00 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:07:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:07:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:07:00 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:07:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:07:00 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:07:00 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:07:00 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:07:00 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:07:00 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:07:00 --> Session Class Initialized
DEBUG - 2016-10-03 17:07:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:07:00 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:07:00 --> Session routines successfully run
DEBUG - 2016-10-03 17:07:00 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:07:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:07:00 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:07:00 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:07:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:07:00 --> Controller Class Initialized
DEBUG - 2016-10-03 17:07:00 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:07:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:07:00 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:07:00 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:07:00 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:07:00 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:07:00 --> Model Class Initialized
DEBUG - 2016-10-03 17:07:00 --> Model Class Initialized
DEBUG - 2016-10-03 17:07:00 --> Model Class Initialized
DEBUG - 2016-10-03 17:07:00 --> Model Class Initialized
DEBUG - 2016-10-03 17:07:00 --> Model Class Initialized
DEBUG - 2016-10-03 17:07:00 --> Model Class Initialized
DEBUG - 2016-10-03 17:07:00 --> Model Class Initialized
DEBUG - 2016-10-03 17:07:00 --> Model Class Initialized
DEBUG - 2016-10-03 17:07:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-03 17:07:00 --> Pagination Class Initialized
DEBUG - 2016-10-03 17:07:00 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:07:00 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/index.php
DEBUG - 2016-10-03 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:07:00 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-03 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:07:00 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-03 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:07:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:07:00 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55961f1d1ca16fdfc4239ae1901a174e
DEBUG - 2016-10-03 17:07:00 --> Final output sent to browser
DEBUG - 2016-10-03 17:07:00 --> Total execution time: 0.5906
DEBUG - 2016-10-03 17:07:04 --> Config Class Initialized
DEBUG - 2016-10-03 17:07:04 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:07:04 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:07:04 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:07:04 --> URI Class Initialized
DEBUG - 2016-10-03 17:07:04 --> Router Class Initialized
DEBUG - 2016-10-03 17:07:04 --> Output Class Initialized
DEBUG - 2016-10-03 17:07:04 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:07:04 --> Security Class Initialized
DEBUG - 2016-10-03 17:07:04 --> Input Class Initialized
DEBUG - 2016-10-03 17:07:04 --> XSS Filtering completed
DEBUG - 2016-10-03 17:07:04 --> XSS Filtering completed
DEBUG - 2016-10-03 17:07:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:07:04 --> Language Class Initialized
DEBUG - 2016-10-03 17:07:04 --> Loader Class Initialized
DEBUG - 2016-10-03 17:07:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:07:04 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:07:04 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:07:04 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:07:04 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:07:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:07:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:07:04 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:07:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:07:04 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:07:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:07:04 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:07:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:07:04 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:07:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:07:04 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:07:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:07:04 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:07:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:07:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:07:04 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:07:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:07:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:07:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:07:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:07:04 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:07:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:07:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:07:04 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:07:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:07:04 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:07:04 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:07:04 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:07:04 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:07:04 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:07:04 --> Session Class Initialized
DEBUG - 2016-10-03 17:07:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:07:04 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:07:04 --> Session routines successfully run
DEBUG - 2016-10-03 17:07:04 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:07:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:07:04 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:07:04 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:07:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:07:04 --> Controller Class Initialized
DEBUG - 2016-10-03 17:07:04 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:07:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:07:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:07:04 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:07:04 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:07:04 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:07:04 --> Model Class Initialized
DEBUG - 2016-10-03 17:07:04 --> Model Class Initialized
DEBUG - 2016-10-03 17:07:04 --> Model Class Initialized
DEBUG - 2016-10-03 17:07:04 --> Model Class Initialized
DEBUG - 2016-10-03 17:07:04 --> Model Class Initialized
DEBUG - 2016-10-03 17:07:04 --> Model Class Initialized
DEBUG - 2016-10-03 17:07:04 --> Model Class Initialized
DEBUG - 2016-10-03 17:07:04 --> Model Class Initialized
DEBUG - 2016-10-03 17:07:04 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:07:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/tr_pegawai_profil.php
DEBUG - 2016-10-03 17:07:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/detail.php
DEBUG - 2016-10-03 17:07:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:07:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:07:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:07:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:07:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:07:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:07:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:07:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:07:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:07:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:07:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:07:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:07:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:07:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:07:05 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-10-03 17:07:05 --> Final output sent to browser
DEBUG - 2016-10-03 17:07:05 --> Total execution time: 0.5561
DEBUG - 2016-10-03 17:08:48 --> Config Class Initialized
DEBUG - 2016-10-03 17:08:48 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:08:48 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:08:48 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:08:48 --> URI Class Initialized
DEBUG - 2016-10-03 17:08:48 --> Router Class Initialized
DEBUG - 2016-10-03 17:08:48 --> Output Class Initialized
DEBUG - 2016-10-03 17:08:48 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:08:48 --> Security Class Initialized
DEBUG - 2016-10-03 17:08:48 --> Input Class Initialized
DEBUG - 2016-10-03 17:08:48 --> XSS Filtering completed
DEBUG - 2016-10-03 17:08:48 --> XSS Filtering completed
DEBUG - 2016-10-03 17:08:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:08:48 --> Language Class Initialized
DEBUG - 2016-10-03 17:08:48 --> Loader Class Initialized
DEBUG - 2016-10-03 17:08:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:08:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:08:48 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:08:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:08:48 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:08:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:08:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:08:48 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:08:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:08:48 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:08:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:08:48 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:08:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:08:48 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:08:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:08:48 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:08:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:08:48 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:08:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:08:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:08:48 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:08:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:08:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:08:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:08:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:08:48 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:08:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:08:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:08:48 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:08:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:08:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:08:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:08:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:08:48 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:08:48 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:08:48 --> Session Class Initialized
DEBUG - 2016-10-03 17:08:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:08:49 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:08:49 --> Session routines successfully run
DEBUG - 2016-10-03 17:08:49 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:08:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:08:49 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:08:49 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:08:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:08:49 --> Controller Class Initialized
DEBUG - 2016-10-03 17:08:49 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:08:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:08:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:08:49 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:08:49 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:08:49 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:08:49 --> Model Class Initialized
DEBUG - 2016-10-03 17:08:49 --> Model Class Initialized
DEBUG - 2016-10-03 17:08:49 --> Model Class Initialized
DEBUG - 2016-10-03 17:08:49 --> Model Class Initialized
DEBUG - 2016-10-03 17:08:49 --> Model Class Initialized
DEBUG - 2016-10-03 17:08:49 --> Model Class Initialized
DEBUG - 2016-10-03 17:08:49 --> Model Class Initialized
DEBUG - 2016-10-03 17:08:49 --> Model Class Initialized
DEBUG - 2016-10-03 17:08:49 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/tr_pegawai_profil.php
DEBUG - 2016-10-03 17:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/detail.php
DEBUG - 2016-10-03 17:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:08:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:08:49 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-10-03 17:08:49 --> Final output sent to browser
DEBUG - 2016-10-03 17:08:49 --> Total execution time: 0.5811
DEBUG - 2016-10-03 17:09:25 --> Config Class Initialized
DEBUG - 2016-10-03 17:09:25 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:09:25 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:09:25 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:09:25 --> URI Class Initialized
DEBUG - 2016-10-03 17:09:25 --> Router Class Initialized
DEBUG - 2016-10-03 17:09:25 --> Output Class Initialized
DEBUG - 2016-10-03 17:09:25 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:09:25 --> Security Class Initialized
DEBUG - 2016-10-03 17:09:25 --> Input Class Initialized
DEBUG - 2016-10-03 17:09:25 --> XSS Filtering completed
DEBUG - 2016-10-03 17:09:25 --> XSS Filtering completed
DEBUG - 2016-10-03 17:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:09:25 --> Language Class Initialized
DEBUG - 2016-10-03 17:09:25 --> Loader Class Initialized
DEBUG - 2016-10-03 17:09:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:09:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:09:25 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:09:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:09:25 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:09:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:09:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:09:25 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:09:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:09:25 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:09:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:09:25 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:09:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:09:25 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:09:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:09:25 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:09:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:09:25 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:09:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:09:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:09:25 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:09:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:09:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:09:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:09:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:09:25 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:09:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:09:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:09:25 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:09:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:09:25 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:09:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:09:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:09:25 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:09:25 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:09:25 --> Session Class Initialized
DEBUG - 2016-10-03 17:09:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:09:25 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:09:25 --> Session routines successfully run
DEBUG - 2016-10-03 17:09:25 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:09:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:09:25 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:09:25 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:09:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:09:25 --> Controller Class Initialized
DEBUG - 2016-10-03 17:09:25 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:09:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:09:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:09:25 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:09:25 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:09:25 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:09:25 --> Model Class Initialized
DEBUG - 2016-10-03 17:09:25 --> Model Class Initialized
DEBUG - 2016-10-03 17:09:25 --> Model Class Initialized
DEBUG - 2016-10-03 17:09:25 --> Model Class Initialized
DEBUG - 2016-10-03 17:09:25 --> Model Class Initialized
DEBUG - 2016-10-03 17:09:25 --> Model Class Initialized
DEBUG - 2016-10-03 17:09:25 --> Model Class Initialized
DEBUG - 2016-10-03 17:09:25 --> Model Class Initialized
DEBUG - 2016-10-03 17:09:25 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:09:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/tr_pegawai_profil.php
DEBUG - 2016-10-03 17:09:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/detail.php
DEBUG - 2016-10-03 17:09:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:09:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:09:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:09:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:09:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:09:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:09:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:09:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:09:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:09:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:09:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:09:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:09:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:09:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:09:26 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-10-03 17:09:26 --> Final output sent to browser
DEBUG - 2016-10-03 17:09:26 --> Total execution time: 0.6171
DEBUG - 2016-10-03 17:09:30 --> Config Class Initialized
DEBUG - 2016-10-03 17:09:30 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:09:30 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:09:30 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:09:30 --> URI Class Initialized
DEBUG - 2016-10-03 17:09:30 --> Router Class Initialized
DEBUG - 2016-10-03 17:09:30 --> Output Class Initialized
DEBUG - 2016-10-03 17:09:30 --> Security Class Initialized
DEBUG - 2016-10-03 17:09:30 --> Input Class Initialized
DEBUG - 2016-10-03 17:09:30 --> XSS Filtering completed
DEBUG - 2016-10-03 17:09:30 --> XSS Filtering completed
DEBUG - 2016-10-03 17:09:30 --> XSS Filtering completed
DEBUG - 2016-10-03 17:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:09:30 --> Language Class Initialized
DEBUG - 2016-10-03 17:09:30 --> Loader Class Initialized
DEBUG - 2016-10-03 17:09:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:09:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:09:30 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:09:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:09:30 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:09:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:09:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:09:30 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:09:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:09:30 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:09:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:09:30 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:09:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:09:30 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:09:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:09:30 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:09:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:09:30 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:09:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:09:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:09:30 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:09:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:09:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:09:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:09:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:09:30 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:09:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:09:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:09:30 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:09:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:09:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:09:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:09:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:09:30 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:09:30 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:09:30 --> Session Class Initialized
DEBUG - 2016-10-03 17:09:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:09:30 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:09:30 --> Session routines successfully run
DEBUG - 2016-10-03 17:09:30 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:09:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:09:30 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:09:30 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:09:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:09:30 --> Controller Class Initialized
DEBUG - 2016-10-03 17:09:30 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:09:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:09:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:09:30 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:09:30 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:09:30 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:09:30 --> Model Class Initialized
DEBUG - 2016-10-03 17:09:30 --> Model Class Initialized
DEBUG - 2016-10-03 17:09:30 --> Model Class Initialized
DEBUG - 2016-10-03 17:09:30 --> Model Class Initialized
DEBUG - 2016-10-03 17:09:30 --> Model Class Initialized
DEBUG - 2016-10-03 17:09:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:09:30 --> Final output sent to browser
DEBUG - 2016-10-03 17:09:30 --> Total execution time: 0.6441
DEBUG - 2016-10-03 17:09:43 --> Config Class Initialized
DEBUG - 2016-10-03 17:09:43 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:09:43 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:09:43 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:09:43 --> URI Class Initialized
DEBUG - 2016-10-03 17:09:43 --> Router Class Initialized
DEBUG - 2016-10-03 17:09:43 --> Output Class Initialized
DEBUG - 2016-10-03 17:09:43 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:09:43 --> Security Class Initialized
DEBUG - 2016-10-03 17:09:43 --> Input Class Initialized
DEBUG - 2016-10-03 17:09:43 --> XSS Filtering completed
DEBUG - 2016-10-03 17:09:43 --> XSS Filtering completed
DEBUG - 2016-10-03 17:09:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:09:43 --> Language Class Initialized
DEBUG - 2016-10-03 17:09:43 --> Loader Class Initialized
DEBUG - 2016-10-03 17:09:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:09:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:09:43 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:09:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:09:43 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:09:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:09:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:09:43 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:09:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:09:43 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:09:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:09:43 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:09:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:09:43 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:09:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:09:43 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:09:43 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:09:43 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:09:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:09:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:09:43 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:09:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:09:43 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:09:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:09:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:09:43 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:09:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:09:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:09:43 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:09:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:09:43 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:09:43 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:09:43 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:09:43 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:09:43 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:09:43 --> Session Class Initialized
DEBUG - 2016-10-03 17:09:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:09:44 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:09:44 --> Session routines successfully run
DEBUG - 2016-10-03 17:09:44 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:09:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:09:44 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:09:44 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:09:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:09:44 --> Controller Class Initialized
DEBUG - 2016-10-03 17:09:44 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:09:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:09:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:09:44 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:09:44 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:09:44 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:09:44 --> Model Class Initialized
DEBUG - 2016-10-03 17:09:44 --> Model Class Initialized
DEBUG - 2016-10-03 17:09:44 --> Model Class Initialized
DEBUG - 2016-10-03 17:09:44 --> Model Class Initialized
DEBUG - 2016-10-03 17:09:44 --> Model Class Initialized
DEBUG - 2016-10-03 17:09:44 --> Model Class Initialized
DEBUG - 2016-10-03 17:09:44 --> Model Class Initialized
DEBUG - 2016-10-03 17:09:44 --> Model Class Initialized
DEBUG - 2016-10-03 17:09:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-03 17:09:44 --> Pagination Class Initialized
DEBUG - 2016-10-03 17:09:44 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:09:44 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/index.php
DEBUG - 2016-10-03 17:09:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:09:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:09:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:09:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:09:44 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-03 17:09:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:09:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:09:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:09:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:09:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:09:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:09:44 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-03 17:09:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:09:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:09:44 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55961f1d1ca16fdfc4239ae1901a174e
DEBUG - 2016-10-03 17:09:44 --> Final output sent to browser
DEBUG - 2016-10-03 17:09:44 --> Total execution time: 0.6816
DEBUG - 2016-10-03 17:10:34 --> Config Class Initialized
DEBUG - 2016-10-03 17:10:34 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:10:34 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:10:34 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:10:34 --> URI Class Initialized
DEBUG - 2016-10-03 17:10:34 --> Router Class Initialized
DEBUG - 2016-10-03 17:10:34 --> Output Class Initialized
DEBUG - 2016-10-03 17:10:35 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:10:35 --> Security Class Initialized
DEBUG - 2016-10-03 17:10:35 --> Input Class Initialized
DEBUG - 2016-10-03 17:10:35 --> XSS Filtering completed
DEBUG - 2016-10-03 17:10:35 --> XSS Filtering completed
DEBUG - 2016-10-03 17:10:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:10:35 --> Language Class Initialized
DEBUG - 2016-10-03 17:10:35 --> Loader Class Initialized
DEBUG - 2016-10-03 17:10:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:10:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:10:35 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:10:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:10:35 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:10:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:10:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:10:35 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:10:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:10:35 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:10:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:10:35 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:10:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:10:35 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:10:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:10:35 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:10:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:10:35 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:10:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:10:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:10:35 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:10:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:10:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:10:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:10:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:10:35 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:10:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:10:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:10:35 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:10:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:10:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:10:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:10:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:10:35 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:10:35 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:10:35 --> Session Class Initialized
DEBUG - 2016-10-03 17:10:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:10:35 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:10:35 --> Session routines successfully run
DEBUG - 2016-10-03 17:10:35 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:10:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:10:35 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:10:35 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:10:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:10:35 --> Controller Class Initialized
DEBUG - 2016-10-03 17:10:35 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:10:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:10:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:10:35 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:10:35 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:10:35 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:10:35 --> Model Class Initialized
DEBUG - 2016-10-03 17:10:35 --> Model Class Initialized
DEBUG - 2016-10-03 17:10:35 --> Model Class Initialized
DEBUG - 2016-10-03 17:10:35 --> Model Class Initialized
DEBUG - 2016-10-03 17:10:35 --> Model Class Initialized
DEBUG - 2016-10-03 17:10:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-03 17:10:35 --> Pagination Class Initialized
DEBUG - 2016-10-03 17:10:35 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:10:35 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/role/atlant/index.php
DEBUG - 2016-10-03 17:10:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:10:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:10:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:10:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:10:35 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/role/atlant/js/index_js.php
DEBUG - 2016-10-03 17:10:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:10:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:10:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:10:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:10:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:10:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:10:35 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/role/atlant/js/index_js.php
DEBUG - 2016-10-03 17:10:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:10:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:10:35 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/bc71e124988d1eb532a929fcbfe4318b
DEBUG - 2016-10-03 17:10:35 --> Final output sent to browser
DEBUG - 2016-10-03 17:10:35 --> Total execution time: 0.7905
DEBUG - 2016-10-03 17:10:40 --> Config Class Initialized
DEBUG - 2016-10-03 17:10:40 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:10:40 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:10:40 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:10:40 --> URI Class Initialized
DEBUG - 2016-10-03 17:10:40 --> Router Class Initialized
DEBUG - 2016-10-03 17:10:40 --> Output Class Initialized
DEBUG - 2016-10-03 17:10:40 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:10:40 --> Security Class Initialized
DEBUG - 2016-10-03 17:10:40 --> Input Class Initialized
DEBUG - 2016-10-03 17:10:40 --> XSS Filtering completed
DEBUG - 2016-10-03 17:10:40 --> XSS Filtering completed
DEBUG - 2016-10-03 17:10:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:10:40 --> Language Class Initialized
DEBUG - 2016-10-03 17:10:40 --> Loader Class Initialized
DEBUG - 2016-10-03 17:10:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:10:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:10:40 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:10:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:10:40 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:10:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:10:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:10:40 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:10:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:10:40 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:10:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:10:40 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:10:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:10:40 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:10:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:10:40 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:10:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:10:40 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:10:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:10:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:10:40 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:10:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:10:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:10:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:10:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:10:40 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:10:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:10:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:10:40 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:10:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:10:40 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:10:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:10:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:10:40 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:10:40 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:10:40 --> Session Class Initialized
DEBUG - 2016-10-03 17:10:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:10:40 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:10:40 --> Session routines successfully run
DEBUG - 2016-10-03 17:10:40 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:10:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:10:40 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:10:40 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:10:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:10:40 --> Controller Class Initialized
DEBUG - 2016-10-03 17:10:40 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:10:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:10:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:10:40 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:10:40 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:10:41 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:10:41 --> Model Class Initialized
DEBUG - 2016-10-03 17:10:41 --> Model Class Initialized
DEBUG - 2016-10-03 17:10:41 --> Model Class Initialized
DEBUG - 2016-10-03 17:10:41 --> Model Class Initialized
DEBUG - 2016-10-03 17:10:41 --> Model Class Initialized
DEBUG - 2016-10-03 17:10:41 --> Model Class Initialized
DEBUG - 2016-10-03 17:10:41 --> Model Class Initialized
DEBUG - 2016-10-03 17:10:41 --> Model Class Initialized
DEBUG - 2016-10-03 17:10:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-03 17:10:41 --> Pagination Class Initialized
DEBUG - 2016-10-03 17:10:41 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:10:41 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/index.php
DEBUG - 2016-10-03 17:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:10:41 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-03 17:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:10:41 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-03 17:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:10:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:10:41 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55961f1d1ca16fdfc4239ae1901a174e
DEBUG - 2016-10-03 17:10:41 --> Final output sent to browser
DEBUG - 2016-10-03 17:10:41 --> Total execution time: 0.7487
DEBUG - 2016-10-03 17:10:46 --> Config Class Initialized
DEBUG - 2016-10-03 17:10:46 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:10:46 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:10:46 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:10:46 --> URI Class Initialized
DEBUG - 2016-10-03 17:10:46 --> Router Class Initialized
DEBUG - 2016-10-03 17:10:46 --> Output Class Initialized
DEBUG - 2016-10-03 17:10:46 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:10:46 --> Security Class Initialized
DEBUG - 2016-10-03 17:10:46 --> Input Class Initialized
DEBUG - 2016-10-03 17:10:46 --> XSS Filtering completed
DEBUG - 2016-10-03 17:10:46 --> XSS Filtering completed
DEBUG - 2016-10-03 17:10:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:10:46 --> Language Class Initialized
DEBUG - 2016-10-03 17:10:46 --> Loader Class Initialized
DEBUG - 2016-10-03 17:10:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:10:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:10:46 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:10:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:10:46 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:10:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:10:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:10:46 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:10:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:10:46 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:10:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:10:46 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:10:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:10:46 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:10:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:10:46 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:10:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:10:46 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:10:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:10:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:10:46 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:10:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:10:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:10:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:10:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:10:46 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:10:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:10:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:10:46 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:10:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:10:46 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:10:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:10:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:10:46 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:10:46 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:10:47 --> Session Class Initialized
DEBUG - 2016-10-03 17:10:47 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:10:47 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:10:47 --> Session routines successfully run
DEBUG - 2016-10-03 17:10:47 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:10:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:10:47 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:10:47 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:10:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:10:47 --> Controller Class Initialized
DEBUG - 2016-10-03 17:10:47 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:10:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:10:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:10:47 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:10:47 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:10:47 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:10:47 --> Model Class Initialized
DEBUG - 2016-10-03 17:10:47 --> Model Class Initialized
DEBUG - 2016-10-03 17:10:47 --> Model Class Initialized
DEBUG - 2016-10-03 17:10:47 --> Model Class Initialized
DEBUG - 2016-10-03 17:10:47 --> Model Class Initialized
DEBUG - 2016-10-03 17:10:47 --> Model Class Initialized
DEBUG - 2016-10-03 17:10:47 --> Model Class Initialized
DEBUG - 2016-10-03 17:10:47 --> Model Class Initialized
DEBUG - 2016-10-03 17:10:47 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:10:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/tr_pegawai_profil.php
DEBUG - 2016-10-03 17:10:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/detail.php
DEBUG - 2016-10-03 17:10:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:10:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:10:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:10:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:10:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:10:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:10:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:10:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:10:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:10:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:10:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:10:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:10:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:10:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:10:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-10-03 17:10:47 --> Final output sent to browser
DEBUG - 2016-10-03 17:10:47 --> Total execution time: 0.7288
DEBUG - 2016-10-03 17:12:09 --> Config Class Initialized
DEBUG - 2016-10-03 17:12:09 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:12:09 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:12:09 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:12:09 --> URI Class Initialized
DEBUG - 2016-10-03 17:12:09 --> Router Class Initialized
DEBUG - 2016-10-03 17:12:09 --> Output Class Initialized
DEBUG - 2016-10-03 17:12:09 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:12:09 --> Security Class Initialized
DEBUG - 2016-10-03 17:12:09 --> Input Class Initialized
DEBUG - 2016-10-03 17:12:09 --> XSS Filtering completed
DEBUG - 2016-10-03 17:12:09 --> XSS Filtering completed
DEBUG - 2016-10-03 17:12:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:12:09 --> Language Class Initialized
DEBUG - 2016-10-03 17:12:09 --> Loader Class Initialized
DEBUG - 2016-10-03 17:12:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:12:09 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:12:09 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:12:09 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:12:09 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:12:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:12:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:12:09 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:12:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:12:09 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:12:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:12:09 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:12:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:12:09 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:12:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:12:09 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:12:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:12:09 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:12:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:12:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:12:09 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:12:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:12:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:12:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:12:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:12:09 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:12:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:12:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:12:09 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:12:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:12:09 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:12:09 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:12:09 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:12:09 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:12:09 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:12:09 --> Session Class Initialized
DEBUG - 2016-10-03 17:12:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:12:09 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:12:09 --> Session routines successfully run
DEBUG - 2016-10-03 17:12:09 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:12:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:12:09 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:12:09 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:12:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:12:09 --> Controller Class Initialized
DEBUG - 2016-10-03 17:12:09 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:12:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:12:09 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:12:09 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:12:09 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:12:09 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:12:09 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:09 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:09 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:09 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:09 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:09 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:09 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:09 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:09 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/tr_pegawai_profil.php
DEBUG - 2016-10-03 17:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/detail.php
DEBUG - 2016-10-03 17:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:12:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:12:09 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-10-03 17:12:09 --> Final output sent to browser
DEBUG - 2016-10-03 17:12:09 --> Total execution time: 0.7230
DEBUG - 2016-10-03 17:12:15 --> Config Class Initialized
DEBUG - 2016-10-03 17:12:15 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:12:15 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:12:15 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:12:15 --> URI Class Initialized
DEBUG - 2016-10-03 17:12:15 --> Router Class Initialized
DEBUG - 2016-10-03 17:12:15 --> Output Class Initialized
DEBUG - 2016-10-03 17:12:15 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:12:15 --> Security Class Initialized
DEBUG - 2016-10-03 17:12:15 --> Input Class Initialized
DEBUG - 2016-10-03 17:12:15 --> XSS Filtering completed
DEBUG - 2016-10-03 17:12:15 --> XSS Filtering completed
DEBUG - 2016-10-03 17:12:15 --> XSS Filtering completed
DEBUG - 2016-10-03 17:12:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:12:15 --> Language Class Initialized
DEBUG - 2016-10-03 17:12:15 --> Loader Class Initialized
DEBUG - 2016-10-03 17:12:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:12:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:12:15 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:12:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:12:15 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:12:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:12:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:12:15 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:12:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:12:15 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:12:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:12:15 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:12:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:12:15 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:12:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:12:15 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:12:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:12:15 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:12:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:12:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:12:15 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:12:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:12:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:12:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:12:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:12:15 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:12:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:12:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:12:15 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:12:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:12:15 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:12:15 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:12:15 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:12:15 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:12:15 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:12:15 --> Session Class Initialized
DEBUG - 2016-10-03 17:12:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:12:15 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:12:15 --> Session routines successfully run
DEBUG - 2016-10-03 17:12:15 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:12:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:12:15 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:12:15 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:12:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:12:15 --> Controller Class Initialized
DEBUG - 2016-10-03 17:12:15 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:12:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:12:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:12:15 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:12:15 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:12:15 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:12:15 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:15 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:15 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:15 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:15 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:15 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:12:15 --> Final output sent to browser
DEBUG - 2016-10-03 17:12:15 --> Total execution time: 0.7273
DEBUG - 2016-10-03 17:12:20 --> Config Class Initialized
DEBUG - 2016-10-03 17:12:20 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:12:20 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:12:20 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:12:20 --> URI Class Initialized
DEBUG - 2016-10-03 17:12:20 --> Router Class Initialized
DEBUG - 2016-10-03 17:12:20 --> Output Class Initialized
DEBUG - 2016-10-03 17:12:20 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:12:20 --> Security Class Initialized
DEBUG - 2016-10-03 17:12:20 --> Input Class Initialized
DEBUG - 2016-10-03 17:12:20 --> XSS Filtering completed
DEBUG - 2016-10-03 17:12:20 --> XSS Filtering completed
DEBUG - 2016-10-03 17:12:20 --> XSS Filtering completed
DEBUG - 2016-10-03 17:12:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:12:20 --> Language Class Initialized
DEBUG - 2016-10-03 17:12:20 --> Loader Class Initialized
DEBUG - 2016-10-03 17:12:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:12:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:12:20 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:12:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:12:20 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:12:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:12:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:12:20 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:12:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:12:20 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:12:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:12:20 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:12:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:12:20 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:12:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:12:20 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:12:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:12:20 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:12:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:12:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:12:20 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:12:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:12:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:12:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:12:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:12:20 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:12:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:12:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:12:20 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:12:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:12:20 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:12:20 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:12:20 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:12:20 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:12:20 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:12:20 --> Session Class Initialized
DEBUG - 2016-10-03 17:12:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:12:20 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:12:20 --> Session routines successfully run
DEBUG - 2016-10-03 17:12:20 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:12:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:12:20 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:12:20 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:12:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:12:20 --> Controller Class Initialized
DEBUG - 2016-10-03 17:12:20 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:12:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:12:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:12:20 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:12:20 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:12:20 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:12:20 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:20 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:20 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:20 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:20 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:20 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:12:20 --> Final output sent to browser
DEBUG - 2016-10-03 17:12:20 --> Total execution time: 0.7526
DEBUG - 2016-10-03 17:12:51 --> Config Class Initialized
DEBUG - 2016-10-03 17:12:51 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:12:51 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:12:51 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:12:51 --> URI Class Initialized
DEBUG - 2016-10-03 17:12:51 --> Router Class Initialized
DEBUG - 2016-10-03 17:12:51 --> Output Class Initialized
DEBUG - 2016-10-03 17:12:51 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:12:51 --> Security Class Initialized
DEBUG - 2016-10-03 17:12:51 --> Input Class Initialized
DEBUG - 2016-10-03 17:12:51 --> XSS Filtering completed
DEBUG - 2016-10-03 17:12:51 --> XSS Filtering completed
DEBUG - 2016-10-03 17:12:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:12:51 --> Language Class Initialized
DEBUG - 2016-10-03 17:12:51 --> Loader Class Initialized
DEBUG - 2016-10-03 17:12:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:12:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:12:51 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:12:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:12:51 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:12:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:12:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:12:51 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:12:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:12:51 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:12:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:12:51 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:12:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:12:51 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:12:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:12:51 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:12:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:12:51 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:12:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:12:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:12:51 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:12:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:12:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:12:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:12:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:12:51 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:12:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:12:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:12:51 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:12:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:12:51 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:12:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:12:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:12:51 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:12:51 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:12:51 --> Session Class Initialized
DEBUG - 2016-10-03 17:12:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:12:51 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:12:51 --> Session routines successfully run
DEBUG - 2016-10-03 17:12:51 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:12:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:12:52 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:12:52 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:12:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:12:52 --> Controller Class Initialized
DEBUG - 2016-10-03 17:12:52 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:12:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:12:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:12:52 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:12:52 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:12:52 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:12:52 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:52 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:52 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:52 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:52 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:52 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:52 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:52 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:52 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:12:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/tr_pegawai_profil.php
DEBUG - 2016-10-03 17:12:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/detail.php
DEBUG - 2016-10-03 17:12:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:12:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:12:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:12:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:12:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:12:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:12:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:12:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:12:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:12:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:12:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:12:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:12:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:12:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:12:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-10-03 17:12:52 --> Final output sent to browser
DEBUG - 2016-10-03 17:12:52 --> Total execution time: 0.7784
DEBUG - 2016-10-03 17:12:56 --> Config Class Initialized
DEBUG - 2016-10-03 17:12:56 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:12:56 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:12:56 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:12:56 --> URI Class Initialized
DEBUG - 2016-10-03 17:12:56 --> Router Class Initialized
DEBUG - 2016-10-03 17:12:56 --> Output Class Initialized
DEBUG - 2016-10-03 17:12:56 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:12:56 --> Security Class Initialized
DEBUG - 2016-10-03 17:12:56 --> Input Class Initialized
DEBUG - 2016-10-03 17:12:56 --> XSS Filtering completed
DEBUG - 2016-10-03 17:12:56 --> XSS Filtering completed
DEBUG - 2016-10-03 17:12:56 --> XSS Filtering completed
DEBUG - 2016-10-03 17:12:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:12:56 --> Language Class Initialized
DEBUG - 2016-10-03 17:12:56 --> Loader Class Initialized
DEBUG - 2016-10-03 17:12:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:12:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:12:56 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:12:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:12:57 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:12:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:12:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:12:57 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:12:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:12:57 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:12:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:12:57 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:12:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:12:57 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:12:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:12:57 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:12:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:12:57 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:12:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:12:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:12:57 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:12:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:12:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:12:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:12:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:12:57 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:12:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:12:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:12:57 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:12:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:12:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:12:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:12:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:12:57 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:12:57 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:12:57 --> Session Class Initialized
DEBUG - 2016-10-03 17:12:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:12:57 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:12:57 --> Session routines successfully run
DEBUG - 2016-10-03 17:12:57 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:12:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:12:57 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:12:57 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:12:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:12:57 --> Controller Class Initialized
DEBUG - 2016-10-03 17:12:57 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:12:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:12:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:12:57 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:12:57 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:12:57 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:12:57 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:57 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:57 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:57 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:57 --> Model Class Initialized
DEBUG - 2016-10-03 17:12:57 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:12:57 --> Final output sent to browser
DEBUG - 2016-10-03 17:12:57 --> Total execution time: 0.7627
DEBUG - 2016-10-03 17:13:22 --> Config Class Initialized
DEBUG - 2016-10-03 17:13:22 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:13:22 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:13:22 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:13:22 --> URI Class Initialized
DEBUG - 2016-10-03 17:13:22 --> Router Class Initialized
DEBUG - 2016-10-03 17:13:22 --> Output Class Initialized
DEBUG - 2016-10-03 17:13:22 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:13:22 --> Security Class Initialized
DEBUG - 2016-10-03 17:13:22 --> Input Class Initialized
DEBUG - 2016-10-03 17:13:22 --> XSS Filtering completed
DEBUG - 2016-10-03 17:13:22 --> XSS Filtering completed
DEBUG - 2016-10-03 17:13:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:13:22 --> Language Class Initialized
DEBUG - 2016-10-03 17:13:22 --> Loader Class Initialized
DEBUG - 2016-10-03 17:13:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:13:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:13:22 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:13:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:13:22 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:13:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:13:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:13:22 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:13:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:13:22 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:13:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:13:22 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:13:22 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:13:22 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:13:22 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:13:22 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:13:22 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:13:22 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:13:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:13:22 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:13:22 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:13:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:13:22 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:13:22 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:13:22 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:13:22 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:13:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:13:22 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:13:22 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:13:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:13:22 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:13:22 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:13:22 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:13:22 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:13:22 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:13:22 --> Session Class Initialized
DEBUG - 2016-10-03 17:13:22 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:13:22 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:13:22 --> Session routines successfully run
DEBUG - 2016-10-03 17:13:22 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:13:22 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:13:22 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:13:22 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:13:22 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:13:22 --> Controller Class Initialized
DEBUG - 2016-10-03 17:13:22 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:13:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:13:22 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:13:22 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:13:22 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:13:22 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:13:22 --> Model Class Initialized
DEBUG - 2016-10-03 17:13:22 --> Model Class Initialized
DEBUG - 2016-10-03 17:13:22 --> Model Class Initialized
DEBUG - 2016-10-03 17:13:22 --> Model Class Initialized
DEBUG - 2016-10-03 17:13:23 --> Model Class Initialized
DEBUG - 2016-10-03 17:13:23 --> Model Class Initialized
DEBUG - 2016-10-03 17:13:23 --> Model Class Initialized
DEBUG - 2016-10-03 17:13:23 --> Model Class Initialized
DEBUG - 2016-10-03 17:13:23 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:13:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/tr_pegawai_profil.php
DEBUG - 2016-10-03 17:13:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/detail.php
DEBUG - 2016-10-03 17:13:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:13:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:13:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:13:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:13:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:13:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:13:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:13:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:13:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:13:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:13:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:13:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:13:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:13:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:13:23 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-10-03 17:13:23 --> Final output sent to browser
DEBUG - 2016-10-03 17:13:23 --> Total execution time: 0.7964
DEBUG - 2016-10-03 17:13:27 --> Config Class Initialized
DEBUG - 2016-10-03 17:13:27 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:13:27 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:13:27 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:13:27 --> URI Class Initialized
DEBUG - 2016-10-03 17:13:27 --> Router Class Initialized
DEBUG - 2016-10-03 17:13:27 --> Output Class Initialized
DEBUG - 2016-10-03 17:13:27 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:13:27 --> Security Class Initialized
DEBUG - 2016-10-03 17:13:27 --> Input Class Initialized
DEBUG - 2016-10-03 17:13:27 --> XSS Filtering completed
DEBUG - 2016-10-03 17:13:27 --> XSS Filtering completed
DEBUG - 2016-10-03 17:13:27 --> XSS Filtering completed
DEBUG - 2016-10-03 17:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:13:27 --> Language Class Initialized
DEBUG - 2016-10-03 17:13:27 --> Loader Class Initialized
DEBUG - 2016-10-03 17:13:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:13:28 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:13:28 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:13:28 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:13:28 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:13:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:13:28 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:13:28 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:13:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:13:28 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:13:28 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:13:28 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:13:28 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:13:28 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:13:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:13:28 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:13:28 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:13:28 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:13:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:13:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:13:28 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:13:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:13:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:13:28 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:13:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:13:28 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:13:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:13:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:13:28 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:13:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:13:28 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:13:28 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:13:28 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:13:28 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:13:28 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:13:28 --> Session Class Initialized
DEBUG - 2016-10-03 17:13:28 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:13:28 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:13:28 --> Session routines successfully run
DEBUG - 2016-10-03 17:13:28 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:13:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:13:28 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:13:28 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:13:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:13:28 --> Controller Class Initialized
DEBUG - 2016-10-03 17:13:28 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:13:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:13:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:13:28 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:13:28 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:13:28 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:13:28 --> Model Class Initialized
DEBUG - 2016-10-03 17:13:28 --> Model Class Initialized
DEBUG - 2016-10-03 17:13:28 --> Model Class Initialized
DEBUG - 2016-10-03 17:13:28 --> Model Class Initialized
DEBUG - 2016-10-03 17:13:28 --> Model Class Initialized
DEBUG - 2016-10-03 17:13:28 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:13:28 --> Final output sent to browser
DEBUG - 2016-10-03 17:13:28 --> Total execution time: 0.7966
DEBUG - 2016-10-03 17:15:20 --> Config Class Initialized
DEBUG - 2016-10-03 17:15:20 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:15:20 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:15:20 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:15:20 --> URI Class Initialized
DEBUG - 2016-10-03 17:15:20 --> Router Class Initialized
DEBUG - 2016-10-03 17:15:20 --> Output Class Initialized
DEBUG - 2016-10-03 17:15:20 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:15:20 --> Security Class Initialized
DEBUG - 2016-10-03 17:15:20 --> Input Class Initialized
DEBUG - 2016-10-03 17:15:20 --> XSS Filtering completed
DEBUG - 2016-10-03 17:15:20 --> XSS Filtering completed
DEBUG - 2016-10-03 17:15:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:15:20 --> Language Class Initialized
DEBUG - 2016-10-03 17:15:20 --> Loader Class Initialized
DEBUG - 2016-10-03 17:15:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:15:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:15:20 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:15:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:15:20 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:15:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:15:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:15:20 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:15:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:15:20 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:15:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:15:21 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:15:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:15:21 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:15:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:15:21 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:15:21 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:15:21 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:15:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:15:21 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:15:21 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:15:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:15:21 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:15:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:15:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:15:21 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:15:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:15:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:15:21 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:15:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:15:21 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:15:21 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:15:21 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:15:21 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:15:21 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:15:21 --> Session Class Initialized
DEBUG - 2016-10-03 17:15:21 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:15:21 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:15:21 --> Session routines successfully run
DEBUG - 2016-10-03 17:15:21 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:15:21 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:15:21 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:15:21 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:15:21 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:15:21 --> Controller Class Initialized
DEBUG - 2016-10-03 17:15:21 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:15:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:15:21 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:15:21 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:15:21 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:15:21 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:15:21 --> Model Class Initialized
DEBUG - 2016-10-03 17:15:21 --> Model Class Initialized
DEBUG - 2016-10-03 17:15:21 --> Model Class Initialized
DEBUG - 2016-10-03 17:15:21 --> Model Class Initialized
DEBUG - 2016-10-03 17:15:21 --> Model Class Initialized
DEBUG - 2016-10-03 17:15:21 --> Model Class Initialized
DEBUG - 2016-10-03 17:15:21 --> Model Class Initialized
DEBUG - 2016-10-03 17:15:21 --> Model Class Initialized
DEBUG - 2016-10-03 17:15:21 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:15:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/tr_pegawai_profil.php
DEBUG - 2016-10-03 17:15:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/detail.php
DEBUG - 2016-10-03 17:15:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:15:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:15:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:15:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:15:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:15:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:15:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:15:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:15:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:15:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:15:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:15:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:15:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:15:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:15:21 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-10-03 17:15:21 --> Final output sent to browser
DEBUG - 2016-10-03 17:15:21 --> Total execution time: 0.8450
DEBUG - 2016-10-03 17:15:24 --> Config Class Initialized
DEBUG - 2016-10-03 17:15:24 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:15:24 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:15:24 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:15:24 --> URI Class Initialized
DEBUG - 2016-10-03 17:15:24 --> Router Class Initialized
DEBUG - 2016-10-03 17:15:24 --> Output Class Initialized
DEBUG - 2016-10-03 17:15:24 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:15:24 --> Security Class Initialized
DEBUG - 2016-10-03 17:15:24 --> Input Class Initialized
DEBUG - 2016-10-03 17:15:24 --> XSS Filtering completed
DEBUG - 2016-10-03 17:15:24 --> XSS Filtering completed
DEBUG - 2016-10-03 17:15:24 --> XSS Filtering completed
DEBUG - 2016-10-03 17:15:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:15:24 --> Language Class Initialized
DEBUG - 2016-10-03 17:15:24 --> Loader Class Initialized
DEBUG - 2016-10-03 17:15:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:15:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:15:24 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:15:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:15:24 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:15:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:15:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:15:24 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:15:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:15:24 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:15:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:15:24 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:15:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:15:25 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:15:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:15:25 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:15:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:15:25 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:15:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:15:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:15:25 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:15:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:15:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:15:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:15:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:15:25 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:15:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:15:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:15:25 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:15:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:15:25 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:15:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:15:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:15:25 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:15:25 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:15:25 --> Session Class Initialized
DEBUG - 2016-10-03 17:15:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:15:25 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:15:25 --> Session routines successfully run
DEBUG - 2016-10-03 17:15:25 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:15:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:15:25 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:15:25 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:15:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:15:25 --> Controller Class Initialized
DEBUG - 2016-10-03 17:15:25 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:15:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:15:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:15:25 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:15:25 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:15:25 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:15:25 --> Model Class Initialized
DEBUG - 2016-10-03 17:15:25 --> Model Class Initialized
DEBUG - 2016-10-03 17:15:25 --> Model Class Initialized
DEBUG - 2016-10-03 17:15:25 --> Model Class Initialized
DEBUG - 2016-10-03 17:15:25 --> Model Class Initialized
DEBUG - 2016-10-03 17:15:25 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:15:25 --> Final output sent to browser
DEBUG - 2016-10-03 17:15:25 --> Total execution time: 0.8367
DEBUG - 2016-10-03 17:15:25 --> Config Class Initialized
DEBUG - 2016-10-03 17:15:25 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:15:25 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:15:25 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:15:25 --> URI Class Initialized
DEBUG - 2016-10-03 17:15:25 --> Router Class Initialized
DEBUG - 2016-10-03 17:15:26 --> Output Class Initialized
DEBUG - 2016-10-03 17:15:26 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:15:26 --> Security Class Initialized
DEBUG - 2016-10-03 17:15:26 --> Input Class Initialized
DEBUG - 2016-10-03 17:15:26 --> XSS Filtering completed
DEBUG - 2016-10-03 17:15:26 --> XSS Filtering completed
DEBUG - 2016-10-03 17:15:26 --> XSS Filtering completed
DEBUG - 2016-10-03 17:15:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:15:26 --> Language Class Initialized
DEBUG - 2016-10-03 17:15:26 --> Loader Class Initialized
DEBUG - 2016-10-03 17:15:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:15:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:15:26 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:15:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:15:26 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:15:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:15:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:15:26 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:15:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:15:26 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:15:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:15:26 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:15:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:15:26 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:15:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:15:26 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:15:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:15:26 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:15:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:15:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:15:26 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:15:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:15:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:15:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:15:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:15:26 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:15:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:15:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:15:26 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:15:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:15:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:15:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:15:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:15:26 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:15:26 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:15:26 --> Session Class Initialized
DEBUG - 2016-10-03 17:15:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:15:26 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:15:26 --> Session routines successfully run
DEBUG - 2016-10-03 17:15:26 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:15:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:15:26 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:15:26 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:15:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:15:26 --> Controller Class Initialized
DEBUG - 2016-10-03 17:15:26 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:15:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:15:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:15:26 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:15:26 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:15:26 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:15:26 --> Model Class Initialized
DEBUG - 2016-10-03 17:15:26 --> Model Class Initialized
DEBUG - 2016-10-03 17:15:26 --> Model Class Initialized
DEBUG - 2016-10-03 17:15:26 --> Model Class Initialized
DEBUG - 2016-10-03 17:15:26 --> Model Class Initialized
DEBUG - 2016-10-03 17:15:26 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:15:26 --> Final output sent to browser
DEBUG - 2016-10-03 17:15:26 --> Total execution time: 0.8792
DEBUG - 2016-10-03 17:19:31 --> Config Class Initialized
DEBUG - 2016-10-03 17:19:31 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:19:31 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:19:31 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:19:31 --> URI Class Initialized
DEBUG - 2016-10-03 17:19:31 --> Router Class Initialized
DEBUG - 2016-10-03 17:19:31 --> Output Class Initialized
DEBUG - 2016-10-03 17:19:31 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:19:31 --> Security Class Initialized
DEBUG - 2016-10-03 17:19:31 --> Input Class Initialized
DEBUG - 2016-10-03 17:19:31 --> XSS Filtering completed
DEBUG - 2016-10-03 17:19:31 --> XSS Filtering completed
DEBUG - 2016-10-03 17:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:19:31 --> Language Class Initialized
DEBUG - 2016-10-03 17:19:31 --> Loader Class Initialized
DEBUG - 2016-10-03 17:19:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:19:31 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:19:31 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:19:31 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:19:31 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:19:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:19:31 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:19:31 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:19:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:19:31 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:19:31 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:19:31 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:19:31 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:19:31 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:19:31 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:19:31 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:19:31 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:19:31 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:19:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:19:31 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:19:31 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:19:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:19:31 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:19:31 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:19:31 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:19:31 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:19:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:19:31 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:19:31 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:19:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:19:31 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:19:31 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:19:31 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:19:31 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:19:31 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:19:31 --> Session Class Initialized
DEBUG - 2016-10-03 17:19:31 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:19:31 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:19:31 --> Session routines successfully run
DEBUG - 2016-10-03 17:19:31 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:19:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:19:31 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:19:31 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:19:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:19:32 --> Controller Class Initialized
DEBUG - 2016-10-03 17:19:32 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:19:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:19:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:19:32 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:19:32 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:19:32 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:19:32 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:32 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:32 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:32 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:32 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:32 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:32 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:32 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:32 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/tr_pegawai_profil.php
DEBUG - 2016-10-03 17:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/detail.php
DEBUG - 2016-10-03 17:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:19:32 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:19:32 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-10-03 17:19:32 --> Final output sent to browser
DEBUG - 2016-10-03 17:19:32 --> Total execution time: 0.8992
DEBUG - 2016-10-03 17:19:37 --> Config Class Initialized
DEBUG - 2016-10-03 17:19:37 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:19:37 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:19:37 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:19:37 --> URI Class Initialized
DEBUG - 2016-10-03 17:19:37 --> Router Class Initialized
DEBUG - 2016-10-03 17:19:37 --> Output Class Initialized
DEBUG - 2016-10-03 17:19:37 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:19:37 --> Security Class Initialized
DEBUG - 2016-10-03 17:19:37 --> Input Class Initialized
DEBUG - 2016-10-03 17:19:37 --> XSS Filtering completed
DEBUG - 2016-10-03 17:19:37 --> XSS Filtering completed
DEBUG - 2016-10-03 17:19:37 --> XSS Filtering completed
DEBUG - 2016-10-03 17:19:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:19:37 --> Language Class Initialized
DEBUG - 2016-10-03 17:19:37 --> Loader Class Initialized
DEBUG - 2016-10-03 17:19:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:19:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:19:37 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:19:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:19:37 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:19:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:19:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:19:37 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:19:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:19:37 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:19:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:19:37 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:19:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:19:37 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:19:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:19:37 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:19:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:19:37 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:19:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:19:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:19:37 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:19:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:19:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:19:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:19:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:19:37 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:19:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:19:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:19:37 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:19:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:19:37 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:19:37 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:19:37 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:19:37 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:19:37 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:19:37 --> Session Class Initialized
DEBUG - 2016-10-03 17:19:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:19:37 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:19:37 --> Session routines successfully run
DEBUG - 2016-10-03 17:19:37 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:19:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:19:37 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:19:37 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:19:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:19:37 --> Controller Class Initialized
DEBUG - 2016-10-03 17:19:37 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:19:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:19:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:19:37 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:19:38 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:19:38 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:19:38 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:38 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:38 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:38 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:38 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:38 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:19:38 --> Final output sent to browser
DEBUG - 2016-10-03 17:19:38 --> Total execution time: 0.8763
DEBUG - 2016-10-03 17:19:38 --> Config Class Initialized
DEBUG - 2016-10-03 17:19:38 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:19:38 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:19:38 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:19:38 --> URI Class Initialized
DEBUG - 2016-10-03 17:19:38 --> Router Class Initialized
DEBUG - 2016-10-03 17:19:38 --> Output Class Initialized
DEBUG - 2016-10-03 17:19:38 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:19:39 --> Security Class Initialized
DEBUG - 2016-10-03 17:19:39 --> Input Class Initialized
DEBUG - 2016-10-03 17:19:39 --> XSS Filtering completed
DEBUG - 2016-10-03 17:19:39 --> XSS Filtering completed
DEBUG - 2016-10-03 17:19:39 --> XSS Filtering completed
DEBUG - 2016-10-03 17:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:19:39 --> Language Class Initialized
DEBUG - 2016-10-03 17:19:39 --> Loader Class Initialized
DEBUG - 2016-10-03 17:19:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:19:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:19:39 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:19:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:19:39 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:19:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:19:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:19:39 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:19:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:19:39 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:19:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:19:39 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:19:39 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:19:39 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:19:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:19:39 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:19:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:19:39 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:19:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:19:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:19:39 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:19:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:19:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:19:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:19:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:19:39 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:19:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:19:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:19:39 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:19:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:19:39 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:19:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:19:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:19:39 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:19:39 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:19:39 --> Session Class Initialized
DEBUG - 2016-10-03 17:19:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:19:39 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:19:39 --> Session routines successfully run
DEBUG - 2016-10-03 17:19:39 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:19:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:19:39 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:19:39 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:19:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:19:39 --> Controller Class Initialized
DEBUG - 2016-10-03 17:19:39 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:19:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:19:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:19:39 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:19:39 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:19:39 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:19:39 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:39 --> Config Class Initialized
DEBUG - 2016-10-03 17:19:39 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:19:39 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:39 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:39 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:19:39 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:19:39 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:39 --> URI Class Initialized
DEBUG - 2016-10-03 17:19:39 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:39 --> Router Class Initialized
DEBUG - 2016-10-03 17:19:39 --> Output Class Initialized
DEBUG - 2016-10-03 17:19:39 --> Security Class Initialized
DEBUG - 2016-10-03 17:19:39 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:19:39 --> Final output sent to browser
DEBUG - 2016-10-03 17:19:39 --> Input Class Initialized
DEBUG - 2016-10-03 17:19:39 --> Total execution time: 0.9212
DEBUG - 2016-10-03 17:19:39 --> XSS Filtering completed
DEBUG - 2016-10-03 17:19:39 --> XSS Filtering completed
DEBUG - 2016-10-03 17:19:39 --> XSS Filtering completed
DEBUG - 2016-10-03 17:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:19:39 --> Language Class Initialized
DEBUG - 2016-10-03 17:19:39 --> Loader Class Initialized
DEBUG - 2016-10-03 17:19:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:19:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:19:39 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:19:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:19:39 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:19:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:19:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:19:40 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:19:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:19:40 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:19:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:19:40 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:19:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:19:40 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:19:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:19:40 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:19:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:19:40 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:19:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:19:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:19:40 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:19:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:19:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:19:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:19:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:19:40 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:19:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:19:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:19:40 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:19:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:19:40 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:19:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:19:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:19:40 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:19:40 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:19:40 --> Session Class Initialized
DEBUG - 2016-10-03 17:19:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:19:40 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:19:40 --> Session routines successfully run
DEBUG - 2016-10-03 17:19:40 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:19:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:19:40 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:19:40 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:19:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:19:40 --> Controller Class Initialized
DEBUG - 2016-10-03 17:19:40 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:19:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:19:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:19:40 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:19:40 --> Config Class Initialized
DEBUG - 2016-10-03 17:19:40 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:19:40 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:19:40 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:19:40 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:19:40 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:19:40 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:40 --> URI Class Initialized
DEBUG - 2016-10-03 17:19:40 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:40 --> Router Class Initialized
DEBUG - 2016-10-03 17:19:40 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:40 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:40 --> Output Class Initialized
DEBUG - 2016-10-03 17:19:40 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:19:40 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:40 --> Security Class Initialized
DEBUG - 2016-10-03 17:19:40 --> Input Class Initialized
DEBUG - 2016-10-03 17:19:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:19:40 --> XSS Filtering completed
DEBUG - 2016-10-03 17:19:40 --> XSS Filtering completed
DEBUG - 2016-10-03 17:19:40 --> Final output sent to browser
DEBUG - 2016-10-03 17:19:40 --> Total execution time: 0.9228
DEBUG - 2016-10-03 17:19:40 --> XSS Filtering completed
DEBUG - 2016-10-03 17:19:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:19:40 --> Language Class Initialized
DEBUG - 2016-10-03 17:19:40 --> Loader Class Initialized
DEBUG - 2016-10-03 17:19:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:19:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:19:40 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:19:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:19:40 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:19:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:19:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:19:40 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:19:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:19:40 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:19:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:19:40 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:19:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:19:40 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:19:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:19:40 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:19:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:19:40 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:19:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:19:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:19:40 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:19:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:19:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:19:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:19:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:19:41 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:19:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:19:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:19:41 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:19:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:19:41 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:19:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:19:41 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:19:41 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:19:41 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:19:41 --> Session Class Initialized
DEBUG - 2016-10-03 17:19:41 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:19:41 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:19:41 --> Session routines successfully run
DEBUG - 2016-10-03 17:19:41 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:19:41 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:19:41 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:19:41 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:19:41 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:19:41 --> Controller Class Initialized
DEBUG - 2016-10-03 17:19:41 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:19:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:19:41 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:19:41 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:19:41 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:19:41 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:19:41 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:41 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:41 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:41 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:41 --> Model Class Initialized
DEBUG - 2016-10-03 17:19:41 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:19:41 --> Final output sent to browser
DEBUG - 2016-10-03 17:19:41 --> Total execution time: 0.9630
DEBUG - 2016-10-03 17:21:02 --> Config Class Initialized
DEBUG - 2016-10-03 17:21:02 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:21:02 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:21:02 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:21:02 --> URI Class Initialized
DEBUG - 2016-10-03 17:21:02 --> Router Class Initialized
DEBUG - 2016-10-03 17:21:02 --> Output Class Initialized
DEBUG - 2016-10-03 17:21:02 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:21:02 --> Security Class Initialized
DEBUG - 2016-10-03 17:21:02 --> Input Class Initialized
DEBUG - 2016-10-03 17:21:02 --> XSS Filtering completed
DEBUG - 2016-10-03 17:21:02 --> XSS Filtering completed
DEBUG - 2016-10-03 17:21:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:21:02 --> Language Class Initialized
DEBUG - 2016-10-03 17:21:02 --> Loader Class Initialized
DEBUG - 2016-10-03 17:21:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:21:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:21:03 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:21:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:21:03 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:21:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:21:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:21:03 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:21:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:21:03 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:21:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:21:03 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:21:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:21:03 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:21:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:21:03 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:21:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:21:03 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:21:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:21:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:21:03 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:21:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:21:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:21:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:21:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:21:03 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:21:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:21:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:21:03 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:21:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:21:03 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:21:03 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:21:03 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:21:03 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:21:03 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:21:03 --> Session Class Initialized
DEBUG - 2016-10-03 17:21:03 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:21:03 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:21:03 --> Session routines successfully run
DEBUG - 2016-10-03 17:21:03 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:21:03 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:21:03 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:21:03 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:21:03 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:21:03 --> Controller Class Initialized
DEBUG - 2016-10-03 17:21:03 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:21:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:21:03 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:21:03 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:21:03 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:21:03 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:21:03 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:03 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:03 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:03 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:03 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:03 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:03 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:03 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:03 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:21:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/tr_pegawai_profil.php
DEBUG - 2016-10-03 17:21:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/detail.php
DEBUG - 2016-10-03 17:21:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:21:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:21:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:21:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:21:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:21:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:21:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:21:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:21:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:21:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:21:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:21:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:21:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:21:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:21:03 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-10-03 17:21:04 --> Final output sent to browser
DEBUG - 2016-10-03 17:21:04 --> Total execution time: 0.9603
DEBUG - 2016-10-03 17:21:10 --> Config Class Initialized
DEBUG - 2016-10-03 17:21:10 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:21:10 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:21:10 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:21:10 --> URI Class Initialized
DEBUG - 2016-10-03 17:21:10 --> Router Class Initialized
DEBUG - 2016-10-03 17:21:10 --> Output Class Initialized
DEBUG - 2016-10-03 17:21:10 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:21:10 --> Security Class Initialized
DEBUG - 2016-10-03 17:21:10 --> Input Class Initialized
DEBUG - 2016-10-03 17:21:10 --> XSS Filtering completed
DEBUG - 2016-10-03 17:21:10 --> XSS Filtering completed
DEBUG - 2016-10-03 17:21:10 --> XSS Filtering completed
DEBUG - 2016-10-03 17:21:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:21:10 --> Language Class Initialized
DEBUG - 2016-10-03 17:21:10 --> Loader Class Initialized
DEBUG - 2016-10-03 17:21:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:21:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:21:10 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:21:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:21:10 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:21:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:21:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:21:11 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:21:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:21:11 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:21:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:21:11 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:21:11 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:21:11 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:21:11 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:21:11 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:21:11 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:21:11 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:21:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:21:11 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:21:11 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:21:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:21:11 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:21:11 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:21:11 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:21:11 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:21:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:21:11 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:21:11 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:21:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:21:11 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:21:11 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:21:11 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:21:11 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:21:11 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:21:11 --> Session Class Initialized
DEBUG - 2016-10-03 17:21:11 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:21:11 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:21:11 --> Session routines successfully run
DEBUG - 2016-10-03 17:21:11 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:21:11 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:21:11 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:21:11 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:21:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:21:11 --> Controller Class Initialized
DEBUG - 2016-10-03 17:21:11 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:21:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:21:11 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:21:11 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:21:11 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:21:11 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:21:11 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:11 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:11 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:11 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:11 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:11 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:21:11 --> Final output sent to browser
DEBUG - 2016-10-03 17:21:11 --> Total execution time: 0.9494
DEBUG - 2016-10-03 17:21:18 --> Config Class Initialized
DEBUG - 2016-10-03 17:21:18 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:21:18 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:21:18 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:21:18 --> URI Class Initialized
DEBUG - 2016-10-03 17:21:18 --> Router Class Initialized
DEBUG - 2016-10-03 17:21:18 --> Output Class Initialized
DEBUG - 2016-10-03 17:21:18 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:21:18 --> Security Class Initialized
DEBUG - 2016-10-03 17:21:18 --> Input Class Initialized
DEBUG - 2016-10-03 17:21:18 --> XSS Filtering completed
DEBUG - 2016-10-03 17:21:18 --> XSS Filtering completed
DEBUG - 2016-10-03 17:21:18 --> XSS Filtering completed
DEBUG - 2016-10-03 17:21:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:21:19 --> Language Class Initialized
DEBUG - 2016-10-03 17:21:19 --> Loader Class Initialized
DEBUG - 2016-10-03 17:21:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:21:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:21:19 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:21:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:21:19 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:21:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:21:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:21:19 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:21:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:21:19 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:21:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:21:19 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:21:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:21:19 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:21:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:21:19 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:21:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:21:19 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:21:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:21:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:21:19 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:21:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:21:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:21:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:21:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:21:19 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:21:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:21:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:21:19 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:21:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:21:19 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:21:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:21:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:21:19 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:21:19 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:21:19 --> Session Class Initialized
DEBUG - 2016-10-03 17:21:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:21:19 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:21:19 --> Session routines successfully run
DEBUG - 2016-10-03 17:21:19 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:21:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:21:19 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:21:19 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:21:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:21:19 --> Controller Class Initialized
DEBUG - 2016-10-03 17:21:19 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:21:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:21:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:21:19 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:21:19 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:21:19 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:21:19 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:19 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:19 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:19 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:19 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:19 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:21:19 --> Final output sent to browser
DEBUG - 2016-10-03 17:21:19 --> Total execution time: 0.9620
DEBUG - 2016-10-03 17:21:34 --> Config Class Initialized
DEBUG - 2016-10-03 17:21:34 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:21:34 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:21:34 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:21:34 --> URI Class Initialized
DEBUG - 2016-10-03 17:21:34 --> Router Class Initialized
DEBUG - 2016-10-03 17:21:34 --> Output Class Initialized
DEBUG - 2016-10-03 17:21:34 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:21:34 --> Security Class Initialized
DEBUG - 2016-10-03 17:21:34 --> Input Class Initialized
DEBUG - 2016-10-03 17:21:34 --> XSS Filtering completed
DEBUG - 2016-10-03 17:21:34 --> XSS Filtering completed
DEBUG - 2016-10-03 17:21:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:21:34 --> Language Class Initialized
DEBUG - 2016-10-03 17:21:34 --> Loader Class Initialized
DEBUG - 2016-10-03 17:21:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:21:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:21:34 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:21:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:21:34 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:21:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:21:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:21:35 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:21:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:21:35 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:21:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:21:35 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:21:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:21:35 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:21:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:21:35 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:21:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:21:35 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:21:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:21:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:21:35 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:21:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:21:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:21:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:21:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:21:35 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:21:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:21:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:21:35 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:21:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:21:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:21:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:21:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:21:35 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:21:35 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:21:35 --> Session Class Initialized
DEBUG - 2016-10-03 17:21:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:21:35 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:21:35 --> Session routines successfully run
DEBUG - 2016-10-03 17:21:35 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:21:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:21:35 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:21:35 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:21:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:21:35 --> Controller Class Initialized
DEBUG - 2016-10-03 17:21:35 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:21:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:21:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:21:35 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:21:35 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:21:35 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:21:35 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:35 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:35 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:35 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:35 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:35 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:35 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:35 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:35 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:21:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/tr_pegawai_profil.php
DEBUG - 2016-10-03 17:21:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/detail.php
DEBUG - 2016-10-03 17:21:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:21:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:21:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:21:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:21:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:21:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:21:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:21:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:21:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:21:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:21:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:21:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:21:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:21:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:21:35 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-10-03 17:21:35 --> Final output sent to browser
DEBUG - 2016-10-03 17:21:35 --> Total execution time: 1.0306
DEBUG - 2016-10-03 17:21:39 --> Config Class Initialized
DEBUG - 2016-10-03 17:21:39 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:21:39 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:21:39 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:21:39 --> URI Class Initialized
DEBUG - 2016-10-03 17:21:39 --> Router Class Initialized
DEBUG - 2016-10-03 17:21:39 --> Output Class Initialized
DEBUG - 2016-10-03 17:21:39 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:21:39 --> Security Class Initialized
DEBUG - 2016-10-03 17:21:39 --> Input Class Initialized
DEBUG - 2016-10-03 17:21:39 --> XSS Filtering completed
DEBUG - 2016-10-03 17:21:39 --> XSS Filtering completed
DEBUG - 2016-10-03 17:21:39 --> XSS Filtering completed
DEBUG - 2016-10-03 17:21:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:21:39 --> Language Class Initialized
DEBUG - 2016-10-03 17:21:39 --> Loader Class Initialized
DEBUG - 2016-10-03 17:21:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:21:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:21:39 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:21:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:21:39 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:21:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:21:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:21:39 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:21:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:21:39 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:21:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:21:39 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:21:39 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:21:39 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:21:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:21:39 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:21:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:21:40 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:21:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:21:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:21:40 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:21:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:21:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:21:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:21:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:21:40 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:21:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:21:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:21:40 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:21:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:21:40 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:21:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:21:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:21:40 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:21:40 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:21:40 --> Session Class Initialized
DEBUG - 2016-10-03 17:21:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:21:40 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:21:40 --> Session routines successfully run
DEBUG - 2016-10-03 17:21:40 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:21:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:21:40 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:21:40 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:21:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:21:40 --> Controller Class Initialized
DEBUG - 2016-10-03 17:21:40 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:21:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:21:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:21:40 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:21:40 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:21:40 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:21:40 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:40 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:40 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:40 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:40 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:21:40 --> Final output sent to browser
DEBUG - 2016-10-03 17:21:40 --> Total execution time: 1.0051
DEBUG - 2016-10-03 17:21:48 --> Config Class Initialized
DEBUG - 2016-10-03 17:21:48 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:21:48 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:21:48 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:21:48 --> URI Class Initialized
DEBUG - 2016-10-03 17:21:48 --> Router Class Initialized
DEBUG - 2016-10-03 17:21:48 --> Output Class Initialized
DEBUG - 2016-10-03 17:21:48 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:21:49 --> Security Class Initialized
DEBUG - 2016-10-03 17:21:49 --> Input Class Initialized
DEBUG - 2016-10-03 17:21:49 --> XSS Filtering completed
DEBUG - 2016-10-03 17:21:49 --> XSS Filtering completed
DEBUG - 2016-10-03 17:21:49 --> XSS Filtering completed
DEBUG - 2016-10-03 17:21:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:21:49 --> Language Class Initialized
DEBUG - 2016-10-03 17:21:49 --> Loader Class Initialized
DEBUG - 2016-10-03 17:21:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:21:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:21:49 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:21:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:21:49 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:21:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:21:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:21:49 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:21:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:21:49 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:21:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:21:49 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:21:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:21:49 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:21:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:21:49 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:21:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:21:49 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:21:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:21:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:21:49 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:21:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:21:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:21:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:21:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:21:49 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:21:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:21:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:21:49 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:21:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:21:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:21:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:21:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:21:49 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:21:49 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:21:49 --> Session Class Initialized
DEBUG - 2016-10-03 17:21:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:21:49 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:21:49 --> Session routines successfully run
DEBUG - 2016-10-03 17:21:49 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:21:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:21:49 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:21:49 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:21:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:21:49 --> Controller Class Initialized
DEBUG - 2016-10-03 17:21:49 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:21:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:21:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:21:49 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:21:49 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:21:49 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:21:49 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:49 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:49 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:49 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:49 --> Model Class Initialized
DEBUG - 2016-10-03 17:21:49 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:21:49 --> Final output sent to browser
DEBUG - 2016-10-03 17:21:49 --> Total execution time: 1.0035
DEBUG - 2016-10-03 17:26:50 --> Config Class Initialized
DEBUG - 2016-10-03 17:26:50 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:26:50 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:26:50 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:26:50 --> URI Class Initialized
DEBUG - 2016-10-03 17:26:50 --> Router Class Initialized
DEBUG - 2016-10-03 17:26:50 --> Output Class Initialized
DEBUG - 2016-10-03 17:26:50 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:26:50 --> Security Class Initialized
DEBUG - 2016-10-03 17:26:50 --> Input Class Initialized
DEBUG - 2016-10-03 17:26:50 --> XSS Filtering completed
DEBUG - 2016-10-03 17:26:50 --> XSS Filtering completed
DEBUG - 2016-10-03 17:26:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:26:50 --> Language Class Initialized
DEBUG - 2016-10-03 17:26:50 --> Loader Class Initialized
DEBUG - 2016-10-03 17:26:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:26:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:26:50 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:26:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:26:50 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:26:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:26:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:26:50 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:26:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:26:50 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:26:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:26:50 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:26:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:26:50 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:26:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:26:50 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:26:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:26:50 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:26:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:26:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:26:51 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:26:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:26:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:26:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:26:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:26:51 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:26:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:26:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:26:51 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:26:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:26:51 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:26:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:26:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:26:51 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:26:51 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:26:51 --> Session Class Initialized
DEBUG - 2016-10-03 17:26:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:26:51 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:26:51 --> Session routines successfully run
DEBUG - 2016-10-03 17:26:51 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:26:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:26:51 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:26:51 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:26:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:26:51 --> Controller Class Initialized
DEBUG - 2016-10-03 17:26:51 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:26:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:26:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:26:51 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:26:51 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:26:51 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:26:51 --> Model Class Initialized
DEBUG - 2016-10-03 17:26:51 --> Model Class Initialized
DEBUG - 2016-10-03 17:26:51 --> Model Class Initialized
DEBUG - 2016-10-03 17:26:51 --> Model Class Initialized
DEBUG - 2016-10-03 17:26:51 --> Model Class Initialized
DEBUG - 2016-10-03 17:26:51 --> Model Class Initialized
DEBUG - 2016-10-03 17:26:51 --> Model Class Initialized
DEBUG - 2016-10-03 17:26:51 --> Model Class Initialized
DEBUG - 2016-10-03 17:26:51 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:26:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/tr_pegawai_profil.php
DEBUG - 2016-10-03 17:26:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/detail.php
DEBUG - 2016-10-03 17:26:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:26:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:26:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:26:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:26:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:26:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:26:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:26:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:26:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:26:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:26:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:26:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:26:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:26:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:26:51 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-10-03 17:26:51 --> Final output sent to browser
DEBUG - 2016-10-03 17:26:51 --> Total execution time: 1.0656
DEBUG - 2016-10-03 17:26:58 --> Config Class Initialized
DEBUG - 2016-10-03 17:26:58 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:26:58 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:26:58 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:26:58 --> URI Class Initialized
DEBUG - 2016-10-03 17:26:58 --> Router Class Initialized
DEBUG - 2016-10-03 17:26:58 --> Output Class Initialized
DEBUG - 2016-10-03 17:26:58 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:26:58 --> Security Class Initialized
DEBUG - 2016-10-03 17:26:58 --> Input Class Initialized
DEBUG - 2016-10-03 17:26:58 --> XSS Filtering completed
DEBUG - 2016-10-03 17:26:58 --> XSS Filtering completed
DEBUG - 2016-10-03 17:26:58 --> XSS Filtering completed
DEBUG - 2016-10-03 17:26:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:26:58 --> Language Class Initialized
DEBUG - 2016-10-03 17:26:58 --> Loader Class Initialized
DEBUG - 2016-10-03 17:26:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:26:58 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:26:58 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:26:58 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:26:58 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:26:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:26:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:26:58 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:26:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:26:58 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:26:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:26:58 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:26:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:26:58 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:26:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:26:58 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:26:58 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:26:58 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:26:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:26:58 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:26:58 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:26:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:26:58 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:26:58 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:26:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:26:58 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:26:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:26:58 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:26:58 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:26:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:26:59 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:26:59 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:26:59 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:26:59 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:26:59 --> Config Class Initialized
DEBUG - 2016-10-03 17:26:59 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:26:59 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:26:59 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:26:59 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:26:59 --> Session Class Initialized
DEBUG - 2016-10-03 17:26:59 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:26:59 --> URI Class Initialized
DEBUG - 2016-10-03 17:26:59 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:26:59 --> Router Class Initialized
DEBUG - 2016-10-03 17:26:59 --> Session routines successfully run
DEBUG - 2016-10-03 17:26:59 --> Output Class Initialized
DEBUG - 2016-10-03 17:26:59 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:26:59 --> Security Class Initialized
DEBUG - 2016-10-03 17:26:59 --> Input Class Initialized
DEBUG - 2016-10-03 17:26:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:26:59 --> XSS Filtering completed
DEBUG - 2016-10-03 17:26:59 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:26:59 --> XSS Filtering completed
DEBUG - 2016-10-03 17:26:59 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:26:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:26:59 --> XSS Filtering completed
DEBUG - 2016-10-03 17:26:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:26:59 --> Controller Class Initialized
DEBUG - 2016-10-03 17:26:59 --> Language Class Initialized
DEBUG - 2016-10-03 17:26:59 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:26:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:26:59 --> Loader Class Initialized
DEBUG - 2016-10-03 17:26:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:26:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:26:59 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:26:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:26:59 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:26:59 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:26:59 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:26:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:26:59 --> Model Class Initialized
DEBUG - 2016-10-03 17:26:59 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:26:59 --> Model Class Initialized
DEBUG - 2016-10-03 17:26:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:26:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:26:59 --> Model Class Initialized
DEBUG - 2016-10-03 17:26:59 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:26:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:26:59 --> Model Class Initialized
DEBUG - 2016-10-03 17:26:59 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:26:59 --> Model Class Initialized
DEBUG - 2016-10-03 17:26:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:26:59 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:26:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:26:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:26:59 --> Final output sent to browser
DEBUG - 2016-10-03 17:26:59 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:26:59 --> Total execution time: 1.0620
DEBUG - 2016-10-03 17:26:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:26:59 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:26:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:26:59 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:26:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:26:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:26:59 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:26:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:26:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:26:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:26:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:26:59 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:26:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:26:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:26:59 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:26:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:26:59 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:26:59 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:26:59 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:26:59 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:26:59 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:26:59 --> Session Class Initialized
DEBUG - 2016-10-03 17:26:59 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:26:59 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:26:59 --> Session routines successfully run
DEBUG - 2016-10-03 17:26:59 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:26:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:26:59 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:26:59 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:26:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:26:59 --> Controller Class Initialized
DEBUG - 2016-10-03 17:26:59 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:26:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:26:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:26:59 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:26:59 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:27:00 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:27:00 --> Model Class Initialized
DEBUG - 2016-10-03 17:27:00 --> Model Class Initialized
DEBUG - 2016-10-03 17:27:00 --> Model Class Initialized
DEBUG - 2016-10-03 17:27:00 --> Model Class Initialized
DEBUG - 2016-10-03 17:27:00 --> Model Class Initialized
DEBUG - 2016-10-03 17:27:00 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:27:00 --> Final output sent to browser
DEBUG - 2016-10-03 17:27:00 --> Total execution time: 1.0629
DEBUG - 2016-10-03 17:27:51 --> Config Class Initialized
DEBUG - 2016-10-03 17:27:51 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:27:51 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:27:51 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:27:51 --> URI Class Initialized
DEBUG - 2016-10-03 17:27:51 --> Router Class Initialized
DEBUG - 2016-10-03 17:27:51 --> Output Class Initialized
DEBUG - 2016-10-03 17:27:51 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:27:51 --> Security Class Initialized
DEBUG - 2016-10-03 17:27:51 --> Input Class Initialized
DEBUG - 2016-10-03 17:27:51 --> XSS Filtering completed
DEBUG - 2016-10-03 17:27:51 --> XSS Filtering completed
DEBUG - 2016-10-03 17:27:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:27:51 --> Language Class Initialized
DEBUG - 2016-10-03 17:27:51 --> Loader Class Initialized
DEBUG - 2016-10-03 17:27:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:27:51 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:27:51 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:27:51 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:27:51 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:27:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:27:51 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:27:51 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:27:51 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:27:51 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:27:51 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:27:51 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:27:51 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:27:51 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:27:51 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:27:51 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:27:51 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:27:51 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:27:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:27:51 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:27:51 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:27:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:27:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:27:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:27:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:27:51 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:27:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:27:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:27:51 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:27:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:27:51 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:27:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:27:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:27:51 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:27:51 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:27:51 --> Session Class Initialized
DEBUG - 2016-10-03 17:27:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:27:51 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:27:51 --> Session routines successfully run
DEBUG - 2016-10-03 17:27:51 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:27:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:27:52 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:27:52 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:27:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:27:52 --> Controller Class Initialized
DEBUG - 2016-10-03 17:27:52 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:27:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:27:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:27:52 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:27:52 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:27:52 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:27:52 --> Model Class Initialized
DEBUG - 2016-10-03 17:27:52 --> Model Class Initialized
DEBUG - 2016-10-03 17:27:52 --> Model Class Initialized
DEBUG - 2016-10-03 17:27:52 --> Model Class Initialized
DEBUG - 2016-10-03 17:27:52 --> Model Class Initialized
DEBUG - 2016-10-03 17:27:52 --> Model Class Initialized
DEBUG - 2016-10-03 17:27:52 --> Model Class Initialized
DEBUG - 2016-10-03 17:27:52 --> Model Class Initialized
DEBUG - 2016-10-03 17:27:52 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:27:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/tr_pegawai_profil.php
DEBUG - 2016-10-03 17:27:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/detail.php
DEBUG - 2016-10-03 17:27:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:27:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:27:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:27:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:27:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:27:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:27:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:27:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:27:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:27:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:27:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:27:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:27:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:27:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:27:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-10-03 17:27:52 --> Final output sent to browser
DEBUG - 2016-10-03 17:27:52 --> Total execution time: 1.1231
DEBUG - 2016-10-03 17:27:57 --> Config Class Initialized
DEBUG - 2016-10-03 17:27:57 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:27:57 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:27:57 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:27:57 --> URI Class Initialized
DEBUG - 2016-10-03 17:27:57 --> Router Class Initialized
DEBUG - 2016-10-03 17:27:57 --> Output Class Initialized
DEBUG - 2016-10-03 17:27:57 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:27:57 --> Security Class Initialized
DEBUG - 2016-10-03 17:27:57 --> Input Class Initialized
DEBUG - 2016-10-03 17:27:57 --> XSS Filtering completed
DEBUG - 2016-10-03 17:27:57 --> XSS Filtering completed
DEBUG - 2016-10-03 17:27:57 --> XSS Filtering completed
DEBUG - 2016-10-03 17:27:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:27:57 --> Language Class Initialized
DEBUG - 2016-10-03 17:27:57 --> Loader Class Initialized
DEBUG - 2016-10-03 17:27:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:27:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:27:57 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:27:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:27:57 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:27:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:27:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:27:57 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:27:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:27:57 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:27:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:27:57 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:27:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:27:57 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:27:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:27:57 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:27:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:27:57 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:27:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:27:57 --> Config Class Initialized
DEBUG - 2016-10-03 17:27:57 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:27:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:27:57 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:27:57 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:27:57 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:27:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:27:57 --> URI Class Initialized
DEBUG - 2016-10-03 17:27:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:27:57 --> Router Class Initialized
DEBUG - 2016-10-03 17:27:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:27:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:27:57 --> Output Class Initialized
DEBUG - 2016-10-03 17:27:57 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:27:57 --> Security Class Initialized
DEBUG - 2016-10-03 17:27:57 --> Input Class Initialized
DEBUG - 2016-10-03 17:27:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:27:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:27:57 --> XSS Filtering completed
DEBUG - 2016-10-03 17:27:57 --> XSS Filtering completed
DEBUG - 2016-10-03 17:27:57 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:27:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:27:57 --> XSS Filtering completed
DEBUG - 2016-10-03 17:27:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:27:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:27:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:27:57 --> Language Class Initialized
DEBUG - 2016-10-03 17:27:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:27:57 --> Loader Class Initialized
DEBUG - 2016-10-03 17:27:57 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:27:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:27:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:27:57 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:27:57 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:27:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:27:57 --> Session Class Initialized
DEBUG - 2016-10-03 17:27:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:27:57 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:27:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:27:57 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:27:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:27:57 --> Session routines successfully run
DEBUG - 2016-10-03 17:27:57 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:27:57 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:27:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:27:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:27:57 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:27:57 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:27:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:27:58 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:27:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:27:58 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:27:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:27:58 --> Controller Class Initialized
DEBUG - 2016-10-03 17:27:58 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:27:58 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:27:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:27:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:27:58 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:27:58 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:27:58 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:27:58 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:27:58 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:27:58 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:27:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:27:58 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:27:58 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:27:58 --> Model Class Initialized
DEBUG - 2016-10-03 17:27:58 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:27:58 --> Model Class Initialized
DEBUG - 2016-10-03 17:27:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:27:58 --> Model Class Initialized
DEBUG - 2016-10-03 17:27:58 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:27:58 --> Model Class Initialized
DEBUG - 2016-10-03 17:27:58 --> Model Class Initialized
DEBUG - 2016-10-03 17:27:58 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:27:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:27:58 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:27:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:27:58 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:27:58 --> Final output sent to browser
DEBUG - 2016-10-03 17:27:58 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:27:58 --> Total execution time: 1.0871
DEBUG - 2016-10-03 17:27:58 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:27:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:27:58 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:27:58 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:27:58 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:27:58 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:27:58 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:27:58 --> Session Class Initialized
DEBUG - 2016-10-03 17:27:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:27:58 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:27:58 --> Session routines successfully run
DEBUG - 2016-10-03 17:27:58 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:27:58 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:27:58 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:27:58 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:27:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:27:58 --> Controller Class Initialized
DEBUG - 2016-10-03 17:27:58 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:27:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:27:58 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:27:58 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:27:58 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:27:58 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:27:58 --> Model Class Initialized
DEBUG - 2016-10-03 17:27:58 --> Model Class Initialized
DEBUG - 2016-10-03 17:27:58 --> Model Class Initialized
DEBUG - 2016-10-03 17:27:58 --> Model Class Initialized
DEBUG - 2016-10-03 17:27:58 --> Model Class Initialized
DEBUG - 2016-10-03 17:27:58 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:27:58 --> Final output sent to browser
DEBUG - 2016-10-03 17:27:58 --> Total execution time: 1.1226
DEBUG - 2016-10-03 17:29:29 --> Config Class Initialized
DEBUG - 2016-10-03 17:29:29 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:29:29 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:29:29 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:29:29 --> URI Class Initialized
DEBUG - 2016-10-03 17:29:30 --> Router Class Initialized
DEBUG - 2016-10-03 17:29:30 --> Output Class Initialized
DEBUG - 2016-10-03 17:29:30 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:29:30 --> Security Class Initialized
DEBUG - 2016-10-03 17:29:30 --> Input Class Initialized
DEBUG - 2016-10-03 17:29:30 --> XSS Filtering completed
DEBUG - 2016-10-03 17:29:30 --> XSS Filtering completed
DEBUG - 2016-10-03 17:29:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:29:30 --> Language Class Initialized
DEBUG - 2016-10-03 17:29:30 --> Loader Class Initialized
DEBUG - 2016-10-03 17:29:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:29:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:29:30 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:29:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:29:30 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:29:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:29:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:29:30 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:29:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:29:30 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:29:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:29:30 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:29:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:29:30 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:29:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:29:30 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:29:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:29:30 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:29:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:29:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:29:30 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:29:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:29:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:29:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:29:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:29:30 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:29:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:29:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:29:30 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:29:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:29:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:29:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:29:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:29:30 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:29:30 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:29:30 --> Session Class Initialized
DEBUG - 2016-10-03 17:29:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:29:30 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:29:30 --> Session routines successfully run
DEBUG - 2016-10-03 17:29:30 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:29:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:29:30 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:29:30 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:29:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:29:30 --> Controller Class Initialized
DEBUG - 2016-10-03 17:29:30 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:29:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:29:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:29:30 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:29:30 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:29:30 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:29:30 --> Model Class Initialized
DEBUG - 2016-10-03 17:29:30 --> Model Class Initialized
DEBUG - 2016-10-03 17:29:30 --> Model Class Initialized
DEBUG - 2016-10-03 17:29:31 --> Model Class Initialized
DEBUG - 2016-10-03 17:29:31 --> Model Class Initialized
DEBUG - 2016-10-03 17:29:31 --> Model Class Initialized
DEBUG - 2016-10-03 17:29:31 --> Model Class Initialized
DEBUG - 2016-10-03 17:29:31 --> Model Class Initialized
DEBUG - 2016-10-03 17:29:31 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:29:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/tr_pegawai_profil.php
DEBUG - 2016-10-03 17:29:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/detail.php
DEBUG - 2016-10-03 17:29:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:29:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:29:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:29:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:29:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:29:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:29:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:29:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:29:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:29:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:29:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:29:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:29:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:29:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:29:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-10-03 17:29:31 --> Final output sent to browser
DEBUG - 2016-10-03 17:29:31 --> Total execution time: 1.1633
DEBUG - 2016-10-03 17:29:34 --> Config Class Initialized
DEBUG - 2016-10-03 17:29:34 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:29:35 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:29:35 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:29:35 --> URI Class Initialized
DEBUG - 2016-10-03 17:29:35 --> Router Class Initialized
DEBUG - 2016-10-03 17:29:35 --> Output Class Initialized
DEBUG - 2016-10-03 17:29:35 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:29:35 --> Security Class Initialized
DEBUG - 2016-10-03 17:29:35 --> Input Class Initialized
DEBUG - 2016-10-03 17:29:35 --> XSS Filtering completed
DEBUG - 2016-10-03 17:29:35 --> XSS Filtering completed
DEBUG - 2016-10-03 17:29:35 --> XSS Filtering completed
DEBUG - 2016-10-03 17:29:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:29:35 --> Language Class Initialized
DEBUG - 2016-10-03 17:29:35 --> Loader Class Initialized
DEBUG - 2016-10-03 17:29:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:29:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:29:35 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:29:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:29:35 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:29:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:29:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:29:35 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:29:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:29:35 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:29:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:29:35 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:29:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:29:35 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:29:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:29:35 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:29:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:29:35 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:29:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:29:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:29:35 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:29:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:29:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:29:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:29:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:29:35 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:29:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:29:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:29:35 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:29:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:29:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:29:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:29:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:29:35 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:29:35 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:29:35 --> Session Class Initialized
DEBUG - 2016-10-03 17:29:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:29:35 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:29:35 --> Session routines successfully run
DEBUG - 2016-10-03 17:29:35 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:29:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:29:35 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:29:35 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:29:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:29:35 --> Controller Class Initialized
DEBUG - 2016-10-03 17:29:35 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:29:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:29:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:29:35 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:29:36 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:29:36 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:29:36 --> Model Class Initialized
DEBUG - 2016-10-03 17:29:36 --> Model Class Initialized
DEBUG - 2016-10-03 17:29:36 --> Model Class Initialized
DEBUG - 2016-10-03 17:29:36 --> Model Class Initialized
DEBUG - 2016-10-03 17:29:36 --> Model Class Initialized
DEBUG - 2016-10-03 17:29:36 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:29:36 --> Final output sent to browser
DEBUG - 2016-10-03 17:29:36 --> Total execution time: 1.1705
DEBUG - 2016-10-03 17:32:19 --> Config Class Initialized
DEBUG - 2016-10-03 17:32:19 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:32:19 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:32:19 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:32:19 --> URI Class Initialized
DEBUG - 2016-10-03 17:32:19 --> Router Class Initialized
DEBUG - 2016-10-03 17:32:19 --> Output Class Initialized
DEBUG - 2016-10-03 17:32:19 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:32:19 --> Security Class Initialized
DEBUG - 2016-10-03 17:32:19 --> Input Class Initialized
DEBUG - 2016-10-03 17:32:19 --> XSS Filtering completed
DEBUG - 2016-10-03 17:32:19 --> XSS Filtering completed
DEBUG - 2016-10-03 17:32:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:32:19 --> Language Class Initialized
DEBUG - 2016-10-03 17:32:19 --> Loader Class Initialized
DEBUG - 2016-10-03 17:32:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:32:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:32:19 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:32:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:32:19 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:32:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:32:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:32:19 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:32:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:32:19 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:32:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:32:19 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:32:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:32:19 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:32:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:32:19 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:32:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:32:19 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:32:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:32:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:32:19 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:32:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:32:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:32:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:32:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:32:19 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:32:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:32:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:32:19 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:32:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:32:19 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:32:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:32:20 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:32:20 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:32:20 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:32:20 --> Session Class Initialized
DEBUG - 2016-10-03 17:32:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:32:20 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:32:20 --> Session routines successfully run
DEBUG - 2016-10-03 17:32:20 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:32:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:32:20 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:32:20 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:32:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:32:20 --> Controller Class Initialized
DEBUG - 2016-10-03 17:32:20 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:32:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:32:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:32:20 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:32:20 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:32:20 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:32:20 --> Model Class Initialized
DEBUG - 2016-10-03 17:32:20 --> Model Class Initialized
DEBUG - 2016-10-03 17:32:20 --> Model Class Initialized
DEBUG - 2016-10-03 17:32:20 --> Model Class Initialized
DEBUG - 2016-10-03 17:32:20 --> Model Class Initialized
DEBUG - 2016-10-03 17:32:20 --> Model Class Initialized
DEBUG - 2016-10-03 17:32:20 --> Model Class Initialized
DEBUG - 2016-10-03 17:32:20 --> Model Class Initialized
DEBUG - 2016-10-03 17:32:20 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:32:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/tr_pegawai_profil.php
DEBUG - 2016-10-03 17:32:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/detail.php
DEBUG - 2016-10-03 17:32:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:32:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:32:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:32:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:32:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:32:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:32:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:32:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:32:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:32:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:32:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:32:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:32:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:32:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:32:20 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-10-03 17:32:20 --> Final output sent to browser
DEBUG - 2016-10-03 17:32:20 --> Total execution time: 1.1969
DEBUG - 2016-10-03 17:32:25 --> Config Class Initialized
DEBUG - 2016-10-03 17:32:25 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:32:25 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:32:25 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:32:25 --> URI Class Initialized
DEBUG - 2016-10-03 17:32:25 --> Router Class Initialized
DEBUG - 2016-10-03 17:32:25 --> Output Class Initialized
DEBUG - 2016-10-03 17:32:25 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:32:25 --> Security Class Initialized
DEBUG - 2016-10-03 17:32:25 --> Input Class Initialized
DEBUG - 2016-10-03 17:32:25 --> XSS Filtering completed
DEBUG - 2016-10-03 17:32:25 --> XSS Filtering completed
DEBUG - 2016-10-03 17:32:25 --> XSS Filtering completed
DEBUG - 2016-10-03 17:32:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:32:25 --> Language Class Initialized
DEBUG - 2016-10-03 17:32:25 --> Loader Class Initialized
DEBUG - 2016-10-03 17:32:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:32:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:32:25 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:32:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:32:25 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:32:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:32:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:32:25 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:32:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:32:25 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:32:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:32:25 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:32:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:32:25 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:32:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:32:25 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:32:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:32:25 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:32:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:32:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:32:25 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:32:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:32:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:32:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:32:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:32:25 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:32:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:32:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:32:25 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:32:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:32:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:32:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:32:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:32:26 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:32:26 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:32:26 --> Session Class Initialized
DEBUG - 2016-10-03 17:32:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:32:26 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:32:26 --> Session routines successfully run
DEBUG - 2016-10-03 17:32:26 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:32:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:32:26 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:32:26 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:32:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:32:26 --> Controller Class Initialized
DEBUG - 2016-10-03 17:32:26 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:32:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:32:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:32:26 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:32:26 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:32:26 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:32:26 --> Model Class Initialized
DEBUG - 2016-10-03 17:32:26 --> Model Class Initialized
DEBUG - 2016-10-03 17:32:26 --> Model Class Initialized
DEBUG - 2016-10-03 17:32:26 --> Model Class Initialized
DEBUG - 2016-10-03 17:32:26 --> Model Class Initialized
DEBUG - 2016-10-03 17:32:26 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:32:26 --> Final output sent to browser
DEBUG - 2016-10-03 17:32:26 --> Total execution time: 1.1719
DEBUG - 2016-10-03 17:39:35 --> Config Class Initialized
DEBUG - 2016-10-03 17:39:35 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:39:35 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:39:35 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:39:35 --> URI Class Initialized
DEBUG - 2016-10-03 17:39:35 --> Router Class Initialized
DEBUG - 2016-10-03 17:39:35 --> Output Class Initialized
DEBUG - 2016-10-03 17:39:35 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:39:35 --> Security Class Initialized
DEBUG - 2016-10-03 17:39:35 --> Input Class Initialized
DEBUG - 2016-10-03 17:39:35 --> XSS Filtering completed
DEBUG - 2016-10-03 17:39:35 --> XSS Filtering completed
DEBUG - 2016-10-03 17:39:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:39:35 --> Language Class Initialized
DEBUG - 2016-10-03 17:39:35 --> Loader Class Initialized
DEBUG - 2016-10-03 17:39:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:39:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:39:35 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:39:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:39:35 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:39:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:39:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:39:35 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:39:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:39:35 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:39:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:39:35 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:39:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:39:35 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:39:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:39:35 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:39:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:39:35 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:39:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:39:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:39:35 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:39:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:39:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:39:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:39:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:39:35 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:39:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:39:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:39:35 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:39:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:39:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:39:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:39:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:39:35 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:39:35 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:39:36 --> Session Class Initialized
DEBUG - 2016-10-03 17:39:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:39:36 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:39:36 --> Session routines successfully run
DEBUG - 2016-10-03 17:39:36 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:39:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:39:36 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:39:36 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:39:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:39:36 --> Controller Class Initialized
DEBUG - 2016-10-03 17:39:36 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:39:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:39:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:39:36 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:39:36 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:39:36 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:39:36 --> Model Class Initialized
DEBUG - 2016-10-03 17:39:36 --> Model Class Initialized
DEBUG - 2016-10-03 17:39:36 --> Model Class Initialized
DEBUG - 2016-10-03 17:39:36 --> Model Class Initialized
DEBUG - 2016-10-03 17:39:36 --> Model Class Initialized
DEBUG - 2016-10-03 17:39:36 --> Model Class Initialized
DEBUG - 2016-10-03 17:39:36 --> Model Class Initialized
DEBUG - 2016-10-03 17:39:36 --> Model Class Initialized
DEBUG - 2016-10-03 17:39:36 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/tr_pegawai_profil.php
DEBUG - 2016-10-03 17:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/detail.php
DEBUG - 2016-10-03 17:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:39:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:39:36 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-10-03 17:39:36 --> Final output sent to browser
DEBUG - 2016-10-03 17:39:36 --> Total execution time: 1.2181
DEBUG - 2016-10-03 17:39:46 --> Config Class Initialized
DEBUG - 2016-10-03 17:39:46 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:39:46 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:39:46 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:39:46 --> URI Class Initialized
DEBUG - 2016-10-03 17:39:46 --> Router Class Initialized
DEBUG - 2016-10-03 17:39:46 --> Output Class Initialized
DEBUG - 2016-10-03 17:39:46 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:39:46 --> Security Class Initialized
DEBUG - 2016-10-03 17:39:46 --> Input Class Initialized
DEBUG - 2016-10-03 17:39:46 --> XSS Filtering completed
DEBUG - 2016-10-03 17:39:46 --> XSS Filtering completed
DEBUG - 2016-10-03 17:39:46 --> XSS Filtering completed
DEBUG - 2016-10-03 17:39:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:39:46 --> Language Class Initialized
DEBUG - 2016-10-03 17:39:46 --> Loader Class Initialized
DEBUG - 2016-10-03 17:39:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:39:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:39:46 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:39:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:39:46 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:39:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:39:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:39:46 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:39:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:39:46 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:39:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:39:46 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:39:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:39:46 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:39:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:39:46 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:39:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:39:46 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:39:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:39:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:39:46 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:39:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:39:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:39:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:39:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:39:46 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:39:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:39:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:39:46 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:39:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:39:46 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:39:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:39:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:39:46 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:39:46 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:39:46 --> Session Class Initialized
DEBUG - 2016-10-03 17:39:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:39:46 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:39:46 --> Session routines successfully run
DEBUG - 2016-10-03 17:39:47 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:39:47 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:39:47 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:39:47 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:39:47 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:39:47 --> Controller Class Initialized
DEBUG - 2016-10-03 17:39:47 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:39:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:39:47 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:39:47 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:39:47 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:39:47 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:39:47 --> Model Class Initialized
DEBUG - 2016-10-03 17:39:47 --> Model Class Initialized
DEBUG - 2016-10-03 17:39:47 --> Model Class Initialized
DEBUG - 2016-10-03 17:39:47 --> Model Class Initialized
DEBUG - 2016-10-03 17:39:47 --> Model Class Initialized
DEBUG - 2016-10-03 17:39:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:39:47 --> Final output sent to browser
DEBUG - 2016-10-03 17:39:47 --> Total execution time: 1.2111
DEBUG - 2016-10-03 17:40:12 --> Config Class Initialized
DEBUG - 2016-10-03 17:40:12 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:40:12 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:40:12 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:40:12 --> URI Class Initialized
DEBUG - 2016-10-03 17:40:12 --> Router Class Initialized
DEBUG - 2016-10-03 17:40:12 --> Output Class Initialized
DEBUG - 2016-10-03 17:40:12 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:40:12 --> Security Class Initialized
DEBUG - 2016-10-03 17:40:12 --> Input Class Initialized
DEBUG - 2016-10-03 17:40:12 --> XSS Filtering completed
DEBUG - 2016-10-03 17:40:12 --> XSS Filtering completed
DEBUG - 2016-10-03 17:40:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:40:12 --> Language Class Initialized
DEBUG - 2016-10-03 17:40:12 --> Loader Class Initialized
DEBUG - 2016-10-03 17:40:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:40:12 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:40:12 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:40:12 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:40:12 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:40:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:40:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:40:12 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:40:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:40:12 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:40:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:40:12 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:40:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:40:12 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:40:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:40:12 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:40:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:40:12 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:40:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:40:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:40:12 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:40:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:40:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:40:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:40:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:40:12 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:40:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:40:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:40:12 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:40:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:40:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:40:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:40:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:40:12 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:40:12 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:40:12 --> Session Class Initialized
DEBUG - 2016-10-03 17:40:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:40:12 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:40:13 --> Session routines successfully run
DEBUG - 2016-10-03 17:40:13 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:40:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:40:13 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:40:13 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:40:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:40:13 --> Controller Class Initialized
DEBUG - 2016-10-03 17:40:13 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:40:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:40:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:40:13 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:40:13 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:40:13 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:40:13 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:13 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:13 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:13 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:13 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:13 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:13 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:13 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:13 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:40:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/tr_pegawai_profil.php
DEBUG - 2016-10-03 17:40:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/detail.php
DEBUG - 2016-10-03 17:40:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:40:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:40:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:40:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:40:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:40:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:40:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:40:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:40:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:40:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:40:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:40:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:40:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:40:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:40:13 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-10-03 17:40:13 --> Final output sent to browser
DEBUG - 2016-10-03 17:40:13 --> Total execution time: 1.2543
DEBUG - 2016-10-03 17:40:17 --> Config Class Initialized
DEBUG - 2016-10-03 17:40:17 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:40:17 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:40:17 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:40:17 --> URI Class Initialized
DEBUG - 2016-10-03 17:40:17 --> Router Class Initialized
DEBUG - 2016-10-03 17:40:17 --> Output Class Initialized
DEBUG - 2016-10-03 17:40:17 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:40:17 --> Security Class Initialized
DEBUG - 2016-10-03 17:40:17 --> Input Class Initialized
DEBUG - 2016-10-03 17:40:17 --> XSS Filtering completed
DEBUG - 2016-10-03 17:40:18 --> XSS Filtering completed
DEBUG - 2016-10-03 17:40:18 --> XSS Filtering completed
DEBUG - 2016-10-03 17:40:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:40:18 --> Language Class Initialized
DEBUG - 2016-10-03 17:40:18 --> Loader Class Initialized
DEBUG - 2016-10-03 17:40:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:40:18 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:40:18 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:40:18 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:40:18 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:40:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:40:18 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:40:18 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:40:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:40:18 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:40:18 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:40:18 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:40:18 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:40:18 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:40:18 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:40:18 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:40:18 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:40:18 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:40:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:40:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:40:18 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:40:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:40:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:40:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:40:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:40:18 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:40:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:40:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:40:18 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:40:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:40:18 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:40:18 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:40:18 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:40:18 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:40:18 --> Config Class Initialized
DEBUG - 2016-10-03 17:40:18 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:40:18 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:40:18 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:40:18 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:40:18 --> Session Class Initialized
DEBUG - 2016-10-03 17:40:18 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:40:18 --> URI Class Initialized
DEBUG - 2016-10-03 17:40:18 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:40:18 --> Router Class Initialized
DEBUG - 2016-10-03 17:40:18 --> Session routines successfully run
DEBUG - 2016-10-03 17:40:18 --> Output Class Initialized
DEBUG - 2016-10-03 17:40:18 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:40:18 --> Security Class Initialized
DEBUG - 2016-10-03 17:40:18 --> Input Class Initialized
DEBUG - 2016-10-03 17:40:18 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:40:18 --> XSS Filtering completed
DEBUG - 2016-10-03 17:40:18 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:40:18 --> XSS Filtering completed
DEBUG - 2016-10-03 17:40:18 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:40:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:40:18 --> XSS Filtering completed
DEBUG - 2016-10-03 17:40:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:40:18 --> Controller Class Initialized
DEBUG - 2016-10-03 17:40:18 --> Language Class Initialized
DEBUG - 2016-10-03 17:40:18 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:40:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:40:18 --> Loader Class Initialized
DEBUG - 2016-10-03 17:40:18 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:40:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:40:18 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:40:18 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:40:18 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:40:18 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:40:18 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:40:18 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:40:18 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:40:18 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:40:18 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:18 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:40:18 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:18 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:40:18 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:40:19 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:19 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:40:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:40:19 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:40:19 --> Config Class Initialized
DEBUG - 2016-10-03 17:40:19 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:40:19 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:40:19 --> Final output sent to browser
DEBUG - 2016-10-03 17:40:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:40:19 --> Total execution time: 1.2196
DEBUG - 2016-10-03 17:40:19 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:40:19 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:40:19 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:40:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:40:19 --> URI Class Initialized
DEBUG - 2016-10-03 17:40:19 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:40:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:40:19 --> Router Class Initialized
DEBUG - 2016-10-03 17:40:19 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:40:19 --> Output Class Initialized
DEBUG - 2016-10-03 17:40:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:40:19 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:40:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:40:19 --> Security Class Initialized
DEBUG - 2016-10-03 17:40:19 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:40:19 --> Input Class Initialized
DEBUG - 2016-10-03 17:40:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:40:19 --> XSS Filtering completed
DEBUG - 2016-10-03 17:40:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:40:19 --> XSS Filtering completed
DEBUG - 2016-10-03 17:40:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:40:19 --> XSS Filtering completed
DEBUG - 2016-10-03 17:40:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:40:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:40:19 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:40:19 --> Language Class Initialized
DEBUG - 2016-10-03 17:40:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:40:19 --> Loader Class Initialized
DEBUG - 2016-10-03 17:40:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:40:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:40:19 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:40:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:40:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:40:19 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:40:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:40:19 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:40:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:40:19 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:40:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:40:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:40:19 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:40:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:40:19 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:40:19 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:40:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:40:19 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:40:19 --> Session Class Initialized
DEBUG - 2016-10-03 17:40:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:40:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:40:19 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:40:19 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:40:19 --> Session routines successfully run
DEBUG - 2016-10-03 17:40:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:40:19 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:40:19 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:40:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:40:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:40:19 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:40:19 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:40:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:40:19 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:40:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:40:19 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:40:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:40:19 --> Controller Class Initialized
DEBUG - 2016-10-03 17:40:19 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:40:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:40:19 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:40:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:40:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:40:19 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:40:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:40:19 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:40:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:40:19 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:40:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:40:19 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:40:19 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:40:19 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:19 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:40:19 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:40:19 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:40:19 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:40:19 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:19 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:40:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:40:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:40:19 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:40:19 --> Final output sent to browser
DEBUG - 2016-10-03 17:40:19 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:40:19 --> Total execution time: 1.2486
DEBUG - 2016-10-03 17:40:19 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:40:19 --> Session Class Initialized
DEBUG - 2016-10-03 17:40:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:40:19 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:40:20 --> Session routines successfully run
DEBUG - 2016-10-03 17:40:20 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:40:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:40:20 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:40:20 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:40:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:40:20 --> Controller Class Initialized
DEBUG - 2016-10-03 17:40:20 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:40:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:40:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:40:20 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:40:20 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:40:20 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:40:20 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:20 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:20 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:20 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:20 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:20 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:40:20 --> Final output sent to browser
DEBUG - 2016-10-03 17:40:20 --> Total execution time: 1.2864
DEBUG - 2016-10-03 17:40:34 --> Config Class Initialized
DEBUG - 2016-10-03 17:40:34 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:40:34 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:40:34 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:40:34 --> URI Class Initialized
DEBUG - 2016-10-03 17:40:34 --> Router Class Initialized
DEBUG - 2016-10-03 17:40:34 --> Output Class Initialized
DEBUG - 2016-10-03 17:40:34 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:40:34 --> Security Class Initialized
DEBUG - 2016-10-03 17:40:34 --> Input Class Initialized
DEBUG - 2016-10-03 17:40:34 --> XSS Filtering completed
DEBUG - 2016-10-03 17:40:34 --> XSS Filtering completed
DEBUG - 2016-10-03 17:40:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:40:34 --> Language Class Initialized
DEBUG - 2016-10-03 17:40:34 --> Loader Class Initialized
DEBUG - 2016-10-03 17:40:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:40:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:40:34 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:40:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:40:34 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:40:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:40:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:40:34 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:40:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:40:34 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:40:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:40:34 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:40:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:40:34 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:40:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:40:34 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:40:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:40:34 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:40:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:40:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:40:34 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:40:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:40:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:40:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:40:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:40:35 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:40:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:40:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:40:35 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:40:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:40:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:40:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:40:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:40:35 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:40:35 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:40:35 --> Session Class Initialized
DEBUG - 2016-10-03 17:40:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:40:35 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:40:35 --> Session routines successfully run
DEBUG - 2016-10-03 17:40:35 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:40:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:40:35 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:40:35 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:40:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:40:35 --> Controller Class Initialized
DEBUG - 2016-10-03 17:40:35 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:40:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:40:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:40:35 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:40:35 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:40:35 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:40:35 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:35 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:35 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:35 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:35 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:35 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:35 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:35 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:35 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:40:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/tr_pegawai_profil.php
DEBUG - 2016-10-03 17:40:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/detail.php
DEBUG - 2016-10-03 17:40:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:40:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:40:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:40:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:40:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:40:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:40:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:40:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:40:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:40:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:40:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:40:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:40:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:40:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:40:35 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-10-03 17:40:35 --> Final output sent to browser
DEBUG - 2016-10-03 17:40:36 --> Total execution time: 1.3081
DEBUG - 2016-10-03 17:40:43 --> Config Class Initialized
DEBUG - 2016-10-03 17:40:43 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:40:43 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:40:43 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:40:43 --> URI Class Initialized
DEBUG - 2016-10-03 17:40:43 --> Router Class Initialized
DEBUG - 2016-10-03 17:40:43 --> Output Class Initialized
DEBUG - 2016-10-03 17:40:43 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:40:43 --> Security Class Initialized
DEBUG - 2016-10-03 17:40:43 --> Input Class Initialized
DEBUG - 2016-10-03 17:40:43 --> XSS Filtering completed
DEBUG - 2016-10-03 17:40:43 --> XSS Filtering completed
DEBUG - 2016-10-03 17:40:43 --> XSS Filtering completed
DEBUG - 2016-10-03 17:40:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:40:43 --> Language Class Initialized
DEBUG - 2016-10-03 17:40:43 --> Loader Class Initialized
DEBUG - 2016-10-03 17:40:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:40:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:40:43 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:40:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:40:43 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:40:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:40:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:40:43 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:40:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:40:43 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:40:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:40:43 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:40:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:40:43 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:40:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:40:44 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:40:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:40:44 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:40:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:40:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:40:44 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:40:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:40:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:40:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:40:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:40:44 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:40:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:40:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:40:44 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:40:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:40:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:40:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:40:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:40:44 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:40:44 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:40:44 --> Session Class Initialized
DEBUG - 2016-10-03 17:40:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:40:44 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:40:44 --> Session routines successfully run
DEBUG - 2016-10-03 17:40:44 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:40:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:40:44 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:40:44 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:40:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:40:44 --> Controller Class Initialized
DEBUG - 2016-10-03 17:40:44 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:40:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:40:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:40:44 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:40:44 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:40:44 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:40:44 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:44 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:44 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:44 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:44 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:44 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:40:44 --> Final output sent to browser
DEBUG - 2016-10-03 17:40:44 --> Total execution time: 1.2904
DEBUG - 2016-10-03 17:40:48 --> Config Class Initialized
DEBUG - 2016-10-03 17:40:48 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:40:48 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:40:48 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:40:48 --> URI Class Initialized
DEBUG - 2016-10-03 17:40:48 --> Router Class Initialized
DEBUG - 2016-10-03 17:40:48 --> Output Class Initialized
DEBUG - 2016-10-03 17:40:48 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:40:49 --> Security Class Initialized
DEBUG - 2016-10-03 17:40:49 --> Input Class Initialized
DEBUG - 2016-10-03 17:40:49 --> XSS Filtering completed
DEBUG - 2016-10-03 17:40:49 --> XSS Filtering completed
DEBUG - 2016-10-03 17:40:49 --> XSS Filtering completed
DEBUG - 2016-10-03 17:40:49 --> XSS Filtering completed
DEBUG - 2016-10-03 17:40:49 --> XSS Filtering completed
DEBUG - 2016-10-03 17:40:49 --> XSS Filtering completed
DEBUG - 2016-10-03 17:40:49 --> XSS Filtering completed
DEBUG - 2016-10-03 17:40:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:40:49 --> Language Class Initialized
DEBUG - 2016-10-03 17:40:49 --> Loader Class Initialized
DEBUG - 2016-10-03 17:40:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:40:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:40:49 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:40:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:40:49 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:40:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:40:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:40:49 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:40:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:40:49 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:40:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:40:49 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:40:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:40:49 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:40:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:40:49 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:40:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:40:49 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:40:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:40:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:40:49 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:40:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:40:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:40:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:40:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:40:49 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:40:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:40:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:40:49 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:40:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:40:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:40:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:40:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:40:49 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:40:49 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:40:49 --> Session Class Initialized
DEBUG - 2016-10-03 17:40:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:40:49 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:40:49 --> Session routines successfully run
DEBUG - 2016-10-03 17:40:49 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:40:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:40:49 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:40:49 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:40:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:40:50 --> Controller Class Initialized
DEBUG - 2016-10-03 17:40:50 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:40:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:40:50 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:40:50 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:40:50 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:40:50 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:40:50 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:50 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:50 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:50 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:50 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:50 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:50 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:50 --> Model Class Initialized
DEBUG - 2016-10-03 17:40:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-10-03 17:40:50 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:40:50 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:40:50 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-10-03 17:40:50 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:40:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/tr_pegawai_profil.php
DEBUG - 2016-10-03 17:40:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/detail.php
DEBUG - 2016-10-03 17:40:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:40:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:40:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:40:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:40:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:40:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:40:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:40:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:40:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:40:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:40:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:40:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_bone/member/atlant/js/tr_pegawai_profil_js.php
DEBUG - 2016-10-03 17:40:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:40:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:40:50 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/39ecaa4b0a9be5faae91e6e9cbfcffd2
DEBUG - 2016-10-03 17:40:50 --> Final output sent to browser
DEBUG - 2016-10-03 17:40:50 --> Total execution time: 1.5162
DEBUG - 2016-10-03 17:41:15 --> Config Class Initialized
DEBUG - 2016-10-03 17:41:15 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:41:15 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:41:15 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:41:15 --> URI Class Initialized
DEBUG - 2016-10-03 17:41:15 --> Router Class Initialized
DEBUG - 2016-10-03 17:41:15 --> Output Class Initialized
DEBUG - 2016-10-03 17:41:15 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:41:15 --> Security Class Initialized
DEBUG - 2016-10-03 17:41:15 --> Input Class Initialized
DEBUG - 2016-10-03 17:41:15 --> XSS Filtering completed
DEBUG - 2016-10-03 17:41:15 --> XSS Filtering completed
DEBUG - 2016-10-03 17:41:15 --> XSS Filtering completed
DEBUG - 2016-10-03 17:41:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:41:15 --> Language Class Initialized
DEBUG - 2016-10-03 17:41:15 --> Loader Class Initialized
DEBUG - 2016-10-03 17:41:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:41:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:41:15 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:41:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:41:15 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:41:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:41:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:41:15 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:41:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:41:15 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:41:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:41:15 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:41:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:41:16 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:41:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:41:16 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:41:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:41:16 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:41:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:41:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:41:16 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:41:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:41:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:41:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:41:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:41:16 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:41:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:41:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:41:16 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:41:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:41:16 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:41:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:41:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:41:16 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:41:16 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:41:16 --> Session Class Initialized
DEBUG - 2016-10-03 17:41:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:41:16 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:41:16 --> Session routines successfully run
DEBUG - 2016-10-03 17:41:16 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:41:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:41:16 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:41:16 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:41:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:41:16 --> Controller Class Initialized
DEBUG - 2016-10-03 17:41:16 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:41:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:41:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:41:16 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:41:16 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:41:16 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:41:16 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:16 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:16 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:16 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:16 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:16 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/d60a4276e1f97a4caf0f67ea68fc1298
DEBUG - 2016-10-03 17:41:16 --> Final output sent to browser
DEBUG - 2016-10-03 17:41:16 --> Total execution time: 1.3152
DEBUG - 2016-10-03 17:41:19 --> Config Class Initialized
DEBUG - 2016-10-03 17:41:19 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:41:19 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:41:19 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:41:19 --> URI Class Initialized
DEBUG - 2016-10-03 17:41:19 --> Router Class Initialized
DEBUG - 2016-10-03 17:41:19 --> Output Class Initialized
DEBUG - 2016-10-03 17:41:19 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:41:19 --> Security Class Initialized
DEBUG - 2016-10-03 17:41:19 --> Input Class Initialized
DEBUG - 2016-10-03 17:41:19 --> XSS Filtering completed
DEBUG - 2016-10-03 17:41:19 --> XSS Filtering completed
DEBUG - 2016-10-03 17:41:19 --> XSS Filtering completed
DEBUG - 2016-10-03 17:41:19 --> XSS Filtering completed
DEBUG - 2016-10-03 17:41:19 --> XSS Filtering completed
DEBUG - 2016-10-03 17:41:19 --> XSS Filtering completed
DEBUG - 2016-10-03 17:41:19 --> XSS Filtering completed
DEBUG - 2016-10-03 17:41:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:41:19 --> Language Class Initialized
DEBUG - 2016-10-03 17:41:19 --> Loader Class Initialized
DEBUG - 2016-10-03 17:41:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:41:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:41:19 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:41:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:41:19 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:41:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:41:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:41:19 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:41:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:41:19 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:41:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:41:19 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:41:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:41:20 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:41:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:41:20 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:41:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:41:20 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:41:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:41:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:41:20 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:41:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:41:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:41:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:41:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:41:20 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:41:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:41:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:41:20 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:41:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:41:20 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:41:20 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:41:20 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:41:20 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:41:20 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:41:20 --> Session Class Initialized
DEBUG - 2016-10-03 17:41:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:41:20 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:41:20 --> Session routines successfully run
DEBUG - 2016-10-03 17:41:20 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:41:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:41:20 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:41:20 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:41:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:41:20 --> Controller Class Initialized
DEBUG - 2016-10-03 17:41:20 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:41:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:41:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:41:20 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:41:20 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:41:20 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:41:20 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:20 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:20 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:20 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:20 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:20 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:20 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:20 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-10-03 17:41:20 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:41:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:41:20 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-10-03 17:41:21 --> Config Class Initialized
DEBUG - 2016-10-03 17:41:21 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:41:21 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:41:21 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:41:21 --> URI Class Initialized
DEBUG - 2016-10-03 17:41:21 --> Router Class Initialized
ERROR - 2016-10-03 17:41:21 --> 404 Page Not Found --> back_end/member
DEBUG - 2016-10-03 17:41:21 --> Config Class Initialized
DEBUG - 2016-10-03 17:41:21 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:41:21 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:41:21 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:41:21 --> URI Class Initialized
DEBUG - 2016-10-03 17:41:21 --> Router Class Initialized
ERROR - 2016-10-03 17:41:21 --> 404 Page Not Found --> img
DEBUG - 2016-10-03 17:41:21 --> Config Class Initialized
DEBUG - 2016-10-03 17:41:21 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:41:21 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:41:22 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:41:22 --> URI Class Initialized
DEBUG - 2016-10-03 17:41:22 --> Router Class Initialized
ERROR - 2016-10-03 17:41:22 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-10-03 17:41:26 --> Config Class Initialized
DEBUG - 2016-10-03 17:41:26 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:41:26 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:41:26 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:41:26 --> URI Class Initialized
DEBUG - 2016-10-03 17:41:26 --> Router Class Initialized
ERROR - 2016-10-03 17:41:26 --> 404 Page Not Found --> back_end/member
DEBUG - 2016-10-03 17:41:26 --> Config Class Initialized
DEBUG - 2016-10-03 17:41:26 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:41:26 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:41:26 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:41:26 --> URI Class Initialized
DEBUG - 2016-10-03 17:41:26 --> Router Class Initialized
ERROR - 2016-10-03 17:41:26 --> 404 Page Not Found --> img
DEBUG - 2016-10-03 17:41:36 --> Config Class Initialized
DEBUG - 2016-10-03 17:41:36 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:41:36 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:41:36 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:41:36 --> URI Class Initialized
DEBUG - 2016-10-03 17:41:36 --> Router Class Initialized
DEBUG - 2016-10-03 17:41:36 --> Output Class Initialized
DEBUG - 2016-10-03 17:41:36 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:41:36 --> Security Class Initialized
DEBUG - 2016-10-03 17:41:36 --> Input Class Initialized
DEBUG - 2016-10-03 17:41:36 --> XSS Filtering completed
DEBUG - 2016-10-03 17:41:36 --> XSS Filtering completed
DEBUG - 2016-10-03 17:41:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:41:36 --> Language Class Initialized
DEBUG - 2016-10-03 17:41:36 --> Loader Class Initialized
DEBUG - 2016-10-03 17:41:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:41:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:41:36 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:41:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:41:36 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:41:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:41:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:41:36 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:41:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:41:36 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:41:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:41:36 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:41:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:41:36 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:41:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:41:37 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:41:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:41:37 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:41:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:41:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:41:37 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:41:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:41:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:41:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:41:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:41:37 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:41:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:41:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:41:37 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:41:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:41:37 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:41:37 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:41:37 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:41:37 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:41:37 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:41:37 --> Session Class Initialized
DEBUG - 2016-10-03 17:41:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:41:37 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:41:37 --> Session routines successfully run
DEBUG - 2016-10-03 17:41:37 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:41:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:41:37 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:41:37 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:41:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:41:37 --> Controller Class Initialized
DEBUG - 2016-10-03 17:41:37 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:41:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:41:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:41:37 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:41:37 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:41:37 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:41:37 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:37 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:37 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:37 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:37 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:37 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:37 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:37 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-03 17:41:37 --> Pagination Class Initialized
DEBUG - 2016-10-03 17:41:37 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:41:37 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/index.php
DEBUG - 2016-10-03 17:41:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:41:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:41:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:41:38 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-03 17:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:41:38 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-03 17:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:41:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:41:38 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55961f1d1ca16fdfc4239ae1901a174e
DEBUG - 2016-10-03 17:41:38 --> Final output sent to browser
DEBUG - 2016-10-03 17:41:38 --> Total execution time: 1.4718
DEBUG - 2016-10-03 17:41:45 --> Config Class Initialized
DEBUG - 2016-10-03 17:41:45 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:41:45 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:41:45 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:41:45 --> URI Class Initialized
DEBUG - 2016-10-03 17:41:45 --> Router Class Initialized
DEBUG - 2016-10-03 17:41:45 --> Output Class Initialized
DEBUG - 2016-10-03 17:41:45 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:41:45 --> Security Class Initialized
DEBUG - 2016-10-03 17:41:45 --> Input Class Initialized
DEBUG - 2016-10-03 17:41:45 --> XSS Filtering completed
DEBUG - 2016-10-03 17:41:45 --> XSS Filtering completed
DEBUG - 2016-10-03 17:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:41:45 --> Language Class Initialized
DEBUG - 2016-10-03 17:41:45 --> Loader Class Initialized
DEBUG - 2016-10-03 17:41:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:41:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:41:45 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:41:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:41:45 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:41:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:41:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:41:46 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:41:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:41:46 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:41:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:41:46 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:41:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:41:46 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:41:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:41:46 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:41:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:41:46 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:41:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:41:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:41:46 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:41:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:41:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:41:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:41:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:41:46 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:41:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:41:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:41:46 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:41:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:41:46 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:41:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:41:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:41:46 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:41:46 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:41:46 --> Session Class Initialized
DEBUG - 2016-10-03 17:41:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:41:46 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:41:46 --> Session routines successfully run
DEBUG - 2016-10-03 17:41:46 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:41:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:41:46 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:41:46 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:41:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:41:46 --> Controller Class Initialized
DEBUG - 2016-10-03 17:41:46 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:41:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:41:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:41:46 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:41:46 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:41:46 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:41:46 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:46 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:46 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:46 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:46 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-03 17:41:47 --> Pagination Class Initialized
DEBUG - 2016-10-03 17:41:47 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:41:47 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/role/atlant/index.php
DEBUG - 2016-10-03 17:41:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:41:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:41:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:41:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:41:47 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/role/atlant/js/index_js.php
DEBUG - 2016-10-03 17:41:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:41:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:41:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:41:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:41:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:41:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:41:47 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/role/atlant/js/index_js.php
DEBUG - 2016-10-03 17:41:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:41:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:41:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/bc71e124988d1eb532a929fcbfe4318b
DEBUG - 2016-10-03 17:41:47 --> Final output sent to browser
DEBUG - 2016-10-03 17:41:47 --> Total execution time: 1.4666
DEBUG - 2016-10-03 17:41:54 --> Config Class Initialized
DEBUG - 2016-10-03 17:41:54 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:41:54 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:41:54 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:41:54 --> URI Class Initialized
DEBUG - 2016-10-03 17:41:54 --> Router Class Initialized
DEBUG - 2016-10-03 17:41:54 --> Output Class Initialized
DEBUG - 2016-10-03 17:41:54 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:41:54 --> Security Class Initialized
DEBUG - 2016-10-03 17:41:54 --> Input Class Initialized
DEBUG - 2016-10-03 17:41:54 --> XSS Filtering completed
DEBUG - 2016-10-03 17:41:54 --> XSS Filtering completed
DEBUG - 2016-10-03 17:41:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:41:54 --> Language Class Initialized
DEBUG - 2016-10-03 17:41:54 --> Loader Class Initialized
DEBUG - 2016-10-03 17:41:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:41:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:41:54 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:41:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:41:54 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:41:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:41:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:41:54 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:41:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:41:54 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:41:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:41:54 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:41:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:41:54 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:41:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:41:55 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:41:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:41:55 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:41:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:41:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:41:55 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:41:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:41:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:41:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:41:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:41:55 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:41:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:41:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:41:55 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:41:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:41:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:41:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:41:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:41:55 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:41:55 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:41:55 --> Session Class Initialized
DEBUG - 2016-10-03 17:41:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:41:55 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:41:55 --> Session routines successfully run
DEBUG - 2016-10-03 17:41:55 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:41:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:41:55 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:41:55 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:41:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:41:55 --> Controller Class Initialized
DEBUG - 2016-10-03 17:41:55 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:41:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:41:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:41:55 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:41:55 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:41:55 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:41:55 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:55 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:55 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:55 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:55 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:55 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:55 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:55 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-03 17:41:55 --> Pagination Class Initialized
DEBUG - 2016-10-03 17:41:55 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:41:56 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/index.php
DEBUG - 2016-10-03 17:41:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:41:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:41:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:41:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:41:56 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-03 17:41:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:41:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:41:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:41:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:41:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:41:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:41:56 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-03 17:41:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:41:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:41:56 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55961f1d1ca16fdfc4239ae1901a174e
DEBUG - 2016-10-03 17:41:56 --> Final output sent to browser
DEBUG - 2016-10-03 17:41:56 --> Total execution time: 1.5443
DEBUG - 2016-10-03 17:41:57 --> Config Class Initialized
DEBUG - 2016-10-03 17:41:57 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:41:57 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:41:57 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:41:57 --> URI Class Initialized
DEBUG - 2016-10-03 17:41:57 --> Router Class Initialized
DEBUG - 2016-10-03 17:41:57 --> Output Class Initialized
DEBUG - 2016-10-03 17:41:57 --> Security Class Initialized
DEBUG - 2016-10-03 17:41:58 --> Input Class Initialized
DEBUG - 2016-10-03 17:41:58 --> XSS Filtering completed
DEBUG - 2016-10-03 17:41:58 --> XSS Filtering completed
DEBUG - 2016-10-03 17:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:41:58 --> Language Class Initialized
DEBUG - 2016-10-03 17:41:58 --> Loader Class Initialized
DEBUG - 2016-10-03 17:41:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:41:58 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:41:58 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:41:58 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:41:58 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:41:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:41:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:41:58 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:41:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:41:58 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:41:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:41:58 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:41:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:41:58 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:41:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:41:58 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:41:58 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:41:58 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:41:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:41:58 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:41:58 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:41:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:41:58 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:41:58 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:41:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:41:58 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:41:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:41:58 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:41:58 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:41:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:41:58 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:41:58 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:41:58 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:41:58 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:41:58 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:41:58 --> Session Class Initialized
DEBUG - 2016-10-03 17:41:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:41:58 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:41:58 --> Session routines successfully run
DEBUG - 2016-10-03 17:41:58 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:41:58 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:41:58 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:41:58 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:41:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:41:59 --> Controller Class Initialized
DEBUG - 2016-10-03 17:41:59 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:41:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:41:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:41:59 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:41:59 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:41:59 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:41:59 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:59 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:59 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:59 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:59 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:59 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:59 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:59 --> Model Class Initialized
DEBUG - 2016-10-03 17:41:59 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:41:59 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/role.php
DEBUG - 2016-10-03 17:41:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:41:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:41:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:41:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:41:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:41:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:41:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:41:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:41:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:41:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:41:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:41:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:41:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4a4af08422f573cdfab8bf3c67404ca1
DEBUG - 2016-10-03 17:41:59 --> Final output sent to browser
DEBUG - 2016-10-03 17:41:59 --> Total execution time: 1.5065
DEBUG - 2016-10-03 17:42:03 --> Config Class Initialized
DEBUG - 2016-10-03 17:42:03 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:42:03 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:42:03 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:42:03 --> URI Class Initialized
DEBUG - 2016-10-03 17:42:03 --> Router Class Initialized
DEBUG - 2016-10-03 17:42:03 --> Output Class Initialized
DEBUG - 2016-10-03 17:42:03 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:42:03 --> Security Class Initialized
DEBUG - 2016-10-03 17:42:03 --> Input Class Initialized
DEBUG - 2016-10-03 17:42:03 --> XSS Filtering completed
DEBUG - 2016-10-03 17:42:03 --> XSS Filtering completed
DEBUG - 2016-10-03 17:42:03 --> XSS Filtering completed
DEBUG - 2016-10-03 17:42:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:42:03 --> Language Class Initialized
DEBUG - 2016-10-03 17:42:03 --> Loader Class Initialized
DEBUG - 2016-10-03 17:42:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:42:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:42:03 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:42:04 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:42:04 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:42:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:42:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:42:04 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:42:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:42:04 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:42:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:42:04 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:42:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:42:04 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:42:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:42:04 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:42:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:42:04 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:42:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:42:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:42:04 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:42:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:42:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:42:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:42:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:42:04 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:42:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:42:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:42:04 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:42:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:42:04 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:42:04 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:42:04 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:42:04 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:42:04 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:42:04 --> Session Class Initialized
DEBUG - 2016-10-03 17:42:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:42:04 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:42:04 --> Session routines successfully run
DEBUG - 2016-10-03 17:42:04 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:42:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:42:04 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:42:04 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:42:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:42:04 --> Controller Class Initialized
DEBUG - 2016-10-03 17:42:04 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:42:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:42:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:42:04 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:42:04 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:42:04 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:42:04 --> Model Class Initialized
DEBUG - 2016-10-03 17:42:05 --> Model Class Initialized
DEBUG - 2016-10-03 17:42:05 --> Model Class Initialized
DEBUG - 2016-10-03 17:42:05 --> Model Class Initialized
DEBUG - 2016-10-03 17:42:05 --> Model Class Initialized
DEBUG - 2016-10-03 17:42:05 --> Model Class Initialized
DEBUG - 2016-10-03 17:42:05 --> Model Class Initialized
DEBUG - 2016-10-03 17:42:05 --> Model Class Initialized
DEBUG - 2016-10-03 17:42:05 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:42:05 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/role.php
DEBUG - 2016-10-03 17:42:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:42:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:42:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:42:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:42:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:42:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:42:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:42:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:42:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:42:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:42:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:42:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:42:05 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/4a4af08422f573cdfab8bf3c67404ca1
DEBUG - 2016-10-03 17:42:05 --> Final output sent to browser
DEBUG - 2016-10-03 17:42:05 --> Total execution time: 1.6958
DEBUG - 2016-10-03 17:42:08 --> Config Class Initialized
DEBUG - 2016-10-03 17:42:08 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:42:08 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:42:08 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:42:08 --> URI Class Initialized
DEBUG - 2016-10-03 17:42:08 --> Router Class Initialized
DEBUG - 2016-10-03 17:42:08 --> Output Class Initialized
DEBUG - 2016-10-03 17:42:08 --> Security Class Initialized
DEBUG - 2016-10-03 17:42:08 --> Input Class Initialized
DEBUG - 2016-10-03 17:42:08 --> XSS Filtering completed
DEBUG - 2016-10-03 17:42:08 --> XSS Filtering completed
DEBUG - 2016-10-03 17:42:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:42:08 --> Language Class Initialized
DEBUG - 2016-10-03 17:42:08 --> Loader Class Initialized
DEBUG - 2016-10-03 17:42:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:42:08 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:42:08 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:42:08 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:42:08 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:42:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:42:08 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:42:08 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:42:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:42:08 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:42:08 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:42:08 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:42:08 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:42:08 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:42:08 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:42:08 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:42:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:42:09 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:42:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:42:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:42:09 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:42:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:42:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:42:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:42:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:42:09 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:42:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:42:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:42:09 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:42:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:42:09 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:42:09 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:42:09 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:42:09 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:42:09 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:42:09 --> Session Class Initialized
DEBUG - 2016-10-03 17:42:09 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:42:09 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:42:09 --> Session routines successfully run
DEBUG - 2016-10-03 17:42:09 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:42:09 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:42:09 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:42:09 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:42:09 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:42:09 --> Controller Class Initialized
DEBUG - 2016-10-03 17:42:09 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:42:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:42:09 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:42:09 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:42:09 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:42:09 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:42:09 --> Model Class Initialized
DEBUG - 2016-10-03 17:42:09 --> Model Class Initialized
DEBUG - 2016-10-03 17:42:09 --> Model Class Initialized
DEBUG - 2016-10-03 17:42:09 --> Model Class Initialized
DEBUG - 2016-10-03 17:42:09 --> Model Class Initialized
DEBUG - 2016-10-03 17:42:09 --> Model Class Initialized
DEBUG - 2016-10-03 17:42:09 --> Model Class Initialized
DEBUG - 2016-10-03 17:42:09 --> Model Class Initialized
DEBUG - 2016-10-03 17:42:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-03 17:42:09 --> Pagination Class Initialized
DEBUG - 2016-10-03 17:42:09 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-03 17:42:09 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/index.php
DEBUG - 2016-10-03 17:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:42:10 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-03 17:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:42:10 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-03 17:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:42:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:42:10 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/84d3783950b39b32de831c99fcba6a85
DEBUG - 2016-10-03 17:42:10 --> Final output sent to browser
DEBUG - 2016-10-03 17:42:10 --> Total execution time: 1.5568
DEBUG - 2016-10-03 17:58:39 --> Config Class Initialized
DEBUG - 2016-10-03 17:58:39 --> Hooks Class Initialized
DEBUG - 2016-10-03 17:58:39 --> Utf8 Class Initialized
DEBUG - 2016-10-03 17:58:39 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 17:58:39 --> URI Class Initialized
DEBUG - 2016-10-03 17:58:39 --> Router Class Initialized
DEBUG - 2016-10-03 17:58:39 --> Output Class Initialized
DEBUG - 2016-10-03 17:58:39 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 17:58:39 --> Security Class Initialized
DEBUG - 2016-10-03 17:58:39 --> Input Class Initialized
DEBUG - 2016-10-03 17:58:39 --> XSS Filtering completed
DEBUG - 2016-10-03 17:58:39 --> XSS Filtering completed
DEBUG - 2016-10-03 17:58:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 17:58:40 --> Language Class Initialized
DEBUG - 2016-10-03 17:58:40 --> Loader Class Initialized
DEBUG - 2016-10-03 17:58:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 17:58:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 17:58:40 --> Helper loaded: url_helper
DEBUG - 2016-10-03 17:58:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 17:58:40 --> Helper loaded: file_helper
DEBUG - 2016-10-03 17:58:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:58:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 17:58:40 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 17:58:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 17:58:40 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 17:58:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 17:58:40 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:58:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 17:58:40 --> Helper loaded: common_helper
DEBUG - 2016-10-03 17:58:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 17:58:40 --> Helper loaded: form_helper
DEBUG - 2016-10-03 17:58:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 17:58:40 --> Helper loaded: security_helper
DEBUG - 2016-10-03 17:58:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:58:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 17:58:40 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 17:58:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 17:58:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 17:58:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 17:58:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 17:58:40 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 17:58:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:58:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 17:58:40 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 17:58:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 17:58:40 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 17:58:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 17:58:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 17:58:40 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 17:58:40 --> Database Driver Class Initialized
DEBUG - 2016-10-03 17:58:40 --> Session Class Initialized
DEBUG - 2016-10-03 17:58:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 17:58:40 --> Helper loaded: string_helper
DEBUG - 2016-10-03 17:58:40 --> Session routines successfully run
DEBUG - 2016-10-03 17:58:40 --> Native_session Class Initialized
DEBUG - 2016-10-03 17:58:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 17:58:40 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:58:40 --> Form Validation Class Initialized
DEBUG - 2016-10-03 17:58:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 17:58:40 --> Controller Class Initialized
DEBUG - 2016-10-03 17:58:41 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 17:58:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 17:58:41 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 17:58:41 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:58:41 --> Carabiner: library configured.
DEBUG - 2016-10-03 17:58:41 --> User Agent Class Initialized
DEBUG - 2016-10-03 17:58:41 --> Model Class Initialized
DEBUG - 2016-10-03 17:58:41 --> Model Class Initialized
DEBUG - 2016-10-03 17:58:41 --> Model Class Initialized
DEBUG - 2016-10-03 17:58:41 --> Model Class Initialized
DEBUG - 2016-10-03 17:58:41 --> Model Class Initialized
DEBUG - 2016-10-03 17:58:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-03 17:58:41 --> Pagination Class Initialized
DEBUG - 2016-10-03 17:58:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-10-03 17:58:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/index.php
DEBUG - 2016-10-03 17:58:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:58:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:58:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:58:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:58:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-10-03 17:58:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:58:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:58:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 17:58:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 17:58:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 17:58:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 17:58:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-10-03 17:58:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 17:58:41 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 17:58:41 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/c2a3e0401bd35d4fcac4bae5f9412231
DEBUG - 2016-10-03 17:58:41 --> Final output sent to browser
DEBUG - 2016-10-03 17:58:41 --> Total execution time: 1.5408
DEBUG - 2016-10-03 18:01:05 --> Config Class Initialized
DEBUG - 2016-10-03 18:01:05 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:01:05 --> Utf8 Class Initialized
DEBUG - 2016-10-03 18:01:05 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 18:01:05 --> URI Class Initialized
DEBUG - 2016-10-03 18:01:05 --> Router Class Initialized
DEBUG - 2016-10-03 18:01:05 --> Output Class Initialized
DEBUG - 2016-10-03 18:01:05 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 18:01:05 --> Security Class Initialized
DEBUG - 2016-10-03 18:01:05 --> Input Class Initialized
DEBUG - 2016-10-03 18:01:05 --> XSS Filtering completed
DEBUG - 2016-10-03 18:01:05 --> XSS Filtering completed
DEBUG - 2016-10-03 18:01:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 18:01:05 --> Language Class Initialized
DEBUG - 2016-10-03 18:01:05 --> Loader Class Initialized
DEBUG - 2016-10-03 18:01:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 18:01:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 18:01:05 --> Helper loaded: url_helper
DEBUG - 2016-10-03 18:01:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 18:01:06 --> Helper loaded: file_helper
DEBUG - 2016-10-03 18:01:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 18:01:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 18:01:06 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 18:01:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 18:01:06 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 18:01:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 18:01:06 --> Helper loaded: common_helper
DEBUG - 2016-10-03 18:01:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 18:01:06 --> Helper loaded: common_helper
DEBUG - 2016-10-03 18:01:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 18:01:06 --> Helper loaded: form_helper
DEBUG - 2016-10-03 18:01:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 18:01:06 --> Helper loaded: security_helper
DEBUG - 2016-10-03 18:01:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 18:01:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 18:01:06 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 18:01:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 18:01:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 18:01:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 18:01:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 18:01:06 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 18:01:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 18:01:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 18:01:06 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 18:01:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 18:01:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 18:01:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 18:01:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 18:01:06 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 18:01:06 --> Database Driver Class Initialized
DEBUG - 2016-10-03 18:01:06 --> Session Class Initialized
DEBUG - 2016-10-03 18:01:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 18:01:06 --> Helper loaded: string_helper
DEBUG - 2016-10-03 18:01:06 --> Session routines successfully run
DEBUG - 2016-10-03 18:01:06 --> Native_session Class Initialized
DEBUG - 2016-10-03 18:01:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 18:01:06 --> Form Validation Class Initialized
DEBUG - 2016-10-03 18:01:06 --> Form Validation Class Initialized
DEBUG - 2016-10-03 18:01:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 18:01:06 --> Controller Class Initialized
DEBUG - 2016-10-03 18:01:06 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 18:01:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 18:01:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 18:01:06 --> Carabiner: library configured.
DEBUG - 2016-10-03 18:01:06 --> Carabiner: library configured.
DEBUG - 2016-10-03 18:01:06 --> User Agent Class Initialized
DEBUG - 2016-10-03 18:01:07 --> Model Class Initialized
DEBUG - 2016-10-03 18:01:07 --> Model Class Initialized
DEBUG - 2016-10-03 18:01:07 --> Model Class Initialized
DEBUG - 2016-10-03 18:01:07 --> Model Class Initialized
DEBUG - 2016-10-03 18:01:07 --> Model Class Initialized
DEBUG - 2016-10-03 18:01:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-10-03 18:01:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/detail.php
DEBUG - 2016-10-03 18:01:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 18:01:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 18:01:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 18:01:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 18:01:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/detail_js.php
DEBUG - 2016-10-03 18:01:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_isian_js.php
DEBUG - 2016-10-03 18:01:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 18:01:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 18:01:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 18:01:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 18:01:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 18:01:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 18:01:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/detail_js.php
DEBUG - 2016-10-03 18:01:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/detail_isian_js.php
DEBUG - 2016-10-03 18:01:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 18:01:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 18:01:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/3cd2012797efc339130dbd0f76604ad9
DEBUG - 2016-10-03 18:01:07 --> Final output sent to browser
DEBUG - 2016-10-03 18:01:07 --> Total execution time: 1.5353
DEBUG - 2016-10-03 18:11:18 --> Config Class Initialized
DEBUG - 2016-10-03 18:11:18 --> Hooks Class Initialized
DEBUG - 2016-10-03 18:11:18 --> Utf8 Class Initialized
DEBUG - 2016-10-03 18:11:18 --> UTF-8 Support Enabled
DEBUG - 2016-10-03 18:11:18 --> URI Class Initialized
DEBUG - 2016-10-03 18:11:18 --> Router Class Initialized
DEBUG - 2016-10-03 18:11:18 --> Output Class Initialized
DEBUG - 2016-10-03 18:11:18 --> Cache file has expired. File deleted
DEBUG - 2016-10-03 18:11:18 --> Security Class Initialized
DEBUG - 2016-10-03 18:11:18 --> Input Class Initialized
DEBUG - 2016-10-03 18:11:18 --> XSS Filtering completed
DEBUG - 2016-10-03 18:11:18 --> XSS Filtering completed
DEBUG - 2016-10-03 18:11:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-03 18:11:19 --> Language Class Initialized
DEBUG - 2016-10-03 18:11:19 --> Loader Class Initialized
DEBUG - 2016-10-03 18:11:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-03 18:11:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-03 18:11:19 --> Helper loaded: url_helper
DEBUG - 2016-10-03 18:11:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-03 18:11:19 --> Helper loaded: file_helper
DEBUG - 2016-10-03 18:11:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 18:11:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-03 18:11:19 --> Helper loaded: conf_helper
DEBUG - 2016-10-03 18:11:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-03 18:11:19 --> Check Exists common_helper.php: No
DEBUG - 2016-10-03 18:11:19 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-03 18:11:19 --> Helper loaded: common_helper
DEBUG - 2016-10-03 18:11:19 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-03 18:11:19 --> Helper loaded: common_helper
DEBUG - 2016-10-03 18:11:19 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-03 18:11:19 --> Helper loaded: form_helper
DEBUG - 2016-10-03 18:11:19 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-03 18:11:19 --> Helper loaded: security_helper
DEBUG - 2016-10-03 18:11:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 18:11:19 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-03 18:11:19 --> Helper loaded: lang_helper
DEBUG - 2016-10-03 18:11:19 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-03 18:11:19 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-03 18:11:19 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-03 18:11:19 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-03 18:11:19 --> Helper loaded: atlant_helper
DEBUG - 2016-10-03 18:11:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 18:11:19 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-03 18:11:19 --> Helper loaded: crypto_helper
DEBUG - 2016-10-03 18:11:19 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-03 18:11:19 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-03 18:11:19 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-03 18:11:19 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-03 18:11:19 --> Helper loaded: sidika_helper
DEBUG - 2016-10-03 18:11:19 --> Database Driver Class Initialized
DEBUG - 2016-10-03 18:11:19 --> Session Class Initialized
DEBUG - 2016-10-03 18:11:19 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-03 18:11:19 --> Helper loaded: string_helper
DEBUG - 2016-10-03 18:11:19 --> Session routines successfully run
DEBUG - 2016-10-03 18:11:19 --> Native_session Class Initialized
DEBUG - 2016-10-03 18:11:19 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-03 18:11:19 --> Form Validation Class Initialized
DEBUG - 2016-10-03 18:11:19 --> Form Validation Class Initialized
DEBUG - 2016-10-03 18:11:19 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-03 18:11:20 --> Controller Class Initialized
DEBUG - 2016-10-03 18:11:20 --> Carabiner: Library initialized.
DEBUG - 2016-10-03 18:11:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-03 18:11:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-03 18:11:20 --> Carabiner: library configured.
DEBUG - 2016-10-03 18:11:20 --> Carabiner: library configured.
DEBUG - 2016-10-03 18:11:20 --> User Agent Class Initialized
DEBUG - 2016-10-03 18:11:20 --> Model Class Initialized
DEBUG - 2016-10-03 18:11:20 --> Model Class Initialized
DEBUG - 2016-10-03 18:11:20 --> Model Class Initialized
DEBUG - 2016-10-03 18:11:20 --> Model Class Initialized
DEBUG - 2016-10-03 18:11:20 --> Model Class Initialized
DEBUG - 2016-10-03 18:11:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-03 18:11:20 --> Pagination Class Initialized
DEBUG - 2016-10-03 18:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-10-03 18:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/index.php
DEBUG - 2016-10-03 18:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 18:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 18:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 18:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 18:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-10-03 18:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 18:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 18:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-03 18:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-03 18:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-03 18:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-03 18:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_pegawai/js/index_js.php
DEBUG - 2016-10-03 18:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-03 18:11:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-03 18:11:20 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/7756cdc8a4cea1c61ca1985b4e86e34f
DEBUG - 2016-10-03 18:11:20 --> Final output sent to browser
DEBUG - 2016-10-03 18:11:20 --> Total execution time: 1.6486
