<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-09-15 14:54:42 --> Config Class Initialized
DEBUG - 2016-09-15 14:54:42 --> Hooks Class Initialized
DEBUG - 2016-09-15 14:54:42 --> Utf8 Class Initialized
DEBUG - 2016-09-15 14:54:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-15 14:54:42 --> URI Class Initialized
DEBUG - 2016-09-15 14:54:42 --> Router Class Initialized
DEBUG - 2016-09-15 14:54:42 --> No URI present. Default controller set.
DEBUG - 2016-09-15 14:54:42 --> Output Class Initialized
DEBUG - 2016-09-15 14:54:43 --> Cache file has expired. File deleted
DEBUG - 2016-09-15 14:54:43 --> Security Class Initialized
DEBUG - 2016-09-15 14:54:43 --> Input Class Initialized
DEBUG - 2016-09-15 14:54:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-15 14:54:43 --> Language Class Initialized
DEBUG - 2016-09-15 14:54:43 --> Loader Class Initialized
DEBUG - 2016-09-15 14:54:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-15 14:54:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-15 14:54:43 --> Helper loaded: url_helper
DEBUG - 2016-09-15 14:54:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-15 14:54:43 --> Helper loaded: file_helper
DEBUG - 2016-09-15 14:54:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-15 14:54:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-15 14:54:43 --> Helper loaded: conf_helper
DEBUG - 2016-09-15 14:54:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-15 14:54:43 --> Check Exists common_helper.php: No
DEBUG - 2016-09-15 14:54:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-15 14:54:43 --> Helper loaded: common_helper
DEBUG - 2016-09-15 14:54:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-15 14:54:43 --> Helper loaded: common_helper
DEBUG - 2016-09-15 14:54:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-15 14:54:43 --> Helper loaded: form_helper
DEBUG - 2016-09-15 14:54:43 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-15 14:54:43 --> Helper loaded: security_helper
DEBUG - 2016-09-15 14:54:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-15 14:54:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-15 14:54:43 --> Helper loaded: lang_helper
DEBUG - 2016-09-15 14:54:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-15 14:54:43 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-15 14:54:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-15 14:54:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-15 14:54:43 --> Helper loaded: atlant_helper
DEBUG - 2016-09-15 14:54:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-15 14:54:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-15 14:54:43 --> Helper loaded: crypto_helper
DEBUG - 2016-09-15 14:54:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-15 14:54:43 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-15 14:54:43 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-15 14:54:43 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-15 14:54:43 --> Helper loaded: sidika_helper
DEBUG - 2016-09-15 14:54:43 --> Database Driver Class Initialized
ERROR - 2016-09-15 14:54:45 --> Severity: Warning  --> pg_connect(): Unable to connect to PostgreSQL server: could not connect to server: Connection refused (0x0000274D/10061)
	Is the server running on host &quot;127.0.0.1&quot; and accepting
	TCP/IP connections on port 5432? E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 87
ERROR - 2016-09-15 14:54:45 --> Unable to connect to the database
DEBUG - 2016-09-15 14:54:45 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-09-15 15:03:36 --> Config Class Initialized
DEBUG - 2016-09-15 15:03:36 --> Hooks Class Initialized
DEBUG - 2016-09-15 15:03:36 --> Utf8 Class Initialized
DEBUG - 2016-09-15 15:03:36 --> UTF-8 Support Enabled
DEBUG - 2016-09-15 15:03:36 --> URI Class Initialized
DEBUG - 2016-09-15 15:03:36 --> Router Class Initialized
DEBUG - 2016-09-15 15:03:36 --> No URI present. Default controller set.
DEBUG - 2016-09-15 15:03:36 --> Output Class Initialized
DEBUG - 2016-09-15 15:03:36 --> Security Class Initialized
DEBUG - 2016-09-15 15:03:36 --> Input Class Initialized
DEBUG - 2016-09-15 15:03:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-15 15:03:36 --> Language Class Initialized
DEBUG - 2016-09-15 15:03:36 --> Loader Class Initialized
DEBUG - 2016-09-15 15:03:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-15 15:03:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-15 15:03:36 --> Helper loaded: url_helper
DEBUG - 2016-09-15 15:03:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-15 15:03:36 --> Helper loaded: file_helper
DEBUG - 2016-09-15 15:03:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-15 15:03:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-15 15:03:36 --> Helper loaded: conf_helper
DEBUG - 2016-09-15 15:03:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-15 15:03:36 --> Check Exists common_helper.php: No
DEBUG - 2016-09-15 15:03:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-15 15:03:36 --> Helper loaded: common_helper
DEBUG - 2016-09-15 15:03:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-15 15:03:36 --> Helper loaded: common_helper
DEBUG - 2016-09-15 15:03:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-15 15:03:36 --> Helper loaded: form_helper
DEBUG - 2016-09-15 15:03:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-15 15:03:36 --> Helper loaded: security_helper
DEBUG - 2016-09-15 15:03:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-15 15:03:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-15 15:03:36 --> Helper loaded: lang_helper
DEBUG - 2016-09-15 15:03:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-15 15:03:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-15 15:03:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-15 15:03:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-15 15:03:36 --> Helper loaded: atlant_helper
DEBUG - 2016-09-15 15:03:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-15 15:03:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-15 15:03:36 --> Helper loaded: crypto_helper
DEBUG - 2016-09-15 15:03:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-15 15:03:36 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-15 15:03:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-15 15:03:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-15 15:03:36 --> Helper loaded: sidika_helper
DEBUG - 2016-09-15 15:03:36 --> Database Driver Class Initialized
DEBUG - 2016-09-15 15:03:37 --> Session Class Initialized
DEBUG - 2016-09-15 15:03:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-15 15:03:37 --> Helper loaded: string_helper
DEBUG - 2016-09-15 15:03:37 --> A session cookie was not found.
DEBUG - 2016-09-15 15:03:37 --> Session routines successfully run
DEBUG - 2016-09-15 15:03:37 --> Native_session Class Initialized
DEBUG - 2016-09-15 15:03:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-15 15:03:37 --> Form Validation Class Initialized
DEBUG - 2016-09-15 15:03:37 --> Form Validation Class Initialized
DEBUG - 2016-09-15 15:03:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-15 15:03:37 --> Controller Class Initialized
DEBUG - 2016-09-15 15:03:37 --> Carabiner: Library initialized.
DEBUG - 2016-09-15 15:03:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-15 15:03:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-15 15:03:37 --> Carabiner: library configured.
DEBUG - 2016-09-15 15:03:37 --> Carabiner: library configured.
DEBUG - 2016-09-15 15:03:37 --> User Agent Class Initialized
DEBUG - 2016-09-15 15:03:37 --> Model Class Initialized
DEBUG - 2016-09-15 15:03:37 --> Model Class Initialized
DEBUG - 2016-09-15 15:03:37 --> Model Class Initialized
ERROR - 2016-09-15 15:03:39 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-15 15:03:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-15 15:03:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-15 15:03:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-15 15:03:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-15 15:03:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-15 15:03:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-15 15:03:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-15 15:03:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-15 15:03:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-15 15:03:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-15 15:03:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-15 15:03:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-15 15:03:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-15 15:03:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-15 15:03:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-15 15:03:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-15 15:03:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-15 15:03:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-15 15:03:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-15 15:03:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-15 15:03:39 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-15 15:03:39 --> Final output sent to browser
DEBUG - 2016-09-15 15:03:39 --> Total execution time: 2.6743
DEBUG - 2016-09-15 15:03:43 --> Config Class Initialized
DEBUG - 2016-09-15 15:03:43 --> Hooks Class Initialized
DEBUG - 2016-09-15 15:03:43 --> Utf8 Class Initialized
DEBUG - 2016-09-15 15:03:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-15 15:03:43 --> URI Class Initialized
DEBUG - 2016-09-15 15:03:43 --> Router Class Initialized
ERROR - 2016-09-15 15:03:43 --> 404 Page Not Found --> adaftar_diklat
DEBUG - 2016-09-15 15:41:52 --> Config Class Initialized
DEBUG - 2016-09-15 15:41:52 --> Hooks Class Initialized
DEBUG - 2016-09-15 15:41:52 --> Utf8 Class Initialized
DEBUG - 2016-09-15 15:41:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-15 15:41:52 --> URI Class Initialized
DEBUG - 2016-09-15 15:41:52 --> Router Class Initialized
DEBUG - 2016-09-15 15:41:52 --> No URI present. Default controller set.
DEBUG - 2016-09-15 15:41:52 --> Output Class Initialized
DEBUG - 2016-09-15 15:41:53 --> Cache file has expired. File deleted
DEBUG - 2016-09-15 15:41:53 --> Security Class Initialized
DEBUG - 2016-09-15 15:41:53 --> Input Class Initialized
DEBUG - 2016-09-15 15:41:53 --> XSS Filtering completed
DEBUG - 2016-09-15 15:41:53 --> XSS Filtering completed
DEBUG - 2016-09-15 15:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-15 15:41:53 --> Language Class Initialized
DEBUG - 2016-09-15 15:41:53 --> Loader Class Initialized
DEBUG - 2016-09-15 15:41:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-15 15:41:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-15 15:41:53 --> Helper loaded: url_helper
DEBUG - 2016-09-15 15:41:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-15 15:41:53 --> Helper loaded: file_helper
DEBUG - 2016-09-15 15:41:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-15 15:41:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-15 15:41:53 --> Helper loaded: conf_helper
DEBUG - 2016-09-15 15:41:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-15 15:41:53 --> Check Exists common_helper.php: No
DEBUG - 2016-09-15 15:41:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-15 15:41:53 --> Helper loaded: common_helper
DEBUG - 2016-09-15 15:41:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-15 15:41:53 --> Helper loaded: common_helper
DEBUG - 2016-09-15 15:41:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-15 15:41:53 --> Helper loaded: form_helper
DEBUG - 2016-09-15 15:41:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-15 15:41:53 --> Helper loaded: security_helper
DEBUG - 2016-09-15 15:41:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-15 15:41:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-15 15:41:53 --> Helper loaded: lang_helper
DEBUG - 2016-09-15 15:41:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-15 15:41:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-15 15:41:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-15 15:41:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-15 15:41:54 --> Helper loaded: atlant_helper
DEBUG - 2016-09-15 15:41:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-15 15:41:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-15 15:41:54 --> Helper loaded: crypto_helper
DEBUG - 2016-09-15 15:41:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-15 15:41:54 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-15 15:41:54 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-15 15:41:54 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-15 15:41:54 --> Helper loaded: sidika_helper
DEBUG - 2016-09-15 15:41:54 --> Database Driver Class Initialized
ERROR - 2016-09-15 15:41:55 --> Severity: Warning  --> pg_connect(): Unable to connect to PostgreSQL server: could not connect to server: Connection refused (0x0000274D/10061)
	Is the server running on host &quot;127.0.0.1&quot; and accepting
	TCP/IP connections on port 5432? E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 87
ERROR - 2016-09-15 15:41:55 --> Unable to connect to the database
DEBUG - 2016-09-15 15:41:55 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-09-15 16:30:27 --> Config Class Initialized
DEBUG - 2016-09-15 16:30:27 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:30:27 --> Utf8 Class Initialized
DEBUG - 2016-09-15 16:30:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-15 16:30:27 --> URI Class Initialized
DEBUG - 2016-09-15 16:30:27 --> Router Class Initialized
DEBUG - 2016-09-15 16:30:27 --> No URI present. Default controller set.
DEBUG - 2016-09-15 16:30:27 --> Output Class Initialized
DEBUG - 2016-09-15 16:30:27 --> Security Class Initialized
DEBUG - 2016-09-15 16:30:27 --> Input Class Initialized
DEBUG - 2016-09-15 16:30:27 --> XSS Filtering completed
DEBUG - 2016-09-15 16:30:27 --> XSS Filtering completed
DEBUG - 2016-09-15 16:30:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-15 16:30:27 --> Language Class Initialized
DEBUG - 2016-09-15 16:30:27 --> Loader Class Initialized
DEBUG - 2016-09-15 16:30:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-15 16:30:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-15 16:30:27 --> Helper loaded: url_helper
DEBUG - 2016-09-15 16:30:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-15 16:30:27 --> Helper loaded: file_helper
DEBUG - 2016-09-15 16:30:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-15 16:30:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-15 16:30:27 --> Helper loaded: conf_helper
DEBUG - 2016-09-15 16:30:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-15 16:30:27 --> Check Exists common_helper.php: No
DEBUG - 2016-09-15 16:30:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-15 16:30:27 --> Helper loaded: common_helper
DEBUG - 2016-09-15 16:30:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-15 16:30:27 --> Helper loaded: common_helper
DEBUG - 2016-09-15 16:30:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-15 16:30:27 --> Helper loaded: form_helper
DEBUG - 2016-09-15 16:30:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-15 16:30:27 --> Helper loaded: security_helper
DEBUG - 2016-09-15 16:30:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-15 16:30:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-15 16:30:27 --> Helper loaded: lang_helper
DEBUG - 2016-09-15 16:30:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-15 16:30:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-15 16:30:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-15 16:30:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-15 16:30:27 --> Helper loaded: atlant_helper
DEBUG - 2016-09-15 16:30:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-15 16:30:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-15 16:30:27 --> Helper loaded: crypto_helper
DEBUG - 2016-09-15 16:30:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-15 16:30:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-15 16:30:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-15 16:30:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-15 16:30:27 --> Helper loaded: sidika_helper
DEBUG - 2016-09-15 16:30:27 --> Database Driver Class Initialized
ERROR - 2016-09-15 16:30:28 --> Severity: Warning  --> pg_connect(): Unable to connect to PostgreSQL server: could not connect to server: Connection refused (0x0000274D/10061)
	Is the server running on host &quot;127.0.0.1&quot; and accepting
	TCP/IP connections on port 5432? E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 87
ERROR - 2016-09-15 16:30:28 --> Unable to connect to the database
DEBUG - 2016-09-15 16:30:28 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-09-15 16:31:03 --> Config Class Initialized
DEBUG - 2016-09-15 16:31:03 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:31:03 --> Utf8 Class Initialized
DEBUG - 2016-09-15 16:31:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-15 16:31:03 --> URI Class Initialized
DEBUG - 2016-09-15 16:31:03 --> Router Class Initialized
DEBUG - 2016-09-15 16:31:03 --> No URI present. Default controller set.
DEBUG - 2016-09-15 16:31:03 --> Output Class Initialized
DEBUG - 2016-09-15 16:31:03 --> Security Class Initialized
DEBUG - 2016-09-15 16:31:03 --> Input Class Initialized
DEBUG - 2016-09-15 16:31:03 --> XSS Filtering completed
DEBUG - 2016-09-15 16:31:03 --> XSS Filtering completed
DEBUG - 2016-09-15 16:31:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-15 16:31:03 --> Language Class Initialized
DEBUG - 2016-09-15 16:31:03 --> Loader Class Initialized
DEBUG - 2016-09-15 16:31:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-15 16:31:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-15 16:31:03 --> Helper loaded: url_helper
DEBUG - 2016-09-15 16:31:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-15 16:31:03 --> Helper loaded: file_helper
DEBUG - 2016-09-15 16:31:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-15 16:31:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-15 16:31:03 --> Helper loaded: conf_helper
DEBUG - 2016-09-15 16:31:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-15 16:31:03 --> Check Exists common_helper.php: No
DEBUG - 2016-09-15 16:31:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-15 16:31:03 --> Helper loaded: common_helper
DEBUG - 2016-09-15 16:31:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-15 16:31:03 --> Helper loaded: common_helper
DEBUG - 2016-09-15 16:31:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-15 16:31:03 --> Helper loaded: form_helper
DEBUG - 2016-09-15 16:31:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-15 16:31:03 --> Helper loaded: security_helper
DEBUG - 2016-09-15 16:31:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-15 16:31:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-15 16:31:03 --> Helper loaded: lang_helper
DEBUG - 2016-09-15 16:31:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-15 16:31:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-15 16:31:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-15 16:31:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-15 16:31:03 --> Helper loaded: atlant_helper
DEBUG - 2016-09-15 16:31:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-15 16:31:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-15 16:31:03 --> Helper loaded: crypto_helper
DEBUG - 2016-09-15 16:31:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-15 16:31:03 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-15 16:31:03 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-15 16:31:03 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-15 16:31:03 --> Helper loaded: sidika_helper
DEBUG - 2016-09-15 16:31:03 --> Database Driver Class Initialized
DEBUG - 2016-09-15 16:31:04 --> Session Class Initialized
DEBUG - 2016-09-15 16:31:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-15 16:31:04 --> Helper loaded: string_helper
DEBUG - 2016-09-15 16:31:04 --> Session routines successfully run
DEBUG - 2016-09-15 16:31:04 --> Native_session Class Initialized
DEBUG - 2016-09-15 16:31:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-15 16:31:04 --> Form Validation Class Initialized
DEBUG - 2016-09-15 16:31:04 --> Form Validation Class Initialized
DEBUG - 2016-09-15 16:31:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-15 16:31:04 --> Controller Class Initialized
DEBUG - 2016-09-15 16:31:04 --> Carabiner: Library initialized.
DEBUG - 2016-09-15 16:31:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-15 16:31:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-15 16:31:04 --> Carabiner: library configured.
DEBUG - 2016-09-15 16:31:04 --> Carabiner: library configured.
DEBUG - 2016-09-15 16:31:04 --> User Agent Class Initialized
DEBUG - 2016-09-15 16:31:04 --> Model Class Initialized
DEBUG - 2016-09-15 16:31:04 --> Model Class Initialized
DEBUG - 2016-09-15 16:31:04 --> Model Class Initialized
ERROR - 2016-09-15 16:31:04 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-15 16:31:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-09-15 16:31:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-15 16:31:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-15 16:31:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-15 16:31:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-15 16:31:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-15 16:31:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-15 16:31:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-15 16:31:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-15 16:31:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-15 16:31:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-15 16:31:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-15 16:31:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-15 16:31:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-15 16:31:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-15 16:31:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-09-15 16:31:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-09-15 16:31:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-09-15 16:31:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-15 16:31:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-15 16:31:05 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-15 16:31:05 --> Final output sent to browser
DEBUG - 2016-09-15 16:31:05 --> Total execution time: 1.0678
DEBUG - 2016-09-15 16:31:06 --> Config Class Initialized
DEBUG - 2016-09-15 16:31:06 --> Hooks Class Initialized
DEBUG - 2016-09-15 16:31:06 --> Utf8 Class Initialized
DEBUG - 2016-09-15 16:31:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-15 16:31:06 --> URI Class Initialized
DEBUG - 2016-09-15 16:31:06 --> Router Class Initialized
ERROR - 2016-09-15 16:31:06 --> 404 Page Not Found --> adaftar_diklat
