<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-10-01 22:41:39 --> Config Class Initialized
DEBUG - 2016-10-01 22:41:39 --> Hooks Class Initialized
DEBUG - 2016-10-01 22:41:39 --> Utf8 Class Initialized
DEBUG - 2016-10-01 22:41:39 --> UTF-8 Support Enabled
DEBUG - 2016-10-01 22:41:39 --> URI Class Initialized
DEBUG - 2016-10-01 22:41:39 --> Router Class Initialized
DEBUG - 2016-10-01 22:41:39 --> No URI present. Default controller set.
DEBUG - 2016-10-01 22:41:39 --> Output Class Initialized
DEBUG - 2016-10-01 22:41:39 --> Cache file has expired. File deleted
DEBUG - 2016-10-01 22:41:39 --> Security Class Initialized
DEBUG - 2016-10-01 22:41:39 --> Input Class Initialized
DEBUG - 2016-10-01 22:41:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-01 22:41:39 --> Language Class Initialized
DEBUG - 2016-10-01 22:41:40 --> Loader Class Initialized
DEBUG - 2016-10-01 22:41:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-01 22:41:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-01 22:41:40 --> Helper loaded: url_helper
DEBUG - 2016-10-01 22:41:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-01 22:41:40 --> Helper loaded: file_helper
DEBUG - 2016-10-01 22:41:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-01 22:41:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-01 22:41:40 --> Helper loaded: conf_helper
DEBUG - 2016-10-01 22:41:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-01 22:41:40 --> Check Exists common_helper.php: No
DEBUG - 2016-10-01 22:41:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-01 22:41:40 --> Helper loaded: common_helper
DEBUG - 2016-10-01 22:41:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-01 22:41:40 --> Helper loaded: common_helper
DEBUG - 2016-10-01 22:41:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-01 22:41:40 --> Helper loaded: form_helper
DEBUG - 2016-10-01 22:41:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-01 22:41:40 --> Helper loaded: security_helper
DEBUG - 2016-10-01 22:41:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-01 22:41:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-01 22:41:40 --> Helper loaded: lang_helper
DEBUG - 2016-10-01 22:41:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-01 22:41:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-01 22:41:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-01 22:41:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-01 22:41:40 --> Helper loaded: atlant_helper
DEBUG - 2016-10-01 22:41:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-01 22:41:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-01 22:41:40 --> Helper loaded: crypto_helper
DEBUG - 2016-10-01 22:41:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-01 22:41:40 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-01 22:41:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-01 22:41:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-01 22:41:40 --> Helper loaded: sidika_helper
DEBUG - 2016-10-01 22:41:40 --> Database Driver Class Initialized
ERROR - 2016-10-01 22:41:41 --> Severity: Warning  --> pg_connect(): Unable to connect to PostgreSQL server: could not connect to server: Connection refused (0x0000274D/10061)
	Is the server running on host &quot;127.0.0.1&quot; and accepting
	TCP/IP connections on port 5432? E:\www\CodeIgniter-2.2.6\system\database\drivers\postgre\postgre_driver.php 87
ERROR - 2016-10-01 22:41:41 --> Unable to connect to the database
DEBUG - 2016-10-01 22:41:41 --> Language file loaded: language/indonesia/db_lang.php
DEBUG - 2016-10-01 22:41:55 --> Config Class Initialized
DEBUG - 2016-10-01 22:41:55 --> Hooks Class Initialized
DEBUG - 2016-10-01 22:41:55 --> Utf8 Class Initialized
DEBUG - 2016-10-01 22:41:55 --> UTF-8 Support Enabled
DEBUG - 2016-10-01 22:41:55 --> URI Class Initialized
DEBUG - 2016-10-01 22:41:55 --> Router Class Initialized
DEBUG - 2016-10-01 22:41:55 --> No URI present. Default controller set.
DEBUG - 2016-10-01 22:41:55 --> Output Class Initialized
DEBUG - 2016-10-01 22:41:55 --> Security Class Initialized
DEBUG - 2016-10-01 22:41:55 --> Input Class Initialized
DEBUG - 2016-10-01 22:41:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-01 22:41:55 --> Language Class Initialized
DEBUG - 2016-10-01 22:41:55 --> Loader Class Initialized
DEBUG - 2016-10-01 22:41:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-01 22:41:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-01 22:41:55 --> Helper loaded: url_helper
DEBUG - 2016-10-01 22:41:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-01 22:41:55 --> Helper loaded: file_helper
DEBUG - 2016-10-01 22:41:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-01 22:41:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-01 22:41:55 --> Helper loaded: conf_helper
DEBUG - 2016-10-01 22:41:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-01 22:41:55 --> Check Exists common_helper.php: No
DEBUG - 2016-10-01 22:41:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-01 22:41:55 --> Helper loaded: common_helper
DEBUG - 2016-10-01 22:41:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-01 22:41:55 --> Helper loaded: common_helper
DEBUG - 2016-10-01 22:41:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-01 22:41:55 --> Helper loaded: form_helper
DEBUG - 2016-10-01 22:41:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-01 22:41:55 --> Helper loaded: security_helper
DEBUG - 2016-10-01 22:41:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-01 22:41:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-01 22:41:55 --> Helper loaded: lang_helper
DEBUG - 2016-10-01 22:41:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-01 22:41:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-01 22:41:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-01 22:41:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-01 22:41:55 --> Helper loaded: atlant_helper
DEBUG - 2016-10-01 22:41:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-01 22:41:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-01 22:41:55 --> Helper loaded: crypto_helper
DEBUG - 2016-10-01 22:41:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-01 22:41:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-01 22:41:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-01 22:41:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-01 22:41:55 --> Helper loaded: sidika_helper
DEBUG - 2016-10-01 22:41:55 --> Database Driver Class Initialized
DEBUG - 2016-10-01 22:41:55 --> Session Class Initialized
DEBUG - 2016-10-01 22:41:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-01 22:41:55 --> Helper loaded: string_helper
DEBUG - 2016-10-01 22:41:55 --> A session cookie was not found.
DEBUG - 2016-10-01 22:41:55 --> Session routines successfully run
DEBUG - 2016-10-01 22:41:55 --> Native_session Class Initialized
DEBUG - 2016-10-01 22:41:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-01 22:41:55 --> Form Validation Class Initialized
DEBUG - 2016-10-01 22:41:55 --> Form Validation Class Initialized
DEBUG - 2016-10-01 22:41:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-01 22:41:55 --> Controller Class Initialized
DEBUG - 2016-10-01 22:41:55 --> Carabiner: Library initialized.
DEBUG - 2016-10-01 22:41:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-01 22:41:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-01 22:41:55 --> Carabiner: library configured.
DEBUG - 2016-10-01 22:41:55 --> Carabiner: library configured.
DEBUG - 2016-10-01 22:41:56 --> User Agent Class Initialized
DEBUG - 2016-10-01 22:41:56 --> Model Class Initialized
DEBUG - 2016-10-01 22:41:56 --> Model Class Initialized
DEBUG - 2016-10-01 22:41:56 --> Model Class Initialized
ERROR - 2016-10-01 22:41:57 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-10-01 22:41:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-10-01 22:41:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-10-01 22:41:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-01 22:41:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-01 22:41:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-01 22:41:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-01 22:41:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-01 22:41:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-01 22:41:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-01 22:41:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-01 22:41:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-01 22:41:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-01 22:41:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-01 22:41:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-01 22:41:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-01 22:41:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-01 22:41:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-01 22:41:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-01 22:41:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-01 22:41:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-01 22:41:57 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-10-01 22:41:57 --> Final output sent to browser
DEBUG - 2016-10-01 22:41:57 --> Total execution time: 1.5365
DEBUG - 2016-10-01 22:42:02 --> Config Class Initialized
DEBUG - 2016-10-01 22:42:02 --> Hooks Class Initialized
DEBUG - 2016-10-01 22:42:02 --> Utf8 Class Initialized
DEBUG - 2016-10-01 22:42:02 --> UTF-8 Support Enabled
DEBUG - 2016-10-01 22:42:02 --> URI Class Initialized
DEBUG - 2016-10-01 22:42:02 --> Router Class Initialized
DEBUG - 2016-10-01 22:42:02 --> Output Class Initialized
DEBUG - 2016-10-01 22:42:03 --> Cache file has expired. File deleted
DEBUG - 2016-10-01 22:42:03 --> Security Class Initialized
DEBUG - 2016-10-01 22:42:03 --> Input Class Initialized
DEBUG - 2016-10-01 22:42:03 --> XSS Filtering completed
DEBUG - 2016-10-01 22:42:03 --> XSS Filtering completed
DEBUG - 2016-10-01 22:42:03 --> XSS Filtering completed
DEBUG - 2016-10-01 22:42:03 --> XSS Filtering completed
DEBUG - 2016-10-01 22:42:03 --> XSS Filtering completed
DEBUG - 2016-10-01 22:42:03 --> XSS Filtering completed
DEBUG - 2016-10-01 22:42:03 --> XSS Filtering completed
DEBUG - 2016-10-01 22:42:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-01 22:42:03 --> Language Class Initialized
DEBUG - 2016-10-01 22:42:03 --> Loader Class Initialized
DEBUG - 2016-10-01 22:42:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-01 22:42:03 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-01 22:42:03 --> Helper loaded: url_helper
DEBUG - 2016-10-01 22:42:03 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-01 22:42:03 --> Helper loaded: file_helper
DEBUG - 2016-10-01 22:42:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-01 22:42:03 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-01 22:42:03 --> Helper loaded: conf_helper
DEBUG - 2016-10-01 22:42:03 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-01 22:42:03 --> Check Exists common_helper.php: No
DEBUG - 2016-10-01 22:42:03 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-01 22:42:03 --> Helper loaded: common_helper
DEBUG - 2016-10-01 22:42:03 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-01 22:42:03 --> Helper loaded: common_helper
DEBUG - 2016-10-01 22:42:03 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-01 22:42:03 --> Helper loaded: form_helper
DEBUG - 2016-10-01 22:42:03 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-01 22:42:03 --> Helper loaded: security_helper
DEBUG - 2016-10-01 22:42:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-01 22:42:03 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-01 22:42:03 --> Helper loaded: lang_helper
DEBUG - 2016-10-01 22:42:03 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-01 22:42:03 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-01 22:42:03 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-01 22:42:03 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-01 22:42:03 --> Helper loaded: atlant_helper
DEBUG - 2016-10-01 22:42:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-01 22:42:03 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-01 22:42:03 --> Helper loaded: crypto_helper
DEBUG - 2016-10-01 22:42:03 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-01 22:42:03 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-01 22:42:03 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-01 22:42:03 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-01 22:42:03 --> Helper loaded: sidika_helper
DEBUG - 2016-10-01 22:42:03 --> Database Driver Class Initialized
DEBUG - 2016-10-01 22:42:03 --> Session Class Initialized
DEBUG - 2016-10-01 22:42:03 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-01 22:42:03 --> Helper loaded: string_helper
DEBUG - 2016-10-01 22:42:03 --> Session routines successfully run
DEBUG - 2016-10-01 22:42:03 --> Native_session Class Initialized
DEBUG - 2016-10-01 22:42:03 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-01 22:42:03 --> Form Validation Class Initialized
DEBUG - 2016-10-01 22:42:03 --> Form Validation Class Initialized
DEBUG - 2016-10-01 22:42:03 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-01 22:42:03 --> Controller Class Initialized
DEBUG - 2016-10-01 22:42:03 --> Carabiner: Library initialized.
DEBUG - 2016-10-01 22:42:03 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-01 22:42:03 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-01 22:42:03 --> Carabiner: library configured.
DEBUG - 2016-10-01 22:42:03 --> Carabiner: library configured.
DEBUG - 2016-10-01 22:42:03 --> User Agent Class Initialized
DEBUG - 2016-10-01 22:42:03 --> Model Class Initialized
DEBUG - 2016-10-01 22:42:03 --> Model Class Initialized
DEBUG - 2016-10-01 22:42:03 --> Model Class Initialized
DEBUG - 2016-10-01 22:42:03 --> Model Class Initialized
DEBUG - 2016-10-01 22:42:03 --> Model Class Initialized
DEBUG - 2016-10-01 22:42:03 --> Model Class Initialized
DEBUG - 2016-10-01 22:42:03 --> Model Class Initialized
DEBUG - 2016-10-01 22:42:04 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-10-01 22:42:04 --> Final output sent to browser
DEBUG - 2016-10-01 22:42:04 --> Total execution time: 1.4521
DEBUG - 2016-10-01 23:17:10 --> Config Class Initialized
DEBUG - 2016-10-01 23:17:10 --> Hooks Class Initialized
DEBUG - 2016-10-01 23:17:10 --> Utf8 Class Initialized
DEBUG - 2016-10-01 23:17:10 --> UTF-8 Support Enabled
DEBUG - 2016-10-01 23:17:10 --> URI Class Initialized
DEBUG - 2016-10-01 23:17:10 --> Router Class Initialized
DEBUG - 2016-10-01 23:17:10 --> Output Class Initialized
DEBUG - 2016-10-01 23:17:10 --> Cache file has expired. File deleted
DEBUG - 2016-10-01 23:17:10 --> Security Class Initialized
DEBUG - 2016-10-01 23:17:10 --> Input Class Initialized
DEBUG - 2016-10-01 23:17:10 --> XSS Filtering completed
DEBUG - 2016-10-01 23:17:10 --> XSS Filtering completed
DEBUG - 2016-10-01 23:17:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-01 23:17:10 --> Language Class Initialized
DEBUG - 2016-10-01 23:17:10 --> Loader Class Initialized
DEBUG - 2016-10-01 23:17:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-01 23:17:10 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-01 23:17:10 --> Helper loaded: url_helper
DEBUG - 2016-10-01 23:17:10 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-01 23:17:10 --> Helper loaded: file_helper
DEBUG - 2016-10-01 23:17:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-01 23:17:10 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-01 23:17:10 --> Helper loaded: conf_helper
DEBUG - 2016-10-01 23:17:10 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-01 23:17:10 --> Check Exists common_helper.php: No
DEBUG - 2016-10-01 23:17:10 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-01 23:17:10 --> Helper loaded: common_helper
DEBUG - 2016-10-01 23:17:10 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-01 23:17:10 --> Helper loaded: common_helper
DEBUG - 2016-10-01 23:17:10 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-01 23:17:10 --> Helper loaded: form_helper
DEBUG - 2016-10-01 23:17:10 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-01 23:17:10 --> Helper loaded: security_helper
DEBUG - 2016-10-01 23:17:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-01 23:17:10 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-01 23:17:10 --> Helper loaded: lang_helper
DEBUG - 2016-10-01 23:17:10 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-01 23:17:10 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-01 23:17:10 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-01 23:17:10 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-01 23:17:10 --> Helper loaded: atlant_helper
DEBUG - 2016-10-01 23:17:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-01 23:17:10 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-01 23:17:10 --> Helper loaded: crypto_helper
DEBUG - 2016-10-01 23:17:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-01 23:17:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-01 23:17:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-01 23:17:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-01 23:17:10 --> Helper loaded: sidika_helper
DEBUG - 2016-10-01 23:17:10 --> Database Driver Class Initialized
DEBUG - 2016-10-01 23:17:10 --> Session Class Initialized
DEBUG - 2016-10-01 23:17:10 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-01 23:17:10 --> Helper loaded: string_helper
DEBUG - 2016-10-01 23:17:10 --> Session routines successfully run
DEBUG - 2016-10-01 23:17:10 --> Native_session Class Initialized
DEBUG - 2016-10-01 23:17:10 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-01 23:17:10 --> Form Validation Class Initialized
DEBUG - 2016-10-01 23:17:10 --> Form Validation Class Initialized
DEBUG - 2016-10-01 23:17:10 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-01 23:17:10 --> Controller Class Initialized
DEBUG - 2016-10-01 23:17:10 --> Carabiner: Library initialized.
DEBUG - 2016-10-01 23:17:10 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-01 23:17:10 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-01 23:17:10 --> Carabiner: library configured.
DEBUG - 2016-10-01 23:17:10 --> Carabiner: library configured.
DEBUG - 2016-10-01 23:17:10 --> User Agent Class Initialized
DEBUG - 2016-10-01 23:17:10 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:10 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:10 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-10-01 23:17:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-01 23:17:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-01 23:17:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-01 23:17:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-01 23:17:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-01 23:17:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-01 23:17:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-01 23:17:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-01 23:17:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-01 23:17:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-01 23:17:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-01 23:17:10 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-01 23:17:10 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-10-01 23:17:10 --> Final output sent to browser
DEBUG - 2016-10-01 23:17:10 --> Total execution time: 0.3965
DEBUG - 2016-10-01 23:17:26 --> Config Class Initialized
DEBUG - 2016-10-01 23:17:26 --> Hooks Class Initialized
DEBUG - 2016-10-01 23:17:26 --> Utf8 Class Initialized
DEBUG - 2016-10-01 23:17:26 --> UTF-8 Support Enabled
DEBUG - 2016-10-01 23:17:26 --> URI Class Initialized
DEBUG - 2016-10-01 23:17:26 --> Router Class Initialized
DEBUG - 2016-10-01 23:17:26 --> Output Class Initialized
DEBUG - 2016-10-01 23:17:26 --> Security Class Initialized
DEBUG - 2016-10-01 23:17:26 --> Input Class Initialized
DEBUG - 2016-10-01 23:17:26 --> XSS Filtering completed
DEBUG - 2016-10-01 23:17:26 --> XSS Filtering completed
DEBUG - 2016-10-01 23:17:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-01 23:17:26 --> Language Class Initialized
DEBUG - 2016-10-01 23:17:26 --> Loader Class Initialized
DEBUG - 2016-10-01 23:17:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-01 23:17:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-01 23:17:26 --> Helper loaded: url_helper
DEBUG - 2016-10-01 23:17:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-01 23:17:26 --> Helper loaded: file_helper
DEBUG - 2016-10-01 23:17:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-01 23:17:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-01 23:17:26 --> Helper loaded: conf_helper
DEBUG - 2016-10-01 23:17:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-01 23:17:26 --> Check Exists common_helper.php: No
DEBUG - 2016-10-01 23:17:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-01 23:17:26 --> Helper loaded: common_helper
DEBUG - 2016-10-01 23:17:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-01 23:17:26 --> Helper loaded: common_helper
DEBUG - 2016-10-01 23:17:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-01 23:17:26 --> Helper loaded: form_helper
DEBUG - 2016-10-01 23:17:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-01 23:17:26 --> Helper loaded: security_helper
DEBUG - 2016-10-01 23:17:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-01 23:17:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-01 23:17:26 --> Helper loaded: lang_helper
DEBUG - 2016-10-01 23:17:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-01 23:17:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-01 23:17:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-01 23:17:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-01 23:17:26 --> Helper loaded: atlant_helper
DEBUG - 2016-10-01 23:17:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-01 23:17:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-01 23:17:26 --> Helper loaded: crypto_helper
DEBUG - 2016-10-01 23:17:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-01 23:17:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-01 23:17:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-01 23:17:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-01 23:17:26 --> Helper loaded: sidika_helper
DEBUG - 2016-10-01 23:17:26 --> Database Driver Class Initialized
DEBUG - 2016-10-01 23:17:26 --> Session Class Initialized
DEBUG - 2016-10-01 23:17:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-01 23:17:26 --> Helper loaded: string_helper
DEBUG - 2016-10-01 23:17:26 --> Session routines successfully run
DEBUG - 2016-10-01 23:17:26 --> Native_session Class Initialized
DEBUG - 2016-10-01 23:17:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-01 23:17:26 --> Form Validation Class Initialized
DEBUG - 2016-10-01 23:17:26 --> Form Validation Class Initialized
DEBUG - 2016-10-01 23:17:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-01 23:17:26 --> Controller Class Initialized
DEBUG - 2016-10-01 23:17:26 --> Carabiner: Library initialized.
DEBUG - 2016-10-01 23:17:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-01 23:17:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-01 23:17:26 --> Carabiner: library configured.
DEBUG - 2016-10-01 23:17:26 --> Carabiner: library configured.
DEBUG - 2016-10-01 23:17:26 --> User Agent Class Initialized
DEBUG - 2016-10-01 23:17:26 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:26 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:26 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:26 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:26 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:26 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:26 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:27 --> Model Class Initialized
ERROR - 2016-10-01 23:17:27 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-10-01 23:17:27 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-01 23:17:27 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-10-01 23:17:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-10-01 23:17:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-10-01 23:17:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-10-01 23:17:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-10-01 23:17:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-10-01 23:17:27 --> Final output sent to browser
DEBUG - 2016-10-01 23:17:27 --> Total execution time: 0.3807
DEBUG - 2016-10-01 23:17:27 --> Config Class Initialized
DEBUG - 2016-10-01 23:17:27 --> Hooks Class Initialized
DEBUG - 2016-10-01 23:17:27 --> Utf8 Class Initialized
DEBUG - 2016-10-01 23:17:27 --> UTF-8 Support Enabled
DEBUG - 2016-10-01 23:17:27 --> URI Class Initialized
DEBUG - 2016-10-01 23:17:27 --> Router Class Initialized
ERROR - 2016-10-01 23:17:27 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-10-01 23:17:34 --> Config Class Initialized
DEBUG - 2016-10-01 23:17:34 --> Hooks Class Initialized
DEBUG - 2016-10-01 23:17:34 --> Utf8 Class Initialized
DEBUG - 2016-10-01 23:17:34 --> UTF-8 Support Enabled
DEBUG - 2016-10-01 23:17:34 --> URI Class Initialized
DEBUG - 2016-10-01 23:17:34 --> Router Class Initialized
DEBUG - 2016-10-01 23:17:34 --> Output Class Initialized
DEBUG - 2016-10-01 23:17:34 --> Cache file has expired. File deleted
DEBUG - 2016-10-01 23:17:34 --> Security Class Initialized
DEBUG - 2016-10-01 23:17:34 --> Input Class Initialized
DEBUG - 2016-10-01 23:17:34 --> XSS Filtering completed
DEBUG - 2016-10-01 23:17:34 --> XSS Filtering completed
DEBUG - 2016-10-01 23:17:34 --> XSS Filtering completed
DEBUG - 2016-10-01 23:17:34 --> XSS Filtering completed
DEBUG - 2016-10-01 23:17:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-01 23:17:34 --> Language Class Initialized
DEBUG - 2016-10-01 23:17:34 --> Loader Class Initialized
DEBUG - 2016-10-01 23:17:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-01 23:17:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-01 23:17:34 --> Helper loaded: url_helper
DEBUG - 2016-10-01 23:17:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-01 23:17:34 --> Helper loaded: file_helper
DEBUG - 2016-10-01 23:17:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-01 23:17:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-01 23:17:34 --> Helper loaded: conf_helper
DEBUG - 2016-10-01 23:17:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-01 23:17:34 --> Check Exists common_helper.php: No
DEBUG - 2016-10-01 23:17:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-01 23:17:34 --> Helper loaded: common_helper
DEBUG - 2016-10-01 23:17:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-01 23:17:34 --> Helper loaded: common_helper
DEBUG - 2016-10-01 23:17:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-01 23:17:34 --> Helper loaded: form_helper
DEBUG - 2016-10-01 23:17:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-01 23:17:34 --> Helper loaded: security_helper
DEBUG - 2016-10-01 23:17:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-01 23:17:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-01 23:17:34 --> Helper loaded: lang_helper
DEBUG - 2016-10-01 23:17:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-01 23:17:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-01 23:17:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-01 23:17:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-01 23:17:34 --> Helper loaded: atlant_helper
DEBUG - 2016-10-01 23:17:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-01 23:17:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-01 23:17:34 --> Helper loaded: crypto_helper
DEBUG - 2016-10-01 23:17:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-01 23:17:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-01 23:17:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-01 23:17:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-01 23:17:34 --> Helper loaded: sidika_helper
DEBUG - 2016-10-01 23:17:34 --> Database Driver Class Initialized
DEBUG - 2016-10-01 23:17:34 --> Session Class Initialized
DEBUG - 2016-10-01 23:17:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-01 23:17:34 --> Helper loaded: string_helper
DEBUG - 2016-10-01 23:17:34 --> Session routines successfully run
DEBUG - 2016-10-01 23:17:34 --> Native_session Class Initialized
DEBUG - 2016-10-01 23:17:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-01 23:17:34 --> Form Validation Class Initialized
DEBUG - 2016-10-01 23:17:34 --> Form Validation Class Initialized
DEBUG - 2016-10-01 23:17:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-01 23:17:34 --> Controller Class Initialized
DEBUG - 2016-10-01 23:17:34 --> Carabiner: Library initialized.
DEBUG - 2016-10-01 23:17:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-01 23:17:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-01 23:17:34 --> Carabiner: library configured.
DEBUG - 2016-10-01 23:17:34 --> Carabiner: library configured.
DEBUG - 2016-10-01 23:17:34 --> User Agent Class Initialized
DEBUG - 2016-10-01 23:17:34 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:34 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:34 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:34 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:34 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:34 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:34 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:34 --> Model Class Initialized
ERROR - 2016-10-01 23:17:34 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-10-01 23:17:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-10-01 23:17:34 --> Form Validation Class Initialized
DEBUG - 2016-10-01 23:17:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-01 23:17:34 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-10-01 23:17:35 --> Config Class Initialized
DEBUG - 2016-10-01 23:17:35 --> Hooks Class Initialized
DEBUG - 2016-10-01 23:17:35 --> Utf8 Class Initialized
DEBUG - 2016-10-01 23:17:35 --> UTF-8 Support Enabled
DEBUG - 2016-10-01 23:17:35 --> URI Class Initialized
DEBUG - 2016-10-01 23:17:35 --> Router Class Initialized
DEBUG - 2016-10-01 23:17:35 --> No URI present. Default controller set.
DEBUG - 2016-10-01 23:17:35 --> Output Class Initialized
DEBUG - 2016-10-01 23:17:35 --> Cache file has expired. File deleted
DEBUG - 2016-10-01 23:17:35 --> Security Class Initialized
DEBUG - 2016-10-01 23:17:35 --> Input Class Initialized
DEBUG - 2016-10-01 23:17:35 --> XSS Filtering completed
DEBUG - 2016-10-01 23:17:35 --> XSS Filtering completed
DEBUG - 2016-10-01 23:17:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-01 23:17:35 --> Language Class Initialized
DEBUG - 2016-10-01 23:17:35 --> Loader Class Initialized
DEBUG - 2016-10-01 23:17:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-01 23:17:35 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-01 23:17:35 --> Helper loaded: url_helper
DEBUG - 2016-10-01 23:17:35 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-01 23:17:35 --> Helper loaded: file_helper
DEBUG - 2016-10-01 23:17:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-01 23:17:35 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-01 23:17:35 --> Helper loaded: conf_helper
DEBUG - 2016-10-01 23:17:35 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-01 23:17:35 --> Check Exists common_helper.php: No
DEBUG - 2016-10-01 23:17:35 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-01 23:17:35 --> Helper loaded: common_helper
DEBUG - 2016-10-01 23:17:35 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-01 23:17:35 --> Helper loaded: common_helper
DEBUG - 2016-10-01 23:17:35 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-01 23:17:35 --> Helper loaded: form_helper
DEBUG - 2016-10-01 23:17:35 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-01 23:17:35 --> Helper loaded: security_helper
DEBUG - 2016-10-01 23:17:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-01 23:17:35 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-01 23:17:35 --> Helper loaded: lang_helper
DEBUG - 2016-10-01 23:17:35 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-01 23:17:35 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-01 23:17:35 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-01 23:17:35 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-01 23:17:35 --> Helper loaded: atlant_helper
DEBUG - 2016-10-01 23:17:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-01 23:17:35 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-01 23:17:35 --> Helper loaded: crypto_helper
DEBUG - 2016-10-01 23:17:35 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-01 23:17:35 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-01 23:17:35 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-01 23:17:35 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-01 23:17:35 --> Helper loaded: sidika_helper
DEBUG - 2016-10-01 23:17:35 --> Database Driver Class Initialized
DEBUG - 2016-10-01 23:17:35 --> Session Class Initialized
DEBUG - 2016-10-01 23:17:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-01 23:17:35 --> Helper loaded: string_helper
DEBUG - 2016-10-01 23:17:35 --> Session routines successfully run
DEBUG - 2016-10-01 23:17:35 --> Native_session Class Initialized
DEBUG - 2016-10-01 23:17:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-01 23:17:35 --> Form Validation Class Initialized
DEBUG - 2016-10-01 23:17:35 --> Form Validation Class Initialized
DEBUG - 2016-10-01 23:17:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-01 23:17:35 --> Controller Class Initialized
DEBUG - 2016-10-01 23:17:35 --> Carabiner: Library initialized.
DEBUG - 2016-10-01 23:17:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-01 23:17:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-01 23:17:35 --> Carabiner: library configured.
DEBUG - 2016-10-01 23:17:35 --> Carabiner: library configured.
DEBUG - 2016-10-01 23:17:35 --> User Agent Class Initialized
DEBUG - 2016-10-01 23:17:35 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:35 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:35 --> Model Class Initialized
ERROR - 2016-10-01 23:17:35 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-10-01 23:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-10-01 23:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-10-01 23:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-01 23:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-01 23:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-01 23:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-01 23:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-01 23:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-01 23:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-01 23:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-01 23:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-01 23:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-01 23:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-01 23:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-01 23:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-01 23:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-01 23:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-01 23:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-01 23:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-01 23:17:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-01 23:17:35 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-10-01 23:17:35 --> Final output sent to browser
DEBUG - 2016-10-01 23:17:35 --> Total execution time: 0.2756
DEBUG - 2016-10-01 23:17:36 --> Config Class Initialized
DEBUG - 2016-10-01 23:17:36 --> Hooks Class Initialized
DEBUG - 2016-10-01 23:17:36 --> Utf8 Class Initialized
DEBUG - 2016-10-01 23:17:36 --> UTF-8 Support Enabled
DEBUG - 2016-10-01 23:17:36 --> URI Class Initialized
DEBUG - 2016-10-01 23:17:36 --> Router Class Initialized
DEBUG - 2016-10-01 23:17:36 --> Output Class Initialized
DEBUG - 2016-10-01 23:17:36 --> Cache file has expired. File deleted
DEBUG - 2016-10-01 23:17:36 --> Security Class Initialized
DEBUG - 2016-10-01 23:17:36 --> Input Class Initialized
DEBUG - 2016-10-01 23:17:36 --> XSS Filtering completed
DEBUG - 2016-10-01 23:17:36 --> XSS Filtering completed
DEBUG - 2016-10-01 23:17:36 --> XSS Filtering completed
DEBUG - 2016-10-01 23:17:36 --> XSS Filtering completed
DEBUG - 2016-10-01 23:17:36 --> XSS Filtering completed
DEBUG - 2016-10-01 23:17:36 --> XSS Filtering completed
DEBUG - 2016-10-01 23:17:36 --> XSS Filtering completed
DEBUG - 2016-10-01 23:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-01 23:17:36 --> Language Class Initialized
DEBUG - 2016-10-01 23:17:36 --> Loader Class Initialized
DEBUG - 2016-10-01 23:17:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-01 23:17:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-01 23:17:36 --> Helper loaded: url_helper
DEBUG - 2016-10-01 23:17:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-01 23:17:36 --> Helper loaded: file_helper
DEBUG - 2016-10-01 23:17:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-01 23:17:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-01 23:17:36 --> Helper loaded: conf_helper
DEBUG - 2016-10-01 23:17:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-01 23:17:36 --> Check Exists common_helper.php: No
DEBUG - 2016-10-01 23:17:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-01 23:17:36 --> Helper loaded: common_helper
DEBUG - 2016-10-01 23:17:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-01 23:17:36 --> Helper loaded: common_helper
DEBUG - 2016-10-01 23:17:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-01 23:17:36 --> Helper loaded: form_helper
DEBUG - 2016-10-01 23:17:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-01 23:17:36 --> Helper loaded: security_helper
DEBUG - 2016-10-01 23:17:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-01 23:17:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-01 23:17:36 --> Helper loaded: lang_helper
DEBUG - 2016-10-01 23:17:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-01 23:17:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-01 23:17:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-01 23:17:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-01 23:17:36 --> Helper loaded: atlant_helper
DEBUG - 2016-10-01 23:17:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-01 23:17:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-01 23:17:36 --> Helper loaded: crypto_helper
DEBUG - 2016-10-01 23:17:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-01 23:17:36 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-01 23:17:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-01 23:17:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-01 23:17:36 --> Helper loaded: sidika_helper
DEBUG - 2016-10-01 23:17:36 --> Database Driver Class Initialized
DEBUG - 2016-10-01 23:17:36 --> Session Class Initialized
DEBUG - 2016-10-01 23:17:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-01 23:17:36 --> Helper loaded: string_helper
DEBUG - 2016-10-01 23:17:36 --> Session routines successfully run
DEBUG - 2016-10-01 23:17:36 --> Native_session Class Initialized
DEBUG - 2016-10-01 23:17:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-01 23:17:36 --> Form Validation Class Initialized
DEBUG - 2016-10-01 23:17:36 --> Form Validation Class Initialized
DEBUG - 2016-10-01 23:17:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-01 23:17:36 --> Controller Class Initialized
DEBUG - 2016-10-01 23:17:36 --> Carabiner: Library initialized.
DEBUG - 2016-10-01 23:17:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-01 23:17:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-01 23:17:36 --> Carabiner: library configured.
DEBUG - 2016-10-01 23:17:36 --> Carabiner: library configured.
DEBUG - 2016-10-01 23:17:36 --> User Agent Class Initialized
DEBUG - 2016-10-01 23:17:36 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:36 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:36 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:36 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:36 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:36 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:36 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:36 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-10-01 23:17:36 --> Final output sent to browser
DEBUG - 2016-10-01 23:17:36 --> Total execution time: 0.3412
DEBUG - 2016-10-01 23:17:40 --> Config Class Initialized
DEBUG - 2016-10-01 23:17:40 --> Hooks Class Initialized
DEBUG - 2016-10-01 23:17:40 --> Utf8 Class Initialized
DEBUG - 2016-10-01 23:17:40 --> UTF-8 Support Enabled
DEBUG - 2016-10-01 23:17:40 --> URI Class Initialized
DEBUG - 2016-10-01 23:17:40 --> Router Class Initialized
DEBUG - 2016-10-01 23:17:40 --> Output Class Initialized
DEBUG - 2016-10-01 23:17:40 --> Cache file has expired. File deleted
DEBUG - 2016-10-01 23:17:40 --> Security Class Initialized
DEBUG - 2016-10-01 23:17:40 --> Input Class Initialized
DEBUG - 2016-10-01 23:17:40 --> XSS Filtering completed
DEBUG - 2016-10-01 23:17:40 --> XSS Filtering completed
DEBUG - 2016-10-01 23:17:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-01 23:17:40 --> Language Class Initialized
DEBUG - 2016-10-01 23:17:40 --> Loader Class Initialized
DEBUG - 2016-10-01 23:17:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-01 23:17:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-01 23:17:40 --> Helper loaded: url_helper
DEBUG - 2016-10-01 23:17:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-01 23:17:40 --> Helper loaded: file_helper
DEBUG - 2016-10-01 23:17:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-01 23:17:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-01 23:17:40 --> Helper loaded: conf_helper
DEBUG - 2016-10-01 23:17:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-01 23:17:40 --> Check Exists common_helper.php: No
DEBUG - 2016-10-01 23:17:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-01 23:17:40 --> Helper loaded: common_helper
DEBUG - 2016-10-01 23:17:40 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-01 23:17:40 --> Helper loaded: common_helper
DEBUG - 2016-10-01 23:17:40 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-01 23:17:40 --> Helper loaded: form_helper
DEBUG - 2016-10-01 23:17:40 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-01 23:17:40 --> Helper loaded: security_helper
DEBUG - 2016-10-01 23:17:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-01 23:17:40 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-01 23:17:40 --> Helper loaded: lang_helper
DEBUG - 2016-10-01 23:17:40 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-01 23:17:40 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-01 23:17:40 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-01 23:17:40 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-01 23:17:40 --> Helper loaded: atlant_helper
DEBUG - 2016-10-01 23:17:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-01 23:17:40 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-01 23:17:40 --> Helper loaded: crypto_helper
DEBUG - 2016-10-01 23:17:40 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-01 23:17:40 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-01 23:17:40 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-01 23:17:40 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-01 23:17:40 --> Helper loaded: sidika_helper
DEBUG - 2016-10-01 23:17:40 --> Database Driver Class Initialized
DEBUG - 2016-10-01 23:17:40 --> Session Class Initialized
DEBUG - 2016-10-01 23:17:40 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-01 23:17:40 --> Helper loaded: string_helper
DEBUG - 2016-10-01 23:17:40 --> Session routines successfully run
DEBUG - 2016-10-01 23:17:40 --> Native_session Class Initialized
DEBUG - 2016-10-01 23:17:40 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-01 23:17:40 --> Form Validation Class Initialized
DEBUG - 2016-10-01 23:17:40 --> Form Validation Class Initialized
DEBUG - 2016-10-01 23:17:40 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-01 23:17:40 --> Controller Class Initialized
DEBUG - 2016-10-01 23:17:40 --> Carabiner: Library initialized.
DEBUG - 2016-10-01 23:17:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-01 23:17:40 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-01 23:17:40 --> Carabiner: library configured.
DEBUG - 2016-10-01 23:17:40 --> Carabiner: library configured.
DEBUG - 2016-10-01 23:17:40 --> User Agent Class Initialized
DEBUG - 2016-10-01 23:17:40 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:40 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:40 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-10-01 23:17:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-01 23:17:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-01 23:17:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-01 23:17:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-01 23:17:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-01 23:17:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-01 23:17:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-01 23:17:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-01 23:17:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-01 23:17:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-01 23:17:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-01 23:17:40 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-01 23:17:40 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-10-01 23:17:40 --> Final output sent to browser
DEBUG - 2016-10-01 23:17:40 --> Total execution time: 0.2819
DEBUG - 2016-10-01 23:17:44 --> Config Class Initialized
DEBUG - 2016-10-01 23:17:44 --> Hooks Class Initialized
DEBUG - 2016-10-01 23:17:44 --> Utf8 Class Initialized
DEBUG - 2016-10-01 23:17:44 --> UTF-8 Support Enabled
DEBUG - 2016-10-01 23:17:44 --> URI Class Initialized
DEBUG - 2016-10-01 23:17:44 --> Router Class Initialized
DEBUG - 2016-10-01 23:17:44 --> Output Class Initialized
DEBUG - 2016-10-01 23:17:44 --> Cache file has expired. File deleted
DEBUG - 2016-10-01 23:17:44 --> Security Class Initialized
DEBUG - 2016-10-01 23:17:45 --> Input Class Initialized
DEBUG - 2016-10-01 23:17:45 --> XSS Filtering completed
DEBUG - 2016-10-01 23:17:45 --> XSS Filtering completed
DEBUG - 2016-10-01 23:17:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-01 23:17:45 --> Language Class Initialized
DEBUG - 2016-10-01 23:17:45 --> Loader Class Initialized
DEBUG - 2016-10-01 23:17:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-01 23:17:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-01 23:17:45 --> Helper loaded: url_helper
DEBUG - 2016-10-01 23:17:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-01 23:17:45 --> Helper loaded: file_helper
DEBUG - 2016-10-01 23:17:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-01 23:17:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-01 23:17:45 --> Helper loaded: conf_helper
DEBUG - 2016-10-01 23:17:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-01 23:17:45 --> Check Exists common_helper.php: No
DEBUG - 2016-10-01 23:17:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-01 23:17:45 --> Helper loaded: common_helper
DEBUG - 2016-10-01 23:17:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-01 23:17:45 --> Helper loaded: common_helper
DEBUG - 2016-10-01 23:17:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-01 23:17:45 --> Helper loaded: form_helper
DEBUG - 2016-10-01 23:17:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-01 23:17:45 --> Helper loaded: security_helper
DEBUG - 2016-10-01 23:17:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-01 23:17:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-01 23:17:45 --> Helper loaded: lang_helper
DEBUG - 2016-10-01 23:17:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-01 23:17:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-01 23:17:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-01 23:17:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-01 23:17:45 --> Helper loaded: atlant_helper
DEBUG - 2016-10-01 23:17:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-01 23:17:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-01 23:17:45 --> Helper loaded: crypto_helper
DEBUG - 2016-10-01 23:17:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-01 23:17:45 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-01 23:17:45 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-01 23:17:45 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-01 23:17:45 --> Helper loaded: sidika_helper
DEBUG - 2016-10-01 23:17:45 --> Database Driver Class Initialized
DEBUG - 2016-10-01 23:17:45 --> Session Class Initialized
DEBUG - 2016-10-01 23:17:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-01 23:17:45 --> Helper loaded: string_helper
DEBUG - 2016-10-01 23:17:45 --> Session routines successfully run
DEBUG - 2016-10-01 23:17:45 --> Native_session Class Initialized
DEBUG - 2016-10-01 23:17:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-01 23:17:45 --> Form Validation Class Initialized
DEBUG - 2016-10-01 23:17:45 --> Form Validation Class Initialized
DEBUG - 2016-10-01 23:17:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-01 23:17:45 --> Controller Class Initialized
DEBUG - 2016-10-01 23:17:45 --> Carabiner: Library initialized.
DEBUG - 2016-10-01 23:17:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-01 23:17:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-01 23:17:45 --> Carabiner: library configured.
DEBUG - 2016-10-01 23:17:45 --> Carabiner: library configured.
DEBUG - 2016-10-01 23:17:45 --> User Agent Class Initialized
DEBUG - 2016-10-01 23:17:45 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:45 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:45 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:45 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:45 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:45 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:45 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:45 --> Model Class Initialized
DEBUG - 2016-10-01 23:17:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-01 23:17:45 --> Pagination Class Initialized
DEBUG - 2016-10-01 23:17:45 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-01 23:17:45 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/index.php
DEBUG - 2016-10-01 23:17:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-01 23:17:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-01 23:17:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-01 23:17:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-01 23:17:45 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-01 23:17:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-01 23:17:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-01 23:17:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-01 23:17:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-01 23:17:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-01 23:17:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-01 23:17:45 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-01 23:17:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-01 23:17:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-01 23:17:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55961f1d1ca16fdfc4239ae1901a174e
DEBUG - 2016-10-01 23:17:45 --> Final output sent to browser
DEBUG - 2016-10-01 23:17:45 --> Total execution time: 0.5355
