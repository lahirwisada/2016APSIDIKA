<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-10-09 01:12:24 --> Config Class Initialized
DEBUG - 2016-10-09 01:12:24 --> Hooks Class Initialized
DEBUG - 2016-10-09 01:12:24 --> Utf8 Class Initialized
DEBUG - 2016-10-09 01:12:25 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 01:12:25 --> URI Class Initialized
DEBUG - 2016-10-09 01:12:25 --> Router Class Initialized
DEBUG - 2016-10-09 01:12:25 --> No URI present. Default controller set.
DEBUG - 2016-10-09 01:12:25 --> Output Class Initialized
DEBUG - 2016-10-09 01:12:25 --> Cache file has expired. File deleted
DEBUG - 2016-10-09 01:12:25 --> Security Class Initialized
DEBUG - 2016-10-09 01:12:25 --> Input Class Initialized
DEBUG - 2016-10-09 01:12:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-09 01:12:25 --> Language Class Initialized
DEBUG - 2016-10-09 01:12:25 --> Loader Class Initialized
DEBUG - 2016-10-09 01:12:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-09 01:12:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-09 01:12:25 --> Helper loaded: url_helper
DEBUG - 2016-10-09 01:12:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-09 01:12:25 --> Helper loaded: file_helper
DEBUG - 2016-10-09 01:12:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:12:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-09 01:12:25 --> Helper loaded: conf_helper
DEBUG - 2016-10-09 01:12:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:12:25 --> Check Exists common_helper.php: No
DEBUG - 2016-10-09 01:12:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-09 01:12:25 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:12:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-09 01:12:25 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:12:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-09 01:12:25 --> Helper loaded: form_helper
DEBUG - 2016-10-09 01:12:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-09 01:12:25 --> Helper loaded: security_helper
DEBUG - 2016-10-09 01:12:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:12:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-09 01:12:25 --> Helper loaded: lang_helper
DEBUG - 2016-10-09 01:12:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:12:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-09 01:12:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-09 01:12:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-09 01:12:25 --> Helper loaded: atlant_helper
DEBUG - 2016-10-09 01:12:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:12:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-09 01:12:25 --> Helper loaded: crypto_helper
DEBUG - 2016-10-09 01:12:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:12:25 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-09 01:12:25 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-09 01:12:25 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-09 01:12:25 --> Helper loaded: sidika_helper
DEBUG - 2016-10-09 01:12:25 --> Database Driver Class Initialized
DEBUG - 2016-10-09 01:12:25 --> Session Class Initialized
DEBUG - 2016-10-09 01:12:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-09 01:12:25 --> Helper loaded: string_helper
DEBUG - 2016-10-09 01:12:25 --> A session cookie was not found.
DEBUG - 2016-10-09 01:12:25 --> Session routines successfully run
DEBUG - 2016-10-09 01:12:25 --> Native_session Class Initialized
DEBUG - 2016-10-09 01:12:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-09 01:12:25 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:12:25 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:12:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 01:12:25 --> Controller Class Initialized
DEBUG - 2016-10-09 01:12:25 --> Carabiner: Library initialized.
DEBUG - 2016-10-09 01:12:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-09 01:12:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-09 01:12:25 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:12:25 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:12:25 --> User Agent Class Initialized
DEBUG - 2016-10-09 01:12:25 --> Model Class Initialized
DEBUG - 2016-10-09 01:12:25 --> Model Class Initialized
DEBUG - 2016-10-09 01:12:25 --> Model Class Initialized
ERROR - 2016-10-09 01:12:25 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-10-09 01:12:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-10-09 01:12:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-10-09 01:12:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-09 01:12:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 01:12:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-09 01:12:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-09 01:12:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-09 01:12:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-09 01:12:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-09 01:12:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 01:12:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-09 01:12:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-09 01:12:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 01:12:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-09 01:12:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-09 01:12:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-09 01:12:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-09 01:12:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-09 01:12:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 01:12:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-09 01:12:25 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-10-09 01:12:25 --> Final output sent to browser
DEBUG - 2016-10-09 01:12:25 --> Total execution time: 0.6164
DEBUG - 2016-10-09 01:12:27 --> Config Class Initialized
DEBUG - 2016-10-09 01:12:27 --> Hooks Class Initialized
DEBUG - 2016-10-09 01:12:27 --> Utf8 Class Initialized
DEBUG - 2016-10-09 01:12:27 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 01:12:27 --> URI Class Initialized
DEBUG - 2016-10-09 01:12:27 --> Router Class Initialized
DEBUG - 2016-10-09 01:12:27 --> Output Class Initialized
DEBUG - 2016-10-09 01:12:27 --> Cache file has expired. File deleted
DEBUG - 2016-10-09 01:12:27 --> Security Class Initialized
DEBUG - 2016-10-09 01:12:27 --> Input Class Initialized
DEBUG - 2016-10-09 01:12:27 --> XSS Filtering completed
DEBUG - 2016-10-09 01:12:27 --> XSS Filtering completed
DEBUG - 2016-10-09 01:12:27 --> XSS Filtering completed
DEBUG - 2016-10-09 01:12:27 --> XSS Filtering completed
DEBUG - 2016-10-09 01:12:27 --> XSS Filtering completed
DEBUG - 2016-10-09 01:12:27 --> XSS Filtering completed
DEBUG - 2016-10-09 01:12:27 --> XSS Filtering completed
DEBUG - 2016-10-09 01:12:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-09 01:12:27 --> Language Class Initialized
DEBUG - 2016-10-09 01:12:27 --> Loader Class Initialized
DEBUG - 2016-10-09 01:12:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-09 01:12:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-09 01:12:27 --> Helper loaded: url_helper
DEBUG - 2016-10-09 01:12:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-09 01:12:27 --> Helper loaded: file_helper
DEBUG - 2016-10-09 01:12:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:12:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-09 01:12:27 --> Helper loaded: conf_helper
DEBUG - 2016-10-09 01:12:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:12:27 --> Check Exists common_helper.php: No
DEBUG - 2016-10-09 01:12:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-09 01:12:27 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:12:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-09 01:12:27 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:12:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-09 01:12:27 --> Helper loaded: form_helper
DEBUG - 2016-10-09 01:12:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-09 01:12:27 --> Helper loaded: security_helper
DEBUG - 2016-10-09 01:12:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:12:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-09 01:12:27 --> Helper loaded: lang_helper
DEBUG - 2016-10-09 01:12:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:12:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-09 01:12:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-09 01:12:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-09 01:12:27 --> Helper loaded: atlant_helper
DEBUG - 2016-10-09 01:12:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:12:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-09 01:12:27 --> Helper loaded: crypto_helper
DEBUG - 2016-10-09 01:12:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:12:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-09 01:12:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-09 01:12:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-09 01:12:27 --> Helper loaded: sidika_helper
DEBUG - 2016-10-09 01:12:27 --> Database Driver Class Initialized
DEBUG - 2016-10-09 01:12:27 --> Session Class Initialized
DEBUG - 2016-10-09 01:12:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-09 01:12:27 --> Helper loaded: string_helper
DEBUG - 2016-10-09 01:12:27 --> Session routines successfully run
DEBUG - 2016-10-09 01:12:27 --> Native_session Class Initialized
DEBUG - 2016-10-09 01:12:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-09 01:12:27 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:12:27 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:12:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 01:12:27 --> Controller Class Initialized
DEBUG - 2016-10-09 01:12:27 --> Carabiner: Library initialized.
DEBUG - 2016-10-09 01:12:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-09 01:12:27 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-09 01:12:27 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:12:27 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:12:27 --> User Agent Class Initialized
DEBUG - 2016-10-09 01:12:27 --> Model Class Initialized
DEBUG - 2016-10-09 01:12:27 --> Model Class Initialized
DEBUG - 2016-10-09 01:12:27 --> Model Class Initialized
DEBUG - 2016-10-09 01:12:27 --> Model Class Initialized
DEBUG - 2016-10-09 01:12:27 --> Model Class Initialized
DEBUG - 2016-10-09 01:12:27 --> Model Class Initialized
DEBUG - 2016-10-09 01:12:27 --> Model Class Initialized
DEBUG - 2016-10-09 01:12:28 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-10-09 01:12:28 --> Final output sent to browser
DEBUG - 2016-10-09 01:12:28 --> Total execution time: 0.6358
DEBUG - 2016-10-09 01:16:12 --> Config Class Initialized
DEBUG - 2016-10-09 01:16:12 --> Hooks Class Initialized
DEBUG - 2016-10-09 01:16:12 --> Utf8 Class Initialized
DEBUG - 2016-10-09 01:16:12 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 01:16:12 --> URI Class Initialized
DEBUG - 2016-10-09 01:16:12 --> Router Class Initialized
DEBUG - 2016-10-09 01:16:12 --> Output Class Initialized
DEBUG - 2016-10-09 01:16:12 --> Security Class Initialized
DEBUG - 2016-10-09 01:16:12 --> Input Class Initialized
DEBUG - 2016-10-09 01:16:12 --> XSS Filtering completed
DEBUG - 2016-10-09 01:16:12 --> XSS Filtering completed
DEBUG - 2016-10-09 01:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-09 01:16:12 --> Language Class Initialized
DEBUG - 2016-10-09 01:16:12 --> Loader Class Initialized
DEBUG - 2016-10-09 01:16:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-09 01:16:12 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-09 01:16:12 --> Helper loaded: url_helper
DEBUG - 2016-10-09 01:16:12 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-09 01:16:12 --> Helper loaded: file_helper
DEBUG - 2016-10-09 01:16:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:16:12 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-09 01:16:12 --> Helper loaded: conf_helper
DEBUG - 2016-10-09 01:16:12 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:16:12 --> Check Exists common_helper.php: No
DEBUG - 2016-10-09 01:16:12 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-09 01:16:12 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:16:12 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-09 01:16:12 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:16:12 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-09 01:16:12 --> Helper loaded: form_helper
DEBUG - 2016-10-09 01:16:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-09 01:16:12 --> Helper loaded: security_helper
DEBUG - 2016-10-09 01:16:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:16:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-09 01:16:12 --> Helper loaded: lang_helper
DEBUG - 2016-10-09 01:16:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:16:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-09 01:16:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-09 01:16:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-09 01:16:12 --> Helper loaded: atlant_helper
DEBUG - 2016-10-09 01:16:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:16:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-09 01:16:12 --> Helper loaded: crypto_helper
DEBUG - 2016-10-09 01:16:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:16:12 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-09 01:16:12 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-09 01:16:12 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-09 01:16:12 --> Helper loaded: sidika_helper
DEBUG - 2016-10-09 01:16:12 --> Database Driver Class Initialized
DEBUG - 2016-10-09 01:16:12 --> Session Class Initialized
DEBUG - 2016-10-09 01:16:12 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-09 01:16:12 --> Helper loaded: string_helper
DEBUG - 2016-10-09 01:16:12 --> Session routines successfully run
DEBUG - 2016-10-09 01:16:12 --> Native_session Class Initialized
DEBUG - 2016-10-09 01:16:12 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-09 01:16:12 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:16:12 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:16:12 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 01:16:12 --> Controller Class Initialized
DEBUG - 2016-10-09 01:16:12 --> Carabiner: Library initialized.
DEBUG - 2016-10-09 01:16:12 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-09 01:16:12 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-09 01:16:12 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:16:12 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:16:12 --> User Agent Class Initialized
DEBUG - 2016-10-09 01:16:12 --> Model Class Initialized
DEBUG - 2016-10-09 01:16:12 --> Model Class Initialized
DEBUG - 2016-10-09 01:16:12 --> Model Class Initialized
ERROR - 2016-10-09 01:16:12 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-10-09 01:16:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-10-09 01:16:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-09 01:16:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 01:16:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-09 01:16:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-09 01:16:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-09 01:16:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 01:16:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-09 01:16:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-09 01:16:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 01:16:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-09 01:16:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-09 01:16:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-09 01:16:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 01:16:12 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-09 01:16:12 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-10-09 01:16:12 --> Final output sent to browser
DEBUG - 2016-10-09 01:16:12 --> Total execution time: 0.1997
DEBUG - 2016-10-09 01:17:44 --> Config Class Initialized
DEBUG - 2016-10-09 01:17:44 --> Hooks Class Initialized
DEBUG - 2016-10-09 01:17:44 --> Utf8 Class Initialized
DEBUG - 2016-10-09 01:17:44 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 01:17:44 --> URI Class Initialized
DEBUG - 2016-10-09 01:17:44 --> Router Class Initialized
DEBUG - 2016-10-09 01:17:44 --> Output Class Initialized
DEBUG - 2016-10-09 01:17:44 --> Cache file has expired. File deleted
DEBUG - 2016-10-09 01:17:44 --> Security Class Initialized
DEBUG - 2016-10-09 01:17:44 --> Input Class Initialized
DEBUG - 2016-10-09 01:17:44 --> XSS Filtering completed
DEBUG - 2016-10-09 01:17:44 --> XSS Filtering completed
DEBUG - 2016-10-09 01:17:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-09 01:17:44 --> Language Class Initialized
DEBUG - 2016-10-09 01:17:44 --> Loader Class Initialized
DEBUG - 2016-10-09 01:17:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-09 01:17:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-09 01:17:44 --> Helper loaded: url_helper
DEBUG - 2016-10-09 01:17:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-09 01:17:44 --> Helper loaded: file_helper
DEBUG - 2016-10-09 01:17:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:17:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-09 01:17:44 --> Helper loaded: conf_helper
DEBUG - 2016-10-09 01:17:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:17:44 --> Check Exists common_helper.php: No
DEBUG - 2016-10-09 01:17:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-09 01:17:44 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:17:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-09 01:17:44 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:17:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-09 01:17:44 --> Helper loaded: form_helper
DEBUG - 2016-10-09 01:17:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-09 01:17:44 --> Helper loaded: security_helper
DEBUG - 2016-10-09 01:17:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:17:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-09 01:17:44 --> Helper loaded: lang_helper
DEBUG - 2016-10-09 01:17:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:17:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-09 01:17:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-09 01:17:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-09 01:17:44 --> Helper loaded: atlant_helper
DEBUG - 2016-10-09 01:17:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:17:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-09 01:17:44 --> Helper loaded: crypto_helper
DEBUG - 2016-10-09 01:17:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:17:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-09 01:17:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-09 01:17:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-09 01:17:44 --> Helper loaded: sidika_helper
DEBUG - 2016-10-09 01:17:44 --> Database Driver Class Initialized
DEBUG - 2016-10-09 01:17:44 --> Session Class Initialized
DEBUG - 2016-10-09 01:17:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-09 01:17:44 --> Helper loaded: string_helper
DEBUG - 2016-10-09 01:17:44 --> Session routines successfully run
DEBUG - 2016-10-09 01:17:44 --> Native_session Class Initialized
DEBUG - 2016-10-09 01:17:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-09 01:17:44 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:17:44 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:17:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 01:17:44 --> Controller Class Initialized
DEBUG - 2016-10-09 01:17:44 --> Carabiner: Library initialized.
DEBUG - 2016-10-09 01:17:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-09 01:17:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-09 01:17:44 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:17:44 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:17:44 --> User Agent Class Initialized
DEBUG - 2016-10-09 01:17:44 --> Model Class Initialized
DEBUG - 2016-10-09 01:17:44 --> Model Class Initialized
DEBUG - 2016-10-09 01:17:44 --> Model Class Initialized
DEBUG - 2016-10-09 01:17:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-10-09 01:17:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-09 01:17:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-09 01:17:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 01:17:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-09 01:17:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 01:17:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-09 01:17:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-09 01:17:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-09 01:17:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 01:17:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-09 01:17:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 01:17:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-09 01:17:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-10-09 01:17:45 --> Final output sent to browser
DEBUG - 2016-10-09 01:17:45 --> Total execution time: 0.7880
DEBUG - 2016-10-09 01:17:54 --> Config Class Initialized
DEBUG - 2016-10-09 01:17:54 --> Hooks Class Initialized
DEBUG - 2016-10-09 01:17:54 --> Utf8 Class Initialized
DEBUG - 2016-10-09 01:17:54 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 01:17:54 --> URI Class Initialized
DEBUG - 2016-10-09 01:17:54 --> Router Class Initialized
DEBUG - 2016-10-09 01:17:55 --> Output Class Initialized
DEBUG - 2016-10-09 01:17:55 --> Security Class Initialized
DEBUG - 2016-10-09 01:17:55 --> Input Class Initialized
DEBUG - 2016-10-09 01:17:55 --> XSS Filtering completed
DEBUG - 2016-10-09 01:17:55 --> XSS Filtering completed
DEBUG - 2016-10-09 01:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-09 01:17:55 --> Language Class Initialized
DEBUG - 2016-10-09 01:17:55 --> Loader Class Initialized
DEBUG - 2016-10-09 01:17:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-09 01:17:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-09 01:17:55 --> Helper loaded: url_helper
DEBUG - 2016-10-09 01:17:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-09 01:17:55 --> Helper loaded: file_helper
DEBUG - 2016-10-09 01:17:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:17:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-09 01:17:55 --> Helper loaded: conf_helper
DEBUG - 2016-10-09 01:17:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:17:55 --> Check Exists common_helper.php: No
DEBUG - 2016-10-09 01:17:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-09 01:17:55 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:17:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-09 01:17:55 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:17:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-09 01:17:55 --> Helper loaded: form_helper
DEBUG - 2016-10-09 01:17:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-09 01:17:55 --> Helper loaded: security_helper
DEBUG - 2016-10-09 01:17:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:17:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-09 01:17:55 --> Helper loaded: lang_helper
DEBUG - 2016-10-09 01:17:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:17:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-09 01:17:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-09 01:17:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-09 01:17:55 --> Helper loaded: atlant_helper
DEBUG - 2016-10-09 01:17:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:17:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-09 01:17:55 --> Helper loaded: crypto_helper
DEBUG - 2016-10-09 01:17:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:17:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-09 01:17:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-09 01:17:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-09 01:17:55 --> Helper loaded: sidika_helper
DEBUG - 2016-10-09 01:17:55 --> Database Driver Class Initialized
DEBUG - 2016-10-09 01:17:55 --> Session Class Initialized
DEBUG - 2016-10-09 01:17:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-09 01:17:55 --> Helper loaded: string_helper
DEBUG - 2016-10-09 01:17:55 --> Session routines successfully run
DEBUG - 2016-10-09 01:17:55 --> Native_session Class Initialized
DEBUG - 2016-10-09 01:17:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-09 01:17:55 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:17:55 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:17:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 01:17:55 --> Controller Class Initialized
DEBUG - 2016-10-09 01:17:55 --> Carabiner: Library initialized.
DEBUG - 2016-10-09 01:17:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-09 01:17:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-09 01:17:55 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:17:55 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:17:55 --> User Agent Class Initialized
DEBUG - 2016-10-09 01:17:55 --> Model Class Initialized
DEBUG - 2016-10-09 01:17:55 --> Model Class Initialized
DEBUG - 2016-10-09 01:17:55 --> Model Class Initialized
DEBUG - 2016-10-09 01:17:55 --> Model Class Initialized
DEBUG - 2016-10-09 01:17:56 --> Model Class Initialized
DEBUG - 2016-10-09 01:17:56 --> Model Class Initialized
DEBUG - 2016-10-09 01:17:56 --> Model Class Initialized
DEBUG - 2016-10-09 01:17:56 --> Model Class Initialized
ERROR - 2016-10-09 01:17:56 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-10-09 01:17:56 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-09 01:17:56 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-10-09 01:17:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-10-09 01:17:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-10-09 01:17:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-10-09 01:17:56 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-10-09 01:17:56 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-10-09 01:17:56 --> Final output sent to browser
DEBUG - 2016-10-09 01:17:56 --> Total execution time: 1.6529
DEBUG - 2016-10-09 01:17:56 --> Config Class Initialized
DEBUG - 2016-10-09 01:17:56 --> Hooks Class Initialized
DEBUG - 2016-10-09 01:17:56 --> Utf8 Class Initialized
DEBUG - 2016-10-09 01:17:56 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 01:17:56 --> URI Class Initialized
DEBUG - 2016-10-09 01:17:56 --> Router Class Initialized
ERROR - 2016-10-09 01:17:57 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-10-09 01:18:04 --> Config Class Initialized
DEBUG - 2016-10-09 01:18:04 --> Hooks Class Initialized
DEBUG - 2016-10-09 01:18:04 --> Utf8 Class Initialized
DEBUG - 2016-10-09 01:18:04 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 01:18:04 --> URI Class Initialized
DEBUG - 2016-10-09 01:18:04 --> Router Class Initialized
DEBUG - 2016-10-09 01:18:04 --> Output Class Initialized
DEBUG - 2016-10-09 01:18:04 --> Cache file has expired. File deleted
DEBUG - 2016-10-09 01:18:04 --> Security Class Initialized
DEBUG - 2016-10-09 01:18:04 --> Input Class Initialized
DEBUG - 2016-10-09 01:18:04 --> XSS Filtering completed
DEBUG - 2016-10-09 01:18:04 --> XSS Filtering completed
DEBUG - 2016-10-09 01:18:04 --> XSS Filtering completed
DEBUG - 2016-10-09 01:18:04 --> XSS Filtering completed
DEBUG - 2016-10-09 01:18:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-09 01:18:04 --> Language Class Initialized
DEBUG - 2016-10-09 01:18:04 --> Loader Class Initialized
DEBUG - 2016-10-09 01:18:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-09 01:18:04 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-09 01:18:04 --> Helper loaded: url_helper
DEBUG - 2016-10-09 01:18:04 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-09 01:18:04 --> Helper loaded: file_helper
DEBUG - 2016-10-09 01:18:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:18:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-09 01:18:04 --> Helper loaded: conf_helper
DEBUG - 2016-10-09 01:18:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:18:04 --> Check Exists common_helper.php: No
DEBUG - 2016-10-09 01:18:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-09 01:18:04 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:18:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-09 01:18:04 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:18:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-09 01:18:04 --> Helper loaded: form_helper
DEBUG - 2016-10-09 01:18:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-09 01:18:04 --> Helper loaded: security_helper
DEBUG - 2016-10-09 01:18:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:18:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-09 01:18:04 --> Helper loaded: lang_helper
DEBUG - 2016-10-09 01:18:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:18:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-09 01:18:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-09 01:18:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-09 01:18:04 --> Helper loaded: atlant_helper
DEBUG - 2016-10-09 01:18:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:18:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-09 01:18:04 --> Helper loaded: crypto_helper
DEBUG - 2016-10-09 01:18:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:18:04 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-09 01:18:04 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-09 01:18:04 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-09 01:18:04 --> Helper loaded: sidika_helper
DEBUG - 2016-10-09 01:18:04 --> Database Driver Class Initialized
DEBUG - 2016-10-09 01:18:04 --> Session Class Initialized
DEBUG - 2016-10-09 01:18:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-09 01:18:04 --> Helper loaded: string_helper
DEBUG - 2016-10-09 01:18:04 --> Session routines successfully run
DEBUG - 2016-10-09 01:18:04 --> Native_session Class Initialized
DEBUG - 2016-10-09 01:18:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-09 01:18:04 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:18:04 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:18:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 01:18:04 --> Controller Class Initialized
DEBUG - 2016-10-09 01:18:04 --> Carabiner: Library initialized.
DEBUG - 2016-10-09 01:18:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-09 01:18:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-09 01:18:04 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:18:04 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:18:04 --> User Agent Class Initialized
DEBUG - 2016-10-09 01:18:04 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:04 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:04 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:04 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:04 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:04 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:04 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:04 --> Model Class Initialized
ERROR - 2016-10-09 01:18:04 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-10-09 01:18:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-10-09 01:18:04 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:18:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 01:18:05 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-10-09 01:18:05 --> Config Class Initialized
DEBUG - 2016-10-09 01:18:05 --> Hooks Class Initialized
DEBUG - 2016-10-09 01:18:05 --> Utf8 Class Initialized
DEBUG - 2016-10-09 01:18:05 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 01:18:05 --> URI Class Initialized
DEBUG - 2016-10-09 01:18:05 --> Router Class Initialized
DEBUG - 2016-10-09 01:18:05 --> No URI present. Default controller set.
DEBUG - 2016-10-09 01:18:05 --> Output Class Initialized
DEBUG - 2016-10-09 01:18:05 --> Cache file has expired. File deleted
DEBUG - 2016-10-09 01:18:05 --> Security Class Initialized
DEBUG - 2016-10-09 01:18:05 --> Input Class Initialized
DEBUG - 2016-10-09 01:18:05 --> XSS Filtering completed
DEBUG - 2016-10-09 01:18:05 --> XSS Filtering completed
DEBUG - 2016-10-09 01:18:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-09 01:18:05 --> Language Class Initialized
DEBUG - 2016-10-09 01:18:05 --> Loader Class Initialized
DEBUG - 2016-10-09 01:18:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-09 01:18:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-09 01:18:05 --> Helper loaded: url_helper
DEBUG - 2016-10-09 01:18:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-09 01:18:05 --> Helper loaded: file_helper
DEBUG - 2016-10-09 01:18:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:18:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-09 01:18:05 --> Helper loaded: conf_helper
DEBUG - 2016-10-09 01:18:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:18:05 --> Check Exists common_helper.php: No
DEBUG - 2016-10-09 01:18:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-09 01:18:05 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:18:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-09 01:18:05 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:18:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-09 01:18:05 --> Helper loaded: form_helper
DEBUG - 2016-10-09 01:18:05 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-09 01:18:05 --> Helper loaded: security_helper
DEBUG - 2016-10-09 01:18:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:18:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-09 01:18:05 --> Helper loaded: lang_helper
DEBUG - 2016-10-09 01:18:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:18:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-09 01:18:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-09 01:18:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-09 01:18:05 --> Helper loaded: atlant_helper
DEBUG - 2016-10-09 01:18:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:18:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-09 01:18:05 --> Helper loaded: crypto_helper
DEBUG - 2016-10-09 01:18:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:18:05 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-09 01:18:05 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-09 01:18:05 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-09 01:18:05 --> Helper loaded: sidika_helper
DEBUG - 2016-10-09 01:18:05 --> Database Driver Class Initialized
DEBUG - 2016-10-09 01:18:05 --> Session Class Initialized
DEBUG - 2016-10-09 01:18:05 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-09 01:18:05 --> Helper loaded: string_helper
DEBUG - 2016-10-09 01:18:05 --> Session routines successfully run
DEBUG - 2016-10-09 01:18:05 --> Native_session Class Initialized
DEBUG - 2016-10-09 01:18:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-09 01:18:05 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:18:05 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:18:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 01:18:05 --> Controller Class Initialized
DEBUG - 2016-10-09 01:18:05 --> Carabiner: Library initialized.
DEBUG - 2016-10-09 01:18:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-09 01:18:05 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-09 01:18:05 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:18:05 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:18:05 --> User Agent Class Initialized
DEBUG - 2016-10-09 01:18:05 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:05 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:05 --> Model Class Initialized
ERROR - 2016-10-09 01:18:05 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-10-09 01:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-10-09 01:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-10-09 01:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-09 01:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 01:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-09 01:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-09 01:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-09 01:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-09 01:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-09 01:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 01:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-09 01:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-09 01:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 01:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-09 01:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-09 01:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-09 01:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-09 01:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-09 01:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 01:18:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-09 01:18:05 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-10-09 01:18:05 --> Final output sent to browser
DEBUG - 2016-10-09 01:18:05 --> Total execution time: 0.3230
DEBUG - 2016-10-09 01:18:05 --> Config Class Initialized
DEBUG - 2016-10-09 01:18:05 --> Hooks Class Initialized
DEBUG - 2016-10-09 01:18:05 --> Utf8 Class Initialized
DEBUG - 2016-10-09 01:18:05 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 01:18:05 --> URI Class Initialized
DEBUG - 2016-10-09 01:18:05 --> Router Class Initialized
DEBUG - 2016-10-09 01:18:05 --> Output Class Initialized
DEBUG - 2016-10-09 01:18:05 --> Cache file has expired. File deleted
DEBUG - 2016-10-09 01:18:05 --> Security Class Initialized
DEBUG - 2016-10-09 01:18:05 --> Input Class Initialized
DEBUG - 2016-10-09 01:18:05 --> XSS Filtering completed
DEBUG - 2016-10-09 01:18:05 --> XSS Filtering completed
DEBUG - 2016-10-09 01:18:05 --> XSS Filtering completed
DEBUG - 2016-10-09 01:18:05 --> XSS Filtering completed
DEBUG - 2016-10-09 01:18:05 --> XSS Filtering completed
DEBUG - 2016-10-09 01:18:05 --> XSS Filtering completed
DEBUG - 2016-10-09 01:18:05 --> XSS Filtering completed
DEBUG - 2016-10-09 01:18:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-09 01:18:05 --> Language Class Initialized
DEBUG - 2016-10-09 01:18:05 --> Loader Class Initialized
DEBUG - 2016-10-09 01:18:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-09 01:18:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-09 01:18:06 --> Helper loaded: url_helper
DEBUG - 2016-10-09 01:18:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-09 01:18:06 --> Helper loaded: file_helper
DEBUG - 2016-10-09 01:18:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:18:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-09 01:18:06 --> Helper loaded: conf_helper
DEBUG - 2016-10-09 01:18:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:18:06 --> Check Exists common_helper.php: No
DEBUG - 2016-10-09 01:18:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-09 01:18:06 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:18:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-09 01:18:06 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:18:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-09 01:18:06 --> Helper loaded: form_helper
DEBUG - 2016-10-09 01:18:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-09 01:18:06 --> Helper loaded: security_helper
DEBUG - 2016-10-09 01:18:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:18:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-09 01:18:06 --> Helper loaded: lang_helper
DEBUG - 2016-10-09 01:18:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:18:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-09 01:18:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-09 01:18:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-09 01:18:06 --> Helper loaded: atlant_helper
DEBUG - 2016-10-09 01:18:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:18:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-09 01:18:06 --> Helper loaded: crypto_helper
DEBUG - 2016-10-09 01:18:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:18:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-09 01:18:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-09 01:18:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-09 01:18:06 --> Helper loaded: sidika_helper
DEBUG - 2016-10-09 01:18:06 --> Database Driver Class Initialized
DEBUG - 2016-10-09 01:18:06 --> Session Class Initialized
DEBUG - 2016-10-09 01:18:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-09 01:18:06 --> Helper loaded: string_helper
DEBUG - 2016-10-09 01:18:06 --> Session routines successfully run
DEBUG - 2016-10-09 01:18:06 --> Native_session Class Initialized
DEBUG - 2016-10-09 01:18:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-09 01:18:06 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:18:06 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:18:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 01:18:06 --> Controller Class Initialized
DEBUG - 2016-10-09 01:18:06 --> Carabiner: Library initialized.
DEBUG - 2016-10-09 01:18:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-09 01:18:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-09 01:18:06 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:18:06 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:18:06 --> User Agent Class Initialized
DEBUG - 2016-10-09 01:18:06 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:06 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:06 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:06 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:06 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:06 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:06 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:06 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-10-09 01:18:06 --> Final output sent to browser
DEBUG - 2016-10-09 01:18:06 --> Total execution time: 0.3874
DEBUG - 2016-10-09 01:18:11 --> Config Class Initialized
DEBUG - 2016-10-09 01:18:11 --> Hooks Class Initialized
DEBUG - 2016-10-09 01:18:11 --> Utf8 Class Initialized
DEBUG - 2016-10-09 01:18:11 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 01:18:11 --> URI Class Initialized
DEBUG - 2016-10-09 01:18:11 --> Router Class Initialized
DEBUG - 2016-10-09 01:18:11 --> Output Class Initialized
DEBUG - 2016-10-09 01:18:11 --> Cache file has expired. File deleted
DEBUG - 2016-10-09 01:18:11 --> Security Class Initialized
DEBUG - 2016-10-09 01:18:11 --> Input Class Initialized
DEBUG - 2016-10-09 01:18:11 --> XSS Filtering completed
DEBUG - 2016-10-09 01:18:11 --> XSS Filtering completed
DEBUG - 2016-10-09 01:18:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-09 01:18:11 --> Language Class Initialized
DEBUG - 2016-10-09 01:18:11 --> Loader Class Initialized
DEBUG - 2016-10-09 01:18:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-09 01:18:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-09 01:18:11 --> Helper loaded: url_helper
DEBUG - 2016-10-09 01:18:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-09 01:18:11 --> Helper loaded: file_helper
DEBUG - 2016-10-09 01:18:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:18:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-09 01:18:11 --> Helper loaded: conf_helper
DEBUG - 2016-10-09 01:18:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:18:11 --> Check Exists common_helper.php: No
DEBUG - 2016-10-09 01:18:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-09 01:18:11 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:18:11 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-09 01:18:11 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:18:11 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-09 01:18:11 --> Helper loaded: form_helper
DEBUG - 2016-10-09 01:18:11 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-09 01:18:11 --> Helper loaded: security_helper
DEBUG - 2016-10-09 01:18:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:18:11 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-09 01:18:11 --> Helper loaded: lang_helper
DEBUG - 2016-10-09 01:18:11 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:18:11 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-09 01:18:11 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-09 01:18:11 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-09 01:18:11 --> Helper loaded: atlant_helper
DEBUG - 2016-10-09 01:18:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:18:11 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-09 01:18:11 --> Helper loaded: crypto_helper
DEBUG - 2016-10-09 01:18:11 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:18:11 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-09 01:18:11 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-09 01:18:11 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-09 01:18:11 --> Helper loaded: sidika_helper
DEBUG - 2016-10-09 01:18:11 --> Database Driver Class Initialized
DEBUG - 2016-10-09 01:18:11 --> Session Class Initialized
DEBUG - 2016-10-09 01:18:11 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-09 01:18:11 --> Helper loaded: string_helper
DEBUG - 2016-10-09 01:18:11 --> Session routines successfully run
DEBUG - 2016-10-09 01:18:11 --> Native_session Class Initialized
DEBUG - 2016-10-09 01:18:11 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-09 01:18:11 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:18:11 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:18:11 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 01:18:11 --> Controller Class Initialized
DEBUG - 2016-10-09 01:18:11 --> Carabiner: Library initialized.
DEBUG - 2016-10-09 01:18:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-09 01:18:11 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-09 01:18:11 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:18:11 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:18:11 --> User Agent Class Initialized
DEBUG - 2016-10-09 01:18:11 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:11 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:11 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-10-09 01:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-09 01:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-09 01:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 01:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-09 01:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 01:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-09 01:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-09 01:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-09 01:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 01:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-09 01:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 01:18:11 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-09 01:18:11 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-10-09 01:18:11 --> Final output sent to browser
DEBUG - 2016-10-09 01:18:11 --> Total execution time: 0.3433
DEBUG - 2016-10-09 01:18:13 --> Config Class Initialized
DEBUG - 2016-10-09 01:18:13 --> Hooks Class Initialized
DEBUG - 2016-10-09 01:18:13 --> Utf8 Class Initialized
DEBUG - 2016-10-09 01:18:13 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 01:18:13 --> URI Class Initialized
DEBUG - 2016-10-09 01:18:13 --> Router Class Initialized
DEBUG - 2016-10-09 01:18:13 --> Output Class Initialized
DEBUG - 2016-10-09 01:18:13 --> Cache file has expired. File deleted
DEBUG - 2016-10-09 01:18:13 --> Security Class Initialized
DEBUG - 2016-10-09 01:18:13 --> Input Class Initialized
DEBUG - 2016-10-09 01:18:13 --> XSS Filtering completed
DEBUG - 2016-10-09 01:18:13 --> XSS Filtering completed
DEBUG - 2016-10-09 01:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-09 01:18:13 --> Language Class Initialized
DEBUG - 2016-10-09 01:18:13 --> Loader Class Initialized
DEBUG - 2016-10-09 01:18:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-09 01:18:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-09 01:18:13 --> Helper loaded: url_helper
DEBUG - 2016-10-09 01:18:13 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-09 01:18:13 --> Helper loaded: file_helper
DEBUG - 2016-10-09 01:18:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:18:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-09 01:18:13 --> Helper loaded: conf_helper
DEBUG - 2016-10-09 01:18:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:18:13 --> Check Exists common_helper.php: No
DEBUG - 2016-10-09 01:18:13 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-09 01:18:13 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:18:13 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-09 01:18:13 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:18:13 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-09 01:18:13 --> Helper loaded: form_helper
DEBUG - 2016-10-09 01:18:13 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-09 01:18:13 --> Helper loaded: security_helper
DEBUG - 2016-10-09 01:18:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:18:13 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-09 01:18:13 --> Helper loaded: lang_helper
DEBUG - 2016-10-09 01:18:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:18:13 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-09 01:18:13 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-09 01:18:13 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-09 01:18:13 --> Helper loaded: atlant_helper
DEBUG - 2016-10-09 01:18:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:18:13 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-09 01:18:13 --> Helper loaded: crypto_helper
DEBUG - 2016-10-09 01:18:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:18:13 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-09 01:18:13 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-09 01:18:13 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-09 01:18:13 --> Helper loaded: sidika_helper
DEBUG - 2016-10-09 01:18:13 --> Database Driver Class Initialized
DEBUG - 2016-10-09 01:18:13 --> Session Class Initialized
DEBUG - 2016-10-09 01:18:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-09 01:18:13 --> Helper loaded: string_helper
DEBUG - 2016-10-09 01:18:13 --> Session routines successfully run
DEBUG - 2016-10-09 01:18:13 --> Native_session Class Initialized
DEBUG - 2016-10-09 01:18:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-09 01:18:13 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:18:13 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:18:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 01:18:13 --> Controller Class Initialized
DEBUG - 2016-10-09 01:18:13 --> Carabiner: Library initialized.
DEBUG - 2016-10-09 01:18:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-09 01:18:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-09 01:18:13 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:18:13 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:18:13 --> User Agent Class Initialized
DEBUG - 2016-10-09 01:18:13 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:13 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:13 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:13 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:13 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:14 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:14 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:14 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-09 01:18:14 --> Pagination Class Initialized
DEBUG - 2016-10-09 01:18:14 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-09 01:18:14 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/index.php
DEBUG - 2016-10-09 01:18:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-09 01:18:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-09 01:18:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 01:18:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-09 01:18:15 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-09 01:18:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 01:18:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-09 01:18:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-09 01:18:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-09 01:18:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 01:18:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-09 01:18:15 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-09 01:18:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 01:18:15 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-09 01:18:15 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55961f1d1ca16fdfc4239ae1901a174e
DEBUG - 2016-10-09 01:18:15 --> Final output sent to browser
DEBUG - 2016-10-09 01:18:15 --> Total execution time: 0.6983
DEBUG - 2016-10-09 01:18:30 --> Config Class Initialized
DEBUG - 2016-10-09 01:18:30 --> Hooks Class Initialized
DEBUG - 2016-10-09 01:18:30 --> Utf8 Class Initialized
DEBUG - 2016-10-09 01:18:30 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 01:18:30 --> URI Class Initialized
DEBUG - 2016-10-09 01:18:30 --> Router Class Initialized
DEBUG - 2016-10-09 01:18:30 --> Output Class Initialized
DEBUG - 2016-10-09 01:18:30 --> Cache file has expired. File deleted
DEBUG - 2016-10-09 01:18:30 --> Security Class Initialized
DEBUG - 2016-10-09 01:18:30 --> Input Class Initialized
DEBUG - 2016-10-09 01:18:30 --> XSS Filtering completed
DEBUG - 2016-10-09 01:18:30 --> XSS Filtering completed
DEBUG - 2016-10-09 01:18:30 --> XSS Filtering completed
DEBUG - 2016-10-09 01:18:30 --> XSS Filtering completed
DEBUG - 2016-10-09 01:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-09 01:18:30 --> Language Class Initialized
DEBUG - 2016-10-09 01:18:30 --> Loader Class Initialized
DEBUG - 2016-10-09 01:18:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-09 01:18:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-09 01:18:30 --> Helper loaded: url_helper
DEBUG - 2016-10-09 01:18:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-09 01:18:30 --> Helper loaded: file_helper
DEBUG - 2016-10-09 01:18:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:18:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-09 01:18:30 --> Helper loaded: conf_helper
DEBUG - 2016-10-09 01:18:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:18:30 --> Check Exists common_helper.php: No
DEBUG - 2016-10-09 01:18:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-09 01:18:30 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:18:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-09 01:18:30 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:18:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-09 01:18:30 --> Helper loaded: form_helper
DEBUG - 2016-10-09 01:18:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-09 01:18:30 --> Helper loaded: security_helper
DEBUG - 2016-10-09 01:18:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:18:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-09 01:18:30 --> Helper loaded: lang_helper
DEBUG - 2016-10-09 01:18:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:18:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-09 01:18:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-09 01:18:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-09 01:18:30 --> Helper loaded: atlant_helper
DEBUG - 2016-10-09 01:18:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:18:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-09 01:18:30 --> Helper loaded: crypto_helper
DEBUG - 2016-10-09 01:18:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:18:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-09 01:18:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-09 01:18:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-09 01:18:30 --> Helper loaded: sidika_helper
DEBUG - 2016-10-09 01:18:30 --> Database Driver Class Initialized
DEBUG - 2016-10-09 01:18:31 --> Session Class Initialized
DEBUG - 2016-10-09 01:18:31 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-09 01:18:31 --> Helper loaded: string_helper
DEBUG - 2016-10-09 01:18:31 --> Session routines successfully run
DEBUG - 2016-10-09 01:18:31 --> Native_session Class Initialized
DEBUG - 2016-10-09 01:18:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-09 01:18:31 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:18:31 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:18:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 01:18:31 --> Controller Class Initialized
DEBUG - 2016-10-09 01:18:31 --> Carabiner: Library initialized.
DEBUG - 2016-10-09 01:18:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-09 01:18:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-09 01:18:31 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:18:31 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:18:31 --> User Agent Class Initialized
DEBUG - 2016-10-09 01:18:31 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:31 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:31 --> Model Class Initialized
ERROR - 2016-10-09 01:18:31 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-10-09 01:18:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-10-09 01:18:31 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:18:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 01:18:31 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-10-09 01:18:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-10-09 01:18:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-09 01:18:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 01:18:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-09 01:18:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-09 01:18:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-09 01:18:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 01:18:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-09 01:18:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-09 01:18:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 01:18:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-09 01:18:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-09 01:18:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-09 01:18:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 01:18:31 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-09 01:18:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-10-09 01:18:31 --> Final output sent to browser
DEBUG - 2016-10-09 01:18:31 --> Total execution time: 0.4260
DEBUG - 2016-10-09 01:18:56 --> Config Class Initialized
DEBUG - 2016-10-09 01:18:56 --> Hooks Class Initialized
DEBUG - 2016-10-09 01:18:56 --> Utf8 Class Initialized
DEBUG - 2016-10-09 01:18:56 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 01:18:56 --> URI Class Initialized
DEBUG - 2016-10-09 01:18:56 --> Router Class Initialized
DEBUG - 2016-10-09 01:18:56 --> Output Class Initialized
DEBUG - 2016-10-09 01:18:56 --> Cache file has expired. File deleted
DEBUG - 2016-10-09 01:18:56 --> Security Class Initialized
DEBUG - 2016-10-09 01:18:56 --> Input Class Initialized
DEBUG - 2016-10-09 01:18:56 --> XSS Filtering completed
DEBUG - 2016-10-09 01:18:56 --> XSS Filtering completed
DEBUG - 2016-10-09 01:18:56 --> XSS Filtering completed
DEBUG - 2016-10-09 01:18:56 --> XSS Filtering completed
DEBUG - 2016-10-09 01:18:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-09 01:18:56 --> Language Class Initialized
DEBUG - 2016-10-09 01:18:56 --> Loader Class Initialized
DEBUG - 2016-10-09 01:18:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-09 01:18:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-09 01:18:56 --> Helper loaded: url_helper
DEBUG - 2016-10-09 01:18:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-09 01:18:56 --> Helper loaded: file_helper
DEBUG - 2016-10-09 01:18:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:18:56 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-09 01:18:56 --> Helper loaded: conf_helper
DEBUG - 2016-10-09 01:18:56 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:18:56 --> Check Exists common_helper.php: No
DEBUG - 2016-10-09 01:18:56 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-09 01:18:56 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:18:56 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-09 01:18:56 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:18:56 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-09 01:18:56 --> Helper loaded: form_helper
DEBUG - 2016-10-09 01:18:56 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-09 01:18:56 --> Helper loaded: security_helper
DEBUG - 2016-10-09 01:18:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:18:56 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-09 01:18:56 --> Helper loaded: lang_helper
DEBUG - 2016-10-09 01:18:56 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:18:56 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-09 01:18:56 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-09 01:18:56 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-09 01:18:56 --> Helper loaded: atlant_helper
DEBUG - 2016-10-09 01:18:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:18:56 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-09 01:18:56 --> Helper loaded: crypto_helper
DEBUG - 2016-10-09 01:18:56 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:18:56 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-09 01:18:56 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-09 01:18:56 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-09 01:18:56 --> Helper loaded: sidika_helper
DEBUG - 2016-10-09 01:18:56 --> Database Driver Class Initialized
DEBUG - 2016-10-09 01:18:56 --> Session Class Initialized
DEBUG - 2016-10-09 01:18:56 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-09 01:18:57 --> Helper loaded: string_helper
DEBUG - 2016-10-09 01:18:57 --> Session routines successfully run
DEBUG - 2016-10-09 01:18:57 --> Native_session Class Initialized
DEBUG - 2016-10-09 01:18:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-09 01:18:57 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:18:57 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:18:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 01:18:57 --> Controller Class Initialized
DEBUG - 2016-10-09 01:18:57 --> Carabiner: Library initialized.
DEBUG - 2016-10-09 01:18:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-09 01:18:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-09 01:18:57 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:18:57 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:18:57 --> User Agent Class Initialized
DEBUG - 2016-10-09 01:18:57 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:57 --> Model Class Initialized
DEBUG - 2016-10-09 01:18:57 --> Model Class Initialized
ERROR - 2016-10-09 01:18:57 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-10-09 01:18:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-10-09 01:18:57 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:18:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 01:18:57 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-10-09 01:18:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-10-09 01:18:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-09 01:18:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 01:18:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-09 01:18:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-09 01:18:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-09 01:18:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 01:18:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-09 01:18:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-09 01:18:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 01:18:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-09 01:18:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-09 01:18:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-09 01:18:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 01:18:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-09 01:18:57 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-10-09 01:18:57 --> Final output sent to browser
DEBUG - 2016-10-09 01:18:57 --> Total execution time: 0.4454
DEBUG - 2016-10-09 01:19:20 --> Config Class Initialized
DEBUG - 2016-10-09 01:19:20 --> Hooks Class Initialized
DEBUG - 2016-10-09 01:19:20 --> Utf8 Class Initialized
DEBUG - 2016-10-09 01:19:20 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 01:19:20 --> URI Class Initialized
DEBUG - 2016-10-09 01:19:20 --> Router Class Initialized
DEBUG - 2016-10-09 01:19:20 --> Output Class Initialized
DEBUG - 2016-10-09 01:19:20 --> Cache file has expired. File deleted
DEBUG - 2016-10-09 01:19:20 --> Security Class Initialized
DEBUG - 2016-10-09 01:19:20 --> Input Class Initialized
DEBUG - 2016-10-09 01:19:20 --> XSS Filtering completed
DEBUG - 2016-10-09 01:19:20 --> XSS Filtering completed
DEBUG - 2016-10-09 01:19:20 --> XSS Filtering completed
DEBUG - 2016-10-09 01:19:20 --> XSS Filtering completed
DEBUG - 2016-10-09 01:19:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-09 01:19:20 --> Language Class Initialized
DEBUG - 2016-10-09 01:19:20 --> Loader Class Initialized
DEBUG - 2016-10-09 01:19:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-09 01:19:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-09 01:19:20 --> Helper loaded: url_helper
DEBUG - 2016-10-09 01:19:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-09 01:19:20 --> Helper loaded: file_helper
DEBUG - 2016-10-09 01:19:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:19:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-09 01:19:20 --> Helper loaded: conf_helper
DEBUG - 2016-10-09 01:19:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:19:20 --> Check Exists common_helper.php: No
DEBUG - 2016-10-09 01:19:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-09 01:19:20 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:19:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-09 01:19:20 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:19:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-09 01:19:20 --> Helper loaded: form_helper
DEBUG - 2016-10-09 01:19:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-09 01:19:20 --> Helper loaded: security_helper
DEBUG - 2016-10-09 01:19:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:19:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-09 01:19:20 --> Helper loaded: lang_helper
DEBUG - 2016-10-09 01:19:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:19:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-09 01:19:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-09 01:19:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-09 01:19:20 --> Helper loaded: atlant_helper
DEBUG - 2016-10-09 01:19:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:19:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-09 01:19:20 --> Helper loaded: crypto_helper
DEBUG - 2016-10-09 01:19:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:19:20 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-09 01:19:20 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-09 01:19:20 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-09 01:19:20 --> Helper loaded: sidika_helper
DEBUG - 2016-10-09 01:19:20 --> Database Driver Class Initialized
DEBUG - 2016-10-09 01:19:20 --> Session Class Initialized
DEBUG - 2016-10-09 01:19:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-09 01:19:20 --> Helper loaded: string_helper
DEBUG - 2016-10-09 01:19:20 --> Session routines successfully run
DEBUG - 2016-10-09 01:19:20 --> Native_session Class Initialized
DEBUG - 2016-10-09 01:19:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-09 01:19:20 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:19:20 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:19:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 01:19:20 --> Controller Class Initialized
DEBUG - 2016-10-09 01:19:20 --> Carabiner: Library initialized.
DEBUG - 2016-10-09 01:19:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-09 01:19:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-09 01:19:20 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:19:20 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:19:20 --> User Agent Class Initialized
DEBUG - 2016-10-09 01:19:20 --> Model Class Initialized
DEBUG - 2016-10-09 01:19:20 --> Model Class Initialized
DEBUG - 2016-10-09 01:19:20 --> Model Class Initialized
ERROR - 2016-10-09 01:19:20 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-10-09 01:19:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-10-09 01:19:20 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:19:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 01:19:20 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-10-09 01:19:20 --> Config Class Initialized
DEBUG - 2016-10-09 01:19:20 --> Hooks Class Initialized
DEBUG - 2016-10-09 01:19:20 --> Utf8 Class Initialized
DEBUG - 2016-10-09 01:19:20 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 01:19:20 --> URI Class Initialized
DEBUG - 2016-10-09 01:19:20 --> Router Class Initialized
DEBUG - 2016-10-09 01:19:20 --> No URI present. Default controller set.
DEBUG - 2016-10-09 01:19:20 --> Output Class Initialized
DEBUG - 2016-10-09 01:19:20 --> Cache file has expired. File deleted
DEBUG - 2016-10-09 01:19:20 --> Security Class Initialized
DEBUG - 2016-10-09 01:19:20 --> Input Class Initialized
DEBUG - 2016-10-09 01:19:20 --> XSS Filtering completed
DEBUG - 2016-10-09 01:19:20 --> XSS Filtering completed
DEBUG - 2016-10-09 01:19:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-09 01:19:20 --> Language Class Initialized
DEBUG - 2016-10-09 01:19:20 --> Loader Class Initialized
DEBUG - 2016-10-09 01:19:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-09 01:19:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-09 01:19:20 --> Helper loaded: url_helper
DEBUG - 2016-10-09 01:19:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-09 01:19:20 --> Helper loaded: file_helper
DEBUG - 2016-10-09 01:19:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:19:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-09 01:19:20 --> Helper loaded: conf_helper
DEBUG - 2016-10-09 01:19:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:19:20 --> Check Exists common_helper.php: No
DEBUG - 2016-10-09 01:19:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-09 01:19:20 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:19:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-09 01:19:20 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:19:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-09 01:19:20 --> Helper loaded: form_helper
DEBUG - 2016-10-09 01:19:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-09 01:19:20 --> Helper loaded: security_helper
DEBUG - 2016-10-09 01:19:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:19:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-09 01:19:20 --> Helper loaded: lang_helper
DEBUG - 2016-10-09 01:19:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:19:21 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-09 01:19:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-09 01:19:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-09 01:19:21 --> Helper loaded: atlant_helper
DEBUG - 2016-10-09 01:19:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:19:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-09 01:19:21 --> Helper loaded: crypto_helper
DEBUG - 2016-10-09 01:19:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:19:21 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-09 01:19:21 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-09 01:19:21 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-09 01:19:21 --> Helper loaded: sidika_helper
DEBUG - 2016-10-09 01:19:21 --> Database Driver Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Session Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-09 01:19:21 --> Helper loaded: string_helper
DEBUG - 2016-10-09 01:19:21 --> Session routines successfully run
DEBUG - 2016-10-09 01:19:21 --> Native_session Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-09 01:19:21 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 01:19:21 --> Controller Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Carabiner: Library initialized.
DEBUG - 2016-10-09 01:19:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-09 01:19:21 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-09 01:19:21 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:19:21 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:19:21 --> User Agent Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Model Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Model Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Model Class Initialized
ERROR - 2016-10-09 01:19:21 --> Hak Akses modul/kontroller 'home' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-09 01:19:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-10-09 01:19:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-10-09 01:19:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-09 01:19:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 01:19:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-09 01:19:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-09 01:19:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-09 01:19:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-09 01:19:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-09 01:19:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 01:19:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-09 01:19:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-09 01:19:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 01:19:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-09 01:19:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-09 01:19:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-09 01:19:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-09 01:19:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-09 01:19:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 01:19:21 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-09 01:19:21 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-10-09 01:19:21 --> Final output sent to browser
DEBUG - 2016-10-09 01:19:21 --> Total execution time: 0.4177
DEBUG - 2016-10-09 01:19:21 --> Config Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Hooks Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Utf8 Class Initialized
DEBUG - 2016-10-09 01:19:21 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 01:19:21 --> URI Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Router Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Output Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Cache file has expired. File deleted
DEBUG - 2016-10-09 01:19:21 --> Security Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Input Class Initialized
DEBUG - 2016-10-09 01:19:21 --> XSS Filtering completed
DEBUG - 2016-10-09 01:19:21 --> XSS Filtering completed
DEBUG - 2016-10-09 01:19:21 --> XSS Filtering completed
DEBUG - 2016-10-09 01:19:21 --> XSS Filtering completed
DEBUG - 2016-10-09 01:19:21 --> XSS Filtering completed
DEBUG - 2016-10-09 01:19:21 --> XSS Filtering completed
DEBUG - 2016-10-09 01:19:21 --> XSS Filtering completed
DEBUG - 2016-10-09 01:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-09 01:19:21 --> Language Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Loader Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-09 01:19:21 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-09 01:19:21 --> Helper loaded: url_helper
DEBUG - 2016-10-09 01:19:21 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-09 01:19:21 --> Helper loaded: file_helper
DEBUG - 2016-10-09 01:19:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:19:21 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-09 01:19:21 --> Helper loaded: conf_helper
DEBUG - 2016-10-09 01:19:21 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:19:21 --> Check Exists common_helper.php: No
DEBUG - 2016-10-09 01:19:21 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-09 01:19:21 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:19:21 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-09 01:19:21 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:19:21 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-09 01:19:21 --> Helper loaded: form_helper
DEBUG - 2016-10-09 01:19:21 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-09 01:19:21 --> Helper loaded: security_helper
DEBUG - 2016-10-09 01:19:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:19:21 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-09 01:19:21 --> Helper loaded: lang_helper
DEBUG - 2016-10-09 01:19:21 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:19:21 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-09 01:19:21 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-09 01:19:21 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-09 01:19:21 --> Helper loaded: atlant_helper
DEBUG - 2016-10-09 01:19:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:19:21 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-09 01:19:21 --> Helper loaded: crypto_helper
DEBUG - 2016-10-09 01:19:21 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:19:21 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-09 01:19:21 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-09 01:19:21 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-09 01:19:21 --> Helper loaded: sidika_helper
DEBUG - 2016-10-09 01:19:21 --> Database Driver Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Session Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-09 01:19:21 --> Helper loaded: string_helper
DEBUG - 2016-10-09 01:19:21 --> Session routines successfully run
DEBUG - 2016-10-09 01:19:21 --> Native_session Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-09 01:19:21 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 01:19:21 --> Controller Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Carabiner: Library initialized.
DEBUG - 2016-10-09 01:19:21 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-09 01:19:21 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-09 01:19:21 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:19:21 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:19:21 --> User Agent Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Model Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Model Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Model Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Model Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Model Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Model Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Model Class Initialized
DEBUG - 2016-10-09 01:19:21 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-10-09 01:19:21 --> Final output sent to browser
DEBUG - 2016-10-09 01:19:21 --> Total execution time: 0.5036
DEBUG - 2016-10-09 01:19:37 --> Config Class Initialized
DEBUG - 2016-10-09 01:19:37 --> Hooks Class Initialized
DEBUG - 2016-10-09 01:19:37 --> Utf8 Class Initialized
DEBUG - 2016-10-09 01:19:37 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 01:19:37 --> URI Class Initialized
DEBUG - 2016-10-09 01:19:37 --> Router Class Initialized
DEBUG - 2016-10-09 01:19:37 --> Output Class Initialized
DEBUG - 2016-10-09 01:19:37 --> Cache file has expired. File deleted
DEBUG - 2016-10-09 01:19:37 --> Security Class Initialized
DEBUG - 2016-10-09 01:19:37 --> Input Class Initialized
DEBUG - 2016-10-09 01:19:37 --> XSS Filtering completed
DEBUG - 2016-10-09 01:19:37 --> XSS Filtering completed
DEBUG - 2016-10-09 01:19:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-09 01:19:37 --> Language Class Initialized
DEBUG - 2016-10-09 01:19:37 --> Loader Class Initialized
DEBUG - 2016-10-09 01:19:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-09 01:19:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-09 01:19:37 --> Helper loaded: url_helper
DEBUG - 2016-10-09 01:19:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-09 01:19:37 --> Helper loaded: file_helper
DEBUG - 2016-10-09 01:19:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:19:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-09 01:19:37 --> Helper loaded: conf_helper
DEBUG - 2016-10-09 01:19:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:19:37 --> Check Exists common_helper.php: No
DEBUG - 2016-10-09 01:19:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-09 01:19:37 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:19:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-09 01:19:37 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:19:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-09 01:19:37 --> Helper loaded: form_helper
DEBUG - 2016-10-09 01:19:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-09 01:19:37 --> Helper loaded: security_helper
DEBUG - 2016-10-09 01:19:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:19:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-09 01:19:38 --> Helper loaded: lang_helper
DEBUG - 2016-10-09 01:19:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:19:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-09 01:19:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-09 01:19:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-09 01:19:38 --> Helper loaded: atlant_helper
DEBUG - 2016-10-09 01:19:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:19:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-09 01:19:38 --> Helper loaded: crypto_helper
DEBUG - 2016-10-09 01:19:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:19:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-09 01:19:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-09 01:19:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-09 01:19:38 --> Helper loaded: sidika_helper
DEBUG - 2016-10-09 01:19:38 --> Database Driver Class Initialized
DEBUG - 2016-10-09 01:19:38 --> Session Class Initialized
DEBUG - 2016-10-09 01:19:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-09 01:19:38 --> Helper loaded: string_helper
DEBUG - 2016-10-09 01:19:38 --> Session routines successfully run
DEBUG - 2016-10-09 01:19:38 --> Native_session Class Initialized
DEBUG - 2016-10-09 01:19:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-09 01:19:38 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:19:38 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:19:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 01:19:38 --> Controller Class Initialized
DEBUG - 2016-10-09 01:19:38 --> Carabiner: Library initialized.
DEBUG - 2016-10-09 01:19:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-09 01:19:38 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-09 01:19:38 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:19:38 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:19:38 --> User Agent Class Initialized
DEBUG - 2016-10-09 01:19:38 --> Model Class Initialized
DEBUG - 2016-10-09 01:19:38 --> Model Class Initialized
DEBUG - 2016-10-09 01:19:38 --> Model Class Initialized
ERROR - 2016-10-09 01:19:38 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-09 01:19:38 --> Model Class Initialized
DEBUG - 2016-10-09 01:19:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-09 01:19:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-09 01:19:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 01:19:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-09 01:19:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-09 01:19:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-09 01:19:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 01:19:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-09 01:19:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-09 01:19:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 01:19:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-09 01:19:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-09 01:19:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-09 01:19:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 01:19:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-09 01:19:38 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-09 01:19:38 --> Final output sent to browser
DEBUG - 2016-10-09 01:19:38 --> Total execution time: 0.9494
DEBUG - 2016-10-09 01:42:47 --> Config Class Initialized
DEBUG - 2016-10-09 01:42:47 --> Hooks Class Initialized
DEBUG - 2016-10-09 01:42:47 --> Utf8 Class Initialized
DEBUG - 2016-10-09 01:42:47 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 01:42:47 --> URI Class Initialized
DEBUG - 2016-10-09 01:42:47 --> Router Class Initialized
DEBUG - 2016-10-09 01:42:47 --> Output Class Initialized
DEBUG - 2016-10-09 01:42:47 --> Cache file has expired. File deleted
DEBUG - 2016-10-09 01:42:47 --> Security Class Initialized
DEBUG - 2016-10-09 01:42:47 --> Input Class Initialized
DEBUG - 2016-10-09 01:42:47 --> XSS Filtering completed
DEBUG - 2016-10-09 01:42:47 --> XSS Filtering completed
DEBUG - 2016-10-09 01:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-09 01:42:47 --> Language Class Initialized
DEBUG - 2016-10-09 01:42:47 --> Loader Class Initialized
DEBUG - 2016-10-09 01:42:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-09 01:42:47 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-09 01:42:47 --> Helper loaded: url_helper
DEBUG - 2016-10-09 01:42:47 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-09 01:42:48 --> Helper loaded: file_helper
DEBUG - 2016-10-09 01:42:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:42:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-09 01:42:48 --> Helper loaded: conf_helper
DEBUG - 2016-10-09 01:42:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 01:42:48 --> Check Exists common_helper.php: No
DEBUG - 2016-10-09 01:42:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-09 01:42:48 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:42:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-09 01:42:48 --> Helper loaded: common_helper
DEBUG - 2016-10-09 01:42:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-09 01:42:48 --> Helper loaded: form_helper
DEBUG - 2016-10-09 01:42:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-09 01:42:48 --> Helper loaded: security_helper
DEBUG - 2016-10-09 01:42:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:42:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-09 01:42:48 --> Helper loaded: lang_helper
DEBUG - 2016-10-09 01:42:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 01:42:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-09 01:42:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-09 01:42:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-09 01:42:48 --> Helper loaded: atlant_helper
DEBUG - 2016-10-09 01:42:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:42:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-09 01:42:48 --> Helper loaded: crypto_helper
DEBUG - 2016-10-09 01:42:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 01:42:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-09 01:42:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-09 01:42:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-09 01:42:48 --> Helper loaded: sidika_helper
DEBUG - 2016-10-09 01:42:48 --> Database Driver Class Initialized
DEBUG - 2016-10-09 01:42:48 --> Session Class Initialized
DEBUG - 2016-10-09 01:42:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-09 01:42:48 --> Helper loaded: string_helper
DEBUG - 2016-10-09 01:42:48 --> Session routines successfully run
DEBUG - 2016-10-09 01:42:48 --> Native_session Class Initialized
DEBUG - 2016-10-09 01:42:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-09 01:42:48 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:42:48 --> Form Validation Class Initialized
DEBUG - 2016-10-09 01:42:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 01:42:48 --> Controller Class Initialized
DEBUG - 2016-10-09 01:42:48 --> Carabiner: Library initialized.
DEBUG - 2016-10-09 01:42:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-09 01:42:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-09 01:42:48 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:42:48 --> Carabiner: library configured.
DEBUG - 2016-10-09 01:42:48 --> User Agent Class Initialized
DEBUG - 2016-10-09 01:42:48 --> Model Class Initialized
DEBUG - 2016-10-09 01:42:48 --> Model Class Initialized
DEBUG - 2016-10-09 01:42:48 --> Model Class Initialized
ERROR - 2016-10-09 01:42:48 --> Hak Akses modul/kontroller 'cfpns' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-09 01:42:48 --> Model Class Initialized
DEBUG - 2016-10-09 01:42:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/index.php
DEBUG - 2016-10-09 01:42:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-09 01:42:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 01:42:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-09 01:42:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-09 01:42:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-09 01:42:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/js/index_js.php
DEBUG - 2016-10-09 01:42:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 01:42:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-09 01:42:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-09 01:42:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 01:42:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-09 01:42:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-09 01:42:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-09 01:42:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/js/index_js.php
DEBUG - 2016-10-09 01:42:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 01:42:48 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-09 01:42:48 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/995228d03d5ba12c79ca56588e90286f
DEBUG - 2016-10-09 01:42:48 --> Final output sent to browser
DEBUG - 2016-10-09 01:42:48 --> Total execution time: 0.4984
DEBUG - 2016-10-09 13:24:26 --> Config Class Initialized
DEBUG - 2016-10-09 13:24:26 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:24:26 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:24:26 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:24:26 --> URI Class Initialized
DEBUG - 2016-10-09 13:24:26 --> Router Class Initialized
DEBUG - 2016-10-09 13:24:26 --> No URI present. Default controller set.
DEBUG - 2016-10-09 13:24:27 --> Output Class Initialized
DEBUG - 2016-10-09 13:24:27 --> Cache file has expired. File deleted
DEBUG - 2016-10-09 13:24:27 --> Security Class Initialized
DEBUG - 2016-10-09 13:24:27 --> Input Class Initialized
DEBUG - 2016-10-09 13:24:27 --> XSS Filtering completed
DEBUG - 2016-10-09 13:24:27 --> XSS Filtering completed
DEBUG - 2016-10-09 13:24:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-09 13:24:27 --> Language Class Initialized
DEBUG - 2016-10-09 13:24:27 --> Loader Class Initialized
DEBUG - 2016-10-09 13:24:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-09 13:24:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-09 13:24:27 --> Helper loaded: url_helper
DEBUG - 2016-10-09 13:24:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-09 13:24:27 --> Helper loaded: file_helper
DEBUG - 2016-10-09 13:24:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 13:24:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-09 13:24:27 --> Helper loaded: conf_helper
DEBUG - 2016-10-09 13:24:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 13:24:27 --> Check Exists common_helper.php: No
DEBUG - 2016-10-09 13:24:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-09 13:24:27 --> Helper loaded: common_helper
DEBUG - 2016-10-09 13:24:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-09 13:24:27 --> Helper loaded: common_helper
DEBUG - 2016-10-09 13:24:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-09 13:24:27 --> Helper loaded: form_helper
DEBUG - 2016-10-09 13:24:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-09 13:24:27 --> Helper loaded: security_helper
DEBUG - 2016-10-09 13:24:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 13:24:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-09 13:24:27 --> Helper loaded: lang_helper
DEBUG - 2016-10-09 13:24:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 13:24:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-09 13:24:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-09 13:24:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-09 13:24:27 --> Helper loaded: atlant_helper
DEBUG - 2016-10-09 13:24:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 13:24:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-09 13:24:27 --> Helper loaded: crypto_helper
DEBUG - 2016-10-09 13:24:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 13:24:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-09 13:24:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-09 13:24:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-09 13:24:27 --> Helper loaded: sidika_helper
DEBUG - 2016-10-09 13:24:27 --> Database Driver Class Initialized
DEBUG - 2016-10-09 13:24:27 --> Session Class Initialized
DEBUG - 2016-10-09 13:24:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-09 13:24:27 --> Helper loaded: string_helper
DEBUG - 2016-10-09 13:24:27 --> Session routines successfully run
DEBUG - 2016-10-09 13:24:27 --> Native_session Class Initialized
DEBUG - 2016-10-09 13:24:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-09 13:24:27 --> Form Validation Class Initialized
DEBUG - 2016-10-09 13:24:27 --> Form Validation Class Initialized
DEBUG - 2016-10-09 13:24:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 13:24:27 --> Controller Class Initialized
DEBUG - 2016-10-09 13:24:27 --> Carabiner: Library initialized.
DEBUG - 2016-10-09 13:24:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-09 13:24:27 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-09 13:24:27 --> Carabiner: library configured.
DEBUG - 2016-10-09 13:24:27 --> Carabiner: library configured.
DEBUG - 2016-10-09 13:24:27 --> User Agent Class Initialized
DEBUG - 2016-10-09 13:24:27 --> Model Class Initialized
DEBUG - 2016-10-09 13:24:27 --> Model Class Initialized
DEBUG - 2016-10-09 13:24:27 --> Model Class Initialized
ERROR - 2016-10-09 13:24:27 --> Hak Akses modul/kontroller 'home' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-09 13:24:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-10-09 13:24:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-10-09 13:24:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-09 13:24:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 13:24:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-09 13:24:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-09 13:24:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-09 13:24:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-09 13:24:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-09 13:24:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 13:24:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-09 13:24:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-09 13:24:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 13:24:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-09 13:24:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-09 13:24:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-09 13:24:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-09 13:24:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-09 13:24:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 13:24:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-09 13:24:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-10-09 13:24:27 --> Final output sent to browser
DEBUG - 2016-10-09 13:24:27 --> Total execution time: 0.5678
DEBUG - 2016-10-09 13:24:29 --> Config Class Initialized
DEBUG - 2016-10-09 13:24:29 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:24:29 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:24:29 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:24:29 --> URI Class Initialized
DEBUG - 2016-10-09 13:24:29 --> Router Class Initialized
DEBUG - 2016-10-09 13:24:29 --> Output Class Initialized
DEBUG - 2016-10-09 13:24:29 --> Cache file has expired. File deleted
DEBUG - 2016-10-09 13:24:29 --> Security Class Initialized
DEBUG - 2016-10-09 13:24:29 --> Input Class Initialized
DEBUG - 2016-10-09 13:24:29 --> XSS Filtering completed
DEBUG - 2016-10-09 13:24:29 --> XSS Filtering completed
DEBUG - 2016-10-09 13:24:29 --> XSS Filtering completed
DEBUG - 2016-10-09 13:24:29 --> XSS Filtering completed
DEBUG - 2016-10-09 13:24:29 --> XSS Filtering completed
DEBUG - 2016-10-09 13:24:29 --> XSS Filtering completed
DEBUG - 2016-10-09 13:24:30 --> XSS Filtering completed
DEBUG - 2016-10-09 13:24:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-09 13:24:30 --> Language Class Initialized
DEBUG - 2016-10-09 13:24:30 --> Loader Class Initialized
DEBUG - 2016-10-09 13:24:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-09 13:24:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-09 13:24:30 --> Helper loaded: url_helper
DEBUG - 2016-10-09 13:24:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-09 13:24:30 --> Helper loaded: file_helper
DEBUG - 2016-10-09 13:24:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 13:24:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-09 13:24:30 --> Helper loaded: conf_helper
DEBUG - 2016-10-09 13:24:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 13:24:30 --> Check Exists common_helper.php: No
DEBUG - 2016-10-09 13:24:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-09 13:24:30 --> Helper loaded: common_helper
DEBUG - 2016-10-09 13:24:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-09 13:24:30 --> Helper loaded: common_helper
DEBUG - 2016-10-09 13:24:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-09 13:24:30 --> Helper loaded: form_helper
DEBUG - 2016-10-09 13:24:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-09 13:24:30 --> Helper loaded: security_helper
DEBUG - 2016-10-09 13:24:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 13:24:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-09 13:24:30 --> Helper loaded: lang_helper
DEBUG - 2016-10-09 13:24:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 13:24:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-09 13:24:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-09 13:24:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-09 13:24:30 --> Helper loaded: atlant_helper
DEBUG - 2016-10-09 13:24:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 13:24:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-09 13:24:30 --> Helper loaded: crypto_helper
DEBUG - 2016-10-09 13:24:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 13:24:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-09 13:24:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-09 13:24:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-09 13:24:30 --> Helper loaded: sidika_helper
DEBUG - 2016-10-09 13:24:30 --> Database Driver Class Initialized
DEBUG - 2016-10-09 13:24:30 --> Session Class Initialized
DEBUG - 2016-10-09 13:24:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-09 13:24:30 --> Helper loaded: string_helper
DEBUG - 2016-10-09 13:24:30 --> Session routines successfully run
DEBUG - 2016-10-09 13:24:30 --> Native_session Class Initialized
DEBUG - 2016-10-09 13:24:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-09 13:24:30 --> Form Validation Class Initialized
DEBUG - 2016-10-09 13:24:30 --> Form Validation Class Initialized
DEBUG - 2016-10-09 13:24:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 13:24:30 --> Controller Class Initialized
DEBUG - 2016-10-09 13:24:30 --> Carabiner: Library initialized.
DEBUG - 2016-10-09 13:24:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-09 13:24:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-09 13:24:30 --> Carabiner: library configured.
DEBUG - 2016-10-09 13:24:30 --> Carabiner: library configured.
DEBUG - 2016-10-09 13:24:30 --> User Agent Class Initialized
DEBUG - 2016-10-09 13:24:30 --> Model Class Initialized
DEBUG - 2016-10-09 13:24:30 --> Model Class Initialized
DEBUG - 2016-10-09 13:24:30 --> Model Class Initialized
DEBUG - 2016-10-09 13:24:30 --> Model Class Initialized
DEBUG - 2016-10-09 13:24:30 --> Model Class Initialized
DEBUG - 2016-10-09 13:24:30 --> Model Class Initialized
DEBUG - 2016-10-09 13:24:30 --> Model Class Initialized
DEBUG - 2016-10-09 13:24:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-10-09 13:24:30 --> Final output sent to browser
DEBUG - 2016-10-09 13:24:30 --> Total execution time: 0.7192
DEBUG - 2016-10-09 13:26:30 --> Config Class Initialized
DEBUG - 2016-10-09 13:26:30 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:26:30 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:26:30 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:26:30 --> URI Class Initialized
DEBUG - 2016-10-09 13:26:30 --> Router Class Initialized
DEBUG - 2016-10-09 13:26:30 --> No URI present. Default controller set.
DEBUG - 2016-10-09 13:26:30 --> Output Class Initialized
DEBUG - 2016-10-09 13:26:30 --> Cache file has expired. File deleted
DEBUG - 2016-10-09 13:26:30 --> Security Class Initialized
DEBUG - 2016-10-09 13:26:30 --> Input Class Initialized
DEBUG - 2016-10-09 13:26:30 --> XSS Filtering completed
DEBUG - 2016-10-09 13:26:30 --> XSS Filtering completed
DEBUG - 2016-10-09 13:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-09 13:26:30 --> Language Class Initialized
DEBUG - 2016-10-09 13:26:30 --> Loader Class Initialized
DEBUG - 2016-10-09 13:26:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-09 13:26:30 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-09 13:26:30 --> Helper loaded: url_helper
DEBUG - 2016-10-09 13:26:30 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-09 13:26:30 --> Helper loaded: file_helper
DEBUG - 2016-10-09 13:26:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 13:26:30 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-09 13:26:30 --> Helper loaded: conf_helper
DEBUG - 2016-10-09 13:26:30 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 13:26:30 --> Check Exists common_helper.php: No
DEBUG - 2016-10-09 13:26:30 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-09 13:26:30 --> Helper loaded: common_helper
DEBUG - 2016-10-09 13:26:30 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-09 13:26:30 --> Helper loaded: common_helper
DEBUG - 2016-10-09 13:26:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-09 13:26:30 --> Helper loaded: form_helper
DEBUG - 2016-10-09 13:26:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-09 13:26:30 --> Helper loaded: security_helper
DEBUG - 2016-10-09 13:26:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 13:26:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-09 13:26:30 --> Helper loaded: lang_helper
DEBUG - 2016-10-09 13:26:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 13:26:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-09 13:26:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-09 13:26:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-09 13:26:30 --> Helper loaded: atlant_helper
DEBUG - 2016-10-09 13:26:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 13:26:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-09 13:26:30 --> Helper loaded: crypto_helper
DEBUG - 2016-10-09 13:26:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 13:26:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-09 13:26:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-09 13:26:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-09 13:26:30 --> Helper loaded: sidika_helper
DEBUG - 2016-10-09 13:26:30 --> Database Driver Class Initialized
DEBUG - 2016-10-09 13:26:30 --> Session Class Initialized
DEBUG - 2016-10-09 13:26:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-09 13:26:30 --> Helper loaded: string_helper
DEBUG - 2016-10-09 13:26:30 --> Session routines successfully run
DEBUG - 2016-10-09 13:26:30 --> Native_session Class Initialized
DEBUG - 2016-10-09 13:26:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-09 13:26:30 --> Form Validation Class Initialized
DEBUG - 2016-10-09 13:26:30 --> Form Validation Class Initialized
DEBUG - 2016-10-09 13:26:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 13:26:30 --> Controller Class Initialized
DEBUG - 2016-10-09 13:26:30 --> Carabiner: Library initialized.
DEBUG - 2016-10-09 13:26:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-09 13:26:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-09 13:26:30 --> Carabiner: library configured.
DEBUG - 2016-10-09 13:26:30 --> Carabiner: library configured.
DEBUG - 2016-10-09 13:26:30 --> User Agent Class Initialized
DEBUG - 2016-10-09 13:26:30 --> Model Class Initialized
DEBUG - 2016-10-09 13:26:30 --> Model Class Initialized
DEBUG - 2016-10-09 13:26:30 --> Model Class Initialized
ERROR - 2016-10-09 13:26:30 --> Hak Akses modul/kontroller 'home' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-09 13:26:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-10-09 13:26:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-10-09 13:26:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-09 13:26:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 13:26:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-09 13:26:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-09 13:26:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-09 13:26:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-09 13:26:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-09 13:26:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 13:26:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-09 13:26:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-09 13:26:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 13:26:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-09 13:26:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-09 13:26:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-09 13:26:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-09 13:26:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-09 13:26:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 13:26:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-09 13:26:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-10-09 13:26:30 --> Final output sent to browser
DEBUG - 2016-10-09 13:26:30 --> Total execution time: 0.5118
DEBUG - 2016-10-09 13:26:31 --> Config Class Initialized
DEBUG - 2016-10-09 13:26:31 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:26:31 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:26:31 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:26:31 --> URI Class Initialized
DEBUG - 2016-10-09 13:26:31 --> Router Class Initialized
DEBUG - 2016-10-09 13:26:31 --> Output Class Initialized
DEBUG - 2016-10-09 13:26:31 --> Cache file has expired. File deleted
DEBUG - 2016-10-09 13:26:31 --> Security Class Initialized
DEBUG - 2016-10-09 13:26:31 --> Input Class Initialized
DEBUG - 2016-10-09 13:26:31 --> XSS Filtering completed
DEBUG - 2016-10-09 13:26:31 --> XSS Filtering completed
DEBUG - 2016-10-09 13:26:31 --> XSS Filtering completed
DEBUG - 2016-10-09 13:26:31 --> XSS Filtering completed
DEBUG - 2016-10-09 13:26:31 --> XSS Filtering completed
DEBUG - 2016-10-09 13:26:31 --> XSS Filtering completed
DEBUG - 2016-10-09 13:26:31 --> XSS Filtering completed
DEBUG - 2016-10-09 13:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-09 13:26:31 --> Language Class Initialized
DEBUG - 2016-10-09 13:26:31 --> Loader Class Initialized
DEBUG - 2016-10-09 13:26:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-09 13:26:31 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-09 13:26:31 --> Helper loaded: url_helper
DEBUG - 2016-10-09 13:26:31 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-09 13:26:31 --> Helper loaded: file_helper
DEBUG - 2016-10-09 13:26:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 13:26:31 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-09 13:26:31 --> Helper loaded: conf_helper
DEBUG - 2016-10-09 13:26:31 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 13:26:31 --> Check Exists common_helper.php: No
DEBUG - 2016-10-09 13:26:31 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-09 13:26:31 --> Helper loaded: common_helper
DEBUG - 2016-10-09 13:26:31 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-09 13:26:31 --> Helper loaded: common_helper
DEBUG - 2016-10-09 13:26:31 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-09 13:26:31 --> Helper loaded: form_helper
DEBUG - 2016-10-09 13:26:31 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-09 13:26:31 --> Helper loaded: security_helper
DEBUG - 2016-10-09 13:26:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 13:26:31 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-09 13:26:31 --> Helper loaded: lang_helper
DEBUG - 2016-10-09 13:26:31 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 13:26:31 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-09 13:26:31 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-09 13:26:31 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-09 13:26:31 --> Helper loaded: atlant_helper
DEBUG - 2016-10-09 13:26:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 13:26:31 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-09 13:26:31 --> Helper loaded: crypto_helper
DEBUG - 2016-10-09 13:26:31 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 13:26:31 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-09 13:26:31 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-09 13:26:31 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-09 13:26:31 --> Helper loaded: sidika_helper
DEBUG - 2016-10-09 13:26:31 --> Database Driver Class Initialized
DEBUG - 2016-10-09 13:26:31 --> Session Class Initialized
DEBUG - 2016-10-09 13:26:31 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-09 13:26:31 --> Helper loaded: string_helper
DEBUG - 2016-10-09 13:26:31 --> Session routines successfully run
DEBUG - 2016-10-09 13:26:31 --> Native_session Class Initialized
DEBUG - 2016-10-09 13:26:31 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-09 13:26:31 --> Form Validation Class Initialized
DEBUG - 2016-10-09 13:26:31 --> Form Validation Class Initialized
DEBUG - 2016-10-09 13:26:31 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 13:26:31 --> Controller Class Initialized
DEBUG - 2016-10-09 13:26:31 --> Carabiner: Library initialized.
DEBUG - 2016-10-09 13:26:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-09 13:26:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-09 13:26:31 --> Carabiner: library configured.
DEBUG - 2016-10-09 13:26:31 --> Carabiner: library configured.
DEBUG - 2016-10-09 13:26:31 --> User Agent Class Initialized
DEBUG - 2016-10-09 13:26:31 --> Model Class Initialized
DEBUG - 2016-10-09 13:26:31 --> Model Class Initialized
DEBUG - 2016-10-09 13:26:31 --> Model Class Initialized
DEBUG - 2016-10-09 13:26:31 --> Model Class Initialized
DEBUG - 2016-10-09 13:26:31 --> Model Class Initialized
DEBUG - 2016-10-09 13:26:31 --> Model Class Initialized
DEBUG - 2016-10-09 13:26:31 --> Model Class Initialized
DEBUG - 2016-10-09 13:26:31 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-10-09 13:26:31 --> Final output sent to browser
DEBUG - 2016-10-09 13:26:31 --> Total execution time: 0.6112
DEBUG - 2016-10-09 13:26:37 --> Config Class Initialized
DEBUG - 2016-10-09 13:26:37 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:26:37 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:26:37 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:26:37 --> URI Class Initialized
DEBUG - 2016-10-09 13:26:37 --> Router Class Initialized
ERROR - 2016-10-09 13:26:37 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:26:37 --> Config Class Initialized
DEBUG - 2016-10-09 13:26:37 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:26:37 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:26:37 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:26:37 --> URI Class Initialized
DEBUG - 2016-10-09 13:26:37 --> Router Class Initialized
ERROR - 2016-10-09 13:26:37 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:26:37 --> Config Class Initialized
DEBUG - 2016-10-09 13:26:37 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:26:37 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:26:37 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:26:37 --> URI Class Initialized
DEBUG - 2016-10-09 13:26:37 --> Router Class Initialized
ERROR - 2016-10-09 13:26:37 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:26:43 --> Config Class Initialized
DEBUG - 2016-10-09 13:26:43 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:26:43 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:26:43 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:26:43 --> URI Class Initialized
DEBUG - 2016-10-09 13:26:43 --> Router Class Initialized
ERROR - 2016-10-09 13:26:43 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:26:43 --> Config Class Initialized
DEBUG - 2016-10-09 13:26:43 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:26:43 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:26:43 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:26:43 --> URI Class Initialized
DEBUG - 2016-10-09 13:26:43 --> Router Class Initialized
ERROR - 2016-10-09 13:26:43 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:35:21 --> Config Class Initialized
DEBUG - 2016-10-09 13:35:21 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:35:21 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:35:21 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:35:21 --> URI Class Initialized
DEBUG - 2016-10-09 13:35:21 --> Router Class Initialized
ERROR - 2016-10-09 13:35:21 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:35:21 --> Config Class Initialized
DEBUG - 2016-10-09 13:35:21 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:35:21 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:35:21 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:35:21 --> URI Class Initialized
DEBUG - 2016-10-09 13:35:21 --> Router Class Initialized
ERROR - 2016-10-09 13:35:21 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:35:22 --> Config Class Initialized
DEBUG - 2016-10-09 13:35:22 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:35:22 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:35:22 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:35:22 --> URI Class Initialized
DEBUG - 2016-10-09 13:35:22 --> Router Class Initialized
ERROR - 2016-10-09 13:35:22 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:35:23 --> Config Class Initialized
DEBUG - 2016-10-09 13:35:23 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:35:23 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:35:23 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:35:23 --> URI Class Initialized
DEBUG - 2016-10-09 13:35:23 --> Router Class Initialized
ERROR - 2016-10-09 13:35:23 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:45:56 --> Config Class Initialized
DEBUG - 2016-10-09 13:45:56 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:45:56 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:45:56 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:45:56 --> URI Class Initialized
DEBUG - 2016-10-09 13:45:56 --> Router Class Initialized
ERROR - 2016-10-09 13:45:56 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:45:56 --> Config Class Initialized
DEBUG - 2016-10-09 13:45:56 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:45:56 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:45:56 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:45:56 --> URI Class Initialized
DEBUG - 2016-10-09 13:45:56 --> Router Class Initialized
ERROR - 2016-10-09 13:45:56 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:46:26 --> Config Class Initialized
DEBUG - 2016-10-09 13:46:26 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:46:26 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:46:26 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:46:26 --> URI Class Initialized
DEBUG - 2016-10-09 13:46:26 --> Router Class Initialized
DEBUG - 2016-10-09 13:46:26 --> Output Class Initialized
DEBUG - 2016-10-09 13:46:26 --> Cache file has expired. File deleted
DEBUG - 2016-10-09 13:46:26 --> Security Class Initialized
DEBUG - 2016-10-09 13:46:26 --> Input Class Initialized
DEBUG - 2016-10-09 13:46:26 --> XSS Filtering completed
DEBUG - 2016-10-09 13:46:26 --> XSS Filtering completed
DEBUG - 2016-10-09 13:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-09 13:46:26 --> Language Class Initialized
DEBUG - 2016-10-09 13:46:26 --> Loader Class Initialized
DEBUG - 2016-10-09 13:46:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-09 13:46:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-09 13:46:26 --> Helper loaded: url_helper
DEBUG - 2016-10-09 13:46:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-09 13:46:26 --> Helper loaded: file_helper
DEBUG - 2016-10-09 13:46:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 13:46:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-09 13:46:26 --> Helper loaded: conf_helper
DEBUG - 2016-10-09 13:46:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 13:46:26 --> Check Exists common_helper.php: No
DEBUG - 2016-10-09 13:46:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-09 13:46:26 --> Helper loaded: common_helper
DEBUG - 2016-10-09 13:46:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-09 13:46:26 --> Helper loaded: common_helper
DEBUG - 2016-10-09 13:46:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-09 13:46:26 --> Helper loaded: form_helper
DEBUG - 2016-10-09 13:46:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-09 13:46:26 --> Helper loaded: security_helper
DEBUG - 2016-10-09 13:46:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 13:46:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-09 13:46:26 --> Helper loaded: lang_helper
DEBUG - 2016-10-09 13:46:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 13:46:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-09 13:46:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-09 13:46:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-09 13:46:26 --> Helper loaded: atlant_helper
DEBUG - 2016-10-09 13:46:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 13:46:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-09 13:46:26 --> Helper loaded: crypto_helper
DEBUG - 2016-10-09 13:46:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 13:46:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-09 13:46:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-09 13:46:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-09 13:46:26 --> Helper loaded: sidika_helper
DEBUG - 2016-10-09 13:46:26 --> Database Driver Class Initialized
DEBUG - 2016-10-09 13:46:26 --> Session Class Initialized
DEBUG - 2016-10-09 13:46:26 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-09 13:46:26 --> Helper loaded: string_helper
ERROR - 2016-10-09 13:46:26 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2016-10-09 13:46:26 --> Session routines successfully run
DEBUG - 2016-10-09 13:46:26 --> Native_session Class Initialized
DEBUG - 2016-10-09 13:46:26 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-09 13:46:26 --> Form Validation Class Initialized
DEBUG - 2016-10-09 13:46:26 --> Form Validation Class Initialized
DEBUG - 2016-10-09 13:46:26 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 13:46:26 --> Controller Class Initialized
DEBUG - 2016-10-09 13:46:26 --> Carabiner: Library initialized.
DEBUG - 2016-10-09 13:46:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-09 13:46:26 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-09 13:46:26 --> Carabiner: library configured.
DEBUG - 2016-10-09 13:46:26 --> Carabiner: library configured.
DEBUG - 2016-10-09 13:46:26 --> User Agent Class Initialized
DEBUG - 2016-10-09 13:46:26 --> Model Class Initialized
DEBUG - 2016-10-09 13:46:26 --> Model Class Initialized
DEBUG - 2016-10-09 13:46:26 --> Model Class Initialized
DEBUG - 2016-10-09 13:46:26 --> Model Class Initialized
DEBUG - 2016-10-09 13:46:26 --> Model Class Initialized
DEBUG - 2016-10-09 13:46:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-09 13:46:26 --> Pagination Class Initialized
DEBUG - 2016-10-09 13:46:26 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-09 13:46:26 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/role/atlant/index.php
DEBUG - 2016-10-09 13:46:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-09 13:46:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-09 13:46:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 13:46:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-09 13:46:26 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/role/atlant/js/index_js.php
DEBUG - 2016-10-09 13:46:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 13:46:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-09 13:46:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-09 13:46:26 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-09 13:46:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 13:46:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-09 13:46:27 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/role/atlant/js/index_js.php
DEBUG - 2016-10-09 13:46:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 13:46:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-09 13:46:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/bc71e124988d1eb532a929fcbfe4318b
DEBUG - 2016-10-09 13:46:27 --> Final output sent to browser
DEBUG - 2016-10-09 13:46:27 --> Total execution time: 0.6555
DEBUG - 2016-10-09 13:55:46 --> Config Class Initialized
DEBUG - 2016-10-09 13:55:46 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:55:46 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:55:46 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:55:46 --> URI Class Initialized
DEBUG - 2016-10-09 13:55:46 --> Router Class Initialized
DEBUG - 2016-10-09 13:55:46 --> Output Class Initialized
DEBUG - 2016-10-09 13:55:46 --> Cache file has expired. File deleted
DEBUG - 2016-10-09 13:55:46 --> Security Class Initialized
DEBUG - 2016-10-09 13:55:46 --> Input Class Initialized
DEBUG - 2016-10-09 13:55:46 --> XSS Filtering completed
DEBUG - 2016-10-09 13:55:46 --> XSS Filtering completed
DEBUG - 2016-10-09 13:55:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-09 13:55:46 --> Language Class Initialized
DEBUG - 2016-10-09 13:55:46 --> Loader Class Initialized
DEBUG - 2016-10-09 13:55:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-09 13:55:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-09 13:55:46 --> Helper loaded: url_helper
DEBUG - 2016-10-09 13:55:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-09 13:55:46 --> Helper loaded: file_helper
DEBUG - 2016-10-09 13:55:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 13:55:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-09 13:55:46 --> Helper loaded: conf_helper
DEBUG - 2016-10-09 13:55:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-09 13:55:46 --> Check Exists common_helper.php: No
DEBUG - 2016-10-09 13:55:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-09 13:55:46 --> Helper loaded: common_helper
DEBUG - 2016-10-09 13:55:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-09 13:55:46 --> Helper loaded: common_helper
DEBUG - 2016-10-09 13:55:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-09 13:55:46 --> Helper loaded: form_helper
DEBUG - 2016-10-09 13:55:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-09 13:55:46 --> Helper loaded: security_helper
DEBUG - 2016-10-09 13:55:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 13:55:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-09 13:55:46 --> Helper loaded: lang_helper
DEBUG - 2016-10-09 13:55:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-09 13:55:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-09 13:55:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-09 13:55:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-09 13:55:46 --> Helper loaded: atlant_helper
DEBUG - 2016-10-09 13:55:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 13:55:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-09 13:55:46 --> Helper loaded: crypto_helper
DEBUG - 2016-10-09 13:55:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-09 13:55:46 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-09 13:55:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-09 13:55:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-09 13:55:46 --> Helper loaded: sidika_helper
DEBUG - 2016-10-09 13:55:46 --> Database Driver Class Initialized
DEBUG - 2016-10-09 13:55:46 --> Session Class Initialized
DEBUG - 2016-10-09 13:55:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-09 13:55:46 --> Helper loaded: string_helper
DEBUG - 2016-10-09 13:55:46 --> Session routines successfully run
DEBUG - 2016-10-09 13:55:46 --> Native_session Class Initialized
DEBUG - 2016-10-09 13:55:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-09 13:55:46 --> Form Validation Class Initialized
DEBUG - 2016-10-09 13:55:46 --> Form Validation Class Initialized
DEBUG - 2016-10-09 13:55:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-09 13:55:46 --> Controller Class Initialized
DEBUG - 2016-10-09 13:55:46 --> Carabiner: Library initialized.
DEBUG - 2016-10-09 13:55:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-09 13:55:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-09 13:55:46 --> Carabiner: library configured.
DEBUG - 2016-10-09 13:55:46 --> Carabiner: library configured.
DEBUG - 2016-10-09 13:55:46 --> User Agent Class Initialized
DEBUG - 2016-10-09 13:55:46 --> Model Class Initialized
DEBUG - 2016-10-09 13:55:46 --> Model Class Initialized
DEBUG - 2016-10-09 13:55:46 --> Model Class Initialized
DEBUG - 2016-10-09 13:55:46 --> Model Class Initialized
DEBUG - 2016-10-09 13:55:46 --> Model Class Initialized
DEBUG - 2016-10-09 13:55:46 --> Model Class Initialized
DEBUG - 2016-10-09 13:55:46 --> Model Class Initialized
DEBUG - 2016-10-09 13:55:46 --> Model Class Initialized
DEBUG - 2016-10-09 13:55:47 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-10-09 13:55:47 --> Pagination Class Initialized
DEBUG - 2016-10-09 13:55:47 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-10-09 13:55:47 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/index.php
DEBUG - 2016-10-09 13:55:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-09 13:55:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-09 13:55:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 13:55:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-09 13:55:47 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-09 13:55:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 13:55:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-09 13:55:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-10-09 13:55:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-10-09 13:55:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-09 13:55:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-10-09 13:55:47 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant/js/index_js.php
DEBUG - 2016-10-09 13:55:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-09 13:55:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-10-09 13:55:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/55961f1d1ca16fdfc4239ae1901a174e
DEBUG - 2016-10-09 13:55:47 --> Final output sent to browser
DEBUG - 2016-10-09 13:55:47 --> Total execution time: 0.7953
DEBUG - 2016-10-09 13:57:24 --> Config Class Initialized
DEBUG - 2016-10-09 13:57:24 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:57:24 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:57:24 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:57:24 --> URI Class Initialized
DEBUG - 2016-10-09 13:57:24 --> Router Class Initialized
ERROR - 2016-10-09 13:57:24 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:57:24 --> Config Class Initialized
DEBUG - 2016-10-09 13:57:24 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:57:24 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:57:24 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:57:24 --> URI Class Initialized
DEBUG - 2016-10-09 13:57:24 --> Router Class Initialized
ERROR - 2016-10-09 13:57:24 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:57:24 --> Config Class Initialized
DEBUG - 2016-10-09 13:57:24 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:57:24 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:57:24 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:57:24 --> URI Class Initialized
DEBUG - 2016-10-09 13:57:24 --> Router Class Initialized
ERROR - 2016-10-09 13:57:24 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:57:30 --> Config Class Initialized
DEBUG - 2016-10-09 13:57:30 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:57:30 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:57:30 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:57:30 --> URI Class Initialized
DEBUG - 2016-10-09 13:57:30 --> Router Class Initialized
ERROR - 2016-10-09 13:57:30 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:57:30 --> Config Class Initialized
DEBUG - 2016-10-09 13:57:30 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:57:30 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:57:30 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:57:30 --> URI Class Initialized
DEBUG - 2016-10-09 13:57:30 --> Router Class Initialized
ERROR - 2016-10-09 13:57:30 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:58:26 --> Config Class Initialized
DEBUG - 2016-10-09 13:58:26 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:58:26 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:58:26 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:58:26 --> URI Class Initialized
DEBUG - 2016-10-09 13:58:26 --> Router Class Initialized
ERROR - 2016-10-09 13:58:26 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:58:26 --> Config Class Initialized
DEBUG - 2016-10-09 13:58:26 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:58:26 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:58:26 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:58:26 --> URI Class Initialized
DEBUG - 2016-10-09 13:58:26 --> Router Class Initialized
ERROR - 2016-10-09 13:58:26 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:58:29 --> Config Class Initialized
DEBUG - 2016-10-09 13:58:29 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:58:29 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:58:29 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:58:29 --> URI Class Initialized
DEBUG - 2016-10-09 13:58:29 --> Router Class Initialized
ERROR - 2016-10-09 13:58:29 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:58:29 --> Config Class Initialized
DEBUG - 2016-10-09 13:58:29 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:58:29 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:58:29 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:58:29 --> URI Class Initialized
DEBUG - 2016-10-09 13:58:29 --> Router Class Initialized
ERROR - 2016-10-09 13:58:29 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:58:29 --> Config Class Initialized
DEBUG - 2016-10-09 13:58:30 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:58:30 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:58:30 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:58:30 --> URI Class Initialized
DEBUG - 2016-10-09 13:58:30 --> Router Class Initialized
ERROR - 2016-10-09 13:58:30 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:58:30 --> Config Class Initialized
DEBUG - 2016-10-09 13:58:30 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:58:30 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:58:30 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:58:30 --> URI Class Initialized
DEBUG - 2016-10-09 13:58:30 --> Router Class Initialized
ERROR - 2016-10-09 13:58:30 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:59:07 --> Config Class Initialized
DEBUG - 2016-10-09 13:59:07 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:59:07 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:59:07 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:59:07 --> URI Class Initialized
DEBUG - 2016-10-09 13:59:07 --> Router Class Initialized
ERROR - 2016-10-09 13:59:07 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:59:07 --> Config Class Initialized
DEBUG - 2016-10-09 13:59:07 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:59:07 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:59:07 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:59:07 --> URI Class Initialized
DEBUG - 2016-10-09 13:59:07 --> Router Class Initialized
ERROR - 2016-10-09 13:59:07 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:59:08 --> Config Class Initialized
DEBUG - 2016-10-09 13:59:08 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:59:08 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:59:08 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:59:08 --> URI Class Initialized
DEBUG - 2016-10-09 13:59:08 --> Router Class Initialized
ERROR - 2016-10-09 13:59:08 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:59:08 --> Config Class Initialized
DEBUG - 2016-10-09 13:59:08 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:59:08 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:59:08 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:59:08 --> URI Class Initialized
DEBUG - 2016-10-09 13:59:08 --> Router Class Initialized
ERROR - 2016-10-09 13:59:08 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:59:09 --> Config Class Initialized
DEBUG - 2016-10-09 13:59:09 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:59:09 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:59:09 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:59:09 --> URI Class Initialized
DEBUG - 2016-10-09 13:59:09 --> Router Class Initialized
ERROR - 2016-10-09 13:59:09 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 13:59:09 --> Config Class Initialized
DEBUG - 2016-10-09 13:59:09 --> Hooks Class Initialized
DEBUG - 2016-10-09 13:59:09 --> Utf8 Class Initialized
DEBUG - 2016-10-09 13:59:09 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 13:59:09 --> URI Class Initialized
DEBUG - 2016-10-09 13:59:09 --> Router Class Initialized
ERROR - 2016-10-09 13:59:09 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 14:01:41 --> Config Class Initialized
DEBUG - 2016-10-09 14:01:41 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:01:41 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:01:41 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:01:41 --> URI Class Initialized
DEBUG - 2016-10-09 14:01:41 --> Router Class Initialized
DEBUG - 2016-10-09 14:02:42 --> Config Class Initialized
DEBUG - 2016-10-09 14:02:42 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:02:42 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:02:42 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:02:42 --> URI Class Initialized
DEBUG - 2016-10-09 14:02:42 --> Router Class Initialized
DEBUG - 2016-10-09 14:02:42 --> Config Class Initialized
DEBUG - 2016-10-09 14:02:42 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:02:42 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:02:42 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:02:42 --> URI Class Initialized
DEBUG - 2016-10-09 14:02:42 --> Router Class Initialized
DEBUG - 2016-10-09 14:02:43 --> Config Class Initialized
DEBUG - 2016-10-09 14:02:43 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:02:43 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:02:43 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:02:43 --> URI Class Initialized
DEBUG - 2016-10-09 14:02:43 --> Router Class Initialized
DEBUG - 2016-10-09 14:02:43 --> Config Class Initialized
DEBUG - 2016-10-09 14:02:43 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:02:43 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:02:43 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:02:43 --> URI Class Initialized
DEBUG - 2016-10-09 14:02:43 --> Router Class Initialized
DEBUG - 2016-10-09 14:02:43 --> Config Class Initialized
DEBUG - 2016-10-09 14:02:43 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:02:43 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:02:43 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:02:43 --> URI Class Initialized
DEBUG - 2016-10-09 14:02:43 --> Router Class Initialized
DEBUG - 2016-10-09 14:02:43 --> Config Class Initialized
DEBUG - 2016-10-09 14:02:43 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:02:43 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:02:43 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:02:43 --> URI Class Initialized
DEBUG - 2016-10-09 14:02:43 --> Router Class Initialized
DEBUG - 2016-10-09 14:02:43 --> Config Class Initialized
DEBUG - 2016-10-09 14:02:43 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:02:43 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:02:43 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:02:43 --> URI Class Initialized
DEBUG - 2016-10-09 14:02:43 --> Router Class Initialized
DEBUG - 2016-10-09 14:02:44 --> Config Class Initialized
DEBUG - 2016-10-09 14:02:44 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:02:44 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:02:44 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:02:44 --> URI Class Initialized
DEBUG - 2016-10-09 14:02:44 --> Router Class Initialized
DEBUG - 2016-10-09 14:02:44 --> Config Class Initialized
DEBUG - 2016-10-09 14:02:44 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:02:44 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:02:44 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:02:44 --> URI Class Initialized
DEBUG - 2016-10-09 14:02:44 --> Router Class Initialized
DEBUG - 2016-10-09 14:02:44 --> Config Class Initialized
DEBUG - 2016-10-09 14:02:44 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:02:44 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:02:44 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:02:44 --> URI Class Initialized
DEBUG - 2016-10-09 14:02:44 --> Router Class Initialized
DEBUG - 2016-10-09 14:02:44 --> Config Class Initialized
DEBUG - 2016-10-09 14:02:44 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:02:44 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:02:44 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:02:44 --> URI Class Initialized
DEBUG - 2016-10-09 14:02:44 --> Router Class Initialized
DEBUG - 2016-10-09 14:02:47 --> Config Class Initialized
DEBUG - 2016-10-09 14:02:47 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:02:47 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:02:47 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:02:47 --> URI Class Initialized
DEBUG - 2016-10-09 14:02:47 --> Router Class Initialized
DEBUG - 2016-10-09 14:04:07 --> Config Class Initialized
DEBUG - 2016-10-09 14:04:07 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:04:07 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:04:07 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:04:07 --> URI Class Initialized
DEBUG - 2016-10-09 14:04:07 --> Router Class Initialized
ERROR - 2016-10-09 14:04:07 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 14:04:07 --> Config Class Initialized
DEBUG - 2016-10-09 14:04:07 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:04:07 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:04:07 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:04:07 --> URI Class Initialized
DEBUG - 2016-10-09 14:04:07 --> Router Class Initialized
ERROR - 2016-10-09 14:04:07 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 14:05:04 --> Config Class Initialized
DEBUG - 2016-10-09 14:05:04 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:05:04 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:05:04 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:05:04 --> URI Class Initialized
DEBUG - 2016-10-09 14:05:04 --> Router Class Initialized
ERROR - 2016-10-09 14:05:04 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 14:05:04 --> Config Class Initialized
DEBUG - 2016-10-09 14:05:04 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:05:04 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:05:04 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:05:04 --> URI Class Initialized
DEBUG - 2016-10-09 14:05:04 --> Router Class Initialized
ERROR - 2016-10-09 14:05:04 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 14:05:43 --> Config Class Initialized
DEBUG - 2016-10-09 14:05:43 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:05:43 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:05:43 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:05:43 --> URI Class Initialized
DEBUG - 2016-10-09 14:05:44 --> Router Class Initialized
ERROR - 2016-10-09 14:05:44 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 14:05:44 --> Config Class Initialized
DEBUG - 2016-10-09 14:05:44 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:05:44 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:05:44 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:05:44 --> URI Class Initialized
DEBUG - 2016-10-09 14:05:44 --> Router Class Initialized
ERROR - 2016-10-09 14:05:44 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 14:05:45 --> Config Class Initialized
DEBUG - 2016-10-09 14:05:45 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:05:45 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:05:45 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:05:45 --> URI Class Initialized
DEBUG - 2016-10-09 14:05:45 --> Router Class Initialized
ERROR - 2016-10-09 14:05:45 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 14:05:45 --> Config Class Initialized
DEBUG - 2016-10-09 14:05:45 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:05:45 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:05:45 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:05:45 --> URI Class Initialized
DEBUG - 2016-10-09 14:05:45 --> Router Class Initialized
ERROR - 2016-10-09 14:05:45 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 14:06:03 --> Config Class Initialized
DEBUG - 2016-10-09 14:06:03 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:06:03 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:06:03 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:06:03 --> URI Class Initialized
DEBUG - 2016-10-09 14:06:03 --> Router Class Initialized
ERROR - 2016-10-09 14:06:03 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 14:06:03 --> Config Class Initialized
DEBUG - 2016-10-09 14:06:03 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:06:03 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:06:03 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:06:03 --> URI Class Initialized
DEBUG - 2016-10-09 14:06:03 --> Router Class Initialized
ERROR - 2016-10-09 14:06:03 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 14:06:23 --> Config Class Initialized
DEBUG - 2016-10-09 14:06:23 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:06:23 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:06:23 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:06:23 --> URI Class Initialized
DEBUG - 2016-10-09 14:06:24 --> Router Class Initialized
DEBUG - 2016-10-09 14:06:35 --> Config Class Initialized
DEBUG - 2016-10-09 14:06:35 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:06:35 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:06:35 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:06:35 --> URI Class Initialized
DEBUG - 2016-10-09 14:06:37 --> Config Class Initialized
DEBUG - 2016-10-09 14:06:37 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:06:37 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:06:37 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:06:37 --> URI Class Initialized
DEBUG - 2016-10-09 14:06:49 --> Config Class Initialized
DEBUG - 2016-10-09 14:06:49 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:06:49 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:06:49 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:06:49 --> URI Class Initialized
DEBUG - 2016-10-09 14:06:49 --> Router Class Initialized
DEBUG - 2016-10-09 14:06:57 --> Config Class Initialized
DEBUG - 2016-10-09 14:06:57 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:06:57 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:06:58 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:06:58 --> URI Class Initialized
DEBUG - 2016-10-09 14:06:58 --> Router Class Initialized
DEBUG - 2016-10-09 14:07:16 --> Config Class Initialized
DEBUG - 2016-10-09 14:07:16 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:07:16 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:07:16 --> URI Class Initialized
DEBUG - 2016-10-09 14:07:16 --> Router Class Initialized
DEBUG - 2016-10-09 14:07:56 --> Config Class Initialized
DEBUG - 2016-10-09 14:07:56 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:07:56 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:07:56 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:07:56 --> URI Class Initialized
DEBUG - 2016-10-09 14:07:56 --> Router Class Initialized
DEBUG - 2016-10-09 14:07:57 --> Config Class Initialized
DEBUG - 2016-10-09 14:07:57 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:07:57 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:07:57 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:07:57 --> URI Class Initialized
DEBUG - 2016-10-09 14:07:57 --> Router Class Initialized
DEBUG - 2016-10-09 14:07:58 --> Config Class Initialized
DEBUG - 2016-10-09 14:07:58 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:07:58 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:07:58 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:07:58 --> URI Class Initialized
DEBUG - 2016-10-09 14:07:58 --> Router Class Initialized
DEBUG - 2016-10-09 14:07:58 --> Config Class Initialized
DEBUG - 2016-10-09 14:07:58 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:07:58 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:07:58 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:07:58 --> URI Class Initialized
DEBUG - 2016-10-09 14:07:58 --> Router Class Initialized
DEBUG - 2016-10-09 14:07:59 --> Config Class Initialized
DEBUG - 2016-10-09 14:07:59 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:07:59 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:07:59 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:07:59 --> URI Class Initialized
DEBUG - 2016-10-09 14:07:59 --> Router Class Initialized
DEBUG - 2016-10-09 14:07:59 --> Config Class Initialized
DEBUG - 2016-10-09 14:07:59 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:07:59 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:07:59 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:07:59 --> URI Class Initialized
DEBUG - 2016-10-09 14:07:59 --> Router Class Initialized
DEBUG - 2016-10-09 14:07:59 --> Config Class Initialized
DEBUG - 2016-10-09 14:07:59 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:07:59 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:07:59 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:07:59 --> URI Class Initialized
DEBUG - 2016-10-09 14:07:59 --> Router Class Initialized
DEBUG - 2016-10-09 14:08:24 --> Config Class Initialized
DEBUG - 2016-10-09 14:08:24 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:08:24 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:08:24 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:08:24 --> URI Class Initialized
DEBUG - 2016-10-09 14:08:24 --> Router Class Initialized
DEBUG - 2016-10-09 14:08:40 --> Config Class Initialized
DEBUG - 2016-10-09 14:08:40 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:08:40 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:08:40 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:08:40 --> URI Class Initialized
DEBUG - 2016-10-09 14:08:40 --> Router Class Initialized
DEBUG - 2016-10-09 14:08:41 --> Config Class Initialized
DEBUG - 2016-10-09 14:08:41 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:08:41 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:08:41 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:08:41 --> URI Class Initialized
DEBUG - 2016-10-09 14:08:41 --> Router Class Initialized
DEBUG - 2016-10-09 14:08:41 --> Config Class Initialized
DEBUG - 2016-10-09 14:08:41 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:08:41 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:08:41 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:08:41 --> URI Class Initialized
DEBUG - 2016-10-09 14:08:41 --> Router Class Initialized
DEBUG - 2016-10-09 14:09:25 --> Config Class Initialized
DEBUG - 2016-10-09 14:09:25 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:09:25 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:09:25 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:09:25 --> URI Class Initialized
DEBUG - 2016-10-09 14:09:25 --> Router Class Initialized
DEBUG - 2016-10-09 14:09:55 --> Config Class Initialized
DEBUG - 2016-10-09 14:09:55 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:09:55 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:09:55 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:09:55 --> URI Class Initialized
DEBUG - 2016-10-09 14:09:55 --> Router Class Initialized
ERROR - 2016-10-09 14:09:55 --> Severity: Notice  --> Undefined index: GitHub/mabesAD/back_bone/member E:\www\CodeIgniter-2.2.6\system\core\Router.php 369
DEBUG - 2016-10-09 14:10:13 --> Config Class Initialized
DEBUG - 2016-10-09 14:10:13 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:10:13 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:10:13 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:10:14 --> URI Class Initialized
DEBUG - 2016-10-09 14:10:14 --> Router Class Initialized
DEBUG - 2016-10-09 14:11:00 --> Config Class Initialized
DEBUG - 2016-10-09 14:11:00 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:11:00 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:11:00 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:11:00 --> URI Class Initialized
DEBUG - 2016-10-09 14:11:00 --> Router Class Initialized
DEBUG - 2016-10-09 14:11:31 --> Config Class Initialized
DEBUG - 2016-10-09 14:11:31 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:11:31 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:11:31 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:11:31 --> URI Class Initialized
DEBUG - 2016-10-09 14:11:31 --> Router Class Initialized
DEBUG - 2016-10-09 14:11:33 --> Config Class Initialized
DEBUG - 2016-10-09 14:11:33 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:11:33 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:11:33 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:11:33 --> URI Class Initialized
DEBUG - 2016-10-09 14:11:33 --> Router Class Initialized
DEBUG - 2016-10-09 14:11:43 --> Config Class Initialized
DEBUG - 2016-10-09 14:11:43 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:11:43 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:11:43 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:11:43 --> URI Class Initialized
DEBUG - 2016-10-09 14:11:43 --> Router Class Initialized
DEBUG - 2016-10-09 14:13:24 --> Config Class Initialized
DEBUG - 2016-10-09 14:13:24 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:13:24 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:13:24 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:13:24 --> URI Class Initialized
DEBUG - 2016-10-09 14:13:24 --> Router Class Initialized
DEBUG - 2016-10-09 14:15:00 --> Config Class Initialized
DEBUG - 2016-10-09 14:15:00 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:15:00 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:15:00 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:15:00 --> URI Class Initialized
DEBUG - 2016-10-09 14:15:00 --> Router Class Initialized
ERROR - 2016-10-09 14:15:00 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 14:15:00 --> Config Class Initialized
DEBUG - 2016-10-09 14:15:00 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:15:00 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:15:00 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:15:00 --> URI Class Initialized
DEBUG - 2016-10-09 14:15:00 --> Router Class Initialized
ERROR - 2016-10-09 14:15:00 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 14:15:01 --> Config Class Initialized
DEBUG - 2016-10-09 14:15:01 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:15:01 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:15:01 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:15:01 --> URI Class Initialized
DEBUG - 2016-10-09 14:15:01 --> Router Class Initialized
ERROR - 2016-10-09 14:15:01 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 14:15:01 --> Config Class Initialized
DEBUG - 2016-10-09 14:15:01 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:15:01 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:15:01 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:15:01 --> URI Class Initialized
DEBUG - 2016-10-09 14:15:01 --> Router Class Initialized
ERROR - 2016-10-09 14:15:01 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 14:15:16 --> Config Class Initialized
DEBUG - 2016-10-09 14:15:16 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:15:16 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:15:16 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:15:16 --> URI Class Initialized
DEBUG - 2016-10-09 14:15:16 --> Router Class Initialized
ERROR - 2016-10-09 14:15:16 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 14:15:16 --> Config Class Initialized
DEBUG - 2016-10-09 14:15:16 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:15:16 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:15:16 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:15:16 --> URI Class Initialized
DEBUG - 2016-10-09 14:15:16 --> Router Class Initialized
ERROR - 2016-10-09 14:15:16 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 14:15:17 --> Config Class Initialized
DEBUG - 2016-10-09 14:15:17 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:15:17 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:15:17 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:15:17 --> URI Class Initialized
DEBUG - 2016-10-09 14:15:17 --> Router Class Initialized
ERROR - 2016-10-09 14:15:17 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 14:15:17 --> Config Class Initialized
DEBUG - 2016-10-09 14:15:17 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:15:17 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:15:17 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:15:17 --> URI Class Initialized
DEBUG - 2016-10-09 14:15:17 --> Router Class Initialized
ERROR - 2016-10-09 14:15:17 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 14:15:17 --> Config Class Initialized
DEBUG - 2016-10-09 14:15:17 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:15:17 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:15:17 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:15:17 --> URI Class Initialized
DEBUG - 2016-10-09 14:15:17 --> Router Class Initialized
ERROR - 2016-10-09 14:15:17 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 14:15:18 --> Config Class Initialized
DEBUG - 2016-10-09 14:15:18 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:15:18 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:15:18 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:15:18 --> URI Class Initialized
DEBUG - 2016-10-09 14:15:18 --> Router Class Initialized
ERROR - 2016-10-09 14:15:18 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 14:15:18 --> Config Class Initialized
DEBUG - 2016-10-09 14:15:18 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:15:18 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:15:18 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:15:18 --> URI Class Initialized
DEBUG - 2016-10-09 14:15:18 --> Router Class Initialized
ERROR - 2016-10-09 14:15:18 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 14:15:18 --> Config Class Initialized
DEBUG - 2016-10-09 14:15:18 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:15:18 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:15:18 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:15:18 --> URI Class Initialized
DEBUG - 2016-10-09 14:15:18 --> Router Class Initialized
ERROR - 2016-10-09 14:15:18 --> 404 Page Not Found --> GitHub
DEBUG - 2016-10-09 14:17:30 --> Config Class Initialized
DEBUG - 2016-10-09 14:17:30 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:17:30 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:17:30 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:17:30 --> URI Class Initialized
DEBUG - 2016-10-09 14:17:30 --> Router Class Initialized
DEBUG - 2016-10-09 14:18:02 --> Config Class Initialized
DEBUG - 2016-10-09 14:18:02 --> Hooks Class Initialized
DEBUG - 2016-10-09 14:18:02 --> Utf8 Class Initialized
DEBUG - 2016-10-09 14:18:02 --> UTF-8 Support Enabled
DEBUG - 2016-10-09 14:18:02 --> URI Class Initialized
DEBUG - 2016-10-09 14:18:02 --> Router Class Initialized
