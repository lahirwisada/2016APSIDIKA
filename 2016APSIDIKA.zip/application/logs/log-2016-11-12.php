<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-11-12 16:11:41 --> Config Class Initialized
DEBUG - 2016-11-12 16:11:41 --> Hooks Class Initialized
DEBUG - 2016-11-12 16:11:42 --> Utf8 Class Initialized
DEBUG - 2016-11-12 16:11:42 --> UTF-8 Support Enabled
DEBUG - 2016-11-12 16:11:42 --> URI Class Initialized
DEBUG - 2016-11-12 16:11:42 --> Router Class Initialized
DEBUG - 2016-11-12 16:11:42 --> No URI present. Default controller set.
DEBUG - 2016-11-12 16:11:42 --> Output Class Initialized
DEBUG - 2016-11-12 16:11:42 --> Cache file has expired. File deleted
DEBUG - 2016-11-12 16:11:42 --> Security Class Initialized
DEBUG - 2016-11-12 16:11:42 --> Input Class Initialized
DEBUG - 2016-11-12 16:11:42 --> XSS Filtering completed
DEBUG - 2016-11-12 16:11:42 --> XSS Filtering completed
DEBUG - 2016-11-12 16:11:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-12 16:11:42 --> Language Class Initialized
DEBUG - 2016-11-12 16:11:42 --> Loader Class Initialized
DEBUG - 2016-11-12 16:11:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-12 16:11:42 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-12 16:11:42 --> Helper loaded: url_helper
DEBUG - 2016-11-12 16:11:42 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-12 16:11:42 --> Helper loaded: file_helper
DEBUG - 2016-11-12 16:11:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:11:42 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-12 16:11:42 --> Helper loaded: conf_helper
DEBUG - 2016-11-12 16:11:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:11:42 --> Check Exists common_helper.php: No
DEBUG - 2016-11-12 16:11:42 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-12 16:11:42 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:11:42 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-12 16:11:42 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:11:42 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-12 16:11:42 --> Helper loaded: form_helper
DEBUG - 2016-11-12 16:11:42 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-12 16:11:42 --> Helper loaded: security_helper
DEBUG - 2016-11-12 16:11:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:11:42 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-12 16:11:42 --> Helper loaded: lang_helper
DEBUG - 2016-11-12 16:11:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:11:42 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-12 16:11:42 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-12 16:11:42 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-12 16:11:42 --> Helper loaded: atlant_helper
DEBUG - 2016-11-12 16:11:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:11:42 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-12 16:11:42 --> Helper loaded: crypto_helper
DEBUG - 2016-11-12 16:11:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:11:42 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-12 16:11:42 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-12 16:11:42 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-12 16:11:42 --> Helper loaded: sidika_helper
DEBUG - 2016-11-12 16:11:42 --> Database Driver Class Initialized
DEBUG - 2016-11-12 16:11:42 --> Session Class Initialized
DEBUG - 2016-11-12 16:11:42 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-12 16:11:42 --> Helper loaded: string_helper
DEBUG - 2016-11-12 16:11:42 --> Session routines successfully run
DEBUG - 2016-11-12 16:11:42 --> Native_session Class Initialized
DEBUG - 2016-11-12 16:11:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-12 16:11:42 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:11:42 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:11:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-12 16:11:42 --> Controller Class Initialized
DEBUG - 2016-11-12 16:11:42 --> Carabiner: Library initialized.
DEBUG - 2016-11-12 16:11:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-12 16:11:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-12 16:11:42 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:11:42 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:11:42 --> User Agent Class Initialized
DEBUG - 2016-11-12 16:11:42 --> Model Class Initialized
DEBUG - 2016-11-12 16:11:42 --> Model Class Initialized
DEBUG - 2016-11-12 16:11:42 --> Model Class Initialized
ERROR - 2016-11-12 16:11:43 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-11-12 16:11:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-11-12 16:11:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-11-12 16:11:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-12 16:11:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-12 16:11:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-12 16:11:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-12 16:11:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-12 16:11:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-11-12 16:11:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-11-12 16:11:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-12 16:11:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-12 16:11:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-12 16:11:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-12 16:11:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-12 16:11:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-12 16:11:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-12 16:11:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-11-12 16:11:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-11-12 16:11:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-12 16:11:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-12 16:11:43 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-11-12 16:11:43 --> Final output sent to browser
DEBUG - 2016-11-12 16:11:43 --> Total execution time: 1.3730
DEBUG - 2016-11-12 16:11:44 --> Config Class Initialized
DEBUG - 2016-11-12 16:11:44 --> Hooks Class Initialized
DEBUG - 2016-11-12 16:11:44 --> Utf8 Class Initialized
DEBUG - 2016-11-12 16:11:44 --> UTF-8 Support Enabled
DEBUG - 2016-11-12 16:11:44 --> URI Class Initialized
DEBUG - 2016-11-12 16:11:44 --> Router Class Initialized
DEBUG - 2016-11-12 16:11:44 --> Output Class Initialized
DEBUG - 2016-11-12 16:11:44 --> Cache file has expired. File deleted
DEBUG - 2016-11-12 16:11:44 --> Security Class Initialized
DEBUG - 2016-11-12 16:11:44 --> Input Class Initialized
DEBUG - 2016-11-12 16:11:44 --> XSS Filtering completed
DEBUG - 2016-11-12 16:11:44 --> XSS Filtering completed
DEBUG - 2016-11-12 16:11:44 --> XSS Filtering completed
DEBUG - 2016-11-12 16:11:44 --> XSS Filtering completed
DEBUG - 2016-11-12 16:11:44 --> XSS Filtering completed
DEBUG - 2016-11-12 16:11:44 --> XSS Filtering completed
DEBUG - 2016-11-12 16:11:44 --> XSS Filtering completed
DEBUG - 2016-11-12 16:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-12 16:11:44 --> Language Class Initialized
DEBUG - 2016-11-12 16:11:44 --> Loader Class Initialized
DEBUG - 2016-11-12 16:11:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-12 16:11:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-12 16:11:44 --> Helper loaded: url_helper
DEBUG - 2016-11-12 16:11:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-12 16:11:44 --> Helper loaded: file_helper
DEBUG - 2016-11-12 16:11:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:11:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-12 16:11:44 --> Helper loaded: conf_helper
DEBUG - 2016-11-12 16:11:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:11:44 --> Check Exists common_helper.php: No
DEBUG - 2016-11-12 16:11:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-12 16:11:44 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:11:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-12 16:11:44 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:11:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-12 16:11:44 --> Helper loaded: form_helper
DEBUG - 2016-11-12 16:11:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-12 16:11:44 --> Helper loaded: security_helper
DEBUG - 2016-11-12 16:11:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:11:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-12 16:11:44 --> Helper loaded: lang_helper
DEBUG - 2016-11-12 16:11:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:11:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-12 16:11:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-12 16:11:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-12 16:11:44 --> Helper loaded: atlant_helper
DEBUG - 2016-11-12 16:11:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:11:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-12 16:11:44 --> Helper loaded: crypto_helper
DEBUG - 2016-11-12 16:11:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:11:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-12 16:11:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-12 16:11:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-12 16:11:44 --> Helper loaded: sidika_helper
DEBUG - 2016-11-12 16:11:44 --> Database Driver Class Initialized
DEBUG - 2016-11-12 16:11:44 --> Session Class Initialized
DEBUG - 2016-11-12 16:11:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-12 16:11:44 --> Helper loaded: string_helper
DEBUG - 2016-11-12 16:11:44 --> Session routines successfully run
DEBUG - 2016-11-12 16:11:44 --> Native_session Class Initialized
DEBUG - 2016-11-12 16:11:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-12 16:11:44 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:11:44 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:11:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-12 16:11:44 --> Controller Class Initialized
DEBUG - 2016-11-12 16:11:44 --> Carabiner: Library initialized.
DEBUG - 2016-11-12 16:11:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-12 16:11:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-12 16:11:44 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:11:44 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:11:44 --> User Agent Class Initialized
DEBUG - 2016-11-12 16:11:44 --> Model Class Initialized
DEBUG - 2016-11-12 16:11:44 --> Model Class Initialized
DEBUG - 2016-11-12 16:11:44 --> Model Class Initialized
DEBUG - 2016-11-12 16:11:44 --> Model Class Initialized
DEBUG - 2016-11-12 16:11:44 --> Model Class Initialized
DEBUG - 2016-11-12 16:11:44 --> Model Class Initialized
DEBUG - 2016-11-12 16:11:44 --> Model Class Initialized
DEBUG - 2016-11-12 16:11:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-11-12 16:11:46 --> Final output sent to browser
DEBUG - 2016-11-12 16:11:46 --> Total execution time: 1.8839
DEBUG - 2016-11-12 16:12:05 --> Config Class Initialized
DEBUG - 2016-11-12 16:12:05 --> Hooks Class Initialized
DEBUG - 2016-11-12 16:12:05 --> Utf8 Class Initialized
DEBUG - 2016-11-12 16:12:05 --> UTF-8 Support Enabled
DEBUG - 2016-11-12 16:12:05 --> URI Class Initialized
DEBUG - 2016-11-12 16:12:05 --> Router Class Initialized
DEBUG - 2016-11-12 16:12:05 --> Output Class Initialized
DEBUG - 2016-11-12 16:12:05 --> Cache file has expired. File deleted
DEBUG - 2016-11-12 16:12:05 --> Security Class Initialized
DEBUG - 2016-11-12 16:12:05 --> Input Class Initialized
DEBUG - 2016-11-12 16:12:05 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:05 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-12 16:12:05 --> Language Class Initialized
DEBUG - 2016-11-12 16:12:05 --> Loader Class Initialized
DEBUG - 2016-11-12 16:12:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-12 16:12:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-12 16:12:05 --> Helper loaded: url_helper
DEBUG - 2016-11-12 16:12:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-12 16:12:05 --> Helper loaded: file_helper
DEBUG - 2016-11-12 16:12:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:12:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-12 16:12:05 --> Helper loaded: conf_helper
DEBUG - 2016-11-12 16:12:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:12:05 --> Check Exists common_helper.php: No
DEBUG - 2016-11-12 16:12:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-12 16:12:05 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:12:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-12 16:12:05 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:12:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-12 16:12:05 --> Helper loaded: form_helper
DEBUG - 2016-11-12 16:12:05 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-12 16:12:05 --> Helper loaded: security_helper
DEBUG - 2016-11-12 16:12:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:12:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-12 16:12:05 --> Helper loaded: lang_helper
DEBUG - 2016-11-12 16:12:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:12:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-12 16:12:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-12 16:12:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-12 16:12:05 --> Helper loaded: atlant_helper
DEBUG - 2016-11-12 16:12:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:12:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-12 16:12:05 --> Helper loaded: crypto_helper
DEBUG - 2016-11-12 16:12:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:12:05 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-12 16:12:05 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-12 16:12:05 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-12 16:12:05 --> Helper loaded: sidika_helper
DEBUG - 2016-11-12 16:12:05 --> Database Driver Class Initialized
DEBUG - 2016-11-12 16:12:05 --> Session Class Initialized
DEBUG - 2016-11-12 16:12:05 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-12 16:12:05 --> Helper loaded: string_helper
DEBUG - 2016-11-12 16:12:05 --> Session routines successfully run
DEBUG - 2016-11-12 16:12:05 --> Native_session Class Initialized
DEBUG - 2016-11-12 16:12:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-12 16:12:05 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:12:05 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:12:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-12 16:12:05 --> Controller Class Initialized
DEBUG - 2016-11-12 16:12:05 --> Carabiner: Library initialized.
DEBUG - 2016-11-12 16:12:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-12 16:12:05 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-12 16:12:05 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:12:05 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:12:05 --> User Agent Class Initialized
DEBUG - 2016-11-12 16:12:05 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:05 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:05 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-11-12 16:12:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-12 16:12:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-12 16:12:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-12 16:12:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-12 16:12:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-12 16:12:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-12 16:12:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-12 16:12:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-12 16:12:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-12 16:12:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-12 16:12:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-12 16:12:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-12 16:12:06 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-11-12 16:12:06 --> Final output sent to browser
DEBUG - 2016-11-12 16:12:06 --> Total execution time: 0.2255
DEBUG - 2016-11-12 16:12:08 --> Config Class Initialized
DEBUG - 2016-11-12 16:12:08 --> Hooks Class Initialized
DEBUG - 2016-11-12 16:12:08 --> Utf8 Class Initialized
DEBUG - 2016-11-12 16:12:08 --> UTF-8 Support Enabled
DEBUG - 2016-11-12 16:12:08 --> URI Class Initialized
DEBUG - 2016-11-12 16:12:08 --> Router Class Initialized
DEBUG - 2016-11-12 16:12:08 --> Output Class Initialized
DEBUG - 2016-11-12 16:12:08 --> Security Class Initialized
DEBUG - 2016-11-12 16:12:08 --> Input Class Initialized
DEBUG - 2016-11-12 16:12:08 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:08 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-12 16:12:08 --> Language Class Initialized
DEBUG - 2016-11-12 16:12:08 --> Loader Class Initialized
DEBUG - 2016-11-12 16:12:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-12 16:12:08 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-12 16:12:08 --> Helper loaded: url_helper
DEBUG - 2016-11-12 16:12:08 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-12 16:12:08 --> Helper loaded: file_helper
DEBUG - 2016-11-12 16:12:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:12:08 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-12 16:12:08 --> Helper loaded: conf_helper
DEBUG - 2016-11-12 16:12:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:12:08 --> Check Exists common_helper.php: No
DEBUG - 2016-11-12 16:12:08 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-12 16:12:08 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:12:08 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-12 16:12:08 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:12:08 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-12 16:12:08 --> Helper loaded: form_helper
DEBUG - 2016-11-12 16:12:08 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-12 16:12:08 --> Helper loaded: security_helper
DEBUG - 2016-11-12 16:12:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:12:08 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-12 16:12:08 --> Helper loaded: lang_helper
DEBUG - 2016-11-12 16:12:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:12:08 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-12 16:12:08 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-12 16:12:08 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-12 16:12:08 --> Helper loaded: atlant_helper
DEBUG - 2016-11-12 16:12:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:12:08 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-12 16:12:08 --> Helper loaded: crypto_helper
DEBUG - 2016-11-12 16:12:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:12:08 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-12 16:12:08 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-12 16:12:08 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-12 16:12:08 --> Helper loaded: sidika_helper
DEBUG - 2016-11-12 16:12:08 --> Database Driver Class Initialized
DEBUG - 2016-11-12 16:12:08 --> Session Class Initialized
DEBUG - 2016-11-12 16:12:08 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-12 16:12:08 --> Helper loaded: string_helper
DEBUG - 2016-11-12 16:12:08 --> Session routines successfully run
DEBUG - 2016-11-12 16:12:08 --> Native_session Class Initialized
DEBUG - 2016-11-12 16:12:08 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-12 16:12:08 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:12:08 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:12:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-12 16:12:08 --> Controller Class Initialized
DEBUG - 2016-11-12 16:12:08 --> Carabiner: Library initialized.
DEBUG - 2016-11-12 16:12:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-12 16:12:08 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-12 16:12:08 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:12:08 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:12:08 --> User Agent Class Initialized
DEBUG - 2016-11-12 16:12:08 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:08 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:08 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:08 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:08 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:08 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:08 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:08 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-11-12 16:12:08 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-11-12 16:12:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-11-12 16:12:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-11-12 16:12:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-11-12 16:12:08 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-11-12 16:12:08 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-11-12 16:12:08 --> Final output sent to browser
DEBUG - 2016-11-12 16:12:08 --> Total execution time: 0.2374
DEBUG - 2016-11-12 16:12:09 --> Config Class Initialized
DEBUG - 2016-11-12 16:12:09 --> Hooks Class Initialized
DEBUG - 2016-11-12 16:12:09 --> Utf8 Class Initialized
DEBUG - 2016-11-12 16:12:09 --> UTF-8 Support Enabled
DEBUG - 2016-11-12 16:12:09 --> URI Class Initialized
DEBUG - 2016-11-12 16:12:09 --> Router Class Initialized
ERROR - 2016-11-12 16:12:09 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-11-12 16:12:15 --> Config Class Initialized
DEBUG - 2016-11-12 16:12:15 --> Hooks Class Initialized
DEBUG - 2016-11-12 16:12:15 --> Utf8 Class Initialized
DEBUG - 2016-11-12 16:12:15 --> UTF-8 Support Enabled
DEBUG - 2016-11-12 16:12:15 --> URI Class Initialized
DEBUG - 2016-11-12 16:12:15 --> Router Class Initialized
DEBUG - 2016-11-12 16:12:15 --> Output Class Initialized
DEBUG - 2016-11-12 16:12:15 --> Cache file has expired. File deleted
DEBUG - 2016-11-12 16:12:15 --> Security Class Initialized
DEBUG - 2016-11-12 16:12:15 --> Input Class Initialized
DEBUG - 2016-11-12 16:12:15 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:15 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:15 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:15 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-12 16:12:15 --> Language Class Initialized
DEBUG - 2016-11-12 16:12:15 --> Loader Class Initialized
DEBUG - 2016-11-12 16:12:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-12 16:12:15 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-12 16:12:15 --> Helper loaded: url_helper
DEBUG - 2016-11-12 16:12:15 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-12 16:12:15 --> Helper loaded: file_helper
DEBUG - 2016-11-12 16:12:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:12:15 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-12 16:12:15 --> Helper loaded: conf_helper
DEBUG - 2016-11-12 16:12:15 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:12:15 --> Check Exists common_helper.php: No
DEBUG - 2016-11-12 16:12:15 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-12 16:12:15 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:12:15 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-12 16:12:15 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:12:15 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-12 16:12:15 --> Helper loaded: form_helper
DEBUG - 2016-11-12 16:12:15 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-12 16:12:15 --> Helper loaded: security_helper
DEBUG - 2016-11-12 16:12:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:12:15 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-12 16:12:15 --> Helper loaded: lang_helper
DEBUG - 2016-11-12 16:12:15 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:12:15 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-12 16:12:15 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-12 16:12:15 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-12 16:12:15 --> Helper loaded: atlant_helper
DEBUG - 2016-11-12 16:12:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:12:15 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-12 16:12:15 --> Helper loaded: crypto_helper
DEBUG - 2016-11-12 16:12:15 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:12:15 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-12 16:12:15 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-12 16:12:15 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-12 16:12:15 --> Helper loaded: sidika_helper
DEBUG - 2016-11-12 16:12:15 --> Database Driver Class Initialized
DEBUG - 2016-11-12 16:12:15 --> Session Class Initialized
DEBUG - 2016-11-12 16:12:15 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-12 16:12:15 --> Helper loaded: string_helper
DEBUG - 2016-11-12 16:12:15 --> Session routines successfully run
DEBUG - 2016-11-12 16:12:15 --> Native_session Class Initialized
DEBUG - 2016-11-12 16:12:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-12 16:12:15 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:12:15 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:12:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-12 16:12:15 --> Controller Class Initialized
DEBUG - 2016-11-12 16:12:15 --> Carabiner: Library initialized.
DEBUG - 2016-11-12 16:12:15 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-12 16:12:15 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-12 16:12:15 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:12:15 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:12:15 --> User Agent Class Initialized
DEBUG - 2016-11-12 16:12:15 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:15 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:15 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:15 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:15 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:15 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:15 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-11-12 16:12:15 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:12:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-12 16:12:15 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-11-12 16:12:16 --> Config Class Initialized
DEBUG - 2016-11-12 16:12:16 --> Hooks Class Initialized
DEBUG - 2016-11-12 16:12:16 --> Utf8 Class Initialized
DEBUG - 2016-11-12 16:12:16 --> UTF-8 Support Enabled
DEBUG - 2016-11-12 16:12:16 --> URI Class Initialized
DEBUG - 2016-11-12 16:12:16 --> Router Class Initialized
DEBUG - 2016-11-12 16:12:16 --> No URI present. Default controller set.
DEBUG - 2016-11-12 16:12:16 --> Output Class Initialized
DEBUG - 2016-11-12 16:12:16 --> Cache file has expired. File deleted
DEBUG - 2016-11-12 16:12:16 --> Security Class Initialized
DEBUG - 2016-11-12 16:12:16 --> Input Class Initialized
DEBUG - 2016-11-12 16:12:16 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:16 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-12 16:12:16 --> Language Class Initialized
DEBUG - 2016-11-12 16:12:16 --> Loader Class Initialized
DEBUG - 2016-11-12 16:12:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-12 16:12:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-12 16:12:16 --> Helper loaded: url_helper
DEBUG - 2016-11-12 16:12:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-12 16:12:16 --> Helper loaded: file_helper
DEBUG - 2016-11-12 16:12:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:12:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-12 16:12:16 --> Helper loaded: conf_helper
DEBUG - 2016-11-12 16:12:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:12:16 --> Check Exists common_helper.php: No
DEBUG - 2016-11-12 16:12:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-12 16:12:16 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:12:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-12 16:12:16 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:12:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-12 16:12:16 --> Helper loaded: form_helper
DEBUG - 2016-11-12 16:12:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-12 16:12:16 --> Helper loaded: security_helper
DEBUG - 2016-11-12 16:12:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:12:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-12 16:12:16 --> Helper loaded: lang_helper
DEBUG - 2016-11-12 16:12:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:12:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-12 16:12:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-12 16:12:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-12 16:12:16 --> Helper loaded: atlant_helper
DEBUG - 2016-11-12 16:12:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:12:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-12 16:12:16 --> Helper loaded: crypto_helper
DEBUG - 2016-11-12 16:12:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:12:16 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-12 16:12:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-12 16:12:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-12 16:12:16 --> Helper loaded: sidika_helper
DEBUG - 2016-11-12 16:12:16 --> Database Driver Class Initialized
DEBUG - 2016-11-12 16:12:16 --> Session Class Initialized
DEBUG - 2016-11-12 16:12:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-12 16:12:16 --> Helper loaded: string_helper
DEBUG - 2016-11-12 16:12:16 --> Session routines successfully run
DEBUG - 2016-11-12 16:12:16 --> Native_session Class Initialized
DEBUG - 2016-11-12 16:12:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-12 16:12:16 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:12:16 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:12:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-12 16:12:16 --> Controller Class Initialized
DEBUG - 2016-11-12 16:12:16 --> Carabiner: Library initialized.
DEBUG - 2016-11-12 16:12:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-12 16:12:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-12 16:12:16 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:12:16 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:12:16 --> User Agent Class Initialized
DEBUG - 2016-11-12 16:12:16 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:16 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:16 --> Model Class Initialized
ERROR - 2016-11-12 16:12:16 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-11-12 16:12:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-11-12 16:12:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-11-12 16:12:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-12 16:12:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-12 16:12:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-12 16:12:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-12 16:12:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-12 16:12:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-11-12 16:12:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-11-12 16:12:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-12 16:12:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-12 16:12:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-12 16:12:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-12 16:12:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-12 16:12:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-12 16:12:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-12 16:12:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-11-12 16:12:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-11-12 16:12:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-12 16:12:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-12 16:12:16 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-11-12 16:12:16 --> Final output sent to browser
DEBUG - 2016-11-12 16:12:16 --> Total execution time: 0.2702
DEBUG - 2016-11-12 16:12:17 --> Config Class Initialized
DEBUG - 2016-11-12 16:12:17 --> Hooks Class Initialized
DEBUG - 2016-11-12 16:12:17 --> Utf8 Class Initialized
DEBUG - 2016-11-12 16:12:17 --> UTF-8 Support Enabled
DEBUG - 2016-11-12 16:12:17 --> URI Class Initialized
DEBUG - 2016-11-12 16:12:17 --> Router Class Initialized
DEBUG - 2016-11-12 16:12:17 --> Output Class Initialized
DEBUG - 2016-11-12 16:12:17 --> Cache file has expired. File deleted
DEBUG - 2016-11-12 16:12:17 --> Security Class Initialized
DEBUG - 2016-11-12 16:12:17 --> Input Class Initialized
DEBUG - 2016-11-12 16:12:17 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:17 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:17 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:17 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:17 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:17 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:17 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-12 16:12:17 --> Language Class Initialized
DEBUG - 2016-11-12 16:12:17 --> Loader Class Initialized
DEBUG - 2016-11-12 16:12:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-12 16:12:17 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-12 16:12:17 --> Helper loaded: url_helper
DEBUG - 2016-11-12 16:12:17 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-12 16:12:17 --> Helper loaded: file_helper
DEBUG - 2016-11-12 16:12:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:12:17 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-12 16:12:17 --> Helper loaded: conf_helper
DEBUG - 2016-11-12 16:12:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:12:17 --> Check Exists common_helper.php: No
DEBUG - 2016-11-12 16:12:17 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-12 16:12:17 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:12:17 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-12 16:12:17 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:12:17 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-12 16:12:17 --> Helper loaded: form_helper
DEBUG - 2016-11-12 16:12:17 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-12 16:12:17 --> Helper loaded: security_helper
DEBUG - 2016-11-12 16:12:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:12:17 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-12 16:12:17 --> Helper loaded: lang_helper
DEBUG - 2016-11-12 16:12:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:12:17 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-12 16:12:17 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-12 16:12:17 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-12 16:12:17 --> Helper loaded: atlant_helper
DEBUG - 2016-11-12 16:12:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:12:17 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-12 16:12:17 --> Helper loaded: crypto_helper
DEBUG - 2016-11-12 16:12:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:12:17 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-12 16:12:17 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-12 16:12:17 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-12 16:12:17 --> Helper loaded: sidika_helper
DEBUG - 2016-11-12 16:12:17 --> Database Driver Class Initialized
DEBUG - 2016-11-12 16:12:17 --> Session Class Initialized
DEBUG - 2016-11-12 16:12:17 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-12 16:12:17 --> Helper loaded: string_helper
DEBUG - 2016-11-12 16:12:17 --> Session routines successfully run
DEBUG - 2016-11-12 16:12:17 --> Native_session Class Initialized
DEBUG - 2016-11-12 16:12:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-12 16:12:17 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:12:17 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:12:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-12 16:12:17 --> Controller Class Initialized
DEBUG - 2016-11-12 16:12:17 --> Carabiner: Library initialized.
DEBUG - 2016-11-12 16:12:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-12 16:12:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-12 16:12:17 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:12:17 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:12:17 --> User Agent Class Initialized
DEBUG - 2016-11-12 16:12:17 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:17 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:17 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:17 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:17 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:17 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:17 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:17 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-11-12 16:12:17 --> Final output sent to browser
DEBUG - 2016-11-12 16:12:17 --> Total execution time: 0.3725
DEBUG - 2016-11-12 16:12:22 --> Config Class Initialized
DEBUG - 2016-11-12 16:12:22 --> Hooks Class Initialized
DEBUG - 2016-11-12 16:12:23 --> Utf8 Class Initialized
DEBUG - 2016-11-12 16:12:23 --> UTF-8 Support Enabled
DEBUG - 2016-11-12 16:12:23 --> URI Class Initialized
DEBUG - 2016-11-12 16:12:23 --> Router Class Initialized
DEBUG - 2016-11-12 16:12:23 --> Output Class Initialized
DEBUG - 2016-11-12 16:12:23 --> Cache file has expired. File deleted
DEBUG - 2016-11-12 16:12:23 --> Security Class Initialized
DEBUG - 2016-11-12 16:12:23 --> Input Class Initialized
DEBUG - 2016-11-12 16:12:23 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:23 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-12 16:12:23 --> Language Class Initialized
DEBUG - 2016-11-12 16:12:23 --> Loader Class Initialized
DEBUG - 2016-11-12 16:12:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-12 16:12:23 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-12 16:12:23 --> Helper loaded: url_helper
DEBUG - 2016-11-12 16:12:23 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-12 16:12:23 --> Helper loaded: file_helper
DEBUG - 2016-11-12 16:12:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:12:23 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-12 16:12:23 --> Helper loaded: conf_helper
DEBUG - 2016-11-12 16:12:23 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:12:23 --> Check Exists common_helper.php: No
DEBUG - 2016-11-12 16:12:23 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-12 16:12:23 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:12:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-12 16:12:23 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:12:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-12 16:12:23 --> Helper loaded: form_helper
DEBUG - 2016-11-12 16:12:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-12 16:12:23 --> Helper loaded: security_helper
DEBUG - 2016-11-12 16:12:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:12:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-12 16:12:23 --> Helper loaded: lang_helper
DEBUG - 2016-11-12 16:12:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:12:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-12 16:12:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-12 16:12:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-12 16:12:23 --> Helper loaded: atlant_helper
DEBUG - 2016-11-12 16:12:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:12:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-12 16:12:23 --> Helper loaded: crypto_helper
DEBUG - 2016-11-12 16:12:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:12:23 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-12 16:12:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-12 16:12:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-12 16:12:23 --> Helper loaded: sidika_helper
DEBUG - 2016-11-12 16:12:23 --> Database Driver Class Initialized
DEBUG - 2016-11-12 16:12:23 --> Session Class Initialized
DEBUG - 2016-11-12 16:12:23 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-12 16:12:23 --> Helper loaded: string_helper
DEBUG - 2016-11-12 16:12:23 --> Session routines successfully run
DEBUG - 2016-11-12 16:12:23 --> Native_session Class Initialized
DEBUG - 2016-11-12 16:12:23 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-12 16:12:23 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:12:23 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:12:23 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-12 16:12:23 --> Controller Class Initialized
DEBUG - 2016-11-12 16:12:23 --> Carabiner: Library initialized.
DEBUG - 2016-11-12 16:12:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-12 16:12:23 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-12 16:12:23 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:12:23 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:12:23 --> User Agent Class Initialized
DEBUG - 2016-11-12 16:12:23 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:23 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:23 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-11-12 16:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-12 16:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-12 16:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-12 16:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-12 16:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-12 16:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-12 16:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-12 16:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-12 16:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-12 16:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-12 16:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-12 16:12:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-12 16:12:23 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-11-12 16:12:23 --> Final output sent to browser
DEBUG - 2016-11-12 16:12:23 --> Total execution time: 0.3061
DEBUG - 2016-11-12 16:12:26 --> Config Class Initialized
DEBUG - 2016-11-12 16:12:26 --> Hooks Class Initialized
DEBUG - 2016-11-12 16:12:26 --> Utf8 Class Initialized
DEBUG - 2016-11-12 16:12:26 --> UTF-8 Support Enabled
DEBUG - 2016-11-12 16:12:26 --> URI Class Initialized
DEBUG - 2016-11-12 16:12:26 --> Router Class Initialized
DEBUG - 2016-11-12 16:12:26 --> Output Class Initialized
DEBUG - 2016-11-12 16:12:26 --> Security Class Initialized
DEBUG - 2016-11-12 16:12:26 --> Input Class Initialized
DEBUG - 2016-11-12 16:12:26 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:26 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-12 16:12:26 --> Language Class Initialized
DEBUG - 2016-11-12 16:12:26 --> Loader Class Initialized
DEBUG - 2016-11-12 16:12:26 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-12 16:12:26 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-12 16:12:26 --> Helper loaded: url_helper
DEBUG - 2016-11-12 16:12:26 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-12 16:12:26 --> Helper loaded: file_helper
DEBUG - 2016-11-12 16:12:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:12:26 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-12 16:12:26 --> Helper loaded: conf_helper
DEBUG - 2016-11-12 16:12:26 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:12:26 --> Check Exists common_helper.php: No
DEBUG - 2016-11-12 16:12:26 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-12 16:12:26 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:12:26 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-12 16:12:26 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:12:26 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-12 16:12:26 --> Helper loaded: form_helper
DEBUG - 2016-11-12 16:12:26 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-12 16:12:26 --> Helper loaded: security_helper
DEBUG - 2016-11-12 16:12:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:12:26 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-12 16:12:26 --> Helper loaded: lang_helper
DEBUG - 2016-11-12 16:12:26 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:12:26 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-12 16:12:26 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-12 16:12:26 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-12 16:12:26 --> Helper loaded: atlant_helper
DEBUG - 2016-11-12 16:12:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:12:26 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-12 16:12:26 --> Helper loaded: crypto_helper
DEBUG - 2016-11-12 16:12:26 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:12:26 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-12 16:12:26 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-12 16:12:26 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-12 16:12:26 --> Helper loaded: sidika_helper
DEBUG - 2016-11-12 16:12:26 --> Database Driver Class Initialized
DEBUG - 2016-11-12 16:12:27 --> Session Class Initialized
DEBUG - 2016-11-12 16:12:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-12 16:12:27 --> Helper loaded: string_helper
DEBUG - 2016-11-12 16:12:27 --> Session routines successfully run
DEBUG - 2016-11-12 16:12:27 --> Native_session Class Initialized
DEBUG - 2016-11-12 16:12:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-12 16:12:27 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:12:27 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:12:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-12 16:12:27 --> Controller Class Initialized
DEBUG - 2016-11-12 16:12:27 --> Carabiner: Library initialized.
DEBUG - 2016-11-12 16:12:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-12 16:12:27 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-12 16:12:27 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:12:27 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:12:27 --> User Agent Class Initialized
DEBUG - 2016-11-12 16:12:27 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:27 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:27 --> Model Class Initialized
ERROR - 2016-11-12 16:12:27 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-11-12 16:12:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-11-12 16:12:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-12 16:12:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-12 16:12:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-12 16:12:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-12 16:12:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-12 16:12:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-12 16:12:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-12 16:12:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-12 16:12:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-12 16:12:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-12 16:12:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-12 16:12:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-12 16:12:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-12 16:12:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-12 16:12:27 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-11-12 16:12:27 --> Final output sent to browser
DEBUG - 2016-11-12 16:12:27 --> Total execution time: 0.3124
DEBUG - 2016-11-12 16:12:36 --> Config Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Hooks Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Utf8 Class Initialized
DEBUG - 2016-11-12 16:12:36 --> UTF-8 Support Enabled
DEBUG - 2016-11-12 16:12:36 --> URI Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Router Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Output Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Cache file has expired. File deleted
DEBUG - 2016-11-12 16:12:36 --> Security Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Input Class Initialized
DEBUG - 2016-11-12 16:12:36 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:36 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:36 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:36 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-12 16:12:36 --> Language Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Loader Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-12 16:12:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-12 16:12:36 --> Helper loaded: url_helper
DEBUG - 2016-11-12 16:12:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-12 16:12:36 --> Helper loaded: file_helper
DEBUG - 2016-11-12 16:12:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:12:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-12 16:12:36 --> Helper loaded: conf_helper
DEBUG - 2016-11-12 16:12:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:12:36 --> Check Exists common_helper.php: No
DEBUG - 2016-11-12 16:12:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-12 16:12:36 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:12:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-12 16:12:36 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:12:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-12 16:12:36 --> Helper loaded: form_helper
DEBUG - 2016-11-12 16:12:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-12 16:12:36 --> Helper loaded: security_helper
DEBUG - 2016-11-12 16:12:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:12:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-12 16:12:36 --> Helper loaded: lang_helper
DEBUG - 2016-11-12 16:12:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:12:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-12 16:12:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-12 16:12:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-12 16:12:36 --> Helper loaded: atlant_helper
DEBUG - 2016-11-12 16:12:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:12:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-12 16:12:36 --> Helper loaded: crypto_helper
DEBUG - 2016-11-12 16:12:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:12:36 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-12 16:12:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-12 16:12:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-12 16:12:36 --> Helper loaded: sidika_helper
DEBUG - 2016-11-12 16:12:36 --> Database Driver Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Session Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-12 16:12:36 --> Helper loaded: string_helper
DEBUG - 2016-11-12 16:12:36 --> Session routines successfully run
DEBUG - 2016-11-12 16:12:36 --> Native_session Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-12 16:12:36 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-12 16:12:36 --> Controller Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Carabiner: Library initialized.
DEBUG - 2016-11-12 16:12:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-12 16:12:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-12 16:12:36 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:12:36 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:12:36 --> User Agent Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Model Class Initialized
ERROR - 2016-11-12 16:12:36 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-11-12 16:12:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-11-12 16:12:36 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-12 16:12:36 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-11-12 16:12:36 --> Config Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Hooks Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Utf8 Class Initialized
DEBUG - 2016-11-12 16:12:36 --> UTF-8 Support Enabled
DEBUG - 2016-11-12 16:12:36 --> URI Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Router Class Initialized
DEBUG - 2016-11-12 16:12:36 --> No URI present. Default controller set.
DEBUG - 2016-11-12 16:12:36 --> Output Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Cache file has expired. File deleted
DEBUG - 2016-11-12 16:12:36 --> Security Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Input Class Initialized
DEBUG - 2016-11-12 16:12:36 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:36 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-12 16:12:36 --> Language Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Loader Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-12 16:12:36 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-12 16:12:36 --> Helper loaded: url_helper
DEBUG - 2016-11-12 16:12:36 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-12 16:12:36 --> Helper loaded: file_helper
DEBUG - 2016-11-12 16:12:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:12:36 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-12 16:12:36 --> Helper loaded: conf_helper
DEBUG - 2016-11-12 16:12:36 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:12:36 --> Check Exists common_helper.php: No
DEBUG - 2016-11-12 16:12:36 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-12 16:12:36 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:12:36 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-12 16:12:36 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:12:36 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-12 16:12:36 --> Helper loaded: form_helper
DEBUG - 2016-11-12 16:12:36 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-12 16:12:36 --> Helper loaded: security_helper
DEBUG - 2016-11-12 16:12:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:12:36 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-12 16:12:36 --> Helper loaded: lang_helper
DEBUG - 2016-11-12 16:12:36 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:12:36 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-12 16:12:36 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-12 16:12:36 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-12 16:12:36 --> Helper loaded: atlant_helper
DEBUG - 2016-11-12 16:12:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:12:36 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-12 16:12:36 --> Helper loaded: crypto_helper
DEBUG - 2016-11-12 16:12:36 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:12:36 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-12 16:12:36 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-12 16:12:36 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-12 16:12:36 --> Helper loaded: sidika_helper
DEBUG - 2016-11-12 16:12:36 --> Database Driver Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Session Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-12 16:12:36 --> Helper loaded: string_helper
DEBUG - 2016-11-12 16:12:36 --> Session routines successfully run
DEBUG - 2016-11-12 16:12:36 --> Native_session Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-12 16:12:36 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-12 16:12:36 --> Controller Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Carabiner: Library initialized.
DEBUG - 2016-11-12 16:12:36 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-12 16:12:36 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-12 16:12:36 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:12:36 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:12:36 --> User Agent Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:36 --> Model Class Initialized
ERROR - 2016-11-12 16:12:36 --> Hak Akses modul/kontroller 'home' untuk role 'administrator' belum di set.
DEBUG - 2016-11-12 16:12:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-11-12 16:12:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-11-12 16:12:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-12 16:12:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-12 16:12:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-12 16:12:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-12 16:12:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-12 16:12:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-11-12 16:12:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-11-12 16:12:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-12 16:12:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-12 16:12:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-12 16:12:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-12 16:12:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-12 16:12:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-12 16:12:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-12 16:12:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-11-12 16:12:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-11-12 16:12:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-12 16:12:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-12 16:12:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-11-12 16:12:37 --> Final output sent to browser
DEBUG - 2016-11-12 16:12:37 --> Total execution time: 0.3580
DEBUG - 2016-11-12 16:12:37 --> Config Class Initialized
DEBUG - 2016-11-12 16:12:37 --> Hooks Class Initialized
DEBUG - 2016-11-12 16:12:37 --> Utf8 Class Initialized
DEBUG - 2016-11-12 16:12:37 --> UTF-8 Support Enabled
DEBUG - 2016-11-12 16:12:37 --> URI Class Initialized
DEBUG - 2016-11-12 16:12:37 --> Router Class Initialized
DEBUG - 2016-11-12 16:12:37 --> Output Class Initialized
DEBUG - 2016-11-12 16:12:37 --> Cache file has expired. File deleted
DEBUG - 2016-11-12 16:12:37 --> Security Class Initialized
DEBUG - 2016-11-12 16:12:37 --> Input Class Initialized
DEBUG - 2016-11-12 16:12:37 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:37 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:37 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:37 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:37 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:37 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:37 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-12 16:12:37 --> Language Class Initialized
DEBUG - 2016-11-12 16:12:37 --> Loader Class Initialized
DEBUG - 2016-11-12 16:12:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-12 16:12:37 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-12 16:12:37 --> Helper loaded: url_helper
DEBUG - 2016-11-12 16:12:37 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-12 16:12:37 --> Helper loaded: file_helper
DEBUG - 2016-11-12 16:12:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:12:37 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-12 16:12:37 --> Helper loaded: conf_helper
DEBUG - 2016-11-12 16:12:37 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:12:37 --> Check Exists common_helper.php: No
DEBUG - 2016-11-12 16:12:37 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-12 16:12:37 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:12:37 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-12 16:12:37 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:12:37 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-12 16:12:37 --> Helper loaded: form_helper
DEBUG - 2016-11-12 16:12:37 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-12 16:12:37 --> Helper loaded: security_helper
DEBUG - 2016-11-12 16:12:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:12:37 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-12 16:12:37 --> Helper loaded: lang_helper
DEBUG - 2016-11-12 16:12:37 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:12:37 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-12 16:12:37 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-12 16:12:37 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-12 16:12:37 --> Helper loaded: atlant_helper
DEBUG - 2016-11-12 16:12:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:12:37 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-12 16:12:37 --> Helper loaded: crypto_helper
DEBUG - 2016-11-12 16:12:37 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:12:37 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-12 16:12:37 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-12 16:12:37 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-12 16:12:37 --> Helper loaded: sidika_helper
DEBUG - 2016-11-12 16:12:37 --> Database Driver Class Initialized
DEBUG - 2016-11-12 16:12:37 --> Session Class Initialized
DEBUG - 2016-11-12 16:12:37 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-12 16:12:37 --> Helper loaded: string_helper
DEBUG - 2016-11-12 16:12:37 --> Session routines successfully run
DEBUG - 2016-11-12 16:12:37 --> Native_session Class Initialized
DEBUG - 2016-11-12 16:12:37 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-12 16:12:37 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:12:37 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:12:37 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-12 16:12:37 --> Controller Class Initialized
DEBUG - 2016-11-12 16:12:37 --> Carabiner: Library initialized.
DEBUG - 2016-11-12 16:12:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-12 16:12:37 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-12 16:12:37 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:12:37 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:12:37 --> User Agent Class Initialized
DEBUG - 2016-11-12 16:12:37 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:37 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:37 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:37 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:37 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:37 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:37 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-11-12 16:12:37 --> Final output sent to browser
DEBUG - 2016-11-12 16:12:37 --> Total execution time: 0.4475
DEBUG - 2016-11-12 16:12:46 --> Config Class Initialized
DEBUG - 2016-11-12 16:12:46 --> Hooks Class Initialized
DEBUG - 2016-11-12 16:12:46 --> Utf8 Class Initialized
DEBUG - 2016-11-12 16:12:46 --> UTF-8 Support Enabled
DEBUG - 2016-11-12 16:12:46 --> URI Class Initialized
DEBUG - 2016-11-12 16:12:46 --> Router Class Initialized
DEBUG - 2016-11-12 16:12:46 --> Output Class Initialized
DEBUG - 2016-11-12 16:12:46 --> Cache file has expired. File deleted
DEBUG - 2016-11-12 16:12:46 --> Security Class Initialized
DEBUG - 2016-11-12 16:12:46 --> Input Class Initialized
DEBUG - 2016-11-12 16:12:46 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:46 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-12 16:12:46 --> Language Class Initialized
DEBUG - 2016-11-12 16:12:46 --> Loader Class Initialized
DEBUG - 2016-11-12 16:12:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-12 16:12:46 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-12 16:12:46 --> Helper loaded: url_helper
DEBUG - 2016-11-12 16:12:46 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-12 16:12:46 --> Helper loaded: file_helper
DEBUG - 2016-11-12 16:12:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:12:46 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-12 16:12:46 --> Helper loaded: conf_helper
DEBUG - 2016-11-12 16:12:46 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:12:46 --> Check Exists common_helper.php: No
DEBUG - 2016-11-12 16:12:46 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-12 16:12:46 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:12:46 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-12 16:12:46 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:12:46 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-12 16:12:46 --> Helper loaded: form_helper
DEBUG - 2016-11-12 16:12:46 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-12 16:12:46 --> Helper loaded: security_helper
DEBUG - 2016-11-12 16:12:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:12:46 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-12 16:12:46 --> Helper loaded: lang_helper
DEBUG - 2016-11-12 16:12:46 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:12:46 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-12 16:12:46 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-12 16:12:46 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-12 16:12:46 --> Helper loaded: atlant_helper
DEBUG - 2016-11-12 16:12:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:12:46 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-12 16:12:46 --> Helper loaded: crypto_helper
DEBUG - 2016-11-12 16:12:46 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:12:46 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-12 16:12:46 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-12 16:12:46 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-12 16:12:46 --> Helper loaded: sidika_helper
DEBUG - 2016-11-12 16:12:46 --> Database Driver Class Initialized
DEBUG - 2016-11-12 16:12:46 --> Session Class Initialized
DEBUG - 2016-11-12 16:12:46 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-12 16:12:46 --> Helper loaded: string_helper
DEBUG - 2016-11-12 16:12:46 --> Session routines successfully run
DEBUG - 2016-11-12 16:12:46 --> Native_session Class Initialized
DEBUG - 2016-11-12 16:12:46 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-12 16:12:46 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:12:46 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:12:46 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-12 16:12:46 --> Controller Class Initialized
DEBUG - 2016-11-12 16:12:46 --> Carabiner: Library initialized.
DEBUG - 2016-11-12 16:12:46 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-12 16:12:46 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-12 16:12:46 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:12:46 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:12:46 --> User Agent Class Initialized
DEBUG - 2016-11-12 16:12:46 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:46 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:46 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:46 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:46 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:46 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:46 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:46 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:46 --> Model Class Initialized
ERROR - 2016-11-12 16:12:46 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'administrator' belum di set.
DEBUG - 2016-11-12 16:12:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-11-12 16:12:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-12 16:12:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-12 16:12:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-12 16:12:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-12 16:12:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-12 16:12:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-12 16:12:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-12 16:12:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-12 16:12:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-12 16:12:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-12 16:12:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-12 16:12:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-12 16:12:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-12 16:12:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-12 16:12:46 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/26764e7c38cfdb071ebc36690ecd8747
DEBUG - 2016-11-12 16:12:46 --> Final output sent to browser
DEBUG - 2016-11-12 16:12:46 --> Total execution time: 0.5962
DEBUG - 2016-11-12 16:12:49 --> Config Class Initialized
DEBUG - 2016-11-12 16:12:49 --> Hooks Class Initialized
DEBUG - 2016-11-12 16:12:49 --> Utf8 Class Initialized
DEBUG - 2016-11-12 16:12:49 --> UTF-8 Support Enabled
DEBUG - 2016-11-12 16:12:49 --> URI Class Initialized
DEBUG - 2016-11-12 16:12:49 --> Router Class Initialized
DEBUG - 2016-11-12 16:12:49 --> Output Class Initialized
DEBUG - 2016-11-12 16:12:49 --> Cache file has expired. File deleted
DEBUG - 2016-11-12 16:12:49 --> Security Class Initialized
DEBUG - 2016-11-12 16:12:49 --> Input Class Initialized
DEBUG - 2016-11-12 16:12:49 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:49 --> XSS Filtering completed
DEBUG - 2016-11-12 16:12:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-12 16:12:49 --> Language Class Initialized
DEBUG - 2016-11-12 16:12:49 --> Loader Class Initialized
DEBUG - 2016-11-12 16:12:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-12 16:12:49 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-12 16:12:49 --> Helper loaded: url_helper
DEBUG - 2016-11-12 16:12:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-12 16:12:49 --> Helper loaded: file_helper
DEBUG - 2016-11-12 16:12:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:12:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-12 16:12:49 --> Helper loaded: conf_helper
DEBUG - 2016-11-12 16:12:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:12:49 --> Check Exists common_helper.php: No
DEBUG - 2016-11-12 16:12:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-12 16:12:49 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:12:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-12 16:12:49 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:12:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-12 16:12:49 --> Helper loaded: form_helper
DEBUG - 2016-11-12 16:12:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-12 16:12:49 --> Helper loaded: security_helper
DEBUG - 2016-11-12 16:12:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:12:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-12 16:12:49 --> Helper loaded: lang_helper
DEBUG - 2016-11-12 16:12:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:12:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-12 16:12:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-12 16:12:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-12 16:12:49 --> Helper loaded: atlant_helper
DEBUG - 2016-11-12 16:12:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:12:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-12 16:12:49 --> Helper loaded: crypto_helper
DEBUG - 2016-11-12 16:12:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:12:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-12 16:12:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-12 16:12:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-12 16:12:49 --> Helper loaded: sidika_helper
DEBUG - 2016-11-12 16:12:49 --> Database Driver Class Initialized
DEBUG - 2016-11-12 16:12:49 --> Session Class Initialized
DEBUG - 2016-11-12 16:12:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-12 16:12:49 --> Helper loaded: string_helper
DEBUG - 2016-11-12 16:12:49 --> Session routines successfully run
DEBUG - 2016-11-12 16:12:49 --> Native_session Class Initialized
DEBUG - 2016-11-12 16:12:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-12 16:12:49 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:12:49 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:12:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-12 16:12:49 --> Controller Class Initialized
DEBUG - 2016-11-12 16:12:49 --> Carabiner: Library initialized.
DEBUG - 2016-11-12 16:12:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-12 16:12:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-12 16:12:49 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:12:49 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:12:49 --> User Agent Class Initialized
DEBUG - 2016-11-12 16:12:49 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:49 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:49 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:49 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:49 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:49 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:49 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:49 --> Model Class Initialized
DEBUG - 2016-11-12 16:12:49 --> Model Class Initialized
ERROR - 2016-11-12 16:12:49 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'administrator' belum di set.
DEBUG - 2016-11-12 16:12:49 --> Model Class Initialized
ERROR - 2016-11-12 16:12:49 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 58
ERROR - 2016-11-12 16:12:49 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 61
ERROR - 2016-11-12 16:12:49 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 64
ERROR - 2016-11-12 16:12:49 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 64
DEBUG - 2016-11-12 16:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/daftar.php
DEBUG - 2016-11-12 16:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-12 16:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-12 16:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-12 16:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-12 16:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-12 16:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/js/daftar_mandiri_js.php
DEBUG - 2016-11-12 16:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/js/daftar_js.php
DEBUG - 2016-11-12 16:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-12 16:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-12 16:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-11-12 16:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-12 16:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-11-12 16:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-11-12 16:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-11-12 16:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/js/daftar_mandiri_js.php
DEBUG - 2016-11-12 16:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/js/daftar_js.php
DEBUG - 2016-11-12 16:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-12 16:12:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-11-12 16:12:49 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/bca08a22cb2ac4b6f004534879c0278e
DEBUG - 2016-11-12 16:12:49 --> Final output sent to browser
DEBUG - 2016-11-12 16:12:49 --> Total execution time: 0.5292
DEBUG - 2016-11-12 16:13:08 --> Config Class Initialized
DEBUG - 2016-11-12 16:13:08 --> Hooks Class Initialized
DEBUG - 2016-11-12 16:13:08 --> Utf8 Class Initialized
DEBUG - 2016-11-12 16:13:08 --> UTF-8 Support Enabled
DEBUG - 2016-11-12 16:13:08 --> URI Class Initialized
DEBUG - 2016-11-12 16:13:08 --> Router Class Initialized
DEBUG - 2016-11-12 16:13:08 --> Output Class Initialized
DEBUG - 2016-11-12 16:13:08 --> Cache file has expired. File deleted
DEBUG - 2016-11-12 16:13:08 --> Security Class Initialized
DEBUG - 2016-11-12 16:13:08 --> Input Class Initialized
DEBUG - 2016-11-12 16:13:08 --> XSS Filtering completed
DEBUG - 2016-11-12 16:13:08 --> XSS Filtering completed
DEBUG - 2016-11-12 16:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-12 16:13:08 --> Language Class Initialized
DEBUG - 2016-11-12 16:13:08 --> Loader Class Initialized
DEBUG - 2016-11-12 16:13:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-12 16:13:08 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-12 16:13:08 --> Helper loaded: url_helper
DEBUG - 2016-11-12 16:13:08 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-12 16:13:08 --> Helper loaded: file_helper
DEBUG - 2016-11-12 16:13:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:13:08 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-12 16:13:08 --> Helper loaded: conf_helper
DEBUG - 2016-11-12 16:13:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:13:08 --> Check Exists common_helper.php: No
DEBUG - 2016-11-12 16:13:08 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-12 16:13:08 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:13:08 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-12 16:13:08 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:13:08 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-12 16:13:08 --> Helper loaded: form_helper
DEBUG - 2016-11-12 16:13:08 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-12 16:13:08 --> Helper loaded: security_helper
DEBUG - 2016-11-12 16:13:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:13:08 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-12 16:13:08 --> Helper loaded: lang_helper
DEBUG - 2016-11-12 16:13:08 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:13:08 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-12 16:13:08 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-12 16:13:08 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-12 16:13:08 --> Helper loaded: atlant_helper
DEBUG - 2016-11-12 16:13:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:13:08 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-12 16:13:08 --> Helper loaded: crypto_helper
DEBUG - 2016-11-12 16:13:08 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:13:08 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-12 16:13:08 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-12 16:13:08 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-12 16:13:08 --> Helper loaded: sidika_helper
DEBUG - 2016-11-12 16:13:08 --> Database Driver Class Initialized
DEBUG - 2016-11-12 16:13:08 --> Session Class Initialized
DEBUG - 2016-11-12 16:13:08 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-12 16:13:08 --> Helper loaded: string_helper
DEBUG - 2016-11-12 16:13:08 --> Session routines successfully run
DEBUG - 2016-11-12 16:13:08 --> Native_session Class Initialized
DEBUG - 2016-11-12 16:13:08 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-12 16:13:08 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:13:08 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:13:08 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-12 16:13:08 --> Controller Class Initialized
DEBUG - 2016-11-12 16:13:08 --> Carabiner: Library initialized.
DEBUG - 2016-11-12 16:13:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-12 16:13:08 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-12 16:13:08 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:13:08 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:13:08 --> User Agent Class Initialized
DEBUG - 2016-11-12 16:13:09 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:09 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:09 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:09 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:09 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:09 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:09 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:09 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:09 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:09 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:09 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-11-12 16:13:09 --> Pagination Class Initialized
DEBUG - 2016-11-12 16:13:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-12 16:13:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-11-12 16:13:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-12 16:13:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-12 16:13:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-12 16:13:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-12 16:13:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-11-12 16:13:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-12 16:13:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-12 16:13:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-12 16:13:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-12 16:13:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-12 16:13:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-12 16:13:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-11-12 16:13:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-12 16:13:09 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-12 16:13:09 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-11-12 16:13:09 --> Final output sent to browser
DEBUG - 2016-11-12 16:13:09 --> Total execution time: 0.5761
DEBUG - 2016-11-12 16:13:19 --> Config Class Initialized
DEBUG - 2016-11-12 16:13:19 --> Hooks Class Initialized
DEBUG - 2016-11-12 16:13:19 --> Utf8 Class Initialized
DEBUG - 2016-11-12 16:13:19 --> UTF-8 Support Enabled
DEBUG - 2016-11-12 16:13:19 --> URI Class Initialized
DEBUG - 2016-11-12 16:13:19 --> Router Class Initialized
DEBUG - 2016-11-12 16:13:20 --> Output Class Initialized
DEBUG - 2016-11-12 16:13:20 --> Security Class Initialized
DEBUG - 2016-11-12 16:13:20 --> Input Class Initialized
DEBUG - 2016-11-12 16:13:20 --> XSS Filtering completed
DEBUG - 2016-11-12 16:13:20 --> XSS Filtering completed
DEBUG - 2016-11-12 16:13:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-12 16:13:20 --> Language Class Initialized
DEBUG - 2016-11-12 16:13:20 --> Loader Class Initialized
DEBUG - 2016-11-12 16:13:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-12 16:13:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-12 16:13:20 --> Helper loaded: url_helper
DEBUG - 2016-11-12 16:13:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-12 16:13:20 --> Helper loaded: file_helper
DEBUG - 2016-11-12 16:13:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:13:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-12 16:13:20 --> Helper loaded: conf_helper
DEBUG - 2016-11-12 16:13:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:13:20 --> Check Exists common_helper.php: No
DEBUG - 2016-11-12 16:13:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-12 16:13:20 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:13:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-12 16:13:20 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:13:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-12 16:13:20 --> Helper loaded: form_helper
DEBUG - 2016-11-12 16:13:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-12 16:13:20 --> Helper loaded: security_helper
DEBUG - 2016-11-12 16:13:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:13:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-12 16:13:20 --> Helper loaded: lang_helper
DEBUG - 2016-11-12 16:13:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:13:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-12 16:13:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-12 16:13:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-12 16:13:20 --> Helper loaded: atlant_helper
DEBUG - 2016-11-12 16:13:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:13:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-12 16:13:20 --> Helper loaded: crypto_helper
DEBUG - 2016-11-12 16:13:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:13:20 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-12 16:13:20 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-12 16:13:20 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-12 16:13:20 --> Helper loaded: sidika_helper
DEBUG - 2016-11-12 16:13:20 --> Database Driver Class Initialized
DEBUG - 2016-11-12 16:13:20 --> Session Class Initialized
DEBUG - 2016-11-12 16:13:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-12 16:13:20 --> Helper loaded: string_helper
DEBUG - 2016-11-12 16:13:20 --> Session routines successfully run
DEBUG - 2016-11-12 16:13:20 --> Native_session Class Initialized
DEBUG - 2016-11-12 16:13:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-12 16:13:20 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:13:20 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:13:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-12 16:13:20 --> Controller Class Initialized
DEBUG - 2016-11-12 16:13:20 --> Carabiner: Library initialized.
DEBUG - 2016-11-12 16:13:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-12 16:13:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-12 16:13:20 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:13:20 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:13:20 --> User Agent Class Initialized
DEBUG - 2016-11-12 16:13:20 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:20 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:20 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:20 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:20 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:20 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:20 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:20 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:20 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:20 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:20 --> Model Class Initialized
ERROR - 2016-11-12 16:13:21 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:177) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-11-12 16:13:53 --> Config Class Initialized
DEBUG - 2016-11-12 16:13:53 --> Hooks Class Initialized
DEBUG - 2016-11-12 16:13:53 --> Utf8 Class Initialized
DEBUG - 2016-11-12 16:13:53 --> UTF-8 Support Enabled
DEBUG - 2016-11-12 16:13:53 --> URI Class Initialized
DEBUG - 2016-11-12 16:13:53 --> Router Class Initialized
DEBUG - 2016-11-12 16:13:53 --> Output Class Initialized
DEBUG - 2016-11-12 16:13:53 --> Cache file has expired. File deleted
DEBUG - 2016-11-12 16:13:53 --> Security Class Initialized
DEBUG - 2016-11-12 16:13:53 --> Input Class Initialized
DEBUG - 2016-11-12 16:13:53 --> XSS Filtering completed
DEBUG - 2016-11-12 16:13:53 --> XSS Filtering completed
DEBUG - 2016-11-12 16:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-11-12 16:13:53 --> Language Class Initialized
DEBUG - 2016-11-12 16:13:53 --> Loader Class Initialized
DEBUG - 2016-11-12 16:13:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-11-12 16:13:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-11-12 16:13:53 --> Helper loaded: url_helper
DEBUG - 2016-11-12 16:13:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-11-12 16:13:53 --> Helper loaded: file_helper
DEBUG - 2016-11-12 16:13:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:13:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-11-12 16:13:53 --> Helper loaded: conf_helper
DEBUG - 2016-11-12 16:13:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-11-12 16:13:53 --> Check Exists common_helper.php: No
DEBUG - 2016-11-12 16:13:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-11-12 16:13:53 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:13:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-11-12 16:13:53 --> Helper loaded: common_helper
DEBUG - 2016-11-12 16:13:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-11-12 16:13:53 --> Helper loaded: form_helper
DEBUG - 2016-11-12 16:13:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-11-12 16:13:53 --> Helper loaded: security_helper
DEBUG - 2016-11-12 16:13:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:13:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-11-12 16:13:53 --> Helper loaded: lang_helper
DEBUG - 2016-11-12 16:13:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-11-12 16:13:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-11-12 16:13:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-11-12 16:13:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-11-12 16:13:53 --> Helper loaded: atlant_helper
DEBUG - 2016-11-12 16:13:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:13:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-11-12 16:13:53 --> Helper loaded: crypto_helper
DEBUG - 2016-11-12 16:13:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-11-12 16:13:53 --> Check Exists sidika_helper.php: No
DEBUG - 2016-11-12 16:13:53 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-11-12 16:13:53 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-11-12 16:13:53 --> Helper loaded: sidika_helper
DEBUG - 2016-11-12 16:13:53 --> Database Driver Class Initialized
DEBUG - 2016-11-12 16:13:53 --> Session Class Initialized
DEBUG - 2016-11-12 16:13:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-11-12 16:13:53 --> Helper loaded: string_helper
DEBUG - 2016-11-12 16:13:53 --> Session routines successfully run
DEBUG - 2016-11-12 16:13:53 --> Native_session Class Initialized
DEBUG - 2016-11-12 16:13:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-11-12 16:13:53 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:13:53 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:13:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-12 16:13:53 --> Controller Class Initialized
DEBUG - 2016-11-12 16:13:53 --> Carabiner: Library initialized.
DEBUG - 2016-11-12 16:13:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-11-12 16:13:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-11-12 16:13:53 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:13:53 --> Carabiner: library configured.
DEBUG - 2016-11-12 16:13:53 --> User Agent Class Initialized
DEBUG - 2016-11-12 16:13:53 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:53 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:53 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:53 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:53 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:53 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:53 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:53 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:53 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:53 --> Model Class Initialized
DEBUG - 2016-11-12 16:13:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-11-12 16:13:53 --> Form Validation Class Initialized
DEBUG - 2016-11-12 16:13:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-11-12 16:13:53 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-11-12 16:13:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-11-12 16:13:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-11-12 16:13:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-11-12 16:13:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-11-12 16:13:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-11-12 16:13:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-11-12 16:13:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8f8e2926e3f1cbfc3aa536b43cdd0626
DEBUG - 2016-11-12 16:13:54 --> Final output sent to browser
DEBUG - 2016-11-12 16:13:54 --> Total execution time: 0.6275
