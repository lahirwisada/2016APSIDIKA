<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-08-09 18:30:13 --> Config Class Initialized
DEBUG - 2016-08-09 18:30:13 --> Hooks Class Initialized
DEBUG - 2016-08-09 18:30:13 --> Utf8 Class Initialized
DEBUG - 2016-08-09 18:30:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-09 18:30:13 --> URI Class Initialized
DEBUG - 2016-08-09 18:30:13 --> Router Class Initialized
DEBUG - 2016-08-09 18:30:13 --> Output Class Initialized
DEBUG - 2016-08-09 18:30:13 --> Cache file has expired. File deleted
DEBUG - 2016-08-09 18:30:13 --> Security Class Initialized
DEBUG - 2016-08-09 18:30:13 --> Input Class Initialized
DEBUG - 2016-08-09 18:30:13 --> XSS Filtering completed
DEBUG - 2016-08-09 18:30:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-09 18:30:13 --> Language Class Initialized
DEBUG - 2016-08-09 18:30:13 --> Loader Class Initialized
DEBUG - 2016-08-09 18:30:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-09 18:30:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-09 18:30:13 --> Helper loaded: url_helper
DEBUG - 2016-08-09 18:30:13 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-09 18:30:13 --> Helper loaded: file_helper
DEBUG - 2016-08-09 18:30:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-09 18:30:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-09 18:30:13 --> Helper loaded: conf_helper
DEBUG - 2016-08-09 18:30:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-09 18:30:13 --> Check Exists common_helper.php: No
DEBUG - 2016-08-09 18:30:13 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-09 18:30:13 --> Helper loaded: common_helper
DEBUG - 2016-08-09 18:30:13 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-09 18:30:13 --> Helper loaded: common_helper
DEBUG - 2016-08-09 18:30:13 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-09 18:30:13 --> Helper loaded: form_helper
DEBUG - 2016-08-09 18:30:13 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-09 18:30:13 --> Helper loaded: security_helper
DEBUG - 2016-08-09 18:30:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-09 18:30:13 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-09 18:30:13 --> Helper loaded: lang_helper
DEBUG - 2016-08-09 18:30:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-09 18:30:13 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-09 18:30:13 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-09 18:30:13 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-09 18:30:13 --> Helper loaded: atlant_helper
DEBUG - 2016-08-09 18:30:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-09 18:30:13 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-09 18:30:13 --> Helper loaded: crypto_helper
DEBUG - 2016-08-09 18:30:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-09 18:30:14 --> Database Driver Class Initialized
DEBUG - 2016-08-09 18:30:14 --> Session Class Initialized
DEBUG - 2016-08-09 18:30:14 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-09 18:30:14 --> Helper loaded: string_helper
DEBUG - 2016-08-09 18:30:14 --> A session cookie was not found.
DEBUG - 2016-08-09 18:30:14 --> Session routines successfully run
DEBUG - 2016-08-09 18:30:14 --> Native_session Class Initialized
DEBUG - 2016-08-09 18:30:14 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-09 18:30:14 --> Form Validation Class Initialized
DEBUG - 2016-08-09 18:30:14 --> Form Validation Class Initialized
DEBUG - 2016-08-09 18:30:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-09 18:30:14 --> Controller Class Initialized
DEBUG - 2016-08-09 18:30:14 --> Carabiner: Library initialized.
DEBUG - 2016-08-09 18:30:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-09 18:30:14 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-09 18:30:14 --> Carabiner: library configured.
DEBUG - 2016-08-09 18:30:14 --> Carabiner: library configured.
DEBUG - 2016-08-09 18:30:14 --> User Agent Class Initialized
DEBUG - 2016-08-09 18:30:14 --> Model Class Initialized
DEBUG - 2016-08-09 18:30:14 --> Model Class Initialized
DEBUG - 2016-08-09 18:30:14 --> Model Class Initialized
DEBUG - 2016-08-09 18:30:16 --> Model Class Initialized
DEBUG - 2016-08-09 18:30:16 --> Model Class Initialized
DEBUG - 2016-08-09 18:30:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-09 18:30:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-08-09 18:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-09 18:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-09 18:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-09 18:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-09 18:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-08-09 18:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-09 18:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-09 18:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-09 18:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-09 18:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-09 18:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-09 18:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-08-09 18:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-09 18:30:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-09 18:30:19 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-08-09 18:30:19 --> Final output sent to browser
DEBUG - 2016-08-09 18:30:19 --> Total execution time: 5.6606
DEBUG - 2016-08-09 18:30:20 --> Config Class Initialized
DEBUG - 2016-08-09 18:30:20 --> Hooks Class Initialized
DEBUG - 2016-08-09 18:30:20 --> Utf8 Class Initialized
DEBUG - 2016-08-09 18:30:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-09 18:30:20 --> URI Class Initialized
DEBUG - 2016-08-09 18:30:20 --> Router Class Initialized
DEBUG - 2016-08-09 18:30:20 --> Output Class Initialized
DEBUG - 2016-08-09 18:30:20 --> Cache file has expired. File deleted
DEBUG - 2016-08-09 18:30:20 --> Security Class Initialized
DEBUG - 2016-08-09 18:30:20 --> Input Class Initialized
DEBUG - 2016-08-09 18:30:20 --> XSS Filtering completed
DEBUG - 2016-08-09 18:30:20 --> XSS Filtering completed
DEBUG - 2016-08-09 18:30:20 --> XSS Filtering completed
DEBUG - 2016-08-09 18:30:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-09 18:30:20 --> Language Class Initialized
DEBUG - 2016-08-09 18:30:20 --> Loader Class Initialized
DEBUG - 2016-08-09 18:30:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-09 18:30:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-09 18:30:20 --> Helper loaded: url_helper
DEBUG - 2016-08-09 18:30:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-09 18:30:20 --> Helper loaded: file_helper
DEBUG - 2016-08-09 18:30:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-09 18:30:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-09 18:30:20 --> Helper loaded: conf_helper
DEBUG - 2016-08-09 18:30:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-09 18:30:20 --> Check Exists common_helper.php: No
DEBUG - 2016-08-09 18:30:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-09 18:30:20 --> Helper loaded: common_helper
DEBUG - 2016-08-09 18:30:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-09 18:30:20 --> Helper loaded: common_helper
DEBUG - 2016-08-09 18:30:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-09 18:30:20 --> Helper loaded: form_helper
DEBUG - 2016-08-09 18:30:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-09 18:30:20 --> Helper loaded: security_helper
DEBUG - 2016-08-09 18:30:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-09 18:30:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-09 18:30:20 --> Helper loaded: lang_helper
DEBUG - 2016-08-09 18:30:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-09 18:30:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-09 18:30:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-09 18:30:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-09 18:30:20 --> Helper loaded: atlant_helper
DEBUG - 2016-08-09 18:30:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-09 18:30:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-09 18:30:20 --> Helper loaded: crypto_helper
DEBUG - 2016-08-09 18:30:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-09 18:30:20 --> Database Driver Class Initialized
DEBUG - 2016-08-09 18:30:20 --> Session Class Initialized
DEBUG - 2016-08-09 18:30:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-09 18:30:20 --> Helper loaded: string_helper
DEBUG - 2016-08-09 18:30:20 --> Session routines successfully run
DEBUG - 2016-08-09 18:30:20 --> Native_session Class Initialized
DEBUG - 2016-08-09 18:30:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-09 18:30:20 --> Form Validation Class Initialized
DEBUG - 2016-08-09 18:30:20 --> Form Validation Class Initialized
DEBUG - 2016-08-09 18:30:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-09 18:30:20 --> Controller Class Initialized
DEBUG - 2016-08-09 18:30:20 --> Carabiner: Library initialized.
DEBUG - 2016-08-09 18:30:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-09 18:30:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-09 18:30:20 --> Carabiner: library configured.
DEBUG - 2016-08-09 18:30:20 --> Carabiner: library configured.
DEBUG - 2016-08-09 18:30:20 --> User Agent Class Initialized
DEBUG - 2016-08-09 18:30:20 --> Model Class Initialized
DEBUG - 2016-08-09 18:30:20 --> Model Class Initialized
DEBUG - 2016-08-09 18:30:20 --> Model Class Initialized
DEBUG - 2016-08-09 18:30:20 --> Model Class Initialized
DEBUG - 2016-08-09 18:30:20 --> Model Class Initialized
DEBUG - 2016-08-09 18:30:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-09 18:30:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-08-09 18:30:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-09 18:30:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-09 18:30:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-09 18:30:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-09 18:30:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-08-09 18:30:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-09 18:30:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-09 18:30:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-09 18:30:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-09 18:30:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-09 18:30:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-09 18:30:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-08-09 18:30:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-09 18:30:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-09 18:30:20 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-08-09 18:30:20 --> Final output sent to browser
DEBUG - 2016-08-09 18:30:20 --> Total execution time: 0.1768
DEBUG - 2016-08-09 18:30:25 --> Config Class Initialized
DEBUG - 2016-08-09 18:30:25 --> Hooks Class Initialized
DEBUG - 2016-08-09 18:30:25 --> Utf8 Class Initialized
DEBUG - 2016-08-09 18:30:25 --> UTF-8 Support Enabled
DEBUG - 2016-08-09 18:30:25 --> URI Class Initialized
DEBUG - 2016-08-09 18:30:25 --> Router Class Initialized
DEBUG - 2016-08-09 18:30:25 --> Output Class Initialized
DEBUG - 2016-08-09 18:30:25 --> Cache file has expired. File deleted
DEBUG - 2016-08-09 18:30:25 --> Security Class Initialized
DEBUG - 2016-08-09 18:30:25 --> Input Class Initialized
DEBUG - 2016-08-09 18:30:25 --> XSS Filtering completed
DEBUG - 2016-08-09 18:30:25 --> XSS Filtering completed
DEBUG - 2016-08-09 18:30:25 --> XSS Filtering completed
DEBUG - 2016-08-09 18:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-09 18:30:25 --> Language Class Initialized
DEBUG - 2016-08-09 18:30:25 --> Loader Class Initialized
DEBUG - 2016-08-09 18:30:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-09 18:30:25 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-09 18:30:25 --> Helper loaded: url_helper
DEBUG - 2016-08-09 18:30:25 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-09 18:30:25 --> Helper loaded: file_helper
DEBUG - 2016-08-09 18:30:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-09 18:30:25 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-09 18:30:25 --> Helper loaded: conf_helper
DEBUG - 2016-08-09 18:30:25 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-09 18:30:25 --> Check Exists common_helper.php: No
DEBUG - 2016-08-09 18:30:25 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-09 18:30:25 --> Helper loaded: common_helper
DEBUG - 2016-08-09 18:30:25 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-09 18:30:25 --> Helper loaded: common_helper
DEBUG - 2016-08-09 18:30:25 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-09 18:30:25 --> Helper loaded: form_helper
DEBUG - 2016-08-09 18:30:25 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-09 18:30:25 --> Helper loaded: security_helper
DEBUG - 2016-08-09 18:30:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-09 18:30:25 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-09 18:30:25 --> Helper loaded: lang_helper
DEBUG - 2016-08-09 18:30:25 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-09 18:30:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-09 18:30:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-09 18:30:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-09 18:30:25 --> Helper loaded: atlant_helper
DEBUG - 2016-08-09 18:30:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-09 18:30:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-09 18:30:25 --> Helper loaded: crypto_helper
DEBUG - 2016-08-09 18:30:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-09 18:30:25 --> Database Driver Class Initialized
DEBUG - 2016-08-09 18:30:25 --> Session Class Initialized
DEBUG - 2016-08-09 18:30:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-09 18:30:25 --> Helper loaded: string_helper
DEBUG - 2016-08-09 18:30:25 --> Session routines successfully run
DEBUG - 2016-08-09 18:30:25 --> Native_session Class Initialized
DEBUG - 2016-08-09 18:30:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-09 18:30:25 --> Form Validation Class Initialized
DEBUG - 2016-08-09 18:30:25 --> Form Validation Class Initialized
DEBUG - 2016-08-09 18:30:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-09 18:30:25 --> Controller Class Initialized
DEBUG - 2016-08-09 18:30:25 --> Carabiner: Library initialized.
DEBUG - 2016-08-09 18:30:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-09 18:30:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-09 18:30:25 --> Carabiner: library configured.
DEBUG - 2016-08-09 18:30:25 --> Carabiner: library configured.
DEBUG - 2016-08-09 18:30:25 --> User Agent Class Initialized
DEBUG - 2016-08-09 18:30:25 --> Model Class Initialized
DEBUG - 2016-08-09 18:30:25 --> Model Class Initialized
DEBUG - 2016-08-09 18:30:25 --> Model Class Initialized
DEBUG - 2016-08-09 18:30:25 --> Model Class Initialized
DEBUG - 2016-08-09 18:30:25 --> Model Class Initialized
ERROR - 2016-08-09 18:30:25 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-08-09 18:30:25 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-08-09 18:30:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-09 18:30:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-08-09 18:30:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-09 18:30:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-09 18:30:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-09 18:30:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-09 18:30:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-08-09 18:30:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-09 18:30:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-09 18:30:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-09 18:30:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-09 18:30:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-09 18:30:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-09 18:30:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/upload_js.php
DEBUG - 2016-08-09 18:30:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-09 18:30:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-09 18:30:25 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-08-09 18:30:25 --> Final output sent to browser
DEBUG - 2016-08-09 18:30:25 --> Total execution time: 0.2726
DEBUG - 2016-08-09 18:30:29 --> Config Class Initialized
DEBUG - 2016-08-09 18:30:29 --> Hooks Class Initialized
DEBUG - 2016-08-09 18:30:29 --> Utf8 Class Initialized
DEBUG - 2016-08-09 18:30:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-09 18:30:29 --> URI Class Initialized
DEBUG - 2016-08-09 18:30:29 --> Router Class Initialized
DEBUG - 2016-08-09 18:30:29 --> Output Class Initialized
DEBUG - 2016-08-09 18:30:29 --> Cache file has expired. File deleted
DEBUG - 2016-08-09 18:30:29 --> Security Class Initialized
DEBUG - 2016-08-09 18:30:29 --> Input Class Initialized
DEBUG - 2016-08-09 18:30:29 --> XSS Filtering completed
DEBUG - 2016-08-09 18:30:29 --> XSS Filtering completed
DEBUG - 2016-08-09 18:30:29 --> XSS Filtering completed
DEBUG - 2016-08-09 18:30:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-09 18:30:29 --> Language Class Initialized
DEBUG - 2016-08-09 18:30:29 --> Loader Class Initialized
DEBUG - 2016-08-09 18:30:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-09 18:30:29 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-09 18:30:29 --> Helper loaded: url_helper
DEBUG - 2016-08-09 18:30:29 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-09 18:30:29 --> Helper loaded: file_helper
DEBUG - 2016-08-09 18:30:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-09 18:30:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-09 18:30:29 --> Helper loaded: conf_helper
DEBUG - 2016-08-09 18:30:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-09 18:30:29 --> Check Exists common_helper.php: No
DEBUG - 2016-08-09 18:30:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-09 18:30:29 --> Helper loaded: common_helper
DEBUG - 2016-08-09 18:30:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-09 18:30:29 --> Helper loaded: common_helper
DEBUG - 2016-08-09 18:30:29 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-09 18:30:29 --> Helper loaded: form_helper
DEBUG - 2016-08-09 18:30:29 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-09 18:30:29 --> Helper loaded: security_helper
DEBUG - 2016-08-09 18:30:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-09 18:30:29 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-09 18:30:29 --> Helper loaded: lang_helper
DEBUG - 2016-08-09 18:30:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-09 18:30:29 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-09 18:30:29 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-09 18:30:29 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-09 18:30:29 --> Helper loaded: atlant_helper
DEBUG - 2016-08-09 18:30:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-09 18:30:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-09 18:30:29 --> Helper loaded: crypto_helper
DEBUG - 2016-08-09 18:30:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-09 18:30:29 --> Database Driver Class Initialized
DEBUG - 2016-08-09 18:30:29 --> Session Class Initialized
DEBUG - 2016-08-09 18:30:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-09 18:30:29 --> Helper loaded: string_helper
DEBUG - 2016-08-09 18:30:29 --> Session routines successfully run
DEBUG - 2016-08-09 18:30:29 --> Native_session Class Initialized
DEBUG - 2016-08-09 18:30:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-09 18:30:29 --> Form Validation Class Initialized
DEBUG - 2016-08-09 18:30:29 --> Form Validation Class Initialized
DEBUG - 2016-08-09 18:30:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-09 18:30:29 --> Controller Class Initialized
DEBUG - 2016-08-09 18:30:29 --> Carabiner: Library initialized.
DEBUG - 2016-08-09 18:30:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-09 18:30:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-09 18:30:29 --> Carabiner: library configured.
DEBUG - 2016-08-09 18:30:29 --> Carabiner: library configured.
DEBUG - 2016-08-09 18:30:29 --> User Agent Class Initialized
DEBUG - 2016-08-09 18:30:29 --> Model Class Initialized
DEBUG - 2016-08-09 18:30:29 --> Model Class Initialized
DEBUG - 2016-08-09 18:30:29 --> Model Class Initialized
DEBUG - 2016-08-09 18:30:29 --> Model Class Initialized
DEBUG - 2016-08-09 18:30:29 --> Model Class Initialized
DEBUG - 2016-08-09 18:30:29 --> Model Class Initialized
DEBUG - 2016-08-09 18:30:30 --> Model Class Initialized
DEBUG - 2016-08-09 18:30:30 --> Model Class Initialized
DEBUG - 2016-08-09 18:30:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-09 18:30:30 --> Pagination Class Initialized
DEBUG - 2016-08-09 18:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-09 18:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-08-09 18:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-09 18:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-09 18:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-09 18:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-09 18:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-09 18:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-09 18:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-09 18:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-09 18:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-09 18:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-09 18:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-09 18:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-08-09 18:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-09 18:30:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-09 18:30:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-08-09 18:30:30 --> Final output sent to browser
DEBUG - 2016-08-09 18:30:30 --> Total execution time: 1.2273
DEBUG - 2016-08-09 18:30:31 --> Config Class Initialized
DEBUG - 2016-08-09 18:30:31 --> Hooks Class Initialized
DEBUG - 2016-08-09 18:30:31 --> Utf8 Class Initialized
DEBUG - 2016-08-09 18:30:31 --> UTF-8 Support Enabled
DEBUG - 2016-08-09 18:30:31 --> URI Class Initialized
DEBUG - 2016-08-09 18:30:31 --> Router Class Initialized
ERROR - 2016-08-09 18:30:31 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-08-09 18:30:52 --> Config Class Initialized
DEBUG - 2016-08-09 18:30:52 --> Hooks Class Initialized
DEBUG - 2016-08-09 18:30:52 --> Utf8 Class Initialized
DEBUG - 2016-08-09 18:30:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-09 18:30:52 --> URI Class Initialized
DEBUG - 2016-08-09 18:30:52 --> Router Class Initialized
DEBUG - 2016-08-09 18:30:52 --> Output Class Initialized
DEBUG - 2016-08-09 18:30:52 --> Security Class Initialized
DEBUG - 2016-08-09 18:30:52 --> Input Class Initialized
DEBUG - 2016-08-09 18:30:52 --> XSS Filtering completed
DEBUG - 2016-08-09 18:30:52 --> XSS Filtering completed
DEBUG - 2016-08-09 18:30:52 --> XSS Filtering completed
DEBUG - 2016-08-09 18:30:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-09 18:30:52 --> Language Class Initialized
DEBUG - 2016-08-09 18:30:52 --> Loader Class Initialized
DEBUG - 2016-08-09 18:30:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-09 18:30:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-09 18:30:52 --> Helper loaded: url_helper
DEBUG - 2016-08-09 18:30:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-09 18:30:52 --> Helper loaded: file_helper
DEBUG - 2016-08-09 18:30:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-09 18:30:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-09 18:30:52 --> Helper loaded: conf_helper
DEBUG - 2016-08-09 18:30:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-09 18:30:52 --> Check Exists common_helper.php: No
DEBUG - 2016-08-09 18:30:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-09 18:30:52 --> Helper loaded: common_helper
DEBUG - 2016-08-09 18:30:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-09 18:30:52 --> Helper loaded: common_helper
DEBUG - 2016-08-09 18:30:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-09 18:30:52 --> Helper loaded: form_helper
DEBUG - 2016-08-09 18:30:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-09 18:30:52 --> Helper loaded: security_helper
DEBUG - 2016-08-09 18:30:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-09 18:30:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-09 18:30:52 --> Helper loaded: lang_helper
DEBUG - 2016-08-09 18:30:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-09 18:30:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-09 18:30:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-09 18:30:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-09 18:30:52 --> Helper loaded: atlant_helper
DEBUG - 2016-08-09 18:30:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-09 18:30:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-09 18:30:52 --> Helper loaded: crypto_helper
DEBUG - 2016-08-09 18:30:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-09 18:30:52 --> Database Driver Class Initialized
DEBUG - 2016-08-09 18:30:52 --> Session Class Initialized
DEBUG - 2016-08-09 18:30:52 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-09 18:30:52 --> Helper loaded: string_helper
DEBUG - 2016-08-09 18:30:52 --> Session routines successfully run
DEBUG - 2016-08-09 18:30:52 --> Native_session Class Initialized
DEBUG - 2016-08-09 18:30:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-09 18:30:52 --> Form Validation Class Initialized
DEBUG - 2016-08-09 18:30:52 --> Form Validation Class Initialized
DEBUG - 2016-08-09 18:30:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-09 18:30:52 --> Controller Class Initialized
DEBUG - 2016-08-09 18:30:52 --> Carabiner: Library initialized.
DEBUG - 2016-08-09 18:30:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-09 18:30:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-09 18:30:52 --> Carabiner: library configured.
DEBUG - 2016-08-09 18:30:52 --> Carabiner: library configured.
DEBUG - 2016-08-09 18:30:52 --> User Agent Class Initialized
DEBUG - 2016-08-09 18:30:52 --> Model Class Initialized
DEBUG - 2016-08-09 18:30:52 --> Model Class Initialized
DEBUG - 2016-08-09 18:30:52 --> Model Class Initialized
DEBUG - 2016-08-09 18:30:52 --> Model Class Initialized
DEBUG - 2016-08-09 18:30:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-09 18:30:52 --> Pagination Class Initialized
DEBUG - 2016-08-09 18:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-08-09 18:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/index.php
DEBUG - 2016-08-09 18:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-09 18:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-09 18:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-09 18:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-09 18:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-08-09 18:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-09 18:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-09 18:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-09 18:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-09 18:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-09 18:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-09 18:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_skpd/js/index_js.php
DEBUG - 2016-08-09 18:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-09 18:30:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-09 18:30:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/860bebf57fee032e24acce1c64d1c3e7
DEBUG - 2016-08-09 18:30:52 --> Final output sent to browser
DEBUG - 2016-08-09 18:30:52 --> Total execution time: 0.2638
DEBUG - 2016-08-09 18:32:06 --> Config Class Initialized
DEBUG - 2016-08-09 18:32:06 --> Hooks Class Initialized
DEBUG - 2016-08-09 18:32:06 --> Utf8 Class Initialized
DEBUG - 2016-08-09 18:32:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-09 18:32:06 --> URI Class Initialized
DEBUG - 2016-08-09 18:32:06 --> Router Class Initialized
DEBUG - 2016-08-09 18:32:06 --> Output Class Initialized
DEBUG - 2016-08-09 18:32:06 --> Cache file has expired. File deleted
DEBUG - 2016-08-09 18:32:06 --> Security Class Initialized
DEBUG - 2016-08-09 18:32:06 --> Input Class Initialized
DEBUG - 2016-08-09 18:32:06 --> XSS Filtering completed
DEBUG - 2016-08-09 18:32:06 --> XSS Filtering completed
DEBUG - 2016-08-09 18:32:06 --> XSS Filtering completed
DEBUG - 2016-08-09 18:32:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-09 18:32:06 --> Language Class Initialized
DEBUG - 2016-08-09 18:32:06 --> Loader Class Initialized
DEBUG - 2016-08-09 18:32:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-08-09 18:32:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-08-09 18:32:06 --> Helper loaded: url_helper
DEBUG - 2016-08-09 18:32:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-08-09 18:32:06 --> Helper loaded: file_helper
DEBUG - 2016-08-09 18:32:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-09 18:32:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-08-09 18:32:06 --> Helper loaded: conf_helper
DEBUG - 2016-08-09 18:32:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-08-09 18:32:06 --> Check Exists common_helper.php: No
DEBUG - 2016-08-09 18:32:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-08-09 18:32:06 --> Helper loaded: common_helper
DEBUG - 2016-08-09 18:32:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-08-09 18:32:06 --> Helper loaded: common_helper
DEBUG - 2016-08-09 18:32:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-08-09 18:32:06 --> Helper loaded: form_helper
DEBUG - 2016-08-09 18:32:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-08-09 18:32:06 --> Helper loaded: security_helper
DEBUG - 2016-08-09 18:32:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-09 18:32:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-08-09 18:32:06 --> Helper loaded: lang_helper
DEBUG - 2016-08-09 18:32:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-08-09 18:32:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-08-09 18:32:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-08-09 18:32:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-08-09 18:32:06 --> Helper loaded: atlant_helper
DEBUG - 2016-08-09 18:32:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-09 18:32:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-08-09 18:32:06 --> Helper loaded: crypto_helper
DEBUG - 2016-08-09 18:32:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-08-09 18:32:06 --> Database Driver Class Initialized
DEBUG - 2016-08-09 18:32:06 --> Session Class Initialized
DEBUG - 2016-08-09 18:32:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-08-09 18:32:06 --> Helper loaded: string_helper
DEBUG - 2016-08-09 18:32:06 --> Session routines successfully run
DEBUG - 2016-08-09 18:32:06 --> Native_session Class Initialized
DEBUG - 2016-08-09 18:32:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-08-09 18:32:06 --> Form Validation Class Initialized
DEBUG - 2016-08-09 18:32:06 --> Form Validation Class Initialized
DEBUG - 2016-08-09 18:32:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-08-09 18:32:06 --> Controller Class Initialized
DEBUG - 2016-08-09 18:32:06 --> Carabiner: Library initialized.
DEBUG - 2016-08-09 18:32:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-08-09 18:32:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-08-09 18:32:06 --> Carabiner: library configured.
DEBUG - 2016-08-09 18:32:06 --> Carabiner: library configured.
DEBUG - 2016-08-09 18:32:06 --> User Agent Class Initialized
DEBUG - 2016-08-09 18:32:06 --> Model Class Initialized
DEBUG - 2016-08-09 18:32:06 --> Model Class Initialized
DEBUG - 2016-08-09 18:32:06 --> Model Class Initialized
DEBUG - 2016-08-09 18:32:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-08-09 18:32:06 --> Pagination Class Initialized
DEBUG - 2016-08-09 18:32:06 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-08-09 18:32:06 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/index.php
DEBUG - 2016-08-09 18:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-09 18:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-09 18:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-09 18:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-09 18:32:06 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2016-08-09 18:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-09 18:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-09 18:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-08-09 18:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-08-09 18:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-08-09 18:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-08-09 18:32:06 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/modul/atlant/js/index_js.php
DEBUG - 2016-08-09 18:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-08-09 18:32:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-08-09 18:32:06 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8118d087c6d6c5bac3947ef2cf7a3513
DEBUG - 2016-08-09 18:32:06 --> Final output sent to browser
DEBUG - 2016-08-09 18:32:06 --> Total execution time: 0.2709
DEBUG - 2016-08-09 18:32:06 --> Config Class Initialized
DEBUG - 2016-08-09 18:32:06 --> Hooks Class Initialized
DEBUG - 2016-08-09 18:32:06 --> Utf8 Class Initialized
DEBUG - 2016-08-09 18:32:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-09 18:32:06 --> URI Class Initialized
DEBUG - 2016-08-09 18:32:06 --> Router Class Initialized
ERROR - 2016-08-09 18:32:06 --> 404 Page Not Found --> back_bone/favicon.ico
