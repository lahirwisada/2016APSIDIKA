<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-10-10 16:45:23 --> Config Class Initialized
DEBUG - 2016-10-10 16:45:23 --> Hooks Class Initialized
DEBUG - 2016-10-10 16:45:23 --> Utf8 Class Initialized
DEBUG - 2016-10-10 16:45:23 --> UTF-8 Support Enabled
DEBUG - 2016-10-10 16:45:23 --> URI Class Initialized
DEBUG - 2016-10-10 16:45:23 --> Router Class Initialized
DEBUG - 2016-10-10 16:45:23 --> No URI present. Default controller set.
DEBUG - 2016-10-10 16:45:23 --> Output Class Initialized
DEBUG - 2016-10-10 16:45:24 --> Cache file has expired. File deleted
DEBUG - 2016-10-10 16:45:24 --> Security Class Initialized
DEBUG - 2016-10-10 16:45:24 --> Input Class Initialized
DEBUG - 2016-10-10 16:45:24 --> XSS Filtering completed
DEBUG - 2016-10-10 16:45:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-10 16:45:24 --> Language Class Initialized
DEBUG - 2016-10-10 16:45:24 --> Loader Class Initialized
DEBUG - 2016-10-10 16:45:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-10 16:45:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-10 16:45:24 --> Helper loaded: url_helper
DEBUG - 2016-10-10 16:45:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-10 16:45:24 --> Helper loaded: file_helper
DEBUG - 2016-10-10 16:45:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-10 16:45:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-10 16:45:24 --> Helper loaded: conf_helper
DEBUG - 2016-10-10 16:45:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-10 16:45:24 --> Check Exists common_helper.php: No
DEBUG - 2016-10-10 16:45:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-10 16:45:24 --> Helper loaded: common_helper
DEBUG - 2016-10-10 16:45:24 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-10 16:45:24 --> Helper loaded: common_helper
DEBUG - 2016-10-10 16:45:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-10 16:45:24 --> Helper loaded: form_helper
DEBUG - 2016-10-10 16:45:24 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-10 16:45:24 --> Helper loaded: security_helper
DEBUG - 2016-10-10 16:45:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-10 16:45:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-10 16:45:24 --> Helper loaded: lang_helper
DEBUG - 2016-10-10 16:45:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-10 16:45:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-10 16:45:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-10 16:45:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-10 16:45:24 --> Helper loaded: atlant_helper
DEBUG - 2016-10-10 16:45:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-10 16:45:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-10 16:45:24 --> Helper loaded: crypto_helper
DEBUG - 2016-10-10 16:45:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-10 16:45:24 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-10 16:45:24 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-10 16:45:24 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-10 16:45:24 --> Helper loaded: sidika_helper
DEBUG - 2016-10-10 16:45:24 --> Database Driver Class Initialized
DEBUG - 2016-10-10 16:45:24 --> Session Class Initialized
DEBUG - 2016-10-10 16:45:24 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-10 16:45:24 --> Helper loaded: string_helper
DEBUG - 2016-10-10 16:45:24 --> A session cookie was not found.
DEBUG - 2016-10-10 16:45:24 --> Session routines successfully run
DEBUG - 2016-10-10 16:45:24 --> Native_session Class Initialized
DEBUG - 2016-10-10 16:45:24 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-10 16:45:24 --> Form Validation Class Initialized
DEBUG - 2016-10-10 16:45:24 --> Form Validation Class Initialized
DEBUG - 2016-10-10 16:45:24 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-10 16:45:24 --> Controller Class Initialized
DEBUG - 2016-10-10 16:45:24 --> Carabiner: Library initialized.
DEBUG - 2016-10-10 16:45:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-10 16:45:24 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-10 16:45:24 --> Carabiner: library configured.
DEBUG - 2016-10-10 16:45:24 --> Carabiner: library configured.
DEBUG - 2016-10-10 16:45:24 --> User Agent Class Initialized
DEBUG - 2016-10-10 16:45:24 --> Model Class Initialized
DEBUG - 2016-10-10 16:45:24 --> Model Class Initialized
DEBUG - 2016-10-10 16:45:24 --> Model Class Initialized
ERROR - 2016-10-10 16:45:24 --> Hak Akses modul/kontroller 'home' untuk role 'Pegawai Negeri Sipil' belum di set.
DEBUG - 2016-10-10 16:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-10-10 16:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-10-10 16:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-10 16:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-10 16:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-10 16:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-10 16:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-10 16:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-10 16:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-10 16:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-10 16:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-10 16:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-10-10 16:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-10-10 16:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-10-10 16:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-10-10 16:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-10-10 16:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-10-10 16:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-10-10 16:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-10-10 16:45:24 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-10-10 16:45:24 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-10-10 16:45:24 --> Final output sent to browser
DEBUG - 2016-10-10 16:45:24 --> Total execution time: 0.3937
DEBUG - 2016-10-10 16:45:24 --> Config Class Initialized
DEBUG - 2016-10-10 16:45:24 --> Hooks Class Initialized
DEBUG - 2016-10-10 16:45:24 --> Utf8 Class Initialized
DEBUG - 2016-10-10 16:45:24 --> UTF-8 Support Enabled
DEBUG - 2016-10-10 16:45:24 --> URI Class Initialized
DEBUG - 2016-10-10 16:45:24 --> Router Class Initialized
DEBUG - 2016-10-10 16:45:24 --> Output Class Initialized
DEBUG - 2016-10-10 16:45:24 --> Cache file has expired. File deleted
DEBUG - 2016-10-10 16:45:24 --> Security Class Initialized
DEBUG - 2016-10-10 16:45:24 --> Input Class Initialized
DEBUG - 2016-10-10 16:45:24 --> XSS Filtering completed
DEBUG - 2016-10-10 16:45:24 --> XSS Filtering completed
DEBUG - 2016-10-10 16:45:24 --> XSS Filtering completed
DEBUG - 2016-10-10 16:45:24 --> XSS Filtering completed
DEBUG - 2016-10-10 16:45:24 --> XSS Filtering completed
DEBUG - 2016-10-10 16:45:24 --> XSS Filtering completed
DEBUG - 2016-10-10 16:45:24 --> XSS Filtering completed
DEBUG - 2016-10-10 16:45:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-10 16:45:24 --> Language Class Initialized
DEBUG - 2016-10-10 16:45:24 --> Loader Class Initialized
DEBUG - 2016-10-10 16:45:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-10-10 16:45:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-10-10 16:45:24 --> Helper loaded: url_helper
DEBUG - 2016-10-10 16:45:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-10-10 16:45:24 --> Helper loaded: file_helper
DEBUG - 2016-10-10 16:45:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-10 16:45:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-10-10 16:45:24 --> Helper loaded: conf_helper
DEBUG - 2016-10-10 16:45:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-10-10 16:45:24 --> Check Exists common_helper.php: No
DEBUG - 2016-10-10 16:45:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-10-10 16:45:24 --> Helper loaded: common_helper
DEBUG - 2016-10-10 16:45:24 --> Check Exists common_helper.php: Yes
DEBUG - 2016-10-10 16:45:24 --> Helper loaded: common_helper
DEBUG - 2016-10-10 16:45:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-10-10 16:45:24 --> Helper loaded: form_helper
DEBUG - 2016-10-10 16:45:24 --> Check Exists security_helper.php: Yes
DEBUG - 2016-10-10 16:45:24 --> Helper loaded: security_helper
DEBUG - 2016-10-10 16:45:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-10 16:45:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-10-10 16:45:24 --> Helper loaded: lang_helper
DEBUG - 2016-10-10 16:45:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-10-10 16:45:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-10-10 16:45:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-10-10 16:45:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-10-10 16:45:24 --> Helper loaded: atlant_helper
DEBUG - 2016-10-10 16:45:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-10 16:45:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-10-10 16:45:24 --> Helper loaded: crypto_helper
DEBUG - 2016-10-10 16:45:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-10-10 16:45:24 --> Check Exists sidika_helper.php: No
DEBUG - 2016-10-10 16:45:24 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-10-10 16:45:24 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-10-10 16:45:24 --> Helper loaded: sidika_helper
DEBUG - 2016-10-10 16:45:24 --> Database Driver Class Initialized
DEBUG - 2016-10-10 16:45:25 --> Session Class Initialized
DEBUG - 2016-10-10 16:45:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-10-10 16:45:25 --> Helper loaded: string_helper
DEBUG - 2016-10-10 16:45:25 --> Session routines successfully run
DEBUG - 2016-10-10 16:45:25 --> Native_session Class Initialized
DEBUG - 2016-10-10 16:45:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-10-10 16:45:25 --> Form Validation Class Initialized
DEBUG - 2016-10-10 16:45:25 --> Form Validation Class Initialized
DEBUG - 2016-10-10 16:45:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-10-10 16:45:25 --> Controller Class Initialized
DEBUG - 2016-10-10 16:45:25 --> Carabiner: Library initialized.
DEBUG - 2016-10-10 16:45:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-10-10 16:45:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-10-10 16:45:25 --> Carabiner: library configured.
DEBUG - 2016-10-10 16:45:25 --> Carabiner: library configured.
DEBUG - 2016-10-10 16:45:25 --> User Agent Class Initialized
DEBUG - 2016-10-10 16:45:25 --> Model Class Initialized
DEBUG - 2016-10-10 16:45:25 --> Model Class Initialized
DEBUG - 2016-10-10 16:45:25 --> Model Class Initialized
DEBUG - 2016-10-10 16:45:25 --> Model Class Initialized
DEBUG - 2016-10-10 16:45:25 --> Model Class Initialized
DEBUG - 2016-10-10 16:45:25 --> Model Class Initialized
DEBUG - 2016-10-10 16:45:25 --> Model Class Initialized
DEBUG - 2016-10-10 16:45:25 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-10-10 16:45:25 --> Final output sent to browser
DEBUG - 2016-10-10 16:45:25 --> Total execution time: 0.5088
