<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-05-24 12:03:09 --> Config Class Initialized
DEBUG - 2016-05-24 12:03:09 --> Hooks Class Initialized
DEBUG - 2016-05-24 12:03:09 --> Utf8 Class Initialized
DEBUG - 2016-05-24 12:03:09 --> UTF-8 Support Enabled
DEBUG - 2016-05-24 12:03:10 --> URI Class Initialized
DEBUG - 2016-05-24 12:03:10 --> Router Class Initialized
DEBUG - 2016-05-24 12:03:10 --> Output Class Initialized
DEBUG - 2016-05-24 12:03:10 --> Cache file has expired. File deleted
DEBUG - 2016-05-24 12:03:10 --> Security Class Initialized
DEBUG - 2016-05-24 12:03:10 --> Input Class Initialized
DEBUG - 2016-05-24 12:03:10 --> XSS Filtering completed
DEBUG - 2016-05-24 12:03:10 --> XSS Filtering completed
DEBUG - 2016-05-24 12:03:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-24 12:03:10 --> Language Class Initialized
DEBUG - 2016-05-24 12:03:11 --> Loader Class Initialized
DEBUG - 2016-05-24 12:03:11 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-24 12:03:11 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-24 12:03:11 --> Helper loaded: url_helper
DEBUG - 2016-05-24 12:03:11 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-24 12:03:11 --> Helper loaded: file_helper
DEBUG - 2016-05-24 12:03:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 12:03:11 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-24 12:03:11 --> Helper loaded: conf_helper
DEBUG - 2016-05-24 12:03:11 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 12:03:11 --> Check Exists common_helper.php: No
DEBUG - 2016-05-24 12:03:11 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-24 12:03:11 --> Helper loaded: common_helper
DEBUG - 2016-05-24 12:03:11 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-24 12:03:11 --> Helper loaded: common_helper
DEBUG - 2016-05-24 12:03:11 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-24 12:03:12 --> Helper loaded: form_helper
DEBUG - 2016-05-24 12:03:12 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-24 12:03:12 --> Helper loaded: security_helper
DEBUG - 2016-05-24 12:03:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 12:03:12 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-24 12:03:12 --> Helper loaded: lang_helper
DEBUG - 2016-05-24 12:03:12 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 12:03:12 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-24 12:03:12 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-24 12:03:12 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-24 12:03:12 --> Helper loaded: atlant_helper
DEBUG - 2016-05-24 12:03:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 12:03:12 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-24 12:03:12 --> Helper loaded: crypto_helper
DEBUG - 2016-05-24 12:03:12 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 12:03:13 --> Database Driver Class Initialized
DEBUG - 2016-05-24 12:03:13 --> Session Class Initialized
DEBUG - 2016-05-24 12:03:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-24 12:03:13 --> Helper loaded: string_helper
DEBUG - 2016-05-24 12:03:13 --> A session cookie was not found.
DEBUG - 2016-05-24 12:03:13 --> Session routines successfully run
DEBUG - 2016-05-24 12:03:13 --> Native_session Class Initialized
DEBUG - 2016-05-24 12:03:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-24 12:03:14 --> Form Validation Class Initialized
DEBUG - 2016-05-24 12:03:14 --> Form Validation Class Initialized
DEBUG - 2016-05-24 12:03:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-24 12:03:14 --> Controller Class Initialized
DEBUG - 2016-05-24 12:03:14 --> Carabiner: Library initialized.
DEBUG - 2016-05-24 12:03:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-24 12:03:14 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-24 12:03:14 --> Carabiner: library configured.
DEBUG - 2016-05-24 12:03:14 --> Carabiner: library configured.
DEBUG - 2016-05-24 12:03:15 --> User Agent Class Initialized
DEBUG - 2016-05-24 12:03:15 --> Model Class Initialized
DEBUG - 2016-05-24 12:03:15 --> Model Class Initialized
DEBUG - 2016-05-24 12:03:15 --> Model Class Initialized
DEBUG - 2016-05-24 12:03:16 --> Model Class Initialized
DEBUG - 2016-05-24 12:03:16 --> Model Class Initialized
DEBUG - 2016-05-24 12:03:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-24 12:03:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-24 12:03:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-24 12:03:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-24 12:03:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-24 12:03:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-24 12:03:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-24 12:03:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-24 12:03:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-24 12:03:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-24 12:03:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-24 12:03:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-24 12:03:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-24 12:03:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-24 12:03:19 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-05-24 12:03:19 --> Final output sent to browser
DEBUG - 2016-05-24 12:03:19 --> Total execution time: 9.1874
DEBUG - 2016-05-24 12:03:24 --> Config Class Initialized
DEBUG - 2016-05-24 12:03:24 --> Hooks Class Initialized
DEBUG - 2016-05-24 12:03:24 --> Utf8 Class Initialized
DEBUG - 2016-05-24 12:03:24 --> UTF-8 Support Enabled
DEBUG - 2016-05-24 12:03:24 --> URI Class Initialized
DEBUG - 2016-05-24 12:03:24 --> Router Class Initialized
DEBUG - 2016-05-24 12:03:24 --> Output Class Initialized
DEBUG - 2016-05-24 12:03:24 --> Cache file has expired. File deleted
DEBUG - 2016-05-24 12:03:24 --> Security Class Initialized
DEBUG - 2016-05-24 12:03:24 --> Input Class Initialized
DEBUG - 2016-05-24 12:03:24 --> XSS Filtering completed
DEBUG - 2016-05-24 12:03:24 --> XSS Filtering completed
DEBUG - 2016-05-24 12:03:24 --> XSS Filtering completed
DEBUG - 2016-05-24 12:03:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-24 12:03:24 --> Language Class Initialized
DEBUG - 2016-05-24 12:03:24 --> Loader Class Initialized
DEBUG - 2016-05-24 12:03:24 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-24 12:03:24 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-24 12:03:24 --> Helper loaded: url_helper
DEBUG - 2016-05-24 12:03:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-24 12:03:24 --> Helper loaded: file_helper
DEBUG - 2016-05-24 12:03:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 12:03:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-24 12:03:24 --> Helper loaded: conf_helper
DEBUG - 2016-05-24 12:03:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 12:03:24 --> Check Exists common_helper.php: No
DEBUG - 2016-05-24 12:03:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-24 12:03:24 --> Helper loaded: common_helper
DEBUG - 2016-05-24 12:03:24 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-24 12:03:24 --> Helper loaded: common_helper
DEBUG - 2016-05-24 12:03:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-24 12:03:24 --> Helper loaded: form_helper
DEBUG - 2016-05-24 12:03:24 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-24 12:03:24 --> Helper loaded: security_helper
DEBUG - 2016-05-24 12:03:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 12:03:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-24 12:03:24 --> Helper loaded: lang_helper
DEBUG - 2016-05-24 12:03:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 12:03:25 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-24 12:03:25 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-24 12:03:25 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-24 12:03:25 --> Helper loaded: atlant_helper
DEBUG - 2016-05-24 12:03:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 12:03:25 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-24 12:03:25 --> Helper loaded: crypto_helper
DEBUG - 2016-05-24 12:03:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 12:03:25 --> Database Driver Class Initialized
DEBUG - 2016-05-24 12:03:25 --> Session Class Initialized
DEBUG - 2016-05-24 12:03:25 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-24 12:03:25 --> Helper loaded: string_helper
DEBUG - 2016-05-24 12:03:25 --> Session routines successfully run
DEBUG - 2016-05-24 12:03:25 --> Native_session Class Initialized
DEBUG - 2016-05-24 12:03:25 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-24 12:03:25 --> Form Validation Class Initialized
DEBUG - 2016-05-24 12:03:25 --> Form Validation Class Initialized
DEBUG - 2016-05-24 12:03:25 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-24 12:03:25 --> Controller Class Initialized
DEBUG - 2016-05-24 12:03:25 --> Carabiner: Library initialized.
DEBUG - 2016-05-24 12:03:25 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-24 12:03:25 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-24 12:03:25 --> Carabiner: library configured.
DEBUG - 2016-05-24 12:03:25 --> Carabiner: library configured.
DEBUG - 2016-05-24 12:03:25 --> User Agent Class Initialized
DEBUG - 2016-05-24 12:03:25 --> Model Class Initialized
DEBUG - 2016-05-24 12:03:25 --> Model Class Initialized
DEBUG - 2016-05-24 12:03:25 --> Model Class Initialized
DEBUG - 2016-05-24 12:03:25 --> Model Class Initialized
DEBUG - 2016-05-24 12:03:25 --> Model Class Initialized
ERROR - 2016-05-24 12:03:25 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-05-24 12:03:25 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-05-24 12:03:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-24 12:03:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-24 12:03:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-24 12:03:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-24 12:03:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-24 12:03:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-24 12:03:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-24 12:03:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-24 12:03:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-24 12:03:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-24 12:03:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-24 12:03:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-24 12:03:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-24 12:03:25 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-24 12:03:25 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-05-24 12:03:25 --> Final output sent to browser
DEBUG - 2016-05-24 12:03:25 --> Total execution time: 0.4166
DEBUG - 2016-05-24 13:36:32 --> Config Class Initialized
DEBUG - 2016-05-24 13:36:32 --> Hooks Class Initialized
DEBUG - 2016-05-24 13:36:32 --> Utf8 Class Initialized
DEBUG - 2016-05-24 13:36:32 --> UTF-8 Support Enabled
DEBUG - 2016-05-24 13:36:32 --> URI Class Initialized
DEBUG - 2016-05-24 13:36:32 --> Router Class Initialized
DEBUG - 2016-05-24 13:36:32 --> Output Class Initialized
DEBUG - 2016-05-24 13:36:32 --> Cache file has expired. File deleted
DEBUG - 2016-05-24 13:36:32 --> Security Class Initialized
DEBUG - 2016-05-24 13:36:32 --> Input Class Initialized
DEBUG - 2016-05-24 13:36:32 --> XSS Filtering completed
DEBUG - 2016-05-24 13:36:32 --> XSS Filtering completed
DEBUG - 2016-05-24 13:36:32 --> XSS Filtering completed
DEBUG - 2016-05-24 13:36:32 --> XSS Filtering completed
DEBUG - 2016-05-24 13:36:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-24 13:36:32 --> Language Class Initialized
DEBUG - 2016-05-24 13:36:33 --> Loader Class Initialized
DEBUG - 2016-05-24 13:36:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-24 13:36:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-24 13:36:33 --> Helper loaded: url_helper
DEBUG - 2016-05-24 13:36:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-24 13:36:33 --> Helper loaded: file_helper
DEBUG - 2016-05-24 13:36:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 13:36:33 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-24 13:36:33 --> Helper loaded: conf_helper
DEBUG - 2016-05-24 13:36:33 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 13:36:33 --> Check Exists common_helper.php: No
DEBUG - 2016-05-24 13:36:33 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-24 13:36:33 --> Helper loaded: common_helper
DEBUG - 2016-05-24 13:36:33 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-24 13:36:33 --> Helper loaded: common_helper
DEBUG - 2016-05-24 13:36:33 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-24 13:36:33 --> Helper loaded: form_helper
DEBUG - 2016-05-24 13:36:33 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-24 13:36:33 --> Helper loaded: security_helper
DEBUG - 2016-05-24 13:36:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 13:36:33 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-24 13:36:33 --> Helper loaded: lang_helper
DEBUG - 2016-05-24 13:36:33 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 13:36:33 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-24 13:36:33 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-24 13:36:33 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-24 13:36:33 --> Helper loaded: atlant_helper
DEBUG - 2016-05-24 13:36:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 13:36:33 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-24 13:36:33 --> Helper loaded: crypto_helper
DEBUG - 2016-05-24 13:36:33 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 13:36:33 --> Database Driver Class Initialized
DEBUG - 2016-05-24 13:36:33 --> Session Class Initialized
DEBUG - 2016-05-24 13:36:33 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-24 13:36:33 --> Helper loaded: string_helper
DEBUG - 2016-05-24 13:36:33 --> Session routines successfully run
DEBUG - 2016-05-24 13:36:33 --> Native_session Class Initialized
DEBUG - 2016-05-24 13:36:33 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-24 13:36:34 --> Form Validation Class Initialized
DEBUG - 2016-05-24 13:36:34 --> Form Validation Class Initialized
DEBUG - 2016-05-24 13:36:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-24 13:36:34 --> Controller Class Initialized
DEBUG - 2016-05-24 13:36:34 --> Carabiner: Library initialized.
DEBUG - 2016-05-24 13:36:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-24 13:36:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-24 13:36:34 --> Carabiner: library configured.
DEBUG - 2016-05-24 13:36:34 --> Carabiner: library configured.
DEBUG - 2016-05-24 13:36:34 --> User Agent Class Initialized
DEBUG - 2016-05-24 13:36:34 --> Model Class Initialized
DEBUG - 2016-05-24 13:36:34 --> Model Class Initialized
DEBUG - 2016-05-24 13:36:34 --> Model Class Initialized
DEBUG - 2016-05-24 13:36:35 --> Model Class Initialized
DEBUG - 2016-05-24 13:36:35 --> Model Class Initialized
DEBUG - 2016-05-24 13:36:36 --> Upload Class Initialized
DEBUG - 2016-05-24 13:36:36 --> Upload Class Initialized
DEBUG - 2016-05-24 13:36:36 --> Class Library loaded: LWS_Upload on upload
DEBUG - 2016-05-24 15:37:31 --> Config Class Initialized
DEBUG - 2016-05-24 15:37:31 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:37:31 --> Utf8 Class Initialized
DEBUG - 2016-05-24 15:37:31 --> UTF-8 Support Enabled
DEBUG - 2016-05-24 15:37:31 --> URI Class Initialized
DEBUG - 2016-05-24 15:37:31 --> Router Class Initialized
DEBUG - 2016-05-24 15:37:31 --> Output Class Initialized
DEBUG - 2016-05-24 15:37:31 --> Security Class Initialized
DEBUG - 2016-05-24 15:37:31 --> Input Class Initialized
DEBUG - 2016-05-24 15:37:31 --> XSS Filtering completed
DEBUG - 2016-05-24 15:37:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-24 15:37:31 --> Language Class Initialized
DEBUG - 2016-05-24 15:37:31 --> Loader Class Initialized
DEBUG - 2016-05-24 15:37:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-24 15:37:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-24 15:37:32 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:37:32 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-24 15:37:32 --> Helper loaded: file_helper
DEBUG - 2016-05-24 15:37:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 15:37:32 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-24 15:37:32 --> Helper loaded: conf_helper
DEBUG - 2016-05-24 15:37:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 15:37:32 --> Check Exists common_helper.php: No
DEBUG - 2016-05-24 15:37:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-24 15:37:32 --> Helper loaded: common_helper
DEBUG - 2016-05-24 15:37:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-24 15:37:32 --> Helper loaded: common_helper
DEBUG - 2016-05-24 15:37:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-24 15:37:32 --> Helper loaded: form_helper
DEBUG - 2016-05-24 15:37:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-24 15:37:32 --> Helper loaded: security_helper
DEBUG - 2016-05-24 15:37:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 15:37:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-24 15:37:32 --> Helper loaded: lang_helper
DEBUG - 2016-05-24 15:37:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 15:37:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-24 15:37:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-24 15:37:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-24 15:37:32 --> Helper loaded: atlant_helper
DEBUG - 2016-05-24 15:37:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 15:37:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-24 15:37:32 --> Helper loaded: crypto_helper
DEBUG - 2016-05-24 15:37:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 15:37:32 --> Database Driver Class Initialized
DEBUG - 2016-05-24 15:37:32 --> Session Class Initialized
DEBUG - 2016-05-24 15:37:32 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-24 15:37:32 --> Helper loaded: string_helper
DEBUG - 2016-05-24 15:37:32 --> A session cookie was not found.
DEBUG - 2016-05-24 15:37:32 --> Session routines successfully run
DEBUG - 2016-05-24 15:37:32 --> Native_session Class Initialized
DEBUG - 2016-05-24 15:37:32 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-24 15:37:32 --> Form Validation Class Initialized
DEBUG - 2016-05-24 15:37:32 --> Form Validation Class Initialized
DEBUG - 2016-05-24 15:37:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-24 15:37:33 --> Controller Class Initialized
DEBUG - 2016-05-24 15:37:33 --> Carabiner: Library initialized.
DEBUG - 2016-05-24 15:37:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-24 15:37:33 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-24 15:37:33 --> Carabiner: library configured.
DEBUG - 2016-05-24 15:37:33 --> Carabiner: library configured.
DEBUG - 2016-05-24 15:37:33 --> User Agent Class Initialized
DEBUG - 2016-05-24 15:37:33 --> Model Class Initialized
DEBUG - 2016-05-24 15:37:33 --> Model Class Initialized
DEBUG - 2016-05-24 15:37:33 --> Model Class Initialized
DEBUG - 2016-05-24 15:37:34 --> Model Class Initialized
DEBUG - 2016-05-24 15:37:34 --> Model Class Initialized
DEBUG - 2016-05-24 15:37:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-24 15:37:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-24 15:37:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-24 15:37:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-24 15:37:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-24 15:37:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-24 15:37:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-24 15:37:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-24 15:37:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-24 15:37:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-24 15:37:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-24 15:37:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-24 15:37:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-24 15:37:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-24 15:37:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-05-24 15:37:34 --> Final output sent to browser
DEBUG - 2016-05-24 15:37:34 --> Total execution time: 2.9991
DEBUG - 2016-05-24 15:37:37 --> Config Class Initialized
DEBUG - 2016-05-24 15:37:37 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:37:37 --> Utf8 Class Initialized
DEBUG - 2016-05-24 15:37:37 --> UTF-8 Support Enabled
DEBUG - 2016-05-24 15:37:37 --> URI Class Initialized
DEBUG - 2016-05-24 15:37:37 --> Router Class Initialized
DEBUG - 2016-05-24 15:37:37 --> Output Class Initialized
DEBUG - 2016-05-24 15:37:38 --> Cache file has expired. File deleted
DEBUG - 2016-05-24 15:37:38 --> Security Class Initialized
DEBUG - 2016-05-24 15:37:38 --> Input Class Initialized
DEBUG - 2016-05-24 15:37:38 --> XSS Filtering completed
DEBUG - 2016-05-24 15:37:38 --> XSS Filtering completed
DEBUG - 2016-05-24 15:37:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-24 15:37:38 --> Language Class Initialized
DEBUG - 2016-05-24 15:37:38 --> Loader Class Initialized
DEBUG - 2016-05-24 15:37:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-24 15:37:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-24 15:37:38 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:37:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-24 15:37:38 --> Helper loaded: file_helper
DEBUG - 2016-05-24 15:37:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 15:37:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-24 15:37:38 --> Helper loaded: conf_helper
DEBUG - 2016-05-24 15:37:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 15:37:38 --> Check Exists common_helper.php: No
DEBUG - 2016-05-24 15:37:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-24 15:37:38 --> Helper loaded: common_helper
DEBUG - 2016-05-24 15:37:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-24 15:37:38 --> Helper loaded: common_helper
DEBUG - 2016-05-24 15:37:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-24 15:37:38 --> Helper loaded: form_helper
DEBUG - 2016-05-24 15:37:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-24 15:37:38 --> Helper loaded: security_helper
DEBUG - 2016-05-24 15:37:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 15:37:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-24 15:37:38 --> Helper loaded: lang_helper
DEBUG - 2016-05-24 15:37:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 15:37:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-24 15:37:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-24 15:37:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-24 15:37:38 --> Helper loaded: atlant_helper
DEBUG - 2016-05-24 15:37:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 15:37:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-24 15:37:38 --> Helper loaded: crypto_helper
DEBUG - 2016-05-24 15:37:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 15:37:38 --> Database Driver Class Initialized
DEBUG - 2016-05-24 15:37:38 --> Session Class Initialized
DEBUG - 2016-05-24 15:37:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-24 15:37:38 --> Helper loaded: string_helper
DEBUG - 2016-05-24 15:37:38 --> Session routines successfully run
DEBUG - 2016-05-24 15:37:38 --> Native_session Class Initialized
DEBUG - 2016-05-24 15:37:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-24 15:37:38 --> Form Validation Class Initialized
DEBUG - 2016-05-24 15:37:38 --> Form Validation Class Initialized
DEBUG - 2016-05-24 15:37:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-24 15:37:38 --> Controller Class Initialized
DEBUG - 2016-05-24 15:37:38 --> Carabiner: Library initialized.
DEBUG - 2016-05-24 15:37:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-24 15:37:38 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-24 15:37:38 --> Carabiner: library configured.
DEBUG - 2016-05-24 15:37:38 --> Carabiner: library configured.
DEBUG - 2016-05-24 15:37:38 --> User Agent Class Initialized
DEBUG - 2016-05-24 15:37:38 --> Model Class Initialized
DEBUG - 2016-05-24 15:37:38 --> Model Class Initialized
DEBUG - 2016-05-24 15:37:38 --> Model Class Initialized
DEBUG - 2016-05-24 15:37:38 --> Model Class Initialized
DEBUG - 2016-05-24 15:37:38 --> Model Class Initialized
ERROR - 2016-05-24 15:37:38 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-05-24 15:37:38 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-05-24 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-24 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-24 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-24 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-24 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-24 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-24 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-24 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-24 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-24 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-24 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-24 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-24 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-24 15:37:38 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-24 15:37:38 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-05-24 15:37:38 --> Final output sent to browser
DEBUG - 2016-05-24 15:37:38 --> Total execution time: 0.3355
DEBUG - 2016-05-24 15:37:44 --> Config Class Initialized
DEBUG - 2016-05-24 15:37:44 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:37:44 --> Utf8 Class Initialized
DEBUG - 2016-05-24 15:37:44 --> UTF-8 Support Enabled
DEBUG - 2016-05-24 15:37:44 --> URI Class Initialized
DEBUG - 2016-05-24 15:37:44 --> Router Class Initialized
DEBUG - 2016-05-24 15:37:44 --> Output Class Initialized
DEBUG - 2016-05-24 15:37:44 --> Cache file has expired. File deleted
DEBUG - 2016-05-24 15:37:44 --> Security Class Initialized
DEBUG - 2016-05-24 15:37:44 --> Input Class Initialized
DEBUG - 2016-05-24 15:37:44 --> XSS Filtering completed
DEBUG - 2016-05-24 15:37:44 --> XSS Filtering completed
DEBUG - 2016-05-24 15:37:44 --> XSS Filtering completed
DEBUG - 2016-05-24 15:37:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-24 15:37:44 --> Language Class Initialized
DEBUG - 2016-05-24 15:37:44 --> Loader Class Initialized
DEBUG - 2016-05-24 15:37:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-24 15:37:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-24 15:37:44 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:37:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-24 15:37:44 --> Helper loaded: file_helper
DEBUG - 2016-05-24 15:37:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 15:37:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-24 15:37:44 --> Helper loaded: conf_helper
DEBUG - 2016-05-24 15:37:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 15:37:44 --> Check Exists common_helper.php: No
DEBUG - 2016-05-24 15:37:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-24 15:37:44 --> Helper loaded: common_helper
DEBUG - 2016-05-24 15:37:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-24 15:37:44 --> Helper loaded: common_helper
DEBUG - 2016-05-24 15:37:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-24 15:37:44 --> Helper loaded: form_helper
DEBUG - 2016-05-24 15:37:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-24 15:37:44 --> Helper loaded: security_helper
DEBUG - 2016-05-24 15:37:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 15:37:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-24 15:37:44 --> Helper loaded: lang_helper
DEBUG - 2016-05-24 15:37:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 15:37:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-24 15:37:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-24 15:37:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-24 15:37:44 --> Helper loaded: atlant_helper
DEBUG - 2016-05-24 15:37:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 15:37:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-24 15:37:44 --> Helper loaded: crypto_helper
DEBUG - 2016-05-24 15:37:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 15:37:44 --> Database Driver Class Initialized
DEBUG - 2016-05-24 15:37:44 --> Session Class Initialized
DEBUG - 2016-05-24 15:37:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-24 15:37:44 --> Helper loaded: string_helper
DEBUG - 2016-05-24 15:37:44 --> Session routines successfully run
DEBUG - 2016-05-24 15:37:44 --> Native_session Class Initialized
DEBUG - 2016-05-24 15:37:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-24 15:37:44 --> Form Validation Class Initialized
DEBUG - 2016-05-24 15:37:44 --> Form Validation Class Initialized
DEBUG - 2016-05-24 15:37:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-24 15:37:44 --> Controller Class Initialized
DEBUG - 2016-05-24 15:37:44 --> Carabiner: Library initialized.
DEBUG - 2016-05-24 15:37:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-24 15:37:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-24 15:37:44 --> Carabiner: library configured.
DEBUG - 2016-05-24 15:37:44 --> Carabiner: library configured.
DEBUG - 2016-05-24 15:37:44 --> User Agent Class Initialized
DEBUG - 2016-05-24 15:37:44 --> Model Class Initialized
DEBUG - 2016-05-24 15:37:44 --> Model Class Initialized
DEBUG - 2016-05-24 15:37:44 --> Model Class Initialized
DEBUG - 2016-05-24 15:37:44 --> Model Class Initialized
DEBUG - 2016-05-24 15:37:44 --> Model Class Initialized
DEBUG - 2016-05-24 15:37:45 --> Upload Class Initialized
DEBUG - 2016-05-24 15:37:45 --> Upload Class Initialized
DEBUG - 2016-05-24 15:37:45 --> Class Library loaded: LWS_Upload on upload
DEBUG - 2016-05-24 15:37:57 --> Config Class Initialized
DEBUG - 2016-05-24 15:37:57 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:37:57 --> Utf8 Class Initialized
DEBUG - 2016-05-24 15:37:57 --> UTF-8 Support Enabled
DEBUG - 2016-05-24 15:37:57 --> URI Class Initialized
DEBUG - 2016-05-24 15:37:57 --> Router Class Initialized
DEBUG - 2016-05-24 15:37:57 --> Output Class Initialized
DEBUG - 2016-05-24 15:37:57 --> Security Class Initialized
DEBUG - 2016-05-24 15:37:57 --> Input Class Initialized
DEBUG - 2016-05-24 15:37:57 --> XSS Filtering completed
DEBUG - 2016-05-24 15:37:57 --> XSS Filtering completed
DEBUG - 2016-05-24 15:37:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-24 15:37:57 --> Language Class Initialized
DEBUG - 2016-05-24 15:37:57 --> Loader Class Initialized
DEBUG - 2016-05-24 15:37:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-24 15:37:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-24 15:37:57 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:37:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-24 15:37:57 --> Helper loaded: file_helper
DEBUG - 2016-05-24 15:37:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 15:37:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-24 15:37:57 --> Helper loaded: conf_helper
DEBUG - 2016-05-24 15:37:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 15:37:57 --> Check Exists common_helper.php: No
DEBUG - 2016-05-24 15:37:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-24 15:37:57 --> Helper loaded: common_helper
DEBUG - 2016-05-24 15:37:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-24 15:37:57 --> Helper loaded: common_helper
DEBUG - 2016-05-24 15:37:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-24 15:37:57 --> Helper loaded: form_helper
DEBUG - 2016-05-24 15:37:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-24 15:37:57 --> Helper loaded: security_helper
DEBUG - 2016-05-24 15:37:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 15:37:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-24 15:37:57 --> Helper loaded: lang_helper
DEBUG - 2016-05-24 15:37:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 15:37:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-24 15:37:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-24 15:37:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-24 15:37:57 --> Helper loaded: atlant_helper
DEBUG - 2016-05-24 15:37:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 15:37:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-24 15:37:57 --> Helper loaded: crypto_helper
DEBUG - 2016-05-24 15:37:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 15:37:57 --> Database Driver Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Session Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-24 15:37:58 --> Helper loaded: string_helper
DEBUG - 2016-05-24 15:37:58 --> Session routines successfully run
DEBUG - 2016-05-24 15:37:58 --> Native_session Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-24 15:37:58 --> Form Validation Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Form Validation Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-24 15:37:58 --> Controller Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Carabiner: Library initialized.
DEBUG - 2016-05-24 15:37:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-24 15:37:58 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-24 15:37:58 --> Carabiner: library configured.
DEBUG - 2016-05-24 15:37:58 --> Carabiner: library configured.
DEBUG - 2016-05-24 15:37:58 --> User Agent Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Model Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Model Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Model Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Model Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Model Class Initialized
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-24 15:37:58 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-05-24 15:37:58 --> Final output sent to browser
DEBUG - 2016-05-24 15:37:58 --> Total execution time: 0.3198
DEBUG - 2016-05-24 15:37:58 --> Config Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Utf8 Class Initialized
DEBUG - 2016-05-24 15:37:58 --> UTF-8 Support Enabled
DEBUG - 2016-05-24 15:37:58 --> URI Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Router Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Output Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Cache file has expired. File deleted
DEBUG - 2016-05-24 15:37:58 --> Security Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Input Class Initialized
DEBUG - 2016-05-24 15:37:58 --> XSS Filtering completed
DEBUG - 2016-05-24 15:37:58 --> XSS Filtering completed
DEBUG - 2016-05-24 15:37:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-24 15:37:58 --> Language Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Loader Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-24 15:37:58 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-24 15:37:58 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:37:58 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-24 15:37:58 --> Helper loaded: file_helper
DEBUG - 2016-05-24 15:37:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 15:37:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-24 15:37:58 --> Helper loaded: conf_helper
DEBUG - 2016-05-24 15:37:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 15:37:58 --> Check Exists common_helper.php: No
DEBUG - 2016-05-24 15:37:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-24 15:37:58 --> Helper loaded: common_helper
DEBUG - 2016-05-24 15:37:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-24 15:37:58 --> Helper loaded: common_helper
DEBUG - 2016-05-24 15:37:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-24 15:37:58 --> Helper loaded: form_helper
DEBUG - 2016-05-24 15:37:58 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-24 15:37:58 --> Helper loaded: security_helper
DEBUG - 2016-05-24 15:37:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 15:37:58 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-24 15:37:58 --> Helper loaded: lang_helper
DEBUG - 2016-05-24 15:37:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 15:37:58 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-24 15:37:58 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-24 15:37:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-24 15:37:58 --> Helper loaded: atlant_helper
DEBUG - 2016-05-24 15:37:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 15:37:58 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-24 15:37:58 --> Helper loaded: crypto_helper
DEBUG - 2016-05-24 15:37:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 15:37:58 --> Database Driver Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Session Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-24 15:37:58 --> Helper loaded: string_helper
DEBUG - 2016-05-24 15:37:58 --> Session routines successfully run
DEBUG - 2016-05-24 15:37:58 --> Native_session Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-24 15:37:58 --> Form Validation Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Form Validation Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-24 15:37:58 --> Controller Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Carabiner: Library initialized.
DEBUG - 2016-05-24 15:37:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-24 15:37:58 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-24 15:37:58 --> Carabiner: library configured.
DEBUG - 2016-05-24 15:37:58 --> Carabiner: library configured.
DEBUG - 2016-05-24 15:37:58 --> User Agent Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Model Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Model Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Model Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Model Class Initialized
DEBUG - 2016-05-24 15:37:58 --> Model Class Initialized
ERROR - 2016-05-24 15:37:58 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-05-24 15:37:58 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-24 15:37:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-24 15:37:58 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-05-24 15:37:58 --> Final output sent to browser
DEBUG - 2016-05-24 15:37:58 --> Total execution time: 0.3478
DEBUG - 2016-05-24 15:38:22 --> Config Class Initialized
DEBUG - 2016-05-24 15:38:22 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:38:22 --> Utf8 Class Initialized
DEBUG - 2016-05-24 15:38:22 --> UTF-8 Support Enabled
DEBUG - 2016-05-24 15:38:22 --> URI Class Initialized
DEBUG - 2016-05-24 15:38:22 --> Router Class Initialized
DEBUG - 2016-05-24 15:38:22 --> Output Class Initialized
DEBUG - 2016-05-24 15:38:22 --> Cache file has expired. File deleted
DEBUG - 2016-05-24 15:38:22 --> Security Class Initialized
DEBUG - 2016-05-24 15:38:22 --> Input Class Initialized
DEBUG - 2016-05-24 15:38:22 --> XSS Filtering completed
DEBUG - 2016-05-24 15:38:22 --> XSS Filtering completed
DEBUG - 2016-05-24 15:38:22 --> XSS Filtering completed
DEBUG - 2016-05-24 15:38:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-24 15:38:22 --> Language Class Initialized
DEBUG - 2016-05-24 15:38:22 --> Loader Class Initialized
DEBUG - 2016-05-24 15:38:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-24 15:38:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-24 15:38:22 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:38:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-24 15:38:22 --> Helper loaded: file_helper
DEBUG - 2016-05-24 15:38:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 15:38:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-24 15:38:22 --> Helper loaded: conf_helper
DEBUG - 2016-05-24 15:38:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 15:38:22 --> Check Exists common_helper.php: No
DEBUG - 2016-05-24 15:38:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-24 15:38:22 --> Helper loaded: common_helper
DEBUG - 2016-05-24 15:38:22 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-24 15:38:22 --> Helper loaded: common_helper
DEBUG - 2016-05-24 15:38:22 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-24 15:38:22 --> Helper loaded: form_helper
DEBUG - 2016-05-24 15:38:22 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-24 15:38:22 --> Helper loaded: security_helper
DEBUG - 2016-05-24 15:38:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 15:38:22 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-24 15:38:22 --> Helper loaded: lang_helper
DEBUG - 2016-05-24 15:38:22 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 15:38:22 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-24 15:38:22 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-24 15:38:22 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-24 15:38:22 --> Helper loaded: atlant_helper
DEBUG - 2016-05-24 15:38:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 15:38:22 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-24 15:38:22 --> Helper loaded: crypto_helper
DEBUG - 2016-05-24 15:38:22 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 15:38:22 --> Database Driver Class Initialized
DEBUG - 2016-05-24 15:38:22 --> Session Class Initialized
DEBUG - 2016-05-24 15:38:22 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-24 15:38:22 --> Helper loaded: string_helper
DEBUG - 2016-05-24 15:38:22 --> Session routines successfully run
DEBUG - 2016-05-24 15:38:22 --> Native_session Class Initialized
DEBUG - 2016-05-24 15:38:22 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-24 15:38:22 --> Form Validation Class Initialized
DEBUG - 2016-05-24 15:38:22 --> Form Validation Class Initialized
DEBUG - 2016-05-24 15:38:22 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-24 15:38:22 --> Controller Class Initialized
DEBUG - 2016-05-24 15:38:22 --> Carabiner: Library initialized.
DEBUG - 2016-05-24 15:38:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-24 15:38:22 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-24 15:38:22 --> Carabiner: library configured.
DEBUG - 2016-05-24 15:38:22 --> Carabiner: library configured.
DEBUG - 2016-05-24 15:38:22 --> User Agent Class Initialized
DEBUG - 2016-05-24 15:38:22 --> Model Class Initialized
DEBUG - 2016-05-24 15:38:22 --> Model Class Initialized
DEBUG - 2016-05-24 15:38:22 --> Model Class Initialized
DEBUG - 2016-05-24 15:38:22 --> Model Class Initialized
DEBUG - 2016-05-24 15:38:22 --> Model Class Initialized
DEBUG - 2016-05-24 15:38:22 --> Upload Class Initialized
DEBUG - 2016-05-24 15:38:22 --> Upload Class Initialized
DEBUG - 2016-05-24 15:38:22 --> Class Library loaded: LWS_Upload on upload
ERROR - 2016-05-24 15:38:22 --> Severity: Warning  --> require_once(E:\www\GitHub\2016APSIDIKA\application\third_party/phpexcel/PHPExcel.php): failed to open stream: No such file or directory E:\www\lwscodeigniterwrapper\libraries\Excel.php 9
DEBUG - 2016-05-24 15:39:38 --> Config Class Initialized
DEBUG - 2016-05-24 15:39:38 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:39:38 --> Utf8 Class Initialized
DEBUG - 2016-05-24 15:39:38 --> UTF-8 Support Enabled
DEBUG - 2016-05-24 15:39:38 --> URI Class Initialized
DEBUG - 2016-05-24 15:39:38 --> Router Class Initialized
DEBUG - 2016-05-24 15:39:38 --> Output Class Initialized
DEBUG - 2016-05-24 15:39:38 --> Security Class Initialized
DEBUG - 2016-05-24 15:39:38 --> Input Class Initialized
DEBUG - 2016-05-24 15:39:38 --> XSS Filtering completed
DEBUG - 2016-05-24 15:39:38 --> XSS Filtering completed
DEBUG - 2016-05-24 15:39:38 --> XSS Filtering completed
DEBUG - 2016-05-24 15:39:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-24 15:39:38 --> Language Class Initialized
DEBUG - 2016-05-24 15:39:38 --> Loader Class Initialized
DEBUG - 2016-05-24 15:39:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-24 15:39:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-24 15:39:38 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:39:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-24 15:39:38 --> Helper loaded: file_helper
DEBUG - 2016-05-24 15:39:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 15:39:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-24 15:39:38 --> Helper loaded: conf_helper
DEBUG - 2016-05-24 15:39:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 15:39:38 --> Check Exists common_helper.php: No
DEBUG - 2016-05-24 15:39:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-24 15:39:38 --> Helper loaded: common_helper
DEBUG - 2016-05-24 15:39:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-24 15:39:38 --> Helper loaded: common_helper
DEBUG - 2016-05-24 15:39:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-24 15:39:38 --> Helper loaded: form_helper
DEBUG - 2016-05-24 15:39:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-24 15:39:38 --> Helper loaded: security_helper
DEBUG - 2016-05-24 15:39:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 15:39:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-24 15:39:38 --> Helper loaded: lang_helper
DEBUG - 2016-05-24 15:39:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 15:39:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-24 15:39:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-24 15:39:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-24 15:39:38 --> Helper loaded: atlant_helper
DEBUG - 2016-05-24 15:39:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 15:39:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-24 15:39:38 --> Helper loaded: crypto_helper
DEBUG - 2016-05-24 15:39:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 15:39:38 --> Database Driver Class Initialized
DEBUG - 2016-05-24 15:39:38 --> Session Class Initialized
DEBUG - 2016-05-24 15:39:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-24 15:39:38 --> Helper loaded: string_helper
DEBUG - 2016-05-24 15:39:38 --> Session routines successfully run
DEBUG - 2016-05-24 15:39:38 --> Native_session Class Initialized
DEBUG - 2016-05-24 15:39:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-24 15:39:38 --> Form Validation Class Initialized
DEBUG - 2016-05-24 15:39:38 --> Form Validation Class Initialized
DEBUG - 2016-05-24 15:39:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-24 15:39:38 --> Controller Class Initialized
DEBUG - 2016-05-24 15:39:38 --> Carabiner: Library initialized.
DEBUG - 2016-05-24 15:39:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-24 15:39:38 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-24 15:39:38 --> Carabiner: library configured.
DEBUG - 2016-05-24 15:39:38 --> Carabiner: library configured.
DEBUG - 2016-05-24 15:39:38 --> User Agent Class Initialized
DEBUG - 2016-05-24 15:39:38 --> Model Class Initialized
DEBUG - 2016-05-24 15:39:38 --> Model Class Initialized
DEBUG - 2016-05-24 15:39:38 --> Model Class Initialized
DEBUG - 2016-05-24 15:39:38 --> Model Class Initialized
DEBUG - 2016-05-24 15:39:38 --> Model Class Initialized
DEBUG - 2016-05-24 15:39:38 --> Upload Class Initialized
DEBUG - 2016-05-24 15:39:38 --> Upload Class Initialized
DEBUG - 2016-05-24 15:39:38 --> Class Library loaded: LWS_Upload on upload
ERROR - 2016-05-24 15:39:38 --> Severity: Warning  --> require_once(E:\www\GitHub\2016APSIDIKA\application\libraries/PHPExcel/PHPExcel.php): failed to open stream: No such file or directory E:\www\lwscodeigniterwrapper\libraries\Excel.php 9
DEBUG - 2016-05-24 15:39:44 --> Config Class Initialized
DEBUG - 2016-05-24 15:39:44 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:39:44 --> Utf8 Class Initialized
DEBUG - 2016-05-24 15:39:44 --> UTF-8 Support Enabled
DEBUG - 2016-05-24 15:39:44 --> URI Class Initialized
DEBUG - 2016-05-24 15:39:44 --> Router Class Initialized
DEBUG - 2016-05-24 15:39:44 --> Output Class Initialized
DEBUG - 2016-05-24 15:39:44 --> Security Class Initialized
DEBUG - 2016-05-24 15:39:44 --> Input Class Initialized
DEBUG - 2016-05-24 15:39:44 --> XSS Filtering completed
DEBUG - 2016-05-24 15:39:44 --> XSS Filtering completed
DEBUG - 2016-05-24 15:39:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-24 15:39:44 --> Language Class Initialized
DEBUG - 2016-05-24 15:39:44 --> Loader Class Initialized
DEBUG - 2016-05-24 15:39:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-24 15:39:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-24 15:39:44 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:39:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-24 15:39:44 --> Helper loaded: file_helper
DEBUG - 2016-05-24 15:39:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 15:39:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-24 15:39:44 --> Helper loaded: conf_helper
DEBUG - 2016-05-24 15:39:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 15:39:44 --> Check Exists common_helper.php: No
DEBUG - 2016-05-24 15:39:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-24 15:39:44 --> Helper loaded: common_helper
DEBUG - 2016-05-24 15:39:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-24 15:39:44 --> Helper loaded: common_helper
DEBUG - 2016-05-24 15:39:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-24 15:39:44 --> Helper loaded: form_helper
DEBUG - 2016-05-24 15:39:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-24 15:39:44 --> Helper loaded: security_helper
DEBUG - 2016-05-24 15:39:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 15:39:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-24 15:39:44 --> Helper loaded: lang_helper
DEBUG - 2016-05-24 15:39:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 15:39:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-24 15:39:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-24 15:39:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-24 15:39:44 --> Helper loaded: atlant_helper
DEBUG - 2016-05-24 15:39:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 15:39:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-24 15:39:44 --> Helper loaded: crypto_helper
DEBUG - 2016-05-24 15:39:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 15:39:44 --> Database Driver Class Initialized
DEBUG - 2016-05-24 15:39:44 --> Session Class Initialized
DEBUG - 2016-05-24 15:39:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-24 15:39:44 --> Helper loaded: string_helper
DEBUG - 2016-05-24 15:39:44 --> Session routines successfully run
DEBUG - 2016-05-24 15:39:44 --> Native_session Class Initialized
DEBUG - 2016-05-24 15:39:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-24 15:39:44 --> Form Validation Class Initialized
DEBUG - 2016-05-24 15:39:44 --> Form Validation Class Initialized
DEBUG - 2016-05-24 15:39:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-24 15:39:44 --> Controller Class Initialized
DEBUG - 2016-05-24 15:39:44 --> Carabiner: Library initialized.
DEBUG - 2016-05-24 15:39:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-24 15:39:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-24 15:39:44 --> Carabiner: library configured.
DEBUG - 2016-05-24 15:39:44 --> Carabiner: library configured.
DEBUG - 2016-05-24 15:39:44 --> User Agent Class Initialized
DEBUG - 2016-05-24 15:39:44 --> Model Class Initialized
DEBUG - 2016-05-24 15:39:44 --> Model Class Initialized
DEBUG - 2016-05-24 15:39:44 --> Model Class Initialized
DEBUG - 2016-05-24 15:39:44 --> Model Class Initialized
DEBUG - 2016-05-24 15:39:44 --> Model Class Initialized
DEBUG - 2016-05-24 15:39:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-24 15:39:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-24 15:39:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-24 15:39:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-24 15:39:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-24 15:39:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-24 15:39:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-24 15:39:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-24 15:39:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-24 15:39:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-24 15:39:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-24 15:39:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-24 15:39:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-24 15:39:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-24 15:39:44 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-05-24 15:39:44 --> Final output sent to browser
DEBUG - 2016-05-24 15:39:44 --> Total execution time: 0.3859
DEBUG - 2016-05-24 15:39:45 --> Config Class Initialized
DEBUG - 2016-05-24 15:39:45 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:39:45 --> Utf8 Class Initialized
DEBUG - 2016-05-24 15:39:45 --> UTF-8 Support Enabled
DEBUG - 2016-05-24 15:39:45 --> URI Class Initialized
DEBUG - 2016-05-24 15:39:45 --> Router Class Initialized
DEBUG - 2016-05-24 15:39:45 --> Output Class Initialized
DEBUG - 2016-05-24 15:39:45 --> Cache file has expired. File deleted
DEBUG - 2016-05-24 15:39:45 --> Security Class Initialized
DEBUG - 2016-05-24 15:39:45 --> Input Class Initialized
DEBUG - 2016-05-24 15:39:45 --> XSS Filtering completed
DEBUG - 2016-05-24 15:39:45 --> XSS Filtering completed
DEBUG - 2016-05-24 15:39:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-24 15:39:45 --> Language Class Initialized
DEBUG - 2016-05-24 15:39:45 --> Loader Class Initialized
DEBUG - 2016-05-24 15:39:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-24 15:39:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-24 15:39:45 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:39:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-24 15:39:45 --> Helper loaded: file_helper
DEBUG - 2016-05-24 15:39:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 15:39:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-24 15:39:45 --> Helper loaded: conf_helper
DEBUG - 2016-05-24 15:39:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 15:39:45 --> Check Exists common_helper.php: No
DEBUG - 2016-05-24 15:39:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-24 15:39:45 --> Helper loaded: common_helper
DEBUG - 2016-05-24 15:39:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-24 15:39:45 --> Helper loaded: common_helper
DEBUG - 2016-05-24 15:39:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-24 15:39:45 --> Helper loaded: form_helper
DEBUG - 2016-05-24 15:39:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-24 15:39:45 --> Helper loaded: security_helper
DEBUG - 2016-05-24 15:39:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 15:39:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-24 15:39:45 --> Helper loaded: lang_helper
DEBUG - 2016-05-24 15:39:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 15:39:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-24 15:39:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-24 15:39:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-24 15:39:45 --> Helper loaded: atlant_helper
DEBUG - 2016-05-24 15:39:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 15:39:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-24 15:39:45 --> Helper loaded: crypto_helper
DEBUG - 2016-05-24 15:39:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 15:39:45 --> Database Driver Class Initialized
DEBUG - 2016-05-24 15:39:45 --> Session Class Initialized
DEBUG - 2016-05-24 15:39:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-24 15:39:45 --> Helper loaded: string_helper
DEBUG - 2016-05-24 15:39:45 --> Session routines successfully run
DEBUG - 2016-05-24 15:39:45 --> Native_session Class Initialized
DEBUG - 2016-05-24 15:39:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-24 15:39:45 --> Form Validation Class Initialized
DEBUG - 2016-05-24 15:39:45 --> Form Validation Class Initialized
DEBUG - 2016-05-24 15:39:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-24 15:39:45 --> Controller Class Initialized
DEBUG - 2016-05-24 15:39:45 --> Carabiner: Library initialized.
DEBUG - 2016-05-24 15:39:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-24 15:39:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-24 15:39:45 --> Carabiner: library configured.
DEBUG - 2016-05-24 15:39:45 --> Carabiner: library configured.
DEBUG - 2016-05-24 15:39:45 --> User Agent Class Initialized
DEBUG - 2016-05-24 15:39:45 --> Model Class Initialized
DEBUG - 2016-05-24 15:39:45 --> Model Class Initialized
DEBUG - 2016-05-24 15:39:45 --> Model Class Initialized
DEBUG - 2016-05-24 15:39:45 --> Model Class Initialized
DEBUG - 2016-05-24 15:39:45 --> Model Class Initialized
ERROR - 2016-05-24 15:39:45 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-05-24 15:39:45 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-05-24 15:39:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-24 15:39:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-05-24 15:39:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-24 15:39:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-24 15:39:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-24 15:39:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-24 15:39:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-24 15:39:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-24 15:39:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-24 15:39:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-24 15:39:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-24 15:39:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-24 15:39:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-24 15:39:45 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-24 15:39:45 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-05-24 15:39:45 --> Final output sent to browser
DEBUG - 2016-05-24 15:39:45 --> Total execution time: 0.4016
DEBUG - 2016-05-24 15:39:48 --> Config Class Initialized
DEBUG - 2016-05-24 15:39:48 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:39:48 --> Utf8 Class Initialized
DEBUG - 2016-05-24 15:39:48 --> UTF-8 Support Enabled
DEBUG - 2016-05-24 15:39:48 --> URI Class Initialized
DEBUG - 2016-05-24 15:39:48 --> Router Class Initialized
DEBUG - 2016-05-24 15:39:48 --> Output Class Initialized
DEBUG - 2016-05-24 15:39:48 --> Cache file has expired. File deleted
DEBUG - 2016-05-24 15:39:48 --> Security Class Initialized
DEBUG - 2016-05-24 15:39:48 --> Input Class Initialized
DEBUG - 2016-05-24 15:39:48 --> XSS Filtering completed
DEBUG - 2016-05-24 15:39:48 --> XSS Filtering completed
DEBUG - 2016-05-24 15:39:48 --> XSS Filtering completed
DEBUG - 2016-05-24 15:39:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-24 15:39:48 --> Language Class Initialized
DEBUG - 2016-05-24 15:39:48 --> Loader Class Initialized
DEBUG - 2016-05-24 15:39:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-24 15:39:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-24 15:39:48 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:39:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-24 15:39:48 --> Helper loaded: file_helper
DEBUG - 2016-05-24 15:39:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 15:39:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-24 15:39:48 --> Helper loaded: conf_helper
DEBUG - 2016-05-24 15:39:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 15:39:48 --> Check Exists common_helper.php: No
DEBUG - 2016-05-24 15:39:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-24 15:39:48 --> Helper loaded: common_helper
DEBUG - 2016-05-24 15:39:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-24 15:39:48 --> Helper loaded: common_helper
DEBUG - 2016-05-24 15:39:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-24 15:39:48 --> Helper loaded: form_helper
DEBUG - 2016-05-24 15:39:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-24 15:39:48 --> Helper loaded: security_helper
DEBUG - 2016-05-24 15:39:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 15:39:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-24 15:39:48 --> Helper loaded: lang_helper
DEBUG - 2016-05-24 15:39:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 15:39:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-24 15:39:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-24 15:39:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-24 15:39:48 --> Helper loaded: atlant_helper
DEBUG - 2016-05-24 15:39:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 15:39:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-24 15:39:48 --> Helper loaded: crypto_helper
DEBUG - 2016-05-24 15:39:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 15:39:48 --> Database Driver Class Initialized
DEBUG - 2016-05-24 15:39:48 --> Session Class Initialized
DEBUG - 2016-05-24 15:39:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-24 15:39:48 --> Helper loaded: string_helper
DEBUG - 2016-05-24 15:39:48 --> Session routines successfully run
DEBUG - 2016-05-24 15:39:48 --> Native_session Class Initialized
DEBUG - 2016-05-24 15:39:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-24 15:39:48 --> Form Validation Class Initialized
DEBUG - 2016-05-24 15:39:48 --> Form Validation Class Initialized
DEBUG - 2016-05-24 15:39:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-24 15:39:48 --> Controller Class Initialized
DEBUG - 2016-05-24 15:39:48 --> Carabiner: Library initialized.
DEBUG - 2016-05-24 15:39:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-24 15:39:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-24 15:39:48 --> Carabiner: library configured.
DEBUG - 2016-05-24 15:39:48 --> Carabiner: library configured.
DEBUG - 2016-05-24 15:39:48 --> User Agent Class Initialized
DEBUG - 2016-05-24 15:39:48 --> Model Class Initialized
DEBUG - 2016-05-24 15:39:48 --> Model Class Initialized
DEBUG - 2016-05-24 15:39:48 --> Model Class Initialized
DEBUG - 2016-05-24 15:39:48 --> Model Class Initialized
DEBUG - 2016-05-24 15:39:48 --> Model Class Initialized
DEBUG - 2016-05-24 15:39:48 --> Upload Class Initialized
DEBUG - 2016-05-24 15:39:48 --> Upload Class Initialized
DEBUG - 2016-05-24 15:39:48 --> Class Library loaded: LWS_Upload on upload
ERROR - 2016-05-24 15:39:48 --> Severity: Warning  --> require_once(E:\www\GitHub\2016APSIDIKA\application\libraries/PHPExcel/PHPExcel.php): failed to open stream: No such file or directory E:\www\lwscodeigniterwrapper\libraries\Excel.php 9
DEBUG - 2016-05-24 15:40:41 --> Config Class Initialized
DEBUG - 2016-05-24 15:40:41 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:40:41 --> Utf8 Class Initialized
DEBUG - 2016-05-24 15:40:41 --> UTF-8 Support Enabled
DEBUG - 2016-05-24 15:40:41 --> URI Class Initialized
DEBUG - 2016-05-24 15:40:41 --> Router Class Initialized
DEBUG - 2016-05-24 15:40:41 --> Output Class Initialized
DEBUG - 2016-05-24 15:40:41 --> Security Class Initialized
DEBUG - 2016-05-24 15:40:41 --> Input Class Initialized
DEBUG - 2016-05-24 15:40:41 --> XSS Filtering completed
DEBUG - 2016-05-24 15:40:41 --> XSS Filtering completed
DEBUG - 2016-05-24 15:40:41 --> XSS Filtering completed
DEBUG - 2016-05-24 15:40:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-24 15:40:41 --> Language Class Initialized
DEBUG - 2016-05-24 15:40:41 --> Loader Class Initialized
DEBUG - 2016-05-24 15:40:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-24 15:40:41 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-24 15:40:41 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:40:41 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-24 15:40:41 --> Helper loaded: file_helper
DEBUG - 2016-05-24 15:40:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 15:40:41 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-24 15:40:41 --> Helper loaded: conf_helper
DEBUG - 2016-05-24 15:40:41 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 15:40:41 --> Check Exists common_helper.php: No
DEBUG - 2016-05-24 15:40:41 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-24 15:40:41 --> Helper loaded: common_helper
DEBUG - 2016-05-24 15:40:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-24 15:40:41 --> Helper loaded: common_helper
DEBUG - 2016-05-24 15:40:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-24 15:40:41 --> Helper loaded: form_helper
DEBUG - 2016-05-24 15:40:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-24 15:40:41 --> Helper loaded: security_helper
DEBUG - 2016-05-24 15:40:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 15:40:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-24 15:40:41 --> Helper loaded: lang_helper
DEBUG - 2016-05-24 15:40:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 15:40:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-24 15:40:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-24 15:40:42 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-24 15:40:42 --> Helper loaded: atlant_helper
DEBUG - 2016-05-24 15:40:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 15:40:42 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-24 15:40:42 --> Helper loaded: crypto_helper
DEBUG - 2016-05-24 15:40:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 15:40:42 --> Database Driver Class Initialized
DEBUG - 2016-05-24 15:40:42 --> Session Class Initialized
DEBUG - 2016-05-24 15:40:42 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-24 15:40:42 --> Helper loaded: string_helper
DEBUG - 2016-05-24 15:40:42 --> Session routines successfully run
DEBUG - 2016-05-24 15:40:42 --> Native_session Class Initialized
DEBUG - 2016-05-24 15:40:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-24 15:40:42 --> Form Validation Class Initialized
DEBUG - 2016-05-24 15:40:42 --> Form Validation Class Initialized
DEBUG - 2016-05-24 15:40:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-24 15:40:42 --> Controller Class Initialized
DEBUG - 2016-05-24 15:40:42 --> Carabiner: Library initialized.
DEBUG - 2016-05-24 15:40:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-24 15:40:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-24 15:40:42 --> Carabiner: library configured.
DEBUG - 2016-05-24 15:40:42 --> Carabiner: library configured.
DEBUG - 2016-05-24 15:40:42 --> User Agent Class Initialized
DEBUG - 2016-05-24 15:40:42 --> Model Class Initialized
DEBUG - 2016-05-24 15:40:42 --> Model Class Initialized
DEBUG - 2016-05-24 15:40:42 --> Model Class Initialized
DEBUG - 2016-05-24 15:40:42 --> Model Class Initialized
DEBUG - 2016-05-24 15:40:42 --> Model Class Initialized
DEBUG - 2016-05-24 15:40:42 --> Upload Class Initialized
DEBUG - 2016-05-24 15:40:42 --> Upload Class Initialized
DEBUG - 2016-05-24 15:40:42 --> Class Library loaded: LWS_Upload on upload
ERROR - 2016-05-24 15:40:43 --> Severity: Notice  --> Undefined property: Cpeserta_diklat::$Excel E:\www\GitHub\2016APSIDIKA\application\controllers\back_end\cpeserta_diklat.php 112
DEBUG - 2016-05-24 15:41:00 --> Config Class Initialized
DEBUG - 2016-05-24 15:41:00 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:41:00 --> Utf8 Class Initialized
DEBUG - 2016-05-24 15:41:00 --> UTF-8 Support Enabled
DEBUG - 2016-05-24 15:41:00 --> URI Class Initialized
DEBUG - 2016-05-24 15:41:00 --> Router Class Initialized
DEBUG - 2016-05-24 15:41:00 --> Output Class Initialized
DEBUG - 2016-05-24 15:41:00 --> Security Class Initialized
DEBUG - 2016-05-24 15:41:00 --> Input Class Initialized
DEBUG - 2016-05-24 15:41:00 --> XSS Filtering completed
DEBUG - 2016-05-24 15:41:00 --> XSS Filtering completed
DEBUG - 2016-05-24 15:41:00 --> XSS Filtering completed
DEBUG - 2016-05-24 15:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-24 15:41:00 --> Language Class Initialized
DEBUG - 2016-05-24 15:41:00 --> Loader Class Initialized
DEBUG - 2016-05-24 15:41:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-24 15:41:00 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-24 15:41:00 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:41:00 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-24 15:41:00 --> Helper loaded: file_helper
DEBUG - 2016-05-24 15:41:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 15:41:00 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-24 15:41:00 --> Helper loaded: conf_helper
DEBUG - 2016-05-24 15:41:00 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-24 15:41:00 --> Check Exists common_helper.php: No
DEBUG - 2016-05-24 15:41:00 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-24 15:41:00 --> Helper loaded: common_helper
DEBUG - 2016-05-24 15:41:00 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-24 15:41:00 --> Helper loaded: common_helper
DEBUG - 2016-05-24 15:41:00 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-24 15:41:00 --> Helper loaded: form_helper
DEBUG - 2016-05-24 15:41:00 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-24 15:41:00 --> Helper loaded: security_helper
DEBUG - 2016-05-24 15:41:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 15:41:00 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-24 15:41:00 --> Helper loaded: lang_helper
DEBUG - 2016-05-24 15:41:00 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-24 15:41:00 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-24 15:41:00 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-24 15:41:00 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-24 15:41:00 --> Helper loaded: atlant_helper
DEBUG - 2016-05-24 15:41:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 15:41:00 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-24 15:41:00 --> Helper loaded: crypto_helper
DEBUG - 2016-05-24 15:41:00 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-24 15:41:00 --> Database Driver Class Initialized
DEBUG - 2016-05-24 15:41:00 --> Session Class Initialized
DEBUG - 2016-05-24 15:41:00 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-24 15:41:00 --> Helper loaded: string_helper
DEBUG - 2016-05-24 15:41:00 --> Session routines successfully run
DEBUG - 2016-05-24 15:41:00 --> Native_session Class Initialized
DEBUG - 2016-05-24 15:41:00 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-24 15:41:00 --> Form Validation Class Initialized
DEBUG - 2016-05-24 15:41:00 --> Form Validation Class Initialized
DEBUG - 2016-05-24 15:41:00 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-24 15:41:00 --> Controller Class Initialized
DEBUG - 2016-05-24 15:41:00 --> Carabiner: Library initialized.
DEBUG - 2016-05-24 15:41:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-24 15:41:00 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-24 15:41:00 --> Carabiner: library configured.
DEBUG - 2016-05-24 15:41:00 --> Carabiner: library configured.
DEBUG - 2016-05-24 15:41:00 --> User Agent Class Initialized
DEBUG - 2016-05-24 15:41:00 --> Model Class Initialized
DEBUG - 2016-05-24 15:41:00 --> Model Class Initialized
DEBUG - 2016-05-24 15:41:00 --> Model Class Initialized
DEBUG - 2016-05-24 15:41:00 --> Model Class Initialized
DEBUG - 2016-05-24 15:41:00 --> Model Class Initialized
DEBUG - 2016-05-24 15:41:00 --> Upload Class Initialized
DEBUG - 2016-05-24 15:41:00 --> Upload Class Initialized
DEBUG - 2016-05-24 15:41:00 --> Class Library loaded: LWS_Upload on upload
