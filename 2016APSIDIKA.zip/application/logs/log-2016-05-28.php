<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-05-28 17:31:18 --> Config Class Initialized
DEBUG - 2016-05-28 17:31:19 --> Hooks Class Initialized
DEBUG - 2016-05-28 17:31:19 --> Utf8 Class Initialized
DEBUG - 2016-05-28 17:31:19 --> UTF-8 Support Enabled
DEBUG - 2016-05-28 17:31:19 --> URI Class Initialized
DEBUG - 2016-05-28 17:31:19 --> Router Class Initialized
DEBUG - 2016-05-28 17:31:20 --> Output Class Initialized
DEBUG - 2016-05-28 17:31:20 --> Cache file has expired. File deleted
DEBUG - 2016-05-28 17:31:20 --> Security Class Initialized
DEBUG - 2016-05-28 17:31:20 --> Input Class Initialized
DEBUG - 2016-05-28 17:31:20 --> XSS Filtering completed
DEBUG - 2016-05-28 17:31:20 --> XSS Filtering completed
DEBUG - 2016-05-28 17:31:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-28 17:31:20 --> Language Class Initialized
DEBUG - 2016-05-28 17:31:23 --> Loader Class Initialized
DEBUG - 2016-05-28 17:31:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-28 17:31:23 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-28 17:31:24 --> Helper loaded: url_helper
DEBUG - 2016-05-28 17:31:24 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-28 17:31:24 --> Helper loaded: file_helper
DEBUG - 2016-05-28 17:31:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-28 17:31:24 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-28 17:31:24 --> Helper loaded: conf_helper
DEBUG - 2016-05-28 17:31:24 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-28 17:31:24 --> Check Exists common_helper.php: No
DEBUG - 2016-05-28 17:31:24 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-28 17:31:24 --> Helper loaded: common_helper
DEBUG - 2016-05-28 17:31:24 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-28 17:31:24 --> Helper loaded: common_helper
DEBUG - 2016-05-28 17:31:24 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-28 17:31:24 --> Helper loaded: form_helper
DEBUG - 2016-05-28 17:31:24 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-28 17:31:24 --> Helper loaded: security_helper
DEBUG - 2016-05-28 17:31:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-28 17:31:24 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-28 17:31:24 --> Helper loaded: lang_helper
DEBUG - 2016-05-28 17:31:24 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-28 17:31:24 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-28 17:31:24 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-28 17:31:24 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-28 17:31:24 --> Helper loaded: atlant_helper
DEBUG - 2016-05-28 17:31:24 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-28 17:31:24 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-28 17:31:25 --> Helper loaded: crypto_helper
DEBUG - 2016-05-28 17:31:25 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-28 17:31:27 --> Database Driver Class Initialized
DEBUG - 2016-05-28 17:31:28 --> Session Class Initialized
DEBUG - 2016-05-28 17:31:28 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-28 17:31:28 --> Helper loaded: string_helper
DEBUG - 2016-05-28 17:31:28 --> Session routines successfully run
DEBUG - 2016-05-28 17:31:28 --> Native_session Class Initialized
DEBUG - 2016-05-28 17:31:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-28 17:31:29 --> Form Validation Class Initialized
DEBUG - 2016-05-28 17:31:29 --> Form Validation Class Initialized
DEBUG - 2016-05-28 17:31:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-28 17:31:30 --> Controller Class Initialized
DEBUG - 2016-05-28 17:31:31 --> Carabiner: Library initialized.
DEBUG - 2016-05-28 17:31:31 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-28 17:31:31 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-28 17:31:31 --> Carabiner: library configured.
DEBUG - 2016-05-28 17:31:31 --> Carabiner: library configured.
DEBUG - 2016-05-28 17:31:31 --> User Agent Class Initialized
DEBUG - 2016-05-28 17:31:31 --> Model Class Initialized
DEBUG - 2016-05-28 17:31:31 --> Model Class Initialized
DEBUG - 2016-05-28 17:31:32 --> Model Class Initialized
DEBUG - 2016-05-28 17:31:32 --> Model Class Initialized
DEBUG - 2016-05-28 17:31:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-28 17:31:33 --> Pagination Class Initialized
DEBUG - 2016-05-28 17:31:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-28 17:31:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/index.php
DEBUG - 2016-05-28 17:31:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-28 17:31:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-28 17:31:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-28 17:31:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-28 17:31:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-05-28 17:31:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-28 17:31:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-28 17:31:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-28 17:31:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-28 17:31:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-28 17:31:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-28 17:31:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-05-28 17:31:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-28 17:31:33 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-28 17:31:33 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0afc8ae14bdb2df5b4e2fbf4366db4fc
DEBUG - 2016-05-28 17:31:33 --> Final output sent to browser
DEBUG - 2016-05-28 17:31:33 --> Total execution time: 14.6341
DEBUG - 2016-05-28 21:43:33 --> Config Class Initialized
DEBUG - 2016-05-28 21:43:33 --> Hooks Class Initialized
DEBUG - 2016-05-28 21:43:33 --> Utf8 Class Initialized
DEBUG - 2016-05-28 21:43:33 --> UTF-8 Support Enabled
DEBUG - 2016-05-28 21:43:33 --> URI Class Initialized
DEBUG - 2016-05-28 21:43:33 --> Router Class Initialized
DEBUG - 2016-05-28 21:43:33 --> Output Class Initialized
DEBUG - 2016-05-28 21:43:33 --> Cache file has expired. File deleted
DEBUG - 2016-05-28 21:43:33 --> Security Class Initialized
DEBUG - 2016-05-28 21:43:33 --> Input Class Initialized
DEBUG - 2016-05-28 21:43:33 --> XSS Filtering completed
DEBUG - 2016-05-28 21:43:33 --> XSS Filtering completed
DEBUG - 2016-05-28 21:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-28 21:43:33 --> Language Class Initialized
DEBUG - 2016-05-28 21:43:33 --> Loader Class Initialized
DEBUG - 2016-05-28 21:43:33 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-05-28 21:43:33 --> Check Exists url_helper.php: Yes
DEBUG - 2016-05-28 21:43:33 --> Helper loaded: url_helper
DEBUG - 2016-05-28 21:43:33 --> Check Exists file_helper.php: Yes
DEBUG - 2016-05-28 21:43:34 --> Helper loaded: file_helper
DEBUG - 2016-05-28 21:43:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-28 21:43:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-05-28 21:43:34 --> Helper loaded: conf_helper
DEBUG - 2016-05-28 21:43:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-05-28 21:43:34 --> Check Exists common_helper.php: No
DEBUG - 2016-05-28 21:43:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-05-28 21:43:34 --> Helper loaded: common_helper
DEBUG - 2016-05-28 21:43:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-05-28 21:43:34 --> Helper loaded: common_helper
DEBUG - 2016-05-28 21:43:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-05-28 21:43:34 --> Helper loaded: form_helper
DEBUG - 2016-05-28 21:43:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-05-28 21:43:34 --> Helper loaded: security_helper
DEBUG - 2016-05-28 21:43:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-28 21:43:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-05-28 21:43:34 --> Helper loaded: lang_helper
DEBUG - 2016-05-28 21:43:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-05-28 21:43:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-05-28 21:43:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-05-28 21:43:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-05-28 21:43:34 --> Helper loaded: atlant_helper
DEBUG - 2016-05-28 21:43:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-28 21:43:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-05-28 21:43:34 --> Helper loaded: crypto_helper
DEBUG - 2016-05-28 21:43:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-05-28 21:43:34 --> Database Driver Class Initialized
DEBUG - 2016-05-28 21:43:34 --> Session Class Initialized
DEBUG - 2016-05-28 21:43:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-05-28 21:43:34 --> Helper loaded: string_helper
DEBUG - 2016-05-28 21:43:34 --> Session routines successfully run
DEBUG - 2016-05-28 21:43:34 --> Native_session Class Initialized
DEBUG - 2016-05-28 21:43:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-05-28 21:43:34 --> Form Validation Class Initialized
DEBUG - 2016-05-28 21:43:34 --> Form Validation Class Initialized
DEBUG - 2016-05-28 21:43:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-05-28 21:43:34 --> Controller Class Initialized
DEBUG - 2016-05-28 21:43:34 --> Carabiner: Library initialized.
DEBUG - 2016-05-28 21:43:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-05-28 21:43:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-05-28 21:43:34 --> Carabiner: library configured.
DEBUG - 2016-05-28 21:43:34 --> Carabiner: library configured.
DEBUG - 2016-05-28 21:43:34 --> User Agent Class Initialized
DEBUG - 2016-05-28 21:43:34 --> Model Class Initialized
DEBUG - 2016-05-28 21:43:34 --> Model Class Initialized
ERROR - 2016-05-28 21:43:35 --> Severity: Notice  --> Undefined index: username E:\www\lwscodeigniterwrapper\models\model_user.php 50
DEBUG - 2016-05-28 21:43:35 --> Model Class Initialized
DEBUG - 2016-05-28 21:43:35 --> Model Class Initialized
DEBUG - 2016-05-28 21:43:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-05-28 21:43:35 --> Pagination Class Initialized
DEBUG - 2016-05-28 21:43:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-05-28 21:43:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/index.php
DEBUG - 2016-05-28 21:43:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-28 21:43:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-28 21:43:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-28 21:43:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-28 21:43:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-05-28 21:43:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-28 21:43:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-28 21:43:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-05-28 21:43:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-05-28 21:43:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-05-28 21:43:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-05-28 21:43:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-05-28 21:43:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-05-28 21:43:36 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-05-28 21:43:36 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0afc8ae14bdb2df5b4e2fbf4366db4fc
DEBUG - 2016-05-28 21:43:36 --> Final output sent to browser
DEBUG - 2016-05-28 21:43:36 --> Total execution time: 2.7742
