<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-12-08 22:51:03 --> Config Class Initialized
DEBUG - 2016-12-08 22:51:03 --> Hooks Class Initialized
DEBUG - 2016-12-08 22:51:03 --> Utf8 Class Initialized
DEBUG - 2016-12-08 22:51:03 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 22:51:03 --> URI Class Initialized
DEBUG - 2016-12-08 22:51:03 --> Router Class Initialized
DEBUG - 2016-12-08 22:51:03 --> No URI present. Default controller set.
DEBUG - 2016-12-08 22:51:03 --> Output Class Initialized
DEBUG - 2016-12-08 22:51:05 --> Cache file has expired. File deleted
DEBUG - 2016-12-08 22:51:05 --> Security Class Initialized
DEBUG - 2016-12-08 22:51:05 --> Input Class Initialized
DEBUG - 2016-12-08 22:51:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 22:51:05 --> Language Class Initialized
DEBUG - 2016-12-08 22:51:08 --> Loader Class Initialized
DEBUG - 2016-12-08 22:51:08 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 22:51:08 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 22:51:08 --> Helper loaded: url_helper
DEBUG - 2016-12-08 22:51:08 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 22:51:08 --> Helper loaded: file_helper
DEBUG - 2016-12-08 22:51:08 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:51:09 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 22:51:09 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 22:51:09 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:51:09 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 22:51:09 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 22:51:09 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:51:09 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 22:51:09 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:51:09 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 22:51:09 --> Helper loaded: form_helper
DEBUG - 2016-12-08 22:51:09 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 22:51:09 --> Helper loaded: security_helper
DEBUG - 2016-12-08 22:51:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:51:09 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 22:51:09 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 22:51:09 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:51:09 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 22:51:09 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 22:51:09 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 22:51:09 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 22:51:09 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:51:09 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 22:51:10 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 22:51:10 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:51:10 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 22:51:10 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 22:51:10 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 22:51:10 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 22:51:11 --> Database Driver Class Initialized
DEBUG - 2016-12-08 22:51:13 --> Session Class Initialized
DEBUG - 2016-12-08 22:51:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 22:51:14 --> Helper loaded: string_helper
DEBUG - 2016-12-08 22:51:14 --> A session cookie was not found.
DEBUG - 2016-12-08 22:51:14 --> Session routines successfully run
DEBUG - 2016-12-08 22:51:14 --> Native_session Class Initialized
DEBUG - 2016-12-08 22:51:15 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 22:51:15 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:51:15 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:51:15 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 22:51:16 --> Controller Class Initialized
DEBUG - 2016-12-08 22:51:17 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 22:51:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 22:51:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 22:51:17 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:51:17 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:51:17 --> User Agent Class Initialized
DEBUG - 2016-12-08 22:51:18 --> Model Class Initialized
DEBUG - 2016-12-08 22:51:18 --> Model Class Initialized
DEBUG - 2016-12-08 22:51:18 --> Model Class Initialized
ERROR - 2016-12-08 22:51:27 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-12-08 22:51:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-12-08 22:51:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-12-08 22:51:27 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-08 22:51:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 22:51:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-08 22:51:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-08 22:51:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-08 22:51:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-12-08 22:51:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-12-08 22:51:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 22:51:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-08 22:51:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-08 22:51:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 22:51:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-08 22:51:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-08 22:51:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-08 22:51:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-12-08 22:51:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-12-08 22:51:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 22:51:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-08 22:51:28 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-12-08 22:51:28 --> Final output sent to browser
DEBUG - 2016-12-08 22:51:28 --> Total execution time: 24.8150
DEBUG - 2016-12-08 22:51:31 --> Config Class Initialized
DEBUG - 2016-12-08 22:51:31 --> Hooks Class Initialized
DEBUG - 2016-12-08 22:51:31 --> Utf8 Class Initialized
DEBUG - 2016-12-08 22:51:31 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 22:51:31 --> URI Class Initialized
DEBUG - 2016-12-08 22:51:31 --> Router Class Initialized
DEBUG - 2016-12-08 22:51:31 --> Output Class Initialized
DEBUG - 2016-12-08 22:51:32 --> Cache file has expired. File deleted
DEBUG - 2016-12-08 22:51:32 --> Security Class Initialized
DEBUG - 2016-12-08 22:51:32 --> Input Class Initialized
DEBUG - 2016-12-08 22:51:32 --> XSS Filtering completed
DEBUG - 2016-12-08 22:51:32 --> XSS Filtering completed
DEBUG - 2016-12-08 22:51:32 --> XSS Filtering completed
DEBUG - 2016-12-08 22:51:32 --> XSS Filtering completed
DEBUG - 2016-12-08 22:51:32 --> XSS Filtering completed
DEBUG - 2016-12-08 22:51:32 --> XSS Filtering completed
DEBUG - 2016-12-08 22:51:32 --> XSS Filtering completed
DEBUG - 2016-12-08 22:51:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 22:51:32 --> Language Class Initialized
DEBUG - 2016-12-08 22:51:32 --> Loader Class Initialized
DEBUG - 2016-12-08 22:51:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 22:51:32 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 22:51:32 --> Helper loaded: url_helper
DEBUG - 2016-12-08 22:51:32 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 22:51:32 --> Helper loaded: file_helper
DEBUG - 2016-12-08 22:51:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:51:32 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 22:51:32 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 22:51:32 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:51:32 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 22:51:32 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 22:51:32 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:51:32 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 22:51:32 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:51:32 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 22:51:32 --> Helper loaded: form_helper
DEBUG - 2016-12-08 22:51:32 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 22:51:32 --> Helper loaded: security_helper
DEBUG - 2016-12-08 22:51:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:51:32 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 22:51:32 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 22:51:32 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:51:32 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 22:51:32 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 22:51:32 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 22:51:32 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 22:51:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:51:32 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 22:51:32 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 22:51:32 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:51:32 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 22:51:32 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 22:51:32 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 22:51:32 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 22:51:32 --> Database Driver Class Initialized
DEBUG - 2016-12-08 22:51:32 --> Session Class Initialized
DEBUG - 2016-12-08 22:51:32 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 22:51:32 --> Helper loaded: string_helper
DEBUG - 2016-12-08 22:51:32 --> Session routines successfully run
DEBUG - 2016-12-08 22:51:32 --> Native_session Class Initialized
DEBUG - 2016-12-08 22:51:32 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 22:51:32 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:51:32 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:51:32 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 22:51:32 --> Controller Class Initialized
DEBUG - 2016-12-08 22:51:32 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 22:51:32 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 22:51:32 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 22:51:32 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:51:32 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:51:32 --> User Agent Class Initialized
DEBUG - 2016-12-08 22:51:32 --> Model Class Initialized
DEBUG - 2016-12-08 22:51:32 --> Model Class Initialized
DEBUG - 2016-12-08 22:51:32 --> Model Class Initialized
DEBUG - 2016-12-08 22:51:32 --> Model Class Initialized
DEBUG - 2016-12-08 22:51:32 --> Model Class Initialized
DEBUG - 2016-12-08 22:51:32 --> Model Class Initialized
DEBUG - 2016-12-08 22:51:32 --> Model Class Initialized
DEBUG - 2016-12-08 22:51:34 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-12-08 22:51:34 --> Final output sent to browser
DEBUG - 2016-12-08 22:51:34 --> Total execution time: 2.8494
DEBUG - 2016-12-08 22:54:19 --> Config Class Initialized
DEBUG - 2016-12-08 22:54:19 --> Hooks Class Initialized
DEBUG - 2016-12-08 22:54:19 --> Utf8 Class Initialized
DEBUG - 2016-12-08 22:54:19 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 22:54:19 --> URI Class Initialized
DEBUG - 2016-12-08 22:54:19 --> Router Class Initialized
DEBUG - 2016-12-08 22:54:20 --> Output Class Initialized
DEBUG - 2016-12-08 22:54:20 --> Security Class Initialized
DEBUG - 2016-12-08 22:54:20 --> Input Class Initialized
DEBUG - 2016-12-08 22:54:20 --> XSS Filtering completed
DEBUG - 2016-12-08 22:54:20 --> XSS Filtering completed
DEBUG - 2016-12-08 22:54:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 22:54:20 --> Language Class Initialized
DEBUG - 2016-12-08 22:54:20 --> Loader Class Initialized
DEBUG - 2016-12-08 22:54:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 22:54:20 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 22:54:20 --> Helper loaded: url_helper
DEBUG - 2016-12-08 22:54:20 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 22:54:20 --> Helper loaded: file_helper
DEBUG - 2016-12-08 22:54:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:54:20 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 22:54:20 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 22:54:20 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:54:20 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 22:54:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 22:54:20 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:54:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 22:54:20 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:54:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 22:54:20 --> Helper loaded: form_helper
DEBUG - 2016-12-08 22:54:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 22:54:20 --> Helper loaded: security_helper
DEBUG - 2016-12-08 22:54:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:54:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 22:54:20 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 22:54:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:54:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 22:54:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 22:54:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 22:54:20 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 22:54:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:54:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 22:54:20 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 22:54:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:54:20 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 22:54:20 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 22:54:20 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 22:54:20 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 22:54:20 --> Database Driver Class Initialized
DEBUG - 2016-12-08 22:54:20 --> Session Class Initialized
DEBUG - 2016-12-08 22:54:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 22:54:20 --> Helper loaded: string_helper
DEBUG - 2016-12-08 22:54:20 --> Session routines successfully run
DEBUG - 2016-12-08 22:54:20 --> Native_session Class Initialized
DEBUG - 2016-12-08 22:54:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 22:54:20 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:54:20 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:54:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 22:54:20 --> Controller Class Initialized
DEBUG - 2016-12-08 22:54:20 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 22:54:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 22:54:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 22:54:20 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:54:20 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:54:20 --> User Agent Class Initialized
DEBUG - 2016-12-08 22:54:20 --> Model Class Initialized
DEBUG - 2016-12-08 22:54:20 --> Model Class Initialized
DEBUG - 2016-12-08 22:54:20 --> Model Class Initialized
ERROR - 2016-12-08 22:54:20 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-12-08 22:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-12-08 22:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-08 22:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 22:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-08 22:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-08 22:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-08 22:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 22:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-08 22:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-08 22:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 22:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-08 22:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-08 22:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-08 22:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 22:54:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-08 22:54:20 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-12-08 22:54:20 --> Final output sent to browser
DEBUG - 2016-12-08 22:54:20 --> Total execution time: 0.2302
DEBUG - 2016-12-08 22:55:13 --> Config Class Initialized
DEBUG - 2016-12-08 22:55:13 --> Hooks Class Initialized
DEBUG - 2016-12-08 22:55:13 --> Utf8 Class Initialized
DEBUG - 2016-12-08 22:55:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 22:55:13 --> URI Class Initialized
DEBUG - 2016-12-08 22:55:13 --> Router Class Initialized
DEBUG - 2016-12-08 22:55:13 --> No URI present. Default controller set.
DEBUG - 2016-12-08 22:55:13 --> Output Class Initialized
DEBUG - 2016-12-08 22:55:13 --> Cache file has expired. File deleted
DEBUG - 2016-12-08 22:55:13 --> Security Class Initialized
DEBUG - 2016-12-08 22:55:13 --> Input Class Initialized
DEBUG - 2016-12-08 22:55:13 --> XSS Filtering completed
DEBUG - 2016-12-08 22:55:13 --> XSS Filtering completed
DEBUG - 2016-12-08 22:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 22:55:13 --> Language Class Initialized
DEBUG - 2016-12-08 22:55:13 --> Loader Class Initialized
DEBUG - 2016-12-08 22:55:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 22:55:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 22:55:13 --> Helper loaded: url_helper
DEBUG - 2016-12-08 22:55:13 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 22:55:13 --> Helper loaded: file_helper
DEBUG - 2016-12-08 22:55:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:55:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 22:55:13 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 22:55:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:55:13 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 22:55:13 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 22:55:13 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:55:13 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 22:55:13 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:55:13 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 22:55:13 --> Helper loaded: form_helper
DEBUG - 2016-12-08 22:55:13 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 22:55:13 --> Helper loaded: security_helper
DEBUG - 2016-12-08 22:55:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:55:13 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 22:55:13 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 22:55:13 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:55:13 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 22:55:13 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 22:55:13 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 22:55:13 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 22:55:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:55:13 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 22:55:13 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 22:55:13 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:55:13 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 22:55:13 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 22:55:13 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 22:55:13 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 22:55:13 --> Database Driver Class Initialized
DEBUG - 2016-12-08 22:55:13 --> Session Class Initialized
DEBUG - 2016-12-08 22:55:13 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 22:55:13 --> Helper loaded: string_helper
DEBUG - 2016-12-08 22:55:13 --> Session routines successfully run
DEBUG - 2016-12-08 22:55:13 --> Native_session Class Initialized
DEBUG - 2016-12-08 22:55:13 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 22:55:13 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:55:13 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:55:13 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 22:55:13 --> Controller Class Initialized
DEBUG - 2016-12-08 22:55:13 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 22:55:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 22:55:13 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 22:55:13 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:55:13 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:55:13 --> User Agent Class Initialized
DEBUG - 2016-12-08 22:55:13 --> Model Class Initialized
DEBUG - 2016-12-08 22:55:13 --> Model Class Initialized
DEBUG - 2016-12-08 22:55:13 --> Model Class Initialized
ERROR - 2016-12-08 22:55:13 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-12-08 22:55:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-12-08 22:55:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-12-08 22:55:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-08 22:55:13 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 22:55:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-08 22:55:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-08 22:55:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-08 22:55:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-12-08 22:55:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-12-08 22:55:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 22:55:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-08 22:55:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-08 22:55:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 22:55:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-08 22:55:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-08 22:55:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-08 22:55:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-12-08 22:55:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-12-08 22:55:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 22:55:14 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-08 22:55:14 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-12-08 22:55:14 --> Final output sent to browser
DEBUG - 2016-12-08 22:55:14 --> Total execution time: 0.2948
DEBUG - 2016-12-08 22:55:14 --> Config Class Initialized
DEBUG - 2016-12-08 22:55:14 --> Hooks Class Initialized
DEBUG - 2016-12-08 22:55:14 --> Utf8 Class Initialized
DEBUG - 2016-12-08 22:55:14 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 22:55:14 --> URI Class Initialized
DEBUG - 2016-12-08 22:55:14 --> Router Class Initialized
DEBUG - 2016-12-08 22:55:14 --> Output Class Initialized
DEBUG - 2016-12-08 22:55:14 --> Cache file has expired. File deleted
DEBUG - 2016-12-08 22:55:14 --> Security Class Initialized
DEBUG - 2016-12-08 22:55:14 --> Input Class Initialized
DEBUG - 2016-12-08 22:55:14 --> XSS Filtering completed
DEBUG - 2016-12-08 22:55:14 --> XSS Filtering completed
DEBUG - 2016-12-08 22:55:14 --> XSS Filtering completed
DEBUG - 2016-12-08 22:55:14 --> XSS Filtering completed
DEBUG - 2016-12-08 22:55:14 --> XSS Filtering completed
DEBUG - 2016-12-08 22:55:14 --> XSS Filtering completed
DEBUG - 2016-12-08 22:55:14 --> XSS Filtering completed
DEBUG - 2016-12-08 22:55:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 22:55:14 --> Language Class Initialized
DEBUG - 2016-12-08 22:55:14 --> Loader Class Initialized
DEBUG - 2016-12-08 22:55:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 22:55:14 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 22:55:14 --> Helper loaded: url_helper
DEBUG - 2016-12-08 22:55:14 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 22:55:14 --> Helper loaded: file_helper
DEBUG - 2016-12-08 22:55:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:55:14 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 22:55:14 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 22:55:14 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:55:14 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 22:55:14 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 22:55:14 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:55:14 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 22:55:14 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:55:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 22:55:14 --> Helper loaded: form_helper
DEBUG - 2016-12-08 22:55:14 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 22:55:14 --> Helper loaded: security_helper
DEBUG - 2016-12-08 22:55:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:55:14 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 22:55:14 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 22:55:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:55:14 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 22:55:14 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 22:55:14 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 22:55:14 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 22:55:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:55:14 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 22:55:14 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 22:55:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:55:14 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 22:55:14 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 22:55:14 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 22:55:14 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 22:55:14 --> Database Driver Class Initialized
DEBUG - 2016-12-08 22:55:14 --> Session Class Initialized
DEBUG - 2016-12-08 22:55:14 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 22:55:14 --> Helper loaded: string_helper
DEBUG - 2016-12-08 22:55:14 --> Session routines successfully run
DEBUG - 2016-12-08 22:55:14 --> Native_session Class Initialized
DEBUG - 2016-12-08 22:55:14 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 22:55:14 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:55:14 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:55:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 22:55:14 --> Controller Class Initialized
DEBUG - 2016-12-08 22:55:14 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 22:55:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 22:55:14 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 22:55:14 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:55:14 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:55:14 --> User Agent Class Initialized
DEBUG - 2016-12-08 22:55:14 --> Model Class Initialized
DEBUG - 2016-12-08 22:55:14 --> Model Class Initialized
DEBUG - 2016-12-08 22:55:14 --> Model Class Initialized
DEBUG - 2016-12-08 22:55:14 --> Model Class Initialized
DEBUG - 2016-12-08 22:55:14 --> Model Class Initialized
DEBUG - 2016-12-08 22:55:14 --> Model Class Initialized
DEBUG - 2016-12-08 22:55:14 --> Model Class Initialized
DEBUG - 2016-12-08 22:55:14 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-12-08 22:55:14 --> Final output sent to browser
DEBUG - 2016-12-08 22:55:14 --> Total execution time: 0.3001
DEBUG - 2016-12-08 22:55:17 --> Config Class Initialized
DEBUG - 2016-12-08 22:55:17 --> Hooks Class Initialized
DEBUG - 2016-12-08 22:55:17 --> Utf8 Class Initialized
DEBUG - 2016-12-08 22:55:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 22:55:17 --> URI Class Initialized
DEBUG - 2016-12-08 22:55:17 --> Router Class Initialized
DEBUG - 2016-12-08 22:55:17 --> Output Class Initialized
DEBUG - 2016-12-08 22:55:17 --> Cache file has expired. File deleted
DEBUG - 2016-12-08 22:55:17 --> Security Class Initialized
DEBUG - 2016-12-08 22:55:17 --> Input Class Initialized
DEBUG - 2016-12-08 22:55:17 --> XSS Filtering completed
DEBUG - 2016-12-08 22:55:17 --> XSS Filtering completed
DEBUG - 2016-12-08 22:55:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 22:55:17 --> Language Class Initialized
DEBUG - 2016-12-08 22:55:17 --> Loader Class Initialized
DEBUG - 2016-12-08 22:55:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 22:55:17 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 22:55:17 --> Helper loaded: url_helper
DEBUG - 2016-12-08 22:55:17 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 22:55:17 --> Helper loaded: file_helper
DEBUG - 2016-12-08 22:55:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:55:17 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 22:55:17 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 22:55:17 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:55:17 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 22:55:17 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 22:55:17 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:55:17 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 22:55:17 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:55:17 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 22:55:17 --> Helper loaded: form_helper
DEBUG - 2016-12-08 22:55:17 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 22:55:17 --> Helper loaded: security_helper
DEBUG - 2016-12-08 22:55:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:55:17 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 22:55:17 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 22:55:17 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:55:17 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 22:55:17 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 22:55:17 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 22:55:17 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 22:55:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:55:17 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 22:55:17 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 22:55:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:55:17 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 22:55:17 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 22:55:17 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 22:55:17 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 22:55:17 --> Database Driver Class Initialized
DEBUG - 2016-12-08 22:55:17 --> Session Class Initialized
DEBUG - 2016-12-08 22:55:17 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 22:55:17 --> Helper loaded: string_helper
DEBUG - 2016-12-08 22:55:17 --> Session routines successfully run
DEBUG - 2016-12-08 22:55:17 --> Native_session Class Initialized
DEBUG - 2016-12-08 22:55:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 22:55:17 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:55:17 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:55:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 22:55:17 --> Controller Class Initialized
DEBUG - 2016-12-08 22:55:17 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 22:55:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 22:55:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 22:55:17 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:55:17 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:55:17 --> User Agent Class Initialized
DEBUG - 2016-12-08 22:55:17 --> Model Class Initialized
DEBUG - 2016-12-08 22:55:17 --> Model Class Initialized
DEBUG - 2016-12-08 22:55:17 --> Model Class Initialized
DEBUG - 2016-12-08 22:55:17 --> Model Class Initialized
DEBUG - 2016-12-08 22:55:17 --> Model Class Initialized
DEBUG - 2016-12-08 22:55:17 --> Model Class Initialized
DEBUG - 2016-12-08 22:55:17 --> Model Class Initialized
DEBUG - 2016-12-08 22:55:17 --> Model Class Initialized
DEBUG - 2016-12-08 22:55:17 --> Model Class Initialized
ERROR - 2016-12-08 22:55:17 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-12-08 22:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-12-08 22:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-08 22:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 22:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-08 22:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-08 22:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-08 22:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 22:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-08 22:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-08 22:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 22:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-08 22:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-08 22:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-08 22:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 22:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-08 22:55:17 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/73f5e075ee35be5f6c1c98a57562112a
DEBUG - 2016-12-08 22:55:17 --> Final output sent to browser
DEBUG - 2016-12-08 22:55:17 --> Total execution time: 0.8016
DEBUG - 2016-12-08 22:56:15 --> Config Class Initialized
DEBUG - 2016-12-08 22:56:15 --> Hooks Class Initialized
DEBUG - 2016-12-08 22:56:15 --> Utf8 Class Initialized
DEBUG - 2016-12-08 22:56:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 22:56:15 --> URI Class Initialized
DEBUG - 2016-12-08 22:56:15 --> Router Class Initialized
DEBUG - 2016-12-08 22:56:15 --> Output Class Initialized
DEBUG - 2016-12-08 22:56:15 --> Cache file has expired. File deleted
DEBUG - 2016-12-08 22:56:15 --> Security Class Initialized
DEBUG - 2016-12-08 22:56:15 --> Input Class Initialized
DEBUG - 2016-12-08 22:56:15 --> XSS Filtering completed
DEBUG - 2016-12-08 22:56:15 --> XSS Filtering completed
DEBUG - 2016-12-08 22:56:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 22:56:16 --> Language Class Initialized
DEBUG - 2016-12-08 22:56:16 --> Loader Class Initialized
DEBUG - 2016-12-08 22:56:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 22:56:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 22:56:16 --> Helper loaded: url_helper
DEBUG - 2016-12-08 22:56:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 22:56:16 --> Helper loaded: file_helper
DEBUG - 2016-12-08 22:56:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:56:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 22:56:16 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 22:56:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:56:16 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 22:56:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 22:56:16 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:56:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 22:56:16 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:56:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 22:56:16 --> Helper loaded: form_helper
DEBUG - 2016-12-08 22:56:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 22:56:16 --> Helper loaded: security_helper
DEBUG - 2016-12-08 22:56:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:56:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 22:56:16 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 22:56:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:56:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 22:56:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 22:56:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 22:56:16 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 22:56:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:56:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 22:56:16 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 22:56:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:56:16 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 22:56:16 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 22:56:16 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 22:56:16 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 22:56:16 --> Database Driver Class Initialized
DEBUG - 2016-12-08 22:56:16 --> Session Class Initialized
DEBUG - 2016-12-08 22:56:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 22:56:16 --> Helper loaded: string_helper
DEBUG - 2016-12-08 22:56:16 --> Session routines successfully run
DEBUG - 2016-12-08 22:56:16 --> Native_session Class Initialized
DEBUG - 2016-12-08 22:56:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 22:56:16 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:56:16 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:56:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 22:56:16 --> Controller Class Initialized
DEBUG - 2016-12-08 22:56:16 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 22:56:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 22:56:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 22:56:16 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:56:16 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:56:16 --> User Agent Class Initialized
DEBUG - 2016-12-08 22:56:16 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:16 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:16 --> Model Class Initialized
ERROR - 2016-12-08 22:56:16 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-12-08 22:56:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-12-08 22:56:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-08 22:56:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 22:56:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-08 22:56:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-08 22:56:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-08 22:56:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 22:56:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-08 22:56:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-08 22:56:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 22:56:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-08 22:56:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-08 22:56:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-08 22:56:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 22:56:16 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-08 22:56:16 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-12-08 22:56:16 --> Final output sent to browser
DEBUG - 2016-12-08 22:56:16 --> Total execution time: 0.3300
DEBUG - 2016-12-08 22:56:18 --> Config Class Initialized
DEBUG - 2016-12-08 22:56:18 --> Hooks Class Initialized
DEBUG - 2016-12-08 22:56:18 --> Utf8 Class Initialized
DEBUG - 2016-12-08 22:56:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 22:56:18 --> URI Class Initialized
DEBUG - 2016-12-08 22:56:18 --> Router Class Initialized
DEBUG - 2016-12-08 22:56:18 --> Output Class Initialized
DEBUG - 2016-12-08 22:56:18 --> Cache file has expired. File deleted
DEBUG - 2016-12-08 22:56:18 --> Security Class Initialized
DEBUG - 2016-12-08 22:56:18 --> Input Class Initialized
DEBUG - 2016-12-08 22:56:18 --> XSS Filtering completed
DEBUG - 2016-12-08 22:56:18 --> XSS Filtering completed
DEBUG - 2016-12-08 22:56:18 --> XSS Filtering completed
DEBUG - 2016-12-08 22:56:18 --> XSS Filtering completed
DEBUG - 2016-12-08 22:56:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 22:56:18 --> Language Class Initialized
DEBUG - 2016-12-08 22:56:18 --> Loader Class Initialized
DEBUG - 2016-12-08 22:56:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 22:56:18 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 22:56:18 --> Helper loaded: url_helper
DEBUG - 2016-12-08 22:56:18 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 22:56:18 --> Helper loaded: file_helper
DEBUG - 2016-12-08 22:56:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:56:18 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 22:56:18 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 22:56:18 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:56:18 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 22:56:18 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 22:56:18 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:56:18 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 22:56:18 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:56:18 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 22:56:18 --> Helper loaded: form_helper
DEBUG - 2016-12-08 22:56:18 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 22:56:18 --> Helper loaded: security_helper
DEBUG - 2016-12-08 22:56:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:56:18 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 22:56:18 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 22:56:18 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:56:18 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 22:56:18 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 22:56:18 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 22:56:18 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 22:56:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:56:18 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 22:56:18 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 22:56:18 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:56:18 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 22:56:18 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 22:56:18 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 22:56:18 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 22:56:18 --> Database Driver Class Initialized
DEBUG - 2016-12-08 22:56:18 --> Session Class Initialized
DEBUG - 2016-12-08 22:56:18 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 22:56:18 --> Helper loaded: string_helper
DEBUG - 2016-12-08 22:56:18 --> Session routines successfully run
DEBUG - 2016-12-08 22:56:18 --> Native_session Class Initialized
DEBUG - 2016-12-08 22:56:18 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 22:56:18 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:56:18 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:56:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 22:56:18 --> Controller Class Initialized
DEBUG - 2016-12-08 22:56:18 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 22:56:18 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 22:56:18 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 22:56:18 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:56:18 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:56:18 --> User Agent Class Initialized
DEBUG - 2016-12-08 22:56:18 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:18 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:18 --> Model Class Initialized
ERROR - 2016-12-08 22:56:18 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-12-08 22:56:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-12-08 22:56:18 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:56:18 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 22:56:18 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-12-08 22:56:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/cfpns/login.php
DEBUG - 2016-12-08 22:56:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-08 22:56:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 22:56:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-08 22:56:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-08 22:56:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-08 22:56:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 22:56:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-08 22:56:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-08 22:56:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 22:56:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-08 22:56:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-08 22:56:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-08 22:56:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 22:56:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-08 22:56:19 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/1c19d368ad873df73996013e55c5e525
DEBUG - 2016-12-08 22:56:19 --> Final output sent to browser
DEBUG - 2016-12-08 22:56:19 --> Total execution time: 0.9162
DEBUG - 2016-12-08 22:56:27 --> Config Class Initialized
DEBUG - 2016-12-08 22:56:27 --> Hooks Class Initialized
DEBUG - 2016-12-08 22:56:27 --> Utf8 Class Initialized
DEBUG - 2016-12-08 22:56:27 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 22:56:27 --> URI Class Initialized
DEBUG - 2016-12-08 22:56:27 --> Router Class Initialized
DEBUG - 2016-12-08 22:56:27 --> Output Class Initialized
DEBUG - 2016-12-08 22:56:27 --> Cache file has expired. File deleted
DEBUG - 2016-12-08 22:56:27 --> Security Class Initialized
DEBUG - 2016-12-08 22:56:27 --> Input Class Initialized
DEBUG - 2016-12-08 22:56:27 --> XSS Filtering completed
DEBUG - 2016-12-08 22:56:27 --> XSS Filtering completed
DEBUG - 2016-12-08 22:56:27 --> XSS Filtering completed
DEBUG - 2016-12-08 22:56:27 --> XSS Filtering completed
DEBUG - 2016-12-08 22:56:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 22:56:27 --> Language Class Initialized
DEBUG - 2016-12-08 22:56:27 --> Loader Class Initialized
DEBUG - 2016-12-08 22:56:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 22:56:27 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 22:56:27 --> Helper loaded: url_helper
DEBUG - 2016-12-08 22:56:27 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 22:56:27 --> Helper loaded: file_helper
DEBUG - 2016-12-08 22:56:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:56:27 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 22:56:27 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 22:56:27 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:56:27 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 22:56:27 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 22:56:27 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:56:27 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 22:56:27 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:56:27 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 22:56:27 --> Helper loaded: form_helper
DEBUG - 2016-12-08 22:56:27 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 22:56:27 --> Helper loaded: security_helper
DEBUG - 2016-12-08 22:56:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:56:27 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 22:56:27 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 22:56:27 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:56:27 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 22:56:27 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 22:56:27 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 22:56:27 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 22:56:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:56:27 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 22:56:27 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 22:56:27 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:56:27 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 22:56:27 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 22:56:27 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 22:56:27 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 22:56:27 --> Database Driver Class Initialized
DEBUG - 2016-12-08 22:56:27 --> Session Class Initialized
DEBUG - 2016-12-08 22:56:27 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 22:56:27 --> Helper loaded: string_helper
DEBUG - 2016-12-08 22:56:27 --> Session routines successfully run
DEBUG - 2016-12-08 22:56:27 --> Native_session Class Initialized
DEBUG - 2016-12-08 22:56:27 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 22:56:27 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:56:27 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:56:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 22:56:27 --> Controller Class Initialized
DEBUG - 2016-12-08 22:56:27 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 22:56:27 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 22:56:27 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 22:56:27 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:56:27 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:56:27 --> User Agent Class Initialized
DEBUG - 2016-12-08 22:56:27 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:27 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:27 --> Model Class Initialized
ERROR - 2016-12-08 22:56:27 --> Hak Akses modul/kontroller 'cfpns' untuk role 'unkown' belum di set.
DEBUG - 2016-12-08 22:56:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-12-08 22:56:27 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:56:27 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 22:56:27 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-12-08 22:56:28 --> Config Class Initialized
DEBUG - 2016-12-08 22:56:28 --> Hooks Class Initialized
DEBUG - 2016-12-08 22:56:28 --> Utf8 Class Initialized
DEBUG - 2016-12-08 22:56:28 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 22:56:28 --> URI Class Initialized
DEBUG - 2016-12-08 22:56:28 --> Router Class Initialized
DEBUG - 2016-12-08 22:56:28 --> Output Class Initialized
DEBUG - 2016-12-08 22:56:28 --> Cache file has expired. File deleted
DEBUG - 2016-12-08 22:56:28 --> Security Class Initialized
DEBUG - 2016-12-08 22:56:28 --> Input Class Initialized
DEBUG - 2016-12-08 22:56:28 --> XSS Filtering completed
DEBUG - 2016-12-08 22:56:28 --> XSS Filtering completed
DEBUG - 2016-12-08 22:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 22:56:28 --> Language Class Initialized
DEBUG - 2016-12-08 22:56:28 --> Loader Class Initialized
DEBUG - 2016-12-08 22:56:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 22:56:28 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 22:56:28 --> Helper loaded: url_helper
DEBUG - 2016-12-08 22:56:28 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 22:56:28 --> Helper loaded: file_helper
DEBUG - 2016-12-08 22:56:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:56:28 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 22:56:28 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 22:56:28 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:56:28 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 22:56:28 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 22:56:28 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:56:28 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 22:56:28 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:56:28 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 22:56:28 --> Helper loaded: form_helper
DEBUG - 2016-12-08 22:56:28 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 22:56:28 --> Helper loaded: security_helper
DEBUG - 2016-12-08 22:56:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:56:28 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 22:56:28 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 22:56:28 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:56:28 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 22:56:28 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 22:56:28 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 22:56:28 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 22:56:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:56:28 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 22:56:28 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 22:56:28 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:56:28 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 22:56:28 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 22:56:28 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 22:56:28 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 22:56:28 --> Database Driver Class Initialized
DEBUG - 2016-12-08 22:56:28 --> Session Class Initialized
DEBUG - 2016-12-08 22:56:28 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 22:56:28 --> Helper loaded: string_helper
DEBUG - 2016-12-08 22:56:28 --> Session routines successfully run
DEBUG - 2016-12-08 22:56:28 --> Native_session Class Initialized
DEBUG - 2016-12-08 22:56:28 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 22:56:28 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:56:28 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:56:28 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 22:56:28 --> Controller Class Initialized
DEBUG - 2016-12-08 22:56:28 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 22:56:28 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 22:56:28 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 22:56:28 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:56:28 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:56:28 --> User Agent Class Initialized
DEBUG - 2016-12-08 22:56:28 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:28 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:28 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:28 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:28 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:28 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:28 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:28 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:28 --> Model Class Initialized
ERROR - 2016-12-08 22:56:28 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'administrator' belum di set.
DEBUG - 2016-12-08 22:56:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-12-08 22:56:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-08 22:56:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 22:56:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-08 22:56:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-08 22:56:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-08 22:56:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 22:56:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-08 22:56:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-08 22:56:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 22:56:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-08 22:56:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-08 22:56:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-08 22:56:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 22:56:28 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-08 22:56:28 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/73f5e075ee35be5f6c1c98a57562112a
DEBUG - 2016-12-08 22:56:28 --> Final output sent to browser
DEBUG - 2016-12-08 22:56:28 --> Total execution time: 0.4164
DEBUG - 2016-12-08 22:56:56 --> Config Class Initialized
DEBUG - 2016-12-08 22:56:56 --> Hooks Class Initialized
DEBUG - 2016-12-08 22:56:56 --> Utf8 Class Initialized
DEBUG - 2016-12-08 22:56:56 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 22:56:56 --> URI Class Initialized
DEBUG - 2016-12-08 22:56:56 --> Router Class Initialized
DEBUG - 2016-12-08 22:56:56 --> Output Class Initialized
DEBUG - 2016-12-08 22:56:56 --> Cache file has expired. File deleted
DEBUG - 2016-12-08 22:56:56 --> Security Class Initialized
DEBUG - 2016-12-08 22:56:56 --> Input Class Initialized
DEBUG - 2016-12-08 22:56:56 --> XSS Filtering completed
DEBUG - 2016-12-08 22:56:56 --> XSS Filtering completed
DEBUG - 2016-12-08 22:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 22:56:56 --> Language Class Initialized
DEBUG - 2016-12-08 22:56:56 --> Loader Class Initialized
DEBUG - 2016-12-08 22:56:56 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 22:56:56 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 22:56:56 --> Helper loaded: url_helper
DEBUG - 2016-12-08 22:56:56 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 22:56:56 --> Helper loaded: file_helper
DEBUG - 2016-12-08 22:56:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:56:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 22:56:57 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 22:56:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:56:57 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 22:56:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 22:56:57 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:56:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 22:56:57 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:56:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 22:56:57 --> Helper loaded: form_helper
DEBUG - 2016-12-08 22:56:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 22:56:57 --> Helper loaded: security_helper
DEBUG - 2016-12-08 22:56:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:56:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 22:56:57 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 22:56:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:56:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 22:56:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 22:56:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 22:56:57 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 22:56:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:56:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 22:56:57 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 22:56:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:56:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 22:56:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 22:56:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 22:56:57 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 22:56:57 --> Database Driver Class Initialized
DEBUG - 2016-12-08 22:56:57 --> Session Class Initialized
DEBUG - 2016-12-08 22:56:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 22:56:57 --> Helper loaded: string_helper
DEBUG - 2016-12-08 22:56:57 --> Session routines successfully run
DEBUG - 2016-12-08 22:56:57 --> Native_session Class Initialized
DEBUG - 2016-12-08 22:56:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 22:56:57 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:56:57 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:56:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 22:56:57 --> Controller Class Initialized
DEBUG - 2016-12-08 22:56:57 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 22:56:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 22:56:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 22:56:57 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:56:57 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:56:57 --> User Agent Class Initialized
DEBUG - 2016-12-08 22:56:57 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:57 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:57 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:57 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:57 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:57 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:57 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:57 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:57 --> Model Class Initialized
ERROR - 2016-12-08 22:56:57 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'administrator' belum di set.
DEBUG - 2016-12-08 22:56:57 --> Model Class Initialized
ERROR - 2016-12-08 22:56:57 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 58
ERROR - 2016-12-08 22:56:57 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 61
ERROR - 2016-12-08 22:56:57 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 64
ERROR - 2016-12-08 22:56:57 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 64
DEBUG - 2016-12-08 22:56:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/daftar.php
DEBUG - 2016-12-08 22:56:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-08 22:56:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 22:56:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-08 22:56:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-08 22:56:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-08 22:56:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/js/daftar_mandiri_js.php
DEBUG - 2016-12-08 22:56:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/js/daftar_js.php
DEBUG - 2016-12-08 22:56:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 22:56:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-08 22:56:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-08 22:56:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 22:56:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-08 22:56:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-08 22:56:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-08 22:56:57 --> Config Class Initialized
DEBUG - 2016-12-08 22:56:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/js/daftar_mandiri_js.php
DEBUG - 2016-12-08 22:56:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/js/daftar_js.php
DEBUG - 2016-12-08 22:56:57 --> Hooks Class Initialized
DEBUG - 2016-12-08 22:56:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 22:56:57 --> Utf8 Class Initialized
DEBUG - 2016-12-08 22:56:57 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 22:56:57 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-08 22:56:57 --> URI Class Initialized
DEBUG - 2016-12-08 22:56:57 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/82e431e4112c3e89eb7c75a74b999d31
DEBUG - 2016-12-08 22:56:57 --> Final output sent to browser
DEBUG - 2016-12-08 22:56:57 --> Router Class Initialized
DEBUG - 2016-12-08 22:56:57 --> Total execution time: 0.7238
DEBUG - 2016-12-08 22:56:57 --> No URI present. Default controller set.
DEBUG - 2016-12-08 22:56:57 --> Output Class Initialized
DEBUG - 2016-12-08 22:56:57 --> Cache file has expired. File deleted
DEBUG - 2016-12-08 22:56:57 --> Security Class Initialized
DEBUG - 2016-12-08 22:56:57 --> Input Class Initialized
DEBUG - 2016-12-08 22:56:57 --> XSS Filtering completed
DEBUG - 2016-12-08 22:56:57 --> XSS Filtering completed
DEBUG - 2016-12-08 22:56:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 22:56:57 --> Language Class Initialized
DEBUG - 2016-12-08 22:56:57 --> Loader Class Initialized
DEBUG - 2016-12-08 22:56:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 22:56:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 22:56:57 --> Helper loaded: url_helper
DEBUG - 2016-12-08 22:56:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 22:56:57 --> Helper loaded: file_helper
DEBUG - 2016-12-08 22:56:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:56:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 22:56:58 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 22:56:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:56:58 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 22:56:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 22:56:58 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:56:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 22:56:58 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:56:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 22:56:58 --> Helper loaded: form_helper
DEBUG - 2016-12-08 22:56:58 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 22:56:58 --> Helper loaded: security_helper
DEBUG - 2016-12-08 22:56:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:56:58 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 22:56:58 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 22:56:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:56:58 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 22:56:58 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 22:56:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 22:56:58 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 22:56:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:56:58 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 22:56:58 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 22:56:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:56:58 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 22:56:58 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 22:56:58 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 22:56:58 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 22:56:58 --> Database Driver Class Initialized
DEBUG - 2016-12-08 22:56:58 --> Session Class Initialized
DEBUG - 2016-12-08 22:56:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 22:56:58 --> Helper loaded: string_helper
DEBUG - 2016-12-08 22:56:58 --> Session routines successfully run
DEBUG - 2016-12-08 22:56:58 --> Native_session Class Initialized
DEBUG - 2016-12-08 22:56:58 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 22:56:58 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:56:58 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:56:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 22:56:58 --> Controller Class Initialized
DEBUG - 2016-12-08 22:56:58 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 22:56:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 22:56:58 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 22:56:58 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:56:58 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:56:58 --> User Agent Class Initialized
DEBUG - 2016-12-08 22:56:58 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:58 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:58 --> Model Class Initialized
ERROR - 2016-12-08 22:56:58 --> Hak Akses modul/kontroller 'home' untuk role 'administrator' belum di set.
DEBUG - 2016-12-08 22:56:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-12-08 22:56:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-12-08 22:56:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-08 22:56:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 22:56:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-08 22:56:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-08 22:56:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-08 22:56:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-12-08 22:56:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-12-08 22:56:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 22:56:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-08 22:56:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-08 22:56:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 22:56:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-08 22:56:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-08 22:56:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-08 22:56:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-12-08 22:56:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-12-08 22:56:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 22:56:58 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-08 22:56:58 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-12-08 22:56:58 --> Final output sent to browser
DEBUG - 2016-12-08 22:56:58 --> Total execution time: 0.4669
DEBUG - 2016-12-08 22:56:58 --> Config Class Initialized
DEBUG - 2016-12-08 22:56:58 --> Hooks Class Initialized
DEBUG - 2016-12-08 22:56:58 --> Utf8 Class Initialized
DEBUG - 2016-12-08 22:56:58 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 22:56:58 --> URI Class Initialized
DEBUG - 2016-12-08 22:56:58 --> Router Class Initialized
DEBUG - 2016-12-08 22:56:58 --> Output Class Initialized
DEBUG - 2016-12-08 22:56:58 --> Cache file has expired. File deleted
DEBUG - 2016-12-08 22:56:58 --> Security Class Initialized
DEBUG - 2016-12-08 22:56:58 --> Input Class Initialized
DEBUG - 2016-12-08 22:56:58 --> XSS Filtering completed
DEBUG - 2016-12-08 22:56:58 --> XSS Filtering completed
DEBUG - 2016-12-08 22:56:58 --> XSS Filtering completed
DEBUG - 2016-12-08 22:56:58 --> XSS Filtering completed
DEBUG - 2016-12-08 22:56:58 --> XSS Filtering completed
DEBUG - 2016-12-08 22:56:58 --> XSS Filtering completed
DEBUG - 2016-12-08 22:56:58 --> XSS Filtering completed
DEBUG - 2016-12-08 22:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 22:56:58 --> Language Class Initialized
DEBUG - 2016-12-08 22:56:58 --> Loader Class Initialized
DEBUG - 2016-12-08 22:56:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 22:56:58 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 22:56:58 --> Helper loaded: url_helper
DEBUG - 2016-12-08 22:56:58 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 22:56:58 --> Helper loaded: file_helper
DEBUG - 2016-12-08 22:56:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:56:58 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 22:56:58 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 22:56:58 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:56:58 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 22:56:58 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 22:56:58 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:56:58 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 22:56:58 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:56:58 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 22:56:58 --> Helper loaded: form_helper
DEBUG - 2016-12-08 22:56:58 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 22:56:58 --> Helper loaded: security_helper
DEBUG - 2016-12-08 22:56:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:56:58 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 22:56:58 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 22:56:58 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:56:58 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 22:56:58 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 22:56:58 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 22:56:58 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 22:56:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:56:58 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 22:56:58 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 22:56:58 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:56:58 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 22:56:58 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 22:56:58 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 22:56:58 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 22:56:58 --> Database Driver Class Initialized
DEBUG - 2016-12-08 22:56:58 --> Session Class Initialized
DEBUG - 2016-12-08 22:56:58 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 22:56:58 --> Helper loaded: string_helper
DEBUG - 2016-12-08 22:56:58 --> Session routines successfully run
DEBUG - 2016-12-08 22:56:58 --> Native_session Class Initialized
DEBUG - 2016-12-08 22:56:58 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 22:56:58 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:56:58 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:56:58 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 22:56:58 --> Controller Class Initialized
DEBUG - 2016-12-08 22:56:58 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 22:56:58 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 22:56:58 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 22:56:58 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:56:58 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:56:58 --> User Agent Class Initialized
DEBUG - 2016-12-08 22:56:58 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:58 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:58 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:59 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:59 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:59 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:59 --> Model Class Initialized
DEBUG - 2016-12-08 22:56:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-12-08 22:56:59 --> Final output sent to browser
DEBUG - 2016-12-08 22:56:59 --> Total execution time: 0.4899
DEBUG - 2016-12-08 22:58:29 --> Config Class Initialized
DEBUG - 2016-12-08 22:58:29 --> Hooks Class Initialized
DEBUG - 2016-12-08 22:58:29 --> Utf8 Class Initialized
DEBUG - 2016-12-08 22:58:29 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 22:58:29 --> URI Class Initialized
DEBUG - 2016-12-08 22:58:29 --> Router Class Initialized
DEBUG - 2016-12-08 22:58:29 --> Output Class Initialized
DEBUG - 2016-12-08 22:58:29 --> Cache file has expired. File deleted
DEBUG - 2016-12-08 22:58:29 --> Security Class Initialized
DEBUG - 2016-12-08 22:58:29 --> Input Class Initialized
DEBUG - 2016-12-08 22:58:29 --> XSS Filtering completed
DEBUG - 2016-12-08 22:58:29 --> XSS Filtering completed
DEBUG - 2016-12-08 22:58:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 22:58:29 --> Language Class Initialized
DEBUG - 2016-12-08 22:58:29 --> Loader Class Initialized
DEBUG - 2016-12-08 22:58:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 22:58:29 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 22:58:29 --> Helper loaded: url_helper
DEBUG - 2016-12-08 22:58:29 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 22:58:29 --> Helper loaded: file_helper
DEBUG - 2016-12-08 22:58:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:58:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 22:58:29 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 22:58:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:58:29 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 22:58:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 22:58:29 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:58:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 22:58:30 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:58:30 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 22:58:30 --> Helper loaded: form_helper
DEBUG - 2016-12-08 22:58:30 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 22:58:30 --> Helper loaded: security_helper
DEBUG - 2016-12-08 22:58:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:58:30 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 22:58:30 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 22:58:30 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:58:30 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 22:58:30 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 22:58:30 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 22:58:30 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 22:58:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:58:30 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 22:58:30 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 22:58:30 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:58:30 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 22:58:30 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 22:58:30 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 22:58:30 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 22:58:30 --> Database Driver Class Initialized
DEBUG - 2016-12-08 22:58:30 --> Session Class Initialized
DEBUG - 2016-12-08 22:58:30 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 22:58:30 --> Helper loaded: string_helper
DEBUG - 2016-12-08 22:58:30 --> Session routines successfully run
DEBUG - 2016-12-08 22:58:30 --> Native_session Class Initialized
DEBUG - 2016-12-08 22:58:30 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 22:58:30 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:58:30 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:58:30 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 22:58:30 --> Controller Class Initialized
DEBUG - 2016-12-08 22:58:30 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 22:58:30 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 22:58:30 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 22:58:30 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:58:30 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:58:30 --> User Agent Class Initialized
DEBUG - 2016-12-08 22:58:30 --> Model Class Initialized
DEBUG - 2016-12-08 22:58:30 --> Model Class Initialized
DEBUG - 2016-12-08 22:58:30 --> Model Class Initialized
DEBUG - 2016-12-08 22:58:30 --> Model Class Initialized
DEBUG - 2016-12-08 22:58:30 --> Model Class Initialized
DEBUG - 2016-12-08 22:58:30 --> Model Class Initialized
DEBUG - 2016-12-08 22:58:30 --> Model Class Initialized
DEBUG - 2016-12-08 22:58:30 --> Model Class Initialized
DEBUG - 2016-12-08 22:58:30 --> Model Class Initialized
ERROR - 2016-12-08 22:58:30 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'administrator' belum di set.
DEBUG - 2016-12-08 22:58:30 --> Model Class Initialized
DEBUG - 2016-12-08 22:58:38 --> Config Class Initialized
DEBUG - 2016-12-08 22:58:38 --> Hooks Class Initialized
DEBUG - 2016-12-08 22:58:38 --> Utf8 Class Initialized
DEBUG - 2016-12-08 22:58:38 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 22:58:38 --> URI Class Initialized
DEBUG - 2016-12-08 22:58:38 --> Router Class Initialized
DEBUG - 2016-12-08 22:58:38 --> Output Class Initialized
DEBUG - 2016-12-08 22:58:38 --> Security Class Initialized
DEBUG - 2016-12-08 22:58:38 --> Input Class Initialized
DEBUG - 2016-12-08 22:58:38 --> XSS Filtering completed
DEBUG - 2016-12-08 22:58:38 --> XSS Filtering completed
DEBUG - 2016-12-08 22:58:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 22:58:38 --> Language Class Initialized
DEBUG - 2016-12-08 22:58:38 --> Loader Class Initialized
DEBUG - 2016-12-08 22:58:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 22:58:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 22:58:38 --> Helper loaded: url_helper
DEBUG - 2016-12-08 22:58:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 22:58:38 --> Helper loaded: file_helper
DEBUG - 2016-12-08 22:58:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:58:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 22:58:38 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 22:58:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:58:38 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 22:58:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 22:58:38 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:58:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 22:58:38 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:58:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 22:58:38 --> Helper loaded: form_helper
DEBUG - 2016-12-08 22:58:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 22:58:38 --> Helper loaded: security_helper
DEBUG - 2016-12-08 22:58:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:58:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 22:58:38 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 22:58:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:58:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 22:58:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 22:58:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 22:58:38 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 22:58:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:58:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 22:58:38 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 22:58:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:58:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 22:58:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 22:58:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 22:58:38 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 22:58:38 --> Database Driver Class Initialized
DEBUG - 2016-12-08 22:58:38 --> Session Class Initialized
DEBUG - 2016-12-08 22:58:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 22:58:38 --> Helper loaded: string_helper
DEBUG - 2016-12-08 22:58:38 --> Session routines successfully run
DEBUG - 2016-12-08 22:58:38 --> Native_session Class Initialized
DEBUG - 2016-12-08 22:58:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 22:58:38 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:58:38 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:58:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 22:58:38 --> Controller Class Initialized
DEBUG - 2016-12-08 22:58:38 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 22:58:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 22:58:38 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 22:58:38 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:58:38 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:58:38 --> User Agent Class Initialized
DEBUG - 2016-12-08 22:58:38 --> Model Class Initialized
DEBUG - 2016-12-08 22:58:39 --> Model Class Initialized
DEBUG - 2016-12-08 22:58:39 --> Model Class Initialized
DEBUG - 2016-12-08 22:58:39 --> Model Class Initialized
DEBUG - 2016-12-08 22:58:39 --> Model Class Initialized
DEBUG - 2016-12-08 22:58:39 --> Model Class Initialized
DEBUG - 2016-12-08 22:58:39 --> Model Class Initialized
DEBUG - 2016-12-08 22:58:39 --> Model Class Initialized
DEBUG - 2016-12-08 22:58:39 --> Model Class Initialized
ERROR - 2016-12-08 22:58:39 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'administrator' belum di set.
DEBUG - 2016-12-08 22:58:39 --> Model Class Initialized
DEBUG - 2016-12-08 22:59:55 --> Config Class Initialized
DEBUG - 2016-12-08 22:59:55 --> Hooks Class Initialized
DEBUG - 2016-12-08 22:59:55 --> Utf8 Class Initialized
DEBUG - 2016-12-08 22:59:55 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 22:59:55 --> URI Class Initialized
DEBUG - 2016-12-08 22:59:55 --> Router Class Initialized
DEBUG - 2016-12-08 22:59:55 --> Output Class Initialized
DEBUG - 2016-12-08 22:59:55 --> Security Class Initialized
DEBUG - 2016-12-08 22:59:55 --> Input Class Initialized
DEBUG - 2016-12-08 22:59:55 --> XSS Filtering completed
DEBUG - 2016-12-08 22:59:55 --> XSS Filtering completed
DEBUG - 2016-12-08 22:59:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 22:59:55 --> Language Class Initialized
DEBUG - 2016-12-08 22:59:55 --> Loader Class Initialized
DEBUG - 2016-12-08 22:59:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 22:59:55 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 22:59:55 --> Helper loaded: url_helper
DEBUG - 2016-12-08 22:59:55 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 22:59:55 --> Helper loaded: file_helper
DEBUG - 2016-12-08 22:59:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:59:55 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 22:59:55 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 22:59:55 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 22:59:55 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 22:59:55 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 22:59:55 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:59:55 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 22:59:55 --> Helper loaded: common_helper
DEBUG - 2016-12-08 22:59:55 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 22:59:55 --> Helper loaded: form_helper
DEBUG - 2016-12-08 22:59:55 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 22:59:55 --> Helper loaded: security_helper
DEBUG - 2016-12-08 22:59:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:59:55 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 22:59:55 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 22:59:55 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 22:59:55 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 22:59:55 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 22:59:55 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 22:59:55 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 22:59:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:59:55 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 22:59:55 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 22:59:55 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 22:59:55 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 22:59:55 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 22:59:55 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 22:59:55 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 22:59:55 --> Database Driver Class Initialized
DEBUG - 2016-12-08 22:59:55 --> Session Class Initialized
DEBUG - 2016-12-08 22:59:55 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 22:59:55 --> Helper loaded: string_helper
DEBUG - 2016-12-08 22:59:55 --> Session routines successfully run
DEBUG - 2016-12-08 22:59:55 --> Native_session Class Initialized
DEBUG - 2016-12-08 22:59:55 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 22:59:55 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:59:55 --> Form Validation Class Initialized
DEBUG - 2016-12-08 22:59:55 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 22:59:55 --> Controller Class Initialized
DEBUG - 2016-12-08 22:59:55 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 22:59:55 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 22:59:55 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 22:59:55 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:59:55 --> Carabiner: library configured.
DEBUG - 2016-12-08 22:59:55 --> User Agent Class Initialized
DEBUG - 2016-12-08 22:59:55 --> Model Class Initialized
DEBUG - 2016-12-08 22:59:55 --> Model Class Initialized
DEBUG - 2016-12-08 22:59:55 --> Model Class Initialized
DEBUG - 2016-12-08 22:59:55 --> Model Class Initialized
DEBUG - 2016-12-08 22:59:55 --> Model Class Initialized
DEBUG - 2016-12-08 22:59:55 --> Model Class Initialized
DEBUG - 2016-12-08 22:59:55 --> Model Class Initialized
DEBUG - 2016-12-08 22:59:55 --> Model Class Initialized
DEBUG - 2016-12-08 22:59:55 --> Model Class Initialized
ERROR - 2016-12-08 22:59:55 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'administrator' belum di set.
DEBUG - 2016-12-08 22:59:55 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:02 --> Config Class Initialized
DEBUG - 2016-12-08 23:01:02 --> Hooks Class Initialized
DEBUG - 2016-12-08 23:01:02 --> Utf8 Class Initialized
DEBUG - 2016-12-08 23:01:02 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 23:01:02 --> URI Class Initialized
DEBUG - 2016-12-08 23:01:02 --> Router Class Initialized
DEBUG - 2016-12-08 23:01:02 --> Output Class Initialized
DEBUG - 2016-12-08 23:01:02 --> Security Class Initialized
DEBUG - 2016-12-08 23:01:02 --> Input Class Initialized
DEBUG - 2016-12-08 23:01:02 --> XSS Filtering completed
DEBUG - 2016-12-08 23:01:02 --> XSS Filtering completed
DEBUG - 2016-12-08 23:01:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 23:01:02 --> Language Class Initialized
DEBUG - 2016-12-08 23:01:02 --> Loader Class Initialized
DEBUG - 2016-12-08 23:01:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 23:01:02 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 23:01:02 --> Helper loaded: url_helper
DEBUG - 2016-12-08 23:01:02 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 23:01:02 --> Helper loaded: file_helper
DEBUG - 2016-12-08 23:01:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 23:01:02 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 23:01:02 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 23:01:02 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 23:01:02 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 23:01:02 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 23:01:02 --> Helper loaded: common_helper
DEBUG - 2016-12-08 23:01:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 23:01:02 --> Helper loaded: common_helper
DEBUG - 2016-12-08 23:01:02 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 23:01:02 --> Helper loaded: form_helper
DEBUG - 2016-12-08 23:01:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 23:01:02 --> Helper loaded: security_helper
DEBUG - 2016-12-08 23:01:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 23:01:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 23:01:02 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 23:01:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 23:01:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 23:01:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 23:01:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 23:01:02 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 23:01:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 23:01:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 23:01:02 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 23:01:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 23:01:02 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 23:01:02 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 23:01:02 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 23:01:02 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 23:01:02 --> Database Driver Class Initialized
DEBUG - 2016-12-08 23:01:02 --> Session Class Initialized
DEBUG - 2016-12-08 23:01:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 23:01:02 --> Helper loaded: string_helper
DEBUG - 2016-12-08 23:01:02 --> Session routines successfully run
DEBUG - 2016-12-08 23:01:02 --> Native_session Class Initialized
DEBUG - 2016-12-08 23:01:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 23:01:02 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:01:02 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:01:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 23:01:02 --> Controller Class Initialized
DEBUG - 2016-12-08 23:01:02 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 23:01:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 23:01:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 23:01:02 --> Carabiner: library configured.
DEBUG - 2016-12-08 23:01:02 --> Carabiner: library configured.
DEBUG - 2016-12-08 23:01:02 --> User Agent Class Initialized
DEBUG - 2016-12-08 23:01:02 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:02 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:02 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:02 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:02 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:02 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:02 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:02 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:02 --> Model Class Initialized
ERROR - 2016-12-08 23:01:02 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'administrator' belum di set.
DEBUG - 2016-12-08 23:01:02 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/daftar.php
DEBUG - 2016-12-08 23:01:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-08 23:01:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 23:01:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-08 23:01:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-08 23:01:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-08 23:01:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/js/daftar_mandiri_js.php
DEBUG - 2016-12-08 23:01:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/js/daftar_js.php
DEBUG - 2016-12-08 23:01:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 23:01:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-08 23:01:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-08 23:01:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 23:01:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-08 23:01:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-08 23:01:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-08 23:01:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/js/daftar_mandiri_js.php
DEBUG - 2016-12-08 23:01:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/js/daftar_js.php
DEBUG - 2016-12-08 23:01:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 23:01:03 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-08 23:01:03 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/82e431e4112c3e89eb7c75a74b999d31
DEBUG - 2016-12-08 23:01:03 --> Final output sent to browser
DEBUG - 2016-12-08 23:01:03 --> Total execution time: 0.5679
DEBUG - 2016-12-08 23:01:43 --> Config Class Initialized
DEBUG - 2016-12-08 23:01:43 --> Hooks Class Initialized
DEBUG - 2016-12-08 23:01:43 --> Utf8 Class Initialized
DEBUG - 2016-12-08 23:01:43 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 23:01:43 --> URI Class Initialized
DEBUG - 2016-12-08 23:01:43 --> Router Class Initialized
DEBUG - 2016-12-08 23:01:43 --> No URI present. Default controller set.
DEBUG - 2016-12-08 23:01:43 --> Output Class Initialized
DEBUG - 2016-12-08 23:01:43 --> Cache file has expired. File deleted
DEBUG - 2016-12-08 23:01:43 --> Security Class Initialized
DEBUG - 2016-12-08 23:01:43 --> Input Class Initialized
DEBUG - 2016-12-08 23:01:43 --> XSS Filtering completed
DEBUG - 2016-12-08 23:01:43 --> XSS Filtering completed
DEBUG - 2016-12-08 23:01:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 23:01:43 --> Language Class Initialized
DEBUG - 2016-12-08 23:01:43 --> Loader Class Initialized
DEBUG - 2016-12-08 23:01:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 23:01:43 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 23:01:43 --> Helper loaded: url_helper
DEBUG - 2016-12-08 23:01:43 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 23:01:43 --> Helper loaded: file_helper
DEBUG - 2016-12-08 23:01:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 23:01:43 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 23:01:43 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 23:01:43 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 23:01:43 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 23:01:43 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 23:01:43 --> Helper loaded: common_helper
DEBUG - 2016-12-08 23:01:43 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 23:01:43 --> Helper loaded: common_helper
DEBUG - 2016-12-08 23:01:43 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 23:01:43 --> Helper loaded: form_helper
DEBUG - 2016-12-08 23:01:43 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 23:01:43 --> Helper loaded: security_helper
DEBUG - 2016-12-08 23:01:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 23:01:43 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 23:01:43 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 23:01:43 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 23:01:43 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 23:01:43 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 23:01:43 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 23:01:43 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 23:01:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 23:01:43 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 23:01:43 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 23:01:43 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 23:01:43 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 23:01:43 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 23:01:43 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 23:01:43 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 23:01:43 --> Database Driver Class Initialized
DEBUG - 2016-12-08 23:01:43 --> Session Class Initialized
DEBUG - 2016-12-08 23:01:43 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 23:01:43 --> Helper loaded: string_helper
DEBUG - 2016-12-08 23:01:43 --> Session routines successfully run
DEBUG - 2016-12-08 23:01:43 --> Native_session Class Initialized
DEBUG - 2016-12-08 23:01:43 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 23:01:43 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:01:43 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:01:43 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 23:01:43 --> Controller Class Initialized
DEBUG - 2016-12-08 23:01:43 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 23:01:43 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 23:01:43 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 23:01:43 --> Carabiner: library configured.
DEBUG - 2016-12-08 23:01:43 --> Carabiner: library configured.
DEBUG - 2016-12-08 23:01:43 --> User Agent Class Initialized
DEBUG - 2016-12-08 23:01:43 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:43 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:43 --> Model Class Initialized
ERROR - 2016-12-08 23:01:43 --> Hak Akses modul/kontroller 'home' untuk role 'administrator' belum di set.
DEBUG - 2016-12-08 23:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index/calender_diklat.php
DEBUG - 2016-12-08 23:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-12-08 23:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-08 23:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 23:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-08 23:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-08 23:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-08 23:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-12-08 23:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-12-08 23:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 23:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-08 23:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-08 23:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 23:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-08 23:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-08 23:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-08 23:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/calender_diklat_js.php
DEBUG - 2016-12-08 23:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/js/index_js.php
DEBUG - 2016-12-08 23:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 23:01:43 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-08 23:01:43 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-12-08 23:01:43 --> Final output sent to browser
DEBUG - 2016-12-08 23:01:43 --> Total execution time: 0.5230
DEBUG - 2016-12-08 23:01:43 --> Config Class Initialized
DEBUG - 2016-12-08 23:01:43 --> Hooks Class Initialized
DEBUG - 2016-12-08 23:01:43 --> Utf8 Class Initialized
DEBUG - 2016-12-08 23:01:43 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 23:01:43 --> URI Class Initialized
DEBUG - 2016-12-08 23:01:44 --> Router Class Initialized
DEBUG - 2016-12-08 23:01:44 --> Output Class Initialized
DEBUG - 2016-12-08 23:01:44 --> Cache file has expired. File deleted
DEBUG - 2016-12-08 23:01:44 --> Security Class Initialized
DEBUG - 2016-12-08 23:01:44 --> Input Class Initialized
DEBUG - 2016-12-08 23:01:44 --> XSS Filtering completed
DEBUG - 2016-12-08 23:01:44 --> XSS Filtering completed
DEBUG - 2016-12-08 23:01:44 --> XSS Filtering completed
DEBUG - 2016-12-08 23:01:44 --> XSS Filtering completed
DEBUG - 2016-12-08 23:01:44 --> XSS Filtering completed
DEBUG - 2016-12-08 23:01:44 --> XSS Filtering completed
DEBUG - 2016-12-08 23:01:44 --> XSS Filtering completed
DEBUG - 2016-12-08 23:01:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 23:01:44 --> Language Class Initialized
DEBUG - 2016-12-08 23:01:44 --> Loader Class Initialized
DEBUG - 2016-12-08 23:01:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 23:01:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 23:01:44 --> Helper loaded: url_helper
DEBUG - 2016-12-08 23:01:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 23:01:44 --> Helper loaded: file_helper
DEBUG - 2016-12-08 23:01:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 23:01:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 23:01:44 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 23:01:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 23:01:44 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 23:01:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 23:01:44 --> Helper loaded: common_helper
DEBUG - 2016-12-08 23:01:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 23:01:44 --> Helper loaded: common_helper
DEBUG - 2016-12-08 23:01:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 23:01:44 --> Helper loaded: form_helper
DEBUG - 2016-12-08 23:01:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 23:01:44 --> Helper loaded: security_helper
DEBUG - 2016-12-08 23:01:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 23:01:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 23:01:44 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 23:01:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 23:01:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 23:01:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 23:01:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 23:01:44 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 23:01:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 23:01:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 23:01:44 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 23:01:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 23:01:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 23:01:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 23:01:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 23:01:44 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 23:01:44 --> Database Driver Class Initialized
DEBUG - 2016-12-08 23:01:44 --> Session Class Initialized
DEBUG - 2016-12-08 23:01:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 23:01:44 --> Helper loaded: string_helper
DEBUG - 2016-12-08 23:01:44 --> Session routines successfully run
DEBUG - 2016-12-08 23:01:44 --> Native_session Class Initialized
DEBUG - 2016-12-08 23:01:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 23:01:44 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:01:44 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:01:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 23:01:44 --> Controller Class Initialized
DEBUG - 2016-12-08 23:01:44 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 23:01:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 23:01:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 23:01:44 --> Carabiner: library configured.
DEBUG - 2016-12-08 23:01:44 --> Carabiner: library configured.
DEBUG - 2016-12-08 23:01:44 --> User Agent Class Initialized
DEBUG - 2016-12-08 23:01:44 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:44 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:44 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:44 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:44 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:44 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:44 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:44 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/90ac5014ef189397686d84a5cf5558fc
DEBUG - 2016-12-08 23:01:44 --> Final output sent to browser
DEBUG - 2016-12-08 23:01:44 --> Total execution time: 0.6164
DEBUG - 2016-12-08 23:01:44 --> Config Class Initialized
DEBUG - 2016-12-08 23:01:44 --> Hooks Class Initialized
DEBUG - 2016-12-08 23:01:44 --> Utf8 Class Initialized
DEBUG - 2016-12-08 23:01:44 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 23:01:44 --> URI Class Initialized
DEBUG - 2016-12-08 23:01:45 --> Router Class Initialized
DEBUG - 2016-12-08 23:01:45 --> Output Class Initialized
DEBUG - 2016-12-08 23:01:45 --> Cache file has expired. File deleted
DEBUG - 2016-12-08 23:01:45 --> Security Class Initialized
DEBUG - 2016-12-08 23:01:45 --> Input Class Initialized
DEBUG - 2016-12-08 23:01:45 --> XSS Filtering completed
DEBUG - 2016-12-08 23:01:45 --> XSS Filtering completed
DEBUG - 2016-12-08 23:01:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 23:01:45 --> Language Class Initialized
DEBUG - 2016-12-08 23:01:45 --> Loader Class Initialized
DEBUG - 2016-12-08 23:01:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 23:01:45 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 23:01:45 --> Helper loaded: url_helper
DEBUG - 2016-12-08 23:01:45 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 23:01:45 --> Helper loaded: file_helper
DEBUG - 2016-12-08 23:01:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 23:01:45 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 23:01:45 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 23:01:45 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 23:01:45 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 23:01:45 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 23:01:45 --> Helper loaded: common_helper
DEBUG - 2016-12-08 23:01:45 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 23:01:45 --> Helper loaded: common_helper
DEBUG - 2016-12-08 23:01:45 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 23:01:45 --> Helper loaded: form_helper
DEBUG - 2016-12-08 23:01:45 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 23:01:45 --> Helper loaded: security_helper
DEBUG - 2016-12-08 23:01:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 23:01:45 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 23:01:45 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 23:01:45 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 23:01:45 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 23:01:45 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 23:01:45 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 23:01:45 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 23:01:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 23:01:45 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 23:01:45 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 23:01:45 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 23:01:45 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 23:01:45 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 23:01:45 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 23:01:45 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 23:01:45 --> Database Driver Class Initialized
DEBUG - 2016-12-08 23:01:45 --> Session Class Initialized
DEBUG - 2016-12-08 23:01:45 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 23:01:45 --> Helper loaded: string_helper
DEBUG - 2016-12-08 23:01:45 --> Session routines successfully run
DEBUG - 2016-12-08 23:01:45 --> Native_session Class Initialized
DEBUG - 2016-12-08 23:01:45 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 23:01:45 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:01:45 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:01:45 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 23:01:45 --> Controller Class Initialized
DEBUG - 2016-12-08 23:01:45 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 23:01:45 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 23:01:45 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 23:01:45 --> Carabiner: library configured.
DEBUG - 2016-12-08 23:01:45 --> Carabiner: library configured.
DEBUG - 2016-12-08 23:01:45 --> User Agent Class Initialized
DEBUG - 2016-12-08 23:01:45 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:45 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:46 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:46 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-12-08 23:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-12-08 23:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-12-08 23:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 23:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-12-08 23:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 23:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-12-08 23:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-12-08 23:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-12-08 23:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 23:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-12-08 23:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 23:01:47 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-12-08 23:01:47 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-12-08 23:01:47 --> Final output sent to browser
DEBUG - 2016-12-08 23:01:47 --> Total execution time: 1.6767
DEBUG - 2016-12-08 23:01:56 --> Config Class Initialized
DEBUG - 2016-12-08 23:01:56 --> Hooks Class Initialized
DEBUG - 2016-12-08 23:01:56 --> Utf8 Class Initialized
DEBUG - 2016-12-08 23:01:56 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 23:01:56 --> URI Class Initialized
DEBUG - 2016-12-08 23:01:56 --> Router Class Initialized
DEBUG - 2016-12-08 23:01:56 --> Output Class Initialized
DEBUG - 2016-12-08 23:01:56 --> Security Class Initialized
DEBUG - 2016-12-08 23:01:56 --> Input Class Initialized
DEBUG - 2016-12-08 23:01:56 --> XSS Filtering completed
DEBUG - 2016-12-08 23:01:56 --> XSS Filtering completed
DEBUG - 2016-12-08 23:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 23:01:56 --> Language Class Initialized
DEBUG - 2016-12-08 23:01:57 --> Loader Class Initialized
DEBUG - 2016-12-08 23:01:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 23:01:57 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 23:01:57 --> Helper loaded: url_helper
DEBUG - 2016-12-08 23:01:57 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 23:01:57 --> Helper loaded: file_helper
DEBUG - 2016-12-08 23:01:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 23:01:57 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 23:01:57 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 23:01:57 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 23:01:57 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 23:01:57 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 23:01:57 --> Helper loaded: common_helper
DEBUG - 2016-12-08 23:01:57 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 23:01:57 --> Helper loaded: common_helper
DEBUG - 2016-12-08 23:01:57 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 23:01:57 --> Helper loaded: form_helper
DEBUG - 2016-12-08 23:01:57 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 23:01:57 --> Helper loaded: security_helper
DEBUG - 2016-12-08 23:01:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 23:01:57 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 23:01:57 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 23:01:57 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 23:01:57 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 23:01:57 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 23:01:57 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 23:01:57 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 23:01:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 23:01:57 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 23:01:57 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 23:01:57 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 23:01:57 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 23:01:57 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 23:01:57 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 23:01:57 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 23:01:57 --> Database Driver Class Initialized
DEBUG - 2016-12-08 23:01:57 --> Session Class Initialized
DEBUG - 2016-12-08 23:01:57 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 23:01:57 --> Helper loaded: string_helper
DEBUG - 2016-12-08 23:01:57 --> Session routines successfully run
DEBUG - 2016-12-08 23:01:57 --> Native_session Class Initialized
DEBUG - 2016-12-08 23:01:57 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 23:01:57 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:01:57 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:01:57 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 23:01:57 --> Controller Class Initialized
DEBUG - 2016-12-08 23:01:57 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 23:01:57 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 23:01:57 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 23:01:57 --> Carabiner: library configured.
DEBUG - 2016-12-08 23:01:57 --> Carabiner: library configured.
DEBUG - 2016-12-08 23:01:57 --> User Agent Class Initialized
DEBUG - 2016-12-08 23:01:57 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:57 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:57 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:57 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:58 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:58 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:58 --> Model Class Initialized
DEBUG - 2016-12-08 23:01:59 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-12-08 23:01:59 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-12-08 23:01:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-12-08 23:01:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-12-08 23:01:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-12-08 23:01:59 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-12-08 23:01:59 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-12-08 23:01:59 --> Final output sent to browser
DEBUG - 2016-12-08 23:01:59 --> Total execution time: 1.9004
DEBUG - 2016-12-08 23:01:59 --> Config Class Initialized
DEBUG - 2016-12-08 23:01:59 --> Hooks Class Initialized
DEBUG - 2016-12-08 23:01:59 --> Utf8 Class Initialized
DEBUG - 2016-12-08 23:01:59 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 23:01:59 --> URI Class Initialized
DEBUG - 2016-12-08 23:01:59 --> Router Class Initialized
ERROR - 2016-12-08 23:01:59 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-12-08 23:02:38 --> Config Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Hooks Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Utf8 Class Initialized
DEBUG - 2016-12-08 23:02:38 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 23:02:38 --> URI Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Router Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Output Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Cache file has expired. File deleted
DEBUG - 2016-12-08 23:02:38 --> Security Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Input Class Initialized
DEBUG - 2016-12-08 23:02:38 --> XSS Filtering completed
DEBUG - 2016-12-08 23:02:38 --> XSS Filtering completed
DEBUG - 2016-12-08 23:02:38 --> XSS Filtering completed
DEBUG - 2016-12-08 23:02:38 --> XSS Filtering completed
DEBUG - 2016-12-08 23:02:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 23:02:38 --> Language Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Loader Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 23:02:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 23:02:38 --> Helper loaded: url_helper
DEBUG - 2016-12-08 23:02:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 23:02:38 --> Helper loaded: file_helper
DEBUG - 2016-12-08 23:02:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 23:02:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 23:02:38 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 23:02:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 23:02:38 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 23:02:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 23:02:38 --> Helper loaded: common_helper
DEBUG - 2016-12-08 23:02:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 23:02:38 --> Helper loaded: common_helper
DEBUG - 2016-12-08 23:02:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 23:02:38 --> Helper loaded: form_helper
DEBUG - 2016-12-08 23:02:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 23:02:38 --> Helper loaded: security_helper
DEBUG - 2016-12-08 23:02:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 23:02:38 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 23:02:38 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 23:02:38 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 23:02:38 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 23:02:38 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 23:02:38 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 23:02:38 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 23:02:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 23:02:38 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 23:02:38 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 23:02:38 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 23:02:38 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 23:02:38 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 23:02:38 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 23:02:38 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 23:02:38 --> Database Driver Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Session Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 23:02:38 --> Helper loaded: string_helper
DEBUG - 2016-12-08 23:02:38 --> Session routines successfully run
DEBUG - 2016-12-08 23:02:38 --> Native_session Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 23:02:38 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 23:02:38 --> Controller Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 23:02:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 23:02:38 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 23:02:38 --> Carabiner: library configured.
DEBUG - 2016-12-08 23:02:38 --> Carabiner: library configured.
DEBUG - 2016-12-08 23:02:38 --> User Agent Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-12-08 23:02:38 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 23:02:38 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-12-08 23:02:38 --> Config Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Hooks Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Utf8 Class Initialized
DEBUG - 2016-12-08 23:02:38 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 23:02:38 --> URI Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Router Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Output Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Cache file has expired. File deleted
DEBUG - 2016-12-08 23:02:38 --> Security Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Input Class Initialized
DEBUG - 2016-12-08 23:02:38 --> XSS Filtering completed
DEBUG - 2016-12-08 23:02:38 --> XSS Filtering completed
DEBUG - 2016-12-08 23:02:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 23:02:38 --> Language Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Loader Class Initialized
DEBUG - 2016-12-08 23:02:38 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 23:02:38 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 23:02:38 --> Helper loaded: url_helper
DEBUG - 2016-12-08 23:02:38 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 23:02:38 --> Helper loaded: file_helper
DEBUG - 2016-12-08 23:02:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 23:02:38 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 23:02:38 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 23:02:38 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 23:02:38 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 23:02:38 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 23:02:38 --> Helper loaded: common_helper
DEBUG - 2016-12-08 23:02:38 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 23:02:38 --> Helper loaded: common_helper
DEBUG - 2016-12-08 23:02:38 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 23:02:38 --> Helper loaded: form_helper
DEBUG - 2016-12-08 23:02:38 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 23:02:39 --> Helper loaded: security_helper
DEBUG - 2016-12-08 23:02:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 23:02:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 23:02:39 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 23:02:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 23:02:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 23:02:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 23:02:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 23:02:39 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 23:02:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 23:02:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 23:02:39 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 23:02:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 23:02:39 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 23:02:39 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 23:02:39 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 23:02:39 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 23:02:39 --> Database Driver Class Initialized
DEBUG - 2016-12-08 23:02:39 --> Session Class Initialized
DEBUG - 2016-12-08 23:02:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 23:02:39 --> Helper loaded: string_helper
DEBUG - 2016-12-08 23:02:39 --> Session routines successfully run
DEBUG - 2016-12-08 23:02:39 --> Native_session Class Initialized
DEBUG - 2016-12-08 23:02:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 23:02:39 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:02:39 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:02:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 23:02:39 --> Controller Class Initialized
DEBUG - 2016-12-08 23:02:39 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 23:02:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 23:02:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 23:02:39 --> Carabiner: library configured.
DEBUG - 2016-12-08 23:02:39 --> Carabiner: library configured.
DEBUG - 2016-12-08 23:02:39 --> User Agent Class Initialized
DEBUG - 2016-12-08 23:02:39 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:39 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:39 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:39 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:39 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:39 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:39 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:39 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:39 --> Model Class Initialized
ERROR - 2016-12-08 23:02:39 --> Hak Akses modul/kontroller 'fdaftar_diklat' untuk role 'administrator' belum di set.
DEBUG - 2016-12-08 23:02:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/fdaftar_diklat/detail.php
DEBUG - 2016-12-08 23:02:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-08 23:02:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 23:02:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-08 23:02:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-08 23:02:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-08 23:02:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 23:02:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-08 23:02:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-12-08 23:02:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 23:02:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-12-08 23:02:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-12-08 23:02:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/default_scripts.php
DEBUG - 2016-12-08 23:02:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 23:02:39 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-12-08 23:02:39 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/73f5e075ee35be5f6c1c98a57562112a
DEBUG - 2016-12-08 23:02:39 --> Final output sent to browser
DEBUG - 2016-12-08 23:02:39 --> Total execution time: 0.6852
DEBUG - 2016-12-08 23:02:41 --> Config Class Initialized
DEBUG - 2016-12-08 23:02:41 --> Hooks Class Initialized
DEBUG - 2016-12-08 23:02:41 --> Utf8 Class Initialized
DEBUG - 2016-12-08 23:02:41 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 23:02:41 --> URI Class Initialized
DEBUG - 2016-12-08 23:02:41 --> Router Class Initialized
DEBUG - 2016-12-08 23:02:41 --> Output Class Initialized
DEBUG - 2016-12-08 23:02:41 --> Cache file has expired. File deleted
DEBUG - 2016-12-08 23:02:42 --> Security Class Initialized
DEBUG - 2016-12-08 23:02:42 --> Input Class Initialized
DEBUG - 2016-12-08 23:02:42 --> XSS Filtering completed
DEBUG - 2016-12-08 23:02:42 --> XSS Filtering completed
DEBUG - 2016-12-08 23:02:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 23:02:42 --> Language Class Initialized
DEBUG - 2016-12-08 23:02:42 --> Loader Class Initialized
DEBUG - 2016-12-08 23:02:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 23:02:42 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 23:02:42 --> Helper loaded: url_helper
DEBUG - 2016-12-08 23:02:42 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 23:02:42 --> Helper loaded: file_helper
DEBUG - 2016-12-08 23:02:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 23:02:42 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 23:02:42 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 23:02:42 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 23:02:42 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 23:02:42 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 23:02:42 --> Helper loaded: common_helper
DEBUG - 2016-12-08 23:02:42 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 23:02:42 --> Helper loaded: common_helper
DEBUG - 2016-12-08 23:02:42 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 23:02:42 --> Helper loaded: form_helper
DEBUG - 2016-12-08 23:02:42 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 23:02:42 --> Helper loaded: security_helper
DEBUG - 2016-12-08 23:02:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 23:02:42 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 23:02:42 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 23:02:42 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 23:02:42 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 23:02:42 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 23:02:42 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 23:02:42 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 23:02:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 23:02:42 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 23:02:42 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 23:02:42 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 23:02:42 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 23:02:42 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 23:02:42 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 23:02:42 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 23:02:42 --> Database Driver Class Initialized
DEBUG - 2016-12-08 23:02:42 --> Session Class Initialized
DEBUG - 2016-12-08 23:02:42 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 23:02:42 --> Helper loaded: string_helper
DEBUG - 2016-12-08 23:02:42 --> Session routines successfully run
DEBUG - 2016-12-08 23:02:42 --> Native_session Class Initialized
DEBUG - 2016-12-08 23:02:42 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 23:02:42 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:02:42 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:02:42 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 23:02:42 --> Controller Class Initialized
DEBUG - 2016-12-08 23:02:42 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 23:02:42 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 23:02:42 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 23:02:42 --> Carabiner: library configured.
DEBUG - 2016-12-08 23:02:42 --> Carabiner: library configured.
DEBUG - 2016-12-08 23:02:42 --> User Agent Class Initialized
DEBUG - 2016-12-08 23:02:42 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:42 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:42 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/home/index.php
DEBUG - 2016-12-08 23:02:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-12-08 23:02:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-12-08 23:02:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 23:02:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-12-08 23:02:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 23:02:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-12-08 23:02:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-12-08 23:02:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-12-08 23:02:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 23:02:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-12-08 23:02:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 23:02:42 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-12-08 23:02:42 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/429db872f6f950c2186085a4c12f1681
DEBUG - 2016-12-08 23:02:42 --> Final output sent to browser
DEBUG - 2016-12-08 23:02:42 --> Total execution time: 0.6087
DEBUG - 2016-12-08 23:02:48 --> Config Class Initialized
DEBUG - 2016-12-08 23:02:48 --> Hooks Class Initialized
DEBUG - 2016-12-08 23:02:48 --> Utf8 Class Initialized
DEBUG - 2016-12-08 23:02:48 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 23:02:48 --> URI Class Initialized
DEBUG - 2016-12-08 23:02:48 --> Router Class Initialized
DEBUG - 2016-12-08 23:02:48 --> Output Class Initialized
DEBUG - 2016-12-08 23:02:48 --> Cache file has expired. File deleted
DEBUG - 2016-12-08 23:02:48 --> Security Class Initialized
DEBUG - 2016-12-08 23:02:48 --> Input Class Initialized
DEBUG - 2016-12-08 23:02:48 --> XSS Filtering completed
DEBUG - 2016-12-08 23:02:48 --> XSS Filtering completed
DEBUG - 2016-12-08 23:02:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 23:02:48 --> Language Class Initialized
DEBUG - 2016-12-08 23:02:48 --> Loader Class Initialized
DEBUG - 2016-12-08 23:02:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 23:02:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 23:02:49 --> Helper loaded: url_helper
DEBUG - 2016-12-08 23:02:49 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 23:02:49 --> Helper loaded: file_helper
DEBUG - 2016-12-08 23:02:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 23:02:49 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 23:02:49 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 23:02:49 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 23:02:49 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 23:02:49 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 23:02:49 --> Helper loaded: common_helper
DEBUG - 2016-12-08 23:02:49 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 23:02:49 --> Helper loaded: common_helper
DEBUG - 2016-12-08 23:02:49 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 23:02:49 --> Helper loaded: form_helper
DEBUG - 2016-12-08 23:02:49 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 23:02:49 --> Helper loaded: security_helper
DEBUG - 2016-12-08 23:02:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 23:02:49 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 23:02:49 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 23:02:49 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 23:02:49 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 23:02:49 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 23:02:49 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 23:02:49 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 23:02:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 23:02:49 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 23:02:49 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 23:02:49 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 23:02:49 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 23:02:49 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 23:02:49 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 23:02:49 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 23:02:49 --> Database Driver Class Initialized
DEBUG - 2016-12-08 23:02:49 --> Session Class Initialized
DEBUG - 2016-12-08 23:02:49 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 23:02:49 --> Helper loaded: string_helper
DEBUG - 2016-12-08 23:02:49 --> Session routines successfully run
DEBUG - 2016-12-08 23:02:49 --> Native_session Class Initialized
DEBUG - 2016-12-08 23:02:49 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 23:02:49 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:02:49 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:02:49 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 23:02:49 --> Controller Class Initialized
DEBUG - 2016-12-08 23:02:49 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 23:02:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 23:02:49 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 23:02:49 --> Carabiner: library configured.
DEBUG - 2016-12-08 23:02:49 --> Carabiner: library configured.
DEBUG - 2016-12-08 23:02:49 --> User Agent Class Initialized
DEBUG - 2016-12-08 23:02:49 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:49 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:49 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:49 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:49 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:49 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:49 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:49 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:49 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:49 --> Model Class Initialized
DEBUG - 2016-12-08 23:02:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-12-08 23:02:49 --> Pagination Class Initialized
DEBUG - 2016-12-08 23:02:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-12-08 23:02:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-12-08 23:02:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-12-08 23:02:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-12-08 23:02:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 23:02:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-12-08 23:02:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-12-08 23:02:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 23:02:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-12-08 23:02:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-12-08 23:02:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-12-08 23:02:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 23:02:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-12-08 23:02:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-12-08 23:02:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 23:02:50 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-12-08 23:02:50 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-12-08 23:02:50 --> Final output sent to browser
DEBUG - 2016-12-08 23:02:50 --> Total execution time: 1.2040
DEBUG - 2016-12-08 23:04:15 --> Config Class Initialized
DEBUG - 2016-12-08 23:04:15 --> Hooks Class Initialized
DEBUG - 2016-12-08 23:04:15 --> Utf8 Class Initialized
DEBUG - 2016-12-08 23:04:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 23:04:15 --> URI Class Initialized
DEBUG - 2016-12-08 23:04:15 --> Router Class Initialized
DEBUG - 2016-12-08 23:04:15 --> Output Class Initialized
DEBUG - 2016-12-08 23:04:16 --> Cache file has expired. File deleted
DEBUG - 2016-12-08 23:04:16 --> Security Class Initialized
DEBUG - 2016-12-08 23:04:16 --> Input Class Initialized
DEBUG - 2016-12-08 23:04:16 --> XSS Filtering completed
DEBUG - 2016-12-08 23:04:16 --> XSS Filtering completed
DEBUG - 2016-12-08 23:04:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 23:04:16 --> Language Class Initialized
DEBUG - 2016-12-08 23:04:16 --> Loader Class Initialized
DEBUG - 2016-12-08 23:04:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 23:04:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 23:04:16 --> Helper loaded: url_helper
DEBUG - 2016-12-08 23:04:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 23:04:16 --> Helper loaded: file_helper
DEBUG - 2016-12-08 23:04:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 23:04:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 23:04:16 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 23:04:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 23:04:16 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 23:04:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 23:04:16 --> Helper loaded: common_helper
DEBUG - 2016-12-08 23:04:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 23:04:16 --> Helper loaded: common_helper
DEBUG - 2016-12-08 23:04:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 23:04:16 --> Helper loaded: form_helper
DEBUG - 2016-12-08 23:04:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 23:04:16 --> Helper loaded: security_helper
DEBUG - 2016-12-08 23:04:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 23:04:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 23:04:16 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 23:04:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 23:04:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 23:04:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 23:04:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 23:04:16 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 23:04:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 23:04:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 23:04:16 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 23:04:17 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 23:04:17 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 23:04:17 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 23:04:17 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 23:04:17 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 23:04:17 --> Database Driver Class Initialized
DEBUG - 2016-12-08 23:04:17 --> Session Class Initialized
DEBUG - 2016-12-08 23:04:17 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 23:04:17 --> Helper loaded: string_helper
DEBUG - 2016-12-08 23:04:17 --> Session routines successfully run
DEBUG - 2016-12-08 23:04:17 --> Native_session Class Initialized
DEBUG - 2016-12-08 23:04:17 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 23:04:17 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:04:17 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:04:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 23:04:17 --> Controller Class Initialized
DEBUG - 2016-12-08 23:04:17 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 23:04:17 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 23:04:17 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 23:04:17 --> Carabiner: library configured.
DEBUG - 2016-12-08 23:04:17 --> Carabiner: library configured.
DEBUG - 2016-12-08 23:04:17 --> User Agent Class Initialized
DEBUG - 2016-12-08 23:04:17 --> Model Class Initialized
DEBUG - 2016-12-08 23:04:17 --> Model Class Initialized
DEBUG - 2016-12-08 23:04:17 --> Model Class Initialized
DEBUG - 2016-12-08 23:04:17 --> Model Class Initialized
DEBUG - 2016-12-08 23:04:17 --> Model Class Initialized
DEBUG - 2016-12-08 23:04:17 --> Model Class Initialized
DEBUG - 2016-12-08 23:04:17 --> Model Class Initialized
DEBUG - 2016-12-08 23:04:17 --> Model Class Initialized
DEBUG - 2016-12-08 23:04:17 --> Model Class Initialized
DEBUG - 2016-12-08 23:04:17 --> Model Class Initialized
DEBUG - 2016-12-08 23:04:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-12-08 23:04:17 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:04:17 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 23:04:17 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-12-08 23:04:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-12-08 23:04:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_spt.php
DEBUG - 2016-12-08 23:04:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-12-08 23:04:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tahapan_diklat.php
DEBUG - 2016-12-08 23:04:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-12-08 23:04:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_dasar_spt.php
DEBUG - 2016-12-08 23:04:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-12-08 23:04:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_tembusan_spt.php
DEBUG - 2016-12-08 23:04:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-12-08 23:04:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_isian_diklat.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_hal_perhatian_spt.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_konfigurasi_sttpp.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail_persyaratan_diklat.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/detail.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_js.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tembusan_spt_js.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_tahapan_js.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_dasar_spt_js.php
DEBUG - 2016-12-08 23:04:18 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_isian_diklat_js.php
DEBUG - 2016-12-08 23:04:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_hal_perhatian_spt_js.php
DEBUG - 2016-12-08 23:04:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/detail_persyaratan_diklat_js.php
DEBUG - 2016-12-08 23:04:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 23:04:19 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-12-08 23:04:19 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/8f8e2926e3f1cbfc3aa536b43cdd0626
DEBUG - 2016-12-08 23:04:19 --> Final output sent to browser
DEBUG - 2016-12-08 23:04:19 --> Total execution time: 1.5830
DEBUG - 2016-12-08 23:05:33 --> Config Class Initialized
DEBUG - 2016-12-08 23:05:33 --> Hooks Class Initialized
DEBUG - 2016-12-08 23:05:33 --> Utf8 Class Initialized
DEBUG - 2016-12-08 23:05:33 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 23:05:33 --> URI Class Initialized
DEBUG - 2016-12-08 23:05:33 --> Router Class Initialized
DEBUG - 2016-12-08 23:05:33 --> Output Class Initialized
DEBUG - 2016-12-08 23:05:34 --> Cache file has expired. File deleted
DEBUG - 2016-12-08 23:05:34 --> Security Class Initialized
DEBUG - 2016-12-08 23:05:34 --> Input Class Initialized
DEBUG - 2016-12-08 23:05:34 --> XSS Filtering completed
DEBUG - 2016-12-08 23:05:34 --> XSS Filtering completed
DEBUG - 2016-12-08 23:05:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 23:05:34 --> Language Class Initialized
DEBUG - 2016-12-08 23:05:34 --> Loader Class Initialized
DEBUG - 2016-12-08 23:05:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 23:05:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 23:05:34 --> Helper loaded: url_helper
DEBUG - 2016-12-08 23:05:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 23:05:34 --> Helper loaded: file_helper
DEBUG - 2016-12-08 23:05:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 23:05:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 23:05:34 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 23:05:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 23:05:34 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 23:05:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 23:05:34 --> Helper loaded: common_helper
DEBUG - 2016-12-08 23:05:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 23:05:34 --> Helper loaded: common_helper
DEBUG - 2016-12-08 23:05:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 23:05:34 --> Helper loaded: form_helper
DEBUG - 2016-12-08 23:05:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 23:05:34 --> Helper loaded: security_helper
DEBUG - 2016-12-08 23:05:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 23:05:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 23:05:34 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 23:05:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 23:05:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 23:05:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 23:05:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 23:05:34 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 23:05:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 23:05:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 23:05:34 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 23:05:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 23:05:34 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 23:05:34 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 23:05:34 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 23:05:34 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 23:05:34 --> Database Driver Class Initialized
DEBUG - 2016-12-08 23:05:34 --> Session Class Initialized
DEBUG - 2016-12-08 23:05:34 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 23:05:34 --> Helper loaded: string_helper
DEBUG - 2016-12-08 23:05:34 --> Session routines successfully run
DEBUG - 2016-12-08 23:05:34 --> Native_session Class Initialized
DEBUG - 2016-12-08 23:05:34 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 23:05:34 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:05:34 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:05:34 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 23:05:34 --> Controller Class Initialized
DEBUG - 2016-12-08 23:05:34 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 23:05:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 23:05:34 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 23:05:34 --> Carabiner: library configured.
DEBUG - 2016-12-08 23:05:34 --> Carabiner: library configured.
DEBUG - 2016-12-08 23:05:34 --> User Agent Class Initialized
DEBUG - 2016-12-08 23:05:34 --> Model Class Initialized
DEBUG - 2016-12-08 23:05:34 --> Model Class Initialized
DEBUG - 2016-12-08 23:05:34 --> Model Class Initialized
DEBUG - 2016-12-08 23:05:34 --> Model Class Initialized
DEBUG - 2016-12-08 23:05:34 --> Model Class Initialized
DEBUG - 2016-12-08 23:05:34 --> Model Class Initialized
DEBUG - 2016-12-08 23:05:34 --> Model Class Initialized
DEBUG - 2016-12-08 23:05:34 --> Model Class Initialized
DEBUG - 2016-12-08 23:05:34 --> Model Class Initialized
DEBUG - 2016-12-08 23:05:34 --> Model Class Initialized
DEBUG - 2016-12-08 23:05:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-12-08 23:05:34 --> Pagination Class Initialized
DEBUG - 2016-12-08 23:05:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-12-08 23:05:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-12-08 23:05:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-12-08 23:05:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-12-08 23:05:34 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 23:05:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-12-08 23:05:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-12-08 23:05:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 23:05:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-12-08 23:05:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-12-08 23:05:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-12-08 23:05:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-12-08 23:05:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-12-08 23:05:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-12-08 23:05:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-12-08 23:05:35 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-12-08 23:05:35 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-12-08 23:05:35 --> Final output sent to browser
DEBUG - 2016-12-08 23:05:35 --> Total execution time: 1.0043
DEBUG - 2016-12-08 23:11:40 --> Config Class Initialized
DEBUG - 2016-12-08 23:11:40 --> Hooks Class Initialized
DEBUG - 2016-12-08 23:11:40 --> Utf8 Class Initialized
DEBUG - 2016-12-08 23:11:40 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 23:11:40 --> URI Class Initialized
DEBUG - 2016-12-08 23:11:40 --> Router Class Initialized
DEBUG - 2016-12-08 23:11:40 --> Output Class Initialized
DEBUG - 2016-12-08 23:11:40 --> Security Class Initialized
DEBUG - 2016-12-08 23:11:40 --> Input Class Initialized
DEBUG - 2016-12-08 23:11:40 --> XSS Filtering completed
DEBUG - 2016-12-08 23:11:40 --> XSS Filtering completed
DEBUG - 2016-12-08 23:11:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 23:11:40 --> Language Class Initialized
DEBUG - 2016-12-08 23:11:40 --> Loader Class Initialized
DEBUG - 2016-12-08 23:11:40 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 23:11:40 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 23:11:40 --> Helper loaded: url_helper
DEBUG - 2016-12-08 23:11:40 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 23:11:40 --> Helper loaded: file_helper
DEBUG - 2016-12-08 23:11:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 23:11:40 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 23:11:40 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 23:11:40 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 23:11:40 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 23:11:40 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 23:11:41 --> Helper loaded: common_helper
DEBUG - 2016-12-08 23:11:41 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 23:11:41 --> Helper loaded: common_helper
DEBUG - 2016-12-08 23:11:41 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 23:11:41 --> Helper loaded: form_helper
DEBUG - 2016-12-08 23:11:41 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 23:11:41 --> Helper loaded: security_helper
DEBUG - 2016-12-08 23:11:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 23:11:41 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 23:11:41 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 23:11:41 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 23:11:41 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 23:11:41 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 23:11:41 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 23:11:41 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 23:11:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 23:11:41 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 23:11:41 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 23:11:41 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 23:11:41 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 23:11:41 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 23:11:41 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 23:11:41 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 23:11:41 --> Database Driver Class Initialized
DEBUG - 2016-12-08 23:11:41 --> Session Class Initialized
DEBUG - 2016-12-08 23:11:41 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 23:11:41 --> Helper loaded: string_helper
DEBUG - 2016-12-08 23:11:41 --> Session routines successfully run
DEBUG - 2016-12-08 23:11:41 --> Native_session Class Initialized
DEBUG - 2016-12-08 23:11:41 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 23:11:41 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:11:41 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:11:41 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 23:11:41 --> Controller Class Initialized
DEBUG - 2016-12-08 23:11:41 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 23:11:41 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 23:11:41 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 23:11:41 --> Carabiner: library configured.
DEBUG - 2016-12-08 23:11:41 --> Carabiner: library configured.
DEBUG - 2016-12-08 23:11:41 --> User Agent Class Initialized
DEBUG - 2016-12-08 23:11:41 --> Model Class Initialized
DEBUG - 2016-12-08 23:11:41 --> Model Class Initialized
DEBUG - 2016-12-08 23:11:41 --> Model Class Initialized
DEBUG - 2016-12-08 23:11:41 --> Model Class Initialized
DEBUG - 2016-12-08 23:11:41 --> Model Class Initialized
DEBUG - 2016-12-08 23:11:41 --> Model Class Initialized
DEBUG - 2016-12-08 23:11:41 --> Model Class Initialized
DEBUG - 2016-12-08 23:11:41 --> Model Class Initialized
DEBUG - 2016-12-08 23:11:41 --> Model Class Initialized
DEBUG - 2016-12-08 23:11:41 --> Model Class Initialized
DEBUG - 2016-12-08 23:11:41 --> Model Class Initialized
ERROR - 2016-12-08 23:11:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:177) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
DEBUG - 2016-12-08 23:13:13 --> Config Class Initialized
DEBUG - 2016-12-08 23:13:13 --> Hooks Class Initialized
DEBUG - 2016-12-08 23:13:13 --> Utf8 Class Initialized
DEBUG - 2016-12-08 23:13:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-08 23:13:13 --> URI Class Initialized
DEBUG - 2016-12-08 23:13:13 --> Router Class Initialized
DEBUG - 2016-12-08 23:13:13 --> Output Class Initialized
DEBUG - 2016-12-08 23:13:13 --> Security Class Initialized
DEBUG - 2016-12-08 23:13:13 --> Input Class Initialized
DEBUG - 2016-12-08 23:13:13 --> XSS Filtering completed
DEBUG - 2016-12-08 23:13:13 --> XSS Filtering completed
DEBUG - 2016-12-08 23:13:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-08 23:13:13 --> Language Class Initialized
DEBUG - 2016-12-08 23:13:13 --> Loader Class Initialized
DEBUG - 2016-12-08 23:13:13 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-12-08 23:13:13 --> Check Exists url_helper.php: Yes
DEBUG - 2016-12-08 23:13:13 --> Helper loaded: url_helper
DEBUG - 2016-12-08 23:13:13 --> Check Exists file_helper.php: Yes
DEBUG - 2016-12-08 23:13:13 --> Helper loaded: file_helper
DEBUG - 2016-12-08 23:13:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 23:13:13 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-12-08 23:13:13 --> Helper loaded: conf_helper
DEBUG - 2016-12-08 23:13:13 --> Check Exists conf_helper.php: No
DEBUG - 2016-12-08 23:13:13 --> Check Exists common_helper.php: No
DEBUG - 2016-12-08 23:13:13 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-12-08 23:13:13 --> Helper loaded: common_helper
DEBUG - 2016-12-08 23:13:14 --> Check Exists common_helper.php: Yes
DEBUG - 2016-12-08 23:13:14 --> Helper loaded: common_helper
DEBUG - 2016-12-08 23:13:14 --> Check Exists form_helper.php: Yes
DEBUG - 2016-12-08 23:13:14 --> Helper loaded: form_helper
DEBUG - 2016-12-08 23:13:14 --> Check Exists security_helper.php: Yes
DEBUG - 2016-12-08 23:13:14 --> Helper loaded: security_helper
DEBUG - 2016-12-08 23:13:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 23:13:14 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-12-08 23:13:14 --> Helper loaded: lang_helper
DEBUG - 2016-12-08 23:13:14 --> Check Exists lang_helper.php: No
DEBUG - 2016-12-08 23:13:14 --> Check Exists atlant_helper.php: No
DEBUG - 2016-12-08 23:13:14 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-12-08 23:13:14 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-12-08 23:13:14 --> Helper loaded: atlant_helper
DEBUG - 2016-12-08 23:13:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 23:13:14 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-12-08 23:13:14 --> Helper loaded: crypto_helper
DEBUG - 2016-12-08 23:13:14 --> Check Exists crypto_helper.php: No
DEBUG - 2016-12-08 23:13:14 --> Check Exists sidika_helper.php: No
DEBUG - 2016-12-08 23:13:14 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-12-08 23:13:14 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-12-08 23:13:14 --> Helper loaded: sidika_helper
DEBUG - 2016-12-08 23:13:14 --> Database Driver Class Initialized
DEBUG - 2016-12-08 23:13:14 --> Session Class Initialized
DEBUG - 2016-12-08 23:13:14 --> Check Exists string_helper.php: Yes
DEBUG - 2016-12-08 23:13:14 --> Helper loaded: string_helper
DEBUG - 2016-12-08 23:13:14 --> Session routines successfully run
DEBUG - 2016-12-08 23:13:14 --> Native_session Class Initialized
DEBUG - 2016-12-08 23:13:14 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-12-08 23:13:14 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:13:14 --> Form Validation Class Initialized
DEBUG - 2016-12-08 23:13:14 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-12-08 23:13:14 --> Controller Class Initialized
DEBUG - 2016-12-08 23:13:14 --> Carabiner: Library initialized.
DEBUG - 2016-12-08 23:13:14 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-12-08 23:13:14 --> Carabiner: config loaded from config file.
DEBUG - 2016-12-08 23:13:14 --> Carabiner: library configured.
DEBUG - 2016-12-08 23:13:14 --> Carabiner: library configured.
DEBUG - 2016-12-08 23:13:14 --> User Agent Class Initialized
DEBUG - 2016-12-08 23:13:14 --> Model Class Initialized
DEBUG - 2016-12-08 23:13:14 --> Model Class Initialized
DEBUG - 2016-12-08 23:13:14 --> Model Class Initialized
DEBUG - 2016-12-08 23:13:14 --> Model Class Initialized
DEBUG - 2016-12-08 23:13:14 --> Model Class Initialized
DEBUG - 2016-12-08 23:13:14 --> Model Class Initialized
DEBUG - 2016-12-08 23:13:14 --> Model Class Initialized
DEBUG - 2016-12-08 23:13:14 --> Model Class Initialized
DEBUG - 2016-12-08 23:13:14 --> Model Class Initialized
DEBUG - 2016-12-08 23:13:14 --> Model Class Initialized
DEBUG - 2016-12-08 23:13:14 --> Model Class Initialized
ERROR - 2016-12-08 23:13:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at E:\www\lwscodeigniterwrapper\libraries\lwphpword\lwphpword.php:177) E:\www\lwscodeigniterwrapper\core\LWS_Common.php 425
