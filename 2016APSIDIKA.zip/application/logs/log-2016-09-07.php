<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-09-07 12:45:28 --> Config Class Initialized
DEBUG - 2016-09-07 12:45:28 --> Hooks Class Initialized
DEBUG - 2016-09-07 12:45:28 --> Utf8 Class Initialized
DEBUG - 2016-09-07 12:45:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 12:45:28 --> URI Class Initialized
DEBUG - 2016-09-07 12:45:28 --> Router Class Initialized
DEBUG - 2016-09-07 12:45:28 --> No URI present. Default controller set.
DEBUG - 2016-09-07 12:45:29 --> Output Class Initialized
DEBUG - 2016-09-07 12:45:29 --> Cache file has expired. File deleted
DEBUG - 2016-09-07 12:45:29 --> Security Class Initialized
DEBUG - 2016-09-07 12:45:29 --> Input Class Initialized
DEBUG - 2016-09-07 12:45:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-07 12:45:29 --> Language Class Initialized
DEBUG - 2016-09-07 12:45:29 --> Loader Class Initialized
DEBUG - 2016-09-07 12:45:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-07 12:45:29 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-07 12:45:29 --> Helper loaded: url_helper
DEBUG - 2016-09-07 12:45:29 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-07 12:45:29 --> Helper loaded: file_helper
DEBUG - 2016-09-07 12:45:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-07 12:45:29 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-07 12:45:29 --> Helper loaded: conf_helper
DEBUG - 2016-09-07 12:45:29 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-07 12:45:29 --> Check Exists common_helper.php: No
DEBUG - 2016-09-07 12:45:29 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-07 12:45:29 --> Helper loaded: common_helper
DEBUG - 2016-09-07 12:45:29 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-07 12:45:29 --> Helper loaded: common_helper
DEBUG - 2016-09-07 12:45:29 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-07 12:45:29 --> Helper loaded: form_helper
DEBUG - 2016-09-07 12:45:29 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-07 12:45:29 --> Helper loaded: security_helper
DEBUG - 2016-09-07 12:45:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-07 12:45:29 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-07 12:45:29 --> Helper loaded: lang_helper
DEBUG - 2016-09-07 12:45:29 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-07 12:45:29 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-07 12:45:29 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-07 12:45:29 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-07 12:45:29 --> Helper loaded: atlant_helper
DEBUG - 2016-09-07 12:45:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-07 12:45:29 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-07 12:45:29 --> Helper loaded: crypto_helper
DEBUG - 2016-09-07 12:45:29 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-07 12:45:29 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-07 12:45:29 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-07 12:45:29 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-07 12:45:29 --> Helper loaded: sidika_helper
DEBUG - 2016-09-07 12:45:29 --> Database Driver Class Initialized
DEBUG - 2016-09-07 12:45:29 --> Session Class Initialized
DEBUG - 2016-09-07 12:45:29 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-07 12:45:29 --> Helper loaded: string_helper
DEBUG - 2016-09-07 12:45:29 --> A session cookie was not found.
DEBUG - 2016-09-07 12:45:29 --> Session routines successfully run
DEBUG - 2016-09-07 12:45:29 --> Native_session Class Initialized
DEBUG - 2016-09-07 12:45:29 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-07 12:45:29 --> Form Validation Class Initialized
DEBUG - 2016-09-07 12:45:29 --> Form Validation Class Initialized
DEBUG - 2016-09-07 12:45:29 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-07 12:45:29 --> Controller Class Initialized
DEBUG - 2016-09-07 12:45:29 --> Carabiner: Library initialized.
DEBUG - 2016-09-07 12:45:29 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-07 12:45:29 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-07 12:45:29 --> Carabiner: library configured.
DEBUG - 2016-09-07 12:45:29 --> Carabiner: library configured.
DEBUG - 2016-09-07 12:45:29 --> User Agent Class Initialized
DEBUG - 2016-09-07 12:45:29 --> Model Class Initialized
DEBUG - 2016-09-07 12:45:29 --> Model Class Initialized
DEBUG - 2016-09-07 12:45:29 --> Model Class Initialized
ERROR - 2016-09-07 12:45:30 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-07 12:45:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-07 12:45:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-07 12:45:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-07 12:45:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-07 12:45:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-07 12:45:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-07 12:45:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-07 12:45:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-07 12:45:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-07 12:45:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-07 12:45:30 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-07 12:45:30 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-07 12:45:30 --> Final output sent to browser
DEBUG - 2016-09-07 12:45:30 --> Total execution time: 1.9031
DEBUG - 2016-09-07 14:03:01 --> Config Class Initialized
DEBUG - 2016-09-07 14:03:01 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:03:01 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:03:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:03:01 --> URI Class Initialized
DEBUG - 2016-09-07 14:03:01 --> Router Class Initialized
DEBUG - 2016-09-07 14:03:01 --> No URI present. Default controller set.
DEBUG - 2016-09-07 14:03:01 --> Output Class Initialized
DEBUG - 2016-09-07 14:03:01 --> Cache file has expired. File deleted
DEBUG - 2016-09-07 14:03:01 --> Security Class Initialized
DEBUG - 2016-09-07 14:03:01 --> Input Class Initialized
DEBUG - 2016-09-07 14:03:01 --> XSS Filtering completed
DEBUG - 2016-09-07 14:03:01 --> XSS Filtering completed
DEBUG - 2016-09-07 14:03:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-07 14:03:01 --> Language Class Initialized
DEBUG - 2016-09-07 14:03:01 --> Loader Class Initialized
DEBUG - 2016-09-07 14:03:01 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-07 14:03:01 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-07 14:03:01 --> Helper loaded: url_helper
DEBUG - 2016-09-07 14:03:01 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-07 14:03:01 --> Helper loaded: file_helper
DEBUG - 2016-09-07 14:03:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-07 14:03:01 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-07 14:03:01 --> Helper loaded: conf_helper
DEBUG - 2016-09-07 14:03:01 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-07 14:03:01 --> Check Exists common_helper.php: No
DEBUG - 2016-09-07 14:03:01 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-07 14:03:01 --> Helper loaded: common_helper
DEBUG - 2016-09-07 14:03:02 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-07 14:03:02 --> Helper loaded: common_helper
DEBUG - 2016-09-07 14:03:02 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-07 14:03:02 --> Helper loaded: form_helper
DEBUG - 2016-09-07 14:03:02 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-07 14:03:02 --> Helper loaded: security_helper
DEBUG - 2016-09-07 14:03:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-07 14:03:02 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-07 14:03:02 --> Helper loaded: lang_helper
DEBUG - 2016-09-07 14:03:02 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-07 14:03:02 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-07 14:03:02 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-07 14:03:02 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-07 14:03:02 --> Helper loaded: atlant_helper
DEBUG - 2016-09-07 14:03:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-07 14:03:02 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-07 14:03:02 --> Helper loaded: crypto_helper
DEBUG - 2016-09-07 14:03:02 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-07 14:03:02 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-07 14:03:02 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-07 14:03:02 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-07 14:03:02 --> Helper loaded: sidika_helper
DEBUG - 2016-09-07 14:03:02 --> Database Driver Class Initialized
DEBUG - 2016-09-07 14:03:02 --> Session Class Initialized
DEBUG - 2016-09-07 14:03:02 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-07 14:03:02 --> Helper loaded: string_helper
DEBUG - 2016-09-07 14:03:02 --> Session routines successfully run
DEBUG - 2016-09-07 14:03:02 --> Native_session Class Initialized
DEBUG - 2016-09-07 14:03:02 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-07 14:03:02 --> Form Validation Class Initialized
DEBUG - 2016-09-07 14:03:02 --> Form Validation Class Initialized
DEBUG - 2016-09-07 14:03:02 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-07 14:03:02 --> Controller Class Initialized
DEBUG - 2016-09-07 14:03:02 --> Carabiner: Library initialized.
DEBUG - 2016-09-07 14:03:02 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-07 14:03:02 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-07 14:03:02 --> Carabiner: library configured.
DEBUG - 2016-09-07 14:03:02 --> Carabiner: library configured.
DEBUG - 2016-09-07 14:03:02 --> User Agent Class Initialized
DEBUG - 2016-09-07 14:03:02 --> Model Class Initialized
DEBUG - 2016-09-07 14:03:02 --> Model Class Initialized
DEBUG - 2016-09-07 14:03:02 --> Model Class Initialized
ERROR - 2016-09-07 14:03:02 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-07 14:03:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-07 14:03:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-07 14:03:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-07 14:03:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-07 14:03:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-07 14:03:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-07 14:03:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-07 14:03:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-07 14:03:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-07 14:03:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-07 14:03:02 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-07 14:03:02 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-07 14:03:02 --> Final output sent to browser
DEBUG - 2016-09-07 14:03:02 --> Total execution time: 0.3839
DEBUG - 2016-09-07 14:03:06 --> Config Class Initialized
DEBUG - 2016-09-07 14:03:06 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:03:06 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:03:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:03:06 --> URI Class Initialized
DEBUG - 2016-09-07 14:03:06 --> Router Class Initialized
DEBUG - 2016-09-07 14:03:06 --> No URI present. Default controller set.
DEBUG - 2016-09-07 14:03:06 --> Output Class Initialized
DEBUG - 2016-09-07 14:03:06 --> Cache file has expired. File deleted
DEBUG - 2016-09-07 14:03:06 --> Security Class Initialized
DEBUG - 2016-09-07 14:03:06 --> Input Class Initialized
DEBUG - 2016-09-07 14:03:06 --> XSS Filtering completed
DEBUG - 2016-09-07 14:03:06 --> XSS Filtering completed
DEBUG - 2016-09-07 14:03:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-07 14:03:06 --> Language Class Initialized
DEBUG - 2016-09-07 14:03:06 --> Loader Class Initialized
DEBUG - 2016-09-07 14:03:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-07 14:03:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-07 14:03:06 --> Helper loaded: url_helper
DEBUG - 2016-09-07 14:03:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-07 14:03:06 --> Helper loaded: file_helper
DEBUG - 2016-09-07 14:03:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-07 14:03:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-07 14:03:06 --> Helper loaded: conf_helper
DEBUG - 2016-09-07 14:03:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-07 14:03:06 --> Check Exists common_helper.php: No
DEBUG - 2016-09-07 14:03:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-07 14:03:06 --> Helper loaded: common_helper
DEBUG - 2016-09-07 14:03:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-07 14:03:06 --> Helper loaded: common_helper
DEBUG - 2016-09-07 14:03:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-07 14:03:06 --> Helper loaded: form_helper
DEBUG - 2016-09-07 14:03:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-07 14:03:06 --> Helper loaded: security_helper
DEBUG - 2016-09-07 14:03:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-07 14:03:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-07 14:03:06 --> Helper loaded: lang_helper
DEBUG - 2016-09-07 14:03:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-07 14:03:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-07 14:03:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-07 14:03:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-07 14:03:06 --> Helper loaded: atlant_helper
DEBUG - 2016-09-07 14:03:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-07 14:03:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-07 14:03:06 --> Helper loaded: crypto_helper
DEBUG - 2016-09-07 14:03:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-07 14:03:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-07 14:03:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-07 14:03:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-07 14:03:06 --> Helper loaded: sidika_helper
DEBUG - 2016-09-07 14:03:06 --> Database Driver Class Initialized
DEBUG - 2016-09-07 14:03:07 --> Session Class Initialized
DEBUG - 2016-09-07 14:03:07 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-07 14:03:07 --> Helper loaded: string_helper
DEBUG - 2016-09-07 14:03:07 --> Session routines successfully run
DEBUG - 2016-09-07 14:03:07 --> Native_session Class Initialized
DEBUG - 2016-09-07 14:03:07 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-07 14:03:07 --> Form Validation Class Initialized
DEBUG - 2016-09-07 14:03:07 --> Form Validation Class Initialized
DEBUG - 2016-09-07 14:03:07 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-07 14:03:07 --> Controller Class Initialized
DEBUG - 2016-09-07 14:03:07 --> Carabiner: Library initialized.
DEBUG - 2016-09-07 14:03:07 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-07 14:03:07 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-07 14:03:07 --> Carabiner: library configured.
DEBUG - 2016-09-07 14:03:07 --> Carabiner: library configured.
DEBUG - 2016-09-07 14:03:07 --> User Agent Class Initialized
DEBUG - 2016-09-07 14:03:07 --> Model Class Initialized
DEBUG - 2016-09-07 14:03:07 --> Model Class Initialized
DEBUG - 2016-09-07 14:03:07 --> Model Class Initialized
ERROR - 2016-09-07 14:03:07 --> Hak Akses modul/kontroller 'home' untuk role 'unkown' belum di set.
DEBUG - 2016-09-07 14:03:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/front_end/home/index.php
DEBUG - 2016-09-07 14:03:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-07 14:03:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-07 14:03:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-07 14:03:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-07 14:03:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-07 14:03:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/menu.php
DEBUG - 2016-09-07 14:03:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-07 14:03:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/breadcrumb.php
DEBUG - 2016-09-07 14:03:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend/footer.php
DEBUG - 2016-09-07 14:03:07 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_frontend.php
DEBUG - 2016-09-07 14:03:07 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/046a57e0b21501b94d9b0e2e68951869
DEBUG - 2016-09-07 14:03:07 --> Final output sent to browser
DEBUG - 2016-09-07 14:03:07 --> Total execution time: 0.2519
DEBUG - 2016-09-07 14:03:09 --> Config Class Initialized
DEBUG - 2016-09-07 14:03:09 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:03:09 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:03:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:03:09 --> URI Class Initialized
DEBUG - 2016-09-07 14:03:09 --> Router Class Initialized
DEBUG - 2016-09-07 14:03:09 --> Output Class Initialized
DEBUG - 2016-09-07 14:03:09 --> Cache file has expired. File deleted
DEBUG - 2016-09-07 14:03:09 --> Security Class Initialized
DEBUG - 2016-09-07 14:03:09 --> Input Class Initialized
DEBUG - 2016-09-07 14:03:09 --> XSS Filtering completed
DEBUG - 2016-09-07 14:03:09 --> XSS Filtering completed
DEBUG - 2016-09-07 14:03:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-07 14:03:09 --> Language Class Initialized
ERROR - 2016-09-07 14:03:09 --> 404 Page Not Found --> 
DEBUG - 2016-09-07 14:03:09 --> Config Class Initialized
DEBUG - 2016-09-07 14:03:09 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:03:09 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:03:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:03:09 --> URI Class Initialized
DEBUG - 2016-09-07 14:03:09 --> Router Class Initialized
ERROR - 2016-09-07 14:03:09 --> 404 Page Not Found --> img
DEBUG - 2016-09-07 14:03:09 --> Config Class Initialized
DEBUG - 2016-09-07 14:03:09 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:03:09 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:03:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:03:09 --> URI Class Initialized
DEBUG - 2016-09-07 14:03:09 --> Router Class Initialized
ERROR - 2016-09-07 14:03:09 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-09-07 14:03:12 --> Config Class Initialized
DEBUG - 2016-09-07 14:03:12 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:03:12 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:03:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:03:12 --> URI Class Initialized
DEBUG - 2016-09-07 14:03:12 --> Router Class Initialized
DEBUG - 2016-09-07 14:03:12 --> Output Class Initialized
DEBUG - 2016-09-07 14:03:12 --> Security Class Initialized
DEBUG - 2016-09-07 14:03:12 --> Input Class Initialized
DEBUG - 2016-09-07 14:03:12 --> XSS Filtering completed
DEBUG - 2016-09-07 14:03:12 --> XSS Filtering completed
DEBUG - 2016-09-07 14:03:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-07 14:03:12 --> Language Class Initialized
ERROR - 2016-09-07 14:03:12 --> 404 Page Not Found --> 
DEBUG - 2016-09-07 14:03:12 --> Config Class Initialized
DEBUG - 2016-09-07 14:03:12 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:03:12 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:03:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:03:12 --> URI Class Initialized
DEBUG - 2016-09-07 14:03:12 --> Router Class Initialized
ERROR - 2016-09-07 14:03:12 --> 404 Page Not Found --> img
DEBUG - 2016-09-07 14:03:17 --> Config Class Initialized
DEBUG - 2016-09-07 14:03:17 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:03:17 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:03:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:03:17 --> URI Class Initialized
DEBUG - 2016-09-07 14:03:17 --> Router Class Initialized
DEBUG - 2016-09-07 14:03:17 --> Output Class Initialized
DEBUG - 2016-09-07 14:03:17 --> Security Class Initialized
DEBUG - 2016-09-07 14:03:17 --> Input Class Initialized
DEBUG - 2016-09-07 14:03:17 --> XSS Filtering completed
DEBUG - 2016-09-07 14:03:17 --> XSS Filtering completed
DEBUG - 2016-09-07 14:03:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-07 14:03:17 --> Language Class Initialized
ERROR - 2016-09-07 14:03:17 --> 404 Page Not Found --> 
DEBUG - 2016-09-07 14:03:17 --> Config Class Initialized
DEBUG - 2016-09-07 14:03:17 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:03:17 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:03:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:03:17 --> URI Class Initialized
DEBUG - 2016-09-07 14:03:17 --> Router Class Initialized
ERROR - 2016-09-07 14:03:17 --> 404 Page Not Found --> img
DEBUG - 2016-09-07 14:03:22 --> Config Class Initialized
DEBUG - 2016-09-07 14:03:22 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:03:22 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:03:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:03:22 --> URI Class Initialized
DEBUG - 2016-09-07 14:03:22 --> Router Class Initialized
DEBUG - 2016-09-07 14:03:22 --> Output Class Initialized
DEBUG - 2016-09-07 14:03:22 --> Cache file has expired. File deleted
DEBUG - 2016-09-07 14:03:22 --> Security Class Initialized
DEBUG - 2016-09-07 14:03:22 --> Input Class Initialized
DEBUG - 2016-09-07 14:03:22 --> XSS Filtering completed
DEBUG - 2016-09-07 14:03:22 --> XSS Filtering completed
DEBUG - 2016-09-07 14:03:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-07 14:03:22 --> Language Class Initialized
ERROR - 2016-09-07 14:03:22 --> Severity: Warning  --> include_once(cpustaka_data.php): failed to open stream: No such file or directory E:\www\GitHub\2016APSIDIKA\application\controllers\back_end\cdaftar_diklat.php 6
ERROR - 2016-09-07 14:03:22 --> Severity: Warning  --> include_once(): Failed opening 'cpustaka_data.php' for inclusion (include_path='.;C:\php\pear') E:\www\GitHub\2016APSIDIKA\application\controllers\back_end\cdaftar_diklat.php 6
DEBUG - 2016-09-07 14:03:22 --> Loader Class Initialized
DEBUG - 2016-09-07 14:03:22 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-07 14:03:22 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-07 14:03:22 --> Helper loaded: url_helper
DEBUG - 2016-09-07 14:03:22 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-07 14:03:22 --> Helper loaded: file_helper
DEBUG - 2016-09-07 14:03:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-07 14:03:22 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-07 14:03:22 --> Helper loaded: conf_helper
DEBUG - 2016-09-07 14:03:22 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-07 14:03:22 --> Check Exists common_helper.php: No
DEBUG - 2016-09-07 14:03:22 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-07 14:03:23 --> Helper loaded: common_helper
DEBUG - 2016-09-07 14:03:23 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-07 14:03:23 --> Helper loaded: common_helper
DEBUG - 2016-09-07 14:03:23 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-07 14:03:23 --> Helper loaded: form_helper
DEBUG - 2016-09-07 14:03:23 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-07 14:03:23 --> Helper loaded: security_helper
DEBUG - 2016-09-07 14:03:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-07 14:03:23 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-07 14:03:23 --> Helper loaded: lang_helper
DEBUG - 2016-09-07 14:03:23 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-07 14:03:23 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-07 14:03:23 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-07 14:03:23 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-07 14:03:23 --> Helper loaded: atlant_helper
DEBUG - 2016-09-07 14:03:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-07 14:03:23 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-07 14:03:23 --> Helper loaded: crypto_helper
DEBUG - 2016-09-07 14:03:23 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-07 14:03:23 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-07 14:03:23 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-07 14:03:23 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-07 14:03:23 --> Helper loaded: sidika_helper
DEBUG - 2016-09-07 14:03:23 --> Database Driver Class Initialized
DEBUG - 2016-09-07 14:03:23 --> Session Class Initialized
DEBUG - 2016-09-07 14:03:23 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-07 14:03:23 --> Helper loaded: string_helper
DEBUG - 2016-09-07 14:03:23 --> Session routines successfully run
DEBUG - 2016-09-07 14:03:23 --> Native_session Class Initialized
DEBUG - 2016-09-07 14:03:23 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-07 14:03:23 --> Form Validation Class Initialized
DEBUG - 2016-09-07 14:03:23 --> Form Validation Class Initialized
DEBUG - 2016-09-07 14:03:23 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-07 14:03:23 --> Controller Class Initialized
DEBUG - 2016-09-07 14:03:23 --> Carabiner: Library initialized.
DEBUG - 2016-09-07 14:03:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-07 14:03:23 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-07 14:03:23 --> Carabiner: library configured.
DEBUG - 2016-09-07 14:03:23 --> Carabiner: library configured.
DEBUG - 2016-09-07 14:03:23 --> User Agent Class Initialized
DEBUG - 2016-09-07 14:03:23 --> Model Class Initialized
DEBUG - 2016-09-07 14:03:23 --> Model Class Initialized
DEBUG - 2016-09-07 14:03:23 --> Model Class Initialized
DEBUG - 2016-09-07 14:03:23 --> Model Class Initialized
DEBUG - 2016-09-07 14:03:23 --> Model Class Initialized
DEBUG - 2016-09-07 14:03:23 --> Model Class Initialized
DEBUG - 2016-09-07 14:03:23 --> Model Class Initialized
DEBUG - 2016-09-07 14:03:23 --> Model Class Initialized
ERROR - 2016-09-07 14:03:23 --> Hak Akses modul/kontroller 'cdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-07 14:03:23 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-07 14:03:23 --> Pagination Class Initialized
DEBUG - 2016-09-07 14:03:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-07 14:03:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-07 14:03:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-07 14:03:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/menu/template_menu.php
DEBUG - 2016-09-07 14:03:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-07 14:03:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-07 14:03:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/default.php
DEBUG - 2016-09-07 14:03:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-07 14:03:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/menu/template_menu.php
DEBUG - 2016-09-07 14:03:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-07 14:03:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-07 14:03:23 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/default.php
DEBUG - 2016-09-07 14:03:23 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-07 14:03:23 --> Final output sent to browser
DEBUG - 2016-09-07 14:03:23 --> Total execution time: 0.8863
DEBUG - 2016-09-07 14:04:10 --> Config Class Initialized
DEBUG - 2016-09-07 14:04:10 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:04:10 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:04:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:04:10 --> URI Class Initialized
DEBUG - 2016-09-07 14:04:10 --> Router Class Initialized
DEBUG - 2016-09-07 14:04:10 --> Output Class Initialized
DEBUG - 2016-09-07 14:04:10 --> Cache file has expired. File deleted
DEBUG - 2016-09-07 14:04:10 --> Security Class Initialized
DEBUG - 2016-09-07 14:04:10 --> Input Class Initialized
DEBUG - 2016-09-07 14:04:10 --> XSS Filtering completed
DEBUG - 2016-09-07 14:04:10 --> XSS Filtering completed
DEBUG - 2016-09-07 14:04:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-07 14:04:10 --> Language Class Initialized
ERROR - 2016-09-07 14:04:10 --> 404 Page Not Found --> 
DEBUG - 2016-09-07 14:04:11 --> Config Class Initialized
DEBUG - 2016-09-07 14:04:11 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:04:11 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:04:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:04:11 --> URI Class Initialized
DEBUG - 2016-09-07 14:04:11 --> Router Class Initialized
ERROR - 2016-09-07 14:04:11 --> 404 Page Not Found --> img
DEBUG - 2016-09-07 14:04:11 --> Config Class Initialized
DEBUG - 2016-09-07 14:04:11 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:04:11 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:04:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:04:11 --> URI Class Initialized
DEBUG - 2016-09-07 14:04:11 --> Router Class Initialized
ERROR - 2016-09-07 14:04:11 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-09-07 14:04:13 --> Config Class Initialized
DEBUG - 2016-09-07 14:04:13 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:04:13 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:04:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:04:13 --> URI Class Initialized
DEBUG - 2016-09-07 14:04:13 --> Router Class Initialized
DEBUG - 2016-09-07 14:04:13 --> Output Class Initialized
DEBUG - 2016-09-07 14:04:13 --> Security Class Initialized
DEBUG - 2016-09-07 14:04:13 --> Input Class Initialized
DEBUG - 2016-09-07 14:04:13 --> XSS Filtering completed
DEBUG - 2016-09-07 14:04:13 --> XSS Filtering completed
DEBUG - 2016-09-07 14:04:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-07 14:04:13 --> Language Class Initialized
ERROR - 2016-09-07 14:04:13 --> 404 Page Not Found --> 
DEBUG - 2016-09-07 14:04:13 --> Config Class Initialized
DEBUG - 2016-09-07 14:04:13 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:04:13 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:04:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:04:13 --> URI Class Initialized
DEBUG - 2016-09-07 14:04:13 --> Router Class Initialized
ERROR - 2016-09-07 14:04:13 --> 404 Page Not Found --> img
DEBUG - 2016-09-07 14:10:52 --> Config Class Initialized
DEBUG - 2016-09-07 14:10:52 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:10:52 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:10:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:10:52 --> URI Class Initialized
DEBUG - 2016-09-07 14:10:52 --> Router Class Initialized
DEBUG - 2016-09-07 14:10:52 --> Output Class Initialized
DEBUG - 2016-09-07 14:10:52 --> Security Class Initialized
DEBUG - 2016-09-07 14:10:52 --> Input Class Initialized
DEBUG - 2016-09-07 14:10:52 --> XSS Filtering completed
DEBUG - 2016-09-07 14:10:52 --> XSS Filtering completed
DEBUG - 2016-09-07 14:10:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-07 14:10:52 --> Language Class Initialized
ERROR - 2016-09-07 14:10:52 --> 404 Page Not Found --> 
DEBUG - 2016-09-07 14:10:52 --> Config Class Initialized
DEBUG - 2016-09-07 14:10:52 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:10:52 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:10:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:10:52 --> URI Class Initialized
DEBUG - 2016-09-07 14:10:52 --> Router Class Initialized
ERROR - 2016-09-07 14:10:52 --> 404 Page Not Found --> img
DEBUG - 2016-09-07 14:10:52 --> Config Class Initialized
DEBUG - 2016-09-07 14:10:52 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:10:52 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:10:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:10:52 --> URI Class Initialized
DEBUG - 2016-09-07 14:10:52 --> Router Class Initialized
ERROR - 2016-09-07 14:10:52 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-09-07 14:15:27 --> Config Class Initialized
DEBUG - 2016-09-07 14:15:27 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:15:27 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:15:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:15:27 --> URI Class Initialized
DEBUG - 2016-09-07 14:15:27 --> Router Class Initialized
DEBUG - 2016-09-07 14:15:27 --> Output Class Initialized
DEBUG - 2016-09-07 14:15:27 --> Security Class Initialized
DEBUG - 2016-09-07 14:15:27 --> Input Class Initialized
DEBUG - 2016-09-07 14:15:27 --> XSS Filtering completed
DEBUG - 2016-09-07 14:15:27 --> XSS Filtering completed
DEBUG - 2016-09-07 14:15:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-07 14:15:27 --> Language Class Initialized
ERROR - 2016-09-07 14:15:27 --> 404 Page Not Found --> 
DEBUG - 2016-09-07 14:15:27 --> Config Class Initialized
DEBUG - 2016-09-07 14:15:27 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:15:27 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:15:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:15:27 --> URI Class Initialized
DEBUG - 2016-09-07 14:15:27 --> Router Class Initialized
ERROR - 2016-09-07 14:15:27 --> 404 Page Not Found --> img
DEBUG - 2016-09-07 14:15:29 --> Config Class Initialized
DEBUG - 2016-09-07 14:15:29 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:15:29 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:15:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:15:29 --> URI Class Initialized
DEBUG - 2016-09-07 14:15:29 --> Router Class Initialized
DEBUG - 2016-09-07 14:15:29 --> Output Class Initialized
DEBUG - 2016-09-07 14:15:29 --> Security Class Initialized
DEBUG - 2016-09-07 14:15:29 --> Input Class Initialized
DEBUG - 2016-09-07 14:15:29 --> XSS Filtering completed
DEBUG - 2016-09-07 14:15:29 --> XSS Filtering completed
DEBUG - 2016-09-07 14:15:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-07 14:15:29 --> Language Class Initialized
ERROR - 2016-09-07 14:15:30 --> 404 Page Not Found --> 
DEBUG - 2016-09-07 14:15:30 --> Config Class Initialized
DEBUG - 2016-09-07 14:15:30 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:15:30 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:15:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:15:30 --> URI Class Initialized
DEBUG - 2016-09-07 14:15:30 --> Router Class Initialized
ERROR - 2016-09-07 14:15:30 --> 404 Page Not Found --> img
DEBUG - 2016-09-07 14:15:30 --> Config Class Initialized
DEBUG - 2016-09-07 14:15:30 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:15:30 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:15:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:15:30 --> URI Class Initialized
DEBUG - 2016-09-07 14:15:30 --> Router Class Initialized
ERROR - 2016-09-07 14:15:30 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-09-07 14:27:54 --> Config Class Initialized
DEBUG - 2016-09-07 14:27:54 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:27:54 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:27:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:27:54 --> URI Class Initialized
DEBUG - 2016-09-07 14:27:54 --> Router Class Initialized
DEBUG - 2016-09-07 14:27:54 --> Output Class Initialized
DEBUG - 2016-09-07 14:27:54 --> Security Class Initialized
DEBUG - 2016-09-07 14:27:54 --> Input Class Initialized
DEBUG - 2016-09-07 14:27:54 --> XSS Filtering completed
DEBUG - 2016-09-07 14:27:54 --> XSS Filtering completed
DEBUG - 2016-09-07 14:27:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-07 14:27:54 --> Language Class Initialized
ERROR - 2016-09-07 14:27:54 --> 404 Page Not Found --> 
DEBUG - 2016-09-07 14:27:54 --> Config Class Initialized
DEBUG - 2016-09-07 14:27:54 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:27:54 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:27:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:27:54 --> URI Class Initialized
DEBUG - 2016-09-07 14:27:54 --> Router Class Initialized
ERROR - 2016-09-07 14:27:54 --> 404 Page Not Found --> img
DEBUG - 2016-09-07 14:27:54 --> Config Class Initialized
DEBUG - 2016-09-07 14:27:54 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:27:54 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:27:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:27:54 --> URI Class Initialized
DEBUG - 2016-09-07 14:27:54 --> Router Class Initialized
ERROR - 2016-09-07 14:27:54 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-09-07 14:27:57 --> Config Class Initialized
DEBUG - 2016-09-07 14:27:57 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:27:57 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:27:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:27:57 --> URI Class Initialized
DEBUG - 2016-09-07 14:27:57 --> Router Class Initialized
DEBUG - 2016-09-07 14:27:57 --> Output Class Initialized
DEBUG - 2016-09-07 14:27:57 --> Security Class Initialized
DEBUG - 2016-09-07 14:27:57 --> Input Class Initialized
DEBUG - 2016-09-07 14:27:57 --> XSS Filtering completed
DEBUG - 2016-09-07 14:27:57 --> XSS Filtering completed
DEBUG - 2016-09-07 14:27:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-07 14:27:57 --> Language Class Initialized
ERROR - 2016-09-07 14:27:57 --> 404 Page Not Found --> 
DEBUG - 2016-09-07 14:27:57 --> Config Class Initialized
DEBUG - 2016-09-07 14:27:57 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:27:57 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:27:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:27:57 --> URI Class Initialized
DEBUG - 2016-09-07 14:27:57 --> Router Class Initialized
ERROR - 2016-09-07 14:27:57 --> 404 Page Not Found --> img
DEBUG - 2016-09-07 14:27:57 --> Config Class Initialized
DEBUG - 2016-09-07 14:27:57 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:27:57 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:27:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:27:57 --> URI Class Initialized
DEBUG - 2016-09-07 14:27:57 --> Router Class Initialized
ERROR - 2016-09-07 14:27:57 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-09-07 14:28:53 --> Config Class Initialized
DEBUG - 2016-09-07 14:28:53 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:28:53 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:28:53 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:28:53 --> URI Class Initialized
DEBUG - 2016-09-07 14:28:53 --> Router Class Initialized
DEBUG - 2016-09-07 14:28:53 --> Output Class Initialized
DEBUG - 2016-09-07 14:28:53 --> Security Class Initialized
DEBUG - 2016-09-07 14:28:53 --> Input Class Initialized
DEBUG - 2016-09-07 14:28:53 --> XSS Filtering completed
DEBUG - 2016-09-07 14:28:53 --> XSS Filtering completed
DEBUG - 2016-09-07 14:28:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-07 14:28:53 --> Language Class Initialized
DEBUG - 2016-09-07 14:28:53 --> Loader Class Initialized
DEBUG - 2016-09-07 14:28:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-07 14:28:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-07 14:28:53 --> Helper loaded: url_helper
DEBUG - 2016-09-07 14:28:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-07 14:28:53 --> Helper loaded: file_helper
DEBUG - 2016-09-07 14:28:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-07 14:28:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-07 14:28:53 --> Helper loaded: conf_helper
DEBUG - 2016-09-07 14:28:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-07 14:28:53 --> Check Exists common_helper.php: No
DEBUG - 2016-09-07 14:28:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-07 14:28:53 --> Helper loaded: common_helper
DEBUG - 2016-09-07 14:28:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-07 14:28:53 --> Helper loaded: common_helper
DEBUG - 2016-09-07 14:28:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-07 14:28:53 --> Helper loaded: form_helper
DEBUG - 2016-09-07 14:28:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-07 14:28:53 --> Helper loaded: security_helper
DEBUG - 2016-09-07 14:28:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-07 14:28:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-07 14:28:53 --> Helper loaded: lang_helper
DEBUG - 2016-09-07 14:28:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-07 14:28:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-07 14:28:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-07 14:28:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-07 14:28:53 --> Helper loaded: atlant_helper
DEBUG - 2016-09-07 14:28:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-07 14:28:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-07 14:28:54 --> Helper loaded: crypto_helper
DEBUG - 2016-09-07 14:28:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-07 14:28:54 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-07 14:28:54 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-07 14:28:54 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-07 14:28:54 --> Helper loaded: sidika_helper
DEBUG - 2016-09-07 14:28:54 --> Database Driver Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Session Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-07 14:28:54 --> Helper loaded: string_helper
DEBUG - 2016-09-07 14:28:54 --> Session routines successfully run
DEBUG - 2016-09-07 14:28:54 --> Native_session Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-07 14:28:54 --> Form Validation Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Form Validation Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-07 14:28:54 --> Controller Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Carabiner: Library initialized.
DEBUG - 2016-09-07 14:28:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-07 14:28:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-07 14:28:54 --> Carabiner: library configured.
DEBUG - 2016-09-07 14:28:54 --> Carabiner: library configured.
DEBUG - 2016-09-07 14:28:54 --> User Agent Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Model Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Model Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Model Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Model Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Model Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Model Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Model Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Model Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Model Class Initialized
ERROR - 2016-09-07 14:28:54 --> Hak Akses modul/kontroller 'cdaftar_diklat' untuk role 'unkown' belum di set.
DEBUG - 2016-09-07 14:28:54 --> Config Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:28:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:28:54 --> URI Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Router Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Output Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Security Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Input Class Initialized
DEBUG - 2016-09-07 14:28:54 --> XSS Filtering completed
DEBUG - 2016-09-07 14:28:54 --> XSS Filtering completed
DEBUG - 2016-09-07 14:28:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-07 14:28:54 --> Language Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Loader Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-07 14:28:54 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-07 14:28:54 --> Helper loaded: url_helper
DEBUG - 2016-09-07 14:28:54 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-07 14:28:54 --> Helper loaded: file_helper
DEBUG - 2016-09-07 14:28:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-07 14:28:54 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-07 14:28:54 --> Helper loaded: conf_helper
DEBUG - 2016-09-07 14:28:54 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-07 14:28:54 --> Check Exists common_helper.php: No
DEBUG - 2016-09-07 14:28:54 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-07 14:28:54 --> Helper loaded: common_helper
DEBUG - 2016-09-07 14:28:54 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-07 14:28:54 --> Helper loaded: common_helper
DEBUG - 2016-09-07 14:28:54 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-07 14:28:54 --> Helper loaded: form_helper
DEBUG - 2016-09-07 14:28:54 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-07 14:28:54 --> Helper loaded: security_helper
DEBUG - 2016-09-07 14:28:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-07 14:28:54 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-07 14:28:54 --> Helper loaded: lang_helper
DEBUG - 2016-09-07 14:28:54 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-07 14:28:54 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-07 14:28:54 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-07 14:28:54 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-07 14:28:54 --> Helper loaded: atlant_helper
DEBUG - 2016-09-07 14:28:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-07 14:28:54 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-07 14:28:54 --> Helper loaded: crypto_helper
DEBUG - 2016-09-07 14:28:54 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-07 14:28:54 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-07 14:28:54 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-07 14:28:54 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-07 14:28:54 --> Helper loaded: sidika_helper
DEBUG - 2016-09-07 14:28:54 --> Database Driver Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Session Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-07 14:28:54 --> Helper loaded: string_helper
DEBUG - 2016-09-07 14:28:54 --> Session routines successfully run
DEBUG - 2016-09-07 14:28:54 --> Native_session Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-07 14:28:54 --> Form Validation Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Form Validation Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-07 14:28:54 --> Controller Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Carabiner: Library initialized.
DEBUG - 2016-09-07 14:28:54 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-07 14:28:54 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-07 14:28:54 --> Carabiner: library configured.
DEBUG - 2016-09-07 14:28:54 --> Carabiner: library configured.
DEBUG - 2016-09-07 14:28:54 --> User Agent Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Model Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Model Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Model Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Model Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Model Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Model Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Model Class Initialized
DEBUG - 2016-09-07 14:28:54 --> Model Class Initialized
ERROR - 2016-09-07 14:28:54 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-07 14:28:54 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/shared/attention_message.php
DEBUG - 2016-09-07 14:28:54 --> File loaded: E:\www\lwscodeigniterwrapper\views/back_bone/member/atlant_login/login.php
DEBUG - 2016-09-07 14:28:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-07 14:28:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-07 14:28:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_css.php
DEBUG - 2016-09-07 14:28:54 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant_login.php
DEBUG - 2016-09-07 14:28:54 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/ccfa3f9a5576a9844cd9cebbfe445ad3
DEBUG - 2016-09-07 14:28:54 --> Final output sent to browser
DEBUG - 2016-09-07 14:28:54 --> Total execution time: 0.3848
DEBUG - 2016-09-07 14:28:55 --> Config Class Initialized
DEBUG - 2016-09-07 14:28:55 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:28:55 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:28:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:28:55 --> URI Class Initialized
DEBUG - 2016-09-07 14:28:55 --> Router Class Initialized
ERROR - 2016-09-07 14:28:55 --> 404 Page Not Found --> back_bone/favicon.ico
DEBUG - 2016-09-07 14:29:05 --> Config Class Initialized
DEBUG - 2016-09-07 14:29:05 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:29:05 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:29:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:29:05 --> URI Class Initialized
DEBUG - 2016-09-07 14:29:05 --> Router Class Initialized
DEBUG - 2016-09-07 14:29:05 --> Output Class Initialized
DEBUG - 2016-09-07 14:29:05 --> Cache file has expired. File deleted
DEBUG - 2016-09-07 14:29:05 --> Security Class Initialized
DEBUG - 2016-09-07 14:29:05 --> Input Class Initialized
DEBUG - 2016-09-07 14:29:05 --> XSS Filtering completed
DEBUG - 2016-09-07 14:29:05 --> XSS Filtering completed
DEBUG - 2016-09-07 14:29:05 --> XSS Filtering completed
DEBUG - 2016-09-07 14:29:05 --> XSS Filtering completed
DEBUG - 2016-09-07 14:29:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-07 14:29:05 --> Language Class Initialized
DEBUG - 2016-09-07 14:29:05 --> Loader Class Initialized
DEBUG - 2016-09-07 14:29:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-07 14:29:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-07 14:29:05 --> Helper loaded: url_helper
DEBUG - 2016-09-07 14:29:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-07 14:29:05 --> Helper loaded: file_helper
DEBUG - 2016-09-07 14:29:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-07 14:29:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-07 14:29:06 --> Helper loaded: conf_helper
DEBUG - 2016-09-07 14:29:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-07 14:29:06 --> Check Exists common_helper.php: No
DEBUG - 2016-09-07 14:29:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-07 14:29:06 --> Helper loaded: common_helper
DEBUG - 2016-09-07 14:29:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-07 14:29:06 --> Helper loaded: common_helper
DEBUG - 2016-09-07 14:29:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-07 14:29:06 --> Helper loaded: form_helper
DEBUG - 2016-09-07 14:29:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-07 14:29:06 --> Helper loaded: security_helper
DEBUG - 2016-09-07 14:29:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-07 14:29:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-07 14:29:06 --> Helper loaded: lang_helper
DEBUG - 2016-09-07 14:29:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-07 14:29:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-07 14:29:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-07 14:29:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-07 14:29:06 --> Helper loaded: atlant_helper
DEBUG - 2016-09-07 14:29:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-07 14:29:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-07 14:29:06 --> Helper loaded: crypto_helper
DEBUG - 2016-09-07 14:29:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-07 14:29:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-07 14:29:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-07 14:29:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-07 14:29:06 --> Helper loaded: sidika_helper
DEBUG - 2016-09-07 14:29:06 --> Database Driver Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Session Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-07 14:29:06 --> Helper loaded: string_helper
DEBUG - 2016-09-07 14:29:06 --> Session routines successfully run
DEBUG - 2016-09-07 14:29:06 --> Native_session Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-07 14:29:06 --> Form Validation Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Form Validation Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-07 14:29:06 --> Controller Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Carabiner: Library initialized.
DEBUG - 2016-09-07 14:29:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-07 14:29:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-07 14:29:06 --> Carabiner: library configured.
DEBUG - 2016-09-07 14:29:06 --> Carabiner: library configured.
DEBUG - 2016-09-07 14:29:06 --> User Agent Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Model Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Model Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Model Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Model Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Model Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Model Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Model Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Model Class Initialized
ERROR - 2016-09-07 14:29:06 --> Hak Akses modul/kontroller 'member' untuk role 'unkown' belum di set.
DEBUG - 2016-09-07 14:29:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-07 14:29:06 --> Form Validation Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-07 14:29:06 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2016-09-07 14:29:06 --> Config Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:29:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:29:06 --> URI Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Router Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Output Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Security Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Input Class Initialized
DEBUG - 2016-09-07 14:29:06 --> XSS Filtering completed
DEBUG - 2016-09-07 14:29:06 --> XSS Filtering completed
DEBUG - 2016-09-07 14:29:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-07 14:29:06 --> Language Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Loader Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-07 14:29:06 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-07 14:29:06 --> Helper loaded: url_helper
DEBUG - 2016-09-07 14:29:06 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-07 14:29:06 --> Helper loaded: file_helper
DEBUG - 2016-09-07 14:29:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-07 14:29:06 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-07 14:29:06 --> Helper loaded: conf_helper
DEBUG - 2016-09-07 14:29:06 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-07 14:29:06 --> Check Exists common_helper.php: No
DEBUG - 2016-09-07 14:29:06 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-07 14:29:06 --> Helper loaded: common_helper
DEBUG - 2016-09-07 14:29:06 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-07 14:29:06 --> Helper loaded: common_helper
DEBUG - 2016-09-07 14:29:06 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-07 14:29:06 --> Helper loaded: form_helper
DEBUG - 2016-09-07 14:29:06 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-07 14:29:06 --> Helper loaded: security_helper
DEBUG - 2016-09-07 14:29:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-07 14:29:06 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-07 14:29:06 --> Helper loaded: lang_helper
DEBUG - 2016-09-07 14:29:06 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-07 14:29:06 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-07 14:29:06 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-07 14:29:06 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-07 14:29:06 --> Helper loaded: atlant_helper
DEBUG - 2016-09-07 14:29:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-07 14:29:06 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-07 14:29:06 --> Helper loaded: crypto_helper
DEBUG - 2016-09-07 14:29:06 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-07 14:29:06 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-07 14:29:06 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-07 14:29:06 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-07 14:29:06 --> Helper loaded: sidika_helper
DEBUG - 2016-09-07 14:29:06 --> Database Driver Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Session Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-07 14:29:06 --> Helper loaded: string_helper
DEBUG - 2016-09-07 14:29:06 --> Session routines successfully run
DEBUG - 2016-09-07 14:29:06 --> Native_session Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-07 14:29:06 --> Form Validation Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Form Validation Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-07 14:29:06 --> Controller Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Carabiner: Library initialized.
DEBUG - 2016-09-07 14:29:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-07 14:29:06 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-07 14:29:06 --> Carabiner: library configured.
DEBUG - 2016-09-07 14:29:06 --> Carabiner: library configured.
DEBUG - 2016-09-07 14:29:06 --> User Agent Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Model Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Model Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Model Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Model Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Model Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Model Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Model Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Model Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Model Class Initialized
DEBUG - 2016-09-07 14:29:06 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-07 14:29:06 --> Pagination Class Initialized
DEBUG - 2016-09-07 14:29:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-07 14:29:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-07 14:29:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-07 14:29:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-07 14:29:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-07 14:29:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-07 14:29:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-07 14:29:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-07 14:29:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-07 14:29:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-07 14:29:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-07 14:29:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-07 14:29:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-07 14:29:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-07 14:29:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-07 14:29:06 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-07 14:29:06 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-07 14:29:06 --> Final output sent to browser
DEBUG - 2016-09-07 14:29:06 --> Total execution time: 0.5401
DEBUG - 2016-09-07 14:29:50 --> Config Class Initialized
DEBUG - 2016-09-07 14:29:50 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:29:50 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:29:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:29:50 --> URI Class Initialized
DEBUG - 2016-09-07 14:29:50 --> Router Class Initialized
DEBUG - 2016-09-07 14:29:50 --> Output Class Initialized
DEBUG - 2016-09-07 14:29:50 --> Cache file has expired. File deleted
DEBUG - 2016-09-07 14:29:50 --> Security Class Initialized
DEBUG - 2016-09-07 14:29:50 --> Input Class Initialized
DEBUG - 2016-09-07 14:29:50 --> XSS Filtering completed
DEBUG - 2016-09-07 14:29:50 --> XSS Filtering completed
DEBUG - 2016-09-07 14:29:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-07 14:29:50 --> Language Class Initialized
DEBUG - 2016-09-07 14:29:50 --> Loader Class Initialized
DEBUG - 2016-09-07 14:29:50 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-07 14:29:50 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-07 14:29:50 --> Helper loaded: url_helper
DEBUG - 2016-09-07 14:29:50 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-07 14:29:50 --> Helper loaded: file_helper
DEBUG - 2016-09-07 14:29:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-07 14:29:50 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-07 14:29:50 --> Helper loaded: conf_helper
DEBUG - 2016-09-07 14:29:50 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-07 14:29:50 --> Check Exists common_helper.php: No
DEBUG - 2016-09-07 14:29:50 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-07 14:29:50 --> Helper loaded: common_helper
DEBUG - 2016-09-07 14:29:50 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-07 14:29:50 --> Helper loaded: common_helper
DEBUG - 2016-09-07 14:29:50 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-07 14:29:50 --> Helper loaded: form_helper
DEBUG - 2016-09-07 14:29:50 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-07 14:29:50 --> Helper loaded: security_helper
DEBUG - 2016-09-07 14:29:50 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-07 14:29:50 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-07 14:29:50 --> Helper loaded: lang_helper
DEBUG - 2016-09-07 14:29:51 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-07 14:29:51 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-07 14:29:51 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-07 14:29:51 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-07 14:29:51 --> Helper loaded: atlant_helper
DEBUG - 2016-09-07 14:29:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-07 14:29:51 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-07 14:29:51 --> Helper loaded: crypto_helper
DEBUG - 2016-09-07 14:29:51 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-07 14:29:51 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-07 14:29:51 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-07 14:29:51 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-07 14:29:51 --> Helper loaded: sidika_helper
DEBUG - 2016-09-07 14:29:51 --> Database Driver Class Initialized
DEBUG - 2016-09-07 14:29:51 --> Session Class Initialized
DEBUG - 2016-09-07 14:29:51 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-07 14:29:51 --> Helper loaded: string_helper
DEBUG - 2016-09-07 14:29:51 --> Session routines successfully run
DEBUG - 2016-09-07 14:29:51 --> Native_session Class Initialized
DEBUG - 2016-09-07 14:29:51 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-07 14:29:51 --> Form Validation Class Initialized
DEBUG - 2016-09-07 14:29:51 --> Form Validation Class Initialized
DEBUG - 2016-09-07 14:29:51 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-07 14:29:51 --> Controller Class Initialized
DEBUG - 2016-09-07 14:29:51 --> Carabiner: Library initialized.
DEBUG - 2016-09-07 14:29:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-07 14:29:51 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-07 14:29:51 --> Carabiner: library configured.
DEBUG - 2016-09-07 14:29:51 --> Carabiner: library configured.
DEBUG - 2016-09-07 14:29:51 --> User Agent Class Initialized
DEBUG - 2016-09-07 14:29:51 --> Model Class Initialized
DEBUG - 2016-09-07 14:29:51 --> Model Class Initialized
DEBUG - 2016-09-07 14:29:51 --> Model Class Initialized
DEBUG - 2016-09-07 14:29:51 --> Model Class Initialized
DEBUG - 2016-09-07 14:29:51 --> Model Class Initialized
DEBUG - 2016-09-07 14:29:51 --> Model Class Initialized
DEBUG - 2016-09-07 14:29:51 --> Model Class Initialized
DEBUG - 2016-09-07 14:29:51 --> Model Class Initialized
DEBUG - 2016-09-07 14:29:51 --> Model Class Initialized
DEBUG - 2016-09-07 14:29:51 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-07 14:29:51 --> Pagination Class Initialized
DEBUG - 2016-09-07 14:29:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-07 14:29:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-07 14:29:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-07 14:29:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-07 14:29:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-07 14:29:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-07 14:29:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-07 14:29:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-07 14:29:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-07 14:29:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-07 14:29:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-07 14:29:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-07 14:29:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-07 14:29:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-07 14:29:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-07 14:29:51 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-07 14:29:51 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-07 14:29:51 --> Final output sent to browser
DEBUG - 2016-09-07 14:29:51 --> Total execution time: 0.4561
DEBUG - 2016-09-07 14:30:04 --> Config Class Initialized
DEBUG - 2016-09-07 14:30:04 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:30:04 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:30:04 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:30:04 --> URI Class Initialized
DEBUG - 2016-09-07 14:30:04 --> Router Class Initialized
DEBUG - 2016-09-07 14:30:04 --> Output Class Initialized
DEBUG - 2016-09-07 14:30:04 --> Cache file has expired. File deleted
DEBUG - 2016-09-07 14:30:04 --> Security Class Initialized
DEBUG - 2016-09-07 14:30:04 --> Input Class Initialized
DEBUG - 2016-09-07 14:30:04 --> XSS Filtering completed
DEBUG - 2016-09-07 14:30:04 --> XSS Filtering completed
DEBUG - 2016-09-07 14:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-07 14:30:04 --> Language Class Initialized
DEBUG - 2016-09-07 14:30:04 --> Loader Class Initialized
DEBUG - 2016-09-07 14:30:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-07 14:30:04 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-07 14:30:04 --> Helper loaded: url_helper
DEBUG - 2016-09-07 14:30:04 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-07 14:30:04 --> Helper loaded: file_helper
DEBUG - 2016-09-07 14:30:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-07 14:30:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-07 14:30:04 --> Helper loaded: conf_helper
DEBUG - 2016-09-07 14:30:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-07 14:30:04 --> Check Exists common_helper.php: No
DEBUG - 2016-09-07 14:30:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-07 14:30:04 --> Helper loaded: common_helper
DEBUG - 2016-09-07 14:30:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-07 14:30:04 --> Helper loaded: common_helper
DEBUG - 2016-09-07 14:30:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-07 14:30:04 --> Helper loaded: form_helper
DEBUG - 2016-09-07 14:30:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-07 14:30:04 --> Helper loaded: security_helper
DEBUG - 2016-09-07 14:30:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-07 14:30:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-07 14:30:04 --> Helper loaded: lang_helper
DEBUG - 2016-09-07 14:30:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-07 14:30:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-07 14:30:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-07 14:30:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-07 14:30:04 --> Helper loaded: atlant_helper
DEBUG - 2016-09-07 14:30:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-07 14:30:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-07 14:30:04 --> Helper loaded: crypto_helper
DEBUG - 2016-09-07 14:30:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-07 14:30:04 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-07 14:30:04 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-07 14:30:04 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-07 14:30:04 --> Helper loaded: sidika_helper
DEBUG - 2016-09-07 14:30:04 --> Database Driver Class Initialized
DEBUG - 2016-09-07 14:30:04 --> Session Class Initialized
DEBUG - 2016-09-07 14:30:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-07 14:30:05 --> Helper loaded: string_helper
DEBUG - 2016-09-07 14:30:05 --> Session routines successfully run
DEBUG - 2016-09-07 14:30:05 --> Native_session Class Initialized
DEBUG - 2016-09-07 14:30:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-07 14:30:05 --> Form Validation Class Initialized
DEBUG - 2016-09-07 14:30:05 --> Form Validation Class Initialized
DEBUG - 2016-09-07 14:30:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-07 14:30:05 --> Controller Class Initialized
DEBUG - 2016-09-07 14:30:05 --> Carabiner: Library initialized.
DEBUG - 2016-09-07 14:30:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-07 14:30:05 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-07 14:30:05 --> Carabiner: library configured.
DEBUG - 2016-09-07 14:30:05 --> Carabiner: library configured.
DEBUG - 2016-09-07 14:30:05 --> User Agent Class Initialized
DEBUG - 2016-09-07 14:30:05 --> Model Class Initialized
DEBUG - 2016-09-07 14:30:05 --> Model Class Initialized
DEBUG - 2016-09-07 14:30:05 --> Model Class Initialized
DEBUG - 2016-09-07 14:30:05 --> Model Class Initialized
DEBUG - 2016-09-07 14:30:05 --> Model Class Initialized
DEBUG - 2016-09-07 14:30:05 --> Model Class Initialized
DEBUG - 2016-09-07 14:30:05 --> Model Class Initialized
DEBUG - 2016-09-07 14:30:05 --> Model Class Initialized
DEBUG - 2016-09-07 14:30:05 --> Model Class Initialized
DEBUG - 2016-09-07 14:30:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-07 14:30:05 --> Pagination Class Initialized
DEBUG - 2016-09-07 14:30:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-07 14:30:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-07 14:30:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-07 14:30:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-07 14:30:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-07 14:30:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-07 14:30:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-07 14:30:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-07 14:30:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-07 14:30:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-07 14:30:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-07 14:30:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-07 14:30:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-07 14:30:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-07 14:30:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-07 14:30:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-07 14:30:05 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-07 14:30:05 --> Final output sent to browser
DEBUG - 2016-09-07 14:30:05 --> Total execution time: 0.4844
DEBUG - 2016-09-07 14:30:44 --> Config Class Initialized
DEBUG - 2016-09-07 14:30:44 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:30:44 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:30:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:30:44 --> URI Class Initialized
DEBUG - 2016-09-07 14:30:44 --> Router Class Initialized
DEBUG - 2016-09-07 14:30:44 --> Output Class Initialized
DEBUG - 2016-09-07 14:30:44 --> Cache file has expired. File deleted
DEBUG - 2016-09-07 14:30:44 --> Security Class Initialized
DEBUG - 2016-09-07 14:30:44 --> Input Class Initialized
DEBUG - 2016-09-07 14:30:44 --> XSS Filtering completed
DEBUG - 2016-09-07 14:30:44 --> XSS Filtering completed
DEBUG - 2016-09-07 14:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-07 14:30:44 --> Language Class Initialized
DEBUG - 2016-09-07 14:30:44 --> Loader Class Initialized
DEBUG - 2016-09-07 14:30:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-07 14:30:44 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-07 14:30:44 --> Helper loaded: url_helper
DEBUG - 2016-09-07 14:30:44 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-07 14:30:44 --> Helper loaded: file_helper
DEBUG - 2016-09-07 14:30:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-07 14:30:44 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-07 14:30:44 --> Helper loaded: conf_helper
DEBUG - 2016-09-07 14:30:44 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-07 14:30:44 --> Check Exists common_helper.php: No
DEBUG - 2016-09-07 14:30:44 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-07 14:30:44 --> Helper loaded: common_helper
DEBUG - 2016-09-07 14:30:44 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-07 14:30:44 --> Helper loaded: common_helper
DEBUG - 2016-09-07 14:30:44 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-07 14:30:44 --> Helper loaded: form_helper
DEBUG - 2016-09-07 14:30:44 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-07 14:30:44 --> Helper loaded: security_helper
DEBUG - 2016-09-07 14:30:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-07 14:30:44 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-07 14:30:44 --> Helper loaded: lang_helper
DEBUG - 2016-09-07 14:30:44 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-07 14:30:44 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-07 14:30:44 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-07 14:30:44 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-07 14:30:44 --> Helper loaded: atlant_helper
DEBUG - 2016-09-07 14:30:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-07 14:30:44 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-07 14:30:44 --> Helper loaded: crypto_helper
DEBUG - 2016-09-07 14:30:44 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-07 14:30:44 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-07 14:30:44 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-07 14:30:44 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-07 14:30:44 --> Helper loaded: sidika_helper
DEBUG - 2016-09-07 14:30:44 --> Database Driver Class Initialized
DEBUG - 2016-09-07 14:30:44 --> Session Class Initialized
DEBUG - 2016-09-07 14:30:44 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-07 14:30:44 --> Helper loaded: string_helper
DEBUG - 2016-09-07 14:30:44 --> Session routines successfully run
DEBUG - 2016-09-07 14:30:44 --> Native_session Class Initialized
DEBUG - 2016-09-07 14:30:44 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-07 14:30:44 --> Form Validation Class Initialized
DEBUG - 2016-09-07 14:30:44 --> Form Validation Class Initialized
DEBUG - 2016-09-07 14:30:44 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-07 14:30:44 --> Controller Class Initialized
DEBUG - 2016-09-07 14:30:44 --> Carabiner: Library initialized.
DEBUG - 2016-09-07 14:30:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-07 14:30:44 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-07 14:30:44 --> Carabiner: library configured.
DEBUG - 2016-09-07 14:30:44 --> Carabiner: library configured.
DEBUG - 2016-09-07 14:30:44 --> User Agent Class Initialized
DEBUG - 2016-09-07 14:30:44 --> Model Class Initialized
DEBUG - 2016-09-07 14:30:44 --> Model Class Initialized
DEBUG - 2016-09-07 14:30:44 --> Model Class Initialized
DEBUG - 2016-09-07 14:30:44 --> Model Class Initialized
DEBUG - 2016-09-07 14:30:44 --> Model Class Initialized
DEBUG - 2016-09-07 14:30:44 --> Model Class Initialized
DEBUG - 2016-09-07 14:30:44 --> Model Class Initialized
DEBUG - 2016-09-07 14:30:44 --> Model Class Initialized
DEBUG - 2016-09-07 14:30:44 --> Model Class Initialized
DEBUG - 2016-09-07 14:30:44 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-07 14:30:44 --> Pagination Class Initialized
DEBUG - 2016-09-07 14:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-07 14:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-09-07 14:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-07 14:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-07 14:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-07 14:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-07 14:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-07 14:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-07 14:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-07 14:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-07 14:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-07 14:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-07 14:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-07 14:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-09-07 14:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-07 14:30:44 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-07 14:30:44 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-09-07 14:30:44 --> Final output sent to browser
DEBUG - 2016-09-07 14:30:44 --> Total execution time: 0.4767
DEBUG - 2016-09-07 14:30:48 --> Config Class Initialized
DEBUG - 2016-09-07 14:30:48 --> Hooks Class Initialized
DEBUG - 2016-09-07 14:30:48 --> Utf8 Class Initialized
DEBUG - 2016-09-07 14:30:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-07 14:30:48 --> URI Class Initialized
DEBUG - 2016-09-07 14:30:48 --> Router Class Initialized
DEBUG - 2016-09-07 14:30:48 --> Output Class Initialized
DEBUG - 2016-09-07 14:30:48 --> Cache file has expired. File deleted
DEBUG - 2016-09-07 14:30:48 --> Security Class Initialized
DEBUG - 2016-09-07 14:30:48 --> Input Class Initialized
DEBUG - 2016-09-07 14:30:48 --> XSS Filtering completed
DEBUG - 2016-09-07 14:30:48 --> XSS Filtering completed
DEBUG - 2016-09-07 14:30:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-07 14:30:48 --> Language Class Initialized
DEBUG - 2016-09-07 14:30:48 --> Loader Class Initialized
DEBUG - 2016-09-07 14:30:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-09-07 14:30:48 --> Check Exists url_helper.php: Yes
DEBUG - 2016-09-07 14:30:48 --> Helper loaded: url_helper
DEBUG - 2016-09-07 14:30:48 --> Check Exists file_helper.php: Yes
DEBUG - 2016-09-07 14:30:48 --> Helper loaded: file_helper
DEBUG - 2016-09-07 14:30:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-07 14:30:48 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-09-07 14:30:48 --> Helper loaded: conf_helper
DEBUG - 2016-09-07 14:30:48 --> Check Exists conf_helper.php: No
DEBUG - 2016-09-07 14:30:48 --> Check Exists common_helper.php: No
DEBUG - 2016-09-07 14:30:48 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-09-07 14:30:48 --> Helper loaded: common_helper
DEBUG - 2016-09-07 14:30:48 --> Check Exists common_helper.php: Yes
DEBUG - 2016-09-07 14:30:48 --> Helper loaded: common_helper
DEBUG - 2016-09-07 14:30:48 --> Check Exists form_helper.php: Yes
DEBUG - 2016-09-07 14:30:48 --> Helper loaded: form_helper
DEBUG - 2016-09-07 14:30:48 --> Check Exists security_helper.php: Yes
DEBUG - 2016-09-07 14:30:48 --> Helper loaded: security_helper
DEBUG - 2016-09-07 14:30:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-07 14:30:48 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-09-07 14:30:48 --> Helper loaded: lang_helper
DEBUG - 2016-09-07 14:30:48 --> Check Exists lang_helper.php: No
DEBUG - 2016-09-07 14:30:48 --> Check Exists atlant_helper.php: No
DEBUG - 2016-09-07 14:30:48 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-09-07 14:30:48 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-09-07 14:30:48 --> Helper loaded: atlant_helper
DEBUG - 2016-09-07 14:30:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-07 14:30:48 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-09-07 14:30:48 --> Helper loaded: crypto_helper
DEBUG - 2016-09-07 14:30:48 --> Check Exists crypto_helper.php: No
DEBUG - 2016-09-07 14:30:48 --> Check Exists sidika_helper.php: No
DEBUG - 2016-09-07 14:30:48 --> Check Exists LWS_sidika_helper.php: No
DEBUG - 2016-09-07 14:30:48 --> Check Exists sidika_helper.php: Yes
DEBUG - 2016-09-07 14:30:48 --> Helper loaded: sidika_helper
DEBUG - 2016-09-07 14:30:48 --> Database Driver Class Initialized
DEBUG - 2016-09-07 14:30:48 --> Session Class Initialized
DEBUG - 2016-09-07 14:30:48 --> Check Exists string_helper.php: Yes
DEBUG - 2016-09-07 14:30:48 --> Helper loaded: string_helper
DEBUG - 2016-09-07 14:30:48 --> Session routines successfully run
DEBUG - 2016-09-07 14:30:48 --> Native_session Class Initialized
DEBUG - 2016-09-07 14:30:48 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-09-07 14:30:48 --> Form Validation Class Initialized
DEBUG - 2016-09-07 14:30:48 --> Form Validation Class Initialized
DEBUG - 2016-09-07 14:30:48 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-09-07 14:30:48 --> Controller Class Initialized
DEBUG - 2016-09-07 14:30:48 --> Carabiner: Library initialized.
DEBUG - 2016-09-07 14:30:48 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-09-07 14:30:48 --> Carabiner: config loaded from config file.
DEBUG - 2016-09-07 14:30:48 --> Carabiner: library configured.
DEBUG - 2016-09-07 14:30:48 --> Carabiner: library configured.
DEBUG - 2016-09-07 14:30:48 --> User Agent Class Initialized
DEBUG - 2016-09-07 14:30:49 --> Model Class Initialized
DEBUG - 2016-09-07 14:30:49 --> Model Class Initialized
DEBUG - 2016-09-07 14:30:49 --> Model Class Initialized
DEBUG - 2016-09-07 14:30:49 --> Model Class Initialized
DEBUG - 2016-09-07 14:30:49 --> Model Class Initialized
DEBUG - 2016-09-07 14:30:49 --> Model Class Initialized
DEBUG - 2016-09-07 14:30:49 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-09-07 14:30:49 --> Pagination Class Initialized
DEBUG - 2016-09-07 14:30:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-09-07 14:30:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-09-07 14:30:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-07 14:30:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-07 14:30:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-07 14:30:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-07 14:30:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-07 14:30:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-07 14:30:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-07 14:30:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-09-07 14:30:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-09-07 14:30:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-09-07 14:30:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-09-07 14:30:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-09-07 14:30:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-09-07 14:30:49 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-09-07 14:30:49 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/06a945f8d054fbc70f1f95b91abc095c
DEBUG - 2016-09-07 14:30:49 --> Final output sent to browser
DEBUG - 2016-09-07 14:30:49 --> Total execution time: 0.6793
