<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-06-24 18:13:34 --> Config Class Initialized
DEBUG - 2016-06-24 18:13:34 --> Hooks Class Initialized
DEBUG - 2016-06-24 18:13:34 --> Utf8 Class Initialized
DEBUG - 2016-06-24 18:13:34 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 18:13:34 --> URI Class Initialized
DEBUG - 2016-06-24 18:13:34 --> Router Class Initialized
DEBUG - 2016-06-24 18:13:34 --> Output Class Initialized
DEBUG - 2016-06-24 18:13:34 --> Cache file has expired. File deleted
DEBUG - 2016-06-24 18:13:34 --> Security Class Initialized
DEBUG - 2016-06-24 18:13:34 --> Input Class Initialized
DEBUG - 2016-06-24 18:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 18:13:34 --> Language Class Initialized
DEBUG - 2016-06-24 18:13:34 --> Loader Class Initialized
DEBUG - 2016-06-24 18:13:34 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-24 18:13:34 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-24 18:13:34 --> Helper loaded: url_helper
DEBUG - 2016-06-24 18:13:34 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-24 18:13:34 --> Helper loaded: file_helper
DEBUG - 2016-06-24 18:13:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-24 18:13:34 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-24 18:13:34 --> Helper loaded: conf_helper
DEBUG - 2016-06-24 18:13:34 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-24 18:13:34 --> Check Exists common_helper.php: No
DEBUG - 2016-06-24 18:13:34 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-24 18:13:34 --> Helper loaded: common_helper
DEBUG - 2016-06-24 18:13:34 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-24 18:13:34 --> Helper loaded: common_helper
DEBUG - 2016-06-24 18:13:34 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-24 18:13:34 --> Helper loaded: form_helper
DEBUG - 2016-06-24 18:13:34 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-24 18:13:34 --> Helper loaded: security_helper
DEBUG - 2016-06-24 18:13:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-24 18:13:34 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-24 18:13:34 --> Helper loaded: lang_helper
DEBUG - 2016-06-24 18:13:34 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-24 18:13:34 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-24 18:13:34 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-24 18:13:34 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-24 18:13:34 --> Helper loaded: atlant_helper
DEBUG - 2016-06-24 18:13:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-24 18:13:34 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-24 18:13:34 --> Helper loaded: crypto_helper
DEBUG - 2016-06-24 18:13:34 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-24 18:13:34 --> Database Driver Class Initialized
DEBUG - 2016-06-24 18:13:35 --> Session Class Initialized
DEBUG - 2016-06-24 18:13:35 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-24 18:13:35 --> Helper loaded: string_helper
DEBUG - 2016-06-24 18:13:35 --> A session cookie was not found.
DEBUG - 2016-06-24 18:13:35 --> Session routines successfully run
DEBUG - 2016-06-24 18:13:35 --> Native_session Class Initialized
DEBUG - 2016-06-24 18:13:35 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-24 18:13:35 --> Form Validation Class Initialized
DEBUG - 2016-06-24 18:13:35 --> Form Validation Class Initialized
DEBUG - 2016-06-24 18:13:35 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-24 18:13:35 --> Controller Class Initialized
DEBUG - 2016-06-24 18:13:35 --> Carabiner: Library initialized.
DEBUG - 2016-06-24 18:13:35 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-24 18:13:35 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-24 18:13:35 --> Carabiner: library configured.
DEBUG - 2016-06-24 18:13:35 --> Carabiner: library configured.
DEBUG - 2016-06-24 18:13:35 --> User Agent Class Initialized
DEBUG - 2016-06-24 18:13:35 --> Model Class Initialized
DEBUG - 2016-06-24 18:13:35 --> Model Class Initialized
DEBUG - 2016-06-24 18:13:35 --> Model Class Initialized
DEBUG - 2016-06-24 18:13:36 --> Model Class Initialized
DEBUG - 2016-06-24 18:13:37 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-06-24 18:13:37 --> Pagination Class Initialized
DEBUG - 2016-06-24 18:13:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-24 18:13:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/index.php
DEBUG - 2016-06-24 18:13:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-24 18:13:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-24 18:13:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-24 18:13:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-24 18:13:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-06-24 18:13:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-24 18:13:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-24 18:13:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-24 18:13:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-24 18:13:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-24 18:13:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-24 18:13:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cref_provinsi/js/index_js.php
DEBUG - 2016-06-24 18:13:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-24 18:13:37 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-24 18:13:37 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/0afc8ae14bdb2df5b4e2fbf4366db4fc
DEBUG - 2016-06-24 18:13:37 --> Final output sent to browser
DEBUG - 2016-06-24 18:13:37 --> Total execution time: 3.2467
DEBUG - 2016-06-24 18:13:43 --> Config Class Initialized
DEBUG - 2016-06-24 18:13:43 --> Hooks Class Initialized
DEBUG - 2016-06-24 18:13:43 --> Utf8 Class Initialized
DEBUG - 2016-06-24 18:13:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 18:13:43 --> URI Class Initialized
DEBUG - 2016-06-24 18:13:43 --> Router Class Initialized
ERROR - 2016-06-24 18:13:43 --> 404 Page Not Found --> back_end/favicon.ico
DEBUG - 2016-06-24 18:36:58 --> Config Class Initialized
DEBUG - 2016-06-24 18:36:58 --> Hooks Class Initialized
DEBUG - 2016-06-24 18:36:58 --> Utf8 Class Initialized
DEBUG - 2016-06-24 18:36:58 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 18:36:58 --> URI Class Initialized
DEBUG - 2016-06-24 18:36:58 --> Router Class Initialized
DEBUG - 2016-06-24 18:36:58 --> Output Class Initialized
DEBUG - 2016-06-24 18:36:58 --> Cache file has expired. File deleted
DEBUG - 2016-06-24 18:36:58 --> Security Class Initialized
DEBUG - 2016-06-24 18:36:58 --> Input Class Initialized
DEBUG - 2016-06-24 18:36:58 --> XSS Filtering completed
DEBUG - 2016-06-24 18:36:58 --> XSS Filtering completed
DEBUG - 2016-06-24 18:36:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 18:36:58 --> Language Class Initialized
DEBUG - 2016-06-24 18:36:59 --> Loader Class Initialized
DEBUG - 2016-06-24 18:36:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-24 18:36:59 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-24 18:36:59 --> Helper loaded: url_helper
DEBUG - 2016-06-24 18:36:59 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-24 18:36:59 --> Helper loaded: file_helper
DEBUG - 2016-06-24 18:36:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-24 18:36:59 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-24 18:36:59 --> Helper loaded: conf_helper
DEBUG - 2016-06-24 18:36:59 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-24 18:36:59 --> Check Exists common_helper.php: No
DEBUG - 2016-06-24 18:36:59 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-24 18:36:59 --> Helper loaded: common_helper
DEBUG - 2016-06-24 18:36:59 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-24 18:36:59 --> Helper loaded: common_helper
DEBUG - 2016-06-24 18:36:59 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-24 18:36:59 --> Helper loaded: form_helper
DEBUG - 2016-06-24 18:36:59 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-24 18:36:59 --> Helper loaded: security_helper
DEBUG - 2016-06-24 18:36:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-24 18:36:59 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-24 18:36:59 --> Helper loaded: lang_helper
DEBUG - 2016-06-24 18:36:59 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-24 18:36:59 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-24 18:36:59 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-24 18:36:59 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-24 18:36:59 --> Helper loaded: atlant_helper
DEBUG - 2016-06-24 18:36:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-24 18:36:59 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-24 18:36:59 --> Helper loaded: crypto_helper
DEBUG - 2016-06-24 18:36:59 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-24 18:36:59 --> Database Driver Class Initialized
DEBUG - 2016-06-24 18:36:59 --> Session Class Initialized
DEBUG - 2016-06-24 18:36:59 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-24 18:36:59 --> Helper loaded: string_helper
DEBUG - 2016-06-24 18:36:59 --> Session routines successfully run
DEBUG - 2016-06-24 18:36:59 --> Native_session Class Initialized
DEBUG - 2016-06-24 18:36:59 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-24 18:36:59 --> Form Validation Class Initialized
DEBUG - 2016-06-24 18:36:59 --> Form Validation Class Initialized
DEBUG - 2016-06-24 18:36:59 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-24 18:36:59 --> Controller Class Initialized
DEBUG - 2016-06-24 18:36:59 --> Carabiner: Library initialized.
DEBUG - 2016-06-24 18:36:59 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-24 18:36:59 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-24 18:36:59 --> Carabiner: library configured.
DEBUG - 2016-06-24 18:36:59 --> Carabiner: library configured.
DEBUG - 2016-06-24 18:36:59 --> User Agent Class Initialized
DEBUG - 2016-06-24 18:36:59 --> Model Class Initialized
DEBUG - 2016-06-24 18:36:59 --> Model Class Initialized
DEBUG - 2016-06-24 18:36:59 --> Model Class Initialized
DEBUG - 2016-06-24 18:36:59 --> Model Class Initialized
DEBUG - 2016-06-24 18:36:59 --> Model Class Initialized
DEBUG - 2016-06-24 18:36:59 --> Model Class Initialized
DEBUG - 2016-06-24 18:36:59 --> Model Class Initialized
DEBUG - 2016-06-24 18:36:59 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:00 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-06-24 18:37:00 --> Pagination Class Initialized
DEBUG - 2016-06-24 18:37:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-24 18:37:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-06-24 18:37:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-24 18:37:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-24 18:37:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-24 18:37:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-24 18:37:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-06-24 18:37:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-24 18:37:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-24 18:37:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-24 18:37:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-24 18:37:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-24 18:37:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-24 18:37:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-06-24 18:37:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-24 18:37:00 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-24 18:37:00 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-06-24 18:37:00 --> Final output sent to browser
DEBUG - 2016-06-24 18:37:00 --> Total execution time: 1.3091
DEBUG - 2016-06-24 18:37:04 --> Config Class Initialized
DEBUG - 2016-06-24 18:37:04 --> Hooks Class Initialized
DEBUG - 2016-06-24 18:37:04 --> Utf8 Class Initialized
DEBUG - 2016-06-24 18:37:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 18:37:04 --> URI Class Initialized
DEBUG - 2016-06-24 18:37:04 --> Router Class Initialized
DEBUG - 2016-06-24 18:37:04 --> Output Class Initialized
DEBUG - 2016-06-24 18:37:04 --> Security Class Initialized
DEBUG - 2016-06-24 18:37:04 --> Input Class Initialized
DEBUG - 2016-06-24 18:37:04 --> XSS Filtering completed
DEBUG - 2016-06-24 18:37:04 --> XSS Filtering completed
DEBUG - 2016-06-24 18:37:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 18:37:04 --> Language Class Initialized
DEBUG - 2016-06-24 18:37:04 --> Loader Class Initialized
DEBUG - 2016-06-24 18:37:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-24 18:37:04 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-24 18:37:04 --> Helper loaded: url_helper
DEBUG - 2016-06-24 18:37:04 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-24 18:37:04 --> Helper loaded: file_helper
DEBUG - 2016-06-24 18:37:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-24 18:37:04 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-24 18:37:04 --> Helper loaded: conf_helper
DEBUG - 2016-06-24 18:37:04 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-24 18:37:04 --> Check Exists common_helper.php: No
DEBUG - 2016-06-24 18:37:04 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-24 18:37:04 --> Helper loaded: common_helper
DEBUG - 2016-06-24 18:37:04 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-24 18:37:04 --> Helper loaded: common_helper
DEBUG - 2016-06-24 18:37:04 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-24 18:37:04 --> Helper loaded: form_helper
DEBUG - 2016-06-24 18:37:04 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-24 18:37:04 --> Helper loaded: security_helper
DEBUG - 2016-06-24 18:37:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-24 18:37:04 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-24 18:37:04 --> Helper loaded: lang_helper
DEBUG - 2016-06-24 18:37:04 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-24 18:37:04 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-24 18:37:04 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-24 18:37:04 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-24 18:37:04 --> Helper loaded: atlant_helper
DEBUG - 2016-06-24 18:37:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-24 18:37:04 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-24 18:37:04 --> Helper loaded: crypto_helper
DEBUG - 2016-06-24 18:37:04 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-24 18:37:04 --> Database Driver Class Initialized
DEBUG - 2016-06-24 18:37:04 --> Session Class Initialized
DEBUG - 2016-06-24 18:37:04 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-24 18:37:04 --> Helper loaded: string_helper
DEBUG - 2016-06-24 18:37:04 --> Session routines successfully run
DEBUG - 2016-06-24 18:37:04 --> Native_session Class Initialized
DEBUG - 2016-06-24 18:37:04 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-24 18:37:04 --> Form Validation Class Initialized
DEBUG - 2016-06-24 18:37:04 --> Form Validation Class Initialized
DEBUG - 2016-06-24 18:37:04 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-24 18:37:04 --> Controller Class Initialized
DEBUG - 2016-06-24 18:37:04 --> Carabiner: Library initialized.
DEBUG - 2016-06-24 18:37:04 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-24 18:37:04 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-24 18:37:04 --> Carabiner: library configured.
DEBUG - 2016-06-24 18:37:04 --> Carabiner: library configured.
DEBUG - 2016-06-24 18:37:04 --> User Agent Class Initialized
DEBUG - 2016-06-24 18:37:04 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:04 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:04 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:04 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:04 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-24 18:37:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-24 18:37:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-24 18:37:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-24 18:37:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-24 18:37:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-24 18:37:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-24 18:37:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-24 18:37:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-24 18:37:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-24 18:37:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-24 18:37:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-24 18:37:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-24 18:37:04 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-24 18:37:04 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-24 18:37:04 --> Final output sent to browser
DEBUG - 2016-06-24 18:37:04 --> Total execution time: 0.3067
DEBUG - 2016-06-24 18:37:05 --> Config Class Initialized
DEBUG - 2016-06-24 18:37:05 --> Hooks Class Initialized
DEBUG - 2016-06-24 18:37:05 --> Utf8 Class Initialized
DEBUG - 2016-06-24 18:37:05 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 18:37:05 --> URI Class Initialized
DEBUG - 2016-06-24 18:37:05 --> Router Class Initialized
DEBUG - 2016-06-24 18:37:05 --> Output Class Initialized
DEBUG - 2016-06-24 18:37:05 --> Cache file has expired. File deleted
DEBUG - 2016-06-24 18:37:05 --> Security Class Initialized
DEBUG - 2016-06-24 18:37:05 --> Input Class Initialized
DEBUG - 2016-06-24 18:37:05 --> XSS Filtering completed
DEBUG - 2016-06-24 18:37:05 --> XSS Filtering completed
DEBUG - 2016-06-24 18:37:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 18:37:05 --> Language Class Initialized
DEBUG - 2016-06-24 18:37:05 --> Loader Class Initialized
DEBUG - 2016-06-24 18:37:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-24 18:37:05 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-24 18:37:05 --> Helper loaded: url_helper
DEBUG - 2016-06-24 18:37:05 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-24 18:37:05 --> Helper loaded: file_helper
DEBUG - 2016-06-24 18:37:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-24 18:37:05 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-24 18:37:05 --> Helper loaded: conf_helper
DEBUG - 2016-06-24 18:37:05 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-24 18:37:05 --> Check Exists common_helper.php: No
DEBUG - 2016-06-24 18:37:05 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-24 18:37:05 --> Helper loaded: common_helper
DEBUG - 2016-06-24 18:37:05 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-24 18:37:05 --> Helper loaded: common_helper
DEBUG - 2016-06-24 18:37:05 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-24 18:37:05 --> Helper loaded: form_helper
DEBUG - 2016-06-24 18:37:05 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-24 18:37:05 --> Helper loaded: security_helper
DEBUG - 2016-06-24 18:37:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-24 18:37:05 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-24 18:37:05 --> Helper loaded: lang_helper
DEBUG - 2016-06-24 18:37:05 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-24 18:37:05 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-24 18:37:05 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-24 18:37:05 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-24 18:37:05 --> Helper loaded: atlant_helper
DEBUG - 2016-06-24 18:37:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-24 18:37:05 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-24 18:37:05 --> Helper loaded: crypto_helper
DEBUG - 2016-06-24 18:37:05 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-24 18:37:05 --> Database Driver Class Initialized
DEBUG - 2016-06-24 18:37:05 --> Session Class Initialized
DEBUG - 2016-06-24 18:37:05 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-24 18:37:05 --> Helper loaded: string_helper
DEBUG - 2016-06-24 18:37:05 --> Session routines successfully run
DEBUG - 2016-06-24 18:37:05 --> Native_session Class Initialized
DEBUG - 2016-06-24 18:37:05 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-24 18:37:05 --> Form Validation Class Initialized
DEBUG - 2016-06-24 18:37:05 --> Form Validation Class Initialized
DEBUG - 2016-06-24 18:37:05 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-24 18:37:05 --> Controller Class Initialized
DEBUG - 2016-06-24 18:37:05 --> Carabiner: Library initialized.
DEBUG - 2016-06-24 18:37:05 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-24 18:37:05 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-24 18:37:05 --> Carabiner: library configured.
DEBUG - 2016-06-24 18:37:05 --> Carabiner: library configured.
DEBUG - 2016-06-24 18:37:05 --> User Agent Class Initialized
DEBUG - 2016-06-24 18:37:05 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:05 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:05 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:05 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:05 --> Model Class Initialized
ERROR - 2016-06-24 18:37:05 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-24 18:37:05 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-24 18:37:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-24 18:37:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-24 18:37:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-24 18:37:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-24 18:37:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-24 18:37:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-24 18:37:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-24 18:37:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-24 18:37:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-24 18:37:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-24 18:37:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-24 18:37:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-24 18:37:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-24 18:37:05 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-24 18:37:05 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-24 18:37:05 --> Final output sent to browser
DEBUG - 2016-06-24 18:37:05 --> Total execution time: 0.2539
DEBUG - 2016-06-24 18:37:51 --> Config Class Initialized
DEBUG - 2016-06-24 18:37:51 --> Hooks Class Initialized
DEBUG - 2016-06-24 18:37:51 --> Utf8 Class Initialized
DEBUG - 2016-06-24 18:37:51 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 18:37:51 --> URI Class Initialized
DEBUG - 2016-06-24 18:37:51 --> Router Class Initialized
DEBUG - 2016-06-24 18:37:51 --> Output Class Initialized
DEBUG - 2016-06-24 18:37:51 --> Cache file has expired. File deleted
DEBUG - 2016-06-24 18:37:51 --> Security Class Initialized
DEBUG - 2016-06-24 18:37:51 --> Input Class Initialized
DEBUG - 2016-06-24 18:37:51 --> XSS Filtering completed
DEBUG - 2016-06-24 18:37:51 --> XSS Filtering completed
DEBUG - 2016-06-24 18:37:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 18:37:51 --> Language Class Initialized
DEBUG - 2016-06-24 18:37:51 --> Loader Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-24 18:37:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-24 18:37:52 --> Helper loaded: url_helper
DEBUG - 2016-06-24 18:37:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-24 18:37:52 --> Helper loaded: file_helper
DEBUG - 2016-06-24 18:37:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-24 18:37:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-24 18:37:52 --> Helper loaded: conf_helper
DEBUG - 2016-06-24 18:37:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-24 18:37:52 --> Check Exists common_helper.php: No
DEBUG - 2016-06-24 18:37:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-24 18:37:52 --> Helper loaded: common_helper
DEBUG - 2016-06-24 18:37:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-24 18:37:52 --> Helper loaded: common_helper
DEBUG - 2016-06-24 18:37:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-24 18:37:52 --> Helper loaded: form_helper
DEBUG - 2016-06-24 18:37:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-24 18:37:52 --> Helper loaded: security_helper
DEBUG - 2016-06-24 18:37:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-24 18:37:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-24 18:37:52 --> Helper loaded: lang_helper
DEBUG - 2016-06-24 18:37:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-24 18:37:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-24 18:37:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-24 18:37:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-24 18:37:52 --> Helper loaded: atlant_helper
DEBUG - 2016-06-24 18:37:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-24 18:37:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-24 18:37:52 --> Helper loaded: crypto_helper
DEBUG - 2016-06-24 18:37:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-24 18:37:52 --> Database Driver Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Session Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-24 18:37:52 --> Helper loaded: string_helper
DEBUG - 2016-06-24 18:37:52 --> Session routines successfully run
DEBUG - 2016-06-24 18:37:52 --> Native_session Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-24 18:37:52 --> Form Validation Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Form Validation Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-24 18:37:52 --> Controller Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Carabiner: Library initialized.
DEBUG - 2016-06-24 18:37:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-24 18:37:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-24 18:37:52 --> Carabiner: library configured.
DEBUG - 2016-06-24 18:37:52 --> Carabiner: library configured.
DEBUG - 2016-06-24 18:37:52 --> User Agent Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-06-24 18:37:52 --> Pagination Class Initialized
DEBUG - 2016-06-24 18:37:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-24 18:37:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/index.php
DEBUG - 2016-06-24 18:37:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-24 18:37:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-24 18:37:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-24 18:37:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-24 18:37:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-06-24 18:37:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-24 18:37:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-24 18:37:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-24 18:37:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-24 18:37:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-24 18:37:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-24 18:37:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/js/index_js.php
DEBUG - 2016-06-24 18:37:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-24 18:37:52 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-24 18:37:52 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5cf2ac055215a66f98ba4d6c33c8329d
DEBUG - 2016-06-24 18:37:52 --> Final output sent to browser
DEBUG - 2016-06-24 18:37:52 --> Total execution time: 0.4661
DEBUG - 2016-06-24 18:37:52 --> Config Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Hooks Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Utf8 Class Initialized
DEBUG - 2016-06-24 18:37:52 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 18:37:52 --> URI Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Router Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Output Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Security Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Input Class Initialized
DEBUG - 2016-06-24 18:37:52 --> XSS Filtering completed
DEBUG - 2016-06-24 18:37:52 --> XSS Filtering completed
DEBUG - 2016-06-24 18:37:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 18:37:52 --> Language Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Loader Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-24 18:37:52 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-24 18:37:52 --> Helper loaded: url_helper
DEBUG - 2016-06-24 18:37:52 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-24 18:37:52 --> Helper loaded: file_helper
DEBUG - 2016-06-24 18:37:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-24 18:37:52 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-24 18:37:52 --> Helper loaded: conf_helper
DEBUG - 2016-06-24 18:37:52 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-24 18:37:52 --> Check Exists common_helper.php: No
DEBUG - 2016-06-24 18:37:52 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-24 18:37:52 --> Helper loaded: common_helper
DEBUG - 2016-06-24 18:37:52 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-24 18:37:52 --> Helper loaded: common_helper
DEBUG - 2016-06-24 18:37:52 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-24 18:37:52 --> Helper loaded: form_helper
DEBUG - 2016-06-24 18:37:52 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-24 18:37:52 --> Helper loaded: security_helper
DEBUG - 2016-06-24 18:37:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-24 18:37:52 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-24 18:37:52 --> Helper loaded: lang_helper
DEBUG - 2016-06-24 18:37:52 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-24 18:37:52 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-24 18:37:52 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-24 18:37:52 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-24 18:37:52 --> Helper loaded: atlant_helper
DEBUG - 2016-06-24 18:37:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-24 18:37:52 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-24 18:37:52 --> Helper loaded: crypto_helper
DEBUG - 2016-06-24 18:37:52 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-24 18:37:52 --> Database Driver Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Session Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-24 18:37:52 --> Helper loaded: string_helper
DEBUG - 2016-06-24 18:37:52 --> Session routines successfully run
DEBUG - 2016-06-24 18:37:52 --> Native_session Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-24 18:37:52 --> Form Validation Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Form Validation Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-24 18:37:52 --> Controller Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Carabiner: Library initialized.
DEBUG - 2016-06-24 18:37:52 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-24 18:37:52 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-24 18:37:52 --> Carabiner: library configured.
DEBUG - 2016-06-24 18:37:52 --> Carabiner: library configured.
DEBUG - 2016-06-24 18:37:52 --> User Agent Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:52 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:53 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:53 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:53 --> Config Class Initialized
DEBUG - 2016-06-24 18:37:53 --> Hooks Class Initialized
DEBUG - 2016-06-24 18:37:53 --> Utf8 Class Initialized
DEBUG - 2016-06-24 18:37:53 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 18:37:53 --> URI Class Initialized
DEBUG - 2016-06-24 18:37:53 --> Router Class Initialized
DEBUG - 2016-06-24 18:37:53 --> Output Class Initialized
DEBUG - 2016-06-24 18:37:53 --> Cache file has expired. File deleted
DEBUG - 2016-06-24 18:37:53 --> Security Class Initialized
DEBUG - 2016-06-24 18:37:53 --> Input Class Initialized
DEBUG - 2016-06-24 18:37:53 --> XSS Filtering completed
DEBUG - 2016-06-24 18:37:53 --> XSS Filtering completed
DEBUG - 2016-06-24 18:37:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 18:37:53 --> Language Class Initialized
DEBUG - 2016-06-24 18:37:53 --> Loader Class Initialized
DEBUG - 2016-06-24 18:37:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-24 18:37:53 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-24 18:37:53 --> Helper loaded: url_helper
DEBUG - 2016-06-24 18:37:53 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-24 18:37:53 --> Helper loaded: file_helper
DEBUG - 2016-06-24 18:37:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-24 18:37:53 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-24 18:37:53 --> Helper loaded: conf_helper
DEBUG - 2016-06-24 18:37:53 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-24 18:37:53 --> Check Exists common_helper.php: No
DEBUG - 2016-06-24 18:37:53 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-24 18:37:53 --> Helper loaded: common_helper
DEBUG - 2016-06-24 18:37:53 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-24 18:37:53 --> Helper loaded: common_helper
DEBUG - 2016-06-24 18:37:53 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-24 18:37:53 --> Helper loaded: form_helper
DEBUG - 2016-06-24 18:37:53 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-24 18:37:53 --> Helper loaded: security_helper
DEBUG - 2016-06-24 18:37:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-24 18:37:53 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-24 18:37:53 --> Helper loaded: lang_helper
DEBUG - 2016-06-24 18:37:53 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-24 18:37:53 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-24 18:37:53 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-24 18:37:53 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-24 18:37:53 --> Helper loaded: atlant_helper
DEBUG - 2016-06-24 18:37:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-24 18:37:53 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-24 18:37:53 --> Helper loaded: crypto_helper
DEBUG - 2016-06-24 18:37:53 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-24 18:37:53 --> Database Driver Class Initialized
DEBUG - 2016-06-24 18:37:53 --> Session Class Initialized
DEBUG - 2016-06-24 18:37:53 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-24 18:37:53 --> Helper loaded: string_helper
DEBUG - 2016-06-24 18:37:53 --> Session routines successfully run
DEBUG - 2016-06-24 18:37:53 --> Native_session Class Initialized
DEBUG - 2016-06-24 18:37:53 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-24 18:37:53 --> Form Validation Class Initialized
DEBUG - 2016-06-24 18:37:53 --> Form Validation Class Initialized
DEBUG - 2016-06-24 18:37:53 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-24 18:37:53 --> Controller Class Initialized
DEBUG - 2016-06-24 18:37:53 --> Carabiner: Library initialized.
DEBUG - 2016-06-24 18:37:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-24 18:37:53 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-24 18:37:53 --> Carabiner: library configured.
DEBUG - 2016-06-24 18:37:53 --> Carabiner: library configured.
DEBUG - 2016-06-24 18:37:53 --> User Agent Class Initialized
DEBUG - 2016-06-24 18:37:53 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:53 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:53 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:53 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:53 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:53 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:53 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:53 --> Model Class Initialized
DEBUG - 2016-06-24 18:37:53 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/paging.php
DEBUG - 2016-06-24 18:37:53 --> Pagination Class Initialized
DEBUG - 2016-06-24 18:37:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-24 18:37:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/index.php
DEBUG - 2016-06-24 18:37:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-24 18:37:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-24 18:37:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-24 18:37:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-24 18:37:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-06-24 18:37:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-24 18:37:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-24 18:37:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-24 18:37:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-24 18:37:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-24 18:37:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-24 18:37:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cdaftar_diklat/js/index_js.php
DEBUG - 2016-06-24 18:37:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-24 18:37:53 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-24 18:37:53 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/861000b47d9b180520dd0e075513d88a
DEBUG - 2016-06-24 18:37:53 --> Final output sent to browser
DEBUG - 2016-06-24 18:37:53 --> Total execution time: 0.3352
DEBUG - 2016-06-24 19:55:15 --> Config Class Initialized
DEBUG - 2016-06-24 19:55:15 --> Hooks Class Initialized
DEBUG - 2016-06-24 19:55:15 --> Utf8 Class Initialized
DEBUG - 2016-06-24 19:55:15 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 19:55:15 --> URI Class Initialized
DEBUG - 2016-06-24 19:55:15 --> Router Class Initialized
DEBUG - 2016-06-24 19:55:15 --> Output Class Initialized
DEBUG - 2016-06-24 19:55:15 --> Cache file has expired. File deleted
DEBUG - 2016-06-24 19:55:15 --> Security Class Initialized
DEBUG - 2016-06-24 19:55:15 --> Input Class Initialized
DEBUG - 2016-06-24 19:55:15 --> XSS Filtering completed
DEBUG - 2016-06-24 19:55:15 --> XSS Filtering completed
DEBUG - 2016-06-24 19:55:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 19:55:15 --> Language Class Initialized
DEBUG - 2016-06-24 19:55:15 --> Loader Class Initialized
DEBUG - 2016-06-24 19:55:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-24 19:55:16 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-24 19:55:16 --> Helper loaded: url_helper
DEBUG - 2016-06-24 19:55:16 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-24 19:55:16 --> Helper loaded: file_helper
DEBUG - 2016-06-24 19:55:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-24 19:55:16 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-24 19:55:16 --> Helper loaded: conf_helper
DEBUG - 2016-06-24 19:55:16 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-24 19:55:16 --> Check Exists common_helper.php: No
DEBUG - 2016-06-24 19:55:16 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-24 19:55:16 --> Helper loaded: common_helper
DEBUG - 2016-06-24 19:55:16 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-24 19:55:16 --> Helper loaded: common_helper
DEBUG - 2016-06-24 19:55:16 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-24 19:55:16 --> Helper loaded: form_helper
DEBUG - 2016-06-24 19:55:16 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-24 19:55:16 --> Helper loaded: security_helper
DEBUG - 2016-06-24 19:55:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-24 19:55:16 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-24 19:55:16 --> Helper loaded: lang_helper
DEBUG - 2016-06-24 19:55:16 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-24 19:55:16 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-24 19:55:16 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-24 19:55:16 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-24 19:55:16 --> Helper loaded: atlant_helper
DEBUG - 2016-06-24 19:55:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-24 19:55:16 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-24 19:55:16 --> Helper loaded: crypto_helper
DEBUG - 2016-06-24 19:55:16 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-24 19:55:16 --> Database Driver Class Initialized
DEBUG - 2016-06-24 19:55:16 --> Session Class Initialized
DEBUG - 2016-06-24 19:55:16 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-24 19:55:16 --> Helper loaded: string_helper
DEBUG - 2016-06-24 19:55:16 --> Session routines successfully run
DEBUG - 2016-06-24 19:55:16 --> Native_session Class Initialized
DEBUG - 2016-06-24 19:55:16 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-24 19:55:16 --> Form Validation Class Initialized
DEBUG - 2016-06-24 19:55:16 --> Form Validation Class Initialized
DEBUG - 2016-06-24 19:55:16 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-24 19:55:16 --> Controller Class Initialized
DEBUG - 2016-06-24 19:55:16 --> Carabiner: Library initialized.
DEBUG - 2016-06-24 19:55:16 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-24 19:55:16 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-24 19:55:16 --> Carabiner: library configured.
DEBUG - 2016-06-24 19:55:16 --> Carabiner: library configured.
DEBUG - 2016-06-24 19:55:16 --> User Agent Class Initialized
DEBUG - 2016-06-24 19:55:16 --> Model Class Initialized
DEBUG - 2016-06-24 19:55:16 --> Model Class Initialized
DEBUG - 2016-06-24 19:55:16 --> Model Class Initialized
DEBUG - 2016-06-24 19:55:17 --> Model Class Initialized
DEBUG - 2016-06-24 19:55:17 --> Model Class Initialized
DEBUG - 2016-06-24 19:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-24 19:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-24 19:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-24 19:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-24 19:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-24 19:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-24 19:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-24 19:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-24 19:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-24 19:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-24 19:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-24 19:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-24 19:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-24 19:55:17 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-24 19:55:17 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/e04533c036b8c152bd6f971633afc4a7
DEBUG - 2016-06-24 19:55:17 --> Final output sent to browser
DEBUG - 2016-06-24 19:55:17 --> Total execution time: 2.1602
DEBUG - 2016-06-24 19:55:19 --> Config Class Initialized
DEBUG - 2016-06-24 19:55:19 --> Hooks Class Initialized
DEBUG - 2016-06-24 19:55:19 --> Utf8 Class Initialized
DEBUG - 2016-06-24 19:55:19 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 19:55:19 --> URI Class Initialized
DEBUG - 2016-06-24 19:55:19 --> Router Class Initialized
DEBUG - 2016-06-24 19:55:19 --> Output Class Initialized
DEBUG - 2016-06-24 19:55:19 --> Cache file has expired. File deleted
DEBUG - 2016-06-24 19:55:19 --> Security Class Initialized
DEBUG - 2016-06-24 19:55:19 --> Input Class Initialized
DEBUG - 2016-06-24 19:55:19 --> XSS Filtering completed
DEBUG - 2016-06-24 19:55:19 --> XSS Filtering completed
DEBUG - 2016-06-24 19:55:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 19:55:19 --> Language Class Initialized
DEBUG - 2016-06-24 19:55:19 --> Loader Class Initialized
DEBUG - 2016-06-24 19:55:19 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-24 19:55:19 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-24 19:55:19 --> Helper loaded: url_helper
DEBUG - 2016-06-24 19:55:19 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-24 19:55:19 --> Helper loaded: file_helper
DEBUG - 2016-06-24 19:55:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-24 19:55:19 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-24 19:55:19 --> Helper loaded: conf_helper
DEBUG - 2016-06-24 19:55:19 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-24 19:55:20 --> Check Exists common_helper.php: No
DEBUG - 2016-06-24 19:55:20 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-24 19:55:20 --> Helper loaded: common_helper
DEBUG - 2016-06-24 19:55:20 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-24 19:55:20 --> Helper loaded: common_helper
DEBUG - 2016-06-24 19:55:20 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-24 19:55:20 --> Helper loaded: form_helper
DEBUG - 2016-06-24 19:55:20 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-24 19:55:20 --> Helper loaded: security_helper
DEBUG - 2016-06-24 19:55:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-24 19:55:20 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-24 19:55:20 --> Helper loaded: lang_helper
DEBUG - 2016-06-24 19:55:20 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-24 19:55:20 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-24 19:55:20 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-24 19:55:20 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-24 19:55:20 --> Helper loaded: atlant_helper
DEBUG - 2016-06-24 19:55:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-24 19:55:20 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-24 19:55:20 --> Helper loaded: crypto_helper
DEBUG - 2016-06-24 19:55:20 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-24 19:55:20 --> Database Driver Class Initialized
DEBUG - 2016-06-24 19:55:20 --> Session Class Initialized
DEBUG - 2016-06-24 19:55:20 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-24 19:55:20 --> Helper loaded: string_helper
DEBUG - 2016-06-24 19:55:20 --> Session routines successfully run
DEBUG - 2016-06-24 19:55:20 --> Native_session Class Initialized
DEBUG - 2016-06-24 19:55:20 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-24 19:55:20 --> Form Validation Class Initialized
DEBUG - 2016-06-24 19:55:20 --> Form Validation Class Initialized
DEBUG - 2016-06-24 19:55:20 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-24 19:55:20 --> Controller Class Initialized
DEBUG - 2016-06-24 19:55:20 --> Carabiner: Library initialized.
DEBUG - 2016-06-24 19:55:20 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-24 19:55:20 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-24 19:55:20 --> Carabiner: library configured.
DEBUG - 2016-06-24 19:55:20 --> Carabiner: library configured.
DEBUG - 2016-06-24 19:55:20 --> User Agent Class Initialized
DEBUG - 2016-06-24 19:55:20 --> Model Class Initialized
DEBUG - 2016-06-24 19:55:20 --> Model Class Initialized
DEBUG - 2016-06-24 19:55:20 --> Model Class Initialized
DEBUG - 2016-06-24 19:55:20 --> Model Class Initialized
DEBUG - 2016-06-24 19:55:20 --> Model Class Initialized
ERROR - 2016-06-24 19:55:20 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
ERROR - 2016-06-24 19:55:20 --> Severity: Notice  --> Trying to get property of non-object E:\www\CodeIgniter-2.2.6\system\core\Loader.php(769) : eval()'d code 15
DEBUG - 2016-06-24 19:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/shared/attention_message.php
DEBUG - 2016-06-24 19:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/back_end/cpeserta_diklat/upload.php
DEBUG - 2016-06-24 19:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-24 19:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-24 19:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-24 19:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-24 19:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-24 19:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-24 19:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/menu.php
DEBUG - 2016-06-24 19:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/vertical_menu.php
DEBUG - 2016-06-24 19:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/breadcrumb.php
DEBUG - 2016-06-24 19:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant/default_scripts.php
DEBUG - 2016-06-24 19:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/additional_js.php
DEBUG - 2016-06-24 19:55:20 --> File loaded: E:\www\GitHub\2016APSIDIKA\application\views/template/atlant.php
DEBUG - 2016-06-24 19:55:20 --> Cache file written: E:\www\GitHub\2016APSIDIKA\application\cache/5ce291722e4fc96871950740b9565b48
DEBUG - 2016-06-24 19:55:20 --> Final output sent to browser
DEBUG - 2016-06-24 19:55:20 --> Total execution time: 0.3890
DEBUG - 2016-06-24 19:55:39 --> Config Class Initialized
DEBUG - 2016-06-24 19:55:39 --> Hooks Class Initialized
DEBUG - 2016-06-24 19:55:39 --> Utf8 Class Initialized
DEBUG - 2016-06-24 19:55:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-24 19:55:39 --> URI Class Initialized
DEBUG - 2016-06-24 19:55:39 --> Router Class Initialized
DEBUG - 2016-06-24 19:55:39 --> Output Class Initialized
DEBUG - 2016-06-24 19:55:39 --> Cache file has expired. File deleted
DEBUG - 2016-06-24 19:55:39 --> Security Class Initialized
DEBUG - 2016-06-24 19:55:39 --> Input Class Initialized
DEBUG - 2016-06-24 19:55:39 --> XSS Filtering completed
DEBUG - 2016-06-24 19:55:39 --> XSS Filtering completed
DEBUG - 2016-06-24 19:55:39 --> XSS Filtering completed
DEBUG - 2016-06-24 19:55:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-06-24 19:55:39 --> Language Class Initialized
DEBUG - 2016-06-24 19:55:39 --> Loader Class Initialized
DEBUG - 2016-06-24 19:55:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/application.php
DEBUG - 2016-06-24 19:55:39 --> Check Exists url_helper.php: Yes
DEBUG - 2016-06-24 19:55:39 --> Helper loaded: url_helper
DEBUG - 2016-06-24 19:55:39 --> Check Exists file_helper.php: Yes
DEBUG - 2016-06-24 19:55:39 --> Helper loaded: file_helper
DEBUG - 2016-06-24 19:55:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-24 19:55:39 --> Check Exists LWS_conf_helper.php: Yes
DEBUG - 2016-06-24 19:55:39 --> Helper loaded: conf_helper
DEBUG - 2016-06-24 19:55:39 --> Check Exists conf_helper.php: No
DEBUG - 2016-06-24 19:55:39 --> Check Exists common_helper.php: No
DEBUG - 2016-06-24 19:55:39 --> Check Exists LWS_common_helper.php: Yes
DEBUG - 2016-06-24 19:55:39 --> Helper loaded: common_helper
DEBUG - 2016-06-24 19:55:39 --> Check Exists common_helper.php: Yes
DEBUG - 2016-06-24 19:55:39 --> Helper loaded: common_helper
DEBUG - 2016-06-24 19:55:39 --> Check Exists form_helper.php: Yes
DEBUG - 2016-06-24 19:55:39 --> Helper loaded: form_helper
DEBUG - 2016-06-24 19:55:39 --> Check Exists security_helper.php: Yes
DEBUG - 2016-06-24 19:55:39 --> Helper loaded: security_helper
DEBUG - 2016-06-24 19:55:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-24 19:55:39 --> Check Exists LWS_lang_helper.php: Yes
DEBUG - 2016-06-24 19:55:39 --> Helper loaded: lang_helper
DEBUG - 2016-06-24 19:55:39 --> Check Exists lang_helper.php: No
DEBUG - 2016-06-24 19:55:39 --> Check Exists atlant_helper.php: No
DEBUG - 2016-06-24 19:55:39 --> Check Exists LWS_atlant_helper.php: No
DEBUG - 2016-06-24 19:55:39 --> Check Exists atlant_helper.php: Yes
DEBUG - 2016-06-24 19:55:39 --> Helper loaded: atlant_helper
DEBUG - 2016-06-24 19:55:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-24 19:55:39 --> Check Exists LWS_crypto_helper.php: Yes
DEBUG - 2016-06-24 19:55:39 --> Helper loaded: crypto_helper
DEBUG - 2016-06-24 19:55:39 --> Check Exists crypto_helper.php: No
DEBUG - 2016-06-24 19:55:39 --> Database Driver Class Initialized
DEBUG - 2016-06-24 19:55:39 --> Session Class Initialized
DEBUG - 2016-06-24 19:55:39 --> Check Exists string_helper.php: Yes
DEBUG - 2016-06-24 19:55:39 --> Helper loaded: string_helper
DEBUG - 2016-06-24 19:55:39 --> Session routines successfully run
DEBUG - 2016-06-24 19:55:39 --> Native_session Class Initialized
DEBUG - 2016-06-24 19:55:39 --> Class Library loaded: LWS_Session on session
DEBUG - 2016-06-24 19:55:39 --> Form Validation Class Initialized
DEBUG - 2016-06-24 19:55:39 --> Form Validation Class Initialized
DEBUG - 2016-06-24 19:55:39 --> Class Library loaded: LWS_Form_validation on form_validation
DEBUG - 2016-06-24 19:55:39 --> Controller Class Initialized
DEBUG - 2016-06-24 19:55:39 --> Carabiner: Library initialized.
DEBUG - 2016-06-24 19:55:39 --> Config file loaded: E:\www\GitHub\2016APSIDIKA\application\config/carabiner.php
DEBUG - 2016-06-24 19:55:39 --> Carabiner: config loaded from config file.
DEBUG - 2016-06-24 19:55:39 --> Carabiner: library configured.
DEBUG - 2016-06-24 19:55:39 --> Carabiner: library configured.
DEBUG - 2016-06-24 19:55:39 --> User Agent Class Initialized
DEBUG - 2016-06-24 19:55:39 --> Model Class Initialized
DEBUG - 2016-06-24 19:55:39 --> Model Class Initialized
DEBUG - 2016-06-24 19:55:39 --> Model Class Initialized
DEBUG - 2016-06-24 19:55:39 --> Model Class Initialized
DEBUG - 2016-06-24 19:55:39 --> Model Class Initialized
DEBUG - 2016-06-24 19:55:39 --> Upload Class Initialized
DEBUG - 2016-06-24 19:55:39 --> Upload Class Initialized
DEBUG - 2016-06-24 19:55:39 --> Class Library loaded: LWS_Upload on upload
